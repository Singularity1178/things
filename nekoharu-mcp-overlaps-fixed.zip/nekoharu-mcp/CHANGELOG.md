# Changelog

## Unreleased - accurate text-on-page fitting

`fit_text_in_page` could report success while text was still cut off at the top (or bottom) of the page. Causes found
by reading `koharu-renderer` and fixed:

1. **Auto-fit layers were never checked.** Every translated layer is auto-fit by default, but the renderer only shrinks
   text down to 9 px (and caps free text at 24 px, ignoring `typography.size`), so long translations in small boxes still
   spill out of the frame. They are now simulated like the renderer does.
2. **Layers without an explicit `size` were skipped**, although the renderer then uses its default size.
3. **Rotation was ignored.** The frame's bounding box was used as if it were the text box, so rotated layers (author
   `angle_degrees` or a rotated 4-point frame) never looked like they overflowed. Frames are now measured in their own
   axes and the text rotated about the centre, as in `renderer.rs::placement`.
4. **Point text was treated as centred.** It is anchored at the frame's top-left corner and never wraps.
5. **Text height was `lines x line-height`, wrapped greedily with fixed average glyph widths.** The renderer uses the
   tight ink box of the real glyphs and an optimal-fit line breaker with hyphenation, so the line count (and with it the
   height) was often wrong, especially for wide comic fonts and all-caps lettering. A built-in TrueType/OpenType reader
   (`src/fontfile.js`) now provides real advances and ink bounds, and `src/textlayout.js` reproduces the line breaking.
6. **Source text was used when the translation was empty**, but Koharu draws only the translation.
7. The frame is no longer allowed to block showing the text: if the frame is bigger than the page but the text fits,
   the text is kept fully visible.

New: `find_offscreen_text` (read-only report), `include_frame` option, per-layer verification (`text.visible_after`),
`text_check` summary telling you whether real font files or estimates were used, `NEKOHARU_FONT_DIRS`.
`find_text_overlaps` / `resolve_text_overlaps` use the same text measurement.
