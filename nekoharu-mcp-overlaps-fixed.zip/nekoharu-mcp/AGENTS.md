# Working with Koharu projects through `nekoharu`

You have the **nekoharu** MCP tools. They edit Koharu / NeKoharu manga-translation projects (`*.khrproj`)
in bulk: typography, text position, visibility, and translation text. (In opencode the tools appear as
`nekoharu_<tool>`, e.g. `nekoharu_set_font_size`.)

## Ground rules

1. **The project must be closed in the Koharu app** while you edit. Tell the user to reopen it afterwards.
   Koharu does not live-reload; an open project would overwrite your changes on its next autosave.
2. **Look before you edit.** Call `project_info`, then `text_stats` (and `list_text` for specifics). Base the
   edit on what is actually there (e.g. the size histogram), not assumptions.
3. **Preview large edits** with `dry_run: true`, report the count of affected layers, then apply.
4. **Group related edits** with `batch` so they land as one revision and one `undo`.
5. **Do exactly what was asked.** No `select` means *every* text layer. If the user said "dialogue only" or
   "pages 3-9", narrow `select` accordingly; if you cannot tell which layers are meant, ask or show a preview.
6. After editing, tell the user: what changed (counts per step), the new revision, and how to revert (`undo`).

## Conventions

- Pages are 1-based. Coordinates are page pixels, origin top-left, +y is down. Bounds: `[l, t, r, b]`.
- Font size is in page pixels. Setting a size fixes it (turns auto-fit off) unless `auto_fit` is passed.
- `scale_font_size` skips auto-fit layers that have no explicit size; check `skipped` in the result and
  use `set_font_size` if the user wants those pinned too.
- Moving/resizing a layer that follows a detected region creates a manual frame for it (`reset_frame` undoes that).
- Moves are clamped inside the page unless `keep_inside_page: false`.

## Recipes

| User says | Do |
| --- | --- |
| "Make all text size 40" | `set_font_size {size: 40}` (dry run first) |
| "Bump text up 20%" | `scale_font_size {factor: 1.2}` |
| "Text on pages 5-8 is too big" | `text_stats {select:{pages:"5-8"}}` then `scale_font_size {factor: .85, select:{pages:"5-8"}}` |
| "Use font X, centered, black with white outline" | `set_typography {font:"X", alignment:"center", color:"#000000", stroke_color:"#ffffff", stroke_width:3}` |
| "Move everything up a bit" | `move_text {dy: -1.5, unit:"percent"}` |
| "Some text is cut off at the page edge" | `find_offscreen_text {margin: 4}` -> `fit_text_in_page {margin: 4}` (dry run first; it measures the rendered text incl. auto-fit, rotation, point text and outline, and moves only what is out of bounds) -> `find_offscreen_text` again to confirm |
| "Text boxes overlap / are too close" | `find_text_overlaps {margin: 6}` -> read both texts of each pair -> `resolve_text_overlaps {margin: 6, resolutions: [{layers:[a,b], push: b}]}` (dry run first) |
| "Center this bubble's text on the page" | `align_text_to_page {horizontal:"center", select:{layers:[id]}}` |
| "Make every line match this one" | `copy_typography {from_layer:id}` |
| "ALL CAPS lettering" | `transform_text {mode:"uppercase"}` |
| "Rename a character everywhere" | `replace_text {find:"Taro", replace:"Tarou", whole_word:true}` |
| "Hide the SFX" | `list_text` to find them, then `set_visibility {visible:false, select:{layers:[...]}}` |
| "Undo that" | `undo` (or `list_history` then `undo {backup}`) |

## Overlapping text

1. Call `find_text_overlaps` (optionally with `margin` for a minimum gap and `select` for pages). Each pair shows `first`
   and `second` (reading order) with their **text**, bounds, the overlap size, and `if_push_first` / `if_push_second`.
2. Read what the two layers say and decide which one should move: usually the one whose position matters less to the
   reading flow, or the one with more free space around it. A later line of dialogue normally yields to an earlier one,
   but not always (e.g. a short SFX should give way to a long speech bubble).
3. Call `resolve_text_overlaps` with `resolutions: [{layers: [a, b], push: <id of the one that moves>}]`. Use `push: "both"`
   to split the move, `axis` / `direction` to control how. Run with `dry_run: true` first and check the `reasons` per layer.
4. If you only decided some pairs, the rest are pushed automatically (later layer in reading order moves); pass
   `resolve_remaining: false` to leave them. Check `unresolved` in the result and call `find_text_overlaps` again to confirm.
   If something cannot be separated, shrink the font (`scale_font_size`) or frames (`set_frame`) instead.

## Text cut off at the page edge

Koharu centres a layer's text on its frame on both axes. Text that doesn't fit therefore spills out equally above and
below (and left/right), so the first line can be cut off while the frame looks fine. Auto-fit text cannot shrink below
9 px, so it can spill too. `fit_text_in_page` measures the real rendered text; read `text_check` and each change's `text`
(`font_size`, `lines`, `measured_with`, `visible_after`). If a layer is listed in `skipped`, the text is bigger than the
page: lower the font size (`scale_font_size`), widen the frame (`set_frame`) or enable `auto_fit`. When `measured_with`
is `approximate`, tell the user the font file wasn't found and suggest `NEKOHARU_FONT_DIRS`.

## Reading results

Editing tools return `matched_layers`, `changed_layers`, per-layer `changes` (from → to, first 30 shown),
`skipped` (with reasons), and, when saved, `saved.revision` + `saved.backup`. `changed_layers: 0` means the
project already matched and nothing was written. Errors come back as `isError` results with a plain message;
nothing is saved on error.

Never edit `.khrproj` files by hand or with other scripts; use these tools, which preserve Koharu's checksums,
slots, and invariants.
