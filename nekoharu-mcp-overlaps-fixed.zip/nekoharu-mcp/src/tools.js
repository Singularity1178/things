// The tool registry. Every tool is usable from MCP (mcp.js) and the CLI (cli.js).

import { decodeScene, encodeScene } from "./codec.js";
import {
  describeSelect,
  finalizeEpochs,
  loadModel,
  round,
  selectLayers,
  summarize,
} from "./model.js";
import * as ops from "./ops.js";
import {
  ProjectError,
  defaultProjectsDir,
  koharuMayBeRunning,
  listHistory,
  listProjects,
  openProject,
  saveProject,
  undoLast,
} from "./store.js";

const MAX_CHANGES_SHOWN = 30;
const MAX_SKIPPED_SHOWN = 15;

// --------------------------------------------------------------------- schemas

const PROJECT = {
  type: "string",
  description:
    "Path to the .khrproj folder, or a project name inside the Koharu projects directory. Optional when KOHARU_PROJECT is set.",
};
const DRY_RUN = {
  type: "boolean",
  description: "Preview the changes without saving anything. Strongly recommended before large edits.",
};
const NULLABLE = (schema) => ({
  ...schema,
  type: [schema.type, "null"],
  ...(schema.enum ? { enum: [...schema.enum, null] } : {}),
});

const SELECT = {
  type: "object",
  description:
    "Which text layers to affect. Omit (or pass {}) to affect EVERY text layer in the project. Conditions are AND-ed.",
  additionalProperties: false,
  properties: {
    pages: {
      description: 'Pages by 1-based number, range, label or id: "all", "3", "1-5,8", or an array.',
      type: ["string", "number", "array"],
      items: { type: ["string", "number"] },
    },
    layers: { type: "array", items: { type: "string" }, description: "Specific text-layer ids (from list_text). Unique 6+ char prefixes work." },
    order: { type: "string", description: 'Reading-order position within each page, 1-based: "1", "1-3,6".' },
    text_contains: { type: "string", description: "Layer text contains this (case-insensitive unless case_sensitive)." },
    text_regex: { type: "string", description: "Layer text matches this regular expression." },
    text_field: { type: "string", enum: ["translation", "source", "any"], description: "Which text text_contains/text_regex search. Default any." },
    case_sensitive: { type: "boolean" },
    has_translation: { type: "boolean" },
    font: { type: ["string", "null"], description: 'Font family currently set (case-insensitive). Use null or "none" for layers with no font set.' },
    size: { type: "number", description: "Layers whose explicit font size equals this." },
    size_min: { type: "number" },
    size_max: { type: "number" },
    auto_fit: { type: "boolean", description: "Layers using automatic fitting (true) or fixed size (false)." },
    writing_mode: { type: "string", enum: ["horizontal", "vertical"] },
    alignment: { type: "string", enum: ["start", "center", "end", "justify"] },
    layout_kind: { type: "string", enum: ["point", "paragraph"] },
    visible: { type: "boolean" },
    translation_origin: { type: "string", enum: ["user", "generated"], description: "Hand-written vs machine-generated translation." },
    bounds_within: {
      type: "array",
      items: { type: "number" },
      minItems: 4,
      maxItems: 4,
      description: "[left, top, right, bottom] in page pixels; keeps layers whose center lies inside.",
    },
  },
};

const TYPOGRAPHY_PROPS = {
  font: NULLABLE({ type: "string", description: "Font family name (null = renderer default)." }),
  font_weight: NULLABLE({ type: "integer", description: "1-1000 (400 regular, 700 bold)." }),
  font_style: NULLABLE({ type: "string", enum: ["normal", "italic", "oblique"] }),
  size: { type: "number", description: "Font size in page pixels. Setting it also turns auto_fit off unless auto_fit is given." },
  auto_fit: { type: "boolean", description: "Let Koharu fit text to its frame automatically." },
  color: NULLABLE({ type: "string", description: 'Fill color: "#rrggbb", "#rrggbbaa" or a name.' }),
  stroke_color: NULLABLE({ type: "string" }),
  stroke_width: NULLABLE({ type: "number" }),
  stroke_method: NULLABLE({ type: "string", enum: ["expansion", "contour"] }),
  stroke_position: NULLABLE({ type: "string", enum: ["outside", "center", "inside"] }),
  stroke_join: NULLABLE({ type: "string", enum: ["round", "miter", "bevel"] }),
  outer_stroke_color: NULLABLE({ type: "string" }),
  outer_stroke_width: NULLABLE({ type: "number" }),
  alignment: NULLABLE({ type: "string", enum: ["start", "center", "end", "justify"] }),
  writing_mode: NULLABLE({ type: "string", enum: ["horizontal", "vertical"] }),
  line_spacing: NULLABLE({ type: "number", description: "Baseline distance as a multiple of font size (0.1-10)." }),
};

const obj = (properties, required = []) => ({ type: "object", properties, required, additionalProperties: false });
const WRITE = (properties, required = []) =>
  obj({ project: PROJECT, select: SELECT, dry_run: DRY_RUN, ...properties }, required);

const DIRECTIONS_ENUM = ["left", "right", "up", "down"];

const TYPO_ARG_KEYS = Object.keys(TYPOGRAPHY_PROPS);

// -------------------------------------------------------------------- handlers

const READ = { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false };
const EDIT = { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: false };

const typoArgs = (args) => Object.fromEntries(TYPO_ARG_KEYS.filter((k) => k in args).map((k) => [k, args[k]]));

/** Write-tool bodies: (model, selectedLayers, args) -> { changes, skipped }. */
const EDITORS = {
  set_typography: (m, l, a) => ops.setTypography(m, l, typoArgs(a)),
  set_font_size: (m, l, a) => ops.setTypography(m, l, { size: a.size, ...(a.auto_fit !== undefined ? { auto_fit: a.auto_fit } : {}) }),
  scale_font_size: (m, l, a) => ops.scaleFontSize(m, l, a),
  copy_typography: (m, l, a) => ops.copyTypography(m, l, a.from_layer, a.fields),
  reset_typography: (m, l) => ops.resetTypography(m, l),
  move_text: (m, l, a) => ops.moveText(m, l, a),
  set_frame: (m, l, a) => ops.setFrame(m, l, a),
  align_text_to_page: (m, l, a) => ops.alignToPage(m, l, a),
  fit_text_in_page: (m, l, a) => ops.fitTextInPage(m, l, a),
  resolve_text_overlaps: (m, l, a) => ops.resolveTextOverlaps(m, l, a),
  reset_frame: (m, l) => ops.resetFrame(m, l),
  set_text_angle: (m, l, a) => ops.setAngle(m, l, a),
  set_visibility: (m, l, a) => ops.setVisibility(m, l, a),
  replace_text: (m, l, a) => ops.replaceText(m, l, a),
  transform_text: (m, l, a) => ops.transformText(m, l, a),
  set_text: (m, _l, a) => ops.setTexts(m, a.edits),
};

function runEditor(name, model, args) {
  const editor = EDITORS[name];
  if (!editor) throw new Error(`Unknown editing step "${name}". Valid: ${Object.keys(EDITORS).join(", ")}`);
  const layers = name === "set_text" ? [] : selectLayers(model, args.select);
  const result = editor(model, layers, args);
  return { ...result, matched: name === "set_text" ? (args.edits?.length ?? 0) : layers.length };
}

function commit(model, args, label, parts) {
  const changes = parts.flatMap((p) => p.changes);
  const skipped = parts.flatMap((p) => p.skipped);
  const touchedLayers = new Set(changes.map((c) => c.layer));
  const out = {
    ok: true,
    operation: label,
    dry_run: Boolean(args.dry_run),
    selection: parts.length === 1 ? describeSelect(args.select) : undefined,
    matched_layers: parts.length === 1 ? parts[0].matched : undefined,
    changed_layers: touchedLayers.size,
    changes: changes.slice(0, MAX_CHANGES_SHOWN),
    ...(changes.length > MAX_CHANGES_SHOWN ? { more_changes_not_shown: changes.length - MAX_CHANGES_SHOWN } : {}),
    ...(skipped.length ? { skipped: skipped.slice(0, MAX_SKIPPED_SHOWN), skipped_total: skipped.length } : {}),
    ...(parts.length === 1 && parts[0].extra ? parts[0].extra : {}),
  };
  if (args.dry_run) {
    out.note = "Dry run: nothing was written.";
    return out;
  }
  if (!changes.length) {
    out.note = "Nothing needed changing; the project was not modified.";
    return out;
  }
  finalizeEpochs(model);
  // Safety net: the edited scene must still decode cleanly before it is published.
  decodeScene(encodeScene(model.scene));
  const saved = saveProject(model.handle, label);
  out.saved = { revision: saved.revision, backup: saved.backup };
  out.note =
    "Saved as a new revision. Reopen the project in Koharu to see it. Use the `undo` tool to revert.";
  if (koharuMayBeRunning()) {
    out.warning =
      "Koharu appears to be running. If this project is open in the app, close it before reopening: " +
      "the app does not reload changes made on disk and its next autosave would overwrite them.";
  }
  return out;
}

function mutation(name) {
  return (args) => {
    const handle = openProject(args.project);
    const model = loadModel(handle);
    const part = runEditor(name, model, args);
    return commit(model, args, name, [part]);
  };
}

// ----------------------------------------------------------------- definitions

export const TOOLS = [
  {
    name: "list_projects",
    description: "List Koharu projects (.khrproj folders) in the projects directory (default ~/Documents/Koharu, override with KOHARU_PROJECTS_DIR).",
    inputSchema: obj({ directory: { type: "string", description: `Directory to scan. Default ${defaultProjectsDir()}` } }),
    annotations: READ,
    run: (a) => listProjects(a.directory),
  },
  {
    name: "project_info",
    description: "Summarize a project: pages (number, label, size, text-layer counts), revision, and overall text statistics. Start here.",
    inputSchema: obj({ project: PROJECT }),
    annotations: READ,
    run: (a) => {
      const model = loadModel(openProject(a.project));
      return {
        project: model.handle.root,
        revision: Number(model.handle.head.revision),
        page_count: model.pages.length,
        coordinate_system: "Page pixels; origin top-left, x right, y down. Bounds are [left, top, right, bottom].",
        pages: model.pages.map((p) => {
          const own = model.layers.filter((l) => l.page === p);
          return {
            page: p.number,
            label: p.label,
            id: p.id,
            width: round(p.width, 1),
            height: round(p.height, 1),
            text_layers: own.length,
            translated: own.filter((l) => l.translation?.text).length,
            chapter_start: p.chapterStart || undefined,
          };
        }),
        stats: ops.statistics(model, model.layers),
      };
    },
  },
  {
    name: "list_text",
    description:
      "List text layers with their text, typography, frame bounds and visibility. Use `select` to filter. Returns ids you can pass to other tools.",
    inputSchema: obj({
      project: PROJECT,
      select: SELECT,
      detail: { type: "string", enum: ["brief", "full"], description: "full adds complete typography and frame polygon." },
      limit: { type: "integer", description: "Max layers returned (default 100)." },
      offset: { type: "integer" },
    }),
    annotations: READ,
    run: (a) => {
      const model = loadModel(openProject(a.project));
      const layers = selectLayers(model, a.select);
      const offset = a.offset ?? 0;
      const limit = a.limit ?? 100;
      return {
        total: layers.length,
        offset,
        returned: Math.min(limit, Math.max(0, layers.length - offset)),
        layers: layers.slice(offset, offset + limit).map((l) => summarize(l, a.detail ?? "brief")),
      };
    },
  },
  {
    name: "get_text_layer",
    description: "Full details of one text layer: complete typography, frame polygon, text, visibility, angle.",
    inputSchema: obj({ project: PROJECT, layer: { type: "string", description: "Layer id (or unique prefix)." } }, ["layer"]),
    annotations: READ,
    run: (a) => {
      const model = loadModel(openProject(a.project));
      const layers = selectLayers(model, { layers: [a.layer] });
      return summarize(layers[0], "full");
    },
  },
  {
    name: "text_stats",
    description:
      "Distribution of font sizes, fonts, colors, alignments and frame sources across the selected layers. Use it to decide what to normalize.",
    inputSchema: obj({ project: PROJECT, select: SELECT }),
    annotations: READ,
    run: (a) => {
      const model = loadModel(openProject(a.project));
      return ops.statistics(model, selectLayers(model, a.select));
    },
  },
  {
    name: "check_project",
    description:
      "Integrity check: verifies both state slots, checksums, that every known component decodes, and that the scene re-encodes byte-for-byte. Safe to run any time.",
    inputSchema: obj({ project: PROJECT }),
    annotations: READ,
    run: (a) => {
      const handle = openProject(a.project);
      const model = loadModel(handle);
      const identical = encodeScene(handle.scene).equals(handle.head.payload);
      const noRelation = model.layers.filter((l) => !l.contentId).length;
      return {
        ok: identical,
        revision: Number(handle.head.revision),
        active_slot: handle.slot,
        pages: model.pages.length,
        text_layers: model.layers.length,
        scene_roundtrip_identical: identical,
        layers_without_text_content: noRelation,
        layers_without_frame: model.layers.filter((l) => !l.frame).length,
        history_backups: listHistory(handle.root).length,
      };
    },
  },
  {
    name: "set_font_size",
    description: 'Set the font size of text layers (e.g. "make all text size 40"). Turns auto-fit off for the affected layers unless auto_fit is given.',
    inputSchema: WRITE({ size: { type: "number", description: "Font size in page pixels." }, auto_fit: { type: "boolean" } }, ["size"]),
    annotations: EDIT,
    run: mutation("set_font_size"),
  },
  {
    name: "set_typography",
    description:
      "Change any typography properties on the selected layers: font, weight, style, size, color, stroke/outline, alignment, writing mode, line spacing, auto-fit. Only the properties you pass change; pass null to clear one.",
    inputSchema: WRITE(TYPOGRAPHY_PROPS),
    annotations: EDIT,
    run: mutation("set_typography"),
  },
  {
    name: "scale_font_size",
    description: "Multiply and/or offset existing explicit font sizes (e.g. factor 1.2 for +20%, delta -2). Optionally clamp with min/max.",
    inputSchema: WRITE({
      factor: { type: "number" },
      delta: { type: "number" },
      min: { type: "number" },
      max: { type: "number" },
      round_to: { type: "integer", description: "Decimal places to round to (default 2)." },
    }),
    annotations: EDIT,
    run: mutation("scale_font_size"),
  },
  {
    name: "copy_typography",
    description: "Copy typography from one layer onto the selected layers (all properties, or only `fields`).",
    inputSchema: WRITE(
      { from_layer: { type: "string" }, fields: { type: "array", items: { type: "string", enum: TYPO_ARG_KEYS } } },
      ["from_layer"],
    ),
    annotations: EDIT,
    run: mutation("copy_typography"),
  },
  {
    name: "reset_typography",
    description: "Remove typography overrides so the selected layers use Koharu's defaults again.",
    inputSchema: WRITE({}),
    annotations: { ...EDIT, destructiveHint: true },
    run: mutation("reset_typography"),
  },
  {
    name: "move_text",
    description:
      "Shift text frames by dx/dy. Positive dx moves right, positive dy moves down. Units are page pixels, or percent of page width/height. Frames are kept inside the page by default.",
    inputSchema: WRITE({
      dx: { type: "number" },
      dy: { type: "number" },
      unit: { type: "string", enum: ["px", "percent"] },
      keep_inside_page: { type: "boolean", description: "Default true." },
    }),
    annotations: EDIT,
    run: mutation("move_text"),
  },
  {
    name: "set_frame",
    description:
      "Set an exact frame position/size, or rescale it. Omitted values are kept. `anchor` is the point of the box that x/y refer to and that stays fixed while resizing.",
    inputSchema: WRITE({
      x: { type: "number" },
      y: { type: "number" },
      width: { type: "number" },
      height: { type: "number" },
      scale: { type: "number", description: "Uniform scale of the current frame." },
      scale_x: { type: "number" },
      scale_y: { type: "number" },
      anchor: {
        type: "string",
        enum: ["top-left", "top", "top-right", "left", "center", "right", "bottom-left", "bottom", "bottom-right"],
      },
      keep_inside_page: { type: "boolean" },
    }),
    annotations: EDIT,
    run: mutation("set_frame"),
  },
  {
    name: "align_text_to_page",
    description: "Align text frames to page edges/center with an optional margin.",
    inputSchema: WRITE({
      horizontal: { type: "string", enum: ["left", "center", "right"] },
      vertical: { type: "string", enum: ["top", "middle", "bottom"] },
      margin: { type: "number" },
    }),
    annotations: EDIT,
    run: mutation("align_text_to_page"),
  },
  {
    name: "fit_text_in_page",
    description:
      "Auto-offset text so ALL of it is visible on the page (e.g. a box 1/4 off the left edge is shifted right by that amount). Handles both axes. It checks the frame AND the text as Koharu will really render it: auto-fit text at the size the renderer will pick (it never goes below 9px, so a long translation in a small box still spills out), fixed-size text, rotated frames, point text (anchored to its corner) and the outline. Koharu centres text that is too big for its frame, so it spills equally above and below - that is how the top line gets cut off. Measurements use the layer's real font file when it can be found (see NEKOHARU_FONT_DIRS), otherwise a slightly generous estimate (reported in `text_check`). Each move is verified (`text.visible_after`). Things already fully inside are not touched. Omit `select` to check every text layer. Use find_offscreen_text first for a read-only report.",
    inputSchema: WRITE({
      margin: { type: "number", description: "Minimum gap to the page edges, in page pixels. Default 0." },
      check_text_overflow: {
        type: "boolean",
        description: "Also account for where the rendered text lands, including spill-over beyond the frame (auto-fit and fixed-size text). Default true. False = frames only.",
      },
      include_frame: {
        type: "boolean",
        description: "Also keep the whole frame on the page (default true). False = only the visible text has to be on the page, the frame may hang over an edge.",
      },
    }),
    annotations: EDIT,
    run: mutation("fit_text_in_page"),
  },
  {
    name: "find_offscreen_text",
    description:
      "Read-only. Lists text layers whose frame or rendered text reaches outside the page, with how many pixels stick out past each edge (`beyond_page_px`, and `text_beyond_page_px` for the text alone), the font size and line count Koharu will use, the measured text bounds and how reliable the measurement is. Run it before fit_text_in_page, and again afterwards to confirm nothing is left.",
    inputSchema: obj({
      project: PROJECT,
      select: SELECT,
      margin: { type: "number", description: "Gap to keep from the page edges, in page pixels. Default 0." },
      check_text_overflow: { type: "boolean", description: "Measure the rendered text, not just the frame. Default true." },
      include_frame: { type: "boolean", description: "Count the frame too, not just the text. Default true." },
      limit: { type: "integer", description: "Max layers returned (default 100)." },
    }),
    annotations: READ,
    run: (a) => {
      const model = loadModel(openProject(a.project));
      return ops.findOffscreenText(model, selectLayers(model, a.select), a);
    },
  },
  {
    name: "find_text_overlaps",
    description:
      "Read-only. Finds text boxes that overlap or sit closer than `margin` and returns each colliding pair WITH THE TEXT of both layers (translation and source), reading order, bounds, the overlap size, and what it would cost to push either one (`if_push_first` / `if_push_second`). `first` is the earlier layer in reading order. Read the texts, decide which layer should give way, then call resolve_text_overlaps with your decisions. Layers outside `select` are still compared if they collide with a selected one.",
    inputSchema: obj({
      project: PROJECT,
      select: SELECT,
      margin: { type: "number", description: "Minimum clear gap between text boxes, in page pixels. Boxes closer than this count as colliding. Default 0 (only real overlaps)." },
      check_text_overflow: { type: "boolean", description: "Use the estimated rendered text size for fixed-size text that spills out of its frame. Default true." },
      include_hidden: { type: "boolean", description: "Also consider hidden layers. Default false." },
      limit: { type: "integer", description: "Max pairs returned (default 50)." },
    }),
    annotations: READ,
    run: (a) => {
      const model = loadModel(openProject(a.project));
      return ops.findOverlaps(model, selectLayers(model, a.select), a);
    },
  },
  {
    name: "resolve_text_overlaps",
    description:
      "Push overlapping / too-close text boxes apart, horizontally or vertically, by the smallest move that clears them (plus `margin`). " +
      "AGENT-DIRECTED: call find_text_overlaps first, read what each pair says, then pass `resolutions` to decide per pair which layer moves, e.g. " +
      '[{ "layers": [textA, textB], "push": textB }] pushes B away from A; push A instead to keep B in place; "both" splits the push; add `axis` or `direction` to force how. ' +
      "AUTOMATIC: pairs you do not decide are resolved in reading order (the later layer moves) unless `resolve_remaining` is false; `priority` lists layer ids that should stay put first. " +
      "Moves avoid leaving the page and avoid creating new collisions where possible. Layers outside `select` never move but still count as obstacles. Anything that cannot be separated is reported in `unresolved`.",
    inputSchema: WRITE({
      resolutions: {
        type: "array",
        description: "Explicit per-pair decisions, applied first and in order.",
        items: obj(
          {
            layers: { type: "array", items: { type: "string" }, minItems: 2, maxItems: 2, description: "The two colliding layer ids (from find_text_overlaps)." },
            push: {
              type: "string",
              description: 'Which layer moves: one of the two ids, "first" / "second" (reading order), or "both" (each moves half the distance in opposite directions).',
            },
            axis: { type: "string", enum: ["auto", "horizontal", "vertical"], description: "Restrict the push to one axis. Default: this call's axis." },
            direction: { type: "string", enum: DIRECTIONS_ENUM, description: "Force the direction the pushed layer moves. Ignored for push \"both\"." },
          },
          ["layers", "push"],
        ),
      },
      priority: {
        type: "array",
        items: { type: "string" },
        description: "Layer ids that should stay put, highest priority first. Used by the automatic pass; unlisted layers follow reading order.",
      },
      resolve_remaining: { type: "boolean", description: "Automatically resolve overlaps not covered by `resolutions`. Default true." },
      axis: { type: "string", enum: ["auto", "horizontal", "vertical"], description: 'Allowed push axis. "auto" (default) picks the shortest move that stays on the page.' },
      margin: { type: "number", description: "Clear gap to leave between text boxes, in page pixels. Default 0." },
      keep_inside_page: { type: "boolean", description: "Never push text off the page. Default true." },
      check_text_overflow: { type: "boolean", description: "Account for estimated text spill-over of fixed-size text. Default true." },
      include_hidden: { type: "boolean", description: "Also consider hidden layers. Default false." },
    }),
    annotations: EDIT,
    run: mutation("resolve_text_overlaps"),
  },
  {
    name: "reset_frame",
    description: "Remove manual frames so layers follow their detected text/bubble region again.",
    inputSchema: WRITE({}),
    annotations: { ...EDIT, destructiveHint: true },
    run: mutation("reset_frame"),
  },
  {
    name: "set_text_angle",
    description: "Rotate text layout (degrees, clockwise-positive as in Koharu). relative=true adds to the current angle.",
    inputSchema: WRITE({ degrees: { type: "number" }, relative: { type: "boolean" } }, ["degrees"]),
    annotations: EDIT,
    run: mutation("set_text_angle"),
  },
  {
    name: "set_visibility",
    description: "Show/hide text layers and/or set their opacity (0-1).",
    inputSchema: WRITE({ visible: { type: "boolean" }, opacity: { type: "number" } }),
    annotations: EDIT,
    run: mutation("set_visibility"),
  },
  {
    name: "set_text",
    description:
      "Edit text of specific layers. Each edit: { layer, translation?, source? }. translation: null removes the translation. Use replace_text for pattern-based edits.",
    inputSchema: obj(
      {
        project: PROJECT,
        dry_run: DRY_RUN,
        edits: {
          type: "array",
          items: obj(
            { layer: { type: "string" }, translation: { type: ["string", "null"] }, source: { type: "string" } },
            ["layer"],
          ),
        },
      },
      ["edits"],
    ),
    annotations: EDIT,
    run: mutation("set_text"),
  },
  {
    name: "replace_text",
    description: "Find and replace in the translation (default), source text, or both, across the selected layers. Supports regex and whole-word matching.",
    inputSchema: WRITE(
      {
        find: { type: "string" },
        replace: { type: "string" },
        field: { type: "string", enum: ["translation", "source", "both"] },
        regex: { type: "boolean" },
        case_sensitive: { type: "boolean" },
        whole_word: { type: "boolean" },
      },
      ["find", "replace"],
    ),
    annotations: EDIT,
    run: mutation("replace_text"),
  },
  {
    name: "transform_text",
    description: "Bulk-reformat text: uppercase, lowercase, title_case, sentence_case, trim, collapse_whitespace, join_lines.",
    inputSchema: WRITE(
      { mode: { type: "string", enum: ops.TEXT_TRANSFORMS }, field: { type: "string", enum: ["translation", "source"] } },
      ["mode"],
    ),
    annotations: EDIT,
    run: mutation("transform_text"),
  },
  {
    name: "batch",
    description:
      'Run several editing steps as ONE atomic revision (one backup, one undo). steps: [{ "tool": "set_font_size", "args": { "size": 32, "select": {...} } }, ...]. Later steps see earlier steps\' results.',
    inputSchema: obj(
      {
        project: PROJECT,
        dry_run: DRY_RUN,
        steps: {
          type: "array",
          items: obj({ tool: { type: "string", enum: Object.keys(EDITORS) }, args: { type: "object" } }, ["tool"]),
        },
      },
      ["steps"],
    ),
    annotations: EDIT,
    run: (a) => {
      if (!Array.isArray(a.steps) || !a.steps.length) throw new Error("`steps` must be a non-empty array");
      const handle = openProject(a.project);
      const model = loadModel(handle);
      const parts = a.steps.map((step, i) => {
        try {
          return runEditor(step.tool, model, step.args ?? {});
        } catch (error) {
          throw new Error(`Step ${i + 1} (${step.tool}) failed: ${error.message}. Nothing was saved.`);
        }
      });
      const result = commit(model, a, "batch", parts);
      result.steps = parts.map((p, i) => ({
        step: i + 1,
        tool: a.steps[i].tool,
        matched_layers: p.matched,
        changed: new Set(p.changes.map((c) => c.layer)).size,
        skipped: p.skipped.length,
        ...(p.extra ? { details: p.extra } : {}),
      }));
      return result;
    },
  },
  {
    name: "list_history",
    description: "List automatic backups (one per change) that `undo` can restore, newest first.",
    inputSchema: obj({ project: PROJECT }),
    annotations: READ,
    run: (a) => ({ backups: listHistory(openProject(a.project).root) }),
  },
  {
    name: "undo",
    description: "Revert the most recent change made by this tool (or restore a specific backup from list_history). Creates a new revision.",
    inputSchema: obj({ project: PROJECT, backup: { type: "string", description: "Backup name from list_history. Default: newest." } }),
    annotations: { ...EDIT, destructiveHint: true },
    run: (a) => {
      const result = undoLast(a.project, a.backup);
      return { ok: true, ...result, note: "Reopen the project in Koharu to see the restored state." };
    },
  },
];

const BY_NAME = new Map(TOOLS.map((t) => [t.name, t]));

export function getTool(name) {
  return BY_NAME.get(name.replace(/-/g, "_"));
}

/** Executes a tool, returning `{ ok, result | error }` and never throwing. */
export function callTool(name, args = {}) {
  const tool = getTool(name);
  if (!tool) return { ok: false, error: `Unknown tool "${name}". Available: ${TOOLS.map((t) => t.name).join(", ")}` };
  try {
    return { ok: true, result: tool.run(args ?? {}) };
  } catch (error) {
    const message = error instanceof ProjectError || error instanceof Error ? error.message : String(error);
    return { ok: false, error: message };
  }
}
