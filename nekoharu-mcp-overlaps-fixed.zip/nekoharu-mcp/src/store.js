// Opening and saving `.khrproj` directories the same way koharu-storage does:
// two alternating complete state slots, newest valid slot wins, atomic publish.

import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { decodeStateFile, encodeStateFile, decodeScene, encodeScene } from "./codec.js";

const SLOTS = ["state-a.khr", "state-b.khr"];
const HISTORY_DIR = ".nekoharu-history";
const MAX_HISTORY = 50;

export class ProjectError extends Error {}

export function defaultProjectsDir() {
  return process.env.KOHARU_PROJECTS_DIR || path.join(os.homedir(), "Documents", "Koharu");
}

/** Resolves a user-supplied project reference to an absolute `.khrproj` directory. */
export function resolveProjectPath(input) {
  const ref = input || process.env.KOHARU_PROJECT;
  if (!ref) {
    throw new ProjectError(
      "No project given. Pass `project` (path to a .khrproj folder, or a project name from list_projects) " +
        "or set the KOHARU_PROJECT environment variable.",
    );
  }
  const candidates = [path.resolve(ref)];
  const dir = defaultProjectsDir();
  candidates.push(path.join(dir, ref), path.join(dir, `${ref}.khrproj`));
  for (const candidate of candidates) {
    if (isProjectDir(candidate)) return candidate;
  }
  throw new ProjectError(
    `Not a Koharu project: ${ref}. Expected a .khrproj folder containing state-a.khr / state-b.khr.`,
  );
}

function isProjectDir(dir) {
  try {
    return fs.statSync(dir).isDirectory() && SLOTS.some((s) => fs.existsSync(path.join(dir, s)));
  } catch {
    return false;
  }
}

export function listProjects(dir = defaultProjectsDir()) {
  let entries = [];
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return { directory: dir, projects: [] };
  }
  const projects = entries
    .filter((e) => e.isDirectory() && isProjectDir(path.join(dir, e.name)))
    .map((e) => {
      const full = path.join(dir, e.name);
      const mtime = Math.max(
        ...SLOTS.filter((s) => fs.existsSync(path.join(full, s))).map(
          (s) => fs.statSync(path.join(full, s)).mtimeMs,
        ),
      );
      return {
        name: e.name.replace(/\.khrproj$/, ""),
        path: full,
        modified: new Date(mtime).toISOString(),
      };
    })
    .sort((a, b) => b.modified.localeCompare(a.modified));
  return { directory: dir, projects };
}

function blobExists(root, hex) {
  return fs.existsSync(path.join(root, "blobs", hex.slice(0, 2), hex));
}

/** Loads the newest valid state, mirroring koharu-storage's recovery rules. */
export function openProject(input) {
  const root = resolveProjectPath(input);
  const candidates = [];
  let firstError = null;
  for (const name of SLOTS) {
    const file = path.join(root, name);
    if (!fs.existsSync(file)) continue;
    try {
      candidates.push({ name, state: decodeStateFile(fs.readFileSync(file)) });
    } catch (error) {
      firstError ??= error;
    }
  }
  candidates.sort((a, b) => (a.state.revision < b.state.revision ? 1 : -1));
  const chosen = candidates.find((c) => c.state.blobs.every((b) => blobExists(root, b)));
  if (!chosen) {
    throw new ProjectError(
      `Could not load a valid state from ${root}${firstError ? `: ${firstError.message}` : ""}`,
    );
  }
  return {
    root,
    slot: chosen.name,
    head: chosen.state,
    scene: decodeScene(chosen.state.payload),
  };
}

function publish(target, bytes) {
  const dir = path.dirname(target);
  const tmp = path.join(dir, `.nekoharu-${process.pid}-${Date.now()}.tmp`);
  const fd = fs.openSync(tmp, "w", 0o600);
  try {
    fs.writeSync(fd, bytes);
    fs.fsyncSync(fd);
  } finally {
    fs.closeSync(fd);
  }
  try {
    // Slots alternate, so replacing the inactive one never endangers the live state.
    if (fs.existsSync(target)) fs.rmSync(target);
    fs.renameSync(tmp, target);
  } catch (error) {
    fs.rmSync(tmp, { force: true });
    throw error;
  }
}

function backupHead(handle, label) {
  const dir = path.join(handle.root, HISTORY_DIR);
  fs.mkdirSync(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const safe = label.replace(/[^a-z0-9_-]+/gi, "-").slice(0, 40);
  const name = `${stamp}_r${handle.head.revision}_${safe}.khr`;
  fs.copyFileSync(path.join(handle.root, handle.slot), path.join(dir, name));
  const all = fs.readdirSync(dir).filter((f) => f.endsWith(".khr")).sort();
  for (const old of all.slice(0, Math.max(0, all.length - MAX_HISTORY))) {
    fs.rmSync(path.join(dir, old), { force: true });
  }
  return name;
}

/** Publishes `handle.scene` as the next revision. Returns the new revision and backup name. */
export function saveProject(handle, label = "edit") {
  const backup = backupHead(handle, label);
  const revision = handle.head.revision + 1n;
  const bytes = encodeStateFile({
    document: handle.head.document,
    revision,
    blobs: handle.head.blobs,
    payload: encodeScene(handle.scene),
  });
  const otherSlot = SLOTS.find((s) => s !== handle.slot);
  publish(path.join(handle.root, otherSlot), bytes);
  return { revision: Number(revision), backup };
}

export function listHistory(input) {
  const root = resolveProjectPath(input);
  const dir = path.join(root, HISTORY_DIR);
  if (!fs.existsSync(dir)) return [];
  return fs
    .readdirSync(dir)
    .filter((f) => f.endsWith(".khr"))
    .sort()
    .reverse()
    .map((f) => {
      const m = /^(.+)_r(\d+)_(.*)\.khr$/.exec(f);
      return { name: f, saved_at: m ? m[1] : null, from_revision: m ? Number(m[2]) : null, label: m?.[3] ?? f };
    });
}

/** Restores the state saved before the most recent change as a new revision. */
export function undoLast(input, name) {
  const handle = openProject(input);
  const history = listHistory(handle.root);
  const target = name ? history.find((h) => h.name === name) : history[0];
  if (!target) throw new ProjectError("Nothing to undo: no backups found for this project.");
  const file = path.join(handle.root, HISTORY_DIR, target.name);
  const restored = decodeStateFile(fs.readFileSync(file));
  if (restored.document !== handle.head.document) {
    throw new ProjectError("Backup belongs to a different project.");
  }
  const revision = handle.head.revision + 1n;
  const bytes = encodeStateFile({ ...restored, revision });
  const otherSlot = SLOTS.find((s) => s !== handle.slot);
  publish(path.join(handle.root, otherSlot), bytes);
  fs.rmSync(file, { force: true });
  return { restored: target.name, revision: Number(revision) };
}

/** Best-effort check for a running Koharu desktop app (it locks open projects). */
export function koharuMayBeRunning() {
  try {
    if (process.platform === "win32") {
      const out = execFileSync("tasklist", ["/FO", "CSV", "/NH"], { encoding: "utf8", timeout: 4000 });
      return /"(ne)?koharu[^"]*\.exe"/i.test(out);
    }
    const out = execFileSync("ps", ["-A", "-o", "comm="], { encoding: "utf8", timeout: 4000 });
    return out.split("\n").some((l) => /(^|\/)(ne)?koharu(-app)?$/i.test(l.trim()));
  } catch {
    return false;
  }
}
