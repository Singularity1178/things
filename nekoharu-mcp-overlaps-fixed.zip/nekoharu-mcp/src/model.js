// A navigable view over the raw scene: pages, text layers, their text content,
// effective frames, plus the selector engine shared by every bulk operation.
//
// Koharu text anatomy (see koharu-scene README):
//   page ── text group ── text layer (TextLayout + Typography [+ Geometry] [+ Visibility])
//                              └─ presents ─▶ text content entity (SourceText + Translation)
//   A layer without its own Geometry takes its frame from a fits-to / flows-in region.

import { KIND, USER, decodeComponent, encodeComponent, hasCodec } from "./codec.js";

export const round = (n, digits = 3) =>
  n === null || n === undefined ? n : Math.round(n * 10 ** digits) / 10 ** digits;

export const comp = (entity, kind) => entity.components.find((c) => c.key === kind);

export function setComp(entity, entry) {
  const i = entity.components.findIndex((c) => c.key === entry.key);
  if (i >= 0) entity.components[i] = entry;
  else {
    entity.components.push(entry);
    // Entities keep components sorted by key (bytewise), as koharu-scene does.
    entity.components.sort((a, b) => Buffer.compare(Buffer.from(a.key), Buffer.from(b.key)));
  }
}

export function removeComp(entity, kind) {
  const i = entity.components.findIndex((c) => c.key === kind);
  if (i < 0) return false;
  entity.components.splice(i, 1);
  return true;
}

export function boundsOf(points) {
  const xs = points.map((p) => p.x);
  const ys = points.map((p) => p.y);
  return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
}

export const hex = (rgba) =>
  rgba
    ? `#${rgba
        .slice(0, rgba[3] === 255 ? 3 : 4)
        .map((v) => v.toString(16).padStart(2, "0"))
        .join("")}`
    : null;

export function loadModel(handle) {
  const { scene } = handle;
  const entities = new Map(); // id -> { entity, pageIndex }
  const relations = new Map(); // `${kind}|${source}` -> relation
  const pages = [];

  scene.pages.forEach((pageRef, index) => {
    const root = pageRef.entities[0];
    const children = new Map();
    for (const e of pageRef.entities) {
      entities.set(e.id, { entity: e, pageIndex: index });
      if (e.parent) {
        if (!children.has(e.parent)) children.set(e.parent, []);
        children.get(e.parent).push(e.id);
      }
    }
    const pageComp = comp(root, KIND.PAGE);
    const meta = pageComp ? decodeComponent(pageComp) : { label: "", width: 0, height: 0 };
    const groupId = (children.get(root.id) ?? []).find((id) =>
      comp(entities.get(id).entity, KIND.TEXT_GROUP),
    );
    pages.push({
      index,
      number: index + 1,
      id: pageRef.id,
      label: meta.label,
      width: meta.width,
      height: meta.height,
      chapterStart: meta.chapter_start,
      ref: pageRef,
      layerIds: groupId ? (children.get(groupId) ?? []) : [],
    });
  });
  for (const rel of scene.relations) relations.set(`${rel.kind}|${rel.source}`, rel);

  const model = { handle, scene, entities, relations, pages, touchedPages: new Set(), layers: [] };
  for (const page of pages) {
    page.layerIds.forEach((id, order) => {
      if (comp(entities.get(id).entity, KIND.TEXT_LAYOUT)) {
        model.layers.push(describeLayer(model, page, id, order));
      }
    });
  }
  return model;
}

const relationTarget = (model, kind, source) => model.relations.get(`${kind}|${source}`)?.target ?? null;

function safeDecode(entity, kind) {
  const entry = comp(entity, kind);
  return entry && hasCodec(kind) ? decodeComponent(entry) : null;
}

function describeLayer(model, page, id, order) {
  const entity = model.entities.get(id).entity;
  const layout = safeDecode(entity, KIND.TEXT_LAYOUT);
  const typography = safeDecode(entity, KIND.TYPOGRAPHY);
  const visibility = safeDecode(entity, KIND.VISIBILITY);
  const ownGeometry = safeDecode(entity, KIND.GEOMETRY);

  const contentId = relationTarget(model, KIND.REL_PRESENTS, id);
  const contentEntity = contentId ? (model.entities.get(contentId)?.entity ?? null) : null;
  const source = contentEntity ? safeDecode(contentEntity, KIND.TEXT_SOURCE) : null;
  const translation = contentEntity ? safeDecode(contentEntity, KIND.TEXT_TRANSLATION) : null;

  let frame = null;
  let frameFrom = "none";
  let frameEntityId = null;
  // Koharu lays text out as balloon text whenever the layer flows in a balloon, even with its own frame.
  const flowTarget = relationTarget(model, KIND.REL_FLOWS_IN, id);
  const flowsIn = Boolean(flowTarget && model.entities.has(flowTarget));
  if (ownGeometry) {
    frame = ownGeometry.points;
    frameFrom = "own";
  } else {
    for (const [rel, label] of [
      [KIND.REL_FITS_TO, "fits-to"],
      [KIND.REL_FLOWS_IN, "flows-in"],
    ]) {
      const target = relationTarget(model, rel, id);
      const geometry = target && safeDecode(model.entities.get(target).entity, KIND.GEOMETRY);
      if (geometry) {
        frame = geometry.points;
        frameFrom = label;
        frameEntityId = target;
        break;
      }
    }
  }

  return {
    id,
    page,
    order: order + 1,
    entity,
    contentId,
    contentEntity,
    layout,
    typography,
    visibility,
    ownGeometry,
    source,
    translation,
    frame,
    frameFrom,
    frameEntityId,
    flowsIn,
  };
}

/** JSON-friendly summary of a layer for tool output. */
export function summarize(layer, detail = "brief") {
  const t = layer.typography;
  const text = layer.translation?.text ?? layer.source?.text ?? "";
  const out = {
    id: layer.id,
    page: layer.page.number,
    page_label: layer.page.label,
    order: layer.order,
    translation: layer.translation?.text ?? null,
    source: layer.source?.text ?? null,
    font: t?.preferred_font ?? null,
    size: round(t?.size ?? null),
    auto_fit: t ? t.auto_fit : null,
    color: hex(t?.color ?? null),
    alignment: t?.alignment ?? null,
    writing_mode: t?.writing_mode ?? null,
    bounds: layer.frame ? boundsOf(layer.frame).map((v) => round(v, 1)) : null,
    frame_from: layer.frameFrom,
    visible: layer.visibility ? layer.visibility.visible : true,
    opacity: round(layer.visibility ? layer.visibility.opacity : 1, 3),
    angle: round(layer.layout?.angle_degrees ?? 0, 2),
  };
  if (detail === "brief") {
    out.translation = clip(out.translation, 120);
    out.source = clip(out.source, 120);
    return out;
  }
  out.layout_kind = layer.layout?.kind ?? null;
  out.typography = t
    ? {
        ...t,
        size: round(t.size),
        stroke_width: round(t.stroke_width),
        outer_stroke_width: round(t.outer_stroke_width),
        line_spacing: round(t.line_spacing),
        color: hex(t.color),
        stroke_color: hex(t.stroke_color),
        outer_stroke_color: hex(t.outer_stroke_color),
      }
    : null;
  out.frame_points = layer.frame?.map((p) => ({ x: round(p.x, 2), y: round(p.y, 2) })) ?? null;
  out.text_preview = clip(text, 400);
  out.content_id = layer.contentId;
  return out;
}

const clip = (s, n) => (s && s.length > n ? `${s.slice(0, n - 1)}…` : s);

// ------------------------------------------------------------------- selection

/** "1-3,7" | 4 | [1,"5-6","Cover"] -> predicate over a page. */
function pageMatcher(model, spec) {
  if (spec === undefined || spec === null || spec === "all") return () => true;
  const tokens = (Array.isArray(spec) ? spec : String(spec).split(",")).map((t) =>
    typeof t === "number" ? String(t) : String(t).trim(),
  );
  const numbers = new Set();
  const others = [];
  for (const token of tokens) {
    const range = /^(\d+)(?:\s*-\s*(\d+))?$/.exec(token);
    if (range) {
      const from = Number(range[1]);
      const to = Number(range[2] ?? range[1]);
      for (let n = from; n <= to; n++) numbers.add(n);
    } else if (/^(first|last)$/i.test(token)) {
      numbers.add(token.toLowerCase() === "first" ? 1 : model.pages.length);
    } else if (token) others.push(token);
  }
  const unknown = others.filter(
    (t) => !model.pages.some((p) => p.id === t || p.label === t || p.id.startsWith(t)),
  );
  if (unknown.length) {
    throw new Error(`Unknown page reference(s): ${unknown.join(", ")}. Use 1-based page numbers, ranges like "2-5", labels or ids.`);
  }
  for (const n of numbers) {
    if (n < 1 || n > model.pages.length) {
      throw new Error(`Page ${n} is out of range (project has ${model.pages.length} pages).`);
    }
  }
  return (page) =>
    numbers.has(page.number) ||
    others.some((t) => page.id === t || page.label === t || page.id.startsWith(t));
}

function layerMatcher(model, ids) {
  if (!ids) return () => true;
  const list = [...new Set(ids)];
  const resolved = new Set();
  for (const ref of list) {
    const exact = model.layers.filter((l) => l.id === ref);
    const matches = exact.length ? exact : ref.length >= 6 ? model.layers.filter((l) => l.id.startsWith(ref)) : [];
    if (matches.length !== 1) {
      throw new Error(
        matches.length === 0
          ? `No text layer with id "${ref}". Use list_text to find ids.`
          : `Layer id prefix "${ref}" is ambiguous.`,
      );
    }
    resolved.add(matches[0].id);
  }
  return (layer) => resolved.has(layer.id);
}

const ci = (s) => (s ?? "").toLowerCase();

/** Returns the text layers matching a selector (default: every text layer). */
export function selectLayers(model, select = {}) {
  const s = select ?? {};
  const pageOk = pageMatcher(model, s.pages);
  const orderOk = s.order === undefined ? () => true : orderMatcher(s.order);
  const idOk = layerMatcher(model, s.layers);
  let regex = null;
  if (s.text_regex) {
    try {
      regex = new RegExp(s.text_regex, s.case_sensitive ? "" : "i");
    } catch (error) {
      throw new Error(`Invalid text_regex: ${error.message}`);
    }
  }
  const field = s.text_field ?? "any";
  const textOf = (l) =>
    field === "translation"
      ? [l.translation?.text ?? ""]
      : field === "source"
        ? [l.source?.text ?? ""]
        : [l.translation?.text ?? "", l.source?.text ?? ""];

  return model.layers.filter((l) => {
    if (!pageOk(l.page) || !orderOk(l.order) || !idOk(l)) return false;
    const t = l.typography;
    if (s.text_contains !== undefined) {
      const needle = s.case_sensitive ? s.text_contains : ci(s.text_contains);
      if (!textOf(l).some((x) => (s.case_sensitive ? x : ci(x)).includes(needle))) return false;
    }
    if (regex && !textOf(l).some((x) => regex.test(x))) return false;
    if (s.has_translation !== undefined && Boolean(l.translation?.text) !== s.has_translation) return false;
    if (s.font !== undefined) {
      const want = s.font === null || ci(String(s.font)) === "none" ? null : ci(String(s.font));
      if ((t?.preferred_font ? ci(t.preferred_font) : null) !== want) return false;
    }
    const size = t?.size ?? null;
    if (s.size !== undefined && (size === null || Math.abs(size - s.size) > 0.01)) return false;
    if (s.size_min !== undefined && (size === null || size < s.size_min)) return false;
    if (s.size_max !== undefined && (size === null || size > s.size_max)) return false;
    if (s.auto_fit !== undefined && (t ? t.auto_fit : true) !== s.auto_fit) return false;
    if (s.writing_mode !== undefined && (t?.writing_mode ?? "horizontal") !== s.writing_mode) return false;
    if (s.alignment !== undefined && (t?.alignment ?? null) !== s.alignment) return false;
    if (s.layout_kind !== undefined && l.layout?.kind !== s.layout_kind) return false;
    if (s.visible !== undefined && (l.visibility ? l.visibility.visible : true) !== s.visible) return false;
    if (s.translation_origin !== undefined) {
      const origin = l.translation?.origin?.kind;
      if (origin !== s.translation_origin) return false;
    }
    if (s.bounds_within !== undefined) {
      if (!l.frame) return false;
      const [x0, y0, x1, y1] = s.bounds_within;
      const [l0, t0, r0, b0] = boundsOf(l.frame);
      const cx = (l0 + r0) / 2;
      const cy = (t0 + b0) / 2;
      if (cx < x0 || cx > x1 || cy < y0 || cy > y1) return false;
    }
    return true;
  });
}

function orderMatcher(spec) {
  const numbers = new Set();
  for (const token of (Array.isArray(spec) ? spec : String(spec).split(",")).map(String)) {
    const m = /^\s*(\d+)(?:\s*-\s*(\d+))?\s*$/.exec(token);
    if (!m) throw new Error(`Invalid order selector "${token}" (use e.g. "1-3,5").`);
    for (let n = Number(m[1]); n <= Number(m[2] ?? m[1]); n++) numbers.add(n);
  }
  return (order) => numbers.has(order);
}

/** Describes a selector in words for tool output. */
export function describeSelect(select) {
  const keys = Object.keys(select ?? {}).filter((k) => select[k] !== undefined);
  return keys.length ? select : "all text layers";
}

// -------------------------------------------------------------------- mutation

/** Marks a layer (and its text content) as user-authored, like Koharu's own edits. */
export function promote(model, layer) {
  for (const entity of [layer.entity, layer.contentEntity]) {
    if (!entity) continue;
    setComp(entity, encodeComponent(KIND.ENTITY_ORIGIN, { origin: USER }, comp(entity, KIND.ENTITY_ORIGIN)));
  }
  touch(model, layer.page);
}

export function touch(model, page) {
  model.touchedPages.add(page.index);
}

/** Bumps the mutation epoch of every page that changed. */
export function finalizeEpochs(model) {
  for (const index of model.touchedPages) model.scene.pages[index].epoch += 1n;
}
