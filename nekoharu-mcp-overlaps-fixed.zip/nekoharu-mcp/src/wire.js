// Wire primitives for the `revision` binary format used by Koharu's scene and
// storage crates (revision 0.30, variable-length integer encoding).
//
//   unsigned ints : < 251 -> 1 byte | 251 + u16 LE | 252 + u32 LE | 253 + u64 LE
//   bool          : 1 byte (0/1)
//   f32 / f64     : little-endian IEEE-754
//   String / Vec  : varint length, then payload / items
//   Option<T>     : 0, or 1 followed by T
//   struct / enum : u16 revision header, fields (enums: u32 discriminant, fields)
//   Uuid          : 16 raw bytes
//   [u8; N]       : N raw bytes

export class Reader {
  /** @param {Buffer} buf */
  constructor(buf) {
    this.buf = buf;
    this.pos = 0;
  }

  get remaining() {
    return this.buf.length - this.pos;
  }

  need(n) {
    if (n < 0 || this.pos + n > this.buf.length) {
      throw new Error(`unexpected end of data (wanted ${n} bytes at offset ${this.pos})`);
    }
  }

  u8() {
    this.need(1);
    return this.buf[this.pos++];
  }

  bytes(n) {
    this.need(n);
    const out = this.buf.subarray(this.pos, this.pos + n);
    this.pos += n;
    return Buffer.from(out);
  }

  /** Variable-length unsigned integer as BigInt. */
  varBig() {
    const tag = this.u8();
    if (tag < 251) return BigInt(tag);
    if (tag === 251) {
      this.need(2);
      const v = this.buf.readUInt16LE(this.pos);
      this.pos += 2;
      return BigInt(v);
    }
    if (tag === 252) {
      this.need(4);
      const v = this.buf.readUInt32LE(this.pos);
      this.pos += 4;
      return BigInt(v);
    }
    if (tag === 253) {
      this.need(8);
      const v = this.buf.readBigUInt64LE(this.pos);
      this.pos += 8;
      return v;
    }
    throw new Error(`unsupported integer tag ${tag}`);
  }

  /** Variable-length unsigned integer as a safe Number. */
  uint() {
    const v = this.varBig();
    if (v > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error("integer too large");
    return Number(v);
  }

  bool() {
    const v = this.u8();
    if (v > 1) throw new Error(`invalid bool ${v}`);
    return v === 1;
  }

  f32() {
    this.need(4);
    const v = this.buf.readFloatLE(this.pos);
    this.pos += 4;
    return v;
  }

  f64() {
    this.need(8);
    const v = this.buf.readDoubleLE(this.pos);
    this.pos += 8;
    return v;
  }

  string() {
    const len = this.uint();
    return this.bytes(len).toString("utf8");
  }

  byteVec() {
    const len = this.uint();
    return this.bytes(len);
  }

  option(read) {
    const tag = this.u8();
    if (tag === 0) return null;
    if (tag === 1) return read(this);
    throw new Error(`invalid option tag ${tag}`);
  }

  vec(read) {
    const len = this.uint();
    if (len > this.remaining) throw new Error("vector length exceeds remaining data");
    const out = [];
    for (let i = 0; i < len; i++) out.push(read(this));
    return out;
  }

  /** Reads a struct/enum revision header, rejecting versions this tool does not know. */
  revision(name, max) {
    const rev = this.uint();
    if (rev < 1 || rev > max) {
      throw new Error(
        `${name} uses revision ${rev}, but this tool only understands up to ${max}. ` +
          `Update nekoharu-mcp before editing this project.`,
      );
    }
    return rev;
  }

  uuid() {
    return bytesToUuid(this.bytes(16));
  }

  done(what) {
    if (this.remaining !== 0) throw new Error(`${what}: ${this.remaining} trailing bytes`);
  }
}

export class Writer {
  constructor() {
    this.parts = [];
  }

  raw(buf) {
    this.parts.push(Buffer.from(buf));
    return this;
  }

  u8(v) {
    this.parts.push(Buffer.from([v]));
    return this;
  }

  varint(value) {
    const v = typeof value === "bigint" ? value : BigInt(value);
    if (v < 0n) throw new Error("negative unsigned integer");
    if (v < 251n) return this.u8(Number(v));
    if (v < 65536n) {
      const b = Buffer.alloc(3);
      b[0] = 251;
      b.writeUInt16LE(Number(v), 1);
      return this.raw(b);
    }
    if (v < 4294967296n) {
      const b = Buffer.alloc(5);
      b[0] = 252;
      b.writeUInt32LE(Number(v), 1);
      return this.raw(b);
    }
    const b = Buffer.alloc(9);
    b[0] = 253;
    b.writeBigUInt64LE(v, 1);
    return this.raw(b);
  }

  bool(v) {
    return this.u8(v ? 1 : 0);
  }

  f32(v) {
    const b = Buffer.alloc(4);
    b.writeFloatLE(v, 0);
    return this.raw(b);
  }

  f64(v) {
    const b = Buffer.alloc(8);
    b.writeDoubleLE(v, 0);
    return this.raw(b);
  }

  string(s) {
    const b = Buffer.from(s, "utf8");
    this.varint(b.length);
    return this.raw(b);
  }

  byteVec(buf) {
    this.varint(buf.length);
    return this.raw(buf);
  }

  option(value, write) {
    if (value === null || value === undefined) return this.u8(0);
    this.u8(1);
    write(this, value);
    return this;
  }

  vec(items, write) {
    this.varint(items.length);
    for (const item of items) write(this, item);
    return this;
  }

  revision(rev) {
    return this.varint(rev);
  }

  uuid(s) {
    return this.raw(uuidToBytes(s));
  }

  finish() {
    return Buffer.concat(this.parts);
  }
}

export function bytesToUuid(b) {
  const h = Buffer.from(b).toString("hex");
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

export function uuidToBytes(s) {
  const hex = s.replace(/-/g, "");
  if (!/^[0-9a-fA-F]{32}$/.test(hex)) throw new Error(`invalid id: ${s}`);
  return Buffer.from(hex, "hex");
}
