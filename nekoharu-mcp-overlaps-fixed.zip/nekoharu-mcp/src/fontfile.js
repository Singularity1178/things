// Minimal, dependency-free TrueType / OpenType (sfnt, TTC) reader used to measure text the way
// Koharu's renderer does: real glyph advances and real glyph ink bounds (glyf table), instead of
// guessing. It never renders anything - only widths and bounding boxes.
//
// Fonts are looked up by name (family, full name or PostScript name, which is how a Koharu
// `preferred_font` is stored) in the usual system font folders, in Koharu's package cache (where
// its bundled fonts are downloaded) and in any folder listed in NEKOHARU_FONT_DIRS.
// Everything degrades gracefully: when a font cannot be found or parsed the caller falls back to
// the approximate metrics in textlayout.js.

import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const FONT_EXT = new Set([".ttf", ".otf", ".ttc", ".otc"]);
const MAX_FILES = 8000;
const MAX_DEPTH = 7;

const norm = (s) => String(s ?? "").toLowerCase().replace(/[^a-z0-9\u0080-\uffff]+/g, "");

// ------------------------------------------------------------------ directories

export function fontDirectories(env = process.env) {
  const home = os.homedir();
  const dirs = [];
  for (const extra of (env.NEKOHARU_FONT_DIRS ?? env.KOHARU_FONT_DIRS ?? "").split(path.delimiter)) {
    if (extra.trim()) dirs.push(extra.trim());
  }
  let cache;
  if (process.platform === "win32") {
    const local = env.LOCALAPPDATA ?? path.join(home, "AppData", "Local");
    dirs.push(path.join(env.WINDIR ?? "C:\\Windows", "Fonts"), path.join(local, "Microsoft", "Windows", "Fonts"));
    cache = local;
  } else if (process.platform === "darwin") {
    dirs.push("/System/Library/Fonts", "/System/Library/Fonts/Supplemental", "/Library/Fonts", path.join(home, "Library", "Fonts"));
    cache = path.join(home, "Library", "Caches");
  } else {
    dirs.push("/usr/share/fonts", "/usr/local/share/fonts", path.join(home, ".fonts"), path.join(home, ".local", "share", "fonts"));
    cache = env.XDG_CACHE_HOME ?? path.join(home, ".cache");
  }
  // Koharu keeps downloaded (bundled) fonts in its runtime package store: <cache dir>/koharu/packages.
  dirs.push(path.join(cache, "koharu", "packages"), path.join(cache, "Koharu", "packages"));
  return [...new Set(dirs)];
}

function walk(dir, depth, out) {
  if (depth > MAX_DEPTH || out.length >= MAX_FILES) return;
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const e of entries) {
    if (out.length >= MAX_FILES) return;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) walk(full, depth + 1, out);
    else if (e.isFile() && FONT_EXT.has(path.extname(e.name).toLowerCase())) out.push(full);
  }
}

// ----------------------------------------------------------------- sfnt parsing

function readAt(fd, position, length) {
  const buf = Buffer.alloc(length);
  const n = fs.readSync(fd, buf, 0, length, position);
  return n === length ? buf : buf.subarray(0, n);
}

/** Offsets of every face in a file (1 for .ttf/.otf, N for collections). */
function faceOffsets(head) {
  if (head.length < 12) return [];
  const tag = head.toString("latin1", 0, 4);
  if (tag === "ttcf") {
    const n = Math.min(head.readUInt32BE(8), 64);
    return Array.from({ length: n }, (_, i) => head.readUInt32BE(12 + i * 4));
  }
  if (["OTTO", "true", "typ1", "\u0000\u0001\u0000\u0000"].includes(tag)) return [0];
  return [];
}

function tableDirectory(buf, base) {
  const n = buf.readUInt16BE(base + 4);
  const tables = {};
  for (let i = 0; i < n; i++) {
    const p = base + 12 + i * 16;
    if (p + 16 > buf.length) break;
    tables[buf.toString("latin1", p, p + 4)] = { offset: buf.readUInt32BE(p + 8), length: buf.readUInt32BE(p + 12) };
  }
  return tables;
}

function decodeName(buf, platform, start, length) {
  if (platform === 3 || platform === 0) {
    const out = [];
    for (let i = 0; i + 1 < length; i += 2) out.push(buf.readUInt16BE(start + i));
    return String.fromCharCode(...out);
  }
  return buf.toString("latin1", start, start + length);
}

/** name IDs we care about (family, full, PostScript, typographic family) -> normalized strings. */
function readNames(buf) {
  const out = new Set();
  if (buf.length < 6) return out;
  const count = buf.readUInt16BE(2);
  const strings = buf.readUInt16BE(4);
  for (let i = 0; i < count; i++) {
    const p = 6 + i * 12;
    if (p + 12 > buf.length) break;
    const id = buf.readUInt16BE(p + 6);
    if (![1, 4, 6, 16].includes(id)) continue;
    const length = buf.readUInt16BE(p + 8);
    const start = strings + buf.readUInt16BE(p + 10);
    if (start + length > buf.length) continue;
    const value = norm(decodeName(buf, buf.readUInt16BE(p), start, length));
    if (value) out.add(value);
  }
  return out;
}

let INDEX = null;
const LOADED = new Map();
const LOOKUPS = new Map();

/** Lightweight scan: reads only each face's table directory, `name` and `OS/2` tables. */
export function fontIndex(dirs = fontDirectories()) {
  if (INDEX) return INDEX;
  const files = [];
  for (const dir of dirs) walk(dir, 0, files);
  const faces = [];
  for (const file of files) {
    let fd;
    try {
      fd = fs.openSync(file, "r");
      const head = readAt(fd, 0, 12 + 4 * 64);
      for (const [index, base] of faceOffsets(head).entries()) {
        const dirBuf = readAt(fd, base, 12 + 16 * 64);
        if (dirBuf.length < 12) continue;
        const tables = tableDirectory(dirBuf, 0);
        if (!tables.name) continue;
        const nameBuf = readAt(fd, tables.name.offset, Math.min(tables.name.length, 1 << 20));
        const names = readNames(nameBuf);
        let weight = 400;
        let italic = false;
        if (tables["OS/2"]) {
          const os2 = readAt(fd, tables["OS/2"].offset, 64);
          if (os2.length >= 64) {
            weight = os2.readUInt16BE(4) || 400;
            italic = (os2.readUInt16BE(62) & 1) === 1;
          }
        }
        faces.push({ file, index, names, weight, italic });
      }
    } catch {
      /* unreadable or broken font: ignore */
    } finally {
      if (fd !== undefined) fs.closeSync(fd);
    }
  }
  INDEX = faces;
  return faces;
}

export function resetFontIndex() {
  INDEX = null;
  LOADED.clear();
  LOOKUPS.clear();
}

class Face {
  constructor(buf, base) {
    this.buf = buf;
    this.t = tableDirectory(buf, base);
    const head = this.t.head;
    this.upem = head ? buf.readUInt16BE(head.offset + 18) || 1000 : 1000;
    this.locaLong = head ? buf.readInt16BE(head.offset + 50) === 1 : false;
    const hhea = this.t.hhea;
    this.hMetrics = hhea ? buf.readUInt16BE(hhea.offset + 34) : 0;
    this.capHeight = 0.72;
    this.xHeight = 0.52;
    const os2 = this.t["OS/2"];
    if (os2 && os2.length >= 90) {
      const version = buf.readUInt16BE(os2.offset);
      if (version >= 2) {
        const xh = buf.readInt16BE(os2.offset + 86);
        const ch = buf.readInt16BE(os2.offset + 88);
        if (ch > 0) this.capHeight = ch / this.upem;
        if (xh > 0) this.xHeight = xh / this.upem;
      }
    }
    this.hasOutlines = Boolean(this.t.glyf && this.t.loca);
    this.cmap = this.#cmap();
    this.cache = new Map();
  }

  #cmap() {
    const table = this.t.cmap;
    if (!table) return null;
    const { buf } = this;
    const n = buf.readUInt16BE(table.offset + 2);
    const subtables = [];
    for (let i = 0; i < n; i++) {
      const p = table.offset + 4 + i * 8;
      const platform = buf.readUInt16BE(p);
      const encoding = buf.readUInt16BE(p + 2);
      const offset = table.offset + buf.readUInt32BE(p + 4);
      const format = buf.readUInt16BE(offset);
      let rank = -1;
      if (platform === 3 && encoding === 10) rank = 5;
      else if (platform === 0 && (encoding === 4 || encoding === 6)) rank = 4;
      else if (platform === 3 && encoding === 1) rank = 3;
      else if (platform === 0) rank = 2;
      if (rank >= 0 && (format === 4 || format === 12)) subtables.push({ rank, offset, format });
    }
    subtables.sort((a, b) => b.rank - a.rank);
    const best = subtables[0];
    if (!best) return null;
    return best.format === 12 ? this.#cmap12(best.offset) : this.#cmap4(best.offset);
  }

  #cmap12(offset) {
    const { buf } = this;
    const groups = buf.readUInt32BE(offset + 12);
    return (cp) => {
      let lo = 0;
      let hi = groups - 1;
      while (lo <= hi) {
        const mid = (lo + hi) >> 1;
        const p = offset + 16 + mid * 12;
        const start = buf.readUInt32BE(p);
        const end = buf.readUInt32BE(p + 4);
        if (cp < start) hi = mid - 1;
        else if (cp > end) lo = mid + 1;
        else return buf.readUInt32BE(p + 8) + (cp - start);
      }
      return 0;
    };
  }

  #cmap4(offset) {
    const { buf } = this;
    const segX2 = buf.readUInt16BE(offset + 6);
    const seg = segX2 / 2;
    const ends = offset + 14;
    const starts = ends + segX2 + 2;
    const deltas = starts + segX2;
    const ranges = deltas + segX2;
    return (cp) => {
      if (cp > 0xffff) return 0;
      let lo = 0;
      let hi = seg - 1;
      while (lo <= hi) {
        const mid = (lo + hi) >> 1;
        const end = buf.readUInt16BE(ends + mid * 2);
        const start = buf.readUInt16BE(starts + mid * 2);
        if (cp < start) hi = mid - 1;
        else if (cp > end) lo = mid + 1;
        else {
          const delta = buf.readInt16BE(deltas + mid * 2);
          const rangeOffset = buf.readUInt16BE(ranges + mid * 2);
          if (rangeOffset === 0) return (cp + delta) & 0xffff;
          const p = ranges + mid * 2 + rangeOffset + (cp - start) * 2;
          if (p + 2 > buf.length) return 0;
          const g = buf.readUInt16BE(p);
          return g === 0 ? 0 : (g + delta) & 0xffff;
        }
      }
      return 0;
    };
  }

  advance(gid) {
    const hmtx = this.t.hmtx;
    if (!hmtx || !this.hMetrics) return this.upem * 0.6;
    const i = Math.min(gid, this.hMetrics - 1);
    return this.buf.readUInt16BE(hmtx.offset + i * 4);
  }

  /** [xMin, yMin, xMax, yMax] in font units, `null` for an empty glyph, `undefined` if unknown (CFF). */
  bounds(gid) {
    if (!this.hasOutlines) return undefined;
    const { buf } = this;
    const loca = this.t.loca.offset;
    let start;
    let end;
    if (this.locaLong) {
      if (loca + (gid + 2) * 4 > buf.length) return undefined;
      start = buf.readUInt32BE(loca + gid * 4);
      end = buf.readUInt32BE(loca + gid * 4 + 4);
    } else {
      if (loca + (gid + 2) * 2 > buf.length) return undefined;
      start = buf.readUInt16BE(loca + gid * 2) * 2;
      end = buf.readUInt16BE(loca + gid * 2 + 2) * 2;
    }
    if (end <= start) return null;
    const p = this.t.glyf.offset + start;
    if (p + 10 > buf.length) return undefined;
    return [buf.readInt16BE(p + 2), buf.readInt16BE(p + 4), buf.readInt16BE(p + 6), buf.readInt16BE(p + 8)];
  }

  /**
   * Metrics of one character in em units: `adv` is the advance, `ink` the vertical ink extent above
   * the baseline (y up) as { ymin, ymax }, `null` when the glyph draws nothing, or "unknown" when
   * the outline format hides its bounds (CFF). Returns `null` if the font lacks the character.
   */
  measure(ch) {
    const cached = this.cache.get(ch);
    if (cached !== undefined) return cached;
    let result = null;
    const gid = this.cmap ? this.cmap(ch.codePointAt(0)) : 0;
    if (gid) {
      const adv = this.advance(gid) / this.upem;
      const b = this.bounds(gid);
      if (b === undefined) result = { adv, ink: "unknown" };
      else if (b === null) result = { adv, ink: null };
      else result = { adv, ink: { ymin: b[1] / this.upem, ymax: b[3] / this.upem } };
    }
    this.cache.set(ch, result);
    return result;
  }
}

function load(entry) {
  const key = `${entry.file}#${entry.index}`;
  if (LOADED.has(key)) return LOADED.get(key);
  let face = null;
  try {
    const buf = fs.readFileSync(entry.file);
    const base = faceOffsets(buf)[entry.index] ?? 0;
    face = new Face(buf, base);
    if (!face.cmap) face = null;
  } catch {
    face = null;
  }
  if (LOADED.size >= 6) LOADED.delete(LOADED.keys().next().value);
  LOADED.set(key, face);
  return face;
}

/**
 * Finds the font file for a Koharu `preferred_font` name (family / full / PostScript name).
 * Picks the face closest to the requested weight and style. Returns { face, file } or null.
 */
export function findFont(name, { weight = 400, italic = false } = {}) {
  const wanted = norm(name);
  if (!wanted) return null;
  const key = `${wanted}|${weight}|${italic}`;
  if (LOOKUPS.has(key)) return LOOKUPS.get(key);
  let found = null;
  try {
    const candidates = fontIndex().filter((f) => f.names.has(wanted));
    if (candidates.length) {
      const score = (f) => Math.abs(f.weight - weight) + (f.italic === italic ? 0 : 1000);
      candidates.sort((a, b) => score(a) - score(b));
      const best = candidates[0];
      const face = load(best);
      if (face) found = { face, file: best.file };
    }
  } catch {
    found = null;
  }
  LOOKUPS.set(key, found);
  return found;
}

/** Loads a face straight from a font file (tests, explicit overrides). */
export function loadFontFile(file, index = 0) {
  return load({ file, index });
}
