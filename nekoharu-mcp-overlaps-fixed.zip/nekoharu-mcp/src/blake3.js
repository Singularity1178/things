// Dependency-free BLAKE3 (32-byte unkeyed hash). Koharu checksums every state
// file with BLAKE3, so the tool needs it to publish a state Koharu will accept.
// Ported from the BLAKE3 reference implementation; verified against Koharu's
// own state files and the official test vectors (see test/).

const IV = [
  0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
];
const PERM = [2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8];
const CHUNK_START = 1;
const CHUNK_END = 2;
const PARENT = 4;
const ROOT = 8;
const CHUNK_LEN = 1024;

const rotr = (x, n) => ((x >>> n) | (x << (32 - n))) >>> 0;

function g(s, a, b, c, d, mx, my) {
  s[a] = (s[a] + s[b] + mx) >>> 0;
  s[d] = rotr(s[d] ^ s[a], 16);
  s[c] = (s[c] + s[d]) >>> 0;
  s[b] = rotr(s[b] ^ s[c], 12);
  s[a] = (s[a] + s[b] + my) >>> 0;
  s[d] = rotr(s[d] ^ s[a], 8);
  s[c] = (s[c] + s[d]) >>> 0;
  s[b] = rotr(s[b] ^ s[c], 7);
}

function round(s, m) {
  g(s, 0, 4, 8, 12, m[0], m[1]);
  g(s, 1, 5, 9, 13, m[2], m[3]);
  g(s, 2, 6, 10, 14, m[4], m[5]);
  g(s, 3, 7, 11, 15, m[6], m[7]);
  g(s, 0, 5, 10, 15, m[8], m[9]);
  g(s, 1, 6, 11, 12, m[10], m[11]);
  g(s, 2, 7, 8, 13, m[12], m[13]);
  g(s, 3, 4, 9, 14, m[14], m[15]);
}

function permute(m) {
  const p = m.slice();
  for (let i = 0; i < 16; i++) m[i] = p[PERM[i]];
}

function compress(cv, block, counter, blockLen, flags) {
  const s = [
    cv[0], cv[1], cv[2], cv[3], cv[4], cv[5], cv[6], cv[7],
    IV[0], IV[1], IV[2], IV[3],
    Number(counter & 0xffffffffn), Number((counter >> 32n) & 0xffffffffn),
    blockLen, flags,
  ];
  const m = block.slice();
  for (let r = 0; r < 7; r++) {
    round(s, m);
    if (r < 6) permute(m);
  }
  for (let i = 0; i < 8; i++) {
    s[i] = (s[i] ^ s[i + 8]) >>> 0;
    s[i + 8] = (s[i + 8] ^ cv[i]) >>> 0;
  }
  return s;
}

function wordsOf(buf) {
  const w = new Array(16).fill(0);
  for (let i = 0; i < buf.length; i++) w[i >> 2] |= buf[i] << (8 * (i & 3));
  return w.map((x) => x >>> 0);
}

// An "output" is a pending compression: it can yield a chaining value or root bytes.
const chainingValue = (o) => compress(o.cv, o.block, o.counter, o.blockLen, o.flags).slice(0, 8);

function parentOutput(left, right) {
  return { cv: IV, block: left.concat(right), counter: 0n, blockLen: 64, flags: PARENT };
}

function chunkOutput(chunk, counter) {
  let cv = IV.slice();
  const blocks = Math.max(1, Math.ceil(chunk.length / 64));
  for (let i = 0; i < blocks; i++) {
    const slice = chunk.subarray(i * 64, Math.min(chunk.length, (i + 1) * 64));
    const first = i === 0 ? CHUNK_START : 0;
    if (i === blocks - 1) {
      return {
        cv,
        block: wordsOf(slice),
        counter,
        blockLen: slice.length,
        flags: first | CHUNK_END,
      };
    }
    cv = compress(cv, wordsOf(slice), counter, 64, first).slice(0, 8);
  }
  throw new Error("unreachable");
}

/** @param {Uint8Array} input @returns {Buffer} 32-byte digest */
export function blake3(input) {
  const data = Buffer.from(input);
  const stack = [];
  let chunks = 0n;
  let offset = 0;
  // All full chunks except a trailing one are folded into the stack as we go.
  while (data.length - offset > CHUNK_LEN) {
    let cv = chainingValue(chunkOutput(data.subarray(offset, offset + CHUNK_LEN), chunks));
    offset += CHUNK_LEN;
    chunks += 1n;
    let total = chunks;
    while ((total & 1n) === 0n) {
      cv = chainingValue(parentOutput(stack.pop(), cv));
      total >>= 1n;
    }
    stack.push(cv);
  }
  let output = chunkOutput(data.subarray(offset), chunks);
  while (stack.length > 0) {
    output = parentOutput(stack.pop(), chainingValue(output));
  }
  const words = compress(output.cv, output.block, 0n, output.blockLen, output.flags | ROOT);
  const out = Buffer.alloc(32);
  for (let i = 0; i < 8; i++) out.writeUInt32LE(words[i], i * 4);
  return out;
}
