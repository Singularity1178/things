// A faithful (but font-file-only) re-implementation of how Koharu's renderer decides WHERE a text
// layer's pixels end up. Everything here mirrors crates/koharu-renderer of NeKoharu v0.85.3-N:
//
//  * frame      renderer.rs `text_draft` + bubble.rs `geometry_frame`: the frame is the layer's own
//               Geometry (axes taken from `TextLayout.angle_degrees`, or inferred from a 4-point
//               rectangle) or the fits-to / flows-in region. The text is rotated about its centre.
//  * size       text_renderer.rs `render_descriptor`: auto-fit text searches the largest size in
//               [9, max] that fits (max = 24 for free text, the balloon width for bubble text, and
//               typography.size is IGNORED while auto-fit is on); fixed text uses typography.size
//               (or the same default maximum when it is unset) and simply overflows.
//  * lines      layout.rs: greedy-looking but really an optimal-fit search that minimises the sum of
//               cubed slack, with discretionary hyphens (penalty 2000). Reproduced here.
//  * block      layout.rs `run_with_size`: height is the TIGHT INK box of all glyphs (+1px pad) and
//               width is the widest line's ink (+1px pad) - not lines x line-height.
//  * placement  text_renderer.rs `placement`: the block is centred on the frame on both axes, so
//               text that is too big spills out equally on both sides. Point text is the exception:
//               it is anchored to the frame's top-left corner and never wraps.
//  * stroke     the outline is drawn outside the glyphs and extends the visible area.
//
// What it cannot know: kerning/ligatures (GPOS), the fallback font chain, Koharu's global
// "font families" setting for layers without a preferred_font, and the exact contour-fitted line
// shapes of speech-balloon text. Those cases are measured conservatively and flagged via `method`
// and `confidence` so callers never silently trust a guess.

import { findFont } from "./fontfile.js";

export const MIN_FONT_SIZE = 9; // renderer.rs MINIMUM_FONT_SIZE
export const DEFAULT_LINE_SPACING = 1.2; // renderer.rs DEFAULT_LINE_SPACING
export const FREE_TEXT_MAX_SIZE = 24; // text_renderer.rs automatic_maximum (non-balloon text)
const PAD = 1; // layout.rs ink padding
const BUBBLE_INSET = 4; // renderer.rs text_inset
const BUBBLE_FIT = 0.9; // balloon contours are narrower than their bounding box
const HYPHEN_PENALTY = 2000; // layout.rs LINE_BREAK_HYPHEN_PENALTY
const OVERFLOW_MULTIPLIER = 10000; // layout.rs LINE_BREAK_OVERFLOW_MULTIPLIER
const APPROX_WIDTH = 1.03; // comic fonts run a little wider than Arial
const APPROX_INK_SLACK = 0.03; // em, added above/below when ink bounds are estimated

// ------------------------------------------------------------------- frame

const rad = (deg) => (deg * Math.PI) / 180;
const finiteAll = (points) => points.every((p) => Number.isFinite(p.x) && Number.isFinite(p.y));

function aabbFrame(points) {
  const xs = points.map((p) => p.x);
  const ys = points.map((p) => p.y);
  const x = Math.min(...xs);
  const y = Math.min(...ys);
  const width = Math.max(...xs) - x;
  const height = Math.max(...ys) - y;
  return width > 0 && height > 0 ? { x, y, width, height, angle: 0 } : null;
}

/** bubble.rs `geometry_frame`: points (+ optional authored angle) -> { x, y, width, height, angle }. */
export function frameGeometry(points, angleDegrees = null) {
  if (!points?.length || !finiteAll(points)) return null;
  if (angleDegrees !== null && angleDegrees !== undefined && Number.isFinite(angleDegrees)) {
    const sin = Math.sin(rad(angleDegrees));
    const cos = Math.cos(rad(angleDegrees));
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (const p of points) {
      const x = p.x * cos + p.y * sin;
      const y = -p.x * sin + p.y * cos;
      minX = Math.min(minX, x);
      minY = Math.min(minY, y);
      maxX = Math.max(maxX, x);
      maxY = Math.max(maxY, y);
    }
    const width = maxX - minX;
    const height = maxY - minY;
    if (!(width > 0 && height > 0)) return null;
    const cx = (minX + maxX) / 2;
    const cy = (minY + maxY) / 2;
    return {
      x: cx * cos - cy * sin - width / 2,
      y: cx * sin + cy * cos - height / 2,
      width,
      height,
      angle: angleDegrees,
    };
  }
  if (points.length !== 4) return aabbFrame(points);
  const [a, b, c, d] = points;
  const top = [b.x - a.x, b.y - a.y];
  const right = [c.x - b.x, c.y - b.y];
  const bottom = [d.x - c.x, d.y - c.y];
  const left = [a.x - d.x, a.y - d.y];
  const width = Math.hypot(...top);
  const height = Math.hypot(...right);
  if (!(width > 1e-9 && height > 1e-9)) return null;
  const scale = Math.max(width, height, 1);
  const tol = scale * 1e-6;
  const isRect =
    Math.abs(Math.hypot(...bottom) - width) <= tol &&
    Math.abs(Math.hypot(...left) - height) <= tol &&
    Math.abs(top[0] * right[0] + top[1] * right[1]) <= width * height * 1e-6 &&
    Math.abs(a.x + c.x - (b.x + d.x)) <= tol &&
    Math.abs(a.y + c.y - (b.y + d.y)) <= tol;
  if (!isRect) return aabbFrame(points);
  const cx = (a.x + b.x + c.x + d.x) / 4;
  const cy = (a.y + b.y + c.y + d.y) / 4;
  return { x: cx - width / 2, y: cy - height / 2, width, height, angle: (Math.atan2(top[1], top[0]) * 180) / Math.PI };
}

/** Frame-local point (origin = top-left of the unrotated frame) -> page coordinates. */
export function toPage(frame, lx, ly) {
  const cx = frame.x + frame.width / 2;
  const cy = frame.y + frame.height / 2;
  const dx = lx - frame.width / 2;
  const dy = ly - frame.height / 2;
  const sin = Math.sin(rad(frame.angle));
  const cos = Math.cos(rad(frame.angle));
  return { x: cx + dx * cos - dy * sin, y: cy + dx * sin + dy * cos };
}

export const cornersOf = (frame, [x0, y0, x1, y1]) =>
  [toPage(frame, x0, y0), toPage(frame, x1, y0), toPage(frame, x1, y1), toPage(frame, x0, y1)];

export function bboxOf(points) {
  const xs = points.map((p) => p.x);
  const ys = points.map((p) => p.y);
  return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
}

// ----------------------------------------------------------------- glyph metrics

// Advance widths (em) of Arial/Helvetica, the baseline of the approximation.
const ADV = {
  " ": 0.278, a: 0.556, b: 0.556, c: 0.5, d: 0.556, e: 0.556, f: 0.278, g: 0.556, h: 0.556, i: 0.222, j: 0.222,
  k: 0.5, l: 0.222, m: 0.833, n: 0.556, o: 0.556, p: 0.556, q: 0.556, r: 0.333, s: 0.5, t: 0.278, u: 0.556,
  v: 0.5, w: 0.722, x: 0.5, y: 0.5, z: 0.5, A: 0.667, B: 0.667, C: 0.722, D: 0.722, E: 0.667, F: 0.611,
  G: 0.778, H: 0.722, I: 0.278, J: 0.5, K: 0.667, L: 0.556, M: 0.833, N: 0.722, O: 0.778, P: 0.667, Q: 0.778,
  R: 0.722, S: 0.667, T: 0.611, U: 0.722, V: 0.667, W: 0.944, X: 0.667, Y: 0.667, Z: 0.611,
  ".": 0.278, ",": 0.278, "!": 0.278, "?": 0.556, "'": 0.191, '"': 0.355, ":": 0.278, ";": 0.278, "-": 0.333,
  "(": 0.333, ")": 0.333, "…": 1, "—": 1, "–": 0.556, "&": 0.667, "%": 0.889, "/": 0.278, "~": 0.584, "*": 0.389,
};

const isCjk = (cp) =>
  (cp >= 0x1100 && cp <= 0x11ff) || (cp >= 0x2e80 && cp <= 0x9fff) || (cp >= 0xac00 && cp <= 0xd7af) ||
  (cp >= 0xf900 && cp <= 0xfaff) || (cp >= 0xff00 && cp <= 0xffef) || (cp >= 0x20000 && cp <= 0x3ffff);

const CJK_TEXT = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Bopomofo}]/u;
export const hasCjk = (text) => CJK_TEXT.test(text);

function approxAdvance(ch) {
  const cp = ch.codePointAt(0);
  if (isCjk(cp)) return 1;
  if (/\p{Mn}/u.test(ch)) return 0;
  if (/\d/.test(ch)) return 0.556 * APPROX_WIDTH;
  return (ADV[ch] ?? (/\p{Lu}/u.test(ch) ? 0.68 : 0.56)) * APPROX_WIDTH;
}

/** Vertical ink extent [ymin, ymax] (em, y up from the baseline) by character class. */
function approxInk(ch, cap, xh) {
  if (/\s/u.test(ch)) return null;
  const cp = ch.codePointAt(0);
  if (isCjk(cp)) return { ymin: -0.08, ymax: 0.88 };
  const fixed = {
    ".": [0, 0.12], ",": [-0.15, 0.12], "'": [cap * 0.62, cap], '"': [cap * 0.62, cap], "`": [cap * 0.7, cap],
    ":": [0, xh], ";": [-0.15, xh], "-": [0.22, 0.34], "–": [0.22, 0.34], "—": [0.22, 0.34], "…": [0, 0.12],
    "(": [-0.2, 0.76], ")": [-0.2, 0.76], "/": [-0.1, 0.76], "~": [0.2, 0.42], "*": [cap * 0.55, cap],
    $: [-0.1, 0.8], "@": [-0.15, 0.74], Q: [-0.1, cap + 0.01], J: [-0.02, cap + 0.01],
  };
  if (fixed[ch]) return { ymin: fixed[ch][0], ymax: fixed[ch][1] };
  if (/[bdfhkl]/.test(ch)) return { ymin: -0.01, ymax: cap * 1.04 };
  if (ch === "t") return { ymin: -0.01, ymax: Math.max(xh * 1.3, cap * 0.9) };
  if (ch === "i" || ch === "j") return { ymin: ch === "j" ? -0.2 : -0.01, ymax: cap * 0.99 };
  if (/[gjpqy]/.test(ch)) return { ymin: -0.22, ymax: xh + 0.01 };
  if (/[a-z]/.test(ch)) return { ymin: -0.01, ymax: xh + 0.01 };
  if (/[\p{Lu}\d]/u.test(ch)) return { ymin: -0.01, ymax: cap + 0.01 };
  return { ymin: 0, ymax: cap };
}

/** Per-layer measuring context: either a real font face or the approximation. */
function makeMetrics(typography) {
  let found = null;
  if (typography?.preferred_font) {
    const style = typography.font_style;
    found = findFont(typography.preferred_font, {
      weight: typography.font_weight ?? 400,
      italic: style === "italic" || style === "oblique",
    });
  }
  const face = found?.face ?? null;
  const cap = face?.capHeight ?? 0.72;
  const xh = face?.xHeight ?? 0.52;
  const cache = new Map();
  let approximated = false;
  const measure = (ch) => {
    let m = cache.get(ch);
    if (m) return m;
    const real = face?.measure(ch);
    if (real) {
      let ink = real.ink;
      if (ink === "unknown") {
        const a = approxInk(ch, cap, xh);
        ink = a && { ymin: a.ymin - APPROX_INK_SLACK, ymax: a.ymax + APPROX_INK_SLACK };
        approximated = true;
      }
      m = { adv: real.adv, ink };
    } else {
      if (!/\s/u.test(ch)) approximated = true; // the font is missing or lacks this character
      const a = approxInk(ch, cap, xh);
      m = {
        adv: approxAdvance(ch),
        ink: a && { ymin: a.ymin - APPROX_INK_SLACK, ymax: a.ymax + APPROX_INK_SLACK },
      };
    }
    cache.set(ch, m);
    return m;
  };
  return {
    measure,
    font: found ? found.file : null,
    fontName: typography?.preferred_font ?? null,
    get approximated() {
      return approximated;
    },
  };
}

// ------------------------------------------------------------- line breaking

const VOWEL = /[aeiouy]/;
const DIGRAPH = new Set(["th", "ch", "sh", "ph", "gh", "wh", "ck", "ng", "qu", "ll", "ss", "tt"]);

/** Cheap stand-in for hypher's English patterns: V-CV and VC-CV syllable splits (min 2 / 3 letters). */
function hyphenPoints(word) {
  const w = word.toLowerCase();
  const out = [];
  for (let i = 2; i <= w.length - 3; i++) {
    const a = w[i - 1];
    const b = w[i];
    const v = (c) => VOWEL.test(c);
    if (v(a) && !v(b) && v(w[i + 1])) out.push(i);
    else if (!v(a) && !v(b) && v(w[i - 2]) && v(w[i + 1]) && !DIGRAPH.has(a + b)) out.push(i);
  }
  return out;
}

const CLOSING = /[\u3001\u3002\uff0c\uff0e\uff09\u300d\u300f\u3011\u30fc\u3041\u3043\u3045\u3047\u3049\u3063\u3083\u3085\u3087\uff01\uff1f]/u;

/** Splits one paragraph into unbreakable pieces (UAX #14 flavoured: spaces, hyphens, CJK). */
function pieces(paragraph) {
  const chars = Array.from(paragraph);
  const out = [];
  let cur = "";
  let i = 0;
  while (i < chars.length) {
    const ch = chars[i];
    cur += ch;
    i++;
    const next = chars[i];
    const space = /[ \t]/.test(ch);
    if (space) {
      if (next === undefined || !/[ \t]/.test(next)) {
        out.push(cur);
        cur = "";
      }
    } else if (/[-–—]/.test(ch) && next !== undefined && !/[\s\d]/.test(next) && cur.length > 1) {
      out.push(cur);
      cur = "";
    } else if (isCjk(ch.codePointAt(0)) && next !== undefined && !CLOSING.test(next)) {
      out.push(cur);
      cur = "";
    }
  }
  if (cur) out.push(cur);
  return out;
}

function advanceOf(text, size, m) {
  let sum = 0;
  for (const ch of text) sum += m.measure(ch).adv;
  return sum * size;
}

function buildSegments(paragraph, size, m, hyphenate) {
  const hy = m.measure("-").adv * size;
  const segs = [];
  for (const piece of pieces(paragraph)) {
    const visible = piece.replace(/[ \t]+$/, "");
    const trailingText = piece.slice(visible.length);
    const trailing = advanceOf(trailingText, size, m);
    const letters = /^\p{L}+$/u.test(visible) && !hasCjk(visible);
    const cuts = hyphenate && letters && visible.length >= 5 ? hyphenPoints(visible) : [];
    if (!cuts.length) {
      segs.push({ text: visible, raw: piece, adv: advanceOf(visible, size, m) + trailing, trailing, suffix: 0 });
      continue;
    }
    let from = 0;
    for (const cut of cuts) {
      const part = visible.slice(from, cut);
      segs.push({ text: part, raw: part, adv: advanceOf(part, size, m), trailing: 0, suffix: hy });
      from = cut;
    }
    const last = visible.slice(from);
    segs.push({ text: last, raw: last + trailingText, adv: advanceOf(last, size, m) + trailing, trailing, suffix: 0 });
  }
  return segs;
}

const badness = (advance, extent) =>
  advance <= extent ? (extent - advance) ** 3 : (advance - extent) ** 3 * OVERFLOW_MULTIPLIER;

/** layout.rs `optimal_uniform_line_breaks`: returns exclusive end indexes per line. */
function optimalBreaks(segs, extent, allowHyphens) {
  const n = segs.length;
  if (!Number.isFinite(extent) || extent <= 0) return { ends: [n], overflow: false };
  const dp = new Array(n + 1).fill(Infinity);
  const prev = new Array(n + 1).fill(-1);
  dp[0] = 0;
  for (let start = 0; start < n; start++) {
    if (!Number.isFinite(dp[start])) continue;
    let advance = 0;
    for (let end = start + 1; end <= n; end++) {
      const s = segs[end - 1];
      advance += s.adv;
      const suffix = end < n ? s.suffix : 0;
      const lineAdvance = advance - s.trailing + suffix;
      const hyphenated = end < n && suffix > 0;
      if (hyphenated && !allowHyphens) continue;
      let cost = dp[start] + badness(lineAdvance, extent);
      if (hyphenated) cost += HYPHEN_PENALTY;
      if (cost < dp[end]) {
        dp[end] = cost;
        prev[end] = start;
      }
      if (advance > extent) break;
    }
  }
  if (!Number.isFinite(dp[n])) return { ends: [n], overflow: true };
  const ends = [];
  for (let i = n; i > 0; i = prev[i]) {
    ends.push(i);
    if (prev[i] < 0) return { ends: [n], overflow: true };
  }
  ends.reverse();
  return { ends, overflow: false };
}

// ------------------------------------------------------------- layout at a size

function lineMetrics(parts, size, m) {
  // parts: [{ text, hyphen }]; returns advance and ink extent (em) of the visible glyphs.
  let adv = 0;
  let ymin = Infinity;
  let ymax = -Infinity;
  for (const part of parts) {
    for (const ch of part.text) {
      const g = m.measure(ch);
      adv += g.adv * size;
      if (g.ink) {
        ymin = Math.min(ymin, g.ink.ymin);
        ymax = Math.max(ymax, g.ink.ymax);
      }
    }
  }
  return { adv, ymin: Number.isFinite(ymin) ? ymin : null, ymax: Number.isFinite(ymax) ? ymax : null };
}

function horizontalLines(ctx, size) {
  const { m, paragraphs, extent, hyphenate, lastResortHyphens } = ctx;
  const lines = [];
  let overflow = false;
  for (const paragraph of paragraphs) {
    const segs = buildSegments(paragraph, size, m, hyphenate);
    if (!segs.length) {
      lines.push({ adv: 0, ymin: null, ymax: null, text: "" });
      continue;
    }
    let result = optimalBreaks(segs, extent, !lastResortHyphens && hyphenate);
    if (lastResortHyphens && hyphenate && result.ends.some((end, k) => lineWidth(segs, k ? result.ends[k - 1] : 0, end) > extent + 1e-6)) {
      result = optimalBreaks(segs, extent, true);
    }
    overflow ||= result.overflow;
    let from = 0;
    for (const end of result.ends) {
      const slice = segs.slice(from, end);
      const parts = slice.map((s) => ({ text: s.text }));
      if (end < segs.length && segs[end - 1].suffix > 0) parts.push({ text: "-" });
      const lm = lineMetrics(parts, size, m);
      lm.text = slice.map((s) => s.raw).join("").trimEnd() + (end < segs.length && segs[end - 1].suffix > 0 ? "-" : "");
      lines.push(lm);
      from = end;
    }
  }
  return { lines, overflow };
}

function lineWidth(segs, from, end) {
  let sum = 0;
  for (let i = from; i < end; i++) sum += segs[i].adv;
  return sum - segs[end - 1].trailing;
}

/** Vertical (tategaki) approximation: columns of full-width cells, right to left. */
function verticalLayout(ctx, size) {
  const { paragraphs, extent } = ctx;
  const perColumn = Number.isFinite(extent) ? Math.max(1, Math.floor(extent / size + 1e-6)) : Infinity;
  let columns = 0;
  let longest = 0;
  for (const p of paragraphs) {
    const len = Array.from(p).length;
    const cols = Math.max(1, Math.ceil(len / perColumn));
    columns += cols;
    longest = Math.max(longest, Math.min(len, perColumn));
  }
  const lh = size * ctx.lineSpacing;
  const width = (columns - 1) * lh + size * 0.95 + 2 * PAD;
  const height = longest * size + 2 * PAD;
  return { lines: columns, width, height, overflow: false };
}

function layoutAt(ctx, size) {
  if (ctx.vertical) {
    const v = verticalLayout(ctx, size);
    return { size, ...v, overflowed: v.width > ctx.maxW + 1e-3 || v.height > ctx.maxH + 1e-3 };
  }
  const lh = size * ctx.lineSpacing;
  const { lines, overflow } = horizontalLines(ctx, size);
  let minY = Infinity;
  let maxY = -Infinity;
  let widest = 0;
  lines.forEach((line, i) => {
    widest = Math.max(widest, line.adv);
    if (line.ymin === null) return;
    const base = i * lh;
    minY = Math.min(minY, base - line.ymax * size);
    maxY = Math.max(maxY, base - line.ymin * size);
  });
  const height = Number.isFinite(minY) ? maxY - minY + 2 * PAD : 0;
  const width = widest + 2 * PAD;
  const overflowed =
    overflow || widest > ctx.extent + 1e-3 || (!ctx.point && (width > ctx.maxW + 1e-3 || height > ctx.maxH + 1e-3));
  return { size, lines: lines.length, lineTexts: lines.map((l) => l.text), width, height, overflowed };
}

/** layout.rs `run_auto` for the non-balloon path (bisection between the minimum and maximum size). */
function autoSize(ctx, minimum, maximum) {
  const fits = (l) => !l.overflowed && l.width <= ctx.maxW + 1e-6 && l.height <= ctx.maxH + 1e-6;
  const top = layoutAt(ctx, maximum);
  if (fits(top)) return top;
  let best = layoutAt(ctx, minimum);
  if (!fits(best)) return best;
  let low = minimum;
  let high = maximum;
  for (let i = 0; i < 16 && high - low > 0.01; i++) {
    const size = (low + high) / 2;
    const l = layoutAt(ctx, size);
    if (fits(l)) {
      best = l;
      low = size;
    } else high = size;
  }
  return best;
}

// -------------------------------------------------------------- public entry

function resolveWritingMode(text, frame, typography) {
  const mode = typography?.writing_mode ?? null;
  const user = typography?.origin?.kind === "user";
  if (user && mode) return mode;
  if (!hasCjk(text)) return "horizontal";
  if (mode) return mode;
  return frame.height > frame.width ? "vertical" : "horizontal";
}

/** Extra visible reach of the outline around the glyphs (px), or 0. */
export function strokePadding(t) {
  const width = t?.stroke_width;
  if (!(width > 0)) return 0;
  const alpha = t.stroke_color ? t.stroke_color[3] : 255;
  if (!(alpha > 0)) return 0;
  const contour = t.stroke_method === "contour";
  const outward = contour && t.stroke_position === "center" ? width / 2 : contour && t.stroke_position === "inside" ? 0 : width;
  const outer = t.outer_stroke_width > 0 && (t.outer_stroke_color ? t.outer_stroke_color[3] : 255) > 0 ? t.outer_stroke_width : 0;
  return outward + outer;
}

/** Text a layer actually renders: only the translation (a blank translation draws nothing). */
export const renderedText = (layer) => {
  const text = layer.translation?.text ?? "";
  return text.trim() ? text.replace(/\r\n?/g, "\n") : "";
};

/**
 * Measures where a text layer's pixels land. Returns null if the layer draws nothing or has no
 * usable frame. All coordinates are page pixels (y down).
 *
 *   frame        { x, y, width, height, angle }  the (possibly rotated) layout box
 *   frameCorners the frame's four page corners, frameBox their bounding box
 *   textCorners  the visible text (glyph ink + outline) as a (rotated) rectangle, textBox its bbox
 *   size/lines   the font size Koharu will pick and the resulting line count
 *   overflow     the text does not fit its frame even at the chosen size
 *   method       "font" (real glyph metrics) | "approximate" (some/all metrics estimated)
 */
export function measureText(layer) {
  const text = renderedText(layer);
  if (!text || !layer.frame) return null;
  const t = layer.typography ?? null;
  const authored = layer.frameFrom === "own";
  const frame = frameGeometry(layer.frame, authored ? (layer.layout?.angle_degrees ?? null) : null);
  if (!frame) return null;

  const bubble = Boolean(layer.flowsIn) || layer.frameFrom === "flows-in";
  const point = !bubble && layer.layout?.kind === "point";
  const writing = resolveWritingMode(text, frame, t);
  const vertical = writing === "vertical";
  const inset = bubble ? BUBBLE_INSET : 0;
  const boundsW = Math.max(0, frame.width - 2 * inset);
  const boundsH = Math.max(0, frame.height - 2 * inset);
  const fit = bubble ? BUBBLE_FIT : 1;
  const m = makeMetrics(t);
  const lang = String(layer.translation?.language?.tag ?? layer.translation?.language ?? "en");

  const ctx = {
    m,
    vertical,
    point,
    paragraphs: text.split("\n"),
    lineSpacing: t?.line_spacing > 0 ? t.line_spacing : DEFAULT_LINE_SPACING,
    maxW: boundsW * fit,
    maxH: boundsH * fit,
    extent: point ? Infinity : (vertical ? boundsH : boundsW) * fit,
    hyphenate: !vertical && /^en/i.test(lang),
    lastResortHyphens: bubble,
  };

  const autoFit = t ? Boolean(t.auto_fit) : true;
  const automaticMax = bubble ? (vertical ? boundsH : boundsW) : FREE_TEXT_MAX_SIZE;
  const maximum = Math.max(0.5, autoFit ? automaticMax : (t?.size ?? automaticMax));
  const minimum = Math.min(MIN_FONT_SIZE, maximum);
  const layout = autoFit && !point ? autoSize(ctx, minimum, maximum) : layoutAt(ctx, t?.size ?? maximum);

  const pad = strokePadding(t);
  // Local (unrotated) ink rectangle, relative to the frame's top-left corner.
  let x0;
  let y0;
  if (point) {
    x0 = 0;
    y0 = 0;
  } else {
    x0 = (frame.width - layout.width) / 2;
    y0 = (frame.height - layout.height) / 2;
  }
  const local = [x0 - pad, y0 - pad, x0 + layout.width + pad, y0 + layout.height + pad];
  const frameCorners = cornersOf(frame, [0, 0, frame.width, frame.height]);
  const textCorners = cornersOf(frame, local);
  const exact = !m.approximated && Boolean(m.font);
  return {
    mode: bubble ? "balloon" : point ? "point" : vertical ? "vertical" : "box",
    frame,
    frameCorners,
    frameBox: bboxOf(frameCorners),
    local,
    textCorners,
    textBox: bboxOf(textCorners),
    size: layout.size,
    lines: layout.lines,
    lineTexts: layout.lineTexts ?? null,
    auto_fit: autoFit && !point,
    overflow: layout.overflowed,
    stroke_padding: pad,
    font: m.fontName,
    font_file: m.font,
    method: exact ? "font" : "approximate",
    confidence: bubble || vertical ? "low" : exact ? "high" : "medium",
  };
}

/** Compact, rounded view for tool output. */
export function describeMeasure(r) {
  const round = (v) => Math.round(v * 10) / 10;
  return {
    mode: r.mode,
    font_size: round(r.size),
    lines: r.lines,
    auto_fit: r.auto_fit,
    overflows_frame: r.overflow,
    text_bounds: r.textBox.map(round),
    frame_bounds: r.frameBox.map(round),
    rotation: round(r.frame.angle),
    measured_with: r.method,
    confidence: r.confidence,
  };
}
