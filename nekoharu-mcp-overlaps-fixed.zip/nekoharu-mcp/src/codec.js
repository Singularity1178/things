// Decoders/encoders for Koharu's on-disk project format.
//
// Layers (outermost first):
//   state-a.khr / state-b.khr   koharu-storage: magic + version + length + BLAKE3 + StoredState
//   StoredState.payload         koharu-scene:   StoredState { pages, entities, relations }
//   StoredComponent.payload     one typed component per (entity, KIND)
//
// Components this tool does not edit are kept as opaque bytes, so they survive a
// load/save cycle byte-for-byte.

import { Reader, Writer } from "./wire.js";
import { blake3 } from "./blake3.js";

export const KIND = {
  PROJECT: "dev.koharu.project",
  PAGE: "dev.koharu.page",
  GEOMETRY: "dev.koharu.geometry",
  VISIBILITY: "dev.koharu.visibility",
  ENTITY_ORIGIN: "dev.koharu.entity.origin",
  TEXT_LAYOUT: "dev.koharu.layer.text",
  TYPOGRAPHY: "dev.koharu.text.typography",
  TEXT_CONTENT: "dev.koharu.text.content",
  TEXT_SOURCE: "dev.koharu.text.source",
  TEXT_TRANSLATION: "dev.koharu.text.translation",
  TEXT_GROUP: "dev.koharu.text.group",
  RASTER_LAYER: "dev.koharu.layer.raster",
  REGION: "dev.koharu.analysis.region",
  REL_PRESENTS: "dev.koharu.relation.presents",
  REL_RECOGNIZED_FROM: "dev.koharu.relation.recognized-from",
  REL_FITS_TO: "dev.koharu.relation.fits-to",
  REL_FLOWS_IN: "dev.koharu.relation.flows-in",
  REL_INSIDE: "dev.koharu.relation.inside",
};

// ---------------------------------------------------------------- id wrappers
// EntityId / RelationId / DocumentId / BlobId are single-field revisioned structs.

const readUuidId = (r) => {
  r.revision("id", 1);
  return r.uuid();
};
const writeUuidId = (w, id) => {
  w.revision(1);
  w.uuid(id);
};
const readBlobId = (r) => {
  r.revision("BlobId", 1);
  return r.bytes(32).toString("hex");
};
const writeBlobId = (w, hex) => {
  w.revision(1);
  w.raw(Buffer.from(hex, "hex"));
};

// --------------------------------------------------------------------- origin
// enum Origin { User, Generated(Generation) }

export function readOrigin(r) {
  r.revision("Origin", 1);
  const variant = r.uint();
  if (variant === 0) return { kind: "user" };
  if (variant === 1) {
    r.revision("Generation", 1);
    r.revision("ProducerId", 1);
    const producer = r.string();
    const model = r.option((x) => x.string());
    const confidence = r.option((x) => x.f32());
    return { kind: "generated", producer, model, confidence };
  }
  throw new Error(`unknown Origin variant ${variant}`);
}

export function writeOrigin(w, origin) {
  w.revision(1);
  if (origin.kind === "user") {
    w.varint(0);
    return;
  }
  w.varint(1);
  w.revision(1);
  w.revision(1);
  w.string(origin.producer);
  w.option(origin.model, (x, v) => x.string(v));
  w.option(origin.confidence, (x, v) => x.f32(v));
}

export const USER = Object.freeze({ kind: "user" });

// ------------------------------------------------------------- unit enum tables
// Each unit enum is itself revisioned: a revision header, then the variant index.

function unitEnum(name, variants) {
  return {
    read(r) {
      r.revision(name, 1);
      const index = r.uint();
      if (index >= variants.length) throw new Error(`unknown ${name} variant ${index}`);
      return variants[index];
    },
    write(w, value) {
      const index = variants.indexOf(value);
      if (index < 0) throw new Error(`invalid ${name}: ${value} (expected ${variants.join("|")})`);
      w.revision(1);
      w.varint(index);
    },
    variants,
  };
}

export const ENUMS = {
  fontStyle: unitEnum("FontStyle", ["normal", "italic", "oblique"]),
  alignment: unitEnum("TextAlignment", ["start", "center", "end", "justify"]),
  writingMode: unitEnum("WritingMode", ["horizontal", "vertical"]),
  strokeMethod: unitEnum("StrokeMethod", ["expansion", "contour"]),
  strokePosition: unitEnum("StrokePosition", ["outside", "center", "inside"]),
  strokeJoin: unitEnum("StrokeJoin", ["round", "miter", "bevel"]),
  layoutKind: unitEnum("TextLayoutKind", ["point", "paragraph"]),
};

const readRgba = (r) => [...r.bytes(4)];
const writeRgba = (w, c) => w.raw(Buffer.from(c));
const optEnum = (e) => (r) => r.option((x) => e.read(x));
const writeOptEnum = (e) => (w, v) => w.option(v, (x, y) => e.write(x, y));

// ------------------------------------------------------------------ components
// Each codec: { schema, decode(Buffer) -> object, encode(object) -> Buffer }.
// `schema` is the highest revision this tool writes.

const COMPONENTS = {};

// TextStyleSpan (revision 1): per-word overrides; offsets count Unicode scalar values.
function readSpan(r) {
  r.revision("TextStyleSpan", 1);
  return {
    start: r.uint(),
    end: r.uint(),
    preferred_font: r.option((x) => x.string()),
    font_weight: r.option((x) => x.uint()),
    font_style: optEnum(ENUMS.fontStyle)(r),
    color: r.option(readRgba),
    stroke_color: r.option(readRgba),
    stroke_width: r.option((x) => x.f32()),
  };
}

function writeSpan(w, s) {
  w.revision(1);
  w.varint(s.start);
  w.varint(s.end);
  w.option(s.preferred_font, (x, v) => x.string(v));
  w.option(s.font_weight, (x, v) => x.varint(v));
  writeOptEnum(ENUMS.fontStyle)(w, s.font_style);
  w.option(s.color, writeRgba);
  w.option(s.stroke_color, writeRgba);
  w.option(s.stroke_width, (x, v) => x.f32(v));
}

function define(kind, schema, decode, encode) {
  COMPONENTS[kind] = {
    schema,
    decode(buf) {
      const r = new Reader(buf);
      const value = decode(r);
      r.done(kind);
      return value;
    },
    encode(value) {
      const w = new Writer();
      encode(w, value);
      return w.finish();
    },
  };
}

define(
  KIND.TYPOGRAPHY,
  5,
  (r) => {
    const rev = r.revision("Typography", 5);
    const t = {
      origin: readOrigin(r),
      preferred_font: r.option((x) => x.string()),
      font_weight: r.option((x) => x.uint()),
      font_style: optEnum(ENUMS.fontStyle)(r),
      size: r.option((x) => x.f32()),
      auto_fit: r.bool(),
      color: r.option(readRgba),
      stroke_color: r.option(readRgba),
      stroke_width: r.option((x) => x.f32()),
      alignment: optEnum(ENUMS.alignment)(r),
      writing_mode: optEnum(ENUMS.writingMode)(r),
      extensions: {},
      stroke_method: null,
      stroke_position: null,
      stroke_join: null,
      outer_stroke_color: null,
      outer_stroke_width: null,
      line_spacing: null,
      spans: [],
    };
    const count = r.uint();
    for (let i = 0; i < count; i++) {
      const k = r.string();
      t.extensions[k] = r.string();
    }
    if (rev >= 2) {
      t.stroke_method = optEnum(ENUMS.strokeMethod)(r);
      t.stroke_position = optEnum(ENUMS.strokePosition)(r);
      t.stroke_join = optEnum(ENUMS.strokeJoin)(r);
    }
    if (rev >= 3) {
      t.outer_stroke_color = r.option(readRgba);
      t.outer_stroke_width = r.option((x) => x.f32());
    }
    if (rev >= 4) t.line_spacing = r.option((x) => x.f32());
    if (rev >= 5) t.spans = r.vec(readSpan);
    return t;
  },
  (w, t) => {
    w.revision(5);
    writeOrigin(w, t.origin);
    w.option(t.preferred_font, (x, v) => x.string(v));
    w.option(t.font_weight, (x, v) => x.varint(v));
    writeOptEnum(ENUMS.fontStyle)(w, t.font_style);
    w.option(t.size, (x, v) => x.f32(v));
    w.bool(t.auto_fit);
    w.option(t.color, writeRgba);
    w.option(t.stroke_color, writeRgba);
    w.option(t.stroke_width, (x, v) => x.f32(v));
    writeOptEnum(ENUMS.alignment)(w, t.alignment);
    writeOptEnum(ENUMS.writingMode)(w, t.writing_mode);
    // BTreeMap<String, String> iterates in byte order.
    const keys = Object.keys(t.extensions).sort((a, b) =>
      Buffer.compare(Buffer.from(a), Buffer.from(b)),
    );
    w.varint(keys.length);
    for (const k of keys) {
      w.string(k);
      w.string(t.extensions[k]);
    }
    writeOptEnum(ENUMS.strokeMethod)(w, t.stroke_method);
    writeOptEnum(ENUMS.strokePosition)(w, t.stroke_position);
    writeOptEnum(ENUMS.strokeJoin)(w, t.stroke_join);
    w.option(t.outer_stroke_color, writeRgba);
    w.option(t.outer_stroke_width, (x, v) => x.f32(v));
    w.option(t.line_spacing, (x, v) => x.f32(v));
    w.vec(t.spans ?? [], writeSpan);
  },
);

define(
  KIND.GEOMETRY,
  1,
  (r) => {
    r.revision("Geometry", 1);
    const origin = readOrigin(r);
    const points = r.vec((x) => {
      x.revision("Point", 1);
      return { x: x.f64(), y: x.f64() };
    });
    return { origin, points };
  },
  (w, g) => {
    w.revision(1);
    writeOrigin(w, g.origin);
    w.vec(g.points, (x, p) => {
      x.revision(1);
      x.f64(p.x);
      x.f64(p.y);
    });
  },
);

define(
  KIND.VISIBILITY,
  1,
  (r) => {
    r.revision("Visibility", 1);
    return { origin: readOrigin(r), visible: r.bool(), opacity: r.f32() };
  },
  (w, v) => {
    w.revision(1);
    writeOrigin(w, v.origin);
    w.bool(v.visible);
    w.f32(v.opacity);
  },
);

define(
  KIND.TEXT_LAYOUT,
  2,
  (r) => {
    const rev = r.revision("TextLayout", 2);
    const origin = readOrigin(r);
    const kind = ENUMS.layoutKind.read(r);
    const angle_degrees = rev >= 2 ? r.option((x) => x.f32()) : null;
    return { origin, kind, angle_degrees };
  },
  (w, l) => {
    w.revision(2);
    writeOrigin(w, l.origin);
    ENUMS.layoutKind.write(w, l.kind);
    w.option(l.angle_degrees, (x, v) => x.f32(v));
  },
);

define(
  KIND.PAGE,
  2,
  (r) => {
    const rev = r.revision("Page", 2);
    return {
      label: r.string(),
      width: r.f64(),
      height: r.f64(),
      chapter_start: rev >= 2 ? r.bool() : false,
    };
  },
  (w, p) => {
    w.revision(2);
    w.string(p.label);
    w.f64(p.width);
    w.f64(p.height);
    w.bool(p.chapter_start);
  },
);

define(
  KIND.ENTITY_ORIGIN,
  1,
  (r) => {
    r.revision("EntityOrigin", 1);
    return { origin: readOrigin(r) };
  },
  (w, v) => {
    w.revision(1);
    writeOrigin(w, v.origin);
  },
);

// SourceText / Translation have hand-written serializers: no revision header,
// `Authored<String>` (value, origin) followed by Option<LanguageTag>.
const authoredText = {
  decode(r) {
    const value = r.string();
    const origin = readOrigin(r);
    const language = r.option((x) => {
      x.revision("LanguageTag", 1);
      return x.string();
    });
    return { text: value, origin, language };
  },
  encode(w, v) {
    w.string(v.text);
    writeOrigin(w, v.origin);
    w.option(v.language, (x, tag) => {
      x.revision(1);
      x.string(tag);
    });
  },
};
define(KIND.TEXT_SOURCE, 1, authoredText.decode, authoredText.encode);
define(KIND.TEXT_TRANSLATION, 1, authoredText.decode, authoredText.encode);

export function hasCodec(kind) {
  return kind in COMPONENTS;
}

/** Decodes a component entry (`{key, schema, payload}`) into a plain object. */
export function decodeComponent(entry) {
  const codec = COMPONENTS[entry.key];
  if (!codec) throw new Error(`no decoder for ${entry.key}`);
  return codec.decode(entry.payload);
}

/** Builds a replacement component entry, preserving reference lists. */
export function encodeComponent(kind, value, previous) {
  const codec = COMPONENTS[kind];
  if (!codec) throw new Error(`no encoder for ${kind}`);
  return {
    key: kind,
    schema: codec.schema,
    payload: codec.encode(value),
    recordRefs: previous?.recordRefs ?? [],
    blobRefs: previous?.blobRefs ?? [],
  };
}

// ------------------------------------------------------------------ scene state

function readEntry(r) {
  r.revision("StoredComponentEntry", 1);
  r.revision("ComponentKey", 1);
  const key = r.string();
  r.revision("StoredComponent", 1);
  const schema = r.uint();
  const payload = r.byteVec();
  const recordRefs = r.vec(readUuidId);
  const blobRefs = r.vec(readBlobId);
  return { key, schema, payload, recordRefs, blobRefs };
}

function writeEntry(w, e) {
  w.revision(1);
  w.revision(1);
  w.string(e.key);
  w.revision(1);
  w.varint(e.schema);
  w.byteVec(e.payload);
  // The scene keeps both reference lists sorted and de-duplicated.
  w.vec([...new Set(e.recordRefs)].sort(), writeUuidId);
  w.vec([...new Set(e.blobRefs)].sort(), writeBlobId);
}

/** Decodes a koharu-scene checkpoint (the payload inside a state file). */
export function decodeScene(buf) {
  const r = new Reader(buf);
  r.revision("scene StoredState", 1);
  const pageOrderEpoch = r.varBig();
  const projectComponents = r.vec(readEntry);
  const pages = r.vec((p) => {
    p.revision("StoredPage", 1);
    return {
      id: readUuidId(p),
      epoch: p.varBig(),
      entities: p.vec((e) => {
        e.revision("StoredEntity", 1);
        return {
          id: readUuidId(e),
          parent: e.option(readUuidId),
          components: e.vec(readEntry),
        };
      }),
    };
  });
  const relations = r.vec((x) => {
    x.revision("StoredRelation", 1);
    const id = readUuidId(x);
    x.revision("Relation", 1);
    const origin = readOrigin(x);
    x.revision("RelationKind", 1);
    const kind = x.string();
    const source = readUuidId(x);
    const target = readUuidId(x);
    return { id, origin, kind, source, target, components: x.vec(readEntry) };
  });
  r.done("scene payload");
  return { pageOrderEpoch, projectComponents, pages, relations };
}

export function encodeScene(scene) {
  const w = new Writer();
  w.revision(1);
  w.varint(scene.pageOrderEpoch);
  w.vec(scene.projectComponents, writeEntry);
  w.vec(scene.pages, (x, page) => {
    x.revision(1);
    writeUuidId(x, page.id);
    x.varint(page.epoch);
    x.vec(page.entities, (y, e) => {
      y.revision(1);
      writeUuidId(y, e.id);
      y.option(e.parent, (z, parent) => writeUuidId(z, parent));
      y.vec(e.components, writeEntry);
    });
  });
  w.vec(scene.relations, (x, rel) => {
    x.revision(1);
    writeUuidId(x, rel.id);
    x.revision(1);
    writeOrigin(x, rel.origin);
    x.revision(1);
    x.string(rel.kind);
    writeUuidId(x, rel.source);
    writeUuidId(x, rel.target);
    x.vec(rel.components, writeEntry);
  });
  return w.finish();
}

// ------------------------------------------------------------------- state file

const MAGIC = Buffer.from("KHRSTATE");
const FORMAT_VERSION = 1;
const HEADER_BYTES = 8 + 4 + 8 + 32;
const MAX_STATE_BYTES = 512 * 1024 * 1024;

/** Verifies and decodes one `state-*.khr` file. */
export function decodeStateFile(file) {
  if (file.length < HEADER_BYTES || !file.subarray(0, 8).equals(MAGIC)) {
    throw new Error("not a Koharu state file");
  }
  const version = file.readUInt32LE(8);
  if (version !== FORMAT_VERSION) throw new Error(`unsupported state format version ${version}`);
  const bodyLen = Number(file.readBigUInt64LE(12));
  if (bodyLen > MAX_STATE_BYTES || file.length !== HEADER_BYTES + bodyLen) {
    throw new Error("state length is invalid");
  }
  const body = file.subarray(HEADER_BYTES);
  if (!blake3(body).equals(file.subarray(20, 52))) throw new Error("state checksum mismatch");
  const r = new Reader(body);
  r.revision("StoredState", 1);
  r.revision("DocumentId", 1);
  const document = r.uuid();
  r.revision("Revision", 1);
  const revision = r.varBig();
  const blobs = r.vec(readBlobId);
  const payload = r.byteVec();
  r.done("state body");
  return { document, revision, blobs, payload };
}

export function encodeStateFile(state) {
  const w = new Writer();
  w.revision(1);
  w.revision(1);
  w.uuid(state.document);
  w.revision(1);
  w.varint(state.revision);
  w.vec([...new Set(state.blobs)].sort(), writeBlobId);
  w.byteVec(state.payload);
  const body = w.finish();
  if (body.length > MAX_STATE_BYTES) throw new Error("state exceeds the maximum encoded size");
  const header = Buffer.alloc(HEADER_BYTES);
  MAGIC.copy(header, 0);
  header.writeUInt32LE(FORMAT_VERSION, 8);
  header.writeBigUInt64LE(BigInt(body.length), 12);
  blake3(body).copy(header, 20);
  return Buffer.concat([header, body]);
}
