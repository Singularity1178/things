import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";

import { blake3 } from "../src/blake3.js";
import { decodeScene, decodeStateFile, encodeScene, encodeStateFile } from "../src/codec.js";
import { callTool } from "../src/tools.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const FIXTURE = path.join(here, "fixtures", "sample.khrproj"); // written by Koharu's own crates

function tempProject() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "nekoharu-"));
  const target = path.join(dir, "Sample.khrproj");
  fs.cpSync(FIXTURE, target, { recursive: true });
  return target;
}

const ok = (name, args) => {
  const out = callTool(name, args);
  assert.ok(out.ok, out.error);
  return out.result;
};

test("blake3 matches the official test vectors", () => {
  assert.equal(blake3(Buffer.alloc(0)).toString("hex"), "af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262");
  for (const [len, expected] of [
    [1025, "d00278ae47eb27b34faecf67b4fe263f82d5412916c1ffd97c8cb7fb814b8444"],
    [31744, "62b6960e1a44bcc1eb1a611a8d6235b6b4b78f32e7abc4fb4c6cdcce94895c47"],
  ]) {
    const input = Buffer.alloc(len);
    for (let i = 0; i < len; i++) input[i] = i % 251;
    assert.equal(blake3(input).toString("hex"), expected);
  }
});

test("Koharu-written state files round-trip byte-for-byte", () => {
  for (const slot of ["state-a.khr", "state-b.khr"]) {
    const file = fs.readFileSync(path.join(FIXTURE, slot));
    const state = decodeStateFile(file);
    const scene = decodeScene(state.payload);
    const payload = encodeScene(scene);
    assert.ok(payload.equals(state.payload));
    assert.ok(encodeStateFile({ ...state, payload }).equals(file));
  }
});

test("a corrupted state file is rejected", () => {
  const file = Buffer.from(fs.readFileSync(path.join(FIXTURE, "state-a.khr")));
  file[file.length - 5] ^= 0xff;
  assert.throws(() => decodeStateFile(file), /checksum/);
});

test("project_info and list_text describe the project", () => {
  const project = tempProject();
  const info = ok("project_info", { project });
  assert.equal(info.page_count, 3);
  assert.equal(info.stats.text_layers, 6);
  const list = ok("list_text", { project, select: { pages: "2" } });
  assert.equal(list.total, 3);
  assert.equal(list.layers[0].page, 2);
});

test("set_font_size changes every layer and the dry run writes nothing", () => {
  const project = tempProject();
  const before = fs.readFileSync(path.join(project, "state-a.khr"));
  const dry = ok("set_font_size", { project, size: 40, dry_run: true });
  assert.equal(dry.changed_layers, 6);
  assert.ok(fs.readFileSync(path.join(project, "state-a.khr")).equals(before));
  assert.ok(!fs.existsSync(path.join(project, "state-b.khr.bak")));

  const real = ok("set_font_size", { project, size: 40 });
  assert.equal(real.saved.revision, 3);
  const stats = ok("text_stats", { project });
  assert.deepEqual(stats.sizes, { 40: 6 });
  assert.equal(stats.auto_fit_layers, 0);
  assert.equal(ok("check_project", { project }).ok, true);

  // Re-applying is a no-op and does not bump the revision.
  const again = ok("set_font_size", { project, size: 40 });
  assert.equal(again.changed_layers, 0);
  assert.equal(again.saved, undefined);
});

test("selectors narrow the edit", () => {
  const project = tempProject();
  ok("set_font_size", { project, size: 18, select: { pages: "1", order: "1" } });
  const stats = ok("text_stats", { project });
  assert.equal(stats.sizes["18"], 1);
  const hits = ok("list_text", { project, select: { text_contains: "hello 1-2" } });
  assert.equal(hits.total, 1);
  assert.throws(() => {
    const out = callTool("list_text", { project, select: { pages: "9" } });
    if (!out.ok) throw new Error(out.error);
  }, /out of range/);
});

test("move_text gives region-bound layers a manual frame and keeps them on the page", () => {
  const project = tempProject();
  const target = ok("list_text", { project, select: { pages: "1", order: "1" } }).layers[0];
  assert.equal(target.frame_from, "fits-to");
  const moved = ok("move_text", { project, dx: -500, dy: 100, select: { layers: [target.id] } });
  assert.equal(moved.changed_layers, 1);
  const after = ok("get_text_layer", { project, layer: target.id });
  assert.equal(after.frame_from, "own");
  assert.equal(after.bounds[0], 0); // clamped at the page edge
  assert.equal(after.bounds[1], 120);

  const reset = ok("reset_frame", { project, select: { layers: [target.id] } });
  assert.equal(reset.changed_layers, 1);
  assert.equal(ok("get_text_layer", { project, layer: target.id }).frame_from, "fits-to");
});

test("typography on a layer that had none is created validly", () => {
  const project = tempProject();
  const bare = ok("list_text", { project, select: { pages: "1", order: "1" } }).layers[0];
  assert.equal(bare.font, null);
  ok("set_typography", { project, color: "#ff8800", alignment: "center", select: { layers: [bare.id] } });
  const after = ok("get_text_layer", { project, layer: bare.id });
  assert.equal(after.color, "#ff8800");
  assert.equal(after.auto_fit, true);
  const bad = callTool("set_typography", { project, auto_fit: false, select: { layers: [bare.id] } });
  assert.ok(bad.ok);
  assert.equal(bad.result.changed_layers, 0);
  assert.equal(bad.result.skipped.length, 1);
});

test("text edits: replace, transform and removal", () => {
  const project = tempProject();
  const replaced = ok("replace_text", { project, find: "hello", replace: "Howdy" });
  assert.equal(replaced.changed_layers, 6);
  ok("transform_text", { project, mode: "uppercase", select: { pages: "1" } });
  const texts = ok("list_text", { project, select: { pages: "1" } }).layers.map((l) => l.translation);
  assert.deepEqual(texts, ["HOWDY 0-0", "HOWDY 0-1", "HOWDY 0-2"]);
  const first = ok("list_text", { project, select: { pages: "1", order: "1" } }).layers[0];
  ok("set_text", { project, edits: [{ layer: first.id, translation: null }] });
  assert.equal(ok("get_text_layer", { project, layer: first.id }).translation, null);
});

test("batch applies several steps as one revision and undo reverts it", () => {
  const project = tempProject();
  const out = ok("batch", {
    project,
    steps: [
      { tool: "set_font_size", args: { size: 30 } },
      { tool: "scale_font_size", args: { factor: 2, select: { pages: "2" } } },
      { tool: "set_visibility", args: { opacity: 0.5 } },
    ],
  });
  assert.equal(out.saved.revision, 3);
  const stats = ok("text_stats", { project });
  assert.deepEqual(stats.sizes, { 30: 3, 60: 3 });
  const undone = ok("undo", { project });
  assert.equal(undone.revision, 4);
  const restored = decodeStateFile(fs.readFileSync(path.join(project, newestSlot(project))));
  assert.equal(restored.revision, 4n);
  assert.deepEqual(ok("text_stats", { project }).sizes, { 25: 2, 26: 2, unset: 2 });
});

function newestSlot(project) {
  const a = decodeStateFile(fs.readFileSync(path.join(project, "state-a.khr")));
  const b = decodeStateFile(fs.readFileSync(path.join(project, "state-b.khr")));
  return a.revision > b.revision ? "state-a.khr" : "state-b.khr";
}

test("bad input fails loudly and leaves the project untouched", () => {
  const project = tempProject();
  const before = fs.readFileSync(path.join(project, "state-a.khr"));
  assert.equal(callTool("set_typography", { project, color: "banana" }).ok, false);
  assert.equal(callTool("set_font_size", { project, size: -3 }).ok, false);
  assert.equal(callTool("nope", {}).ok, false);
  assert.equal(callTool("set_font_size", { project: "/definitely/missing", size: 3 }).ok, false);
  assert.ok(fs.readFileSync(path.join(project, "state-a.khr")).equals(before));
});

test("MCP server speaks JSON-RPC over stdio", async () => {
  const project = tempProject();
  const child = spawn(process.execPath, [path.join(here, "..", "src", "cli.js"), "serve"], { stdio: ["pipe", "pipe", "ignore"] });
  const replies = new Map();
  let buffer = "";
  child.stdout.on("data", (chunk) => {
    buffer += chunk;
    let i;
    while ((i = buffer.indexOf("\n")) >= 0) {
      const message = JSON.parse(buffer.slice(0, i));
      buffer = buffer.slice(i + 1);
      replies.set(message.id, message);
    }
  });
  const send = (message) => child.stdin.write(`${JSON.stringify(message)}\n`);
  const wait = async (id) => {
    for (let n = 0; n < 200 && !replies.has(id); n++) await new Promise((r) => setTimeout(r, 25));
    assert.ok(replies.has(id), `no reply for ${id}`);
    return replies.get(id);
  };
  send({ jsonrpc: "2.0", id: 1, method: "initialize", params: { protocolVersion: "2025-06-18", capabilities: {} } });
  const init = await wait(1);
  assert.equal(init.result.serverInfo.name, "nekoharu-mcp");
  send({ jsonrpc: "2.0", method: "notifications/initialized" });
  send({ jsonrpc: "2.0", id: 2, method: "tools/list" });
  const list = await wait(2);
  assert.ok(list.result.tools.some((t) => t.name === "set_font_size"));
  assert.ok(list.result.tools.every((t) => t.inputSchema.type === "object"));
  send({ jsonrpc: "2.0", id: 3, method: "tools/call", params: { name: "set_font_size", arguments: { project, size: 40 } } });
  const call = await wait(3);
  assert.equal(call.result.isError, false);
  assert.equal(JSON.parse(call.result.content[0].text).changed_layers, 6);
  child.kill();
});

test("typography revision 5 (style spans) round-trips and revision 4 payloads still decode", async () => {
  const { KIND, encodeComponent, decodeComponent } = await import("../src/codec.js");
  const { baseTypography, remapSpans } = await import("../src/ops.js");
  const t = baseTypography();
  t.spans = [{ start: 1, end: 3, preferred_font: "X", font_weight: 700, font_style: "italic", color: [1, 2, 3, 255], stroke_color: null, stroke_width: 1.5 }];
  const entry = encodeComponent(KIND.TYPOGRAPHY, t);
  assert.equal(entry.schema, 5);
  const back = decodeComponent(entry);
  assert.deepEqual(back.spans, t.spans);
  // A revision 4 payload (no trailing span list) must still decode, with empty spans.
  const v4 = Buffer.from(entry.payload.subarray(0, entry.payload.length - (entry.payload.length - encodeComponent(KIND.TYPOGRAPHY, baseTypography()).payload.length + 1)));
  v4[0] = 4;
  assert.deepEqual(decodeComponent({ key: KIND.TYPOGRAPHY, schema: 4, payload: v4 }).spans, []);
  // Spans follow translation edits.
  const sp = [{ ...t.spans[0], start: 6, end: 11 }];
  const out = remapSpans(sp, "hello world", "hi big world");
  assert.deepEqual([out[0].start, out[0].end], [7, 12]);
});

test("editing typography/text does not turn a pipeline-inferred writing_mode into a user override", async () => {
  const { baseTypography, setTypography, scaleFontSize, copyTypography } = await import("../src/ops.js");
  const generated = () => ({ ...baseTypography(), origin: { kind: "generated", producer: "detector", model: null, confidence: null }, writing_mode: "vertical", size: 20, auto_fit: false });
  const mkLayer = (id, typography) => ({
    id,
    page: { number: 1, index: 0, width: 100, height: 100 },
    entity: { components: [] },
    contentEntity: null,
    typography,
  });
  const model = { touchedPages: new Set(), layers: [] };

  // Unrelated property edit: the inferred "vertical" must be dropped, not authored.
  const a = mkLayer("aaaaaa", generated());
  setTypography(model, [a], { color: "#112233" });
  assert.equal(a.typography.origin.kind, "user");
  assert.equal(a.typography.writing_mode, null);

  // Size scaling goes through the same path.
  const b = mkLayer("bbbbbb", generated());
  scaleFontSize(model, [b], { factor: 2 });
  assert.equal(b.typography.writing_mode, null);

  // Explicitly requested writing modes are still honoured.
  const c = mkLayer("cccccc", generated());
  setTypography(model, [c], { writing_mode: "vertical" });
  assert.equal(c.typography.writing_mode, "vertical");
  const d = mkLayer("dddddd", generated());
  setTypography(model, [d], { writing_mode: "horizontal" });
  assert.equal(d.typography.writing_mode, "horizontal");

  // User-authored modes are preserved across unrelated edits.
  const e = mkLayer("eeeeee", { ...generated(), origin: { kind: "user" } });
  setTypography(model, [e], { color: "#112233" });
  assert.equal(e.typography.writing_mode, "vertical");

  // Copying from a generated source doesn't leak its inferred mode.
  model.layers = [mkLayer("ffffff", generated())];
  const g = mkLayer("gggggg", null);
  copyTypography(model, [g], "ffffff");
  assert.equal(g.typography.writing_mode, null);
});

test("fit_text_in_page moves only out-of-bounds frames, by the smallest offset", async () => {
  const { fitTextInPage } = await import("../src/ops.js");
  const box = (x, y, w, h) => [{ x, y }, { x: x + w, y }, { x: x + w, y: y + h }, { x, y: y + h }];
  const mk = (id, frame) => ({
    id,
    page: { number: 1, index: 0, width: 1000, height: 1400 },
    entity: { components: [] },
    contentEntity: null,
    frame,
    frameFrom: "own",
  });
  const model = { touchedPages: new Set() };
  const left = mk("left", box(-50, 100, 200, 100)); // a quarter off the left edge
  const inside = mk("inside", box(100, 100, 200, 100));
  const corner = mk("corner", box(900, 1350, 200, 100)); // off right and bottom
  const huge = mk("huge", box(-100, 0, 1200, 100)); // wider than the page
  const { changes, skipped } = fitTextInPage(model, [left, inside, corner, huge]);
  assert.equal(left.frame[0].x, 0);
  assert.equal(left.frame[0].y, 100);
  assert.deepEqual(inside.frame, box(100, 100, 200, 100));
  assert.equal(corner.frame[1].x, 1000);
  assert.equal(corner.frame[2].y, 1400);
  assert.equal(huge.frame[0].x, -100); // centered: (1000-1200)/2 = -100
  assert.deepEqual(changes.map((c) => c.layer).sort(), ["corner", "left"]);
  assert.equal(skipped.length, 1);
  assert.equal(skipped[0].layer, "huge");

  const m = mk("margin", box(-5, 10, 100, 50));
  fitTextInPage(model, [m], { margin: 20 });
  assert.equal(m.frame[0].x, 20);
  assert.equal(m.frame[0].y, 20);
});

test("fit_text_in_page accounts for fixed-size text that overflows its frame vertically", async () => {
  const { fitTextInPage, baseTypography } = await import("../src/ops.js");
  const box = (x, y, w, h) => [{ x, y }, { x: x + w, y }, { x: x + w, y: y + h }, { x, y: y + h }];
  const mk = (id, frame, typography, text) => ({
    id,
    page: { number: 1, index: 0, width: 600, height: 900 },
    entity: { components: [] },
    contentEntity: null,
    frame,
    frameFrom: "own",
    typography,
    translation: { text },
    source: null,
  });
  const model = { touchedPages: new Set() };
  const text = "LOOKS SO HAPPY, SURROUNDED BY ALL THOSE SLIMY FEMALES";
  const fixed = { ...baseTypography(), auto_fit: false, size: 48 };
  // Frame is inside the page, but the text is far taller than it and spills over the top.
  const a = mk("aaaaaa", box(100, 20, 250, 150), fixed, text);
  const { changes } = fitTextInPage(model, [a]);
  assert.equal(changes.length, 1);
  assert.ok(a.frame[0].y > 20, "frame moved down");
  // Auto-fit text that fits its frame (the renderer shrinks it to <= 24px here) is left alone.
  const b = mk("bbbbbb", box(100, 20, 250, 150), { ...baseTypography(), auto_fit: true, size: 48 }, text);
  assert.equal(fitTextInPage(model, [b]).changes.length, 0);
  // Opting out restores frame-only behaviour.
  const c = mk("cccccc", box(100, 20, 250, 150), fixed, text);
  assert.equal(fitTextInPage(model, [c], { check_text_overflow: false }).changes.length, 0);
  // Text taller than the whole page is centred and reported.
  const d = mk("dddddd", box(100, 300, 250, 150), { ...fixed, size: 200 }, text);
  const out = fitTextInPage(model, [d]);
  assert.equal(out.skipped.length, 1);
});

// ------------------------------------------------------------------ text overlaps

const boxPts = (x, y, w, h) => [{ x, y }, { x: x + w, y }, { x: x + w, y: y + h }, { x, y: y + h }];
const mkOverlapModel = (specs, page = { number: 1, index: 0, width: 1000, height: 1400 }) => {
  const layers = specs.map(([id, order, frame, text, extra = {}]) => ({
    id,
    page,
    order,
    entity: { components: [] },
    contentEntity: null,
    frame,
    frameFrom: "own",
    typography: null,
    translation: { text },
    source: { text: `src ${text}` },
    ...extra,
  }));
  return { model: { touchedPages: new Set(), layers }, layers };
};
const boundsNow = (l) => [Math.min(...l.frame.map((p) => p.x)), Math.min(...l.frame.map((p) => p.y))];

test("find_text_overlaps reports colliding pairs with both texts and push costs", async () => {
  const { findOverlaps } = await import("../src/ops.js");
  const { model, layers } = mkOverlapModel([
    ["aaaaaa", 1, boxPts(100, 100, 200, 100), "Hello there"],
    ["bbbbbb", 2, boxPts(250, 120, 200, 100), "General Kenobi"], // overlaps a by 50 x 80
    ["cccccc", 3, boxPts(700, 700, 100, 100), "far away"],
  ]);
  const out = findOverlaps(model, layers);
  assert.equal(out.pairs_total, 1);
  const [pair] = out.pairs;
  assert.equal(pair.first.id, "aaaaaa");
  assert.equal(pair.second.id, "bbbbbb");
  assert.equal(pair.first.text, "Hello there");
  assert.equal(pair.second.text, "General Kenobi");
  assert.deepEqual(pair.overlap, { width: 50, height: 80 });
  assert.equal(pair.if_push_second.direction, "right");
  assert.equal(pair.if_push_second.distance, 50);

  // Touching boxes are not an overlap, but are "too close" once a margin is requested.
  const touching = mkOverlapModel([
    ["aaaaaa", 1, boxPts(0, 0, 100, 100), "a"],
    ["bbbbbb", 2, boxPts(100, 0, 100, 100), "b"],
  ]);
  assert.equal(findOverlaps(touching.model, touching.layers).pairs_total, 0);
  const close = findOverlaps(touching.model, touching.layers, { margin: 10 });
  assert.equal(close.pairs_total, 1);
  assert.equal(close.pairs[0].overlap.too_close_only, true);
});

test("resolve_text_overlaps pushes the later layer by default, and only as far as needed", async () => {
  const { resolveTextOverlaps, findOverlaps } = await import("../src/ops.js");
  const { model, layers } = mkOverlapModel([
    ["aaaaaa", 1, boxPts(100, 100, 200, 100), "one"],
    ["bbbbbb", 2, boxPts(250, 120, 200, 100), "two"],
  ]);
  const out = resolveTextOverlaps(model, layers, {});
  assert.deepEqual(boundsNow(layers[0]), [100, 100], "first stays");
  assert.deepEqual(boundsNow(layers[1]), [300, 120], "second moves right by 50");
  assert.equal(out.changes.length, 1);
  assert.equal(out.changes[0].layer, "bbbbbb");
  assert.equal(out.extra.overlapping_pairs_before, 1);
  assert.equal(out.extra.overlapping_pairs_after, 0);
  assert.equal(findOverlaps(model, layers).pairs_total, 0);
});

test("resolve_text_overlaps follows the agent's per-pair decision", async () => {
  const { resolveTextOverlaps } = await import("../src/ops.js");
  const make = () =>
    mkOverlapModel([
      ["aaaaaa", 1, boxPts(100, 100, 200, 100), "one"],
      ["bbbbbb", 2, boxPts(250, 120, 200, 100), "two"],
    ]);

  // Push text 1 instead of text 2: it moves away from text 2 (left), text 2 stays.
  let { model, layers } = make();
  resolveTextOverlaps(model, layers, { resolutions: [{ layers: ["aaaaaa", "bbbbbb"], push: "aaaaaa" }] });
  assert.deepEqual(boundsNow(layers[1]), [250, 120]);
  assert.equal(layers[0].frame[1].x, 250, "first's right edge now meets second's left edge");

  // Force a vertical push of the second layer (down, clear of the first's bottom edge at 200).
  ({ model, layers } = make());
  resolveTextOverlaps(model, layers, { resolutions: [{ layers: ["aaaaaa", "bbbbbb"], push: "second", axis: "vertical" }] });
  assert.deepEqual(boundsNow(layers[1]), [250, 200]);

  // "both" splits the push between the two layers.
  ({ model, layers } = make());
  resolveTextOverlaps(model, layers, { resolutions: [{ layers: ["aaaaaa", "bbbbbb"], push: "both", axis: "horizontal" }] });
  assert.deepEqual(boundsNow(layers[0]), [75, 100]);
  assert.deepEqual(boundsNow(layers[1]), [275, 120]);

  // resolve_remaining:false leaves undecided pairs alone and reports them.
  ({ model, layers } = make());
  const out = resolveTextOverlaps(model, layers, { resolve_remaining: false });
  assert.equal(out.changes.length, 0);
  assert.equal(out.extra.unresolved.length, 1);
  assert.deepEqual(out.extra.unresolved[0].texts, ["one", "two"]);

  // Bad decisions fail loudly.
  ({ model, layers } = make());
  assert.throws(() => resolveTextOverlaps(model, layers, { resolutions: [{ layers: ["aaaaaa", "bbbbbb"], push: "cccccc" }] }), /No text layer/);
  assert.throws(() => resolveTextOverlaps(model, layers, { resolutions: [{ layers: ["aaaaaa"], push: "aaaaaa" }] }), /\[idA, idB\]/);
});

test("resolve_text_overlaps stays on the page, avoids new collisions and honours priority and selection", async () => {
  const { resolveTextOverlaps, findOverlaps } = await import("../src/ops.js");

  // Near the right page edge, the push goes another way instead of off the page.
  let { model, layers } = mkOverlapModel([
    ["aaaaaa", 1, boxPts(750, 100, 200, 100), "one"],
    ["bbbbbb", 2, boxPts(800, 120, 200, 100), "two"],
  ]);
  resolveTextOverlaps(model, layers, {});
  assert.ok(Math.max(...layers[1].frame.map((p) => p.x)) <= 1000, "still inside the page");
  assert.equal(findOverlaps(model, layers).pairs_total, 0);

  // A neighbour on the preferred side is avoided: B would go right (50px) but C is there, so it goes down.
  ({ model, layers } = mkOverlapModel([
    ["aaaaaa", 1, boxPts(100, 100, 200, 100), "one"],
    ["bbbbbb", 2, boxPts(250, 120, 200, 100), "two"],
    ["cccccc", 3, boxPts(300, 100, 200, 100), "three"],
  ]));
  // c overlaps b as well; the sweep must end with nothing colliding.
  resolveTextOverlaps(model, layers, {});
  assert.equal(findOverlaps(model, layers).pairs_total, 0);

  // priority: make the later layer the one that stays.
  ({ model, layers } = mkOverlapModel([
    ["aaaaaa", 1, boxPts(100, 100, 200, 100), "one"],
    ["bbbbbb", 2, boxPts(250, 120, 200, 100), "two"],
  ]));
  resolveTextOverlaps(model, layers, { priority: ["bbbbbb"] });
  assert.deepEqual(boundsNow(layers[1]), [250, 120], "prioritised layer stays");
  assert.notDeepEqual(boundsNow(layers[0]), [100, 100], "the other one gave way");

  // Layers outside the selection never move; they are fixed obstacles for the selected one.
  ({ model, layers } = mkOverlapModel([
    ["aaaaaa", 1, boxPts(100, 100, 200, 100), "one"],
    ["bbbbbb", 2, boxPts(250, 120, 200, 100), "two"],
  ]));
  const out = resolveTextOverlaps(model, [layers[0]], {}); // only the FIRST layer may move
  assert.deepEqual(boundsNow(layers[1]), [250, 120]);
  assert.equal(out.changes.length, 1);
  assert.equal(out.changes[0].layer, "aaaaaa");

  // margin leaves a clear gap.
  ({ model, layers } = mkOverlapModel([
    ["aaaaaa", 1, boxPts(100, 100, 200, 100), "one"],
    ["bbbbbb", 2, boxPts(250, 120, 200, 100), "two"],
  ]));
  resolveTextOverlaps(model, layers, { margin: 10 });
  assert.deepEqual(boundsNow(layers[1]), [310, 120]);

  // Hidden layers are ignored unless asked for.
  ({ model, layers } = mkOverlapModel([
    ["aaaaaa", 1, boxPts(100, 100, 200, 100), "one"],
    ["bbbbbb", 2, boxPts(250, 120, 200, 100), "two", { visibility: { visible: false, opacity: 1 } }],
  ]));
  assert.equal(resolveTextOverlaps(model, layers, {}).changes.length, 0);
});

test("overlap tools are registered and usable inside batch", async () => {
  const { TOOLS } = await import("../src/tools.js");
  const names = TOOLS.map((t) => t.name);
  assert.ok(names.includes("find_text_overlaps"));
  assert.ok(names.includes("resolve_text_overlaps"));
  const batch = TOOLS.find((t) => t.name === "batch");
  assert.ok(batch.inputSchema.properties.steps.items.properties.tool.enum.includes("resolve_text_overlaps"));
  assert.equal(TOOLS.find((t) => t.name === "find_text_overlaps").annotations.readOnlyHint, true);
});

test("resolve_text_overlaps handles three or more colliding texts", async () => {
  const { resolveTextOverlaps, findOverlaps } = await import("../src/ops.js");
  const cases = {
    chain: [[100, 100, 200, 100], [250, 100, 200, 100], [400, 100, 200, 100]],
    stack: Array(5).fill([300, 300, 200, 100]),
    grid: [[100, 100, 200, 100], [250, 100, 200, 100], [100, 150, 200, 100], [250, 150, 200, 100]],
    corner: [[850, 1300, 150, 100], [900, 1320, 100, 80], [880, 1290, 120, 100]],
  };
  for (const [name, specs] of Object.entries(cases)) {
    const { model, layers } = mkOverlapModel(specs.map((s, i) => [`layer${String(i).padStart(3, "0")}`, i + 1, boxPts(...s), `t${i}`]));
    const out = resolveTextOverlaps(model, layers, { margin: 4 });
    assert.equal(out.extra.overlapping_pairs_after, 0, name);
    assert.equal(findOverlaps(model, layers, { margin: 4 }).pairs_total, 0, name);
    for (const l of layers) {
      const xs = l.frame.map((p) => p.x), ys = l.frame.map((p) => p.y);
      assert.ok(Math.min(...xs) >= 0 && Math.max(...xs) <= 1000 && Math.min(...ys) >= 0 && Math.max(...ys) <= 1400, `${name}: on page`);
    }
    assert.deepEqual(boundsNow(layers[0]), [specs[0][0], specs[0][1]], `${name}: first in reading order stays`);
  }
});


// ------------------------------------------------- fit_text_in_page: text really on the page

const fitBox = (x, y, w, h) => [{ x, y }, { x: x + w, y }, { x: x + w, y: y + h }, { x, y: y + h }];
const fitLayer = (id, frame, typography, text, extra = {}) => ({
  id,
  page: { number: 1, index: 0, width: 600, height: 900 },
  entity: { components: [] },
  contentEntity: null,
  frame,
  frameFrom: "own",
  typography,
  layout: { kind: "paragraph", angle_degrees: null },
  translation: { text },
  source: null,
  ...extra,
});
const onPage = (box, w = 600, h = 900) => box[0] >= -0.01 && box[1] >= -0.01 && box[2] <= w + 0.01 && box[3] <= h + 0.01;
const LONG = "LOOKS SO HAPPY, SURROUNDED BY ALL THOSE SLIMY FEMALES";

test("fit_text_in_page leaves the TOP of oversized fixed-size text visible, and verifies it", async () => {
  const { fitTextInPage, baseTypography } = await import("../src/ops.js");
  const { measureText } = await import("../src/textlayout.js");
  const model = { touchedPages: new Set() };
  const typo = { ...baseTypography(), auto_fit: false, size: 48 };
  const a = fitLayer("aaaaaa", fitBox(100, 20, 250, 150), typo, LONG);
  assert.ok(measureText(a).textBox[1] < 0, "the text really is cut off at the top before");
  const { changes } = fitTextInPage(model, [a]);
  assert.equal(changes.length, 1);
  assert.ok(onPage(measureText(a).textBox), "rendered text is fully on the page afterwards");
  assert.equal(changes[0].text.visible_after, true);
  assert.ok(changes[0].text.lines >= 6);
});

test("fit_text_in_page also handles AUTO-FIT text that cannot shrink enough (9px floor)", async () => {
  const { fitTextInPage, baseTypography } = await import("../src/ops.js");
  const { measureText } = await import("../src/textlayout.js");
  const model = { touchedPages: new Set() };
  const long = "I never expected the shopkeeper to hand over the ancient map without asking for anything in return, not even a name.";
  const a = fitLayer("aaaaaa", fitBox(100, 3, 70, 36), { ...baseTypography(), auto_fit: true }, long);
  const before = measureText(a);
  assert.equal(before.size, 9, "auto-fit bottoms out at the renderer's minimum size");
  assert.ok(before.overflow && before.textBox[1] < 0);
  fitTextInPage(model, [a]);
  assert.ok(onPage(measureText(a).textBox));
  // Text that fits after auto-fit stays where it is.
  const b = fitLayer("bbbbbb", fitBox(100, 3, 250, 150), { ...baseTypography(), auto_fit: true }, "Hello!");
  assert.equal(fitTextInPage(model, [b]).changes.length, 0);
});

test("fit_text_in_page uses the rotated frame axes, and anchors point text to its corner", async () => {
  const { fitTextInPage, baseTypography } = await import("../src/ops.js");
  const { measureText, frameGeometry } = await import("../src/textlayout.js");
  const model = { touchedPages: new Set() };
  const typo = { ...baseTypography(), auto_fit: false, size: 40 };
  // 90 degrees: the text axes are swapped, so a tall box is a wide text line area.
  const rotated = fitLayer("rotate", fitBox(250, 30, 60, 300), typo, LONG, { layout: { kind: "paragraph", angle_degrees: 90 } });
  const f = frameGeometry(rotated.frame, 90);
  assert.ok(Math.abs(f.width - 300) < 1e-6 && Math.abs(f.height - 60) < 1e-6);
  fitTextInPage(model, [rotated]);
  assert.ok(onPage(measureText(rotated).textBox), "rotated text ends up on the page");
  // Point text starts at the frame's top-left corner and runs right/down (no centring, no wrapping).
  const point = fitLayer("pointpoint", fitBox(500, -20, 40, 20), { ...baseTypography(), auto_fit: false, size: 30 }, "A long sentence of point text", {
    layout: { kind: "point", angle_degrees: null },
  });
  const m = measureText(point);
  assert.equal(m.mode, "point");
  assert.equal(m.lines, 1);
  assert.ok(m.textBox[2] > 600, "point text runs past the right edge");
  fitTextInPage(model, [point]);
  assert.ok(onPage(measureText(point).textBox));
});

test("fit_text_in_page ignores layers that render nothing and respects margin / include_frame", async () => {
  const { fitTextInPage, baseTypography } = await import("../src/ops.js");
  const { measureText } = await import("../src/textlayout.js");
  const model = { touchedPages: new Set() };
  const typo = { ...baseTypography(), auto_fit: false, size: 60 };
  // A blank translation draws nothing even though the source text is long.
  const blank = fitLayer("blankk", fitBox(100, 5, 80, 40), typo, "   ", { source: { text: LONG } });
  assert.equal(measureText(blank), null);
  assert.equal(fitTextInPage(model, [blank]).changes.length, 0);
  // margin applies to the text too.
  const c = fitLayer("cccccc", fitBox(100, 300, 250, 150), { ...baseTypography(), auto_fit: false, size: 20 }, "Hi");
  fitTextInPage(model, [c], { margin: 0 });
  assert.equal(c.frame[0].y, 300, "already inside: untouched");
  // A frame taller than the page: the text alone is kept visible.
  const tall = fitLayer("tallll", fitBox(100, -200, 120, 1400), { ...baseTypography(), auto_fit: false, size: 24 }, "Short");
  const out = fitTextInPage(model, [tall]);
  assert.ok(onPage(measureText(tall).textBox), "text visible although the frame cannot fit");
  assert.equal(out.skipped.length, 0);
});

test("find_offscreen_text reports how far text sticks out, and stays silent for fine layers", async () => {
  const { findOffscreenText, baseTypography } = await import("../src/ops.js");
  const model = { touchedPages: new Set() };
  const a = fitLayer("aaaaaa", fitBox(100, 20, 250, 150), { ...baseTypography(), auto_fit: false, size: 48 }, LONG);
  const b = fitLayer("bbbbbb", fitBox(100, 300, 250, 150), { ...baseTypography(), auto_fit: true }, "Fine");
  const out = findOffscreenText(model, [a, b]);
  assert.equal(out.total, 1);
  assert.equal(out.layers[0].layer, "aaaaaa");
  assert.ok(out.layers[0].beyond_page_px.top > 50);
  assert.ok(out.layers[0].text_beyond_page_px.top > 50);
  assert.equal(out.layers[0].fixable_by_moving, true);
});

test("a real TrueType font is read for exact advances and ink bounds", async (t) => {
  const file = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf";
  if (!fs.existsSync(file)) return t.skip("DejaVu Sans not installed");
  const { loadFontFile } = await import("../src/fontfile.js");
  const face = loadFontFile(file);
  assert.ok(Math.abs(face.measure("A").adv - 1401 / 2048) < 1e-6);
  assert.equal(face.measure(" ").ink, null);
  assert.ok(face.measure("g").ink.ymin < -0.15, "descender goes below the baseline");
});

test("end to end: fit_text_in_page on a saved project keeps the top line visible, and undo restores it", async () => {
  const { makeProject } = await import("./helpers/make-project.js");
  const { measureText } = await import("../src/textlayout.js");
  const { loadModel } = await import("../src/model.js");
  const { openProject } = await import("../src/store.js");
  const pts = (x, y, w, h) => [{ x, y }, { x: x + w, y }, { x: x + w, y: y + h }, { x, y: y + h }];
  const { dir, ids } = makeProject({
    layers: [
      { text: LONG, points: pts(100, 20, 250, 150), typography: { auto_fit: false, size: 48 } },
      { text: "I never expected the shopkeeper to hand over the ancient map without asking for anything in return, not even a name.", points: pts(100, 3, 70, 36), typography: { auto_fit: true } },
      { text: "Point text runs right and down", points: pts(500, 10, 40, 20), typography: { auto_fit: false, size: 30 }, layout: { kind: "point" } },
      { text: "Fine", points: pts(100, 300, 200, 100), typography: { auto_fit: true } },
    ],
  });
  const worst = (project) => {
    const model = loadModel(openProject(project));
    return model.layers.map((l) => {
      const b = measureText(l).textBox;
      return Math.max(0, -b[0], -b[1], b[2] - 600, b[3] - 900);
    });
  };
  assert.ok(worst(dir).slice(0, 3).every((v) => v > 1), "all three problem layers are cut off before");

  const report = ok("find_offscreen_text", { project: dir });
  assert.equal(report.total, 3);

  const dry = ok("fit_text_in_page", { project: dir, dry_run: true });
  assert.equal(dry.changed_layers, 3);
  assert.ok(worst(dir).slice(0, 3).every((v) => v > 1), "dry run writes nothing");

  const real = ok("fit_text_in_page", { project: dir });
  assert.equal(real.changed_layers, 3);
  assert.ok(real.changes.every((c) => c.text.visible_after === true));
  assert.equal(real.text_check.layers_measured, 4);
  assert.ok(worst(dir).every((v) => v < 0.01), "everything is fully visible after saving and reloading");
  assert.equal(ok("find_offscreen_text", { project: dir }).total, 0);
  assert.equal(ok("fit_text_in_page", { project: dir }).changed_layers, 0, "idempotent");

  ok("undo", { project: dir });
  assert.equal(ok("find_offscreen_text", { project: dir }).total, 3);
  assert.equal(ids.length, 4);
});
