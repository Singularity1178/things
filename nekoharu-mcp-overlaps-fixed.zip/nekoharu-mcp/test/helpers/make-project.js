// Builds a small synthetic .khrproj with the real codec, so tools can be tested end to end
// without Koharu-written fixtures. Layers are described as plain objects.

import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

import { KIND, USER, encodeComponent, encodeScene, encodeStateFile } from "../../src/codec.js";
import { baseTypography } from "../../src/ops.js";

const entry = (kind, value) => encodeComponent(kind, value, undefined);
const bare = (key) => ({ key, schema: 1, payload: Buffer.alloc(0), recordRefs: [], blobRefs: [] });
const sorted = (components) => components.sort((a, b) => Buffer.compare(Buffer.from(a.key), Buffer.from(b.key)));

/**
 * layers: [{ text, points?, typography?, layout?: {kind, angle_degrees} }]
 * Returns the path of the created project folder.
 */
export function makeProject({ width = 600, height = 900, layers }) {
  const id = () => crypto.randomUUID();
  const pageId = id();
  const groupId = id();
  const entities = [
    { id: pageId, parent: null, components: sorted([entry(KIND.PAGE, { label: "p1", width, height, chapter_start: false })]) },
    { id: groupId, parent: pageId, components: [bare(KIND.TEXT_GROUP)] },
  ];
  const relations = [];
  const ids = [];
  for (const layer of layers) {
    const layerId = id();
    const contentId = id();
    ids.push(layerId);
    const components = [
      entry(KIND.TEXT_LAYOUT, { origin: USER, kind: layer.layout?.kind ?? "paragraph", angle_degrees: layer.layout?.angle_degrees ?? null }),
      entry(KIND.TYPOGRAPHY, { ...baseTypography(), ...layer.typography }),
    ];
    if (layer.points) components.push(entry(KIND.GEOMETRY, { origin: USER, points: layer.points }));
    entities.push({ id: layerId, parent: groupId, components: sorted(components) });
    entities.push({
      id: contentId,
      parent: pageId,
      components: sorted([
        entry(KIND.TEXT_SOURCE, { text: "src", origin: USER, language: null }),
        entry(KIND.TEXT_TRANSLATION, { text: layer.text, origin: USER, language: "en" }),
      ]),
    });
    relations.push({ id: id(), origin: USER, kind: KIND.REL_PRESENTS, source: layerId, target: contentId, components: [] });
  }
  const scene = { pageOrderEpoch: 1n, projectComponents: [], pages: [{ id: pageId, epoch: 1n, entities }], relations };
  const dir = path.join(fs.mkdtempSync(path.join(os.tmpdir(), "nekoharu-synth-")), "Synth.khrproj");
  fs.mkdirSync(dir, { recursive: true });
  const file = encodeStateFile({ document: id(), revision: 1n, blobs: [], payload: encodeScene(scene) });
  fs.writeFileSync(path.join(dir, "state-a.khr"), file);
  return { dir, ids };
}
