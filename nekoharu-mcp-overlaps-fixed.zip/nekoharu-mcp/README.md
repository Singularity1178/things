# nekoharu-mcp

**Project-wide edits for Koharu / NeKoharu projects — as an MCP server for AI agents and a CLI for you.**

Change every text size to 40, nudge all the dialogue up 2%, swap a font on pages 3–9, fix a recurring
translation, or hand the whole job to an agent in opencode / Claude / Cursor — without clicking through
hundreds of text boxes.

- **Zero dependencies.** Plain Node.js ≥ 18. Nothing to `npm install`.
- **Reads and writes real `.khrproj` projects directly.** The binary format (`revision` encoding,
  BLAKE3-checksummed alternating state slots) is implemented from the Koharu source, and was verified
  against projects written by Koharu's own `koharu-scene` crate: byte-exact round trips, and Koharu's
  own `Session::open` accepts the edited result.
- **Safe by default.** Every change makes a backup, supports `dry_run`, and can be reverted with `undo`.
  Each save is a new revision published atomically into the inactive state slot, exactly like Koharu does.
- **Agent-friendly.** 27 tools with precise JSON schemas, one-call `batch` edits, and usage instructions
  delivered to the agent during the MCP handshake.

> **Close the project in Koharu first.** Koharu holds the project open and does not reload files changed on
> disk (its next autosave would overwrite your edits). Edit with the project closed, then reopen it.

## Install

1. Unzip anywhere, e.g. `~/tools/nekoharu-mcp`.
2. Make sure `node --version` is 18 or newer.
3. Try it: `node src/cli.js tools`

Optional: `npm link` inside the folder gives you global `nekoharu` and `nekoharu-mcp` commands.

## Use it from the command line

```bash
# What's in the project?
node src/cli.js project-info ~/Documents/Koharu/MyManga.khrproj

# Every text layer to size 40 (preview first)
node src/cli.js set-font-size MyManga --size 40 --dry-run
node src/cli.js set-font-size MyManga --size 40

# Only pages 1-5, only layers currently smaller than 30
node src/cli.js set-font-size MyManga --size 32 --select.pages 1-5 --select.size_max 30

# +15% on all explicit sizes, never below 18
node src/cli.js scale-font-size MyManga --factor 1.15 --min 18

# Move all text up 2% of the page height; center the text on page 7
node src/cli.js move-text MyManga --dy -2 --unit percent
node src/cli.js align-text-to-page MyManga --horizontal center --select.pages 7

# Font, color, alignment, outline in one go
node src/cli.js set-typography MyManga --font "Anime Ace" --color "#111111" --alignment center --stroke_color white --stroke_width 3

# Fix a recurring translation
node src/cli.js replace-text MyManga --find "Mr." --replace "Mister" --whole_word

# Text boxes colliding? See which ones (with their text), then push them apart
node src/cli.js find-text-overlaps MyManga --margin 6
node src/cli.js resolve-text-overlaps MyManga --margin 6 --dry-run
node src/cli.js resolve-text-overlaps MyManga --json '{"resolutions":[{"layers":["a1b2c3d4","e5f6a7b8"],"push":"e5f6a7b8","axis":"vertical"}]}'

# Oops
node src/cli.js undo MyManga
```

`<project>` can be a path to the `.khrproj` folder, or just a project name found in
`~/Documents/Koharu` (override with `KOHARU_PROJECTS_DIR`). Set `KOHARU_PROJECT` to skip typing it.
Flags are tool arguments; nest with dots (`--select.pages 1-3`) or pass `--json '{...}'`.
`node src/cli.js help <tool>` prints a tool's full schema.

## Use it from an AI agent (MCP)

The server speaks MCP over stdio: `node /absolute/path/to/nekoharu-mcp/src/cli.js serve`.

### opencode

Easiest (works on every opencode version):

```bash
opencode mcp add nekoharu -- node /absolute/path/to/nekoharu-mcp/src/cli.js serve
opencode mcp list        # should show: nekoharu connected
```

Or edit `opencode.json` by hand (see [`examples/`](examples)). Current releases use
`mcp.servers.<name>`; older ones use `mcp.<name>` with `"enabled": true`:

```jsonc
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "servers": {
      "nekoharu": {
        "type": "local",
        "command": ["node", "/absolute/path/to/nekoharu-mcp/src/cli.js", "serve"],
        "environment": { "KOHARU_PROJECTS_DIR": "/home/you/Documents/Koharu" }
      }
    }
  }
}
```

Then just talk to it:

> Use nekoharu on the project "MyManga". Show me the text size distribution, then set every text size to
> 40, except the SFX on pages 12–14 which should stay as they are. Preview first.

Copy [`AGENTS.md`](AGENTS.md) into your repo (or opencode rules) to give agents the full playbook.
Other clients: see `examples/claude_desktop_config.json` and `examples/cursor-mcp.json` — same command.

### What agents get

| Group | Tools |
| --- | --- |
| Discover | `list_projects`, `project_info`, `list_text`, `get_text_layer`, `text_stats`, `check_project` |
| Typography | `set_font_size`, `set_typography`, `scale_font_size`, `copy_typography`, `reset_typography` |
| Position | `move_text`, `set_frame`, `align_text_to_page`, `fit_text_in_page`, `find_offscreen_text`, `reset_frame`, `set_text_angle` |
| Overlaps | `find_text_overlaps` (shows which boxes collide and what they say), `resolve_text_overlaps` (pushes them apart) |
| Visibility | `set_visibility` |
| Text | `set_text`, `replace_text`, `transform_text` |
| Safety | `batch` (many edits, one revision), `list_history`, `undo` |

Every editing tool takes the same optional `select` filter (pages, order, text, regex, font, size range, auto-fit,
writing mode, alignment, visibility, translation origin, region) and `dry_run`. With no `select`, **all** text layers
are affected — that is the point.

## Fixing overlapping text

Bigger fonts or a manual move can leave text boxes sitting on top of each other (or too close). Two tools handle it:

- **`find_text_overlaps`** (read-only) lists every colliding pair on the selected pages with **what each layer says**
  (translation and source), reading order, bounds, how much they overlap, and what pushing either one would cost.
  Add `margin` to also flag boxes that are merely too close.
- **`resolve_text_overlaps`** pushes them apart horizontally or vertically by the smallest move that clears them
  (plus `margin`), staying on the page and avoiding new collisions where it can.

The agent stays in control of the order. For each pair it can decide who moves:

```jsonc
{ "resolutions": [
    { "layers": ["<text 1>", "<text 2>"], "push": "<text 2>" },                  // text 2 gives way
    { "layers": ["<text 3>", "<text 4>"], "push": "<text 3>", "axis": "vertical" }, // text 3 moves, only up/down
    { "layers": ["<text 5>", "<text 6>"], "push": "both" }                          // each moves half
] }
```

`push` also accepts `"first"` / `"second"` (reading order), and `direction` forces `left|right|up|down`.
Pairs without a decision are resolved automatically: the layer later in reading order moves (or use `priority`, a list of
layer ids that should stay put). Set `resolve_remaining: false` to touch only the pairs you decided. Layers outside
`select` never move but still count as obstacles; anything that cannot be separated is listed under `unresolved`.
Overlap checks use each frame plus the estimated spill-over of oversized fixed-size text (`check_text_overflow`);
rotation is not modelled.

## Keeping text on the page

`fit_text_in_page` slides a layer by the smallest amount that puts **everything Koharu draws** inside the page, and
`find_offscreen_text` is its read-only twin (it reports how many pixels stick out past each edge).

```bash
node src/cli.js find-offscreen-text MyManga --margin 4
node src/cli.js fit-text-in-page MyManga --margin 4 --dry-run
node src/cli.js fit-text-in-page MyManga --margin 4
```

"Everything" is measured the way NeKoharu's renderer lays text out (`src/textlayout.js` is a port of the relevant parts of
`koharu-renderer`), not by looking at the frame alone:

- text is centred on its frame on **both** axes, so text that is too big spills out equally above and below - the top line
  gets cut off even when the frame itself is on the page;
- the block is the **tight ink box** of the glyphs (real glyph bounds), not `lines x line-height`;
- **auto-fit** text is measured at the size the renderer will pick (largest size in 9-24 px for free text; it can't go
  below 9 px, so a long translation in a small box still spills) - `typography.size` is ignored while auto-fit is on;
- fixed-size text uses its size; layers with no translation draw nothing and are ignored;
- line breaks follow the renderer's optimal-fit search (cubed slack, discretionary hyphens) using the **real font file**;
- rotated frames (`angle_degrees`, or a rotated 4-point frame) are measured in their own axes and rotated about the centre;
- **point text** is anchored to the frame's top-left corner and never wraps;
- the outline (stroke + outer stroke) counts as visible text;
- every move is re-checked against the same measurement (`text.visible_after`).

Fonts are found by `preferred_font` (family, full or PostScript name) in the system font folders, in Koharu's package
cache (`<cache dir>/koharu/packages`, where its bundled fonts are downloaded) and in any folder listed in the
`NEKOHARU_FONT_DIRS` environment variable (path-separated). If a font can't be found (or uses CFF outlines, whose glyph
bounds aren't read) the layer is measured with a slightly generous approximation; the result says so under `text_check`
and per layer (`measured_with`, `confidence`). Speech-balloon text and vertical text are approximations
(`confidence: "low"`).

## Conventions

- Pages are **1-based**. Coordinates are **page pixels**, origin top-left, y grows downward. Bounds are
  `[left, top, right, bottom]`.
- A **font size** is in page pixels. Setting a size turns *auto-fit* off for that layer (fixed size) unless
  you pass `auto_fit`. `scale_font_size` only touches layers that have an explicit size.
- Koharu text layers that follow a detected region have no frame of their own. The first time you move
  or resize one, the tool gives it a manual frame; `reset_frame` hands it back to the detector.
- Edited layers are stamped as **user-authored**, like edits in Koharu's editor, so a later pipeline run
  will not silently overwrite them.
- Colors: `"#rrggbb"`, `"#rrggbbaa"`, a name, or `[r,g,b,a]`.

## How it works (and what it deliberately does not do)

Koharu stores a project as `*.khrproj/` containing `state-a.khr` and `state-b.khr` (alternating complete
snapshots: magic, format version, length, BLAKE3 checksum, then a `revision`-encoded scene) plus
content-addressed `blobs/`. This tool:

1. loads the newest valid slot (same recovery rule as Koharu);
2. decodes the scene and the components it edits (typography, geometry, visibility, layout, source/translation
   text), keeping every other component as opaque bytes so nothing else changes;
3. applies the edit, bumps the touched pages' epochs, re-validates that the scene re-decodes;
4. copies the old state to `.nekoharu-history/`, then writes revision N+1 into the *other* slot atomically.

It does **not** run OCR/translation/inpainting, import or export files, create or delete text layers or
pages, or edit raster layers/blobs — it is for bulk **typesetting and text** edits. It refuses to touch a
component revision newer than it understands rather than risk corrupting a project (update the tool if
Koharu's format moves on). Format knowledge is pinned to NeKoharu `v0.85.3-N`.

## Development

```bash
npm test      # unit + integration tests, uses a project written by Koharu's own Rust crates (test/fixtures)
```

MIT licensed.

## Compatibility

Supports Koharu / NeKoharu projects whose Typography component is revision 1–5. Revision 5 adds per-word
style `spans`; they are preserved on every edit and shifted automatically when a translation is changed
(`set_text`, `replace_text`, `transform_text`). Components are written back at revision 5.
