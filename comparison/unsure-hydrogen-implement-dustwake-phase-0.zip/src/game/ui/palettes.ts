// Colour-blind-safe palettes for overlays (vision mode, alerts, build validity, graphs).
// Pure (no DOM).
import type { Highlight } from "../content/vision";

export type PaletteId = "default" | "deuteranopia" | "protanopia" | "tritanopia" | "highContrast";

export interface UiPalette {
  id: PaletteId;
  label: string;
  vision: Record<Highlight, string>;
  valid: string;
  invalid: string;
  selection: string;
  info: string;
  warn: string;
  alert: string;
  series: [string, string, string, string];
}

export const PALETTES: Record<PaletteId, UiPalette> = {
  default: {
    id: "default",
    label: "Default",
    vision: {
      important: "#ffe070",
      buildable: "#6ef0a8",
      interactable: "#7fe8ff",
      npc: "#c890ff",
    },
    valid: "#7ae08a",
    invalid: "#e07a7a",
    selection: "#7fe8ff",
    info: "#7fe8ff",
    warn: "#f0b050",
    alert: "#e86a6a",
    series: ["#7fe8ff", "#7ae08a", "#f0b050", "#c890ff"],
  },
  // Okabe-Ito inspired colour-blind-safe palettes
  deuteranopia: {
    id: "deuteranopia",
    label: "Deuteranopia-Safe",
    vision: {
      important: "#f0e442",
      buildable: "#56b4e9",
      interactable: "#0072b2",
      npc: "#cc79a7",
    },
    valid: "#56b4e9",
    invalid: "#d55e00",
    selection: "#f0e442",
    info: "#56b4e9",
    warn: "#e69f00",
    alert: "#d55e00",
    series: ["#0072b2", "#e69f00", "#56b4e9", "#cc79a7"],
  },
  protanopia: {
    id: "protanopia",
    label: "Protanopia-Safe",
    vision: {
      important: "#f0e442",
      buildable: "#56b4e9",
      interactable: "#009e73",
      npc: "#cc79a7",
    },
    valid: "#56b4e9",
    invalid: "#e69f00",
    selection: "#f0e442",
    info: "#56b4e9",
    warn: "#f0e442",
    alert: "#d55e00",
    series: ["#56b4e9", "#e69f00", "#009e73", "#cc79a7"],
  },
  tritanopia: {
    id: "tritanopia",
    label: "Tritanopia-Safe",
    vision: {
      important: "#ff88aa",
      buildable: "#00c8c8",
      interactable: "#70e0e0",
      npc: "#ff6644",
    },
    valid: "#00c8c8",
    invalid: "#e85040",
    selection: "#ff88aa",
    info: "#00c8c8",
    warn: "#ffaa80",
    alert: "#e84040",
    series: ["#00c8c8", "#e85040", "#ff88aa", "#80e0e0"],
  },
  highContrast: {
    id: "highContrast",
    label: "High Contrast",
    vision: {
      important: "#ffffff",
      buildable: "#00ffaa",
      interactable: "#00e5ff",
      npc: "#ff80ff",
    },
    valid: "#00ff88",
    invalid: "#ff4444",
    selection: "#ffffff",
    info: "#00e5ff",
    warn: "#ffdd00",
    alert: "#ff4444",
    series: ["#ffffff", "#00e5ff", "#ffdd00", "#ff80ff"],
  },
};

export const PALETTE_ORDER: PaletteId[] = ["default", "deuteranopia", "protanopia", "tritanopia", "highContrast"];
