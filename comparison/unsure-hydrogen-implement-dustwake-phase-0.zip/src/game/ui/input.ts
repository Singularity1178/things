// Input v2 (0.5): unified mouse (hover, click, drag-select, wheel, right-click),
// keyboard (with SettingsStore remapping) and gamepad parity.
import { BASE_W, BASE_H } from "../view/zoom";
import { SettingsStore, type ActionName } from "./settings";

export const UI_SCALE = 2;
export const UI_W = BASE_W * UI_SCALE; // 640
export const UI_H = BASE_H * UI_SCALE; // 360

export interface MouseRect {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
}

export interface MouseState {
  /** Cursor in 2x UI coordinates (0..640, 0..360). */
  x: number;
  y: number;
  /** Cursor in base 1x UI coordinates (0..320, 0..180). */
  bx: number;
  by: number;
  /** True once pointer has moved inside the canvas. */
  inside: boolean;
  /** Buttons currently held. */
  leftDown: boolean;
  rightDown: boolean;
  /** Edge triggers this frame (cleared at end of update). */
  leftClick: boolean;
  rightClick: boolean;
  leftRelease: boolean;
  /** Wheel delta this frame (positive = scroll down / zoom out). */
  wheelY: number;
  /** Drag state in 2x UI coordinates. */
  dragStart: { x: number; y: number } | null;
  dragging: boolean;
  /** Completed drag-select box in 2x UI coordinates on the frame released. */
  draggedBox: MouseRect | null;
}

const DRAG_THRESHOLD_PX = 5;

export class InputManager {
  keys = new Set<string>();
  pressed = new Set<string>();
  typed: string[] = [];

  mouse: MouseState = {
    x: UI_W / 2,
    y: UI_H / 2,
    bx: BASE_W / 2,
    by: BASE_H / 2,
    inside: false,
    leftDown: false,
    rightDown: false,
    leftClick: false,
    rightClick: false,
    leftRelease: false,
    wheelY: 0,
    dragStart: null,
    dragging: false,
    draggedBox: null,
  };

  /** Gamepad axes & previous button state for edge detection. */
  gpAxis = { ix: 0, iy: 0 };
  private gpPrevButtons: boolean[] = [];
  private gpPrevDir = { u: false, d: false, l: false, r: false };
  /** Raw last key pressed this frame (for keybinding capture in Settings). */
  lastRawKey: string | null = null;

  constructor(public settings: SettingsStore) {}

  keyDown(raw: string) {
    const k = raw.toLowerCase();
    this.lastRawKey = k;
    if (!this.keys.has(k)) this.pressed.add(k);
    this.keys.add(k);
    if (raw.length === 1) this.typed.push(raw);
    else if (k === "backspace") this.typed.push("\b");
  }

  keyUp(raw: string) {
    this.keys.delete(raw.toLowerCase());
  }

  pointerMove(uiX: number, uiY: number) {
    this.mouse.x = Math.max(0, Math.min(UI_W, uiX));
    this.mouse.y = Math.max(0, Math.min(UI_H, uiY));
    this.mouse.bx = this.mouse.x / UI_SCALE;
    this.mouse.by = this.mouse.y / UI_SCALE;
    this.mouse.inside = true;
    if (this.mouse.leftDown && this.mouse.dragStart) {
      const dist = Math.hypot(this.mouse.x - this.mouse.dragStart.x, this.mouse.y - this.mouse.dragStart.y);
      if (dist >= DRAG_THRESHOLD_PX) this.mouse.dragging = true;
    }
  }

  pointerDown(uiX: number, uiY: number, button: number) {
    this.pointerMove(uiX, uiY);
    if (button === 0) {
      this.mouse.leftDown = true;
      this.mouse.leftClick = true;
      this.mouse.dragStart = { x: this.mouse.x, y: this.mouse.y };
      this.mouse.dragging = false;
      this.pressed.add("click");
    } else if (button === 2) {
      this.mouse.rightDown = true;
      this.mouse.rightClick = true;
      this.pressed.add("rightclick");
    }
  }

  pointerUp(uiX: number, uiY: number, button: number) {
    this.pointerMove(uiX, uiY);
    if (button === 0) {
      if (this.mouse.dragging && this.mouse.dragStart) {
        this.mouse.draggedBox = {
          x0: Math.min(this.mouse.dragStart.x, this.mouse.x),
          y0: Math.min(this.mouse.dragStart.y, this.mouse.y),
          x1: Math.max(this.mouse.dragStart.x, this.mouse.x),
          y1: Math.max(this.mouse.dragStart.y, this.mouse.y),
        };
      }
      this.mouse.leftDown = false;
      this.mouse.leftRelease = true;
      this.mouse.dragging = false;
      this.mouse.dragStart = null;
    } else if (button === 2) {
      this.mouse.rightDown = false;
    }
  }

  wheel(deltaY: number) {
    this.mouse.wheelY += deltaY;
  }

  /** Poll connected standard gamepad (no-op in headless Node). */
  pollGamepad() {
    this.gpAxis.ix = 0;
    this.gpAxis.iy = 0;
    if (typeof navigator === "undefined" || typeof navigator.getGamepads !== "function") return;
    let pads: (Gamepad | null)[] = [];
    try {
      pads = Array.from(navigator.getGamepads() ?? []);
    } catch {
      return;
    }
    const gp = pads.find((p) => p && p.connected);
    if (!gp) return;

    const dead = 0.28;
    const ax0 = Math.abs(gp.axes[0] ?? 0) > dead ? gp.axes[0] : 0;
    const ax1 = Math.abs(gp.axes[1] ?? 0) > dead ? gp.axes[1] : 0;
    const dLeft = gp.buttons[14]?.pressed || ax0 < -0.5;
    const dRight = gp.buttons[15]?.pressed || ax0 > 0.5;
    const dUp = gp.buttons[12]?.pressed || ax1 < -0.5;
    const dDown = gp.buttons[13]?.pressed || ax1 > 0.5;

    this.gpAxis.ix = ax0 !== 0 ? ax0 : (dRight ? 1 : 0) - (dLeft ? 1 : 0);
    this.gpAxis.iy = ax1 !== 0 ? ax1 : (dDown ? 1 : 0) - (dUp ? 1 : 0);

    // Directional edge triggers for menu navigation
    if (dUp && !this.gpPrevDir.u) this.pressed.add("arrowup");
    if (dDown && !this.gpPrevDir.d) this.pressed.add("arrowdown");
    if (dLeft && !this.gpPrevDir.l) this.pressed.add("arrowleft");
    if (dRight && !this.gpPrevDir.r) this.pressed.add("arrowright");
    this.gpPrevDir = { u: !!dUp, d: !!dDown, l: !!dLeft, r: !!dRight };

    // Standard mapping: A(0)->e, B(1)->escape, X(2)->space, Y(3)->i, LB(4)->q, RB(5)->r, Start(9)->escape
    const map: Record<number, string> = {
      0: "e",
      1: "escape",
      2: " ",
      3: "i",
      4: "q",
      5: "r",
      9: "escape",
    };
    for (const [idxStr, key] of Object.entries(map)) {
      const idx = Number(idxStr);
      const down = !!gp.buttons[idx]?.pressed;
      const prev = !!this.gpPrevButtons[idx];
      if (down && !prev) this.pressed.add(key);
      this.gpPrevButtons[idx] = down;
    }
  }

  /** Clear per-frame edges after screen update. */
  endFrame() {
    this.pressed.clear();
    this.typed.length = 0;
    this.lastRawKey = null;
    this.mouse.leftClick = false;
    this.mouse.rightClick = false;
    this.mouse.leftRelease = false;
    this.mouse.wheelY = 0;
    this.mouse.draggedBox = null;
  }

  has(...k: string[]) {
    return k.some((x) => this.keys.has(x));
  }

  hit(...k: string[]) {
    return k.some((x) => this.pressed.has(x));
  }

  /** Check whether a remapped logical action is currently held. */
  actionDown(act: ActionName): boolean {
    const keys = this.settings.data.keybinds[act];
    return keys.some((k) => this.keys.has(k));
  }

  /** Check whether a remapped logical action was triggered this frame. */
  actionHit(act: ActionName): boolean {
    const keys = this.settings.data.keybinds[act];
    return keys.some((k) => this.pressed.has(k));
  }

  /** Convert 2x UI coordinates to world coordinates given camera and view size. */
  toWorld(uiX: number, uiY: number, cam: { x: number; y: number }, vw: number, vh: number) {
    return {
      x: cam.x + (uiX / UI_W) * vw,
      y: cam.y + (uiY / UI_H) * vh,
    };
  }

  /** Current drag rectangle in 2x UI coordinates (if actively dragging). */
  currentDragRect(): MouseRect | null {
    if (!this.mouse.dragging || !this.mouse.dragStart) return null;
    return {
      x0: Math.min(this.mouse.dragStart.x, this.mouse.x),
      y0: Math.min(this.mouse.dragStart.y, this.mouse.y),
      x1: Math.max(this.mouse.dragStart.x, this.mouse.x),
      y1: Math.max(this.mouse.dragStart.y, this.mouse.y),
    };
  }
}
