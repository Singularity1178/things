// Notification feed (0.5): alerts, warnings, discoveries, and pause-on-alert options.
// Pure state + 2x UI renderer.
import { UI } from "./kit";
import { PALETTES } from "./palettes";
import { SettingsStore } from "./settings";
import { drawButton2x, drawPanel2x, inRect, type HitRegistry } from "./components";
import type { InputManager } from "./input";
import { clipPropText, drawPropText, drawPropTextS } from "./propFont";

export type AlertLevel = "info" | "warn" | "alert";
export type AlertCategory = "workerBlocked" | "noPower" | "storageFull" | "discovery" | "system";

export interface NotificationItem {
  id: number;
  simTime: number;
  day: number;
  level: AlertLevel;
  category: AlertCategory;
  title: string;
  body?: string;
  area?: string;
  x?: number;
  y?: number;
  actorId?: string;
  read: boolean;
  /** Remaining toast visibility time (seconds); item stays in history after toast fades. */
  ttl: number;
}

const MAX_HISTORY = 50;
const TOAST_TTL = 6.5;

export class NotificationFeed {
  items: NotificationItem[] = [];
  drawerOpen = false;
  private seq = 1;

  constructor(private settings: SettingsStore) {}

  clear() {
    this.items = [];
  }

  unreadCount(): number {
    let n = 0;
    for (const it of this.items) if (!it.read) n++;
    return n;
  }

  /**
   * Push a notification. Returns true if settings dictate the simulation should pause
   * on this alert.
   */
  push(opts: {
    simTime: number;
    day: number;
    level: AlertLevel;
    category: AlertCategory;
    title: string;
    body?: string;
    area?: string;
    x?: number;
    y?: number;
    actorId?: string;
  }): boolean {
    const item: NotificationItem = {
      id: this.seq++,
      simTime: opts.simTime,
      day: opts.day,
      level: opts.level,
      category: opts.category,
      title: opts.title,
      body: opts.body,
      area: opts.area,
      x: opts.x,
      y: opts.y,
      actorId: opts.actorId,
      read: false,
      ttl: TOAST_TTL,
    };
    this.items.unshift(item);
    if (this.items.length > MAX_HISTORY) this.items.length = MAX_HISTORY;

    const s = this.settings.data;
    if (opts.level === "alert" && s.pauseOnAlert) return true;
    if (opts.category === "workerBlocked" && s.pauseWorkerBlocked) return true;
    if (opts.category === "noPower" && s.pauseNoPower) return true;
    if (opts.category === "storageFull" && s.pauseStorageFull) return true;
    return false;
  }

  markAllRead() {
    for (const it of this.items) it.read = true;
  }

  dismiss(id: number) {
    this.items = this.items.filter((x) => x.id !== id);
  }

  update(dt: number) {
    for (const it of this.items) {
      if (it.ttl > 0) it.ttl = Math.max(0, it.ttl - dt);
    }
  }

  toggleDrawer() {
    this.drawerOpen = !this.drawerOpen;
    if (this.drawerOpen) this.markAllRead();
  }

  /**
   * Render compact top-left notification badge + active toasts (or expanded history drawer)
   * on the 2x UI canvas.
   */
  draw(
    ctx: CanvasRenderingContext2D,
    input: InputManager,
    hits: HitRegistry,
    onFocus?: (item: NotificationItem) => void,
  ) {
    const pal = PALETTES[this.settings.data.palette];
    const colOf = (lvl: AlertLevel) => (lvl === "alert" ? pal.alert : lvl === "warn" ? pal.warn : pal.info);
    const unread = this.unreadCount();

    // Top-left Alerts toggle button
    const bx = 6, by = 6, bw = 72, bh = 16;
    const hovered = input.mouse.inside && inRect(input.mouse.x, input.mouse.y, { x: bx, y: by, w: bw, h: bh });
    const label = unread > 0 ? `Alerts (${unread})` : `Alerts (${this.items.length})`;
    drawButton2x(ctx, bx, by, bw, bh, label, {
      hovered,
      active: this.drawerOpen,
      color: unread > 0 ? pal.warn : UI.text,
    });
    hits.add("alerts.toggle", { x: bx, y: by, w: bw, h: bh }, {
      tooltip: "Toggle Notification Feed (N)",
      onClick: () => this.toggleDrawer(),
    });

    if (this.drawerOpen) {
      const dx = 6, dy = 26, dw = 236, dh = 190;
      drawPanel2x(ctx, dx, dy, dw, dh, "#121017", "#4e4856", "#6a6372");
      drawPropTextS(ctx, "Notification Feed", dx + 8, dy + 6, UI.title);

      const clrRect = { x: dx + dw - 52, y: dy + 4, w: 46, h: 13 };
      drawButton2x(ctx, clrRect.x, clrRect.y, clrRect.w, clrRect.h, "Clear", {
        hovered: input.mouse.inside && inRect(input.mouse.x, input.mouse.y, clrRect),
      });
      hits.add("alerts.clear", clrRect, {
        tooltip: "Clear all notifications",
        onClick: () => this.clear(),
      });

      const shown = this.items.slice(0, 8);
      if (!shown.length) {
        drawPropText(ctx, "No notifications yet.", dx + 10, dy + 28, UI.dim);
      } else {
        shown.forEach((it, idx) => {
          const ry = dy + 22 + idx * 20;
          const rowRect = { x: dx + 5, y: ry, w: dw - 10, h: 18 };
          const hov = input.mouse.inside && inRect(input.mouse.x, input.mouse.y, rowRect);
          ctx.fillStyle = hov ? "#221e2b" : "#18151f";
          ctx.fillRect(rowRect.x, rowRect.y, rowRect.w, rowRect.h);
          ctx.fillStyle = colOf(it.level);
          ctx.fillRect(rowRect.x, rowRect.y, 3, rowRect.h);
          const dayNum = Math.floor(it.day) + 1;
          drawPropTextS(ctx, clipPropText(it.title, dw - 58), rowRect.x + 7, ry + 2, UI.text);
          drawPropText(ctx, `D${dayNum}`, rowRect.x + rowRect.w - 22, ry + 2, UI.dim);
          if (it.body) {
            drawPropText(ctx, clipPropText(it.body, dw - 24), rowRect.x + 7, ry + 10, UI.mid);
          }
          hits.add(`alerts.item.${it.id}`, rowRect, {
            tooltip: it.body ? `${it.title}: ${it.body}` : it.title,
            onClick: () => {
              it.read = true;
              onFocus?.(it);
            },
          });
        });
      }
      return;
    }

    // Compact live toast stack (up to 3 fading items)
    const active = this.items.filter((it) => it.ttl > 0).slice(0, 3);
    active.forEach((it, i) => {
      const ty = 26 + i * 22;
      const tw = 200, th = 19;
      const rect = { x: 6, y: ty, w: tw, h: th };
      const alpha = Math.min(1, it.ttl / 0.8);
      ctx.globalAlpha = alpha;
      drawPanel2x(ctx, rect.x, rect.y, rect.w, rect.h, "#121017", colOf(it.level));
      ctx.fillStyle = colOf(it.level);
      ctx.fillRect(rect.x + 2, rect.y + 2, 3, rect.h - 4);
      drawPropTextS(ctx, clipPropText(it.title, tw - 16), rect.x + 9, rect.y + 6, UI.title);
      ctx.globalAlpha = 1;
      hits.add(`alerts.toast.${it.id}`, rect, {
        tooltip: it.body ?? it.title,
        onClick: () => {
          it.read = true;
          it.ttl = 0;
          onFocus?.(it);
        },
      });
    });
  }
}
