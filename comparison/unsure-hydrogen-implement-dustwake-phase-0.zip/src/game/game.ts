// Host + presentation orchestrator (0.6). Delegates rendering, camera,
// particles and event reactions to `view/`, simulation timing to `sim/clock.ts`,
// input/UI v2 to `ui/`, and multi-slot persistence to `world/saveStore.ts`.
import { TS } from "./content/tiles";
import { ITEMS, type ItemId } from "./content/items";
import { hasItem } from "./sim/inventory";
import { golemGlow } from "./sim/gear";
import { toggleGearKit, grantStoryKit, grantBuildKit, teleportTo, type DebugPlace } from "./sim/debug";
import { foundationDemo } from "./sim/debugFoundations";
import { GOLEM_LIGHT } from "./content/gear";
import { BuildUi } from "./screens/buildMenu";
import { CraftingUi } from "./screens/crafting";
import { PackUi } from "./screens/pack";
import { StorageUi } from "./screens/storage";
import { DebugUi } from "./screens/debug";
import { ManageUi } from "./screens/manage";
import { TransferUi } from "./screens/transfer";
import { BookUi } from "./screens/book";
import { SchematicUi } from "./screens/schematic";
import { DialogueUi } from "./screens/dialogue";
import { IntroCutscene } from "./screens/intro";
import { CrossingCutscene } from "./screens/crossing";
import { SettingsUi } from "./screens/settingsUi";
import { SystemUi } from "./screens/systemUi";
import { ARRIVE } from "./content/cutscenes";
import { MonologueLog, drawMonologue } from "./ui/monologue";
import { renderTitle } from "./screens/cards";
import { propDef } from "./content/props";
import { FLAGS } from "./content/flags";
import { makeCanvas, Sprite, clamp, lerp } from "./util";
import { type Facing } from "./golem";
import { Light, makeLight, computeVis, applyGlow } from "./light";
import { Sfx } from "./audio";
import { CR } from "./circle";
import { carvingVisible, clumpCleared } from "./runeReveal";
import { RUNE_NODES } from "./content/runes";
import { runeState } from "./sim/runes";
import { linkedGlow, runeDudGlow, severedGlow } from "./view/runeFx";
import { drawText, drawTextS } from "./font";
import {
  createDynamicArea,
  createWorld,
  enterArea,
  player,
  currentArea,
  actorById,
  hasFlag,
  setFlag,
  clearFlag,
  type World,
  type Actor,
} from "./world/world";
import type { PropInst } from "./world/area";
import { stepPlayer, stepWorld, addPlayTime, type PlayerInput } from "./sim/step";
import { SimClock, EdgeInputLatch, InputRecorder, SPEED_PRESETS, type SimSpeed } from "./sim/clock";
import { classifyActorLod, type ViewBounds } from "./sim/lod";
import { interactables, type Interactable } from "./sim/interact";
import { AreaView } from "./view/areaView";
import { Camera } from "./view/camera";
import { ParticleSystem } from "./view/particles";
import { WorldRenderer, type GolemLook } from "./view/worldRenderer";
import { EventReactor, type ReactionHost } from "./view/reactions";
import { ScreenStack, type Screen } from "./ui/screens";
import { BASE_W, BASE_H, ZOOM_STEPS, ZOOM_DEFAULT, viewSize, nextZoomStep } from "./view/zoom";
import { VisionView, setVisionPalette, type VisionArt } from "./view/vision";
import { saveToStorage, loadFromStorage, getSaveManager, migrateLegacyLocalStorage } from "./view/persistence";
import type { Target } from "./content/tasks";
import { folkPresent } from "./sim/folk";
import { keeperPresent, shopOfArea, shopOpen } from "./sim/shops";
import { drawClosedSign } from "./keeperArt";
import { drawChatIcon, drawSpeech } from "./folkArt";
import { hash01, DAY_SECONDS, litLevel, skyLight, sunLevel, clockText, phaseAt, hearthSmoke, type DayPhase } from "./content/daycycle";
import { worldHour, advanceDay, advanceDayTo } from "./sim/daytime";
import { InputManager, UI_W, UI_H } from "./ui/input";
import { SettingsStore } from "./ui/settings";
import { PALETTES } from "./ui/palettes";
import { NotificationFeed, type NotificationItem } from "./ui/notifications";
import {
  HitRegistry,
  UiContextMenu,
  drawButton2x,
  drawPanel2x,
  drawTooltip,
  inRect,
  type ContextMenuItem,
} from "./ui/components";
import { drawPropText, drawPropTextS } from "./ui/propFont";
import { UI } from "./ui/kit";

const DEBUG_SPEED_MULT = 3;

export const W = BASE_W, H = BASE_H;
export { ZOOM_STEPS, ZOOM_DEFAULT, viewSize, UI_W, UI_H };
export { ARRIVE };

const newSeed = () => (Math.random() * 4294967296) >>> 0;

export class Game {
  /** Base-size (320x180) UI layer for legacy screens and snapshots. */
  baseUi = makeCanvas(W, H);
  ctx: CanvasRenderingContext2D;
  /** 2x high-resolution (640x360) UI layer for UI v2 HUD, proportional font & management panels. */
  hctx: CanvasRenderingContext2D;
  /** World layer sized to current view (vw x vh). */
  wctx: CanvasRenderingContext2D;
  vw = W;
  vh = H;
  zoom = 1;
  zoomAnim: { from: number; to: number; t: number; dur: number } | null = null;
  onView: ((w: number, h: number) => void) | null = null;

  settings: SettingsStore;
  input: InputManager;
  notifications: NotificationFeed;
  hits = new HitRegistry();
  contextMenu = new UiContextMenu();
  saveManager = getSaveManager();

  clock = new SimClock();
  edgeLatch = new EdgeInputLatch();
  recorder = new InputRecorder();

  cam = new Camera();
  particlesSys = new ParticleSystem();
  renderer: WorldRenderer;
  reactor = new EventReactor();
  vision = new VisionView();
  sfx = new Sfx();

  world!: World;
  view!: AreaView;
  screens = new ScreenStack();
  t = 0;
  frameDt = 0;
  toast: { icon: Sprite; name: string; t: number } | null = null;

  debugSpeed = false;
  debugSpeedMult = DEBUG_SPEED_MULT;
  debugNoclip = false;
  debugHud = false;
  debugMsg: { text: string; t: number } | null = null;
  debugClock = 1;

  rumbleT = 50;
  eyeBoost = 0;
  crackFlash = 0;
  shudder: { tx: number; ty: number; t: number } | null = null;
  fizzT = 0;
  look: GolemLook = { eye: 0, core: 0, dormant: 1, sparkT: 2, sputter: 0, z: 0 };
  glight!: Light;
  dripT: number[] = [];
  target: Interactable | null = null;
  private uiTimers: { at: number; fn: () => void }[] = [];
  private S!: Record<
    "title" | "intro" | "play" | "tele" | "crossing" | "inv" | "schem" | "book" | "build" | "crafting" | "storage" | "manage" | "dialogue" | "debug",
    Screen
  >;
  note: { text: string; t: number } | null = null;
  tele = { x: 0, y: 0, dur: 4.6, first: true, travelled: false };
  arriveFade = 0;
  doorFade = 0;
  hideGolem = false;
  runeAnim: { t: number; glow: number; column: number } | null = null;
  runeDud: { x: number; y: number; t: number } | null = null;

  buildUi!: BuildUi;
  craftUi!: CraftingUi;
  packUi!: PackUi;
  storageUi!: StorageUi;
  manageUi!: ManageUi;
  transferUi!: TransferUi;
  debugUi!: DebugUi;
  bookUi!: BookUi;
  schemUi!: SchematicUi;
  dialogueUi!: DialogueUi;
  introUi!: IntroCutscene;
  crossingUi!: CrossingCutscene;
  settingsUi!: SettingsUi;
  systemUi!: SystemUi;

  monologue = new MonologueLog();
  bars = { v: 0, to: 0 };
  gaze: Facing | null = null;
  private skyT = 3;

  /** Drag-selected actor ids (0.5 mouse drag-select). */
  selectedActors = new Set<string>();
  /** Autosave tracking (timer + area transitions). */
  private autosaveT = 0;
  private lastAreaId = "";
  private dynFloorSeq = 1;

  /** Live telemetry for SystemUi & LOD monitoring. */
  telemetry = { frameMs: [] as number[], active: 0, near: 0, far: 0 };

  constructor(public canvas: HTMLCanvasElement, public uiCanvas: HTMLCanvasElement) {
    this.wctx = canvas.getContext("2d")!;
    this.wctx.imageSmoothingEnabled = false;
    this.ctx = this.baseUi.ctx;
    if (uiCanvas.width < UI_W || uiCanvas.height < UI_H) {
      uiCanvas.width = UI_W;
      uiCanvas.height = UI_H;
    }
    this.hctx = uiCanvas.getContext("2d")!;
    this.hctx.imageSmoothingEnabled = false;

    const storage = typeof localStorage !== "undefined" ? localStorage : undefined;
    this.settings = new SettingsStore(storage);
    this.input = new InputManager(this.settings);
    this.notifications = new NotificationFeed(this.settings);
    this.renderer = new WorldRenderer(this.wctx, W, H);
    this.applySettings();

    this.makeScreens();
    this.reset();
    this.screens.set(this.S.title);
    void migrateLegacyLocalStorage(this.saveManager);
  }

  // Compatibility accessors for tests & callers expecting original Game fields
  get particles() { return this.particlesSys.list; }
  set particles(v) { this.particlesSys.list = v; }
  get keys() { return this.input.keys; }
  get pressed() { return this.input.pressed; }
  get typed() { return this.input.typed; }
  get npcLooks() { return this.reactor.npcLooks; }
  get circle() { return this.renderer.circle; }
  get runeArt() { return this.renderer.runeArt; }
  get pl() { return player(this.world); }
  get area() { return currentArea(this.world); }
  get hasArm() { return hasFlag(this.world, FLAGS.golemArm); }

  applySettings() {
    const s = this.settings.data;
    this.sfx.setVolumes(s.masterVol, s.sfxVol, s.ambientVol);
    setVisionPalette(s.palette);
  }

  // ---------------------------------------------------------------- session
  reset(world: World = createWorld(newSeed())) {
    this.world = world;
    this.view?.dispose();
    const area = currentArea(world);
    this.view = new AreaView(area);
    this.lastAreaId = area.id;
    this.autosaveT = 0;
    this.schemUi.reset(world);
    const pl = player(world);
    this.glight = makeLight(pl.x, pl.y - 6, GOLEM_LIGHT.rad, GOLEM_LIGHT.col, 0, 0.05, "golem");
    this.dripT = area.drips.map(() => Math.random() * 4);
    this.look = { eye: 0, core: 0, dormant: 1, sparkT: 1.5, sputter: 0, z: 0 };
    this.zoomAnim = null;
    this.setZoom(hasFlag(world, FLAGS.golemEye) ? ZOOM_DEFAULT : 1);
    this.cam.snap(pl.x, pl.y, area, this.vw, this.vh);
    this.cam.clearShake();
    this.reactor.clear();
    this.vision.reset(pl.mode === "scan");
    this.dialogueUi.reset();
    this.packUi.reset();
    this.storageUi.reset();
    this.manageUi.reset();
    this.transferUi.reset();
    this.particlesSys.clear();
    this.selectedActors.clear();
    this.contextMenu.close();
    this.notifications.clear();
    this.clock.reset(world);
    this.edgeLatch.clear();
    this.toast = null;
    this.fizzT = 0;
    this.shudder = null;
    this.uiTimers = [];
    this.rumbleT = 45 + Math.random() * 30;
    this.note = null;
    this.arriveFade = 0;
    this.doorFade = 0;
    this.hideGolem = false;
    this.runeAnim = null;
    this.runeDud = null;
    this.gaze = null;
    this.skyT = 3;
    this.monologue.reset();
    this.bars = { v: 0, to: 0 };
  }

  resume(world: World) {
    this.reset(world);
    this.look.dormant = 0;
    this.screens.set(this.S.play);
  }

  saveGame() {
    try {
      saveToStorage(this.world);
      void this.saveManager.saveSlot("slot1", this.world, "Manual Save");
      this.say("GAME SAVED");
      this.sfx.tone(520, 0.1, "triangle", 0.05);
    } catch {
      this.say("COULD NOT SAVE");
      this.sfx.tone(180, 0.1, "square", 0.04);
    }
  }

  loadGame(): boolean {
    let w: World | null = null;
    try { w = loadFromStorage(); } catch { w = null; }
    if (!w) {
      this.say("NO SAVED GAME");
      this.sfx.tone(180, 0.1, "square", 0.04);
      return false;
    }
    this.resume(w);
    this.say("GAME LOADED");
    return true;
  }

  private triggerAutosave(reason: string) {
    void this.saveManager.saveSlot("autosave", this.world, `Autosave (${reason})`).catch(() => {});
  }

  createTestDynamicFloor() {
    const id = `dyn_floor_${this.dynFloorSeq++}`;
    const depth = this.dynFloorSeq - 1;
    const area = createDynamicArea(this.world, {
      id,
      kind: "floor",
      seed: (this.world.seed ^ (depth * 7919)) >>> 0,
      w: 48,
      h: 30,
      parent: this.pl.area,
      depth,
      authored: false,
    });
    enterArea(this.world, this.pl, area.id, area.start.x, area.start.y);
    this.syncView();
    this.cam.snap(this.pl.x, this.pl.y, area, this.vw, this.vh);
    this.say(`ENTERED GENERATED FLOOR (DEPTH ${depth})`);
  }

  private syncView() {
    const area = currentArea(this.world);
    if (this.view.area === area) return;
    this.view.dispose();
    this.view = new AreaView(area);
    this.dripT = area.drips.map(() => Math.random() * 4);
    this.glight.vx = -999;
    const pl = this.pl;
    this.cam.snap(pl.x, pl.y, area, this.vw, this.vh);
    if (this.lastAreaId !== area.id) {
      this.lastAreaId = area.id;
      this.triggerAutosave(area.id);
    }
  }

  // ---------------------------------------------------------------- zoom
  setZoom(z: number) {
    this.zoom = z;
    const { w, h } = viewSize(z);
    if (w === this.vw && h === this.vh) return;
    this.cam.onResize(this.vw, this.vh, w, h, this.view?.area);
    this.vw = w;
    this.vh = h;
    this.canvas.width = w;
    this.canvas.height = h;
    this.wctx.imageSmoothingEnabled = false;
    this.renderer.resize(this.wctx, w, h);
    this.onView?.(w, h);
  }

  zoomTo(z: number, dur: number) {
    if (z === this.zoom && !this.zoomAnim) return;
    this.zoomAnim = { from: this.zoom, to: z, t: 0, dur };
  }

  private stepZoom(dt: number) {
    const a = this.zoomAnim;
    if (!a) return;
    a.t += dt;
    const k = clamp(a.t / a.dur, 0, 1), e = k * k * (3 - 2 * k);
    this.setZoom(lerp(a.from, a.to, e));
    if (k >= 1) this.zoomAnim = null;
  }

  wheel(deltaY: number) {
    this.input.wheel(deltaY);
    if (!this.screens.is("play") || !hasFlag(this.world, FLAGS.golemEye) || deltaY === 0) return;
    if (this.notifications.drawerOpen) return;
    const cur = this.zoomAnim?.to ?? this.zoom;
    const next = nextZoomStep(cur, deltaY);
    if (next === cur) return;
    this.zoomTo(next, 0.25);
    this.sfx.tone(next > cur ? 420 : 560, 0.05, "triangle", 0.03);
  }

  // ---------------------------------------------------------------- input
  keyDown(k: string) { this.input.keyDown(k); }
  keyUp(k: string) { this.input.keyUp(k); }
  pointer(uiX = UI_W / 2, uiY = UI_H / 2, button = 0) { this.input.pointerDown(uiX, uiY, button); }
  pointerMove(uiX: number, uiY: number) { this.input.pointerMove(uiX, uiY); }
  pointerUp(uiX: number, uiY: number, button = 0) { this.input.pointerUp(uiX, uiY, button); }
  has(...k: string[]) { return this.input.has(...k); }
  hit(...k: string[]) { return this.input.hit(...k); }

  debugKey(n: number) {
    const w = this.world, pl = this.pl;
    const say = (text: string) => { this.debugMsg = { text, t: 0 }; };
    if (n === 0) this.debugUi.toggle();
    else if (n === 1) {
      if (this.hasArm) { clearFlag(w, FLAGS.golemArm); say("DEBUG: IRON ARM OFF"); }
      else { setFlag(w, FLAGS.golemArm); say("DEBUG: IRON ARM ON"); }
    } else if (n === 2) {
      const given = grantStoryKit(w, pl);
      this.sfx.tone(520, 0.1, "triangle", 0.05);
      say(given ? "DEBUG: RUNES + CORE + TOOLS GRANTED" : "DEBUG: ALREADY HAVE ALL RUNES + CORE + TOOLS");
    } else if (n === 3) {
      this.debugSpeed = !this.debugSpeed;
      say(this.debugSpeed ? "DEBUG: SUPER SPEED ON" : "DEBUG: SUPER SPEED OFF");
    } else if (n === 4) {
      grantBuildKit(w, pl);
      say("DEBUG: BUILD + MASONRY + PLANS + BASKET + MATERIALS");
    } else if (n === 6) {
      const on = toggleGearKit(w, pl);
      this.sfx.tone(on ? 560 : 380, 0.1, "triangle", 0.05);
      say(on ? "DEBUG: GEAR KIT ON - ALL SLOTS UNLOCKED" : "DEBUG: GEAR KIT OFF - SLOTS LOCKED AGAIN");
    } else if (n === 5) {
      if (hasFlag(w, FLAGS.golemEye)) { w.flags.delete(FLAGS.golemEye); this.zoomTo(1, 0.4); say("DEBUG: EYE REPAIR OFF"); }
      else { setFlag(w, FLAGS.golemEye); this.zoomTo(ZOOM_DEFAULT, 1); this.eyeBoost = 1.5; say("DEBUG: EYE REPAIR ON (SCROLL TO ZOOM)"); }
    }
  }

  debugSetFlag(flag: string, on: boolean) {
    const w = this.world;
    if (on) setFlag(w, flag); else clearFlag(w, flag);
    if (flag === FLAGS.golemEye) {
      if (on) { this.zoomTo(ZOOM_DEFAULT, 0.6); this.eyeBoost = 1.5; }
      else this.zoomTo(1, 0.4);
    }
  }

  debugTeleport(p: DebugPlace): boolean {
    const pl = this.pl;
    if (!teleportTo(this.world, pl, p.area, p.x, p.y)) return false;
    this.syncView();
    this.cam.snap(pl.x, pl.y, this.area, this.vw, this.vh);
    this.glight.vx = -999;
    this.particlesSys.clear();
    this.drainEvents();
    return true;
  }

  debugNewGame() { this.resume(createWorld(newSeed())); this.say("NEW GAME (DEBUG)"); }
  debugFoundations() { this.resume(foundationDemo()); this.say("FOUNDATION FIXTURE: A WORKER GATHERS THROUGH THE RUNES."); }
  debugZoom() {
    const cur = this.zoomAnim?.to ?? this.zoom;
    const steps = [...ZOOM_STEPS].sort((x, y) => x - y);
    const next = steps.find((z) => z > cur + 1e-6) ?? steps[0];
    this.zoomTo(next, 0.3);
  }

  // ---------------------------------------------------------------- helpers
  spawn(p: Parameters<ParticleSystem["spawn"]>[0]) { this.particlesSys.spawn(p); }
  shake(t: number, m: number) { this.cam.shake(t, m, this.settings.data.screenShake); }
  dist2(x: number, y: number) { const pl = this.pl, dx = x - pl.x, dy = y - pl.y; return dx * dx + dy * dy; }
  volAt(x: number, y: number) { return clamp(1 - Math.sqrt(this.dist2(x, y)) / 220, 0, 1); }
  later(delay: number, fn: () => void) { this.uiTimers.push({ at: this.t + delay, fn }); }

  sparkBurst(n: number) {
    const pl = this.pl;
    const right = pl.facing === "down" || pl.facing === "left";
    const sx = pl.x + (pl.facing === "up" ? -8 : pl.facing === "down" ? 8 : right ? -1 : 1);
    const sy = pl.y - 9 + Math.round(this.look.dormant * 4);
    for (let i = 0; i < n; i++) {
      this.spawn({
        x: sx, y: sy + 9, z: 9,
        vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.3) * 20, vz: 10 + Math.random() * 30,
        life: 0.3 + Math.random() * 0.4, kind: "spark",
        col: Math.random() < 0.5 ? "#fff2a0" : "#ffb040", emit: true, g: 120,
      });
    }
  }

  // ---------------------------------------------------------------- screens
  private makeScreens() {
    const g = this;
    const scr = (id: string, opaque: boolean, update: (dt: number) => void, render: () => void): Screen => ({
      id, opaque, t: 0, update, render,
    });
    this.buildUi = new BuildUi(this);
    this.craftUi = new CraftingUi(this);
    this.packUi = new PackUi(this);
    this.storageUi = new StorageUi(this);
    this.manageUi = new ManageUi(this);
    this.transferUi = new TransferUi(this, (id) => this.manageUi.open(id));
    this.manageUi.openTransfer = (id) => this.transferUi.open(id);
    this.debugUi = new DebugUi(this);
    this.bookUi = new BookUi(this);
    this.schemUi = new SchematicUi(this);
    this.dialogueUi = new DialogueUi(this);
    this.introUi = new IntroCutscene(this);
    this.crossingUi = new CrossingCutscene(this);
    this.settingsUi = new SettingsUi(this);
    this.systemUi = new SystemUi({
      hctx: this.hctx,
      input: this.input,
      settings: this.settings,
      screens: this.screens,
      get world() { return g.world; },
      saveManager: this.saveManager,
      telemetry: this.telemetry,
      resume: (w) => g.resume(w),
      openSettings: () => g.settingsUi.open(),
      goTitle: () => { g.reset(); g.screens.set(g.S.title); },
      say: (txt) => g.say(txt),
      createTestDynamicFloor: () => g.createTestDynamicFloor(),
    });

    this.S = {
      title: scr(
        "title",
        true,
        (dt) => {
          if (g.hit("o")) { g.settingsUi.open(); return; }
          if (g.hit("l") && g.loadGame()) { g.sfx.init(); return; }
          if (g.pressed.size) { g.sfx.init(); g.introUi.start(); }
          if (Math.random() < 0.3) {
            g.spawn({ x: Math.random() * W, y: H + 2, vy: -10 - Math.random() * 12, vx: (Math.random() - 0.5) * 4, life: 6, kind: "ember", col: Math.random() < 0.5 ? "#ff8a3a" : "#c84a10", emit: true });
          }
          g.updateParticles(dt);
        },
        () => renderTitle(g.ctx, g.t, g.particles),
      ),
      intro: this.introUi.screen,
      play: scr("play", true, (dt) => g.updatePlay(dt), () => g.renderWorldScene()),
      tele: scr(
        "tele",
        true,
        (dt) => {
          if (g.tele.first && g.S.tele.t > 0.2 && g.hit("escape")) { g.skipCrossing(); return; }
          if (g.updateTele(dt)) return;
          stepPlayer(g.world, dt, { ix: 0, iy: 0, use: false });
          g.drainEvents();
          g.worldFrame(dt);
        },
        () => {
          g.renderWorldScene();
          const t = g.S.tele.t, w0 = g.tele.dur - 1.6;
          if (t > w0 && g.settings.data.flashes) {
            g.ctx.fillStyle = `rgba(235,240,255,${clamp((t - w0) / 1.4, 0, 1)})`;
            g.ctx.fillRect(0, 0, W, H);
          }
          if (g.tele.first) g.renderSkipHint(t);
        },
      ),
      crossing: this.crossingUi.screen,
      book: this.bookUi.screen,
      build: this.buildUi.screen,
      crafting: this.craftUi.screen,
      storage: this.storageUi.screen,
      manage: this.manageUi.screen,
      debug: this.debugUi.screen,
      dialogue: this.dialogueUi.screen,
      inv: this.packUi.screen,
      schem: this.schemUi.screen,
    };
  }

  // ---------------------------------------------------------------- update
  update(dt: number) {
    this.frameDt = dt;
    this.t += dt;
    this.input.pollGamepad();
    this.notifications.update(dt);
    if (this.uiTimers.length) {
      const due = this.uiTimers.filter((u) => u.at <= this.t);
      this.uiTimers = this.uiTimers.filter((u) => u.at > this.t);
      for (const u of due) u.fn();
    }
    this.stepZoom(dt);
    this.screens.update(dt);
    this.input.endFrame();
  }

  private viewBounds(): ViewBounds {
    return { x0: this.cam.x, y0: this.cam.y, x1: this.cam.x + this.vw, y1: this.cam.y + this.vh };
  }

  worldFrame(dt: number) {
    const vb = this.viewBounds();
    const t0 = typeof performance !== "undefined" ? performance.now() : 0;
    stepWorld(this.world, dt, vb);
    if (typeof performance !== "undefined") {
      const ms = performance.now() - t0;
      this.telemetry.frameMs.push(ms);
      if (this.telemetry.frameMs.length > 60) this.telemetry.frameMs.shift();
    }
    if (this.debugClock > 1) advanceDay(this.world, ((this.debugClock - 1) * dt * 24) / DAY_SECONDS);
    this.drainEvents();
    this.syncView();
    if (this.view.flush()) this.glight.vx = -999;
    this.updateWorldFx(dt);
    this.updateLodTelemetry(vb);
  }

  private updateLodTelemetry(vb: ViewBounds) {
    let active = 0, near = 0, far = 0;
    for (const a of this.world.actors) {
      const tier = classifyActorLod(this.world, a, vb);
      if (tier === "active") active++;
      else if (tier === "near") near++;
      else far++;
    }
    this.telemetry.active = active;
    this.telemetry.near = near;
    this.telemetry.far = far;
  }

  private reactionHost(): ReactionHost {
    const g = this;
    return {
      world: g.world,
      pl: g.pl,
      area: g.area,
      view: g.view,
      t: g.t,
      hasArm: g.hasArm,
      sfx: g.sfx,
      particles: g.particlesSys,
      cam: g.cam,
      monologue: g.monologue,
      notifications: g.notifications,
      circlePixels: g.circle.pixels,
      isPlayScreen: () => g.screens.is("play"),
      screenShakeEnabled: () => g.settings.data.screenShake,
      say: (text) => g.say(text),
      later: (delay, fn) => g.later(delay, fn),
      volAt: (x, y) => g.volAt(x, y),
      sparkBurst: (n) => g.sparkBurst(n),
      setToast: (toast) => { g.toast = toast; },
      openBook: (id) => g.bookUi.open(id as ItemId),
      openSchematic: () => g.schemUi.open(),
      openCrafting: (st, prop) => g.craftUi.open(st, prop),
      openStorage: (prop) => g.storageUi.open(prop),
      openManage: (target) => g.manageUi.open(target),
      openDialogue: (npc, script, seg) => g.dialogueUi.open(npc, script, seg),
      onStartTeleport: (x, y, dur, first) => {
        g.tele = { x, y, dur, first, travelled: false };
        g.screens.set(g.S.tele);
        g.sfx.teleport();
        if (first) { g.letterbox(true); g.monologue.pinned = true; }
      },
      onTravelled: () => { g.tele.travelled = true; },
      onDayPhase: (ph) => g.onDayPhase(ph),
      onPortal: (door) => {
        g.doorFade = 1;
        if (door) g.sfx.open();
        else g.sfx.step(true);
      },
      onEyeRepaired: (by) => {
        const lk = g.look;
        lk.sputter = 0; lk.eye = 1;
        g.eyeBoost = 2.2;
        g.sfx.eyeRepair();
        g.shake(0.25, 1);
        g.sparkBurst(10);
        for (let i = 0; i < 24; i++) {
          g.spawn({ x: g.pl.x + (Math.random() - 0.5) * 4, y: g.pl.y, z: 18, vx: (Math.random() - 0.5) * 60, vy: (Math.random() - 0.5) * 24, vz: 10 + Math.random() * 40, life: 0.4 + Math.random() * 0.5, kind: "spark", col: Math.random() < 0.5 ? "#bff4ff" : "#7fe8ff", emit: true, g: 110 });
        }
        const byA = by ? actorById(g.world, by) ?? g.world.actors.find((a) => a.npc === by) : undefined;
        if (byA) g.npcLook(byA).reach = 1.8;
        g.later(0.5, () => g.zoomTo(ZOOM_DEFAULT, 1.1));
        g.dialogueUi.zoomHint = true;
      },
      onPauseAlert: () => {
        if (g.clock.speed > 0) {
          g.clock.setSpeed(0);
          g.say("PAUSED ON ALERT");
        }
      },
      setFizz: (t) => { g.fizzT = t; },
      setCrackFlash: (v) => { g.crackFlash = v; },
      setShudder: (tx, ty, t) => { g.shudder = { tx, ty, t }; },
      setRuneDud: (x, y) => { g.runeDud = { x, y, t: 0 }; },
      setEyeBoost: (v) => { g.eyeBoost = Math.max(g.eyeBoost, v); },
    };
  }

  drainEvents() {
    this.reactor.drainEvents(this.reactionHost());
  }

  updatePlay(dt: number) {
    const w = this.world, pl = this.pl, lk = this.look;

    // UI v2 Context Menu & HUD Hit Resolution first (mouse clicks on HUD don't trigger world clicks)
    if (this.contextMenu.handleInput(this.input)) return;
    if (this.hits.resolve(this.input)) return;

    // Speed hotkeys & v2 menus
    if (this.hit("p")) this.clock.setSpeed(this.clock.speed === 0 ? 1 : 0);
    if (this.hit("1")) this.clock.setSpeed(1);
    if (this.hit("2")) this.clock.setSpeed(2);
    if (this.hit("3")) this.clock.setSpeed(4);
    if (this.hit("4")) this.clock.setSpeed(8);
    if (this.input.actionHit("notifications")) this.notifications.toggleDrawer();
    if (this.input.actionHit("settings")) { this.settingsUi.open(); return; }
    if (this.input.actionHit("pause")) { this.systemUi.open(2); return; }

    // Drag-select & right-click context menu on world
    this.handlePlayMouse();

    // Quick save / load
    if (this.input.actionHit("quicksave") || this.hit("k")) this.saveGame();
    if ((this.input.actionHit("quickload") || this.hit("l")) && this.loadGame()) return;

    // Autosave timer
    const autoSec = this.settings.data.autosaveIntervalSec;
    if (autoSec > 0 && this.clock.speed > 0) {
      this.autosaveT += dt;
      if (this.autosaveT >= autoSec) {
        this.autosaveT = 0;
        this.triggerAutosave("timer");
      }
    }

    // Legacy overlay triggers
    if (!pl.task) {
      if (this.input.actionHit("pack") || this.hit("i", "tab")) { this.packUi.open("view"); return this.updateWorldFx(dt); }
      if ((this.input.actionHit("map") || this.hit("m")) && hasItem(pl, "schematic")) { this.schemUi.open(); return this.updateWorldFx(dt); }
      if (this.input.actionHit("build") || this.hit("b")) { this.buildUi.open(); return this.updateWorldFx(dt); }
      if (this.hit("v")) { this.buildUi.quickPlace(); return this.updateWorldFx(dt); }
      if (this.buildUi.pending) { this.buildUi.resumeAfterWork(); if (!this.screens.is("play")) return this.updateWorldFx(dt); }
      if (this.craftUi.pending) { this.craftUi.resume(); if (!this.screens.is("play")) return this.updateWorldFx(dt); }
      if (this.manageUi.pending) { this.manageUi.resume(); if (!this.screens.is("play")) return this.updateWorldFx(dt); }
    }

    // Latch single-frame edge actions so fixed-timestep accumulator consumes them exactly once
    this.edgeLatch.push({
      use: this.input.actionHit("interact") || this.hit("e", "enter"),
      attack: this.input.actionHit("attack") || this.hit(" "),
      core: this.input.actionHit("core") || this.hit("c"),
      toggleScan: this.input.actionHit("scan") || this.hit("z"),
    });

    let ix = this.input.gpAxis.ix;
    let iy = this.input.gpAxis.iy;
    if (this.input.actionDown("moveLeft") || this.has("arrowleft", "a")) ix -= 1;
    if (this.input.actionDown("moveRight") || this.has("arrowright", "d")) ix += 1;
    if (this.input.actionDown("moveUp") || this.has("arrowup", "w")) iy -= 1;
    if (this.input.actionDown("moveDown") || this.has("arrowdown", "s")) iy += 1;
    ix = clamp(ix, -1, 1);
    iy = clamp(iy, -1, 1);

    const vb = this.viewBounds();
    const steps = this.clock.advance(dt, w, (tickDt) => {
      const edges = this.edgeLatch.consume();
      const inp: PlayerInput = {
        ix,
        iy,
        use: edges.use,
        attack: edges.attack,
        core: edges.core,
        toggleScan: edges.toggleScan,
        speed: this.debugSpeed ? this.debugSpeedMult : 1,
        noclip: this.debugNoclip,
      };
      this.recorder.record(this.clock.tickCount, inp);
      addPlayTime(w, tickDt);
      const res = stepPlayer(w, tickDt, inp);
      this.target = res.target;
      if (res.ui) this.packUi.open("select", res.ui.socket);
      const t0 = typeof performance !== "undefined" ? performance.now() : 0;
      stepWorld(w, tickDt, vb);
      if (typeof performance !== "undefined") {
        const ms = performance.now() - t0;
        this.telemetry.frameMs.push(ms);
        if (this.telemetry.frameMs.length > 60) this.telemetry.frameMs.shift();
      }
      if (this.debugClock > 1) advanceDay(w, ((this.debugClock - 1) * tickDt * 24) / DAY_SECONDS);
      this.drainEvents();
      this.syncView();
    });

    if (steps === 0) {
      // Still compute hover interaction target when paused
      this.updateLodTelemetry(vb);
    } else {
      this.updateLodTelemetry(vb);
    }

    const fxDt = this.clock.speed === 0 ? 0 : dt * this.clock.speed;
    // Golem damage sparks & eye state
    if (fxDt > 0) {
      lk.sparkT -= fxDt;
      if (lk.sparkT <= 0) {
        lk.sparkT = 1.5 + Math.random() * 4;
        if (!this.hasArm) { this.sparkBurst(3 + ((Math.random() * 4) | 0)); if (Math.random() < 0.6) this.sfx.spark(); }
        if (Math.random() < 0.12) lk.sputter = 0.25;
      }
      lk.sputter = Math.max(0, lk.sputter - fxDt);
      lk.core = lk.sputter > 0 ? (Math.random() < 0.5 ? 0.3 : 0.8) : 1;
      lk.eye = lk.sputter > 0 && !hasFlag(w, FLAGS.golemEye) ? 0.3 : 1;
      lk.dormant = 0;
      this.eyeBoost = Math.max(0, this.eyeBoost - fxDt);

      if (!this.area.base.outdoor && !this.area.base.interior) this.rumbleT -= fxDt;
      if (this.rumbleT <= 0) {
        this.rumbleT = 50 + Math.random() * 50;
        this.sfx.rumble();
        this.shake(2.2, 1.5);
        for (let i = 0; i < 30 * this.zoom * this.zoom; i++) {
          this.spawn({ x: this.cam.x + Math.random() * this.vw, y: this.cam.y + Math.random() * this.vh, z: 60 + Math.random() * 40, vz: -10, life: 4, kind: "debris", col: Math.random() < 0.5 ? "#6a6372" : "#4b4552", g: 60 });
        }
      }
    }

    if (this.view.flush()) this.glight.vx = -999;
    this.updateWorldFx(fxDt > 0 ? fxDt : dt * 0.15);
  }

  private handlePlayMouse() {
    const m = this.input.mouse;
    // Drag-select actors in current area
    if (m.draggedBox) {
      const p0 = this.input.toWorld(m.draggedBox.x0, m.draggedBox.y0, this.cam, this.vw, this.vh);
      const p1 = this.input.toWorld(m.draggedBox.x1, m.draggedBox.y1, this.cam, this.vw, this.vh);
      this.selectedActors.clear();
      for (const a of this.world.actors) {
        if (a.area !== this.pl.area || a.id === this.world.playerId) continue;
        if (a.x >= p0.x && a.x <= p1.x && a.y >= p0.y && a.y <= p1.y) {
          this.selectedActors.add(a.id);
        }
      }
      if (this.selectedActors.size > 0) {
        this.say(`SELECTED ${this.selectedActors.size} ACTOR${this.selectedActors.size > 1 ? "S" : ""}`);
      }
    }

    // Single left-click on an actor in world
    if (m.leftClick && !m.dragging) {
      const wp = this.input.toWorld(m.x, m.y, this.cam, this.vw, this.vh);
      const hit = this.findActorNear(wp.x, wp.y, 14);
      if (hit) {
        this.selectedActors.clear();
        this.selectedActors.add(hit.id);
      } else {
        this.selectedActors.clear();
      }
    }

    // Right-click context menu on world
    if (m.rightClick) {
      const wp = this.input.toWorld(m.x, m.y, this.cam, this.vw, this.vh);
      const actor = this.findActorNear(wp.x, wp.y, 16);
      const items: ContextMenuItem[] = [];
      if (actor) {
        if (actor.definition === "worker_golem" || actor.definition === "golem") {
          items.push({ label: `Manage ${actor.name ?? "Worker"}`, onSelect: () => this.manageUi.open(actor.id) });
        }
        items.push({
          label: "Inspect",
          onSelect: () => this.say(`${(actor.name ?? actor.person?.name ?? actor.id).toUpperCase()} (${actor.area.toUpperCase()})`),
        });
      } else {
        const tx = Math.floor(wp.x / TS), ty = Math.floor(wp.y / TS);
        items.push({
          label: `Inspect Tile (${tx}, ${ty})`,
          onSelect: () => this.say(`TILE ${tx},${ty} IN ${this.area.id.toUpperCase()}`),
        });
        items.push({
          label: this.pl.mode === "scan" ? "Disable Scan Mode" : "Enable Scan Mode",
          onSelect: () => { this.pl.mode = this.pl.mode === "scan" ? "normal" : "scan"; },
        });
        items.push({
          label: "Open Build Menu",
          onSelect: () => this.buildUi.open(),
        });
      }
      this.contextMenu.show(m.x, m.y, items);
    }
  }

  private findActorNear(wx: number, wy: number, radius: number): Actor | undefined {
    let best: Actor | undefined;
    let bestD = radius;
    for (const a of this.world.actors) {
      if (a.area !== this.pl.area || a.id === this.world.playerId) continue;
      const d = Math.hypot(a.x - wx, a.y - 8 - wy);
      if (d <= bestD) { bestD = d; best = a; }
    }
    return best;
  }

  updateTele(_dt: number): boolean {
    const t = this.S.tele.t, lk = this.look, tl = this.tele, pl = this.pl;
    if (!pl.task && t > 0.2) {
      this.sfx.setHum(0);
      if (tl.first && tl.travelled) { this.particlesSys.clear(); this.crossingUi.start(); }
      else {
        if (tl.first) { this.letterbox(false); this.monologue.release(); }
        this.screens.set(this.S.play);
        this.arriveFade = tl.travelled ? 1 : 0;
        lk.z = tl.travelled ? 16 : 0;
      }
      return true;
    }
    const lift = tl.dur - 1.6;
    lk.z = Math.min(t, lift) * (tl.first ? 4 : 6) + Math.sin(t * 3) * 1;
    lk.eye = 1; lk.core = 1;
    this.shake(0.1, Math.min(4, t * 1.2));
    for (let i = 0; i < 6; i++) {
      const a = Math.random() * Math.PI * 2, r = 20 + Math.random() * 50;
      this.spawn({ x: tl.x + Math.cos(a) * r, y: tl.y + Math.sin(a) * r, z: 2, vx: -Math.cos(a) * r * 0.8, vy: -Math.sin(a) * r * 0.8, vz: 10 + Math.random() * 20, life: 1.2, kind: "rune", col: Math.random() < 0.5 ? "#c0a0ff" : "#80e0ff", emit: true, g: -5 });
    }
    this.glight.int = 0.9 + t * 0.4;
    return false;
  }

  skipCrossing() {
    const pl = this.pl;
    for (let i = 0; i < 200 && pl.task; i++) stepPlayer(this.world, 0.1, { ix: 0, iy: 0, use: false });
    this.drainEvents();
    this.sfx.setHum(0);
    this.look.z = 0;
    if (!this.tele.travelled) { this.letterbox(false); this.monologue.release(); this.screens.set(this.S.play); return; }
    this.syncView();
    this.particlesSys.clear();
    this.crossingUi.start();
    this.crossingUi.skip();
  }

  tendedLevel(p: PropInst, hour = worldHour(this.world)): number {
    if (!this.area.base.tended || p.dyn) return 1;
    const habit = propDef(p.kind).habit;
    return habit ? litLevel(habit, p.id, hour) : 1;
  }

  private onDayPhase(phase: DayPhase) {
    const a = this.area;
    if (!a.base.outdoor || !this.screens.is("play")) return;
    const town = !!a.base.tended;
    if (phase === "dawn") { this.say(town ? "DAWN. THE TOWN PUTS OUT ITS LAMPS." : "DAWN BREAKS."); if (town) this.sfx.bell(); }
    else if (phase === "dusk") { this.say(town ? "DUSK. THE TOWN LIGHTS ITS LAMPS." : "DUSK. THE LIGHT IS GOING."); if (town) this.sfx.bell(); }
    else if (phase === "night") this.say("NIGHT FALLS.");
  }

  debugAdvanceTime(): string {
    const marks = [0, 5, 6, 7, 12, 19, 20, 21], h = worldHour(this.world);
    advanceDayTo(this.world, marks.find((m) => m > h + 0.01) ?? marks[0]);
    this.drainEvents();
    const now = worldHour(this.world);
    return `${clockText(now)} ${phaseAt(now).toUpperCase()}`;
  }

  surfaceRuneState(): { t: number; glow: number; column: number } {
    if (this.runeAnim) return this.runeAnim;
    const state = runeState(this.world, RUNE_NODES.surface);
    const rest = state === "linked" ? linkedGlow(this.t) : state === "severed" ? severedGlow(this.t) : 0;
    const d = this.runeDud, p = d ? this.area.prop(RUNE_NODES.surface.prop) : undefined;
    const glow = d && p && Math.hypot(p.x - d.x, p.y - d.y) < 4 ? runeDudGlow(d.t, rest, state === "dormant" ? 0.5 : 1) : rest;
    return { t: state === "dormant" ? 0 : 1, glow, column: 0 };
  }

  arriveStep(t: number, dt: number) {
    const A = ARRIVE, t0 = t - dt, lk = this.look;
    const rp = this.area.prop("rune.surface");
    const c = rp ?? this.pl;
    const crossed = (at: number) => t >= at && t0 < at;
    const ease = (x: number) => x * x * (3 - 2 * x);
    const prog = ease(clamp((t - A.SWEEP) / (A.SWEEP_END - A.SWEEP), 0, 1));
    let glow = 0;
    if (t >= A.GLOW && t < A.SWEEP) glow = 0.4 * ease(clamp((t - A.GLOW) / (A.SWEEP - A.GLOW), 0, 1)) * (0.85 + 0.15 * Math.sin(t * 7));
    else if (t >= A.SWEEP && t < A.SWEEP_END) glow = 0.4 + 0.25 * prog + 0.06 * Math.sin(t * 6);
    else if (t >= A.SWEEP_END && t < A.PULSE_END) glow = 0.65 + 0.95 * Math.sin((Math.PI * (t - A.SWEEP_END)) / (A.PULSE_END - A.SWEEP_END));
    else if (t >= A.PULSE_END) glow = 0.75 + 0.2 * Math.sin(t * 5);
    const column = t < A.PULSE_END ? 0 : t < A.FLASH ? ease((t - A.PULSE_END) / (A.FLASH - A.PULSE_END)) : Math.max(0, 1 - (t - A.FLASH) / 0.9);
    const prev = this.runeAnim?.t ?? 0;
    this.runeAnim = { t: prog, glow, column };
    this.hideGolem = t < A.FLASH;

    if (crossed(A.GLOW)) { this.sfx.setHum(0.25); this.sfx.tone(98, 2.2, "sine", 0.05, 110); }
    if (t >= A.SWEEP && t < A.SWEEP_END) this.sfx.setHum(0.25 + prog * 0.75);
    if (crossed(A.SWEEP)) this.sfx.tone(110, A.SWEEP_END - A.SWEEP, "sine", 0.05, 220);
    if (crossed(A.SWEEP_END)) { this.sfx.activate(); this.shake(0.6, 2); }
    if (crossed(A.PULSE_END)) this.sfx.tone(196, A.FLASH - A.PULSE_END, "triangle", 0.04, 392);
    if (crossed(A.FLASH)) { this.sfx.teleport(); this.shake(0.9, 3.5); this.sfx.setHum(0.2); }
    if (crossed(A.END - 0.5)) this.sfx.setHum(0);

    const px = this.circle.pixels;
    if (glow > 0 && t < A.FLASH && Math.random() < dt * 14 * Math.min(1, glow)) {
      const q = this.runeArt.model.pixels[(Math.random() * px.length) | 0];
      if (carvingVisible(q, prog)) {
        this.spawn({ x: c.x + q.x, y: c.y + q.y, z: 0, vz: 6 + Math.random() * 10, life: 1.2, kind: "rune", col: Math.random() < 0.6 ? "#a070ff" : "#70d0ff", emit: true, g: -2 });
      }
    }
    if (prog > prev) {
      for (const cl of this.runeArt.model.clumps) {
        if (clumpCleared(cl, prog) && !clumpCleared(cl, prev)) this.witherClump(c.x + cl.x, c.y + cl.y, cl.px.length);
      }
      if (t < A.SWEEP_END) this.shake(0.1, 0.3 + prog * 0.8);
    }
    if (t >= A.PULSE_END && t < A.FLASH) {
      this.shake(0.1, 0.4 + column * 2.6);
      for (let i = 0; i < 2 + column * 8; i++) {
        const a = Math.random() * Math.PI * 2, r = 50 + Math.random() * 40;
        this.spawn({ x: c.x + Math.cos(a) * r, y: c.y + Math.sin(a) * r, z: 2 + Math.random() * 6, vx: -Math.cos(a) * r * 1.1, vy: -Math.sin(a) * r * 1.1, vz: 4 + column * 30, life: 0.9, kind: "rune", col: Math.random() < 0.5 ? "#c0a0ff" : "#80e0ff", emit: true, g: -4 });
      }
    }
    if (crossed(A.FLASH)) {
      for (let i = 0; i < 46; i++) {
        const a = Math.random() * Math.PI * 2, v = 30 + Math.random() * 70;
        this.spawn({ x: c.x, y: c.y + 4, z: 4 + Math.random() * 20, vx: Math.cos(a) * v, vy: Math.sin(a) * v * 0.5, vz: 20 + Math.random() * 40, life: 0.8 + Math.random() * 0.6, kind: "spark", col: Math.random() < 0.5 ? "#e8e0ff" : "#a070ff", emit: true, g: 90 });
      }
    }
    const fall = clamp((t - A.FLASH) / A.FALL, 0, 1);
    lk.z = 30 * (1 - fall) ** 2;
    lk.eye = 1; lk.core = 1; lk.dormant = 0;
    this.cam.snap(c.x, c.y, this.area, this.vw, this.vh);
  }

  arriveEnd() {
    this.runeAnim = null;
    this.hideGolem = false;
    this.look.z = 0; this.look.eye = 1; this.look.core = 1; this.look.dormant = 0;
    this.sfx.setHum(0);
  }

  landFx() {
    const pl = this.pl;
    this.sfx.slam(); this.shake(0.35, 2.2);
    for (let i = 0; i < 22; i++) {
      const ang = Math.random() * Math.PI * 2, v = 16 + Math.random() * 30;
      this.spawn({ x: pl.x + Math.cos(ang) * 4, y: pl.y + Math.sin(ang) * 2, z: 1, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v * 0.5, vz: 6 + Math.random() * 12, life: 0.7 + Math.random() * 0.6, kind: "dust", col: Math.random() < 0.5 ? "#8a8478" : "#a09a8c", g: 20 });
    }
    if (!this.hasArm) this.sparkBurst(6);
  }

  sunrise(level: number) {
    if (level <= 0 && !this.view.lights.has("sunrise")) return;
    const pl = this.pl;
    const lt = this.view.dynamicLight("sunrise", () => makeLight(pl.x + 190, pl.y - 30, 330, [1, 0.7, 0.4], 0, 0, "sunrise"));
    lt.int = 0.75 * clamp(level, 0, 1);
  }

  clearParticles() { this.particlesSys.clear(); }
  anyKey() { return this.input.pressed.size > 0; }
  wakeAgain() { this.reset(); this.introUi.start(); }

  witherClump(x: number, y: number, size: number) {
    const cols = ["#3e5e2a", "#527636", "#6e8e34", "#7a6a3a", "#5a4630"];
    for (let i = 0; i < 1 + Math.min(4, size / 6); i++) {
      this.spawn({ x: x + (Math.random() - 0.5) * 6, y: y + (Math.random() - 0.5) * 4, z: 1, vx: 10 + Math.random() * 22, vy: (Math.random() - 0.5) * 10, vz: 12 + Math.random() * 18, life: 0.7 + Math.random() * 0.7, kind: "debris", col: cols[(Math.random() * cols.length) | 0], g: 26 });
    }
    if (Math.random() < 0.6) this.spawn({ x, y, z: 1, vz: 10 + Math.random() * 8, life: 0.8, kind: "rune", col: "#c0a0ff", emit: true, g: -3 });
  }

  arriveOverlay(t: number) {
    const A = ARRIVE, ctx = this.ctx;
    if (t < A.FADE) { ctx.fillStyle = `rgba(0,0,0,${1 - t / A.FADE})`; ctx.fillRect(0, 0, W, H); }
    if (t > A.FLASH && t < A.FLASH + 1 && this.settings.data.flashes) {
      ctx.fillStyle = `rgba(235,240,255,${1 - (t - A.FLASH)})`;
      ctx.fillRect(0, 0, W, H);
    }
  }

  renderCinema() {
    this.renderBars();
    const bar = this.bars.v * this.bars.v * (3 - 2 * this.bars.v);
    drawMonologue(this.ctx, this.monologue, this.t, 7 + Math.round(12 * bar));
  }

  renderSkipHint(t: number) {
    const ctx = this.ctx;
    ctx.globalAlpha = clamp((t - 0.6) * 1.5, 0, 1) * 0.85;
    drawText(ctx, "ESC - SKIP", W - 5, H - 9, "#8a8392", 1, "right");
    ctx.globalAlpha = 1;
  }

  updateWorldFx(dt: number) {
    const pl = this.pl, area = this.area, VW = this.vw, VH = this.vh;
    const plPos = this.clock.interpolatedPos(pl.id, pl.x, pl.y, pl.area);
    this.cam.update(plPos.x, plPos.y, area, VW, VH, dt);
    this.crackFlash = Math.max(0, this.crackFlash - dt);
    if (this.shudder && (this.shudder.t -= dt) <= 0) this.shudder = null;

    const gl = this.glight;
    gl.x = plPos.x; gl.y = plPos.y - 6;
    applyGlow(gl, golemGlow(this.world, pl));
    if (Math.abs(gl.x - gl.vx) > 2 || Math.abs(gl.y - gl.vy) > 2) computeVis(gl, area);
    const base = this.screens.is("tele") ? gl.int : 1.0;
    gl.cur = base * this.look.core * (0.95 + 0.05 * Math.sin(this.t * 13) * Math.sin(this.t * 3.1)) + this.eyeBoost * 0.3;

    const rh = this.reactionHost();
    this.reactor.updateNpcLooks(rh, dt);

    const hour = worldHour(this.world), sun = sunLevel(hour);
    for (const L of this.view.lights.values()) {
      const n = Math.sin(this.t * 9 + L.seed) * 0.5 + Math.sin(this.t * 23.7 + L.seed * 2) * 0.3 + Math.sin(this.t * 3.3 + L.seed) * 0.2;
      L.cur = L.int * (1 - L.flick * (0.5 + 0.5 * n));
      if (L.habit) L.day = litLevel(L.habit, L.owner!, hour);
      else if (L.sky) { const s = skyLight(L.sky, hour); L.r = s.col[0]; L.g = s.col[1]; L.b = s.col[2]; L.day = s.gain; }
    }

    const r = area.ritual, cl = this.view.byId("circle");
    if (r?.active) {
      this.sfx.setHum(Math.min(1, r.actT / 2));
      if (cl) {
        const target = 120;
        if (cl.rad < target) { cl.rad = Math.min(target, cl.rad + dt * 30); if (Math.abs(cl.rad - cl.vx) > 0) computeVis(cl, area); }
        cl.int = 0.6 + Math.min(1, r.actT / 3) * 0.6;
        cl.cur = cl.int * (0.85 + 0.15 * Math.sin(this.t * 3));
      }
      const c = area.ritualPos;
      if (Math.random() < dt * 30) {
        const p = this.circle.pixels[(Math.random() * this.circle.pixels.length) | 0];
        this.spawn({ x: c.x + p.x, y: c.y + p.y, z: 0, vz: 8 + Math.random() * 12, life: 1.5, kind: "rune", col: Math.random() < 0.6 ? "#a070ff" : "#70d0ff", emit: true, g: -2 });
      }
    } else if (cl) {
      cl.cur = cl.int * (0.8 + 0.2 * Math.sin(this.t * 1.3)) + (this.fizzT > 0 ? Math.random() * 0.6 : 0);
    }
    this.fizzT = Math.max(0, this.fizzT - dt);

    if (this.runeDud) {
      const d = this.runeDud;
      if (d.t < 0.7 && Math.random() < dt * 40) {
        const p = this.circle.pixels[(Math.random() * this.circle.pixels.length) | 0];
        this.spawn({ x: d.x + p.x, y: d.y + p.y, z: 1, vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.5) * 30, vz: 20 + Math.random() * 30, life: 0.45, kind: "spark", col: Math.random() < 0.5 ? "#ff6a8a" : "#a070ff", emit: true, g: 120 });
      }
      if ((d.t += dt) >= 1.1) this.runeDud = null;
    }

    const rg = this.view.byId("runeglow");
    if (rg) {
      const st = this.surfaceRuneState();
      rg.cur = rg.int * (st.glow * (0.92 + 0.08 * Math.sin(this.t * 2.3)) + st.column * 0.7);
      if (!this.runeAnim && runeState(this.world, RUNE_NODES.surface) === "linked" && Math.random() < dt * 8) {
        const p = this.circle.pixels[(Math.random() * this.circle.pixels.length) | 0];
        this.spawn({ x: rg.x + p.x, y: rg.y + p.y, z: 0, vz: 6 + Math.random() * 10, life: 1.4, kind: "rune", col: Math.random() < 0.6 ? "#a070ff" : "#70d0ff", emit: true, g: -2 });
      }
    }

    if (this.arriveFade > 0) { this.arriveFade = Math.max(0, this.arriveFade - dt * 1.4); this.look.z = Math.max(0, this.look.z - dt * 24); }
    if (this.doorFade > 0) this.doorFade = Math.max(0, this.doorFade - dt * 2.8);
    if (this.note) { this.note.t += dt; if (this.note.t > 3) this.note = null; }
    this.stepMonologue(dt);

    if (area.base.outdoor && Math.random() < dt * 1.5) {
      this.spawn({ x: this.cam.x - 20 + Math.random() * VW, y: this.cam.y + Math.random() * VH, z: 30 + Math.random() * 40, vx: 8 + Math.random() * 8, vy: (Math.random() - 0.3) * 3, vz: -4 - Math.random() * 3, life: 7, kind: "mote", col: ["#7a5630", "#946a34", "#5a7a34", "#a07c40"][(Math.random() * 4) | 0], emit: false, g: 0 });
    }
    if (area.base.outdoor && Math.random() < dt * 3 * this.zoom * this.zoom * (1 - sun)) {
      this.spawn({ x: this.cam.x + Math.random() * VW, y: this.cam.y + Math.random() * VH, z: 6 + Math.random() * 20, vx: (Math.random() - 0.5) * 4, vy: (Math.random() - 0.5) * 3, life: 4, kind: "mote", col: "#d8f080", emit: true, g: 0 });
    }
    if (area.base.outdoor && Math.random() < dt * 1.2 * this.zoom * this.zoom * sun) {
      this.spawn({ x: this.cam.x + Math.random() * VW, y: this.cam.y + Math.random() * VH, z: 8 + Math.random() * 18, vx: (Math.random() - 0.5) * 10, vy: (Math.random() - 0.5) * 6, life: 5, kind: "mote", col: ["#f0e8c0", "#e8c860", "#d8d0e8", "#e89a5a"][(Math.random() * 4) | 0], emit: false, g: 0 });
    }
    if (area.base.outdoor && (this.skyT -= dt) <= 0) {
      this.skyT = 2.5 + Math.random() * 6;
      if (sun > 0.6) this.sfx.bird(); else if (sun < 0.25) this.sfx.cricket();
    }

    area.drips.forEach((d, i) => {
      this.dripT[i] -= dt;
      if (this.dripT[i] <= 0) {
        this.dripT[i] = 1.5 + Math.random() * 4;
        if (Math.abs(d.x - this.cam.x - VW / 2) < VW / 2 + 100 && Math.abs(d.y - this.cam.y - VH / 2) < VH / 2 + 90) {
          this.spawn({ x: d.x, y: d.y, z: 70, vz: -20, life: 3, kind: "drip", col: "#6a8aa8", g: 140 });
        }
      }
    });

    for (const p of area.props) {
      if (!p.lit) continue;
      const fire = propDef(p.kind).fire;
      if (!fire || this.tendedLevel(p, hour) <= 0.05) continue;
      if (Math.abs(p.x - this.cam.x - VW / 2) > VW / 2 + 40 || Math.abs(p.y - this.cam.y - VH / 2) > VH / 2 + 50) continue;
      if (Math.random() < dt * fire.embers) {
        this.spawn({ x: p.x + (Math.random() - 0.5) * 4, y: p.y + fire.emberDy, z: 14, vx: (Math.random() - 0.5) * 6, vz: 10 + Math.random() * 10, life: 1 + Math.random(), kind: "ember", col: Math.random() < 0.5 ? "#ffb040" : "#ff6a1a", emit: true, g: -4 });
      }
    }

    for (const p of area.props) {
      const sm = propDef(p.kind).smoke;
      if (!sm || Math.abs(p.x - this.cam.x - VW / 2) > VW / 2 + 40 || Math.abs(p.y - this.cam.y - VH / 2) > VH / 2 + 70) continue;
      if (Math.random() < dt * sm.rate * (area.base.tended ? hearthSmoke(hour) : 1)) {
        this.spawn({ x: p.x + sm.dx + (Math.random() - 0.5) * 3, y: p.y, z: sm.z, vx: 3 + Math.random() * 4, vy: (Math.random() - 0.5) * 1.5, vz: 7 + Math.random() * 5, life: 2.2 + Math.random() * 1.8, kind: "smoke", col: Math.random() < 0.5 ? "#6e6a70" : "#585460", g: -1, size: 2, emit: false });
      }
    }

    if (Math.random() < dt * 8 * this.zoom * this.zoom) {
      this.spawn({ x: this.cam.x + Math.random() * VW, y: this.cam.y + Math.random() * VH, z: 4 + Math.random() * 30, vx: (Math.random() - 0.5) * 3, vy: (Math.random() - 0.5) * 2, vz: (Math.random() - 0.5) * 2, life: 5, kind: "mote", col: "#b8b0a0", emit: false, g: 0 });
    }
    const moon = this.view.byId("moon");
    if (moon && Math.random() < dt * 5) {
      this.spawn({ x: moon.x - 14 + Math.random() * 30, y: moon.y + 2, z: 10 + Math.random() * 70, vx: (Math.random() - 0.5) * 2, vz: -3 - Math.random() * 3, life: 6, kind: "mote", col: sun > 0.5 ? "#ffe8b0" : "#a8c0ff", emit: true, g: 0 });
    }
    if (Math.random() < dt * 2) {
      const cands: [number, number][] = [];
      for (const it of interactables(area)) if (it.kind === "item" || it.kind === "propItem" || (it.kind === "container" && it.hasItem)) cands.push([it.x, it.y - (it.itemZ ?? 6) - 2]);
      const near = cands.filter(([x, y]) => Math.abs(x - this.cam.x - VW / 2) < VW / 2 + 10 && Math.abs(y - this.cam.y - VH / 2) < VH / 2 + 10);
      if (near.length) {
        const [x, y] = near[(Math.random() * near.length) | 0];
        this.spawn({ x: x + (Math.random() - 0.5) * 8, y: y + 2, z: 2 + Math.random() * 4, life: 0.45, kind: "glint", col: "#fff4d0", emit: true });
      }
    }
    if (this.debugMsg) { this.debugMsg.t += dt; if (this.debugMsg.t > 2) this.debugMsg = null; }
    if (this.toast) { this.toast.t += dt; if (this.toast.t > 3) this.toast = null; }

    const focus = this.screens.is("play") && this.target ? visionId(this.target) : null;
    for (const c of this.vision.update(dt, this.world, pl, gl, focus, this.visionArt())) {
      this.reactor.onVisionCue(rh, c);
    }
    this.updateParticles(dt);
  }

  private visionArtCache: VisionArt | null = null;
  private visionArt(): VisionArt {
    const a = (this.visionArtCache ??= {
      t: 0,
      npcLook: (x) => this.npcLook(x),
      circle: { lines: [this.circle.glow, this.circle.glowGap], r: CR },
      self: () => (this.hideGolem ? null : this.renderer.selfPose),
    });
    a.t = this.t;
    return a;
  }

  npcLook(a: Actor) { return this.reactor.npcLook(this.world, a); }
  updateParticles(dt: number) { this.particlesSys.update(dt, (x, y) => this.sfx.drip(this.volAt(x, y))); }

  say(text: string) { this.note = { text, t: 0 }; }
  letterbox(on: boolean) { this.bars.to = on ? 1 : 0; if (on) this.bars.v = 1; }
  startPlay() { this.screens.set(this.S.play); }
  renderScene() { this.renderWorldScene(); }

  private stepMonologue(dt: number) {
    const s = this.monologue.update(dt);
    if (s.started) this.sfx.thoughtStart();
    for (let i = 0; i < s.typed; i++) this.sfx.thoughtTick(s.tone === "void");
    const b = this.bars;
    if (b.v !== b.to) b.v = b.to > b.v ? Math.min(b.to, b.v + dt * 4) : Math.max(b.to, b.v - dt * 2.2);
  }

  private renderBars() {
    const b = this.bars.v;
    if (b <= 0) return;
    const e = b * b * (3 - 2 * b), h = Math.round(14 * e);
    this.ctx.fillStyle = "#000";
    this.ctx.fillRect(0, 0, W, h);
    this.ctx.fillRect(0, H - h, W, h);
  }

  read(id: ItemId) {
    const opens = ITEMS[id].opens;
    if (opens === "schematic") this.schemUi.open();
    else if (opens === "book") this.bookUi.open(id);
  }
  boostEye(level: number) { this.eyeBoost = level; }
  animate(dt: number) { this.updateWorldFx(dt); }

  renderNote(y = H - 40) {
    if (!this.note) return;
    const ctx = this.ctx;
    ctx.globalAlpha = clamp(3 - this.note.t, 0, 1);
    drawTextS(ctx, this.note.text, W / 2, y, "#e8d8b0", 1, "center", "#000");
    ctx.globalAlpha = 1;
  }

  // ---------------------------------------------------------------- render
  render() {
    this.ctx.clearRect(0, 0, W, H);
    this.hctx.clearRect(0, 0, UI_W, UI_H);

    // Render screen stack in order, compositing 1x baseUi onto 2x hctx before any hires screen
    const stack = (this.screens as unknown as { stack: Screen[] }).stack;
    let i = stack.length - 1;
    while (i > 0 && !stack[i].opaque) i--;
    let baseDirty = false;
    const flushBase = () => {
      if (!baseDirty) return;
      this.hctx.drawImage(this.baseUi.c, 0, 0, UI_W, UI_H);
      this.ctx.clearRect(0, 0, W, H);
      baseDirty = false;
    };
    for (; i < stack.length; i++) {
      const s = stack[i];
      if (s.hires) {
        flushBase();
        s.render();
      } else {
        s.render();
        baseDirty = true;
      }
    }
    flushBase();

    if (this.screens.is("play")) {
      this.renderHudV2();
    } else if (this.screens.is("title")) {
      this.renderTitleV2Hint();
    }
  }

  private renderWorldScene() {
    this.view.flush();
    this.renderWorld();
    this.renderHud();
  }

  renderWorld() {
    const pal = PALETTES[this.settings.data.palette];
    this.renderer.render(this.wctx, {
      world: this.world,
      pl: this.pl,
      view: this.view,
      cam: this.cam,
      clock: this.clock,
      vw: this.vw,
      vh: this.vh,
      t: this.t,
      look: this.look,
      glight: this.glight,
      particles: this.particlesSys.list,
      vision: this.vision,
      npcLook: (a) => this.npcLook(a),
      tendedLevel: (p, h) => this.tendedLevel(p, h),
      surfaceRuneState: () => this.surfaceRuneState(),
      hideGolem: this.hideGolem,
      gaze: this.gaze,
      eyeBoost: this.eyeBoost,
      crackFlash: this.crackFlash,
      fizzT: this.fizzT,
      shudder: this.shudder,
      screenShake: this.settings.data.screenShake,
      flashes: this.settings.data.flashes,
      selectedIds: this.selectedActors,
      selectionColor: pal.selection,
    });
  }

  renderFolkBubbles(dt: number) {
    const ctx = this.wctx, area = this.area, camX = this.cam.x, camY = this.cam.y;
    for (const [id, b] of this.reactor.bubbles) { b.t += dt; if (b.t > b.dur) this.reactor.bubbles.delete(id); }
    const shop = shopOfArea(area.id), counter = shop && !shopOpen(this.world, shop.id) ? area.base.spots?.find((s) => s.id === "keeper") : undefined;
    if (counter) drawClosedSign(ctx, Math.round(counter.x - camX), Math.round(counter.y - camY) + 12);
    for (const a of this.world.actors) {
      if (a.area !== area.id || !(a.kind === "folk" ? folkPresent(a) && !!a.life : a.kind === "keeper" && keeperPresent(a))) continue;
      const ip = this.clock.interpolatedPos(a.id, a.x, a.y, a.area);
      const x = Math.round(ip.x - camX), y = Math.round(ip.y - camY);
      if (x < -60 || y < -60 || x > this.vw + 60 || y > this.vh + 60) continue;
      if (a.life?.pose === "lie") {
        const k = (this.t * 0.5 + hash01(a.id, 4)) % 1;
        ctx.globalAlpha = Math.sin(k * Math.PI) * 0.8;
        drawTextS(ctx, k < 0.5 ? "z" : "Z", x + 4 + k * 6, y - 26 - k * 10, "#d8e0f0", 1, "left", "#1a1418");
        ctx.globalAlpha = 1;
      }
      const b = this.reactor.bubbles.get(a.id);
      if (!b) continue;
      const fade = clamp(Math.min(b.t / 0.12, (b.dur - b.t) / 0.25), 0, 1);
      const top = y - (a.life?.pose === "sit" ? 27 : a.kind === "keeper" ? 26 : 30);
      ctx.globalAlpha = fade;
      if (b.text) drawSpeech(ctx, b.text, x, top, this.vw);
      else if (b.icon) drawChatIcon(ctx, b.icon, x + 3, top - Math.round((1 - fade) * 3));
      ctx.globalAlpha = 1;
    }
  }

  renderHud() {
    const ctx = this.ctx;
    if (this.screens.is("play") && this.target) {
      const wctx = this.wctx, it = this.target;
      const x = Math.round(it.x - this.cam.x), y = Math.round(it.y - this.cam.y - (it.itemZ ?? 10) - 14 + Math.sin(this.t * 4) * 1.5);
      wctx.fillStyle = "rgba(0,0,0,0.6)";
      wctx.fillRect(x - 3, y, 7, 1); wctx.fillRect(x - 2, y + 1, 5, 1); wctx.fillRect(x - 1, y + 2, 3, 1);
      wctx.fillStyle = "#d8cfa8";
      wctx.fillRect(x - 2, y - 1, 5, 1); wctx.fillRect(x - 1, y, 3, 1); wctx.fillRect(x, y + 1, 1, 1);
    }
    if (this.screens.is("play") || this.screens.is("dialogue")) this.renderFolkBubbles(this.frameDt);
    if (this.arriveFade > 0 && this.settings.data.flashes) { ctx.fillStyle = `rgba(235,240,255,${this.arriveFade})`; ctx.fillRect(0, 0, W, H); }
    if (this.doorFade > 0) { ctx.fillStyle = `rgba(6,5,9,${this.doorFade})`; ctx.fillRect(0, 0, W, H); }
    this.renderBars();
    const bar = this.bars.v * this.bars.v * (3 - 2 * this.bars.v);
    drawMonologue(ctx, this.monologue, this.t, 7 + Math.round(12 * bar));
    if (this.screens.is("play")) { this.renderNote(); this.vision.drawHud(ctx, W); this.renderClock(); }
    if (this.debugMsg) {
      ctx.globalAlpha = clamp(2 - this.debugMsg.t, 0, 1);
      drawTextS(ctx, this.debugMsg.text, W / 2, 6, "#ff9a5a", 1, "center");
      ctx.globalAlpha = 1;
    }
    if (this.debugHud || this.debugNoclip || this.debugSpeed) {
      const pl = this.pl, modes = [this.debugNoclip ? "NOCLIP" : "", this.debugSpeed ? `SPEED X${this.debugSpeedMult}` : ""].filter(Boolean).join("  ");
      const lines = [
        ...(this.debugHud ? [`${pl.area.toUpperCase()}  X ${Math.round(pl.x)}  Y ${Math.round(pl.y)}  TILE ${Math.floor(pl.x / TS)},${Math.floor((pl.y - 3) / TS)}`] : []),
        ...(modes ? [`DEBUG: ${modes}`] : []),
      ];
      lines.forEach((l, i) => drawTextS(ctx, l, 4, H - 8 - (lines.length - 1 - i) * 8, "#ff9a5a", 1, "left", "#000"));
    }
    if (!this.screens.is("schem") && !this.screens.is("dialogue")) this.renderToast(H - 26);
  }

  /** 2x high-resolution HUD overlay: speed bar, notification feed, selection, context menu, tooltips. */
  private renderHudV2() {
    const hctx = this.hctx;
    const pal = PALETTES[this.settings.data.palette];
    this.hits.begin();

    // 1. Notification Feed (top-left)
    this.notifications.draw(hctx, this.input, this.hits, (item: NotificationItem) => {
      if (item.actorId) {
        const a = actorById(this.world, item.actorId);
        if (a && a.area === this.pl.area) this.cam.snap(a.x, a.y, this.area, this.vw, this.vh);
      }
    });

    // 2. Top-right Speed & System Bar
    const speedBarX = UI_W - 214, speedBarY = 6;
    drawPanel2x(hctx, speedBarX, speedBarY, 208, 18, "#121017", "#3e3848");
    const labels: Record<SimSpeed, string> = { 0: "||", 1: "1x", 2: "2x", 4: "4x", 8: "8x" };
    SPEED_PRESETS.forEach((spd, idx) => {
      const bx = speedBarX + 4 + idx * 24;
      const by = speedBarY + 2;
      const r = { x: bx, y: by, w: 22, h: 14 };
      const hov = this.input.mouse.inside && inRect(this.input.mouse.x, this.input.mouse.y, r);
      const act = this.clock.speed === spd;
      drawButton2x(hctx, bx, by, 22, 14, labels[spd], {
        active: act,
        hovered: hov,
        color: act ? (spd === 0 ? pal.warn : pal.valid) : UI.text,
      });
      this.hits.add(`hud.speed.${spd}`, r, {
        tooltip: spd === 0 ? "Pause simulation (P)" : `Set speed ${spd}x`,
        onClick: () => this.clock.setSpeed(spd),
      });
    });

    // Saves & Settings quick buttons
    const savesRect = { x: speedBarX + 128, y: speedBarY + 2, w: 38, h: 14 };
    drawButton2x(hctx, savesRect.x, savesRect.y, savesRect.w, savesRect.h, "Saves", {
      hovered: this.input.mouse.inside && inRect(this.input.mouse.x, this.input.mouse.y, savesRect),
    });
    this.hits.add("hud.saves", savesRect, {
      tooltip: "Save Slots & Export (Esc)",
      onClick: () => this.systemUi.open(0),
    });

    const setRect = { x: speedBarX + 168, y: speedBarY + 2, w: 36, h: 14 };
    drawButton2x(hctx, setRect.x, setRect.y, setRect.w, setRect.h, "Set", {
      hovered: this.input.mouse.inside && inRect(this.input.mouse.x, this.input.mouse.y, setRect),
    });
    this.hits.add("hud.settings", setRect, {
      tooltip: "Settings & Accessibility (O)",
      onClick: () => this.settingsUi.open(),
    });

    // 3. Paused banner & Selection pill
    if (this.clock.speed === 0) {
      drawPanel2x(hctx, UI_W / 2 - 42, 6, 84, 16, "#1a1216", pal.warn);
      drawPropTextS(hctx, "PAUSED", UI_W / 2, 10, pal.warn, 1, "center");
    }
    if (this.selectedActors.size > 0) {
      drawPanel2x(hctx, 6, UI_H - 26, 134, 20, "#121017", pal.selection);
      drawPropTextS(hctx, `Selected: ${this.selectedActors.size}`, 14, UI_H - 20, pal.selection);
    }

    // 4. Drag-select box
    const drag = this.input.currentDragRect();
    if (drag) {
      hctx.fillStyle = "rgba(127, 232, 255, 0.14)";
      hctx.fillRect(drag.x0, drag.y0, drag.x1 - drag.x0, drag.y1 - drag.y0);
      hctx.fillStyle = pal.selection;
      hctx.fillRect(drag.x0, drag.y0, drag.x1 - drag.x0, 1);
      hctx.fillRect(drag.x0, drag.y1, drag.x1 - drag.x0, 1);
      hctx.fillRect(drag.x0, drag.y0, 1, drag.y1 - drag.y0);
      hctx.fillRect(drag.x1, drag.y0, 1, drag.y1 - drag.y0);
    }

    // 5. Context Menu & Tooltips
    this.contextMenu.draw(hctx);
    if (this.hits.tooltip && !this.contextMenu.open) {
      drawTooltip(hctx, this.hits.tooltip);
    }
  }

  private renderTitleV2Hint() {
    drawPropText(this.hctx, "O: Settings   L: Load Save   Click or Press Any Key to Begin", UI_W / 2, UI_H - 16, UI.mid, 1, "center");
  }

  renderClock() {
    if (!this.area.base.outdoor && !hasFlag(this.world, FLAGS.tutorialDone)) return;
    const ctx = this.ctx, hour = worldHour(this.world), ph = phaseAt(hour), x = W - 35, y = H - 11;
    ctx.fillStyle = "rgba(6,5,9,0.6)"; ctx.fillRect(x - 3, y - 2, 36, 11);
    const px = (c: string, cells: number[][]) => { ctx.fillStyle = c; for (const [cx, cy, w = 1, h = 1] of cells) ctx.fillRect(x + cx, y + cy, w, h); };
    if (ph === "day") {
      px("#ffb030", [[3, 0], [3, 6], [0, 3], [6, 3], [1, 1], [5, 1], [1, 5], [5, 5]]);
      px("#ffd860", [[2, 2, 3, 3]]);
    } else if (ph === "night") {
      px("#c8d4f0", [[2, 1, 3, 1], [1, 2, 2, 1], [1, 3, 2, 1], [1, 4, 3, 1], [2, 5, 3, 1]]);
      px("#7a88b0", [[5, 2], [6, 0]]);
    } else {
      px("#ff9a40", [[2, 3, 3, 2], [1, 4, 5, 1], [3, 1], [1, 2], [5, 2]]);
      px("#8a5a3a", [[0, 5, 7, 1]]);
    }
    drawText(ctx, clockText(hour), x + 10, y + 1, ph === "night" ? "#a8b4d8" : ph === "day" ? "#e8d8a0" : "#f0b078");
  }

  renderToast(y: number) {
    const ctx = this.ctx;
    if (this.toast) {
      const t = this.toast.t;
      const a = t < 0.2 ? t / 0.2 : t > 2.5 ? 1 - (t - 2.5) / 0.5 : 1;
      ctx.globalAlpha = clamp(a, 0, 1);
      const name = this.toast.name;
      const w = name.length * 4 + 30;
      const x = Math.round(W / 2 - w / 2);
      ctx.fillStyle = "#0c0a0e"; ctx.fillRect(x, y, w, 20);
      ctx.fillStyle = "#3a3540"; ctx.fillRect(x, y, w, 1); ctx.fillRect(x, y + 19, w, 1); ctx.fillRect(x, y, 1, 20); ctx.fillRect(x + w - 1, y, 1, 20);
      ctx.drawImage(this.toast.icon.a, x + 3, y + 2);
      drawText(ctx, name, x + 23, y + 8, "#d8d0b8");
      ctx.globalAlpha = 1;
    }
  }
}

function visionId(t: Target): string | null {
  return t.propId ?? t.looseId ?? t.actorId ?? (t.tx !== undefined && t.ty !== undefined ? `tile:${t.tx},${t.ty}` : null);
}
