// Area registry & dynamic area builders (AreaSpec).
// Authored areas keep deterministic builders and diff-based saves; runtime-created
// areas (floors, caves, outposts, wilds, player-built) are constructed from a saved
// AreaSpec { id, kind, seed, w, h, parent, depth } via AREA_BUILDERS[kind].
import { mulberry } from "../core/rng";
import { TS, T, FS, WS } from "../content/tiles";
import { buildDungeon, type AreaData, type PropDef, type LightDef, type Room, type LooseItem } from "../map";
import { buildSurface } from "../surface";
import { buildTown } from "../town";
import { INTERIOR_BUILDERS } from "../townInteriors";

/** Minimum dimensions that keep a 2x zoomed viewport inside bounds. */
export const MIN_DYNAMIC_W = 44;
export const MIN_DYNAMIC_H = 26;

export interface AreaSpec {
  id: string;
  kind: string;
  seed: number;
  w: number;
  h: number;
  parent?: string;
  depth: number;
  /** True for authored areas (saved as diff against builder); false/omitted for generated/player-built areas. */
  authored?: boolean;
  /** Optional builder parameters. */
  params?: Record<string, number | string | boolean>;
}

export const AREAS: Record<string, () => AreaData> = {
  dungeon: buildDungeon,
  surface: buildSurface,
  // Westwake, the market town west of the surface, and the six rooms behind its shop doors.
  town: buildTown,
  ...INTERIOR_BUILDERS,
};

/** Build a procedural subterranean floor (rooms, corridors, pillars, rocks, torches). */
function buildProceduralFloor(spec: AreaSpec): AreaData {
  const w = Math.max(MIN_DYNAMIC_W, spec.w);
  const h = Math.max(MIN_DYNAMIC_H, spec.h);
  const rng = mulberry(spec.seed ^ (spec.depth * 2654435761));
  const grid = new Uint8Array(w * h);
  const plan = new Uint8Array(w * h);
  const style = new Uint8Array(w * h);
  const tvar = new Uint8Array(w * h);
  const props: PropDef[] = [];
  const lights: LightDef[] = [];
  const loose: LooseItem[] = [];
  const rooms: Room[] = [];

  for (let i = 0; i < w * h; i++) {
    grid[i] = T.WALL;
    tvar[i] = Math.floor(rng() * 4);
    style[i] = WS.STONE;
  }

  const carve = (rx: number, ry: number, rw: number, rh: number, fs: number = FS.FLAG) => {
    for (let y = Math.max(2, ry); y < Math.min(h - 2, ry + rh); y++) {
      for (let x = Math.max(2, rx); x < Math.min(w - 2, rx + rw); x++) {
        const idx = y * w + x;
        grid[idx] = T.FLOOR;
        style[idx] = fs;
      }
    }
  };

  // Entry hall
  const cx = Math.floor(w / 2), cy = Math.floor(h / 2);
  const entryW = 9, entryH = 7;
  const ex0 = Math.max(3, cx - 4), ey0 = Math.max(3, cy - 3);
  carve(ex0, ey0, entryW, entryH, FS.COBBLE);
  rooms.push({ num: 1, name: `DEPTH ${spec.depth} LANDING`, x: ex0, y: ey0, w: entryW, h: entryH });

  // Carve satellite chambers connected by halls
  const count = 3 + Math.floor(rng() * 3);
  for (let i = 0; i < count; i++) {
    const rw = 6 + Math.floor(rng() * 5);
    const rh = 5 + Math.floor(rng() * 4);
    const rx = 3 + Math.floor(rng() * Math.max(1, w - rw - 6));
    const ry = 3 + Math.floor(rng() * Math.max(1, h - rh - 6));
    carve(rx, ry, rw, rh, rng() < 0.5 ? FS.FLAG : FS.COBBLE);
    rooms.push({ num: i + 2, name: `CHAMBER ${i + 1}`, x: rx, y: ry, w: rw, h: rh });

    // Corridor from room center to entry hall center
    const rcx = Math.floor(rx + rw / 2), rcy = Math.floor(ry + rh / 2);
    const xMin = Math.min(cx, rcx), xMax = Math.max(cx, rcx);
    const yMin = Math.min(cy, rcy), yMax = Math.max(cy, rcy);
    carve(xMin, cy - 1, xMax - xMin + 2, 2, FS.FLAG);
    carve(rcx - 1, yMin, 2, yMax - yMin + 2, FS.FLAG);

    // Place a torch and a rock or chest in the room
    const tx = rx + 1, ty = ry;
    if (grid[(ty - 1) * w + tx] === T.WALL) {
      const pid = `torch@${tx},${ty}`;
      props.push({ id: pid, kind: "torch", x: tx * TS + 8, y: ty * TS + 4, v: 0, lit: true });
      lights.push({ x: tx * TS + 8, y: ty * TS + 4, rad: 88, col: [1.0, 0.72, 0.36], int: 0.78, flick: 0.14, owner: pid });
    }
    if (rng() < 0.75) {
      const rkx = rx + Math.floor(rw / 2), rky = ry + Math.floor(rh / 2);
      const kind = spec.depth >= 2 && rng() < 0.45 ? "vein" : "rock";
      props.push({ id: `${kind}@${rkx},${rky}`, kind, x: rkx * TS + 8, y: rky * TS + 12, v: Math.floor(rng() * 3) });
    }
  }

  // Entry hall torch
  const eTorchId = `torch@${ex0 + 2},${ey0}`;
  props.push({ id: eTorchId, kind: "torch", x: (ex0 + 2) * TS + 8, y: ey0 * TS + 4, v: 0, lit: true });
  lights.push({ x: (ex0 + 2) * TS + 8, y: ey0 * TS + 4, rad: 100, col: [1.0, 0.75, 0.4], int: 0.85, flick: 0.12, owner: eTorchId });

  return {
    id: spec.id,
    w, h,
    grid, plan, style, tvar,
    rooms,
    props,
    decals: [],
    lights,
    loose,
    start: { x: cx * TS + 8, y: cy * TS + 10 },
    exits: [],
    drips: [{ x: (cx - 2) * TS + 8, y: (cy - 1) * TS + 8 }],
  };
}

/** Build a procedural natural cave floor. */
function buildProceduralCave(spec: AreaSpec): AreaData {
  const w = Math.max(MIN_DYNAMIC_W, spec.w);
  const h = Math.max(MIN_DYNAMIC_H, spec.h);
  const rng = mulberry(spec.seed ^ (spec.depth * 1597334677));
  const grid = new Uint8Array(w * h);
  const plan = new Uint8Array(w * h);
  const style = new Uint8Array(w * h);
  const tvar = new Uint8Array(w * h);
  const props: PropDef[] = [];
  const lights: LightDef[] = [];

  for (let i = 0; i < w * h; i++) {
    grid[i] = T.WALL;
    style[i] = WS.STONE;
    tvar[i] = Math.floor(rng() * 4);
  }

  // Random walk cavern carving from center
  let wx = Math.floor(w / 2), wy = Math.floor(h / 2);
  const cx = wx, cy = wy;
  const steps = Math.floor(w * h * 0.55);
  for (let s = 0; s < steps; s++) {
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const nx = wx + dx, ny = wy + dy;
      if (nx >= 3 && ny >= 3 && nx < w - 3 && ny < h - 3) {
        grid[ny * w + nx] = T.FLOOR;
        style[ny * w + nx] = FS.EARTH;
      }
    }
    const dir = Math.floor(rng() * 4);
    if (dir === 0 && wx < w - 5) wx++;
    else if (dir === 1 && wx > 4) wx--;
    else if (dir === 2 && wy < h - 5) wy++;
    else if (dir === 3 && wy > 4) wy--;
    if (rng() < 0.03) { wx = cx; wy = cy; }
  }

  // Scatter rocks and iron veins
  for (let y = 4; y < h - 4; y += 3) {
    for (let x = 4; x < w - 4; x += 3) {
      if (grid[y * w + x] !== T.FLOOR) continue;
      if (Math.hypot(x - cx, y - cy) < 3) continue;
      if (rng() < 0.16) {
        const kind = rng() < 0.4 ? "vein" : "rock";
        props.push({ id: `${kind}@${x},${y}`, kind, x: x * TS + 8, y: y * TS + 12, v: Math.floor(rng() * 3) });
      }
    }
  }

  const brazierId = `brazier@${cx - 2},${cy}`;
  props.push({ id: brazierId, kind: "brazier", x: (cx - 2) * TS + 8, y: cy * TS + 12, v: 0, lit: true });
  lights.push({ x: (cx - 2) * TS + 8, y: cy * TS + 6, rad: 110, col: [1.0, 0.72, 0.35], int: 0.85, flick: 0.15, owner: brazierId });

  return {
    id: spec.id,
    w, h,
    grid, plan, style, tvar,
    rooms: [{ num: 1, name: `CAVERN DEPTH ${spec.depth}`, x: 3, y: 3, w: w - 6, h: h - 6 }],
    props,
    decals: [],
    lights,
    loose: [],
    start: { x: cx * TS + 8, y: cy * TS + 10 },
    exits: [],
    drips: [{ x: (cx + 2) * TS + 8, y: cy * TS + 8 }],
  };
}

/** Build a procedural outdoor outpost / generated wilds area. */
function buildProceduralWild(spec: AreaSpec): AreaData {
  const w = Math.max(MIN_DYNAMIC_W, spec.w);
  const h = Math.max(MIN_DYNAMIC_H, spec.h);
  const rng = mulberry(spec.seed ^ (spec.depth * 2246822519));
  const grid = new Uint8Array(w * h);
  const plan = new Uint8Array(w * h);
  const style = new Uint8Array(w * h);
  const tvar = new Uint8Array(w * h);
  const props: PropDef[] = [];
  const lights: LightDef[] = [];

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = y * w + x;
      tvar[idx] = Math.floor(rng() * 4);
      const border = x < 2 || y < 2 || x >= w - 2 || y >= h - 2;
      grid[idx] = border ? T.WALL : T.FLOOR;
      style[idx] = border ? WS.STONE : (rng() < 0.72 ? FS.GRASS : FS.EARTH);
    }
  }

  const cx = Math.floor(w / 2), cy = Math.floor(h / 2);
  for (let y = cy - 2; y <= cy + 2; y++) {
    for (let x = cx - 2; x <= cx + 2; x++) {
      style[y * w + x] = FS.EARTH;
    }
  }

  // Campfire or brazier at center if outpost
  if (spec.kind === "outpost") {
    const bid = `brazier@${cx - 1},${cy - 1}`;
    props.push({ id: bid, kind: "brazier", x: (cx - 1) * TS + 8, y: (cy - 1) * TS + 12, v: 0, lit: true });
    lights.push({ x: (cx - 1) * TS + 8, y: (cy - 1) * TS + 6, rad: 120, col: [1.0, 0.72, 0.36], int: 0.9, flick: 0.14, owner: bid });
    props.push({ id: `chest@${cx + 2},${cy - 1}`, kind: "chest", x: (cx + 2) * TS + 8, y: (cy - 1) * TS + 12, v: 0, container: true });
  }

  // Trees & rocks around clearing
  for (let y = 4; y < h - 4; y += 3) {
    for (let x = 4; x < w - 4; x += 3) {
      if (Math.hypot(x - cx, y - cy) < 5) continue;
      const r = rng();
      if (r < 0.24) props.push({ id: `tree@${x},${y}`, kind: "tree", x: x * TS + 8, y: y * TS + 12, v: Math.floor(rng() * 3) });
      else if (r < 0.34) props.push({ id: `rock@${x},${y}`, kind: "rock", x: x * TS + 8, y: y * TS + 12, v: Math.floor(rng() * 3) });
    }
  }

  return {
    id: spec.id,
    w, h,
    grid, plan, style, tvar,
    rooms: [{ num: 1, name: spec.kind === "outpost" ? "OUTPOST CLEARING" : "GENERATED WILDS", x: 2, y: 2, w: w - 4, h: h - 4 }],
    props,
    decals: [],
    lights,
    loose: [],
    outdoor: true,
    ambient: [0.09, 0.11, 0.16],
    start: { x: cx * TS + 8, y: cy * TS + 12 },
    exits: [],
    drips: [],
  };
}

/** Build a blank player-built room/floor enclosed by walls. */
function buildBlankArea(spec: AreaSpec): AreaData {
  const w = Math.max(MIN_DYNAMIC_W, spec.w);
  const h = Math.max(MIN_DYNAMIC_H, spec.h);
  const grid = new Uint8Array(w * h);
  const plan = new Uint8Array(w * h);
  const style = new Uint8Array(w * h);
  const tvar = new Uint8Array(w * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = y * w + x;
      const wall = x < 2 || y < 2 || x >= w - 2 || y >= h - 2;
      grid[i] = wall ? T.WALL : T.FLOOR;
      style[i] = wall ? WS.STONE : FS.FLAG;
      tvar[i] = (x + y) % 4;
    }
  }
  const cx = Math.floor(w / 2), cy = Math.floor(h / 2);
  return {
    id: spec.id,
    w, h,
    grid, plan, style, tvar,
    rooms: [{ num: 1, name: `FLOOR ${spec.depth}`, x: 2, y: 2, w: w - 4, h: h - 4 }],
    props: [],
    decals: [],
    lights: [],
    loose: [],
    start: { x: cx * TS + 8, y: cy * TS + 10 },
    exits: [],
    drips: [],
  };
}

/**
 * Builder registry selected by `AreaSpec.kind`.
 * Authored areas ignore spec size/seed (their layout is authored); generated areas
 * build deterministically from `spec`.
 */
export const AREA_BUILDERS: Record<string, (spec: AreaSpec) => AreaData> = {
  dungeon: () => buildDungeon(),
  surface: () => buildSurface(),
  town: () => buildTown(),
  ...Object.fromEntries(Object.entries(INTERIOR_BUILDERS).map(([k, fn]) => [k, () => fn()])),
  floor: buildProceduralFloor,
  cave: buildProceduralCave,
  outpost: buildProceduralWild,
  wild: buildProceduralWild,
  blank: buildBlankArea,
};

export function authoredSpec(id: string): AreaSpec | null {
  const build = AREAS[id];
  if (!build) return null;
  const data = build();
  return {
    id,
    kind: id,
    seed: id === "dungeon" ? 1337 : 0,
    w: data.w,
    h: data.h,
    depth: id === "dungeon" ? 1 : 0,
    authored: true,
  };
}

export function buildAreaFromSpec(spec: AreaSpec): AreaData {
  const fn = AREA_BUILDERS[spec.kind] ?? (AREAS[spec.id] ? () => AREAS[spec.id]() : undefined);
  if (!fn) throw new Error(`unknown area kind "${spec.kind}"`);
  const data = fn(spec);
  return data.id === spec.id ? data : { ...data, id: spec.id };
}
