// Multi-slot save management, rolling backups, autosave and corrupted-save
// recovery. Pure (no DOM / browser APIs): backed by an injected async
// SaveBackend (IndexedDB in browser, MemorySaveBackend in tests).
import { player, type World } from "./world";
import { exportSaveString, serialize, tryLoadSave, type LoadRecoveryResult } from "./save";

export const SAVE_SLOTS = ["autosave", "slot1", "slot2", "slot3"] as const;
export type SaveSlotId = (typeof SAVE_SLOTS)[number] | string;

export const MAX_BACKUPS_PER_SLOT = 2;

export interface SaveMeta {
  slotId: string;
  label: string;
  savedAt: number;
  playTime: number;
  day: number;
  area: string;
  version: number;
  sizeBytes: number;
  corrupted?: boolean;
}

export interface SaveBackend {
  get(key: string): Promise<string | null>;
  set(key: string, value: string): Promise<void>;
  del(key: string): Promise<void>;
  keys(): Promise<string[]>;
}

/** In-memory SaveBackend for headless tests and non-browser environments. */
export class MemorySaveBackend implements SaveBackend {
  private map = new Map<string, string>();
  async get(key: string) { return this.map.get(key) ?? null; }
  async set(key: string, value: string) { this.map.set(key, value); }
  async del(key: string) { this.map.delete(key); }
  async keys() { return [...this.map.keys()]; }
  /** Test helper: overwrite raw slot bytes directly (e.g. to simulate corruption). */
  corruptRaw(key: string, value: string) { this.map.set(key, value); }
  rawMap() { return this.map; }
}

const primaryKey = (slotId: string) => `save:${slotId}`;
const backupKey = (slotId: string, idx: number) => `backup:${slotId}:${idx}`;
const metaKey = (slotId: string) => `meta:${slotId}`;

export class SaveManager {
  constructor(private backend: SaveBackend) {}

  /** Save `world` to `slotId`, rotating existing primary data into rolling backups. */
  async saveSlot(slotId: string, world: World, label?: string): Promise<SaveMeta> {
    const existing = await this.backend.get(primaryKey(slotId));
    if (existing) {
      // Only rotate valid JSON into backups so a corrupted primary never overwrites a good backup.
      if (tryLoadSave(existing)) {
        for (let i = MAX_BACKUPS_PER_SLOT; i >= 2; i--) {
          const prev = await this.backend.get(backupKey(slotId, i - 1));
          if (prev !== null) await this.backend.set(backupKey(slotId, i), prev);
        }
        await this.backend.set(backupKey(slotId, 1), existing);
      }
    }
    const data = serialize(world);
    const json = JSON.stringify(data);
    await this.backend.set(primaryKey(slotId), json);

    const pl = player(world);
    const meta: SaveMeta = {
      slotId,
      label: label ?? (slotId === "autosave" ? "Autosave" : slotId.toUpperCase()),
      savedAt: Date.now(),
      playTime: world.playTime,
      day: world.day,
      area: pl?.area ?? "dungeon",
      version: data.version,
      sizeBytes: json.length,
    };
    await this.backend.set(metaKey(slotId), JSON.stringify(meta));
    return meta;
  }

  /** Load a slot, automatically recovering from rolling backups if primary is corrupted. */
  async loadSlot(slotId: string): Promise<(LoadRecoveryResult & { slotId: string }) | null> {
    const primary = await this.backend.get(primaryKey(slotId));
    const backups: (string | null)[] = [];
    for (let i = 1; i <= MAX_BACKUPS_PER_SLOT; i++) {
      backups.push(await this.backend.get(backupKey(slotId, i)));
    }
    const res = tryLoadSave(primary, backups);
    if (!res) return null;
    return { ...res, slotId };
  }

  /** Export a slot (or live world) as a portable save file string. */
  async exportSlot(slotId: string): Promise<string | null> {
    const loaded = await this.loadSlot(slotId);
    if (!loaded) return null;
    return exportSaveString(loaded.world);
  }

  /** Delete a slot and all its rolling backups & metadata. */
  async deleteSlot(slotId: string): Promise<void> {
    await this.backend.del(primaryKey(slotId));
    await this.backend.del(metaKey(slotId));
    for (let i = 1; i <= MAX_BACKUPS_PER_SLOT; i++) {
      await this.backend.del(backupKey(slotId, i));
    }
  }

  /** List metadata for all known slots (autosave + slot1..slot3 + any custom slots). */
  async listSlots(): Promise<(SaveMeta | null)[]> {
    const allKeys = await this.backend.keys();
    const known = new Set<string>(SAVE_SLOTS);
    for (const k of allKeys) {
      if (k.startsWith("save:")) known.add(k.slice(5));
    }
    const out: (SaveMeta | null)[] = [];
    for (const id of known) {
      const rawMeta = await this.backend.get(metaKey(id));
      const hasPrimary = (await this.backend.get(primaryKey(id))) !== null;
      if (!rawMeta && !hasPrimary) {
        out.push(null);
        continue;
      }
      if (rawMeta) {
        try {
          const parsed = JSON.parse(rawMeta) as SaveMeta;
          out.push(parsed);
          continue;
        } catch {
          // Fall through to metadata reconstruction
        }
      }
      out.push({
        slotId: id,
        label: id,
        savedAt: 0,
        playTime: 0,
        day: 0,
        area: "unknown",
        version: 0,
        sizeBytes: 0,
        corrupted: true,
      });
    }
    return out;
  }

  /** Load the most recently saved valid slot (used by Quick Load / Continue). */
  async loadLatest(): Promise<(LoadRecoveryResult & { slotId: string }) | null> {
    const list = (await this.listSlots()).filter((m): m is SaveMeta => !!m && !m.corrupted);
    list.sort((a, b) => b.savedAt - a.savedAt);
    for (const m of list) {
      const res = await this.loadSlot(m.slotId);
      if (res) return res;
    }
    return null;
  }
}
