// Simulation Level-of-Detail (LOD) and area catch-up.
// Three tiers:
//   - Active (in view / near player): full step every tick
//   - Near   (same area, off-camera): staggered lower-rate step (1/4 tick rate)
//   - Far    (other areas): routine/idle actors skip per-tick work and catch up
//            via schedule ("set down where the hour says") on area entry using
//            `world.time - area.lastTicked`. Active cross-area jobs step at Far rate.
import type { Actor, World } from "../world/world";
import { getArea, player } from "../world/world";
import { isFolk, settle, STALE } from "./folk";

export type SimLod = "active" | "near" | "far";

export interface ViewBounds {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
}

export const NEAR_STEP_STRIDE = 4;
export const FAR_JOB_STRIDE = 4;
const VIEW_PAD = 64;

/** Deterministic integer hash of actor id for staggered LOD buckets. */
export function actorBucket(id: string): number {
  let h = 2166136261;
  for (let i = 0; i < id.length; i++) {
    h ^= id.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h >>> 0;
}

/** Classify an actor into Active / Near / Far LOD relative to the player and camera view. */
export function classifyActorLod(w: World, a: Actor, view?: ViewBounds): SimLod {
  const pl = player(w);
  if (!pl || a.id === w.playerId) return "active";
  if (a.area !== pl.area) return "far";
  if (view) {
    if (
      a.x >= view.x0 - VIEW_PAD &&
      a.x <= view.x1 + VIEW_PAD &&
      a.y >= view.y0 - VIEW_PAD &&
      a.y <= view.y1 + VIEW_PAD
    ) {
      return "active";
    }
    return "near";
  }
  // When no view window is supplied (headless unit tests), treat the current area as Active.
  return "active";
}

/**
 * Decide whether `a` steps on this tick and by what dt multiplier.
 * Deterministic for any (w.time, a.id) so save/load and 1x/8x replays match.
 */
export function shouldStepLod(
  a: Actor,
  lod: SimLod,
  tick: number,
  bucket: number,
): { step: boolean; mult: number } {
  if (lod === "active") return { step: true, mult: 1 };
  if (lod === "near") {
    // Never delay an unsettled townsperson's initial settle on area entry.
    if (a.life && a.life.seen < -1e8) return { step: true, mult: 1 };
    return (tick + bucket) % NEAR_STEP_STRIDE === 0
      ? { step: true, mult: NEAR_STEP_STRIDE }
      : { step: false, mult: 0 };
  }
  // Far tier: only actors carrying an active task or running player job advance in background.
  const hasWork = !!a.task || (!!a.job && a.job.status === "running");
  if (!hasWork) return { step: false, mult: 0 };
  return (tick + bucket) % FAR_JOB_STRIDE === 0
    ? { step: true, mult: FAR_JOB_STRIDE }
    : { step: false, mult: 0 };
}

/**
 * Catch up an area when the player enters it after time has elapsed elsewhere.
 * Uses `world.time - area.lastTicked` to advance ritual timers and settle
 * schedule-driven residents where the current hour says.
 */
export function catchUpArea(w: World, areaId: string): number {
  const area = getArea(w, areaId);
  const elapsed = Math.max(0, w.time - area.lastTicked);
  if (elapsed > 0 && area.ritual?.active) {
    area.advanceRitual(elapsed);
  }
  if (elapsed > 0) {
    for (const a of w.actors) {
      if (a.area !== areaId) continue;
      if (isFolk(a) && !a.task && (!a.job || a.job.status === "done")) {
        if (w.time - a.life!.seen > STALE || elapsed > STALE) {
          settle(w, a);
          a.life!.seen = w.time;
        }
      }
    }
  }
  area.lastTicked = w.time;
  return elapsed;
}
