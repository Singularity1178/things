// Fixed-timestep simulation clock, speed control, actor interpolation state,
// and deterministic input-stream replay. Pure (no DOM): tested headless.
import type { Facing } from "../golem";
import type { PlayerInput } from "./step";
import type { World } from "../world/world";

export const SIM_HZ = 60;
export const SIM_DT = 1 / SIM_HZ;
export const SPEED_PRESETS = [0, 1, 2, 4, 8] as const;
export type SimSpeed = (typeof SPEED_PRESETS)[number];

/** Maximum fixed ticks executed in a single host frame (prevents spiral of death). */
const MAX_TICKS_PER_FRAME = 32;
const TELEPORT_SNAP_DIST = 40;

export interface ActorSnapshot {
  x: number;
  y: number;
  area: string;
  facing: Facing;
}

export interface RecordedTick {
  tick: number;
  input: PlayerInput;
}

export interface ReplayLog {
  seed?: number;
  tickHz: number;
  frames: RecordedTick[];
}

/**
 * Fixed-timestep accumulator and render-interpolation tracker.
 * Decouples simulation step cadence from browser frame rate while supporting
 * pause / 1x / 2x / 4x / 8x speeds and deterministic replays.
 */
export class SimClock {
  accumulator = 0;
  speed: SimSpeed = 1;
  tickCount = 0;
  alpha = 1;
  private prev = new Map<string, ActorSnapshot>();
  private curr = new Map<string, ActorSnapshot>();

  reset(w?: World) {
    this.accumulator = 0;
    this.tickCount = 0;
    this.alpha = 1;
    this.prev.clear();
    this.curr.clear();
    if (w) this.capture(w, true);
  }

  setSpeed(s: SimSpeed) {
    this.speed = s;
    if (s === 0) this.accumulator = 0;
  }

  cycleSpeed(dir: 1 | -1 = 1): SimSpeed {
    const idx = SPEED_PRESETS.indexOf(this.speed);
    const next = SPEED_PRESETS[(idx + dir + SPEED_PRESETS.length) % SPEED_PRESETS.length];
    this.setSpeed(next);
    return next;
  }

  /** Snapshot actor positions before/after a tick for sub-tick interpolation. */
  capture(w: World, init = false) {
    if (init) {
      this.prev.clear();
      this.curr.clear();
      for (const a of w.actors) {
        const snap: ActorSnapshot = { x: a.x, y: a.y, area: a.area, facing: a.facing };
        this.prev.set(a.id, snap);
        this.curr.set(a.id, { ...snap });
      }
      return;
    }
    this.prev = this.curr;
    this.curr = new Map();
    for (const a of w.actors) {
      this.curr.set(a.id, { x: a.x, y: a.y, area: a.area, facing: a.facing });
    }
  }

  /**
   * Advance the accumulator by `realDt` scaled by `this.speed`.
   * Executes `onTick(SIM_DT, tickIndex)` for each whole fixed step.
   * Returns the number of fixed ticks executed.
   */
  advance(realDt: number, w: World, onTick: (dt: number, tickOffset: number) => void): number {
    if (this.speed === 0 || realDt <= 0) {
      this.alpha = 1;
      return 0;
    }
    // Clamp raw frame dt so tab-switching never stalls the browser, then scale by speed.
    const clampedReal = Math.min(0.1, realDt);
    this.accumulator += clampedReal * this.speed;

    let steps = 0;
    while (this.accumulator + 1e-9 >= SIM_DT && steps < MAX_TICKS_PER_FRAME) {
      this.accumulator = Math.max(0, this.accumulator - SIM_DT);
      onTick(SIM_DT, steps);
      this.tickCount++;
      steps++;
    }
    if (steps >= MAX_TICKS_PER_FRAME && this.accumulator > SIM_DT) {
      this.accumulator = this.accumulator % SIM_DT;
    }
    if (steps > 0) this.capture(w, false);
    this.alpha = Math.max(0, Math.min(1, this.accumulator / SIM_DT));
    return steps;
  }

  /** Interpolated world position for actor `id` at current `alpha`. */
  interpolatedPos(id: string, fallbackX: number, fallbackY: number, area: string): { x: number; y: number } {
    const c = this.curr.get(id);
    const p = this.prev.get(id);
    if (!c || !p || c.area !== area || p.area !== area) {
      return { x: fallbackX, y: fallbackY };
    }
    if (Math.hypot(c.x - p.x, c.y - p.y) > TELEPORT_SNAP_DIST) {
      return { x: fallbackX, y: fallbackY };
    }
    const a = this.alpha;
    return {
      x: p.x + (c.x - p.x) * a,
      y: p.y + (c.y - p.y) * a,
    };
  }
}

/**
 * Records per-tick player inputs for deterministic replay across speeds (1x vs 8x).
 */
export class InputRecorder {
  frames: RecordedTick[] = [];

  record(tick: number, input: PlayerInput) {
    this.frames.push({ tick, input: { ...input } });
  }

  exportLog(seed?: number): ReplayLog {
    return { seed, tickHz: SIM_HZ, frames: this.frames.map((f) => ({ tick: f.tick, input: { ...f.input } })) };
  }
}

/**
 * Latch helper so single-frame edge inputs (E, Space, C, Z) are never dropped
 * when accumulator < SIM_DT, and never fired multiple times in one frame at 8x.
 */
export class EdgeInputLatch {
  use = false;
  attack = false;
  core = false;
  toggleScan = false;

  push(edges: { use?: boolean; attack?: boolean; core?: boolean; toggleScan?: boolean }) {
    if (edges.use) this.use = true;
    if (edges.attack) this.attack = true;
    if (edges.core) this.core = true;
    if (edges.toggleScan) this.toggleScan = true;
  }

  consume(): { use: boolean; attack: boolean; core: boolean; toggleScan: boolean } {
    const out = { use: this.use, attack: this.attack, core: this.core, toggleScan: this.toggleScan };
    this.use = false;
    this.attack = false;
    this.core = false;
    this.toggleScan = false;
    return out;
  }

  clear() {
    this.use = false;
    this.attack = false;
    this.core = false;
    this.toggleScan = false;
  }
}

/**
 * Run a deterministic replay stream against a World using `stepFn`, simulating
 * browser frames at any `speed` (1x, 2x, 4x, 8x) with fixed SIM_DT ticks.
 */
export function runDeterministicReplay(
  w: World,
  stream: readonly PlayerInput[],
  speed: SimSpeed,
  stepFn: (world: World, dt: number, input: PlayerInput) => void,
): { ticksRun: number; framesRun: number } {
  if (speed === 0) return { ticksRun: 0, framesRun: 0 };
  const clock = new SimClock();
  clock.setSpeed(speed);
  clock.capture(w, true);
  let cursor = 0;
  let framesRun = 0;
  // Step with realistic 60Hz browser frame deltas until all `stream.length` ticks have executed.
  while (cursor < stream.length) {
    const remaining = stream.length - cursor;
    // Use exact frame dt so remaining ticks aren't overshot at >1x speeds.
    const frameDt = Math.min(SIM_DT, (remaining * SIM_DT) / speed);
    clock.advance(frameDt, w, (dt) => {
      if (cursor >= stream.length) return;
      stepFn(w, dt, stream[cursor++]);
    });
    framesRun++;
  }
  return { ticksRun: cursor, framesRun };
}
