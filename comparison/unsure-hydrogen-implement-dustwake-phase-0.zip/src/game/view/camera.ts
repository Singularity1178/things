// Camera controller: smooth tracking, zoom-centered resizing, clamping, and screen shake.
import { TS } from "../content/tiles";
import { clamp } from "../util";
import type { Area } from "../world/area";

export class Camera {
  x = 0;
  y = 0;
  shakeT = 0;
  shakeMag = 0;

  shake(t: number, m: number, enabled = true) {
    if (!enabled) return;
    this.shakeT = Math.max(this.shakeT, t);
    this.shakeMag = Math.max(this.shakeMag, m);
  }

  clearShake() {
    this.shakeT = 0;
    this.shakeMag = 0;
  }

  snap(targetX: number, targetY: number, area: Area, vw: number, vh: number) {
    this.x = clamp(targetX - vw / 2, 0, Math.max(0, area.w * TS - vw));
    this.y = clamp(targetY - 12 - vh / 2, 0, Math.max(0, area.h * TS - vh));
  }

  onResize(oldW: number, oldH: number, newW: number, newH: number, area?: Area) {
    this.x -= (newW - oldW) / 2;
    this.y -= (newH - oldH) / 2;
    if (area) {
      this.x = clamp(this.x, 0, Math.max(0, area.w * TS - newW));
      this.y = clamp(this.y, 0, Math.max(0, area.h * TS - newH));
    }
  }

  update(targetX: number, targetY: number, area: Area, vw: number, vh: number, dt: number) {
    const tx = clamp(targetX - vw / 2, 0, Math.max(0, area.w * TS - vw));
    const ty = clamp(targetY - 12 - vh / 2, 0, Math.max(0, area.h * TS - vh));
    this.x += (tx - this.x) * Math.min(1, dt * 3.5);
    this.y += (ty - this.y) * Math.min(1, dt * 3.5);
    this.shakeT = Math.max(0, this.shakeT - dt);
    if (this.shakeT <= 0) this.shakeMag = 0;
  }

  shakenPos(enabled = true): { camX: number; camY: number } {
    let sx = 0, sy = 0;
    if (enabled && this.shakeT > 0) {
      sx = (Math.random() - 0.5) * this.shakeMag * 2;
      sy = (Math.random() - 0.5) * this.shakeMag * 2;
    }
    return { camX: Math.round(this.x + sx), camY: Math.round(this.y + sy) };
  }
}
