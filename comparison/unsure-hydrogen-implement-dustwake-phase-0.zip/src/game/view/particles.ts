// Particle system extracted from Game (0.6).
export interface Particle {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  max: number;
  kind: "spark" | "ember" | "dust" | "debris" | "drip" | "splash" | "rune" | "mote" | "glint" | "smoke";
  col: string;
  emit: boolean;
  g: number;
  size: number;
}

const MAX_PARTICLES = 900;

export class ParticleSystem {
  list: Particle[] = [];

  clear() {
    this.list = [];
  }

  spawn(p: Partial<Particle> & { x: number; y: number }) {
    if (this.list.length > MAX_PARTICLES) return;
    this.list.push({
      z: 0,
      vx: 0,
      vy: 0,
      vz: 0,
      life: 1,
      max: p.life ?? 1,
      kind: "dust",
      col: "#888",
      emit: false,
      g: 0,
      size: 1,
      ...p,
    } as Particle);
  }

  update(dt: number, onDrip?: (x: number, y: number) => void) {
    const ps = this.list;
    for (let i = ps.length - 1; i >= 0; i--) {
      const p = ps[i];
      p.life -= dt / p.max;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vz -= p.g * dt;
      p.z += p.vz * dt;
      if (p.kind === "debris" || p.kind === "spark" || p.kind === "dust") {
        if (p.z < 0) {
          p.z = 0;
          p.vz = -p.vz * 0.35;
          p.vx *= 0.6;
          p.vy *= 0.6;
        }
      }
      if (p.kind === "drip" && p.z <= 0) {
        for (let k = 0; k < 5; k++) {
          this.spawn({
            x: p.x,
            y: p.y,
            z: 0,
            vx: (Math.random() - 0.5) * 20,
            vy: (Math.random() - 0.5) * 8,
            vz: 12 + Math.random() * 8,
            life: 0.35,
            kind: "splash",
            col: "#7a9ab8",
            g: 80,
          });
        }
        onDrip?.(p.x, p.y);
        p.life = 0;
      }
      if (p.kind === "mote") {
        p.vx += (Math.random() - 0.5) * dt * 4;
        p.vz += (Math.random() - 0.5) * dt * 4;
      }
      if (p.kind === "smoke") {
        p.vx *= 0.97;
        p.vy *= 0.97;
      }
      if (p.life <= 0) ps.splice(i, 1);
    }
  }
}
