// Browser persistence: IndexedDB multi-slot backend (with localStorage fallback),
// legacy v1..v19 save import, and file export/import helpers.
import { saveToStorage as saveSync, loadFromStorage as loadSync, exportSaveString, importSaveString } from "../world/save";
import { SaveManager, MemorySaveBackend, type SaveBackend } from "../world/saveStore";
import type { World } from "../world/world";

const DB_NAME = "dustwake_saves";
const DB_VERSION = 1;
const STORE_NAME = "kv";
const LS_PREFIX = "dustwake.v2.";

export const saveToStorage = (w: World) => saveSync(w, localStorage);
export const loadFromStorage = () => loadSync(localStorage);

/**
 * IndexedDB SaveBackend with transparent fallback to localStorage / memory
 * when running in restricted iframes or headless environments.
 */
export class IndexedDbSaveBackend implements SaveBackend {
  private dbPromise: Promise<IDBDatabase | null> | null = null;
  private memFallback = new MemorySaveBackend();

  private openDb(): Promise<IDBDatabase | null> {
    if (this.dbPromise) return this.dbPromise;
    this.dbPromise = new Promise((resolve) => {
      if (typeof indexedDB === "undefined") {
        resolve(null);
        return;
      }
      try {
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = () => {
          const db = req.result;
          if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME);
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => resolve(null);
      } catch {
        resolve(null);
      }
    });
    return this.dbPromise;
  }

  async get(key: string): Promise<string | null> {
    const db = await this.openDb();
    if (!db) {
      if (typeof localStorage !== "undefined") return localStorage.getItem(LS_PREFIX + key);
      return this.memFallback.get(key);
    }
    return new Promise((resolve) => {
      try {
        const tx = db.transaction(STORE_NAME, "readonly");
        const req = tx.objectStore(STORE_NAME).get(key);
        req.onsuccess = () => resolve(typeof req.result === "string" ? req.result : null);
        req.onerror = () => resolve(null);
      } catch {
        resolve(null);
      }
    });
  }

  async set(key: string, value: string): Promise<void> {
    const db = await this.openDb();
    if (!db) {
      if (typeof localStorage !== "undefined") {
        try { localStorage.setItem(LS_PREFIX + key, value); } catch { /* ignore quota */ }
      } else {
        await this.memFallback.set(key, value);
      }
      return;
    }
    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(STORE_NAME, "readwrite");
        tx.objectStore(STORE_NAME).put(value, key);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error ?? new Error("IndexedDB write failed"));
      } catch (err) {
        reject(err);
      }
    });
  }

  async del(key: string): Promise<void> {
    const db = await this.openDb();
    if (!db) {
      if (typeof localStorage !== "undefined") localStorage.removeItem(LS_PREFIX + key);
      else await this.memFallback.del(key);
      return;
    }
    return new Promise((resolve) => {
      try {
        const tx = db.transaction(STORE_NAME, "readwrite");
        tx.objectStore(STORE_NAME).delete(key);
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      } catch {
        resolve();
      }
    });
  }

  async keys(): Promise<string[]> {
    const db = await this.openDb();
    if (!db) {
      if (typeof localStorage !== "undefined") {
        const out: string[] = [];
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          if (k && k.startsWith(LS_PREFIX)) out.push(k.slice(LS_PREFIX.length));
        }
        return out;
      }
      return this.memFallback.keys();
    }
    return new Promise((resolve) => {
      try {
        const tx = db.transaction(STORE_NAME, "readonly");
        const req = tx.objectStore(STORE_NAME).getAllKeys();
        req.onsuccess = () => resolve((req.result ?? []).map(String));
        req.onerror = () => resolve([]);
      } catch {
        resolve([]);
      }
    });
  }
}

let defaultManager: SaveManager | null = null;
let legacyMigrated = false;

export function getSaveManager(): SaveManager {
  if (!defaultManager) defaultManager = new SaveManager(new IndexedDbSaveBackend());
  return defaultManager;
}

/** Migrate legacy single-slot localStorage save (`dustwake.save`) into `slot1` once. */
export async function migrateLegacyLocalStorage(mgr = getSaveManager()): Promise<boolean> {
  if (legacyMigrated || typeof localStorage === "undefined") return false;
  legacyMigrated = true;
  try {
    const legacy = localStorage.getItem("dustwake.save");
    if (!legacy) return false;
    const existing = await mgr.loadSlot("slot1");
    if (existing) return false;
    const w = importSaveString(legacy);
    await mgr.saveSlot("slot1", w, "Legacy Save");
    return true;
  } catch {
    return false;
  }
}

/** Trigger a browser file download of the current world save. */
export function downloadWorldSave(w: World, filename = `dustwake-day${Math.floor(w.day) + 1}.dustwake.json`) {
  if (typeof document === "undefined") return;
  const json = exportSaveString(w);
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/** Open a file picker in the browser to import a `.dustwake.json` save file. */
export function pickAndImportSave(onWorld: (w: World) => void, onError?: (err: string) => void) {
  if (typeof document === "undefined") return;
  const input = document.createElement("input");
  input.type = "file";
  input.accept = ".json,.dustwake.json,application/json";
  input.onchange = async () => {
    const file = input.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const w = importSaveString(text);
      onWorld(w);
    } catch (err) {
      onError?.(err instanceof Error ? err.message : "Could not import save file");
    }
  };
  input.click();
}
