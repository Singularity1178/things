// World Renderer extracted from Game (0.6): draws the lit scene at view
// resolution (vw x vh), interpolating actor positions between fixed sim ticks.
import { TS, T } from "../content/tiles";
import { ITEMS, isGlyph, glyphItem } from "../content/items";
import { FLAGS } from "../content/flags";
import { GLYPHS } from "../content/glyphs";
import { propDef } from "../content/props";
import { propLook } from "../content/digging";
import { ambientAt, lampGain, sunLevel, type RGB } from "../content/daycycle";
import { runeMarks } from "../sim/gear";
import { worldHour, exposureOf } from "../sim/daytime";
import type { SimClock } from "../sim/clock";
import { propSprite } from "../art/props";
import { rubbleSprite, pillarSprite, doorSprite, barsSprite } from "../art/tiles";
import { itemIcon, glyphPattern } from "../art/items";
import { makeCanvas, Pen, Sprite, hash2, clamp, lerp, makeSprite } from "../util";
import { drawGolem, slamPose, type GolemPose, type Facing } from "../golem";
import { Lighting, type Light } from "../light";
import { buildCircle, CircleArt, CR } from "../circle";
import { SurfaceRuneArt } from "../surfaceRune";
import { drawActor, type Look as NpcPoseLook } from "./actors";
import type { AreaView } from "./areaView";
import type { VisionView } from "./vision";
import type { Camera } from "./camera";
import type { Particle } from "./particles";
import { hasFlag, type Actor, type World } from "../world/world";
import type { PropInst } from "../world/area";

const BURIED_AMBIENT: RGB = [0.05, 0.045, 0.065];

export interface GolemLook {
  eye: number;
  core: number;
  dormant: number;
  sparkT: number;
  sputter: number;
  z: number;
}

export interface WorldRenderState {
  world: World;
  pl: Actor;
  view: AreaView;
  cam: Camera;
  clock: SimClock;
  vw: number;
  vh: number;
  t: number;
  look: GolemLook;
  glight: Light;
  particles: readonly Particle[];
  vision: VisionView;
  npcLook: (a: Actor) => NpcPoseLook;
  tendedLevel: (p: PropInst, hour: number) => number;
  surfaceRuneState: () => { t: number; glow: number; column: number };
  hideGolem: boolean;
  gaze: Facing | null;
  eyeBoost: number;
  crackFlash: number;
  fizzT: number;
  shudder: { tx: number; ty: number; t: number } | null;
  screenShake: boolean;
  flashes: boolean;
  selectedIds?: ReadonlySet<string>;
  selectionColor?: string;
}

export class WorldRenderer {
  scene: ReturnType<typeof makeCanvas>;
  emit: ReturnType<typeof makeCanvas>;
  lighting: Lighting;
  outImg: ImageData;
  circle: CircleArt = buildCircle();
  shaft: Sprite;
  sunShaft: Sprite;
  selfPose: { pose: GolemPose; x: number; y: number } | null = null;
  private runeArtCache: SurfaceRuneArt | null = null;

  constructor(wctx: CanvasRenderingContext2D, vw: number, vh: number) {
    this.scene = makeCanvas(vw, vh);
    this.emit = makeCanvas(vw, vh);
    this.lighting = new Lighting(vw, vh);
    this.outImg = wctx.createImageData(vw, vh);
    this.shaft = this.buildShaft(["#1c2638", "#121a28", "#26324a"]);
    this.sunShaft = this.buildShaft(["#4a3a1c", "#33280f", "#5e4a22"]);
  }

  get runeArt() {
    return (this.runeArtCache ??= new SurfaceRuneArt(this.circle.pixels));
  }

  resize(wctx: CanvasRenderingContext2D, vw: number, vh: number) {
    this.scene = makeCanvas(vw, vh);
    this.emit = makeCanvas(vw, vh);
    this.lighting = new Lighting(vw, vh);
    this.outImg = wctx.createImageData(vw, vh);
  }

  private buildShaft(cols: [string, string, string]): Sprite {
    const FOOT = 150, FADE = 0.55;
    return makeSprite(80, FOOT + 10, 40, FOOT, 1, (p) => {
      for (let y = 0; y < FOOT + 10; y++) {
        const t = y / FOOT;
        const cx = lerp(22, 40, t), hw = lerp(7, 24, t);
        const k = clamp(t / FADE, 0, 1), dens = k * k * (3 - 2 * k);
        for (let x = 0; x < 80; x++) {
          const d = Math.abs(x - cx) / hw;
          if (y > FOOT) {
            const e = ((x - 40) / 26) ** 2 + ((y - FOOT - 2) / 7) ** 2;
            if (e < 1 && (x + y) % 2 === 0) p.g(x, y, 1, 1, cols[2]);
            continue;
          }
          if (d < 1 && (x + y) % 2 === 0 && hash2(x, y, 2) > d * 0.8 && hash2(x, y, 5) < dens) {
            p.g(x, y, 1, 1, d < 0.5 ? cols[0] : cols[1]);
          }
        }
      }
    });
  }

  eyeSpot(st: Pick<WorldRenderState, "hideGolem" | "pl" | "look" | "clock">): { x: number; y: number; w: number; show: boolean } | null {
    if (st.hideGolem) return null;
    const pl = st.pl, lk = st.look, f = pl.facing;
    const pos = st.clock.interpolatedPos(pl.id, pl.x, pl.y, pl.area);
    const y = Math.round(pos.y - lk.z) - 18 + Math.round(lk.dormant * 4) + Math.round(lk.dormant * 3);
    const x = Math.round(pos.x) + (f === "right" ? 2 : f === "left" ? -4 : -2);
    return { x, y, w: f === "down" ? 4 : 2, show: f !== "up" };
  }

  render(wctx: CanvasRenderingContext2D, st: WorldRenderState) {
    const sc = this.scene.ctx, ec = this.emit.ctx;
    const area = st.view.area;
    const { camX, camY } = st.cam.shakenPos(st.screenShake);
    const W = st.vw, H = st.vh;
    const hour = worldHour(st.world);

    sc.fillStyle = "#000"; sc.fillRect(0, 0, W, H);
    ec.fillStyle = "#000"; ec.fillRect(0, 0, W, H);
    st.view.prepare(camX, camY, W, H);
    st.view.idle();
    sc.drawImage(st.view.bg.c, camX, camY, W, H, 0, 0, W, H);

    const spr = (s: Sprite, x: number, y: number) => {
      const dx = Math.round(x - s.ax - camX), dy = Math.round(y - s.ay - camY);
      if (dx > W || dy > H || dx + s.w < 0 || dy + s.h < 0) return;
      sc.drawImage(s.a, dx, dy);
      ec.drawImage(s.e, dx, dy);
    };

    const daylight = sunLevel(hour);
    if (area.base.interior && daylight > 0) for (const pt of area.base.portals ?? []) {
      if (!pt.door || pt.dir !== "down") continue;
      const x = pt.x - 1 - camX, y = pt.y + 4 - camY, ww = pt.w + 2;
      sc.globalAlpha = daylight; sc.fillStyle = "#cfc49c"; sc.fillRect(x, y, ww, 6); sc.fillStyle = "#f0e8c8"; sc.fillRect(x + 1, y + 2, ww - 2, 3); sc.globalAlpha = 1;
      ec.globalAlpha = daylight * 0.45; ec.fillStyle = "#a89868"; ec.fillRect(x, y, ww, 6); ec.globalAlpha = 1;
    }

    const r = area.ritual;
    if (r) {
      const c = area.ritualPos;
      const schemRead = hasFlag(st.world, FLAGS.knowSchematic);
      const ccx = c.x - CR - camX, ccy = c.y - CR - camY;
      if (ccx > -140 && ccx < W + 10 && ccy > -140 && ccy < H + 10) {
        sc.drawImage(this.circle.base, ccx, ccy);
        sc.drawImage(r.carved ? this.circle.gapCarved : this.circle.chalk, ccx, ccy);
        let lvl = r.active ? 0.55 + 0.35 * Math.sin(st.t * 3) + Math.min(0.3, r.actT * 0.1) : 0.16 + 0.06 * Math.sin(st.t * 1.3);
        if (st.fizzT > 0 && st.flashes) lvl = Math.random() * 0.8;
        ec.globalAlpha = clamp(lvl, 0, 1);
        ec.drawImage(this.circle.glow, ccx, ccy);
        if (r.carved) ec.drawImage(this.circle.glowGap, ccx, ccy);
        if (!r.carved && schemRead) { ec.globalAlpha = 0.45 + 0.3 * Math.sin(st.t * 4); ec.drawImage(this.circle.ghost, ccx, ccy); }
        if (r.active) {
          ec.globalCompositeOperation = "lighter";
          ec.globalAlpha = 0.35 + 0.25 * Math.sin(st.t * 5);
          ec.drawImage(this.circle.glow, ccx, ccy);
          ec.drawImage(this.circle.glowGap, ccx, ccy);
          ec.globalCompositeOperation = "source-over";
        }
        ec.globalAlpha = 1;
      }
    }

    for (const p of area.props) if (p.kind === "runecircle") this.drawSurfaceRune(p, camX, camY, st);

    type D = { y: number; f: () => void };
    const list: D[] = [];
    const vx0 = camX - 48, vx1 = camX + W + 48, vy0 = camY - 16, vy1 = camY + H + 60;
    for (const p of area.props) {
      if (p.x < vx0 || p.x > vx1 || p.y < vy0 || p.y > vy1) continue;
      if (p.kind === "pedestal") {
        const i = Number(p.id.slice(3));
        list.push({ y: p.y, f: () => this.drawPedestal(p, i, spr, camX, camY, st) });
        continue;
      }
      const def = propDef(p.kind);
      const lvl = def.habit ? st.tendedLevel(p, hour) : 1;
      const alt = def.alt === "lit" ? !!p.lit && lvl > 0.05 : def.alt === "taken" ? p.taken : p.open;
      const s = propSprite(p.kind, propLook(p), alt);
      if (!s) continue;
      if (lvl <= 0.01 && def.habit === "window") continue;
      list.push({
        y: def.wallMounted ? p.y - 0.5 : def.flat ? p.y - 16 : p.y,
        f: () => {
          if (lvl < 1 && def.alt !== "lit") this.drawDimmed(s, p, lvl, def.habit === "window", camX, camY, W, H);
          else if (def.sway && !alt) this.drawSwaying(s, p, camX, camY, st.t, W, H);
          else spr(s, p.x, p.y);
          if (p.lit && def.fire && lvl > 0.05) this.drawFlame(p, def.fire.big, camX, camY, st.t);
          if (p.item && !p.container && !p.taken && ITEMS[p.item].showOnProp !== false) {
            const ic = itemIcon(p.item);
            const bob = isGlyph(p.item) ? Math.round(Math.sin(st.t * 2) * 0.6) : 0;
            spr(ic, p.x + (def.itemDx ?? 0), p.y - (p.itemZ ?? 8) + bob);
          }
        },
      });
    }

    for (const l of area.loose) {
      if (l.taken || l.x < vx0 || l.x > vx1 || l.y < vy0 || l.y > vy1) continue;
      list.push({ y: l.y, f: () => spr(itemIcon(l.item), l.x, l.y + 2) });
    }

    const AW = area.w;
    const tx0 = Math.max(0, Math.floor(camX / TS) - 1), tx1 = Math.min(AW - 1, Math.floor((camX + W) / TS) + 1);
    const ty0 = Math.max(0, Math.floor(camY / TS) - 1), ty1 = Math.min(area.h - 1, Math.floor((camY + H) / TS) + 3);
    for (let ty = ty0; ty <= ty1; ty++) {
      for (let tx = tx0; tx <= tx1; tx++) {
        const t = area.grid[ty * AW + tx];
        const x = tx * TS + 8, y = ty * TS + 16;
        if (t === T.RUBBLE) {
          const s = rubbleSprite(Math.floor(hash2(tx, ty, 5) * 3), false);
          list.push({ y, f: () => spr(s, x, y) });
        } else if (t === T.CRACKED) {
          const s = rubbleSprite(0, true);
          const sh = st.shudder;
          const jx = sh && sh.tx === tx && ty >= sh.ty && ty <= sh.ty + 2 ? Math.round(Math.sin(st.t * 80) * 2 * Math.min(1, sh.t / 0.3)) : 0;
          list.push({
            y,
            f: () => {
              spr(s, x + jx, y);
              if (st.crackFlash > 0 && st.flashes) {
                ec.globalAlpha = st.crackFlash;
                ec.drawImage(s.e, Math.round(x + jx - s.ax - camX), Math.round(y - s.ay - camY));
                ec.globalAlpha = 1;
              }
            },
          });
        } else if (t === T.PILLAR) {
          const s = pillarSprite(area.tvar[ty * AW + tx] === 1);
          list.push({ y, f: () => spr(s, x, y) });
        } else if (t === T.LOCKED) {
          const s = doorSprite();
          list.push({ y, f: () => spr(s, x, y) });
        } else if (t === T.BARS) {
          const s = barsSprite();
          list.push({ y, f: () => spr(s, x, y) });
        }
      }
    }

    for (const a of st.world.actors) {
      if (a.id === st.world.playerId || a.area !== area.id) continue;
      const ip = st.clock.interpolatedPos(a.id, a.x, a.y, a.area);
      if (ip.x < vx0 || ip.x > vx1 || ip.y < vy0 || ip.y > vy1) continue;
      const drawActorAt = () => {
        if (st.selectedIds?.has(a.id)) {
          sc.fillStyle = st.selectionColor ?? "#7fe8ff";
          sc.fillRect(Math.round(ip.x - camX - 7), Math.round(ip.y - camY - 2), 14, 1);
          sc.fillRect(Math.round(ip.x - camX - 7), Math.round(ip.y - camY + 2), 14, 1);
        }
        const savedX = a.x, savedY = a.y;
        a.x = ip.x; a.y = ip.y;
        drawActor(sc, ec, st.world, a, camX, camY, st.t, st.npcLook(a));
        a.x = savedX; a.y = savedY;
      };
      list.push({ y: ip.y, f: drawActorAt });
    }

    const pl = st.pl;
    const plPos = st.clock.interpolatedPos(pl.id, pl.x, pl.y, pl.area);
    if (!st.hideGolem) list.push({ y: plPos.y, f: () => this.drawPlayer(camX, camY, plPos.x, plPos.y, st) });

    for (const p of st.particles) {
      if (p.kind === "debris" || p.kind === "dust" || p.kind === "smoke" || p.kind === "splash") {
        list.push({
          y: p.y,
          f: () => {
            sc.fillStyle = p.col;
            const s = p.size;
            sc.fillRect(Math.round(p.x - camX), Math.round(p.y - p.z - camY), s, s);
            if (p.emit === false) {
              ec.fillStyle = "#000";
              ec.fillRect(Math.round(p.x - camX), Math.round(p.y - p.z - camY), s, s);
            }
          },
        });
      }
    }

    list.sort((a, b) => a.y - b.y);
    for (const d of list) d.f();

    const moon = st.view.byId("moon");
    if (moon) {
      const sun = daylight, mx = Math.round(moon.x - this.shaft.ax - camX), my = Math.round(moon.y + 2 - this.shaft.ay - camY);
      ec.globalCompositeOperation = "lighter";
      if (sun < 1) { ec.globalAlpha = 1 - sun; ec.drawImage(this.shaft.e, mx, my); }
      if (sun > 0) { ec.globalAlpha = sun; ec.drawImage(this.sunShaft.e, mx, my); }
      ec.globalAlpha = 1; ec.globalCompositeOperation = "source-over";
    }

    for (const p of st.particles) {
      if (p.kind === "debris" || p.kind === "dust" || p.kind === "smoke" || p.kind === "splash") continue;
      const x = Math.round(p.x - camX), y = Math.round(p.y - p.z - camY);
      if (x < -2 || y < -2 || x > W + 2 || y > H + 2) continue;
      if (p.kind === "glint") {
        const a = Math.sin(clamp(p.life, 0, 1) * Math.PI);
        ec.globalCompositeOperation = "lighter";
        ec.fillStyle = `rgba(255,240,200,${a})`;
        ec.fillRect(x, y, 1, 1);
        if (a > 0.5) { ec.fillStyle = `rgba(255,240,200,${a * 0.5})`; ec.fillRect(x - 1, y, 3, 1); ec.fillRect(x, y - 1, 1, 3); }
        ec.globalCompositeOperation = "source-over";
        continue;
      }
      if (p.emit) {
        ec.globalCompositeOperation = "lighter";
        ec.globalAlpha = clamp(p.life * 1.5, 0, 1);
        ec.fillStyle = p.col; ec.fillRect(x, y, p.size, p.size);
        ec.globalAlpha = 1;
        ec.globalCompositeOperation = "source-over";
      } else if (p.kind === "mote") {
        sc.fillStyle = p.col; sc.fillRect(x, y, 1, 1);
      } else {
        sc.fillStyle = p.col; sc.fillRect(x, y, p.size, p.size);
      }
    }

    const sImg = sc.getImageData(0, 0, W, H);
    const eImg = ec.getImageData(0, 0, W, H);
    const active: Light[] = st.hideGolem ? [] : [st.glight];
    for (const L of st.view.lights.values()) if (L.on) active.push(L);
    this.lighting.accumulate(active, camX, camY);
    const exposure = exposureOf(area);
    this.lighting.compose(sImg.data, eImg.data, this.outImg.data, ambientAt(area.base.ambient ?? BURIED_AMBIENT, hour, exposure), 6, lampGain(hour, exposure));
    wctx.putImageData(this.outImg, 0, 0);

    const eye = this.eyeSpot(st);
    st.vision.draw(wctx, st.pl, camX, camY, W, H, st.t, eye && { x: eye.x + eye.w / 2 - 1, y: eye.y, w: eye.w, show: eye.show });
  }

  drawSurfaceRune(p: PropInst, camX: number, camY: number, st: WorldRenderState) {
    const rs = st.surfaceRuneState();
    const ccx = Math.round(p.x - CR - camX), ccy = Math.round(p.y - CR - camY);
    if (ccx > -140 && ccx < st.vw + 10 && ccy > -140 && ccy < st.vh + 10) {
      const sc = this.scene.ctx, ec = this.emit.ctx;
      const L = this.runeArt.layers(rs.t);
      sc.drawImage(L.scene, ccx, ccy);
      if (rs.glow > 0) {
        ec.globalAlpha = clamp(rs.glow, 0, 1);
        ec.drawImage(L.emit, ccx, ccy);
        if (rs.glow > 1) {
          ec.globalCompositeOperation = "lighter";
          ec.globalAlpha = clamp(rs.glow - 1, 0, 1);
          ec.drawImage(L.emit, ccx, ccy);
          ec.globalCompositeOperation = "source-over";
        }
        ec.globalAlpha = 1;
      }
    }
    if (rs.column > 0) this.drawSummonColumn(p.x - camX, p.y - camY, rs.column, st.t);
  }

  drawSummonColumn(x: number, y: number, k: number, t: number) {
    const ec = this.emit.ctx;
    x = Math.round(x); y = Math.round(y);
    const w = Math.round(3 + 7 * k);
    ec.globalCompositeOperation = "lighter";
    for (let yy = y + 4; yy > -2; yy -= 2) {
      const f = 1 - ((y - yy) / Math.max(1, y + 2)) * 0.6;
      const wob = Math.round(Math.sin(yy * 0.21 + t * 9) * k);
      ec.globalAlpha = clamp(k * f * 0.5, 0, 1); ec.fillStyle = "#9a70ff"; ec.fillRect(x - w + wob, yy - 2, w * 2, 2);
      ec.globalAlpha = clamp(k * f, 0, 1); ec.fillStyle = "#e8e0ff"; ec.fillRect(x - 1 + wob, yy - 2, 2 + Math.round(k * 2), 2);
    }
    ec.globalAlpha = clamp(k * 0.6, 0, 1); ec.fillStyle = "#c0a0ff"; ec.fillRect(x - 14, y - 3, 28, 8);
    ec.globalAlpha = 1;
    ec.globalCompositeOperation = "source-over";
  }

  private drawDimmed(s: Sprite, p: PropInst, lvl: number, whole: boolean, camX: number, camY: number, vw: number, vh: number) {
    const dx = Math.round(p.x - s.ax - camX), dy = Math.round(p.y - s.ay - camY);
    if (dx > vw || dy > vh || dx + s.w < 0 || dy + s.h < 0) return;
    const sc = this.scene.ctx, ec = this.emit.ctx;
    if (whole) sc.globalAlpha = lvl;
    sc.drawImage(s.a, dx, dy);
    sc.globalAlpha = 1;
    if (lvl > 0.01) { ec.globalAlpha = lvl; ec.drawImage(s.e, dx, dy); ec.globalAlpha = 1; }
  }

  drawSwaying(s: Sprite, p: PropInst, camX: number, camY: number, t: number, vw: number, vh: number) {
    const dx = Math.round(p.x - s.ax - camX), dy = Math.round(p.y - s.ay - camY);
    if (dx > vw || dy > vh || dx + s.w < 0 || dy + s.h < 0) return;
    const sc = this.scene.ctx, ec = this.emit.ctx;
    const wv = Math.sin(t * 1.6 + p.x * 0.031 + p.y * 0.017) + 0.4 * Math.sin(t * 3.7 + p.x * 0.11);
    const o = Math.round(wv * 0.75);
    if (!o) { sc.drawImage(s.a, dx, dy); ec.drawImage(s.e, dx, dy); return; }
    const cut = Math.floor(s.h * 0.55);
    for (const [src, ctx] of [[s.a, sc], [s.e, ec]] as const) {
      ctx.drawImage(src, 0, 0, s.w, cut, dx + o, dy, s.w, cut);
      ctx.drawImage(src, 0, cut, s.w, s.h - cut, dx, dy + cut, s.w, s.h - cut);
    }
  }

  drawFlame(p: PropInst, big: boolean, camX: number, camY: number, tNow: number) {
    const ec = this.emit.ctx;
    const bx = Math.round(p.x - camX), by = Math.round(p.y - camY - 15 + (propDef(p.kind).fire?.dy ?? 0));
    const t = tNow * 12 + p.x;
    const cols = ["#ff5a10", "#ff9a30", "#ffd060", "#fff0b0"];
    const w = big ? 8 : 3;
    for (let i = 0; i < w; i++) {
      const hgt = Math.max(1, Math.round((big ? 7 : 4) * (1 - Math.abs(i - (w - 1) / 2) / w) + Math.sin(t + i * 1.7) * 1.5 + Math.sin(t * 1.7 + i) * 0.8));
      for (let j = 0; j < hgt; j++) {
        const k = Math.min(3, Math.floor((j / hgt) * 4));
        ec.fillStyle = cols[3 - k];
        if (j === hgt - 1) ec.fillStyle = cols[0];
        ec.fillRect(bx - Math.floor(w / 2) + i, by - j + (big ? 2 : 0), 1, 1);
      }
    }
  }

  drawPedestal(p: PropInst, i: number, spr: (s: Sprite, x: number, y: number) => void, camX: number, camY: number, st: WorldRenderState) {
    const s = propSprite("pedestal", 0, false)!;
    spr(s, p.x, p.y);
    const area = st.view.area, r = area.ritual!;
    const g = r.sockets[i];
    const ec = this.emit.ctx;
    const topY = p.y - 15;
    if (g >= 0) {
      spr(itemIcon(glyphItem(g)), p.x, topY + 4);
      if (r.active) {
        const pen = new Pen(ec, true);
        glyphPattern(pen, g, Math.round(p.x - camX) - 4, Math.round(topY - camY) - 7, GLYPHS[g].color, true);
      }
      if (r.wrong[i] && st.fizzT > 0 && st.flashes && Math.sin(st.t * 30) > 0) {
        ec.fillStyle = "#ff2040";
        ec.globalAlpha = 0.6;
        ec.fillRect(Math.round(p.x - camX) - 6, Math.round(topY - camY) - 8, 12, 12);
        ec.globalAlpha = 1;
      }
    }
    if (hasFlag(st.world, FLAGS.knowSchematic) && g !== r.solution[i] && !r.active) {
      const pen = new Pen(ec, true);
      ec.globalAlpha = 0.35 + 0.2 * Math.sin(st.t * 3 + i);
      const bob = Math.round(Math.sin(st.t * 2 + i) * 1.5);
      glyphPattern(pen, r.solution[i], Math.round(p.x - camX) - 3, Math.round(topY - camY) - 16 + bob - (g >= 0 ? 4 : 0), GLYPHS[r.solution[i]].color, true);
      ec.globalAlpha = 1;
    }
    if (i === 0 && r.core) {
      const c = area.ritualPos;
      const bob = Math.round(Math.sin(st.t * 2) * 1.5) + (r.active ? -3 : 0);
      spr(itemIcon("core"), c.x, c.y - 4 + bob);
    }
  }

  drawPlayer(camX: number, camY: number, px: number, py: number, st: WorldRenderState) {
    const pl = st.pl, lk = st.look, sc = this.scene.ctx;
    sc.fillStyle = "rgba(0,0,0,0.45)";
    const sx = Math.round(px - camX), sy = Math.round(py - camY);
    const sw = Math.max(4, 8 - Math.round(lk.z / 3));
    sc.fillRect(sx - sw, sy - 1, sw * 2, 2);
    sc.fillRect(sx - sw + 2, sy - 2, sw * 2 - 4, 4);
    const a = pl.task;
    let raise = 0, reach = 0, slam: number | undefined, dip: number | undefined;
    if (a) {
      const k = a.t / a.dur;
      if (a.kind === "reach" || a.kind === "push" || a.kind === "dismantle") reach = Math.sin(Math.min(1, k) * Math.PI);
      if (a.kind === "smash") raise = a.t < 0.5 ? a.t / 0.5 : a.t < 0.62 ? lerp(1, -1, (a.t - 0.5) / 0.12) : lerp(-1, 0, clamp((a.t - 0.62) / 0.5, 0, 1));
      if (a.kind === "carve") reach = 0.4 + 0.6 * Math.abs(Math.sin(a.t * 14));
      if (a.kind === "craft") reach = 0.3 + 0.7 * Math.abs(Math.sin(a.t * 9));
      if (a.kind === "attach") reach = 0.3;
      if (a.kind === "punch") { const k2 = a.t / a.dur; raise = k2 < 0.35 ? k2 / 0.35 : k2 < 0.5 ? lerp(1, -1, (k2 - 0.35) / 0.15) : lerp(-1, 0, clamp((k2 - 0.5) / 0.4, 0, 1)); }
      if (a.kind === "channel") reach = 0.2;
      if (a.kind === "slam") ({ lift: slam, dip } = slamPose(k));
    }
    const pose: GolemPose = {
      facing: st.gaze ?? pl.facing,
      phase: pl.phase,
      moving: pl.moving && !a,
      hasArm: hasFlag(st.world, FLAGS.golemArm),
      dormant: lk.dormant,
      eye: clamp(lk.eye + st.eyeBoost + st.vision.k * 0.35, 0, 1.6),
      core: lk.core,
      raise,
      reach,
      t: st.t,
      eyeFixed: hasFlag(st.world, FLAGS.golemEye),
      back: pl.gear.back,
      runes: runeMarks(st.world, pl),
      slam,
      dip,
    };
    const ox = px - camX + (a?.kind === "push" ? Math.round(Math.sin(a.t * 40)) : 0);
    const oy = py - camY - lk.z;
    drawGolem(new Pen(sc, false), ox, oy, pose);
    drawGolem(new Pen(this.emit.ctx, true), ox, oy, pose);
    this.selfPose = { pose, x: ox + camX, y: oy + camY };
  }
}
