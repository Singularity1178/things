// System / Pause / Save Slots / Telemetry screen (0.4, 0.5) on the 2x UI layer (640x360).
import { UI } from "../ui/kit";
import { UI_W, UI_H, type InputManager } from "../ui/input";
import { PALETTES } from "../ui/palettes";
import type { SettingsStore } from "../ui/settings";
import { SAVE_SLOTS, type SaveManager, type SaveMeta } from "../world/saveStore";
import { downloadWorldSave, pickAndImportSave } from "../view/persistence";
import {
  drawButton2x,
  drawGraph2x,
  drawPanel2x,
  inRect,
  UiModal,
  UiTable,
  UiTabs,
  type Rect2x,
  type TableColumn,
} from "../ui/components";
import { drawPropText, drawPropTextS } from "../ui/propFont";
import type { Screen, ScreenStack } from "../ui/screens";
import type { World } from "../world/world";

export interface SystemHost {
  readonly hctx: CanvasRenderingContext2D;
  readonly input: InputManager;
  readonly settings: SettingsStore;
  readonly screens: ScreenStack;
  readonly world: World;
  readonly saveManager: SaveManager;
  readonly telemetry: { frameMs: number[]; active: number; near: number; far: number };
  resume(world: World): void;
  openSettings(): void;
  goTitle(): void;
  say(text: string): void;
  createTestDynamicFloor(): void;
}

const TABS = [
  { id: "saves", label: "Save Slots" },
  { id: "telemetry", label: "World & LOD" },
  { id: "menu", label: "System" },
];

interface SlotRow {
  slotId: string;
  meta: SaveMeta | null;
}

const COLS: TableColumn<SlotRow>[] = [
  { key: "slot", label: "Slot", w: 84, value: (r) => (r.slotId === "autosave" ? "Autosave" : r.slotId.toUpperCase()) },
  { key: "area", label: "Area", w: 108, value: (r) => (r.meta ? (r.meta.corrupted ? "Corrupted" : r.meta.area) : "Empty") },
  { key: "day", label: "Day", w: 54, align: "right", value: (r) => (r.meta && !r.meta.corrupted ? `D${Math.floor(r.meta.day) + 1}` : "-") },
  { key: "size", label: "Size", w: 66, align: "right", value: (r) => (r.meta && r.meta.sizeBytes ? `${(r.meta.sizeBytes / 1024).toFixed(1)}k` : "-") },
  {
    key: "saved",
    label: "Saved",
    w: 110,
    align: "right",
    value: (r) => (r.meta?.savedAt ? new Date(r.meta.savedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "-"),
  },
];

export class SystemUi {
  screen: Screen;
  tabs = new UiTabs(TABS);
  table = new UiTable<SlotRow>();
  modal = new UiModal();
  rows: SlotRow[] = SAVE_SLOTS.map((slotId) => ({ slotId, meta: null }));
  statusMsg = "";
  private loading = false;

  constructor(private host: SystemHost) {
    this.screen = {
      id: "system",
      opaque: false,
      hires: true,
      t: 0,
      update: () => this.update(),
      render: () => this.render(),
    };
  }

  open(tabIndex = 0) {
    this.tabs.index = tabIndex;
    this.statusMsg = "";
    this.modal.close();
    this.refreshSlots();
    this.host.screens.push(this.screen);
  }

  refreshSlots() {
    if (this.loading) return;
    this.loading = true;
    this.host.saveManager
      .listSlots()
      .then((list) => {
        const byId = new Map<string, SaveMeta>();
        for (const m of list) if (m) byId.set(m.slotId, m);
        this.rows = SAVE_SLOTS.map((slotId) => ({ slotId, meta: byId.get(slotId) ?? null }));
      })
      .catch(() => {})
      .finally(() => {
        this.loading = false;
      });
  }

  private box(): Rect2x {
    return { x: 80, y: 28, w: UI_W - 160, h: UI_H - 56 };
  }

  private update() {
    const { input, screens } = this.host;
    if (this.modal.handleInput(input)) return;

    if (input.hit("escape")) {
      screens.pop();
      return;
    }

    const b = this.box();
    if (input.mouse.leftClick && inRect(input.mouse.x, input.mouse.y, { x: b.x + b.w - 22, y: b.y + 6, w: 16, h: 14 })) {
      screens.pop();
      return;
    }

    if (this.tabs.handleInput(input, b.x + 12, b.y + 26, 128, 18, 6)) {
      if (this.tabs.index === 0) this.refreshSlots();
      return;
    }

    const tab = TABS[this.tabs.index].id;
    if (tab === "saves") this.updateSaves(b);
    else if (tab === "telemetry") this.updateTelemetry(b);
    else this.updateMenu(b);
  }

  private updateSaves(b: Rect2x) {
    const { input, saveManager, world } = this.host;
    const tblRect: Rect2x = { x: b.x + 14, y: b.y + 52, w: b.w - 28, h: 112 };
    const sorted = this.table.sortRows(this.rows, COLS);
    this.table.handleInput(input, tblRect, sorted, COLS);
    const sel = sorted[this.table.list.selected];

    const btns = [
      { id: "save", label: "Save Slot", disabled: !sel || sel.slotId === "autosave" },
      { id: "load", label: "Load Slot", disabled: !sel || !sel.meta },
      { id: "export", label: "Export File", disabled: false },
      { id: "import", label: "Import File", disabled: false },
      { id: "delete", label: "Delete", disabled: !sel || !sel.meta },
    ];
    const bw = 82, gap = 6, by = b.y + 174;
    btns.forEach((btn, i) => {
      const rx = b.x + 14 + i * (bw + gap);
      if (!btn.disabled && input.mouse.leftClick && inRect(input.mouse.x, input.mouse.y, { x: rx, y: by, w: bw, h: 20 })) {
        if (btn.id === "save" && sel) {
          saveManager.saveSlot(sel.slotId, world).then(() => {
            this.statusMsg = `Saved to ${sel.slotId.toUpperCase()}.`;
            this.host.say(`SAVED TO ${sel.slotId.toUpperCase()}`);
            this.refreshSlots();
          });
        } else if (btn.id === "load" && sel) {
          saveManager.loadSlot(sel.slotId).then((res) => {
            if (!res) {
              this.statusMsg = "Could not load slot (corrupted or empty).";
              return;
            }
            this.host.resume(res.world);
            this.host.say(res.recoveredFromBackup ? "RECOVERED FROM BACKUP" : `LOADED ${sel.slotId.toUpperCase()}`);
          });
        } else if (btn.id === "export") {
          downloadWorldSave(world);
          this.statusMsg = "Exported world save file.";
        } else if (btn.id === "import") {
          pickAndImportSave(
            (w) => {
              this.host.resume(w);
              this.host.say("IMPORTED SAVE FILE");
            },
            (err) => {
              this.statusMsg = `Import error: ${err}`;
            },
          );
        } else if (btn.id === "delete" && sel) {
          this.modal.show(
            "Delete Save Slot?",
            `Permanently remove ${sel.slotId.toUpperCase()} and its rolling backups?`,
            [
              {
                label: "Delete",
                color: UI.bad,
                onClick: () => {
                  saveManager.deleteSlot(sel.slotId).then(() => {
                    this.statusMsg = `Deleted ${sel.slotId.toUpperCase()}.`;
                    this.refreshSlots();
                  });
                  this.modal.close();
                },
              },
              { label: "Cancel", onClick: () => this.modal.close() },
            ],
          );
        }
      }
    });
  }

  private updateTelemetry(b: Rect2x) {
    const { input } = this.host;
    const genBtn: Rect2x = { x: b.x + 14, y: b.y + b.h - 42, w: 168, h: 20 };
    if (input.mouse.leftClick && inRect(input.mouse.x, input.mouse.y, genBtn)) {
      this.host.createTestDynamicFloor();
      this.host.screens.popToBase();
    }
  }

  private updateMenu(b: Rect2x) {
    const { input, screens } = this.host;
    const actions = [
      { label: "Resume Game", fn: () => screens.popToBase() },
      { label: "Settings & Accessibility", fn: () => this.host.openSettings() },
      { label: "Return to Title Screen", fn: () => this.host.goTitle() },
    ];
    actions.forEach((a, i) => {
      const r: Rect2x = { x: b.x + 120, y: b.y + 72 + i * 32, w: b.w - 240, h: 24 };
      if (input.mouse.leftClick && inRect(input.mouse.x, input.mouse.y, r)) a.fn();
    });
  }

  private render() {
    const ctx = this.host.hctx;
    const { input, settings, world, telemetry } = this.host;
    const b = this.box();
    ctx.fillStyle = "rgba(0,0,0,0.58)";
    ctx.fillRect(0, 0, UI_W, UI_H);

    drawPanel2x(ctx, b.x, b.y, b.w, b.h, "#121017", "#5a5268", "#7a7088");
    drawPropTextS(ctx, "System & World Management", b.x + 12, b.y + 8, UI.title);
    drawButton2x(ctx, b.x + b.w - 22, b.y + 6, 16, 14, "X", {
      hovered: input.mouse.inside && inRect(input.mouse.x, input.mouse.y, { x: b.x + b.w - 22, y: b.y + 6, w: 16, h: 14 }),
    });

    this.tabs.draw(ctx, input, b.x + 12, b.y + 26, 128, 18, 6);

    const tab = TABS[this.tabs.index].id;
    const pal = PALETTES[settings.data.palette];

    if (tab === "saves") {
      const tblRect: Rect2x = { x: b.x + 14, y: b.y + 52, w: b.w - 28, h: 112 };
      const sorted = this.table.sortRows(this.rows, COLS);
      this.table.draw(ctx, tblRect, sorted, COLS);
      const sel = sorted[this.table.list.selected];
      const btns = [
        { label: "Save Slot", disabled: !sel || sel.slotId === "autosave" },
        { label: "Load Slot", disabled: !sel || !sel.meta },
        { label: "Export File", disabled: false },
        { label: "Import File", disabled: false },
        { label: "Delete", disabled: !sel || !sel.meta, color: UI.bad },
      ];
      const bw = 82, gap = 6, by = b.y + 174;
      btns.forEach((btn, i) => {
        const rx = b.x + 14 + i * (bw + gap);
        drawButton2x(ctx, rx, by, bw, 20, btn.label, {
          disabled: btn.disabled,
          hovered: !btn.disabled && input.mouse.inside && inRect(input.mouse.x, input.mouse.y, { x: rx, y: by, w: bw, h: 20 }),
          color: btn.color,
        });
      });
      if (this.statusMsg) drawPropText(ctx, this.statusMsg, b.x + 14, b.y + 206, UI.ok);
      drawPropText(ctx, "IndexedDB multi-slot store with rolling backups & auto-recovery", b.x + 14, b.y + b.h - 32, UI.dim);
    } else if (tab === "telemetry") {
      drawGraph2x(
        ctx,
        { x: b.x + 14, y: b.y + 54, w: b.w - 28, h: 92 },
        [{ label: "Sim Tick ms", color: pal.info, values: telemetry.frameMs.length ? telemetry.frameMs : [0] }],
        { title: "Simulation Frame Budget (ms)", min: 0, max: 16.7, unit: "ms" },
      );
      drawPropTextS(
        ctx,
        `Actors: ${world.actors.length} total  |  Active: ${telemetry.active}  |  Near: ${telemetry.near}  |  Far: ${telemetry.far}`,
        b.x + 14,
        b.y + 156,
        UI.text,
      );
      drawPropText(
        ctx,
        `Loaded Areas (${world.areas.size}): ${[...world.areas.keys()].slice(0, 6).join(", ")}`,
        b.x + 14,
        b.y + 172,
        UI.mid,
      );
      const genBtn: Rect2x = { x: b.x + 14, y: b.y + b.h - 42, w: 168, h: 20 };
      drawButton2x(ctx, genBtn.x, genBtn.y, genBtn.w, genBtn.h, "Visit Generated Floor", {
        hovered: input.mouse.inside && inRect(input.mouse.x, input.mouse.y, genBtn),
        color: pal.valid,
      });
    } else {
      const actions = ["Resume Game", "Settings & Accessibility", "Return to Title Screen"];
      actions.forEach((label, i) => {
        const r: Rect2x = { x: b.x + 120, y: b.y + 72 + i * 32, w: b.w - 240, h: 24 };
        drawButton2x(ctx, r.x, r.y, r.w, r.h, label, {
          hovered: input.mouse.inside && inRect(input.mouse.x, input.mouse.y, r),
        });
      });
    }

    drawPropText(ctx, "Esc: Close", b.x + 14, b.y + b.h - 16, UI.dim);
    this.modal.draw(ctx, input);
  }
}
