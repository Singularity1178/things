// Settings & Accessibility screen (0.7) rendered on the 2x UI layer (640x360)
// using UI v2 components (tabs, sliders, toggles, scroll list, key capture).
import { UI } from "../ui/kit";
import { UI_W, UI_H, type InputManager } from "../ui/input";
import { PALETTE_ORDER, PALETTES } from "../ui/palettes";
import { ACTION_LABELS, formatKeyName, type ActionName, type SettingsStore } from "../ui/settings";
import { drawButton2x, drawPanel2x, drawToggle2x, inRect, UiSlider, UiTabs, type Rect2x } from "../ui/components";
import { drawPropText, drawPropTextS } from "../ui/propFont";
import type { Screen, ScreenStack } from "../ui/screens";

export interface SettingsHost {
  readonly hctx: CanvasRenderingContext2D;
  readonly input: InputManager;
  readonly settings: SettingsStore;
  readonly screens: ScreenStack;
  applySettings(): void;
  say(text: string): void;
}

const TABS = [
  { id: "audio", label: "Audio" },
  { id: "display", label: "Accessibility" },
  { id: "alerts", label: "Alerts & Save" },
  { id: "controls", label: "Controls" },
];

const ACTIONS = Object.keys(ACTION_LABELS) as ActionName[];
const AUTOSAVE_OPTS = [0, 60, 120, 300] as const;

export class SettingsUi {
  screen: Screen;
  tabs = new UiTabs(TABS);
  cursor = 0;
  rebinding: ActionName | null = null;
  ctrlScroll = 0;
  private sliders = [new UiSlider(), new UiSlider(), new UiSlider()];

  constructor(private host: SettingsHost) {
    this.screen = {
      id: "settings",
      opaque: false,
      hires: true,
      t: 0,
      update: () => this.update(),
      render: () => this.render(),
    };
  }

  open() {
    this.cursor = 0;
    this.rebinding = null;
    this.host.screens.push(this.screen);
  }

  private box(): Rect2x {
    return { x: 80, y: 32, w: UI_W - 160, h: UI_H - 64 };
  }

  private update() {
    const { input, settings, screens } = this.host;

    if (this.rebinding) {
      if (input.hit("escape")) {
        this.rebinding = null;
        return;
      }
      if (input.lastRawKey && input.lastRawKey !== "escape") {
        settings.rebind(this.rebinding, input.lastRawKey);
        this.host.applySettings();
        this.rebinding = null;
      }
      return;
    }

    if (input.hit("escape", "o")) {
      screens.pop();
      return;
    }

    const b = this.box();
    if (this.tabs.handleInput(input, b.x + 12, b.y + 26, 108, 18, 6)) {
      this.cursor = 0;
      this.ctrlScroll = 0;
      return;
    }

    // Close button [X]
    if (input.mouse.leftClick && inRect(input.mouse.x, input.mouse.y, { x: b.x + b.w - 22, y: b.y + 6, w: 16, h: 14 })) {
      screens.pop();
      return;
    }

    const tabId = TABS[this.tabs.index].id;
    if (tabId === "audio") this.updateAudio(b);
    else if (tabId === "display") this.updateDisplay(b);
    else if (tabId === "alerts") this.updateAlerts(b);
    else this.updateControls(b);
  }

  private updateAudio(b: Rect2x) {
    const { input, settings } = this.host;
    const keys: ("masterVol" | "sfxVol" | "ambientVol")[] = ["masterVol", "sfxVol", "ambientVol"];
    if (input.hit("arrowup", "w")) this.cursor = Math.max(0, this.cursor - 1);
    if (input.hit("arrowdown", "s")) this.cursor = Math.min(2, this.cursor + 1);

    for (let i = 0; i < 3; i++) {
      const tr: Rect2x = { x: b.x + 190, y: b.y + 68 + i * 36, w: 220, h: 16 };
      if (input.mouse.inside && inRect(input.mouse.x, input.mouse.y, { x: b.x + 12, y: tr.y - 4, w: b.w - 24, h: 24 })) {
        if (input.mouse.leftClick) this.cursor = i;
      }
      const next = this.sliders[i].handleInput(input, tr, settings.data[keys[i]], 0, 1, 0.05, this.cursor === i);
      if (next !== null) {
        settings.set(keys[i], Math.round(next * 100) / 100);
        this.host.applySettings();
      }
    }
  }

  private updateDisplay(b: Rect2x) {
    const { input, settings } = this.host;
    if (input.hit("arrowup", "w")) this.cursor = Math.max(0, this.cursor - 1);
    if (input.hit("arrowdown", "s")) this.cursor = Math.min(3, this.cursor + 1);

    const toggleRow = (i: number) => {
      if (i === 0) settings.set("screenShake", !settings.data.screenShake);
      else if (i === 1) settings.set("flashes", !settings.data.flashes);
      else if (i === 2) {
        const scales: (1 | 1.5 | 2)[] = [1, 1.5, 2];
        const next = scales[(scales.indexOf(settings.data.uiScale) + 1) % scales.length];
        settings.set("uiScale", next);
      } else if (i === 3) {
        const next = PALETTE_ORDER[(PALETTE_ORDER.indexOf(settings.data.palette) + 1) % PALETTE_ORDER.length];
        settings.set("palette", next);
      }
      this.host.applySettings();
    };

    if (input.hit("e", "enter", " ")) toggleRow(this.cursor);
    for (let i = 0; i < 4; i++) {
      const r: Rect2x = { x: b.x + 14, y: b.y + 62 + i * 32, w: b.w - 28, h: 24 };
      if (input.mouse.leftClick && inRect(input.mouse.x, input.mouse.y, r)) {
        this.cursor = i;
        toggleRow(i);
      }
    }
  }

  private updateAlerts(b: Rect2x) {
    const { input, settings } = this.host;
    if (input.hit("arrowup", "w")) this.cursor = Math.max(0, this.cursor - 1);
    if (input.hit("arrowdown", "s")) this.cursor = Math.min(4, this.cursor + 1);

    const toggleRow = (i: number) => {
      if (i === 0) settings.set("pauseOnAlert", !settings.data.pauseOnAlert);
      else if (i === 1) settings.set("pauseWorkerBlocked", !settings.data.pauseWorkerBlocked);
      else if (i === 2) settings.set("pauseNoPower", !settings.data.pauseNoPower);
      else if (i === 3) settings.set("pauseStorageFull", !settings.data.pauseStorageFull);
      else if (i === 4) {
        const next = AUTOSAVE_OPTS[(AUTOSAVE_OPTS.indexOf(settings.data.autosaveIntervalSec as any) + 1) % AUTOSAVE_OPTS.length];
        settings.set("autosaveIntervalSec", next);
      }
      this.host.applySettings();
    };

    if (input.hit("e", "enter", " ")) toggleRow(this.cursor);
    for (let i = 0; i < 5; i++) {
      const r: Rect2x = { x: b.x + 14, y: b.y + 60 + i * 28, w: b.w - 28, h: 22 };
      if (input.mouse.leftClick && inRect(input.mouse.x, input.mouse.y, r)) {
        this.cursor = i;
        toggleRow(i);
      }
    }
  }

  private updateControls(b: Rect2x) {
    const { input, settings } = this.host;
    const vis = 8;
    if (input.hit("arrowup", "w")) this.cursor = Math.max(0, this.cursor - 1);
    if (input.hit("arrowdown", "s")) this.cursor = Math.min(ACTIONS.length - 1, this.cursor + 1);
    if (input.mouse.wheelY !== 0) {
      this.ctrlScroll = Math.max(0, Math.min(ACTIONS.length - vis, this.ctrlScroll + (input.mouse.wheelY > 0 ? 1 : -1)));
    }
    if (this.cursor < this.ctrlScroll) this.ctrlScroll = this.cursor;
    if (this.cursor >= this.ctrlScroll + vis) this.ctrlScroll = this.cursor - vis + 1;

    if (input.hit("e", "enter", " ")) {
      this.rebinding = ACTIONS[this.cursor];
      return;
    }

    for (let i = 0; i < vis; i++) {
      const idx = this.ctrlScroll + i;
      if (idx >= ACTIONS.length) break;
      const r: Rect2x = { x: b.x + 14, y: b.y + 56 + i * 22, w: b.w - 28, h: 20 };
      if (input.mouse.leftClick && inRect(input.mouse.x, input.mouse.y, r)) {
        this.cursor = idx;
        this.rebinding = ACTIONS[idx];
        return;
      }
    }

    const resetBtn: Rect2x = { x: b.x + b.w - 134, y: b.y + b.h - 26, w: 120, h: 18 };
    if (input.mouse.leftClick && inRect(input.mouse.x, input.mouse.y, resetBtn)) {
      settings.resetKeybinds();
      this.host.applySettings();
    }
  }

  private render() {
    const ctx = this.host.hctx;
    const { input, settings } = this.host;
    const b = this.box();
    ctx.fillStyle = "rgba(0,0,0,0.58)";
    ctx.fillRect(0, 0, UI_W, UI_H);

    drawPanel2x(ctx, b.x, b.y, b.w, b.h, "#121017", "#5a5268", "#7a7088");
    drawPropTextS(ctx, "Settings & Accessibility", b.x + 12, b.y + 8, UI.title);
    drawButton2x(ctx, b.x + b.w - 22, b.y + 6, 16, 14, "X", {
      hovered: input.mouse.inside && inRect(input.mouse.x, input.mouse.y, { x: b.x + b.w - 22, y: b.y + 6, w: 16, h: 14 }),
    });

    this.tabs.draw(ctx, input, b.x + 12, b.y + 26, 108, 18, 6);

    const tabId = TABS[this.tabs.index].id;
    const pal = PALETTES[settings.data.palette];

    if (tabId === "audio") {
      const rows: { label: string; key: "masterVol" | "sfxVol" | "ambientVol" }[] = [
        { label: "Master Volume", key: "masterVol" },
        { label: "Sound Effects Volume", key: "sfxVol" },
        { label: "Ambient Atmosphere", key: "ambientVol" },
      ];
      rows.forEach((row, i) => {
        const ry = b.y + 68 + i * 36;
        const focused = this.cursor === i;
        drawPropTextS(ctx, row.label, b.x + 18, ry + 4, focused ? UI.title : UI.text);
        const tr: Rect2x = { x: b.x + 190, y: ry, w: 220, h: 16 };
        this.sliders[i].draw(ctx, tr, settings.data[row.key], 0, 1, focused, pal.info);
        drawPropText(ctx, `${Math.round(settings.data[row.key] * 100)}%`, tr.x + tr.w + 14, ry + 4, UI.mid);
      });
    } else if (tabId === "display") {
      const rows = [
        { label: "Screen Shake", desc: "Camera jolt on slams & tremors", kind: "toggle" as const, on: settings.data.screenShake },
        { label: "Screen Flashes", desc: "Impact & rune arrival flashes", kind: "toggle" as const, on: settings.data.flashes },
        { label: "HUD UI Scale", desc: "Preferred overlay density", kind: "value" as const, val: `${settings.data.uiScale}x` },
        { label: "Overlay Palette", desc: "Colour-blind-safe highlights", kind: "value" as const, val: PALETTES[settings.data.palette].label },
      ];
      rows.forEach((row, i) => {
        const ry = b.y + 62 + i * 32;
        const r: Rect2x = { x: b.x + 14, y: ry, w: b.w - 28, h: 24 };
        const hov = input.mouse.inside && inRect(input.mouse.x, input.mouse.y, r);
        if (this.cursor === i || hov) {
          ctx.fillStyle = "#1c1824";
          ctx.fillRect(r.x, r.y, r.w, r.h);
        }
        drawPropTextS(ctx, row.label, r.x + 8, ry + 4, this.cursor === i ? UI.title : UI.text);
        drawPropText(ctx, row.desc, r.x + 8, ry + 13, UI.dim);
        if (row.kind === "toggle") {
          drawToggle2x(ctx, r.x + r.w - 36, ry + 6, row.on, hov, this.cursor === i, pal.valid);
        } else {
          drawButton2x(ctx, r.x + r.w - 134, ry + 4, 126, 16, row.val, { hovered: hov, focused: this.cursor === i });
        }
      });
    } else if (tabId === "alerts") {
      const rows = [
        { label: "Pause on Critical Alert", val: settings.data.pauseOnAlert },
        { label: "Pause when Worker Blocked", val: settings.data.pauseWorkerBlocked },
        { label: "Pause when Worker Out of Power", val: settings.data.pauseNoPower },
        { label: "Pause when Storage Full", val: settings.data.pauseStorageFull },
        { label: "Autosave Timer", text: settings.data.autosaveIntervalSec ? `${settings.data.autosaveIntervalSec}s` : "Off" },
      ];
      rows.forEach((row, i) => {
        const ry = b.y + 60 + i * 28;
        const r: Rect2x = { x: b.x + 14, y: ry, w: b.w - 28, h: 22 };
        const hov = input.mouse.inside && inRect(input.mouse.x, input.mouse.y, r);
        if (this.cursor === i || hov) {
          ctx.fillStyle = "#1c1824";
          ctx.fillRect(r.x, r.y, r.w, r.h);
        }
        drawPropTextS(ctx, row.label, r.x + 8, ry + 7, this.cursor === i ? UI.title : UI.text);
        if ("val" in row && row.val !== undefined) {
          drawToggle2x(ctx, r.x + r.w - 36, ry + 5, row.val, hov, this.cursor === i, pal.valid);
        } else {
          drawButton2x(ctx, r.x + r.w - 86, ry + 3, 78, 16, row.text!, { hovered: hov, focused: this.cursor === i });
        }
      });
    } else {
      const vis = 8;
      for (let i = 0; i < vis; i++) {
        const idx = this.ctrlScroll + i;
        if (idx >= ACTIONS.length) break;
        const act = ACTIONS[idx];
        const ry = b.y + 56 + i * 22;
        const r: Rect2x = { x: b.x + 14, y: ry, w: b.w - 28, h: 20 };
        const hov = input.mouse.inside && inRect(input.mouse.x, input.mouse.y, r);
        if (this.cursor === idx || hov) {
          ctx.fillStyle = "#1c1824";
          ctx.fillRect(r.x, r.y, r.w, r.h);
        }
        drawPropTextS(ctx, ACTION_LABELS[act], r.x + 8, ry + 6, this.cursor === idx ? UI.title : UI.text);
        const isRebind = this.rebinding === act;
        const bindTxt = isRebind ? "Press a key..." : settings.data.keybinds[act].map(formatKeyName).join(" / ");
        drawButton2x(ctx, r.x + r.w - 130, ry + 2, 122, 16, bindTxt, {
          hovered: hov,
          focused: this.cursor === idx || isRebind,
          color: isRebind ? UI.amber : UI.text,
        });
      }
      const resetBtn: Rect2x = { x: b.x + b.w - 134, y: b.y + b.h - 26, w: 120, h: 18 };
      drawButton2x(ctx, resetBtn.x, resetBtn.y, resetBtn.w, resetBtn.h, "Reset Defaults", {
        hovered: input.mouse.inside && inRect(input.mouse.x, input.mouse.y, resetBtn),
      });
    }

    drawPropText(ctx, "Esc / O: Close   Q/R or Click: Tabs", b.x + 14, b.y + b.h - 18, UI.dim);
  }
}
