import { useEffect, useRef } from "react";
import { Game, W, H, UI_W, UI_H } from "./game/game";
import { serialize } from "./game/world/save";
import { saveToStorage, loadFromStorage } from "./game/view/persistence";
import { foundationDemo, registerFoundations } from "./game/sim/debugFoundations";
import { setWorkerOrder } from "./game/sim/jobs";
import type { JobOrder } from "./game/world/jobs";
import { player } from "./game/world/world";

export default function App() {
  const ref = useRef<HTMLCanvasElement>(null);
  const uiRef = useRef<HTMLCanvasElement>(null);
  const wrap = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Two stacked layers with the same display rect: the world canvas is sized
    // to the current view (W x H times the zoom level, 1 world px = 1 canvas
    // px), while the UI canvas renders at 2x (UI_W x UI_H = 640x360) so dense
    // management info and mixed-case proportional text stay crisp.
    const canvas = ref.current!;
    const ui = uiRef.current!;
    const game = new Game(canvas, ui);
    if (new URLSearchParams(window.location.search).has("debug")) {
      registerFoundations();
      (window as unknown as Record<string, unknown>).dustwake = {
        game,
        serialize: () => serialize(game.world),
        save: () => saveToStorage(game.world),
        load: () => { const w = loadFromStorage(); if (w) game.resume(w); return !!w; },
        foundations: () => { game.resume(foundationDemo()); game.say("FOUNDATION FIXTURE: A WORKER GATHERS THROUGH THE RUNES."); },
        order: (id: string, order: JobOrder | null) => setWorkerOrder(game.world, player(game.world), id, order),
      };
    }
    let raf = 0;
    let last = performance.now();
    let running = true;

    const fit = () => {
      const vw = window.innerWidth, vh = window.innerHeight;
      let s = Math.min(vw / W, vh / H);
      if (s >= 2) s = Math.floor(s);
      const dw = Math.round(W * s), dh = Math.round(H * s);
      const ws = dw / game.vw;
      for (const c of [canvas, ui]) {
        c.style.width = `${dw}px`;
        c.style.height = `${dh}px`;
      }
      canvas.style.width = `${Math.round(game.vw * ws)}px`;
      canvas.style.height = `${Math.round(game.vh * ws)}px`;
    };
    game.onView = fit;
    fit();
    window.addEventListener("resize", fit);

    const toUiCoords = (e: PointerEvent | MouseEvent) => {
      const rect = ui.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / Math.max(1, rect.width)) * UI_W;
      const y = ((e.clientY - rect.top) / Math.max(1, rect.height)) * UI_H;
      return { x, y };
    };

    const block = new Set(["arrowup", "arrowdown", "arrowleft", "arrowright", " ", "tab", "/", "'", "backspace"]);
    const kd = (e: KeyboardEvent) => {
      if (e.ctrlKey && !e.altKey && !e.shiftKey) {
        const n = ({ Digit0: 0, Numpad0: 0, Digit1: 1, Digit2: 2, Digit3: 3, Digit4: 4, Digit5: 5, Digit6: 6, Numpad1: 1, Numpad2: 2, Numpad3: 3, Numpad4: 4, Numpad5: 5, Numpad6: 6 } as Record<string, number>)[e.code];
        if (n !== undefined) {
          e.preventDefault();
          if (!e.repeat) game.debugKey(n);
          return;
        }
      }
      if (block.has(e.key.toLowerCase())) e.preventDefault();
      game.keyDown(e.key);
    };
    const ku = (e: KeyboardEvent) => game.keyUp(e.key);
    const pm = (e: PointerEvent) => {
      const p = toUiCoords(e);
      game.pointerMove(p.x, p.y);
    };
    const pd = (e: PointerEvent) => {
      const p = toUiCoords(e);
      game.pointer(p.x, p.y, e.button);
    };
    const pu = (e: PointerEvent) => {
      const p = toUiCoords(e);
      game.pointerUp(p.x, p.y, e.button);
    };
    const cm = (e: MouseEvent) => e.preventDefault();
    const wh = (e: WheelEvent) => { e.preventDefault(); game.wheel(e.deltaY); };

    window.addEventListener("keydown", kd);
    window.addEventListener("keyup", ku);
    ui.addEventListener("pointermove", pm);
    ui.addEventListener("pointerdown", pd);
    window.addEventListener("pointerup", pu);
    ui.addEventListener("contextmenu", cm);
    window.addEventListener("wheel", wh, { passive: false });
    const blur = () => game.keys.clear();
    window.addEventListener("blur", blur);

    const loop = (now: number) => {
      if (!running) return;
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      game.update(dt);
      game.render();
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      game.onView = null;
      window.removeEventListener("resize", fit);
      window.removeEventListener("keydown", kd);
      window.removeEventListener("keyup", ku);
      window.removeEventListener("blur", blur);
      window.removeEventListener("wheel", wh);
      ui.removeEventListener("pointermove", pm);
      ui.removeEventListener("pointerdown", pd);
      window.removeEventListener("pointerup", pu);
      ui.removeEventListener("contextmenu", cm);
      game.sfx.ctx?.close();
      game.view.dispose();
      delete (window as unknown as Record<string, unknown>).dustwake;
    };
  }, []);

  return (
    <div ref={wrap} className="fixed inset-0 bg-black flex items-center justify-center overflow-hidden select-none">
      <div className="relative">
        <canvas
          ref={ref}
          width={W}
          height={H}
          className="block outline-none"
          style={{ imageRendering: "pixelated" }}
        />
        <canvas
          ref={uiRef}
          width={UI_W}
          height={UI_H}
          tabIndex={0}
          className="absolute inset-0 block outline-none"
          style={{ imageRendering: "pixelated" }}
        />
      </div>
    </div>
  );
}
