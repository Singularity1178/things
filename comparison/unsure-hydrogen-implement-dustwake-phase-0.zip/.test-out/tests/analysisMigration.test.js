"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const build_1 = require("../src/game/content/build");
const flags_1 = require("../src/game/content/flags");
const items_1 = require("../src/game/content/items");
const vision_1 = require("../src/game/content/vision");
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const debugFoundations_1 = require("../src/game/sim/debugFoundations");
const analysis_1 = require("../src/game/sim/analysis");
const tasks_1 = require("../src/game/sim/tasks");
const inventory_1 = require("../src/game/sim/inventory");
const step_1 = require("../src/game/sim/step");
const build_2 = require("../src/game/sim/build");
const catalog_1 = require("../src/game/sim/catalog");
const interact_1 = require("../src/game/sim/interact");
const gear_1 = require("../src/game/sim/gear");
const discovery_1 = require("../src/game/sim/discovery");
(0, debugFoundations_1.registerFoundations)();
function scanWorld() {
    const w = (0, world_1.createWorld)(12), area = (0, world_1.getArea)(w, "debug_workshop"), pl = (0, world_1.player)(w), chest = area.prop("chest.fixture");
    (0, world_1.enterArea)(w, pl, area.id, chest.x, chest.y + 11);
    pl.facing = "up";
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    (0, inventory_1.addItems)(w, pl, "planks", 8);
    return { w, pl, area, chest };
}
(0, node_test_1.test)("input toggles sim scan mode; using a storage prop analyzes instead of opening it", () => {
    const { w, pl, area, chest } = scanWorld();
    strict_1.default.deepEqual((0, build_2.canBuild)(w, pl, "storage_chest"), { ok: false, reason: "unknown" });
    strict_1.default.equal((0, catalog_1.entryFor)(w, pl, "storage_chest").status, "unknown");
    const result = (0, step_1.stepPlayer)(w, 0.01, { ix: 0, iy: 0, use: true, toggleScan: true });
    strict_1.default.equal(result.target?.propId, chest.id);
    strict_1.default.equal(pl.mode, "scan");
    strict_1.default.equal(pl.task?.kind, "scan");
    strict_1.default.equal(w.flags.has("analysis.storage_chest"), false);
    (0, tasks_1.tickTask)(w, pl, 1);
    strict_1.default.ok(w.flags.has("analysis.storage_chest"));
    strict_1.default.deepEqual((0, build_2.canBuild)(w, pl, "storage_chest"), { ok: true });
    strict_1.default.ok(w.events.some((e) => e.t === "analyzed"));
    strict_1.default.ok(!w.events.some((e) => e.t === "openStorage"));
    (0, step_1.stepPlayer)(w, 0.01, { ix: 0, iy: 0, use: true, toggleScan: true });
    (0, tasks_1.tickTask)(w, pl, 1);
    strict_1.default.equal(pl.mode, "normal");
    strict_1.default.ok(w.events.some((e) => e.t === "openStorage"));
    strict_1.default.equal(area.storageRevision, 0, "scanning does not touch contents");
});
(0, node_test_1.test)("buildable furniture is a scan-only target, and analysis gating is an optional data row", () => {
    const { w, pl, area } = scanWorld();
    const table = area.addProp("table", 80, 80);
    strict_1.default.ok(!(0, interact_1.interactables)(area).some((i) => i.propId === table.id), "not a normal interactable");
    pl.x = table.x;
    pl.y = table.y + 12;
    pl.facing = "up";
    const old = build_1.RECIPES.table.analysis;
    build_1.RECIPES.table.analysis = "table";
    try {
        strict_1.default.equal((0, catalog_1.entryFor)(w, pl, "table").status, "unknown");
        const normal = (0, step_1.stepPlayer)(w, 0.01, { ix: 0, iy: 0, use: true });
        strict_1.default.equal(normal.target, null, "outside scan mode the table is not a target");
        strict_1.default.equal(Boolean(pl.task), false);
        strict_1.default.equal(w.flags.has("analysis.table"), false, "normal interaction never analyzes");
        (0, step_1.stepPlayer)(w, 0.01, { ix: 0, iy: 0, use: true, toggleScan: true });
        strict_1.default.equal(pl.task?.kind, "scan");
        (0, tasks_1.tickTask)(w, pl, 1);
        strict_1.default.equal((0, catalog_1.entryFor)(w, pl, "table").status, "ok");
        strict_1.default.deepEqual((0, build_2.canBuild)(w, pl, "torch_post"), { ok: false, reason: "cost" }, "a recipe without an analysis key needs only knowledge/materials");
    }
    finally {
        if (old)
            build_1.RECIPES.table.analysis = old;
        else
            delete build_1.RECIPES.table.analysis;
    }
});
(0, node_test_1.test)("scan at an occupied workbench never steals its chisel; normal mode still picks up first", () => {
    const w = (0, world_1.createWorld)(14), area = (0, world_1.getArea)(w, "dungeon"), pl = (0, world_1.player)(w), p = area.prop("workbench@13.5,37");
    pl.x = p.x;
    pl.y = p.y + 12;
    pl.facing = "up";
    (0, step_1.stepPlayer)(w, 0.01, { ix: 0, iy: 0, use: true, toggleScan: true });
    (0, tasks_1.tickTask)(w, pl, 1);
    strict_1.default.equal(p.taken, false);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "chisel"), 0);
    strict_1.default.ok(w.flags.has("analysis.craftbench"));
    (0, step_1.stepPlayer)(w, 0.01, { ix: 0, iy: 0, use: true, toggleScan: true });
    (0, tasks_1.tickTask)(w, pl, 1);
    strict_1.default.ok(p.taken);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "chisel"), 1);
});
(0, node_test_1.test)("scan work is saved, fires once, and revalidates a missing or distant prop", () => {
    const { w, pl, area, chest } = scanWorld();
    (0, step_1.stepPlayer)(w, 0.01, { ix: 0, iy: 0, use: true, toggleScan: true });
    (0, tasks_1.tickTask)(w, pl, 0.3);
    const loaded = (0, save_1.deserialize)((0, save_1.serialize)(w));
    strict_1.default.equal((0, world_1.player)(loaded).mode, "scan");
    strict_1.default.equal((0, world_1.player)(loaded).task.kind, "scan");
    (0, tasks_1.tickTask)(loaded, (0, world_1.player)(loaded), 1);
    (0, tasks_1.tickTask)(loaded, (0, world_1.player)(loaded), 1);
    strict_1.default.equal(loaded.events.filter((e) => e.t === "analyzed").length, 1);
    area.removeProp(chest.id);
    (0, tasks_1.tickTask)(w, pl, 1);
    strict_1.default.equal(w.flags.has("analysis.storage_chest"), false);
    const second = scanWorld();
    (0, step_1.stepPlayer)(second.w, 0.01, { ix: 0, iy: 0, use: true, toggleScan: true });
    second.pl.x = 32;
    (0, tasks_1.tickTask)(second.w, second.pl, 1);
    strict_1.default.equal(second.w.flags.has("analysis.storage_chest"), false);
});
(0, node_test_1.test)("highlight classification is data-driven with important items, interactables, NPCs and buildables", () => {
    for (const item of ["arm", "book_build", "crown", "rune_swift", "glyph0", "core"])
        strict_1.default.equal((0, analysis_1.classifyHighlight)({ item, buildable: true }), "important");
    strict_1.default.equal((0, analysis_1.classifyHighlight)({ item: "wood", interactable: true }), "interactable");
    strict_1.default.equal((0, analysis_1.classifyHighlight)({ actor: true }), "npc");
    strict_1.default.equal((0, analysis_1.classifyHighlight)({ buildable: true, interactable: true }), "buildable");
    strict_1.default.equal((0, analysis_1.classifyHighlight)({}), null);
    const { w, area, pl, chest } = scanWorld();
    const a = (0, world_1.makeActor)("small", "worker_golem", area.id, pl.x - 60, pl.y);
    w.actors.push(a);
    const targets = (0, analysis_1.visionTargets)(w, area);
    strict_1.default.equal(targets.find((t) => t.id === a.id).category, "npc");
    strict_1.default.equal(targets.find((t) => t.id === chest.id).category, "buildable");
    const old = vision_1.HIGHLIGHT_RULES.length;
    vision_1.HIGHLIGHT_RULES.unshift({ category: "important", tags: ["material"] });
    strict_1.default.equal((0, analysis_1.classifyHighlight)({ item: "wood" }), "important");
    vision_1.HIGHLIGHT_RULES.shift();
    strict_1.default.equal(vision_1.HIGHLIGHT_RULES.length, old);
    strict_1.default.ok(items_1.ITEMS.ruby_core && items_1.ITEMS.large_ruby);
});
(0, node_test_1.test)("interacting with a worker asks for actor management, not a player-only dialogue", () => {
    const { w, area, pl } = scanWorld();
    const a = (0, world_1.makeActor)("small", "worker_golem", area.id, pl.x - 40, pl.y);
    w.actors.push(a);
    a.powerCore = "ruby_core"; // a dormant body (never had a core) keeps its screen shut: see tests/dormantGolem.test.ts
    const it = (0, interact_1.npcInteractables)(w, area).find((i) => i.actorId === a.id);
    strict_1.default.equal(it.kind, "worker");
    pl.x = a.x;
    pl.y = a.y + 12;
    (0, interact_1.interact)(w, pl, area, it);
    (0, tasks_1.tickTask)(w, pl, 1);
    strict_1.default.ok(w.events.some((e) => e.t === "manageActor" && e.target === a.id));
    strict_1.default.ok(!w.events.some((e) => e.t === "dialogue"));
});
/** Actual v9 actor shape: none of v10's fields sneak into this fixture. */
function oldSave(knowledge) {
    const s = (0, save_1.serialize)((0, world_1.createWorld)(19));
    s.version = 9;
    s.actors = s.actors.filter((a) => a.id !== "npc.worker.artificery"); // no worker golem existed before v12
    s.flags = ["golem.arm", "golem.slot.rune1", "golem.eye", ...(knowledge ? ["know.build"] : [])];
    for (const a of s.actors)
        for (const key of ["definition", "upgrades", "powerCore", "mode", "job", "jobSeq"])
            delete a[key];
    s.actors[0].gear = { back: "basket", rune1: "rune_swift" };
    s.actors[0].inventory = [{ item: "wood", n: 12 }, ...Array.from({ length: 47 }, () => null)];
    s.areas.dungeon.looseTaken.push("crown");
    return s;
}
(0, node_test_1.test)("v9 migrates body flags onto only the player, preserves gear and grants only frozen legacy analyses", () => {
    const raw = oldSave(true), original = JSON.stringify(raw), w = (0, save_1.deserialize)(raw), pl = (0, world_1.player)(w), guardian = (0, world_1.actorById)(w, "npc.guardian");
    strict_1.default.equal(save_1.SAVE_VERSION, 19);
    strict_1.default.equal((0, save_1.serialize)(w).version, 19); // v18: townsfolk (tests/folk.test.ts); v19: shops (tests/shops.test.ts)
    strict_1.default.equal(JSON.stringify(raw), original, "migrating never mutates the caller's JSON");
    strict_1.default.equal(pl.definition, "golem");
    strict_1.default.equal(guardian.definition, "guardian");
    strict_1.default.deepEqual(pl.upgrades, ["golem.arm", "golem.slot.rune1"]);
    strict_1.default.deepEqual(guardian.upgrades, []);
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 48);
    strict_1.default.equal((0, inventory_1.capacity)(w, guardian), 0);
    strict_1.default.ok((0, gear_1.slotUsable)(w, pl, "rune1"));
    strict_1.default.ok(!(0, gear_1.slotUsable)(w, guardian, "rune1"));
    strict_1.default.equal(pl.gear.rune1, "rune_swift");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 12);
    strict_1.default.equal(pl.mode, "normal");
    strict_1.default.equal(pl.powerCore, null);
    strict_1.default.equal(pl.job, null);
    strict_1.default.equal(pl.jobSeq, 0);
    for (const id of ["wall_torch", "brazier", "craftbench", "table", "chair", "wall_banner"])
        strict_1.default.ok(w.flags.has(`analysis.${id}`));
    strict_1.default.equal(w.flags.has("analysis.storage_chest"), false, "new content is not accidentally grandfathered");
    strict_1.default.ok(w.flags.has("golem.eye"), "story eye repair stays progression");
    strict_1.default.equal(w.flags.has("golem.arm"), false);
    strict_1.default.equal((0, discovery_1.relicCount)(w, pl), 1, "a discovered but no longer carried crown keeps credit");
    (0, step_1.stepWorld)(w, 0.05);
    strict_1.default.deepEqual((0, save_1.serialize)((0, save_1.deserialize)((0, save_1.serialize)(w))), (0, save_1.serialize)(w));
});
(0, node_test_1.test)("old players who knew building remain able to build when a legacy row opts into analysis", () => {
    const old = build_1.RECIPES.table.analysis;
    build_1.RECIPES.table.analysis = "table";
    try {
        const w = (0, save_1.deserialize)(oldSave(true)), pl = (0, world_1.player)(w);
        (0, inventory_1.addItems)(w, pl, "planks", 4);
        strict_1.default.ok((0, build_2.canBuild)(w, pl, "table").ok);
        const unlearned = (0, save_1.deserialize)(oldSave(false));
        (0, world_1.setFlag)(unlearned, "know.build");
        (0, inventory_1.addItems)(unlearned, (0, world_1.player)(unlearned), "planks", 4);
        strict_1.default.deepEqual((0, build_2.canBuild)(unlearned, (0, world_1.player)(unlearned), "table"), { ok: false, reason: "unknown" });
    }
    finally {
        if (old)
            build_1.RECIPES.table.analysis = old;
        else
            delete build_1.RECIPES.table.analysis;
    }
});
(0, node_test_1.test)("v1 saves migrate through the whole chain, including gear, NPCs and actor upgrades", () => {
    const s = oldSave(true);
    s.version = 1;
    s.flags.push("golem.basket");
    s.actors = s.actors.filter((a) => a.kind !== "npc");
    s.actors[0].inventory = ["chisel", "wood", "wood", "crown"];
    delete s.actors[0].gear;
    const w = (0, save_1.deserialize)(s), pl = (0, world_1.player)(w);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 2);
    strict_1.default.equal(pl.gear.back, "basket");
    strict_1.default.ok(pl.upgrades.includes("golem.arm"));
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 48);
    strict_1.default.ok((0, world_1.actorById)(w, "npc.guardian"));
    strict_1.default.equal((0, discovery_1.relicCount)(w, pl), 1);
    strict_1.default.equal(w.flags.has("golem.basket"), false);
});
(0, node_test_1.test)("legacy in-flight harvest keeps its work and remaining yield after migration", () => {
    const { w, pl } = scanWorld(), yard = (0, world_1.getArea)(w, "debug_yard"), tree = yard.prop("tree.fixture");
    (0, world_1.enterArea)(w, pl, yard.id, tree.x, tree.y + 12);
    yard.damageProp(tree.id, 2);
    (0, inventory_1.addItems)(w, pl, "wood", 2);
    const s = (0, save_1.serialize)(w);
    s.version = 9;
    for (const a of s.actors)
        for (const key of ["definition", "upgrades", "powerCore", "mode", "job", "jobSeq"])
            delete a[key];
    s.actors[0].task = { kind: "punch", dur: 0.75, t: 0.2, fired: false, area: yard.id, effect: { op: "harvest" }, target: { kind: "harvest", propId: tree.id, x: tree.x, y: tree.y } };
    const loaded = (0, save_1.deserialize)(s), a = (0, world_1.player)(loaded), area = (0, world_1.getArea)(loaded, yard.id);
    (0, tasks_1.tickTask)(loaded, a, 1);
    strict_1.default.equal(area.prop(tree.id).dmg, 3);
    strict_1.default.equal((0, inventory_1.countItem)(a, "wood"), 3);
    (0, tasks_1.applyEffect)(loaded, a, { op: "harvest" }, { kind: "harvest", propId: tree.id, x: tree.x, y: tree.y });
    strict_1.default.equal((0, inventory_1.countItem)(a, "wood"), 6);
});
(0, node_test_1.test)("save persistence is injected, DOM-free, and rejects unknown future versions", () => {
    const w = (0, world_1.createWorld)(12), values = new Map();
    const storage = { getItem: (key) => values.get(key) ?? null, setItem: (key, value) => { values.set(key, value); } };
    strict_1.default.equal((0, save_1.loadFromStorage)(storage), null);
    (0, save_1.saveToStorage)(w, storage);
    strict_1.default.deepEqual((0, save_1.serialize)((0, save_1.loadFromStorage)(storage)), (0, save_1.serialize)(w));
    strict_1.default.throws(() => (0, save_1.migrate)({ ...(0, save_1.serialize)(w), version: save_1.SAVE_VERSION + 1 }), /newer/);
});
