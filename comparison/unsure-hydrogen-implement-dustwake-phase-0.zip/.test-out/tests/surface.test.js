"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Surface slice: inventory rework, rune network travel, harvesting, building,
// off-screen policy, save/load + migration, perf and save-size reports.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const inventory_1 = require("../src/game/sim/inventory");
const commands_1 = require("../src/game/sim/commands");
const build_1 = require("../src/game/sim/build");
const runes_1 = require("../src/game/sim/runes");
const ritual_1 = require("../src/game/sim/ritual");
const tasks_1 = require("../src/game/sim/tasks");
const step_1 = require("../src/game/sim/step");
const collision_1 = require("../src/game/sim/collision");
const interact_1 = require("../src/game/sim/interact");
const harvesting_1 = require("../src/game/sim/harvesting");
const runes_2 = require("../src/game/content/runes");
const harvest_1 = require("../src/game/content/harvest");
const tasks_2 = require("../src/game/content/tasks");
const flags_1 = require("../src/game/content/flags");
const tiles_1 = require("../src/game/content/tiles");
const areaView_1 = require("../src/game/view/areaView");
const tiles_2 = require("../src/game/art/tiles");
const light_1 = require("../src/game/light");
const util_1 = require("../src/game/util");
const helpers_1 = require("./helpers");
const total = (w, id) => (0, inventory_1.countItem)((0, world_1.player)(w), id) + [...w.areas.values()].reduce((s, a) => s + a.loose.filter((l) => !l.taken && l.item === id).reduce((k, l) => k + (l.n ?? 1), 0), 0);
/** Finish the tutorial puzzle and take the first jump; ends standing on the surface. */
function toSurface(w) {
    const pl = (0, world_1.player)(w), dg = (0, world_1.currentArea)(w), r = dg.ritual;
    r.core = true;
    r.carved = true;
    r.sockets = r.solution.slice();
    (0, ritual_1.checkRune)(w, dg);
    r.actT = 5;
    const c = dg.ritualPos;
    pl.x = c.x;
    pl.y = c.y + 2;
    let g = 0;
    while (pl.area !== "surface" && g++ < 1000)
        (0, helpers_1.frame)(w);
    (0, helpers_1.frames)(w, 5);
}
// ------------------------------------------------------------------ Part A
(0, node_test_1.test)("capacity is derived from tiers: 8 / 16 with the arm / 48 wearing the basket", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 8);
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 16);
    (0, world_1.clearFlag)(w, flags_1.FLAGS.golemArm);
    pl.gear.back = "basket";
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 48, "highest satisfied tier wins");
});
(0, node_test_1.test)("stacking: materials stack to their max, tools take a slot each", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    strict_1.default.equal((0, inventory_1.addItems)(w, pl, "wood", 25), 0);
    strict_1.default.deepEqual(pl.inventory.filter(Boolean), [{ item: "wood", n: 20 }, { item: "wood", n: 5 }]);
    (0, inventory_1.addItems)(w, pl, "chisel", 1);
    (0, inventory_1.addItems)(w, pl, "key", 1);
    strict_1.default.equal(pl.inventory.filter(Boolean).length, 4);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 25);
});
(0, node_test_1.test)("full pack: extra items land on the ground, nothing is lost", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, world_1.currentArea)(w).takeLoose("coin"); // the treasury's own coin is not part of this test
    for (const id of ["chisel", "key", "core", "glyph0", "glyph1", "glyph2", "glyph3", "crown"])
        (0, inventory_1.addItems)(w, pl, id, 1);
    (0, helpers_1.events)(w);
    (0, inventory_1.giveItem)(w, pl, "coin", 1);
    const ev = (0, helpers_1.events)(w);
    strict_1.default.ok(ev.some((e) => e.t === "packFull"));
    strict_1.default.ok(!(0, inventory_1.hasItem)(pl, "coin"));
    strict_1.default.equal(total(w, "coin"), 1, "coin is on the ground");
    // picking it up with a full pack refuses and leaves it there
    const it = (0, helpers_1.find)(w, (i) => i.kind === "item" && (0, world_1.currentArea)(w).looseItem(i.looseId)?.item === "coin");
    (0, helpers_1.useOn)(w, it);
    strict_1.default.equal(total(w, "coin"), 1);
});
(0, node_test_1.test)("capacity growth reveals slots without moving items; a shrink never loses items", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
    (0, inventory_1.addItems)(w, pl, "chisel", 1);
    for (let i = 0; i < 15; i++)
        (0, inventory_1.addItems)(w, pl, i % 2 ? "wood" : "stone", 20);
    const before = JSON.stringify(pl.inventory.slice(0, 16));
    pl.gear.back = "basket";
    (0, inventory_1.reconcileCapacity)(w, pl);
    strict_1.default.equal(pl.inventory.length, 48);
    strict_1.default.equal(JSON.stringify(pl.inventory.slice(0, 16)), before, "growth keeps slots in place");
    const wood = total(w, "wood"), stone = total(w, "stone");
    delete pl.gear.back;
    (0, world_1.clearFlag)(w, flags_1.FLAGS.golemArm); // a forced shrink (debug keys): the fallback still never loses items
    (0, step_1.stepWorld)(w, 1 / 60);
    strict_1.default.equal(pl.inventory.length, 8);
    strict_1.default.equal(total(w, "wood"), wood);
    strict_1.default.equal(total(w, "stone"), stone);
    strict_1.default.ok((0, inventory_1.hasItem)(pl, "chisel"));
    strict_1.default.ok((0, world_1.currentArea)(w).loose.some((l) => l.dyn && !l.taken), "overflow dropped into the world");
});
(0, node_test_1.test)("drop with Q: one unit, in front of the golem, stable id, saves, and can be picked up again", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, inventory_1.addItems)(w, pl, "coin", 1);
    (0, inventory_1.addItems)(w, pl, "wood", 3);
    pl.facing = "down";
    const slot = pl.inventory.findIndex((s) => s?.item === "wood");
    strict_1.default.equal((0, commands_1.dropFromSlot)(w, pl, slot), "ok");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 2);
    const a = (0, world_1.currentArea)(w), l = a.loose.find((x) => x.dyn);
    strict_1.default.equal(l.id, "drop0");
    strict_1.default.equal(Math.floor(l.y / tiles_1.TS), Math.floor((pl.y - 3) / tiles_1.TS) + 1, "landed on the tile in front");
    strict_1.default.equal((0, commands_1.dropFromSlot)(w, pl, slot), "ok");
    strict_1.default.equal(a.loose.filter((x) => x.dyn && !x.taken).length, 1, "same spot merges into one stack");
    strict_1.default.equal(a.loose.find((x) => x.dyn).n, 2);
    const w2 = (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
    strict_1.default.deepEqual((0, save_1.serialize)(w2), (0, save_1.serialize)(w));
    const it = (0, interact_1.interactables)((0, world_1.currentArea)(w2)).find((i) => i.looseId === "drop0");
    (0, helpers_1.useOn)(w2, it);
    strict_1.default.equal((0, inventory_1.countItem)((0, world_1.player)(w2), "wood"), 3);
    strict_1.default.equal((0, world_1.getArea)(w2, "dungeon").looseItem("drop0").taken, true);
});
(0, node_test_1.test)("tutorial-critical items are not droppable", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    for (const id of ["chisel", "schematic", "core", "key", "glyph1"]) {
        (0, inventory_1.addItems)(w, pl, id, 1);
        (0, helpers_1.events)(w);
        strict_1.default.equal((0, commands_1.dropFromSlot)(w, pl, pl.inventory.findIndex((s) => s?.item === id)), "undroppable", id);
        strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "message"), "feedback");
        strict_1.default.ok((0, inventory_1.hasItem)(pl, id));
    }
});
(0, node_test_1.test)("dropped items can't satisfy ritual sockets or the centre", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), a = (0, world_1.currentArea)(w), r = a.ritual;
    (0, inventory_1.addItems)(w, pl, "coin", 1);
    (0, inventory_1.addItems)(w, pl, "crown", 1);
    const sock = (0, helpers_1.find)(w, (i) => i.kind === "socket" && i.socket === 0);
    pl.x = sock.x;
    pl.y = sock.y + 9;
    pl.facing = "up";
    (0, commands_1.dropFromSlot)(w, pl, 0);
    const c = a.ritualPos;
    pl.x = c.x;
    pl.y = c.y + 12;
    (0, commands_1.dropFromSlot)(w, pl, 1);
    (0, helpers_1.frames)(w, 30);
    strict_1.default.deepEqual(r.sockets, [-1, -1, -1, -1]);
    strict_1.default.equal(r.core, false);
    strict_1.default.ok(!(0, helpers_1.events)(w).some((e) => e.t === "runeActivated" || e.t === "runeFizzled" || e.t === "glyphPlaced"));
});
(0, node_test_1.test)("the surface basket is picked up into the pack; worn, it grants the 48-slot tier", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, world_1.enterArea)(w, pl, "surface", 100, 100);
    const it = (0, helpers_1.find)(w, (i) => i.looseId === "basket");
    (0, helpers_1.useOn)(w, it);
    strict_1.default.ok((0, inventory_1.hasItem)(pl, "basket"), "stored like any item");
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 8);
    strict_1.default.equal((0, commands_1.wearFromSlot)(w, pl, pl.inventory.findIndex((s) => s?.item === "basket")), "ok");
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 48);
    strict_1.default.ok(!(0, inventory_1.hasItem)(pl, "basket"), "worn, not stored");
});
(0, node_test_1.test)("a full 48-slot inventory round-trips through save/load", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    pl.gear.back = "basket";
    const ids = ["wood", "stone", "coin", "crown", "goblet", "chisel"];
    for (let i = 0; i < 48; i++)
        (0, inventory_1.addItems)(w, pl, ids[i % ids.length], ids[i % ids.length] === "wood" || ids[i % ids.length] === "stone" ? 20 : 1);
    strict_1.default.equal(pl.inventory.filter(Boolean).length, 48);
    const w2 = (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
    strict_1.default.deepEqual((0, world_1.player)(w2).inventory, pl.inventory);
});
(0, node_test_1.test)("a v1 save (ItemId[] inventory, area-less schedule) migrates to the current version", () => {
    const w = (0, helpers_1.newWorld)(4242), pl = (0, world_1.player)(w);
    (0, inventory_1.addItems)(w, pl, "chisel", 1);
    (0, inventory_1.addItems)(w, pl, "coin", 1);
    (0, tasks_1.schedule)(w, 5, pl, { op: "grantItem", item: "goblet" });
    const s = (0, save_1.serialize)(w);
    const v1 = {
        ...s, version: 1,
        actors: s.actors.map((a) => ({ ...a, inventory: a.inventory.filter(Boolean).map((x) => x.item), task: null, queue: [] })),
        scheduled: s.scheduled.map(({ area: _a, ...e }) => e),
        areas: Object.fromEntries(Object.entries(s.areas).map(([id, d]) => {
            const { looseAdded: _l, looseSeq: _q, propsAdded: _p, propSeq: _s, ...rest } = d;
            return [id, rest];
        })),
    };
    const w2 = (0, save_1.deserialize)(v1);
    strict_1.default.equal(save_1.SAVE_VERSION, 19); // v18: townsfolk (tests/folk.test.ts); v19: shops (tests/shops.test.ts)
    strict_1.default.deepEqual((0, world_1.player)(w2).inventory.filter(Boolean), [{ item: "chisel", n: 1 }, { item: "coin", n: 1 }]);
    strict_1.default.equal((0, world_1.player)(w2).inventory.length, 8);
    strict_1.default.equal(w2.scheduled[0].area, "dungeon");
    for (let i = 0; i < 400; i++)
        (0, step_1.stepWorld)(w2, 1 / 60);
    strict_1.default.ok((0, inventory_1.hasItem)((0, world_1.player)(w2), "goblet"), "migrated schedule still fires");
});
// ------------------------------------------------------------------ Part B
(0, node_test_1.test)("rune links resolve both ways from one declaration", () => {
    strict_1.default.equal((0, runes_2.runeDestination)("dungeon").node.id, "surface");
    strict_1.default.equal((0, runes_2.runeDestination)("surface").node.id, "dungeon");
});
(0, node_test_1.test)("an inactive rune gives feedback and does nothing", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    strict_1.default.equal((0, runes_1.travel)(w, pl, (0, world_1.currentArea)(w), "rune.dungeon"), false);
    strict_1.default.equal(pl.area, "dungeon");
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "message"));
    (0, world_1.enterArea)(w, pl, "surface", 100, 100);
    const it = (0, helpers_1.find)(w, (i) => i.kind === "rune");
    (0, helpers_1.useOn)(w, it);
    strict_1.default.equal(pl.area, "surface", "dormant surface rune goes nowhere");
});
(0, node_test_1.test)("tutorial teleport arrives at the surface rune via the network and wakes it", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    toSurface(w);
    strict_1.default.equal(pl.area, "surface");
    strict_1.default.ok(w.flags.has(runes_2.RUNE_NODES.surface.flag) && w.flags.has(flags_1.FLAGS.tutorialDone));
    const rp = (0, world_1.getArea)(w, "surface").prop("rune.surface");
    strict_1.default.ok(Math.hypot(pl.x - rp.x, pl.y - rp.y) < 12, "placed at the linked rune");
});
(0, node_test_1.test)("round trip: back to the dungeon circle without re-triggering the tutorial, and up again", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    toSurface(w);
    const flags = [...w.flags].sort();
    const ritual = JSON.stringify((0, world_1.getArea)(w, "dungeon").ritual);
    (0, helpers_1.events)(w);
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "rune"));
    let g = 0;
    while (pl.area !== "dungeon" && g++ < 400)
        (0, helpers_1.frame)(w);
    strict_1.default.equal(pl.area, "dungeon");
    const c = (0, world_1.getArea)(w, "dungeon").ritualPos;
    strict_1.default.ok(Math.abs(pl.x - c.x) < 4 && pl.y > c.y + 20, "arrived just south of the circle");
    (0, helpers_1.frames)(w, 400);
    const ev = (0, helpers_1.events)(w);
    strict_1.default.ok(!ev.some((e) => e.t === "teleport" && e.first), "no first-jump cinematic again");
    strict_1.default.equal(pl.area, "dungeon", "standing near the circle does not bounce back");
    strict_1.default.deepEqual([...w.flags].sort(), flags);
    strict_1.default.equal(JSON.stringify((0, world_1.getArea)(w, "dungeon").ritual).replace(/"actT":[\d.e-]+/, ""), ritual.replace(/"actT":[\d.e-]+/, ""));
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "rune"));
    g = 0;
    while (pl.area !== "surface" && g++ < 400)
        (0, helpers_1.frame)(w);
    strict_1.default.equal(pl.area, "surface");
});
(0, node_test_1.test)("arrival falls back to the nearest free spot when the rune is blocked", () => {
    const w = (0, helpers_1.newWorld)();
    const s = (0, world_1.getArea)(w, "surface"), rp = s.prop("rune.surface"), n = runes_2.RUNE_NODES.surface;
    s.addProp("rock", rp.x + n.arrive.dx, rp.y + n.arrive.dy + 4);
    const spot = (0, runes_1.arrivalSpot)(w, n);
    strict_1.default.ok((0, collision_1.boxFree)(s, spot.x, spot.y));
    strict_1.default.notDeepEqual(spot, { x: rp.x + n.arrive.dx, y: rp.y + n.arrive.dy });
    strict_1.default.deepEqual((0, runes_1.arrivalSpot)(w, n), spot, "deterministic");
});
// ------------------------------------------------------------------ Part C
/** Where the golem stands to slam a prop: just below it, facing up, so the fists land in its footprint. */
const slamSpot = (p) => ({ x: p.x, y: p.y + 9 });
/** Slam a prop (harvesting is the attack: trees and rocks are not interactables). */
function slamProp(w, p) {
    const s = slamSpot(p), pl = (0, world_1.player)(w);
    pl.x = s.x;
    pl.y = s.y;
    pl.vx = 0;
    pl.vy = 0;
    pl.facing = "up";
    (0, helpers_1.frame)(w, { ix: 0, iy: 0, use: false, attack: true });
    let g = 0;
    while (pl.task && g++ < 1000)
        (0, helpers_1.frame)(w);
    (0, helpers_1.frames)(w, 30);
}
/** The nearest standing tree that is the only harvestable the blow reaches, so a slam at it harvests just it. */
function nearestTree(w) {
    const pl = (0, world_1.player)(w), a = (0, world_1.currentArea)(w);
    return a.props.filter((p) => p.kind === "tree" && !p.taken && (0, harvesting_1.harvestReach)(a, p.x, p.y + 2, tasks_2.SLAM_RADIUS).length === 1)
        .sort((p, q) => Math.hypot(p.x - pl.x, p.y - pl.y) - Math.hypot(q.x - pl.x, q.y - pl.y))[0];
}
(0, node_test_1.test)("multi-hit harvest: damage lives on the tree, yields wood, then depletes to a stump", () => {
    const w = (0, helpers_1.newWorld)();
    toSurface(w);
    const pl = (0, world_1.player)(w), p = nearestTree(w);
    const rev = (0, world_1.currentArea)(w).revision;
    for (let i = 0; i < 3; i++)
        slamProp(w, p);
    strict_1.default.equal(p.dmg, 3);
    strict_1.default.equal(p.taken, false);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 3);
    strict_1.default.ok((0, world_1.currentArea)(w).revision > rev);
    slamProp(w, p);
    strict_1.default.equal(p.taken, true, "depleted (permanent in v1)");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), harvest_1.HARVEST.tree.hp * harvest_1.HARVEST.tree.perHit.n + harvest_1.HARVEST.tree.final.n);
    strict_1.default.ok(!(0, interact_1.interactables)((0, world_1.currentArea)(w)).some((i) => i.propId === p.id));
});
(0, node_test_1.test)("harvesting with a full pack drops the yield on the ground", () => {
    const w = (0, helpers_1.newWorld)();
    toSurface(w);
    const pl = (0, world_1.player)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
    for (let i = 0; i < 16; i++)
        (0, inventory_1.addItems)(w, pl, i % 2 ? "coin" : "crown", 1);
    slamProp(w, nearestTree(w));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 0);
    strict_1.default.equal(total(w, "wood"), 1);
});
(0, node_test_1.test)("regrow hook schedules into the prop's own area, even after the harvester travels", () => {
    const w = (0, helpers_1.newWorld)();
    toSurface(w);
    const pl = (0, world_1.player)(w), p = nearestTree(w);
    harvest_1.HARVEST.tree.regrow = 2;
    try {
        for (let i = 0; i < 4; i++)
            slamProp(w, p);
        strict_1.default.equal(p.taken, true);
        strict_1.default.equal(w.scheduled.at(-1).area, "surface");
        (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "rune"));
        let g = 0;
        while (pl.area !== "dungeon" && g++ < 400)
            (0, helpers_1.frame)(w);
        (0, helpers_1.frames)(w, 200);
        strict_1.default.equal(p.taken, false, "regrew in the surface while the golem was below");
        strict_1.default.equal(p.dmg, 0);
    }
    finally {
        delete harvest_1.HARVEST.tree.regrow;
    }
});
(0, node_test_1.test)("queued work aimed at an area is dropped when its actor travels", () => {
    const w = (0, helpers_1.newWorld)();
    const a = (0, world_1.makeActor)("helper", "fixture", "dungeon", 100, 100);
    w.actors.push(a);
    (0, tasks_1.enqueueTask)(a, { kind: "reach", dur: 0.5, effect: { op: "cue", cue: "scrape" } });
    (0, world_1.enterArea)(w, a, "surface", 100, 100);
    strict_1.default.equal(a.queue.length, 0);
});
(0, node_test_1.test)("build placement is validated in sim and gated by know.build", () => {
    const w = (0, helpers_1.newWorld)();
    toSurface(w);
    const pl = (0, world_1.player)(w), a = (0, world_1.currentArea)(w);
    pl.x = 20 * tiles_1.TS + 8;
    pl.y = 50 * tiles_1.TS + 14;
    pl.facing = "down";
    for (let ty = 49; ty <= 53; ty++)
        for (let tx = 18; tx <= 22; tx++)
            a.setTile(tx, ty, tiles_1.T.FLOOR);
    a.props = a.props.filter((p) => Math.abs(p.x - pl.x) > 64 || Math.abs(p.y - pl.y) > 64);
    const tx = 20, ty = 51;
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "torch_post", tx, ty), { ok: false, reason: "unknown" });
    (0, inventory_1.addItems)(w, pl, "book_build", 1);
    (0, commands_1.readItem)(w, pl, "book_build");
    strict_1.default.ok(w.flags.has(flags_1.FLAGS.knowBuild));
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "torch_post", tx, ty), { ok: false, reason: "cost" });
    (0, inventory_1.addItems)(w, pl, "wood", 4);
    (0, inventory_1.addItems)(w, pl, "stone", 2);
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "torch_post", tx, ty), { ok: true });
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "torch_post", tx, ty + 4), { ok: false, reason: "reach" });
    a.setTile(tx + 1, ty, tiles_1.T.RUBBLE);
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "torch_post", tx + 1, ty), { ok: false, reason: "solid" });
    const rp = a.prop("rune.surface");
    pl.x = rp.x;
    pl.y = rp.y + 40;
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "torch_post", Math.floor(rp.x / tiles_1.TS), Math.floor(rp.y / tiles_1.TS) + 1), { ok: false, reason: "occupied" });
});
(0, node_test_1.test)("placing a torch consumes materials, creates a lit prop and registers its light; saves", () => {
    const w = (0, helpers_1.newWorld)();
    toSurface(w);
    const pl = (0, world_1.player)(w), a = (0, world_1.currentArea)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    (0, inventory_1.addItems)(w, pl, "wood", 3);
    (0, inventory_1.addItems)(w, pl, "stone", 1);
    const rp = a.prop("rune.surface");
    pl.x = rp.x + 72;
    pl.y = rp.y + 8;
    pl.facing = "right";
    const tx = Math.floor(pl.x / tiles_1.TS) + 1, ty = Math.floor((pl.y - 3) / tiles_1.TS);
    const view = new areaView_1.AreaView(a);
    strict_1.default.ok((0, commands_1.orderBuild)(w, pl, "torch_post", tx, ty));
    while (pl.task)
        (0, helpers_1.frame)(w);
    const torch = a.props.find((p) => p.kind === "torch_post");
    strict_1.default.ok(torch && torch.lit && torch.dyn);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "stone"), 0);
    view.flush();
    strict_1.default.ok(view.lights.has("prop:" + torch.id), "light reconciled from area.revision, no manual re-bake");
    view.prepare(torch.x - 160, torch.y - 90, 320, 180);
    strict_1.default.ok(view.lights.get("prop:" + torch.id).n > 0, "traced once in view");
    // a partially harvested tree too
    const t = nearestTree(w);
    slamProp(w, t);
    const w2 = (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
    strict_1.default.deepEqual((0, save_1.serialize)(w2), (0, save_1.serialize)(w));
    const a2 = (0, world_1.currentArea)(w2);
    strict_1.default.equal(a2.prop(torch.id).lit, true);
    strict_1.default.equal(a2.prop(t.id).dmg, 1);
    strict_1.default.ok(new areaView_1.AreaView(a2).lights.has("prop:" + torch.id));
});
(0, node_test_1.test)("surface changes persist across travel and save/load", () => {
    const w = (0, helpers_1.newWorld)();
    toSurface(w);
    const pl = (0, world_1.player)(w);
    slamProp(w, nearestTree(w));
    (0, inventory_1.addItems)(w, pl, "coin", 1);
    pl.facing = "down";
    (0, commands_1.dropFromSlot)(w, pl, pl.inventory.findIndex((s) => s?.item === "coin"));
    const snap = JSON.stringify((0, save_1.serialize)(w).areas.surface);
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "rune"));
    let g = 0;
    while (pl.area !== "dungeon" && g++ < 400)
        (0, helpers_1.frame)(w);
    const mid = (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
    strict_1.default.equal(JSON.stringify((0, save_1.serialize)(mid).areas.surface), snap, "mid-travel save keeps the surface");
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "rune"));
    g = 0;
    while (pl.area !== "surface" && g++ < 400)
        (0, helpers_1.frame)(w);
    strict_1.default.equal(JSON.stringify((0, save_1.serialize)(w).areas.surface), snap);
});
// ------------------------------------------------------------------ Part D
(0, node_test_1.test)("perf report: surface bake and light tracing, full vs view-window", () => {
    const s = (0, world_1.getArea)((0, helpers_1.newWorld)(), "surface");
    // The wild surface has a single builder light (the rune). Add one far from the
    // view so "only lights near the view get traced" is still exercised.
    s.lights.push({ x: (s.w - 4) * tiles_1.TS, y: (s.h - 4) * tiles_1.TS, rad: 40, col: [1, 1, 1], int: 0.5, flick: 0, id: "far-probe" });
    const c = (0, util_1.makeCanvas)(s.w * tiles_1.TS, s.h * tiles_1.TS);
    let t0 = performance.now();
    (0, tiles_2.bakeRegion)(c.ctx, s, 0, 0, s.w - 1, s.h - 1);
    const fullBake = performance.now() - t0;
    const lights = s.lights.map((l) => (0, light_1.makeLight)(l.x, l.y, l.rad, l.col, l.int, l.flick));
    t0 = performance.now();
    for (const L of lights)
        (0, light_1.computeVis)(L, s);
    const fullVis = performance.now() - t0;
    const v = new areaView_1.AreaView(s);
    const rp = s.prop("rune.surface");
    t0 = performance.now();
    v.prepare(rp.x - 160, rp.y - 102, 320, 180);
    const firstFrame = performance.now() - t0;
    t0 = performance.now();
    let n = 0;
    while (v.idle())
        n++;
    const idleTotal = performance.now() - t0;
    console.log(`# PERF surface ${s.w}x${s.h}: full bake ${fullBake.toFixed(1)}ms, all ${lights.length} lights traced ${fullVis.toFixed(1)}ms | ` +
        `chunked first frame ${firstFrame.toFixed(1)}ms (${v.stats.chunksBaked - n} chunks, ${v.stats.visTraced} lights), then ${n} chunks in background (${(idleTotal / Math.max(1, n)).toFixed(1)}ms/frame)`);
    strict_1.default.ok(v.fullyBaked);
    strict_1.default.ok(v.stats.visTraced < lights.length);
});
(0, node_test_1.test)("save-size report: mass tile edits on the surface", () => {
    const w = (0, helpers_1.newWorld)();
    const s = (0, world_1.getArea)(w, "surface");
    const base = JSON.stringify((0, save_1.serialize)(w)).length;
    let n = 0;
    for (let ty = 4; ty < s.h - 4 && n < 3000; ty++)
        for (let tx = 4; tx < s.w - 4 && n < 3000; tx++) {
            s.setTile(tx, ty, s.tile(tx, ty) === tiles_1.T.FLOOR ? tiles_1.T.RUBBLE : tiles_1.T.FLOOR);
            n++;
        }
    const size = JSON.stringify((0, save_1.serialize)(w)).length;
    console.log(`# SAVE baseline ${base} B; after ${n} surface tile edits ${size} B (${((size - base) / n).toFixed(1)} B/tile)`);
    strict_1.default.ok(size < 100000);
});
