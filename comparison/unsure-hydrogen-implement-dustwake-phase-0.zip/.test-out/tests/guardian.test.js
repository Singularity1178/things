"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The Treasury Guardian encounter and the NPC/dialogue foundation it sits on,
// driven headlessly through the sim (no browser).
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const world_1 = require("../src/game/world/world");
const tiles_1 = require("../src/game/content/tiles");
const flags_1 = require("../src/game/content/flags");
const dialogue_1 = require("../src/game/content/dialogue");
const dialogueLayout_1 = require("../src/game/ui/dialogueLayout");
const npcs_1 = require("../src/game/content/npcs");
const actors_1 = require("../src/game/content/actors");
const font_1 = require("../src/game/font");
const interact_1 = require("../src/game/sim/interact");
const inventory_1 = require("../src/game/sim/inventory");
const tasks_1 = require("../src/game/sim/tasks");
const dialogue_2 = require("../src/game/sim/dialogue");
const collision_1 = require("../src/game/sim/collision");
const reach_1 = require("../src/game/sim/reach");
const save_1 = require("../src/game/world/save");
const helpers_1 = require("./helpers");
const G = helpers_1.GUARDIAN;
const corePresent = (w) => {
    let n = 0;
    for (const a of w.actors)
        n += (0, inventory_1.countItem)(a, "core");
    for (const area of w.areas.values()) {
        n += area.loose.filter((l) => !l.taken && l.item === "core").length;
        if (area.ritual?.core)
            n++;
    }
    return n;
};
// ------------------------------------------------------------------ encounter
(0, node_test_1.test)("the guardian is an NPC actor, dormant in the treasury, with an empty pack", () => {
    const w = (0, helpers_1.newWorld)();
    const g = (0, world_1.actorById)(w, G);
    strict_1.default.equal(g.kind, "npc");
    strict_1.default.equal(g.npc, "guardian");
    strict_1.default.equal(g.area, "dungeon");
    strict_1.default.deepEqual(g.inventory, []);
    const tx = Math.floor(g.x / tiles_1.TS), ty = Math.floor(g.y / tiles_1.TS);
    strict_1.default.ok(tx >= 52 && tx <= 59 && ty >= 3 && ty <= 8, `in the treasury (${tx},${ty})`);
    strict_1.default.equal((0, dialogue_2.isAwake)(w, G), false);
    (0, helpers_1.frames)(w, 120);
    strict_1.default.deepEqual(g.inventory, [], "capacity tiers (golem.*) do not apply to NPCs");
    strict_1.default.equal(npcs_1.NPCS.guardian.type, "special");
});
(0, node_test_1.test)("full encounter: wake, repair, core, farewell; repeating grants nothing", () => {
    const w = (0, helpers_1.newWorld)(7), pl = (0, world_1.player)(w);
    (0, helpers_1.events)(w);
    (0, helpers_1.useOn)(w, (0, helpers_1.guardianIt)(w));
    const ev = (0, helpers_1.events)(w);
    const d = ev.find((e) => e.t === "dialogue");
    strict_1.default.ok(d && d.t === "dialogue" && d.segment === "intro" && d.npc === G && d.script === "guardian");
    const script = (0, dialogue_2.scriptOf)(w, G);
    let seg = (0, dialogue_2.currentSegment)(w, pl, script);
    const order = [];
    while (seg) {
        order.push(seg.id);
        seg = (0, dialogue_2.playSegment)(w, pl, G, seg);
    }
    strict_1.default.deepEqual(order, ["intro", "repair", "core", "farewell"]);
    const all = (0, helpers_1.events)(w);
    strict_1.default.ok(all.some((e) => e.t === "npcState" && e.awake));
    strict_1.default.ok(all.some((e) => e.t === "eyeRepaired" && e.by === G));
    strict_1.default.ok(all.some((e) => e.t === "npcState" && !e.awake));
    strict_1.default.ok((0, world_1.hasFlag)(w, flags_1.FLAGS.golemEye));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "core"), 1);
    strict_1.default.equal(corePresent(w), 1);
    strict_1.default.equal((0, dialogue_2.isAwake)(w, G), false, "dormant again");
    for (const f of [dialogue_1.GUARDIAN_FLAGS.met, dialogue_1.GUARDIAN_FLAGS.coreGiven, dialogue_1.GUARDIAN_FLAGS.farewell])
        strict_1.default.ok((0, world_1.hasFlag)(w, f), f);
    // Talking again: a short examine-style line, no dialogue.
    (0, helpers_1.useOn)(w, (0, helpers_1.guardianIt)(w));
    const again = (0, helpers_1.events)(w);
    strict_1.default.ok(!again.some((e) => e.t === "dialogue"));
    strict_1.default.ok(again.some((e) => e.t === "message" && /NOT STIR/.test(e.text)));
    // Forcing every beat and segment again changes nothing.
    for (const s of script.segments) {
        for (const p of s.pages)
            for (const b of [p.beat, p.then])
                if (b)
                    (0, dialogue_2.dialogueBeat)(w, pl, G, s.id, b);
        (0, dialogue_2.finishSegment)(w, pl, G, s.id);
    }
    (0, tasks_1.applyEffect)(w, pl, { op: "npcGive", npc: G, item: "core", once: dialogue_1.GUARDIAN_FLAGS.coreGiven });
    strict_1.default.equal(corePresent(w), 1, "exactly one core, ever");
    strict_1.default.ok(!(0, helpers_1.events)(w).some((e) => e.t === "eyeRepaired" || e.t === "itemGained"));
});
(0, node_test_1.test)("beats are validated against the script: no core before the guardian has spoken", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    strict_1.default.equal((0, dialogue_2.dialogueBeat)(w, pl, G, "core", "giveCore"), false, "core segment not yet available");
    strict_1.default.equal((0, dialogue_2.dialogueBeat)(w, pl, G, "intro", "giveCore"), false, "beat not in that segment");
    strict_1.default.equal((0, dialogue_2.dialogueBeat)(w, pl, "npc.nobody", "intro", "wake"), false);
    strict_1.default.equal(corePresent(w), 0);
});
(0, node_test_1.test)("an interrupted dialogue resumes at the first unfinished segment", () => {
    const w = (0, helpers_1.newWorld)(3), pl = (0, world_1.player)(w);
    const script = (0, dialogue_2.scriptOf)(w, G);
    const seg = (id) => script.segments.find((s) => s.id === id);
    // Esc during the intro: awake, but not yet met; the intro plays again.
    strict_1.default.equal((0, dialogue_2.talkTo)(w, pl, G)?.id, "intro");
    (0, dialogue_2.playSegment)(w, pl, G, seg("intro"), 3);
    strict_1.default.ok((0, dialogue_2.isAwake)(w, G) && !(0, world_1.hasFlag)(w, dialogue_1.GUARDIAN_FLAGS.met));
    strict_1.default.equal((0, dialogue_2.talkTo)(w, pl, G)?.id, "intro");
    (0, dialogue_2.playSegment)(w, pl, G, seg("intro"));
    // Esc before the repair beat: no eye yet, the repair segment is next again.
    strict_1.default.equal((0, dialogue_2.talkTo)(w, pl, G)?.id, "repair");
    (0, dialogue_2.playSegment)(w, pl, G, seg("repair"), 0);
    strict_1.default.ok(!(0, world_1.hasFlag)(w, flags_1.FLAGS.golemEye));
    strict_1.default.equal((0, dialogue_2.talkTo)(w, pl, G)?.id, "repair");
    // Esc right after the repair beat: the eye is mended, so the core is next.
    (0, dialogue_2.playSegment)(w, pl, G, seg("repair"), 1);
    strict_1.default.ok((0, world_1.hasFlag)(w, flags_1.FLAGS.golemEye));
    strict_1.default.equal((0, dialogue_2.talkTo)(w, pl, G)?.id, "core");
    // Esc right after the core is handed over: farewell is next; still one core.
    (0, dialogue_2.playSegment)(w, pl, G, seg("core"), 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "core"), 1);
    strict_1.default.equal((0, dialogue_2.talkTo)(w, pl, G)?.id, "farewell");
    // Esc on the last farewell page (before its goDormant): it stays awake and the farewell replays.
    (0, dialogue_2.playSegment)(w, pl, G, seg("farewell"), 2);
    strict_1.default.ok((0, dialogue_2.isAwake)(w, G));
    strict_1.default.equal((0, dialogue_2.talkTo)(w, pl, G)?.id, "farewell");
    (0, dialogue_2.playSegment)(w, pl, G, seg("farewell"));
    strict_1.default.equal((0, dialogue_2.talkTo)(w, pl, G), null);
    strict_1.default.ok(!(0, dialogue_2.isAwake)(w, G));
    strict_1.default.equal(corePresent(w), 1);
    strict_1.default.ok((0, world_1.hasFlag)(w, flags_1.FLAGS.golemEye));
});
(0, node_test_1.test)("a full pack: the core lands on the ground, clear of the guardian, and can be picked up", () => {
    const w = (0, helpers_1.newWorld)(5), pl = (0, world_1.player)(w);
    const fill = ["chisel", "key", "glyph0", "glyph1", "glyph2", "glyph3", "crown", "goblet"];
    for (const id of fill)
        (0, inventory_1.addItems)(w, pl, id, 1);
    strict_1.default.equal(pl.inventory.filter(Boolean).length, (0, inventory_1.capacity)(w, pl));
    (0, helpers_1.talkThrough)(w, (0, helpers_1.guardianIt)(w));
    const ev = (0, helpers_1.events)(w);
    strict_1.default.ok(!ev.some((e) => e.t === "itemGained" && e.item === "core"));
    strict_1.default.ok((0, world_1.hasFlag)(w, dialogue_1.GUARDIAN_FLAGS.coreGiven));
    const a = (0, world_1.currentArea)(w);
    const core = a.loose.find((l) => !l.taken && l.item === "core");
    strict_1.default.ok(core, "core on the ground");
    const gb = (0, collision_1.actorBox)((0, world_1.actorById)(w, G));
    strict_1.default.ok(core.x < gb[0] - 3 || core.x > gb[2] + 3 || core.y < gb[1] - 3 || core.y > gb[3] + 3, "not under the guardian");
    strict_1.default.equal(corePresent(w), 1);
    // make room and pick it up
    pl.inventory[pl.inventory.findIndex((s) => s?.item === "crown")] = null;
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.looseId === core.id));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "core"), 1);
    strict_1.default.equal(corePresent(w), 1);
});
// ------------------------------------------------------------------ treasury
/** Blocking boxes in the dungeon: props and every body but the player's; `withGuardian` false leaves out only the guardian. */
const boxesOf = (w, withGuardian = true) => {
    const a = (0, world_1.getArea)(w, "dungeon"), g = (0, collision_1.actorBox)((0, world_1.actorById)(w, G));
    const b = a.props.filter(collision_1.propBlocks).map((p) => p.box);
    const bodies = (0, collision_1.actorBoxes)(w, "dungeon", w.playerId);
    return [...b, ...(withGuardian ? bodies : bodies.filter((x) => x.join() !== g.join()))];
};
(0, node_test_1.test)("the treasury chest is looted: open, empty, not a container", () => {
    const w = (0, helpers_1.newWorld)();
    const c = (0, world_1.currentArea)(w).prop("chest@57,4");
    strict_1.default.equal(c.open, true);
    strict_1.default.equal(c.item, undefined);
    strict_1.default.ok(!c.container);
    strict_1.default.ok(!(0, interact_1.interactables)((0, world_1.currentArea)(w)).some((i) => i.propId === "chest@57,4"));
    strict_1.default.ok(!(0, world_1.currentArea)(w).props.some((p) => p.item === "core"), "no prop holds the core");
    // a save diff does not record the builder's open state
    strict_1.default.equal((0, save_1.serialize)(w).areas.dungeon.props["chest@57,4"], undefined);
});
(0, node_test_1.test)("the treasury and the guardian are reachable; the guardian blocks nothing", () => {
    const w = (0, helpers_1.newWorld)(), a = (0, world_1.getArea)(w, "dungeon");
    a.setTile(51, 5, tiles_1.T.FLOOR); // the door, once unlocked
    a.setTile(47, 10, tiles_1.T.FLOOR);
    a.setTile(47, 11, tiles_1.T.FLOOR); // the cracked wall, once broken
    const withG = (0, reach_1.reachable)(a, boxesOf(w), a.base.start);
    const without = (0, reach_1.reachable)(a, boxesOf(w, false), a.base.start);
    const g = (0, world_1.actorById)(w, G), gb = (0, collision_1.actorBox)(g);
    // the doorway and the treasury floor in front of the guardian are reachable
    strict_1.default.equal(withG[5 * a.w + 51], 1, "doorway");
    strict_1.default.equal(withG[6 * a.w + 55], 1, "treasury floor");
    const it = (0, helpers_1.guardianIt)(w);
    strict_1.default.ok((0, reach_1.nearReached)(a, withG, it.x, it.y + it.r / 2, 0), "a spot to talk from");
    // every cell reachable without the guardian is still reachable, unless the golem would overlap its body
    for (let ty = 0; ty < a.h; ty++)
        for (let tx = 0; tx < a.w; tx++) {
            if (!without[ty * a.w + tx] || withG[ty * a.w + tx])
                continue;
            const fx = tx * tiles_1.TS + 8, fy = ty * tiles_1.TS + 11;
            const overlaps = fx + 5 > gb[0] && fx - 5 < gb[2] && fy > gb[1] && fy - 5 < gb[3];
            strict_1.default.ok(overlaps, `guardian cuts off ${tx},${ty}`);
        }
    // the treasury's loose coin is still reachable
    const coin = a.looseItem("coin");
    strict_1.default.ok((0, reach_1.nearReached)(a, withG, coin.x, coin.y));
});
(0, node_test_1.test)("the golem cannot walk through the guardian", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), g = (0, world_1.actorById)(w, G);
    (0, world_1.currentArea)(w).setTile(51, 5, tiles_1.T.FLOOR);
    pl.x = g.x;
    pl.y = g.y + 20;
    pl.facing = "up";
    (0, helpers_1.frames)(w, 240, { ix: 0, iy: -1, use: false });
    strict_1.default.ok(pl.y - 5 >= g.y - 0.01, `stopped at its body (golem feet ${pl.y.toFixed(1)}, guardian feet ${g.y})`);
    strict_1.default.ok(!(0, collision_1.boxFree)((0, world_1.currentArea)(w), g.x, g.y - 2, (0, collision_1.actorBoxes)(w, "dungeon", pl.id)));
});
// ------------------------------------------------------------------ data lint
(0, node_test_1.test)("dialogue text, as wrapped for the box, uses font glyphs only and never overflows it", () => {
    const ok = (s, where) => {
        for (const ch of s)
            strict_1.default.ok(font_1.FONT_GLYPHS.has(ch), `${where}: glyph ${JSON.stringify(ch)} not in the font`);
    };
    for (const [sid, script] of Object.entries(dialogue_1.DIALOGUE)) {
        ok(script.idle, `${sid}.idle`);
        strict_1.default.ok(script.idle.length <= 60, `${sid}.idle fits the note line`);
        const ids = new Set();
        for (const seg of script.segments) {
            strict_1.default.ok(!ids.has(seg.id), `${sid}: duplicate segment ${seg.id}`);
            ids.add(seg.id);
            strict_1.default.ok(seg.pages.length > 0);
            seg.pages.forEach((p, i) => {
                const where = `${sid}.${seg.id}[${i}]`;
                strict_1.default.ok(p.text.trim().length > 0, `${where}: empty page`);
                // What the box shows: the paragraph wrapped to the box width, paginated to its line capacity.
                const screens = (0, dialogueLayout_1.layoutDialogue)([p]);
                for (const sc of screens) {
                    strict_1.default.ok(sc.lines.length >= 1 && sc.lines.length <= dialogueLayout_1.DIALOGUE_LINES, `${where}: ${sc.lines.length} lines on one screen`);
                    for (const l of sc.lines) {
                        ok(l, where);
                        strict_1.default.ok(l.length <= dialogueLayout_1.DIALOGUE_COLS, `${where}: "${l}" is ${l.length} chars`);
                        // glyphs + the 1 px shadow stay inside the inset text area
                        strict_1.default.ok((0, font_1.textWidth)(l) + 1 <= dialogueLayout_1.DIALOGUE_BOX.w - 2 * dialogueLayout_1.DIALOGUE_BOX.padX, `${where}: "${l}" overflows the box`);
                    }
                }
                // wrapping only re-flows whitespace: nothing authored is lost or reordered
                strict_1.default.equal(screens.flatMap((sc) => sc.lines).join(" ").replace(/\s+/g, " ").trim(), p.text.replace(/\s+/g, " ").trim(), where);
                if (p.speaker)
                    ok(p.speaker, where);
                for (const b of [p.beat, p.then])
                    if (b)
                        strict_1.default.ok(dialogue_1.BEATS[b], `${where}: unknown beat ${b}`);
            });
        }
    }
    for (const [id, d] of Object.entries(npcs_1.NPCS)) {
        ok(d.name, id);
        strict_1.default.ok(dialogue_1.DIALOGUE[d.dialogue], `${id}: script ${d.dialogue}`);
    }
});
// ------------------------------------------------------------------ saves
/** A v4 save of `w`, as the old build would have written it (no NPC actors or flags; the chest was a closed container). */
function asV4(w, chestOpened) {
    const s = JSON.parse(JSON.stringify((0, save_1.serialize)(w)));
    s.version = 4;
    s.actors = s.actors.filter((a) => a.kind !== "npc");
    s.flags = s.flags.filter((f) => !f.startsWith("npc."));
    const props = { ...s.areas.dungeon.props };
    delete props["chest@57,4"];
    if (chestOpened)
        props["chest@57,4"] = { open: true, item: null };
    s.areas.dungeon.props = props;
    return s;
}
(0, node_test_1.test)("v4 -> v5: a save without the core gets a dormant guardian who still gives it", () => {
    strict_1.default.equal(save_1.SAVE_VERSION, 19); // v18: townsfolk (tests/folk.test.ts); v19: shops (tests/shops.test.ts)
    const w0 = (0, helpers_1.newWorld)(11), pl0 = (0, world_1.player)(w0);
    (0, inventory_1.addItems)(w0, pl0, "chisel", 1);
    pl0.x = 56 * tiles_1.TS;
    pl0.y = 7 * tiles_1.TS;
    const w = (0, save_1.deserialize)(asV4(w0, false)), pl = (0, world_1.player)(w);
    const g = (0, world_1.actorById)(w, G);
    strict_1.default.ok(g && g.kind === "npc" && g.npc === "guardian");
    strict_1.default.ok(!(0, dialogue_2.isAwake)(w, G) && !(0, world_1.hasFlag)(w, dialogue_1.GUARDIAN_FLAGS.coreGiven));
    strict_1.default.equal((0, world_1.getArea)(w, "dungeon").prop("chest@57,4").open, true, "the chest is the empty one");
    strict_1.default.equal(corePresent(w), 0);
    strict_1.default.deepEqual((0, helpers_1.talkThrough)(w, (0, helpers_1.guardianIt)(w)), ["intro", "repair", "core", "farewell"]);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "core"), 1);
    strict_1.default.equal(corePresent(w), 1);
});
(0, node_test_1.test)("v4 -> v5: a save whose core was taken or placed never gets a second one", () => {
    // taken: in the pack
    const a0 = (0, helpers_1.newWorld)(12);
    (0, inventory_1.addItems)(a0, (0, world_1.player)(a0), "core", 1);
    const a = (0, save_1.deserialize)(asV4(a0, true));
    strict_1.default.ok((0, world_1.hasFlag)(a, dialogue_1.GUARDIAN_FLAGS.coreGiven));
    strict_1.default.deepEqual((0, helpers_1.talkThrough)(a, (0, helpers_1.guardianIt)(a)), ["intro", "repair", "farewell"], "the story still plays, minus the gift");
    strict_1.default.ok((0, world_1.hasFlag)(a, flags_1.FLAGS.golemEye));
    strict_1.default.equal(corePresent(a), 1);
    // placed: seated in the circle (the pack no longer has it)
    const b0 = (0, helpers_1.newWorld)(13);
    (0, world_1.getArea)(b0, "dungeon").ritual.core = true;
    const b = (0, save_1.deserialize)(asV4(b0, true));
    strict_1.default.ok((0, world_1.hasFlag)(b, dialogue_1.GUARDIAN_FLAGS.coreGiven));
    (0, helpers_1.talkThrough)(b, (0, helpers_1.guardianIt)(b));
    strict_1.default.equal(corePresent(b), 1);
    // opened a moment before saving: the grant was still scheduled
    const c0 = (0, helpers_1.newWorld)(14);
    c0.scheduled.push({ at: c0.time + 0.2, actor: "golem", area: "dungeon", effect: { op: "grantItem", item: "core" } });
    const c = (0, save_1.deserialize)(asV4(c0, true));
    strict_1.default.ok((0, world_1.hasFlag)(c, dialogue_1.GUARDIAN_FLAGS.coreGiven));
    (0, helpers_1.frames)(c, 30);
    (0, helpers_1.talkThrough)(c, (0, helpers_1.guardianIt)(c));
    strict_1.default.equal(corePresent(c), 1);
});
(0, node_test_1.test)("save/load mid-encounter round-trips and resumes with no duplicate core", () => {
    const w = (0, helpers_1.newWorld)(21), pl = (0, world_1.player)(w);
    const script = (0, dialogue_2.scriptOf)(w, G);
    (0, dialogue_2.playSegment)(w, pl, G, script.segments[0]);
    (0, dialogue_2.playSegment)(w, pl, G, script.segments[1]);
    (0, dialogue_2.playSegment)(w, pl, G, script.segments[2], 1); // core handed over, then Esc
    const s = JSON.parse(JSON.stringify((0, save_1.serialize)(w)));
    const w2 = (0, save_1.deserialize)(s);
    strict_1.default.deepEqual((0, save_1.serialize)(w2), (0, save_1.serialize)(w));
    strict_1.default.ok((0, dialogue_2.isAwake)(w2, G) && (0, world_1.hasFlag)(w2, flags_1.FLAGS.golemEye));
    strict_1.default.equal((0, dialogue_2.talkTo)(w2, (0, world_1.player)(w2), G)?.id, "farewell");
    (0, helpers_1.talkThrough)(w2, (0, helpers_1.guardianIt)(w2));
    strict_1.default.equal(corePresent(w2), 1);
    strict_1.default.ok(!(0, dialogue_2.isAwake)(w2, G));
});
// ------------------------------------------------------------------ foundation
(0, node_test_1.test)("dormant is reversible: wake it again and a later data-only segment plays", () => {
    const w = (0, helpers_1.newWorld)(31), pl = (0, world_1.player)(w);
    (0, helpers_1.talkThrough)(w, (0, helpers_1.guardianIt)(w));
    strict_1.default.ok(!(0, dialogue_2.isAwake)(w, G));
    const script = dialogue_1.DIALOGUE.guardian;
    const repaired = (0, flags_1.npcFlag)(G, "repaired");
    // a future post-repair chapter, added purely as data
    script.segments.push({
        id: "afterRepair", when: { flags: [repaired] }, done: (0, flags_1.npcFlag)(G, "thanked"),
        pages: [{ beat: "wake", text: "I AM WHOLE AGAIN." }],
    });
    try {
        strict_1.default.equal((0, dialogue_2.talkTo)(w, pl, G), null, "nothing to say yet");
        (0, world_1.setFlag)(w, repaired); // what the repair work will do later
        (0, tasks_1.applyEffect)(w, pl, { op: "npcAwake", npc: G, awake: true });
        strict_1.default.ok((0, dialogue_2.isAwake)(w, G));
        strict_1.default.equal((0, dialogue_2.talkTo)(w, pl, G)?.id, "afterRepair");
        strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "dialogue" && e.segment === "afterRepair"));
        (0, dialogue_2.playSegment)(w, pl, G, script.segments[script.segments.length - 1]);
        strict_1.default.ok((0, world_1.hasFlag)(w, (0, flags_1.npcFlag)(G, "thanked")));
        strict_1.default.equal(corePresent(w), 1);
    }
    finally {
        script.segments.pop();
    }
});
(0, node_test_1.test)("a second NPC is pure data: its own NpcDef row and script, talked to through the generic path", () => {
    actors_1.ACTORS.tester = { ...actors_1.ACTORS.guardian, body: { box: [10, 6], reach: 18, height: 20 } };
    npcs_1.NPCS.tester = { name: "TEST SUBJECT", type: "special", dialogue: "tester", actor: "tester" };
    dialogue_1.DIALOGUE.tester = {
        idle: "IT IGNORES YOU.",
        segments: [
            { id: "hello", done: "npc.tester.hello", pages: [{ beat: "wake", text: "HELLO." }] },
            { id: "bye", when: { flags: ["npc.tester.hello"] }, done: "npc.tester.bye", pages: [{ then: "goDormant", text: "BYE." }] },
        ],
    };
    try {
        const w = (0, helpers_1.newWorld)(41), pl = (0, world_1.player)(w);
        const t = (0, world_1.makeNpc)({ id: "npc.tester", npc: "tester", x: pl.x + 40, y: pl.y }, "dungeon");
        w.actors.push(t);
        const it = (0, helpers_1.find)(w, (i) => i.kind === "npc" && i.actorId === "npc.tester");
        strict_1.default.equal(it.npc, "tester");
        strict_1.default.deepEqual((0, helpers_1.talkThrough)(w, it), ["hello", "bye"]);
        strict_1.default.ok((0, world_1.hasFlag)(w, "npc.tester.hello") && (0, world_1.hasFlag)(w, "npc.tester.bye"));
        strict_1.default.ok(!(0, dialogue_2.isAwake)(w, "npc.tester"));
        (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.actorId === "npc.tester"));
        strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "message" && e.text === "IT IGNORES YOU."));
        strict_1.default.equal(corePresent(w), 0, "the guardian's beats were never involved");
        strict_1.default.ok(!(0, world_1.hasFlag)(w, dialogue_1.GUARDIAN_FLAGS.met));
    }
    finally {
        delete npcs_1.NPCS.tester;
        delete dialogue_1.DIALOGUE.tester;
        delete actors_1.ACTORS.tester;
    }
});
(0, node_test_1.test)("guardian state lives under npc.guardian.*, never golem.*", () => {
    const w = (0, helpers_1.newWorld)(51);
    const before = new Set(w.flags);
    (0, helpers_1.talkThrough)(w, (0, helpers_1.guardianIt)(w));
    const added = [...w.flags].filter((f) => !before.has(f));
    strict_1.default.ok(added.length >= 3);
    for (const f of added)
        strict_1.default.ok(f.startsWith("npc.guardian.") || f === flags_1.FLAGS.golemEye, f);
    strict_1.default.deepEqual(added.filter((f) => f.startsWith("golem.")), [flags_1.FLAGS.golemEye], "only the player's own eye");
    // runtime state is a flag too (awake), and it is reversible
    (0, tasks_1.applyEffect)(w, (0, world_1.player)(w), { op: "npcAwake", npc: G, awake: true });
    strict_1.default.ok(w.flags.has("npc.guardian.awake"));
    (0, tasks_1.applyEffect)(w, (0, world_1.player)(w), { op: "npcAwake", npc: G, awake: false });
    strict_1.default.ok(!w.flags.has("npc.guardian.awake"));
});
