"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Routes, runes and the pack (v17): the surface rune severed while the circle below is broken (lit, carrying
// nobody, waking nothing), a worker's routes over runes and portals alike (the dug-out stair, the old road to
// Westwake, the shops' doors), gather orders that keep what they gather, and the v16 -> v17 migration. The host's
// side (the rune's refusal as it is drawn) is tests/runeHost.test.ts.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const runes_1 = require("../src/game/content/runes");
const geography_1 = require("../src/game/content/geography");
const areas_1 = require("../src/game/world/areas");
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const ritual_1 = require("../src/game/sim/ritual");
const runes_2 = require("../src/game/sim/runes");
const routes_1 = require("../src/game/sim/routes");
const portals_1 = require("../src/game/sim/portals");
const digging_1 = require("../src/game/sim/digging");
const navigation_1 = require("../src/game/sim/navigation");
const jobs_1 = require("../src/game/sim/jobs");
const orders_1 = require("../src/game/sim/orders");
const step_1 = require("../src/game/sim/step");
const inventory_1 = require("../src/game/sim/inventory");
const debugFoundations_1 = require("../src/game/sim/debugFoundations");
const helpers_1 = require("./helpers");
(0, debugFoundations_1.registerFoundations)();
const DT = 0.05, WORKER = "npc.worker.artificery", GATE = "buriedgate@48,61", STAIR = geography_1.ENTRANCES.surface_stair;
const S = runes_1.RUNE_NODES.surface, D = runes_1.RUNE_NODES.dungeon;
/** A world past the first crossing: the circle solved and lit, the surface rune restored, the golem on the surface. */
function crossed() {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), dg = (0, world_1.currentArea)(w), r = dg.ritual;
    r.core = true;
    r.carved = true;
    r.sockets = r.solution.slice();
    (0, ritual_1.checkRune)(w, dg);
    r.actT = 5;
    const c = dg.ritualPos;
    pl.x = c.x;
    pl.y = c.y + 2;
    for (let i = 0; i < 1000 && pl.area !== "surface"; i++)
        (0, helpers_1.frame)(w);
    (0, helpers_1.frames)(w, 5);
    (0, helpers_1.events)(w);
    return { w, pl };
}
/** Down in the halls, take the glyph out of a socket, as the player does: the circle goes dark (sim/ritual.ts: deactivate). */
function breakCircle(w) {
    const pl = (0, world_1.player)(w), c = (0, world_1.getArea)(w, "dungeon").ritualPos;
    (0, world_1.enterArea)(w, pl, "dungeon", c.x, c.y + 70);
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "socket" && i.socket === 0));
}
/** The halls' own worker golem, cored, with a Rune of Swift on it so the long walks stay short. */
function withWorker(w) {
    const wk = (0, world_1.actorById)(w, WORKER);
    wk.powerCore = "ruby_core";
    wk.gear.rune0 = "rune_swift";
    return wk;
}
/** The surface stair dug out, as the last stroke leaves it (sim/digging.ts: applyDig). */
function openStair(w) {
    const surface = (0, world_1.getArea)(w, "surface");
    surface.setPropState(GATE, { open: true, lit: true });
    surface.touch("layout");
    strict_1.default.ok((0, digging_1.openEntrance)(w, (0, world_1.player)(w), "surface_stair"));
}
function until(w, check, limit = 20000) {
    for (let i = 0; i < limit && !check(); i++)
        (0, step_1.stepWorld)(w, DT);
    strict_1.default.ok(check(), JSON.stringify(w.actors.filter((a) => a.job).map((a) => ({ id: a.id, x: a.x, y: a.y, area: a.area, job: a.job }))));
}
/** Step until the worker's order stops running, noting each way it took between areas, in order. */
function follow(w, wk, stop = () => false) {
    const seen = [];
    (0, helpers_1.events)(w);
    until(w, () => {
        for (const e of (0, helpers_1.events)(w)) {
            if (e.t === "portal" && e.actor === wk.id)
                seen.push(`${e.from}>${e.to}`);
            else if (e.t === "travelled" && e.actor === wk.id)
                seen.push(`rune:${e.from}>${e.to}`);
        }
        return stop() || wk.job?.status !== "running";
    });
    return seen;
}
// ------------------------------------------------------------------ the rune
(0, node_test_1.test)("a broken circle below severs the surface rune: it stays lit but carries nobody, wakes nothing, and E gets its refusal", () => {
    const { w, pl } = crossed();
    const surface = (0, world_1.getArea)(w, "surface"), dg = (0, world_1.getArea)(w, "dungeon"), rp = surface.prop(S.prop);
    strict_1.default.equal((0, runes_2.runeState)(w, S), "linked");
    strict_1.default.equal((0, runes_2.runeState)(w, D), "linked");
    breakCircle(w);
    strict_1.default.ok(!dg.ritual.active && !(0, world_1.hasFlag)(w, D.flag) && (0, world_1.hasFlag)(w, S.flag), "the circle is dark; the surface rune keeps its own restoration");
    strict_1.default.equal((0, runes_2.runeState)(w, D), "dormant");
    strict_1.default.equal((0, runes_2.runeState)(w, S), "severed");
    // the awakening runs one way: the circle wakes the surface rune, never the reverse
    strict_1.default.deepEqual((0, runes_1.runeDestinations)("dungeon").map((d) => [d.node.id, d.wakes]), [["surface", true]]);
    strict_1.default.deepEqual((0, runes_1.runeDestinations)("surface").map((d) => [d.node.id, d.wakes]), [["dungeon", false]]);
    strict_1.default.equal((0, runes_2.runeRoute)(w, "surface", "dungeon"), null);
    // the sim refuses the trip itself (a worker's channel, a channel saved mid-way), and sets nothing
    (0, world_1.enterArea)(w, pl, "surface", rp.x, rp.y + 4);
    (0, helpers_1.events)(w);
    strict_1.default.equal((0, runes_2.travel)(w, pl, surface, S.prop), false);
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "message" && e.text === "NOTHING ANSWERS ON THE OTHER SIDE"));
    strict_1.default.ok(pl.area === "surface" && !(0, world_1.hasFlag)(w, D.flag));
    // E on it: no channel and no jump; the refusal's cue at the rune (the host plays the sputter) and its words
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "rune"));
    const ev = (0, helpers_1.events)(w);
    strict_1.default.ok(!ev.some((e) => e.t === "teleport" || e.t === "travelled" || e.t === "runeAwakened"));
    strict_1.default.deepEqual(ev.filter((e) => e.t === "cue"), [{ t: "cue", cue: "runeDud", x: rp.x, y: rp.y, actor: pl.id }]);
    strict_1.default.ok(ev.some((e) => e.t === "message" && e.text === "THE RUNE GUTTERS OUT. NOTHING ANSWERS ON THE OTHER SIDE"));
    strict_1.default.ok(pl.area === "surface" && !(0, world_1.hasFlag)(w, D.flag) && !dg.ritual.active, "still here, and the circle below still dark");
    // the glyph back in its socket: the circle lights, and the surface rune carries again
    (0, world_1.enterArea)(w, pl, "dungeon", dg.ritualPos.x, dg.ritualPos.y + 70);
    (0, ritual_1.placeGlyph)(w, pl, dg, 0, dg.ritual.solution[0]);
    (0, helpers_1.frames)(w, 60);
    strict_1.default.ok(dg.ritual.active && (0, world_1.hasFlag)(w, D.flag));
    strict_1.default.equal((0, runes_2.runeState)(w, S), "linked");
    (0, world_1.enterArea)(w, pl, "surface", rp.x, rp.y + 4);
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "rune"));
    strict_1.default.equal(pl.area, "dungeon", "mended, it carries");
    // a rune that was never lit is dormant, not severed, and says so (the halls' circle before the ritual)
    const fresh = (0, helpers_1.newWorld)();
    strict_1.default.equal((0, runes_2.runeState)(fresh, D), "dormant");
    strict_1.default.equal((0, runes_2.runeState)(fresh, S), "dormant");
    strict_1.default.equal((0, runes_2.runeRoute)(fresh, "dungeon", "surface"), null);
});
(0, node_test_1.test)("v16 -> v17: a circle the surface rune had wrongly woken goes dark again, and an order stopped for want of a route keeps its reason", () => {
    strict_1.default.equal(save_1.SAVE_VERSION, 19);
    const { w } = crossed();
    breakCircle(w);
    const wk = withWorker(w);
    strict_1.default.ok((0, jobs_1.assignJob)(w, wk, (0, jobs_1.walkOrder)("surface", 100, 100)));
    for (let i = 0; i < 5; i++)
        (0, step_1.stepWorld)(w, DT);
    strict_1.default.deepEqual([wk.job.status, wk.job.reason], ["blocked", "noRoute"], "rune dark, stair buried: no way out of the halls");
    strict_1.default.equal((0, orders_1.blockText)("noRoute"), "NO WAY THERE");
    strict_1.default.ok(!("noRuneRoute" in orders_1.BLOCK_TEXT));
    const now = JSON.parse(JSON.stringify((0, save_1.serialize)(w)));
    // that world as v16 saved it once the bug had bitten: the dark circle's flag set by a trip down, the old reason name
    const v16 = { ...now, version: 16, flags: [...now.flags, "rune.dungeon.active"], actors: now.actors.map((a) => (a.id === WORKER ? { ...a, job: { ...a.job, reason: "noRuneRoute" } } : a)) };
    const up = (0, save_1.migrate)(v16);
    strict_1.default.equal(up.version, 19);
    strict_1.default.ok(!up.flags.includes("rune.dungeon.active") && up.flags.includes("rune.surface.active"));
    strict_1.default.deepEqual(up, now, "and nothing else moved");
    const w2 = (0, save_1.deserialize)(v16);
    strict_1.default.equal((0, runes_2.runeState)(w2, S), "severed");
    strict_1.default.equal((0, runes_2.runeState)(w2, D), "dormant");
    // a circle that is lit keeps its flag; a save that never reached the ritual is untouched
    const lit = JSON.parse(JSON.stringify((0, save_1.serialize)(crossed().w)));
    strict_1.default.deepEqual((0, save_1.migrate)({ ...lit, version: 16 }), lit);
    const early = JSON.parse(JSON.stringify((0, save_1.serialize)((0, helpers_1.newWorld)())));
    strict_1.default.deepEqual((0, save_1.migrate)({ ...early, version: 16 }), early);
});
// ------------------------------------------------------------------ routes
(0, node_test_1.test)("a worker takes the dug-out stair when the rune will not carry it, and walks on along the old road into Westwake", () => {
    const { w } = crossed();
    const wk = withWorker(w), means = (0, routes_1.meansOf)(wk);
    breakCircle(w);
    // rune dark, stair buried: nothing leads out of the halls, and nothing beyond them is offered
    strict_1.default.deepEqual((0, routes_1.firstHops)(w, means, "dungeon", "surface"), []);
    strict_1.default.ok(!(0, orders_1.canReach)(w, wk, "surface") && !(0, orders_1.canReach)(w, wk, "town"));
    strict_1.default.ok((0, orders_1.walkOptions)(w, wk).every((o) => o.area === "dungeon"));
    openStair(w);
    strict_1.default.deepEqual((0, routes_1.firstHops)(w, means, "dungeon", "surface"), [{ via: "portal", portal: STAIR.below.portal, area: "surface" }]);
    strict_1.default.deepEqual((0, routes_1.firstHops)(w, means, "surface", "dungeon"), [{ via: "portal", portal: STAIR.above.portal, area: "dungeon" }]);
    strict_1.default.deepEqual((0, routes_1.firstHops)(w, means, "dungeon", "town"), [{ via: "portal", portal: STAIR.below.portal, area: "surface" }]);
    strict_1.default.ok((0, orders_1.canReach)(w, wk, "surface") && (0, orders_1.canReach)(w, wk, "town"));
    // Westwake has never been visited: it is known as the far end of the road out of the surface, and offered by its start
    strict_1.default.ok(!w.areas.has("town"));
    strict_1.default.deepEqual((0, orders_1.knownAreas)(w), ["dungeon", "surface", "town"]);
    const spot = (0, orders_1.walkOptions)(w, wk).find((o) => o.label === "WESTWAKE START");
    strict_1.default.ok(spot && spot.area === "town");
    strict_1.default.ok(!w.areas.has("town"), "listing it instantiates nothing");
    strict_1.default.ok((0, jobs_1.assignJob)(w, wk, (0, jobs_1.walkOrder)(spot.area, spot.x, spot.y)));
    const seen = follow(w, wk);
    strict_1.default.equal(wk.job?.status, "done", JSON.stringify(wk.job));
    strict_1.default.deepEqual(seen, ["stair_up>stair_down", "west_road>east_road"], "up the stair, then west along the road: no rune");
    strict_1.default.equal(wk.area, "town");
    strict_1.default.ok(Math.hypot(wk.x - spot.x, wk.y - spot.y) < 3);
    strict_1.default.ok(w.areas.has("town"), "the town exists once someone has walked in");
    // from there the shops' doors are ways too, and the way home is the same road and stair
    strict_1.default.ok((0, orders_1.knownAreas)(w).includes("town_guild") && (0, orders_1.walkOptions)(w, wk).some((o) => o.label === "GUILD HALL START"));
    strict_1.default.deepEqual((0, routes_1.firstHops)(w, means, "town", "town_smithy"), [{ via: "portal", portal: "door.smithy", area: "town_smithy" }]);
    strict_1.default.deepEqual((0, routes_1.firstHops)(w, means, "town_smithy", "dungeon"), [{ via: "portal", portal: "door", area: "town" }]);
    strict_1.default.deepEqual((0, routes_1.firstHops)(w, means, "town", "dungeon"), [{ via: "portal", portal: "east_road", area: "surface" }]);
    // a body that cannot use runes still walks; one that can only use runes has no way while the circle is dark
    strict_1.default.equal((0, routes_1.firstHops)(w, { runes: false, portals: true }, "town", "dungeon").length, 1);
    strict_1.default.deepEqual((0, routes_1.firstHops)(w, { runes: true, portals: false }, "surface", "dungeon"), []);
});
(0, node_test_1.test)("with the rune and the stair both open it sets out for the nearer way, and keeps to it", () => {
    const { w } = crossed();
    const wk = withWorker(w), dg = (0, world_1.getArea)(w, "dungeon"), s = (0, world_1.getArea)(w, "surface").start;
    openStair(w);
    strict_1.default.deepEqual((0, routes_1.firstHops)(w, (0, routes_1.meansOf)(wk), "dungeon", "surface").map((h) => h.via), ["rune", "portal"]);
    // standing where the hall to the stair opens: the stair
    const foot = dg.base.spots.find((p) => p.id === "stairfoot");
    wk.x = foot.x;
    wk.y = foot.y;
    strict_1.default.ok((0, jobs_1.assignJob)(w, wk, (0, jobs_1.walkOrder)("surface", s.x, s.y)));
    const goals = new Set();
    strict_1.default.deepEqual(follow(w, wk, () => { if (wk.area === "dungeon" && wk.job?.nav)
        goals.add(wk.job.nav.goal); return wk.area === "surface"; }), ["stair_up>stair_down"]);
    strict_1.default.equal(goals.size, 1, "one walk goal all the way: it does not change its mind");
    // standing by the circle: the rune
    const c = dg.ritualPos;
    (0, world_1.enterArea)(w, wk, "dungeon", c.x, c.y + D.arrive.dy);
    strict_1.default.ok((0, jobs_1.assignJob)(w, wk, (0, jobs_1.walkOrder)("surface", s.x, s.y)));
    strict_1.default.deepEqual(follow(w, wk, () => wk.area === "surface"), ["rune:dungeon>surface"]);
});
(0, node_test_1.test)("every road, door and stair can be stood in by a worker's body and walked to from where its area is entered", () => {
    const w = (0, helpers_1.newWorld)(), ids = Object.keys(areas_1.AREAS).filter((id) => !id.startsWith("debug_"));
    (0, world_1.getArea)(w, "surface");
    openStair(w);
    let n = 0;
    for (const id of ids) {
        const area = (0, world_1.getArea)(w, id), a = (0, world_1.makeActor)(`t.${id}`, "worker_golem", id, area.start.x, area.start.y);
        a.powerCore = "ruby_core";
        w.actors.push(a);
        strict_1.default.ok((0, portals_1.portalsOf)(area).length, `${id} has a way out`);
        for (const p of (0, portals_1.portalsOf)(area)) {
            n++;
            strict_1.default.ok((0, portals_1.portalOpen)(w, p), `${id}.${p.id}`);
            const at = (0, portals_1.portalStand)(p, (0, navigation_1.navGrid)(area, a).free);
            strict_1.default.ok(at && (0, portals_1.inPortal)(p, at.x, at.y), `${id}.${p.id}: a place to stand inside its box`);
            strict_1.default.ok((0, navigation_1.findPath)(w, a, { x: at.x, y: at.y, range: 1 }, false), `${id}.${p.id}: walkable from the area's start`);
            strict_1.default.ok((0, portals_1.portalsOf)((0, world_1.getArea)(w, p.to.area)).some((q) => q.id === p.to.portal), `${id}.${p.id}: its far side exists`);
        }
    }
    strict_1.default.equal(n, 16, "the stair's two ends, the road's two ends, six shop doors and the six ways back out");
    // a box that is blocked whole has nowhere to stand
    strict_1.default.equal((0, portals_1.portalStand)((0, portals_1.portalsOf)((0, world_1.getArea)(w, "surface"))[0], () => false), null);
});
// ------------------------------------------------------------------ gathering to the pack
(0, node_test_1.test)("a gather order to INVENTORY: the worker keeps what it gathers, the amount counts what it gathered, and a save mid-way carries on", () => {
    const order = (0, jobs_1.gatherOrder)("wood", "debug_yard", null, 5);
    strict_1.default.ok(jobs_1.JOB_HANDLERS.gatherDeposit.validate(order.args));
    strict_1.default.equal(jobs_1.JOB_HANDLERS.gatherDeposit.validate({ resource: "wood", fromArea: "debug_yard", amount: 5 }), false, "no storage named at all is not an order");
    const w = (0, debugFoundations_1.foundationDemo)(), a = (0, world_1.actorById)(w, "debug.worker");
    const chestEmpty = (x) => (0, world_1.getArea)(x, "debug_workshop").prop("chest.fixture").inventory.every((s) => !s);
    strict_1.default.equal((0, jobs_1.orderRefusal)(w, (0, world_1.player)(w), a.id, order), null);
    strict_1.default.ok((0, jobs_1.assignJob)(w, a, order));
    strict_1.default.equal(a.job.args.storage, null);
    strict_1.default.deepEqual((0, orders_1.jobView)(w, a).lines, ["FROM DEBUG YARD", "TO INVENTORY"]);
    until(w, () => a.task?.kind === "punch" && !!a.task.fired && (0, inventory_1.countItem)(a, "wood") > 0);
    const loaded = (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w)))), b = (0, world_1.actorById)(loaded, "debug.worker");
    strict_1.default.deepEqual((0, save_1.serialize)(loaded), (0, save_1.serialize)(w));
    strict_1.default.equal(b.job.completed, (0, inventory_1.countItem)(b, "wood"), "counted where the blow paid, before the swing has ended");
    for (const [x, y] of [[w, a], [loaded, b]]) {
        until(x, () => y.job?.status !== "running");
        strict_1.default.equal(y.job?.status, "done");
        strict_1.default.equal(y.job.completed, 5);
        strict_1.default.equal((0, orders_1.jobView)(x, y).progress, "5/5");
        strict_1.default.equal((0, orders_1.jobView)(x, y).phase, "FINISHED");
        strict_1.default.ok((0, inventory_1.countItem)(y, "wood") >= 5, "what a last blow paid over the amount is kept too");
        strict_1.default.equal(y.area, "debug_yard", "it stays where the work was");
        strict_1.default.ok(chestEmpty(x), "and stores nothing");
    }
    strict_1.default.deepEqual((0, save_1.serialize)(loaded), (0, save_1.serialize)(w));
    // a full pack stops it (PACK FULL) until room is made, as for any gather; on repeat it goes on while there is room
    const f = (0, debugFoundations_1.foundationDemo)(), c = (0, world_1.actorById)(f, "debug.worker");
    (0, inventory_1.addItems)(f, c, "coin", 8);
    strict_1.default.ok((0, jobs_1.assignJob)(f, c, (0, jobs_1.gatherOrder)("wood", "debug_yard", null, 1, true)));
    until(f, () => c.job?.status === "blocked");
    strict_1.default.equal(c.job.reason, "packFull");
    strict_1.default.equal(c.area, "debug_yard");
    strict_1.default.equal((0, inventory_1.countItem)(c, "wood"), 0);
    c.inventory[0] = null;
    (0, jobs_1.resumeJob)(f, c);
    until(f, () => (0, inventory_1.countItem)(c, "wood") >= 3);
    strict_1.default.equal(c.job.completed, (0, inventory_1.countItem)(c, "wood"));
    strict_1.default.equal((0, orders_1.jobView)(f, c).progress, `${c.job.completed} DONE (REPEAT)`);
    // the order screen's TO list: every chest it can get to, then INVENTORY, which is always there
    const g = (0, debugFoundations_1.foundationDemo)(), d = (0, world_1.actorById)(g, "debug.worker");
    strict_1.default.deepEqual((0, orders_1.gatherTargets)(g, d).map((t) => t.label), ["DEBUG WORKSHOP CHEST", orders_1.INVENTORY_LABEL]);
    (0, world_1.getArea)(g, "debug_workshop").removeProp("chest.fixture");
    strict_1.default.deepEqual((0, orders_1.gatherTargets)(g, d), [{ label: "INVENTORY", ref: null }]);
    strict_1.default.equal((0, orders_1.gatherRefusal)(g, d, "wood", "debug_yard", null), null);
    strict_1.default.equal((0, jobs_1.orderRefusal)(g, (0, world_1.player)(g), d.id, (0, jobs_1.gatherOrder)("wood", "debug_yard", { area: "nowhere", prop: "x" }, 3)), "NO SUCH STORAGE");
});
