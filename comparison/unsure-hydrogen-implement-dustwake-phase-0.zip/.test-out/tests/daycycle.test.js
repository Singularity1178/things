"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The day/night cycle and the two cutscenes that can be skipped.
//
// Sim side (no DOM): the cycle's maths (content/daycycle.ts), the calendar
// clock (sim/daytime.ts), who tends which light, the first crossing setting the
// hour, the save format (v13) and the golem's line at its first dusk.
// Host side (the real Game on the fake canvas, driven by key presses): the
// opening skipped with Esc, the first jump played right through the crossing,
// the crossing skipped at every stage (and the world left the same as when it
// is watched), R at the chapter card, and the town's lamps following the hour.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const g0 = globalThis;
g0.localStorage ?? (g0.localStorage = { getItem: () => null, setItem: () => { }, removeItem: () => { } });
const game_1 = require("../src/game/game");
const daycycle_1 = require("../src/game/content/daycycle");
const daytime_1 = require("../src/game/sim/daytime");
const step_1 = require("../src/game/sim/step");
const runes_1 = require("../src/game/sim/runes");
const tasks_1 = require("../src/game/sim/tasks");
const interactions_1 = require("../src/game/content/interactions");
const runes_2 = require("../src/game/content/runes");
const flags_1 = require("../src/game/content/flags");
const monologue_1 = require("../src/game/content/monologue");
const cutscenes_1 = require("../src/game/content/cutscenes");
const crossing_1 = require("../src/game/screens/crossing");
const cutscene_1 = require("../src/game/ui/cutscene");
const props_1 = require("../src/game/content/props");
const areas_1 = require("../src/game/world/areas");
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const helpers_1 = require("./helpers");
const near = (a, b, eps = 1e-6) => Math.abs(a - b) <= eps;
const NIGHT = [0.32, 0.31, 0.42];
// ------------------------------------------------------------------ the cycle's maths
(0, node_test_1.test)("the day has four parts, and the sun eases up through dawn and down through dusk", () => {
    strict_1.default.equal((0, daycycle_1.phaseAt)(0), "night");
    strict_1.default.equal((0, daycycle_1.phaseAt)(4.99), "night");
    strict_1.default.equal((0, daycycle_1.phaseAt)(daycycle_1.DAY_HOURS.dawn), "dawn");
    strict_1.default.equal((0, daycycle_1.phaseAt)(6.99), "dawn");
    strict_1.default.equal((0, daycycle_1.phaseAt)(daycycle_1.DAY_HOURS.sunrise), "day");
    strict_1.default.equal((0, daycycle_1.phaseAt)(12), "day");
    strict_1.default.equal((0, daycycle_1.phaseAt)(daycycle_1.DAY_HOURS.dusk), "dusk");
    strict_1.default.equal((0, daycycle_1.phaseAt)(daycycle_1.DAY_HOURS.nightfall), "night");
    strict_1.default.equal((0, daycycle_1.phaseAt)(24 + 12), "day", "hours wrap");
    strict_1.default.equal((0, daycycle_1.sunLevel)(0), 0);
    strict_1.default.equal((0, daycycle_1.sunLevel)(12), 1);
    strict_1.default.equal((0, daycycle_1.sunLevel)(23), 0);
    for (let h = 5; h < 7; h += 0.05)
        strict_1.default.ok((0, daycycle_1.sunLevel)(h + 0.05) >= (0, daycycle_1.sunLevel)(h), "dawn only brightens");
    for (let h = 19; h < 21; h += 0.05)
        strict_1.default.ok((0, daycycle_1.sunLevel)(h + 0.05) <= (0, daycycle_1.sunLevel)(h), "dusk only darkens");
    strict_1.default.ok(near((0, daycycle_1.sunLevel)(6), 0.5), "half up at the middle of dawn");
    strict_1.default.equal((0, daycycle_1.hourOf)(0.5), 12);
    strict_1.default.ok(near((0, daycycle_1.hourOf)(3.25), 6));
    strict_1.default.equal((0, daycycle_1.clockText)(6.69), "06:40");
    strict_1.default.equal((0, daycycle_1.clockText)(23.99), "23:50");
});
(0, node_test_1.test)("ambient light: an area's own ambient is its night; the sun adds the day; buried areas never change", () => {
    strict_1.default.deepEqual((0, daycycle_1.ambientAt)(NIGHT, 0, "outdoor"), NIGHT, "night is the authored look, untouched");
    strict_1.default.deepEqual((0, daycycle_1.ambientAt)(NIGHT, 12, "outdoor"), [...daycycle_1.SKY.day]);
    const dawn = (0, daycycle_1.ambientAt)(NIGHT, 6, "outdoor"), dusk = (0, daycycle_1.ambientAt)(NIGHT, 20, "outdoor");
    strict_1.default.ok(dawn[0] > dawn[2] && dusk[0] > dusk[2], "the twilights are warm");
    strict_1.default.ok(dawn[0] > NIGHT[0] && dawn[0] < 1);
    const dark = [0.05, 0.045, 0.065];
    for (const h of [0, 6, 12, 20]) {
        strict_1.default.equal((0, daycycle_1.ambientAt)(dark, h, "buried"), dark);
        strict_1.default.equal((0, daycycle_1.lampGain)(h, "buried"), 1);
    }
    const room = [0.3, 0.25, 0.22], noon = (0, daycycle_1.ambientAt)(room, 12, "interior");
    strict_1.default.ok(noon[0] > room[0] && noon[0] < daycycle_1.SKY.day[0], "a room is lit by day, but less than the street");
    strict_1.default.equal((0, daycycle_1.lampGain)(0, "outdoor"), 1);
    strict_1.default.ok(near((0, daycycle_1.lampGain)(12, "outdoor"), daycycle_1.SKY.lampInSun), "a lamp at noon counts for little");
    strict_1.default.ok((0, daycycle_1.lampGain)(12, "interior") > (0, daycycle_1.lampGain)(12, "outdoor"));
    const moon = [0.55, 0.68, 1];
    strict_1.default.deepEqual((0, daycycle_1.skyLight)(moon, 0).col, moon, "sky light keeps its authored colour by night");
    const beam = (0, daycycle_1.skyLight)(moon, 12);
    strict_1.default.ok(beam.col[0] > beam.col[2] && beam.gain > 1, "and is a sunbeam by day");
});
// ------------------------------------------------------------------ the clock
(0, node_test_1.test)("the calendar clock runs with world time, forward only, and says so once when the day turns", () => {
    const w = (0, helpers_1.newWorld)();
    strict_1.default.ok(near((0, daytime_1.worldHour)(w), daycycle_1.START_HOUR), "the golem wakes in the night");
    strict_1.default.equal((0, daytime_1.worldPhase)(w), "night");
    (0, step_1.stepWorld)(w, daycycle_1.DAY_SECONDS / 24);
    strict_1.default.ok(near((0, daytime_1.worldHour)(w), daycycle_1.START_HOUR + 1, 1e-6), "an hour of the day is DAY_SECONDS / 24 of world time");
    (0, daytime_1.advanceDayTo)(w, 4.9);
    const day = w.day;
    w.events = [];
    for (let i = 0; i < 60; i++)
        (0, step_1.stepWorld)(w, 0.2); // 12 s: 0.4 h, across 05:00
    const turns = w.events.filter((e) => e.t === "dayPhase");
    strict_1.default.deepEqual(turns.map((e) => e.t === "dayPhase" && e.phase), ["dawn"], "one event at the boundary");
    strict_1.default.ok(w.day > day);
    // advanceDayTo: the next time it is that hour (tomorrow if it has passed)
    const before = w.day;
    (0, daytime_1.advanceDayTo)(w, 4);
    strict_1.default.ok(near((0, daytime_1.worldHour)(w), 4) && w.day > before && w.day - before > 0.9, "04:00 has passed today: tomorrow's");
    // advanceDayUpTo: only if still ahead today; never back, never round the clock
    const d0 = w.day;
    (0, daytime_1.advanceDayUpTo)(w, 3);
    strict_1.default.equal(w.day, d0, "an hour behind is left alone");
    (0, daytime_1.advanceDayUpTo)(w, 6.6);
    strict_1.default.ok(near((0, daytime_1.worldHour)(w), 6.6));
    const d1 = w.day;
    (0, daytime_1.advanceDayUpTo)(w, 6.6);
    (0, daytime_1.advanceDayUpTo)(w, 6.5);
    strict_1.default.equal(w.day, d1, "safe to call again");
});
(0, node_test_1.test)("the first crossing lands in the last dark before dawn; later hops take no time", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    for (let i = 0; i < 40; i++)
        (0, step_1.stepWorld)(w, 5); // some time in the halls: the hour could be anything
    (0, world_1.setFlag)(w, runes_2.RUNE_NODES.dungeon.flag);
    const before = w.day;
    strict_1.default.ok((0, runes_1.travel)(w, pl, (0, world_1.currentArea)(w), "rune.dungeon"));
    strict_1.default.equal(pl.area, "surface");
    strict_1.default.ok((0, world_1.hasFlag)(w, flags_1.FLAGS.tutorialDone));
    strict_1.default.ok(near((0, daytime_1.worldHour)(w), daycycle_1.FIRST_ARRIVAL_HOUR) && w.day > before, "forward to 04:00");
    strict_1.default.equal((0, daytime_1.worldPhase)(w), "night");
    const d = w.day;
    strict_1.default.ok((0, runes_1.travel)(w, pl, (0, world_1.currentArea)(w), "rune.surface"));
    strict_1.default.equal(pl.area, "dungeon");
    strict_1.default.equal(w.day, d, "a hop back takes no time");
});
// ------------------------------------------------------------------ who tends which light
const town = () => areas_1.AREAS.town();
const tended = (habit) => town().props.filter((p) => (0, props_1.propDef)(p.kind).habit === habit).map((p) => p.id);
(0, node_test_1.test)("only the town is tended, and its lights have their habits (the charter stone's rune never sleeps)", () => {
    strict_1.default.equal(town().tended, true);
    strict_1.default.ok(!areas_1.AREAS.surface().tended && !areas_1.AREAS.dungeon().tended, "the wild and the halls keep no hours");
    strict_1.default.ok(!areas_1.AREAS.town_tavern().tended, "a room keeps its own lamps lit");
    strict_1.default.equal((0, props_1.propDef)("rune_lamp").habit, "rune");
    strict_1.default.equal((0, props_1.propDef)("rune_sconce").habit, "rune");
    for (const k of ["lantern", "torch", "torch_post", "brazier"])
        strict_1.default.equal((0, props_1.propDef)(k).habit, "fire", k);
    for (const k of ["winglow", "winglow_rune", "winglow_up"])
        strict_1.default.equal((0, props_1.propDef)(k).habit, "window", k);
    strict_1.default.equal((0, props_1.propDef)("marketcross").habit, undefined, "THE LIGHT RUNE AT ITS HEAD HAS NEVER GONE OUT");
    strict_1.default.ok((0, props_1.propDef)("marketcross").light);
    strict_1.default.ok(tended("rune").length > 20 && tended("fire").length > 15 && tended("window").length > 40);
});
(0, node_test_1.test)("the town puts its lights out in the morning and lights them at dusk, each kind in its own way", () => {
    const runes = tended("rune"), fires = tended("fire"), wins = tended("window");
    const lit = (ids, habit, h) => ids.filter((id) => (0, daycycle_1.litLevel)(habit, id, h) > 0.5).length;
    // broad day: everything tended is out
    for (const h of [8, 12, 16, 18.5]) {
        strict_1.default.equal(lit(runes, "rune", h), 0, `runes asleep at ${h}`);
        strict_1.default.equal(lit(fires, "fire", h), 0, `fires out at ${h}`);
        strict_1.default.equal(lit(wins, "window", h), 0, `windows dark at ${h}`);
    }
    // deep night: every street light burns, every house is asleep
    for (const h of [23, 1, 3]) {
        strict_1.default.equal(lit(runes, "rune", h), runes.length);
        strict_1.default.equal(lit(fires, "fire", h), fires.length);
    }
    strict_1.default.equal(lit(wins, "window", 3), 0, "the whole town is in bed at three");
    strict_1.default.ok(lit(wins, "window", 21.5) > wins.length * 0.8, "and nearly all of it is up at half past nine");
    const early = lit(wins, "window", 5.9);
    strict_1.default.ok(early > 0 && early < wins.length * 0.6, "a few are up before dawn");
    // runes answer the dark together (a ripple); fires wait for a hand (spread over an hour or more)
    const firstOn = (habit, id) => { for (let h = 19; h < 21.5; h += 0.01)
        if ((0, daycycle_1.litLevel)(habit, id, h) > 0.5)
            return h; return NaN; };
    const spread = (xs) => Math.max(...xs) - Math.min(...xs);
    const runeOn = runes.map((id) => firstOn("rune", id)), fireOn = fires.map((id) => firstOn("fire", id));
    strict_1.default.ok(runeOn.every((h) => h > 19 && h < 20.6) && spread(runeOn) < 0.4, `runes wake within minutes of each other (${spread(runeOn).toFixed(2)} h)`);
    strict_1.default.ok(spread(fireOn) > 0.6 && fireOn.every((h) => h >= 19.5), `fires are lit one by one (${spread(fireOn).toFixed(2)} h)`);
    // morning: all of it out by a little after sunrise, and not all at once
    strict_1.default.equal(lit(runes, "rune", 6.6) + lit(fires, "fire", 7.3) + lit(wins, "window", 7.3), 0);
    strict_1.default.ok(lit(fires, "fire", 6.5) > 0 && lit(fires, "fire", 6.5) < fires.length, "some fires doused, some still burning at half past six");
    // the same lamp keeps the same hours
    strict_1.default.equal((0, daycycle_1.litLevel)("fire", fires[0], 20.1), (0, daycycle_1.litLevel)("fire", fires[0], 20.1 + 24));
});
// ------------------------------------------------------------------ saving
(0, node_test_1.test)("save v13: the clock is saved; an older save resumes at night in the halls, at its first morning on the surface", () => {
    strict_1.default.equal(save_1.SAVE_VERSION, 19);
    const w = (0, helpers_1.newWorld)();
    (0, daytime_1.advanceDayTo)(w, 15.25);
    const s = (0, save_1.serialize)(w);
    strict_1.default.equal(s.day, w.day);
    strict_1.default.equal((0, save_1.deserialize)(JSON.parse(JSON.stringify(s))).day, w.day);
    const old = (surface) => {
        const o = (0, save_1.serialize)((0, helpers_1.newWorld)());
        o.version = 12;
        delete o.day;
        if (surface)
            o.flags.push(flags_1.FLAGS.tutorialDone);
        return o;
    };
    const halls = (0, save_1.migrate)(old(false)), up = (0, save_1.migrate)(old(true));
    strict_1.default.equal(halls.version, 19);
    strict_1.default.ok(near((0, daycycle_1.hourOf)(halls.day), daycycle_1.START_HOUR));
    strict_1.default.ok(near((0, daycycle_1.hourOf)(up.day), daycycle_1.FIRST_MORNING_HOUR));
    const loaded = (0, save_1.deserialize)(old(true));
    for (let i = 0; i < 30; i++)
        (0, step_1.stepWorld)(loaded, 1 / 60);
    strict_1.default.ok(loaded.day > up.day, "and the clock runs on");
});
// ------------------------------------------------------------------ the golem's line at dusk
(0, node_test_1.test)("the golem remarks on its first dusk under the open sky, once, and not from the halls", () => {
    const dusk = (w) => { (0, daytime_1.advanceDayTo)(w, 18.95); (0, step_1.stepWorld)(w, 3); return w.monologue.said.includes("sky.dusk"); };
    const under = (0, helpers_1.newWorld)();
    strict_1.default.equal(dusk(under), false, "nothing to see from the halls");
    const w = (0, helpers_1.newWorld)(), s = (0, world_1.getArea)(w, "surface").start;
    (0, world_1.enterArea)(w, (0, world_1.player)(w), "surface", s.x, s.y);
    strict_1.default.equal(dusk(w), true);
    strict_1.default.equal(dusk(w), true);
    strict_1.default.equal(w.monologue.said.filter((id) => id === "sky.dusk").length, 1, "once");
});
// ------------------------------------------------------------------ the crossing's script
(0, node_test_1.test)("the crossing script: ordered beats, one hand-over, known cues and lines, and the act marks the screen needs", () => {
    const tl = (0, cutscene_1.timeline)(cutscenes_1.CROSSING), at = (label) => tl.find((b) => b.label === label).at;
    for (let i = 1; i < tl.length; i++)
        strict_1.default.ok(tl[i].at > tl[i - 1].at, "beats strictly ordered");
    strict_1.default.equal(tl.filter((b) => b.control).length, 1);
    strict_1.default.ok(tl[tl.length - 1].control, "control is the last beat");
    for (const b of tl) {
        for (const c of b.cues ?? [])
            strict_1.default.ok(crossing_1.CROSSING_CUES[c], `unknown cue ${c}`);
        if (b.think)
            strict_1.default.ok(monologue_1.THOUGHTS[b.think], `unknown line ${b.think}`);
    }
    strict_1.default.deepEqual(tl.filter((b) => b.think).map((b) => b.think), ["cross.transit", "cross.anchor", "cross.rewrite", "cross.arrived", "cross.observed", "cross.light"]);
    strict_1.default.ok(at("stall") < at("rewrite") && at("rewrite") < at("surface"), "the transit: climb, stall, rewrite, then the world");
    strict_1.default.ok(near(at("landed"), at("surface") + cutscenes_1.ARRIVE.FLASH + cutscenes_1.ARRIVE.FALL), "the land cue is the moment the fall ends");
    strict_1.default.ok(at("arrived") > at("landed") && at("first light") > at("observed"));
    strict_1.default.ok(at("chapter") > at("first light") + cutscenes_1.CROSSING.lapse - 1, "the chapter card comes as the morning does");
    strict_1.default.ok((0, cutscene_1.controlAt)(cutscenes_1.CROSSING) - at("chapter") >= 8, "left alone, the card holds a good while before handing over");
    strict_1.default.ok(at("chapter") < 32, "not slow");
});
// ------------------------------------------------------------------ through the host
const canvas = () => globalThis.document.createElement("canvas");
const DT = 1 / 60;
const tick = (g, n = 1) => { for (let i = 0; i < n; i++)
    g.update(DT); };
const press = (g, key) => { g.keyDown(key); g.update(DT); g.keyUp(key); };
const CROSS_LINES = ["cross.engage", "cross.transit", "cross.anchor", "cross.rewrite", "cross.arrived", "cross.observed", "cross.light"];
(0, node_test_1.test)("the opening can be skipped with Esc: control at once, the golem up and lit, its lines thought but not shown", () => {
    const g = new game_1.Game(canvas(), canvas());
    press(g, "x");
    strict_1.default.ok(g.screens.is("intro"));
    g.keyDown("d");
    tick(g, 90); // other keys do nothing, held or pressed
    strict_1.default.ok(g.screens.is("intro"));
    press(g, "Escape");
    strict_1.default.ok(g.screens.is("play"), "skipped");
    strict_1.default.deepEqual(g.world.monologue.said, (0, cutscene_1.timeline)(cutscenes_1.INTRO).filter((b) => b.think).map((b) => b.think), "every line is on record, in order");
    strict_1.default.equal(g.monologue.lines.length, 0, "none of them on screen");
    strict_1.default.equal(g.monologue.pinned, false);
    strict_1.default.deepEqual([g.look.core, g.look.eye, g.look.dormant], [1, 1, 0]);
    strict_1.default.equal(g.bars.to, 0, "the letterbox opens");
    const x0 = g.pl.x;
    tick(g, 30);
    g.keyUp("d");
    strict_1.default.ok(g.pl.x > x0, "and the golem walks");
    // Esc in the first instant (the title's own key press) does not skip
    const h = new game_1.Game(canvas(), canvas());
    h.keyDown("Escape");
    h.update(DT);
    h.update(DT);
    h.keyUp("Escape");
    strict_1.default.ok(h.screens.is("intro"), "Esc on the title starts the opening, it does not skip it");
});
/** What stepPlayer does when the golem stands on the freshly charged circle (sim/step.ts), without solving the ritual first. */
function beginFirstJump(w) {
    const pl = (0, world_1.player)(w), c = (0, world_1.currentArea)(w).ritualPos;
    (0, world_1.setFlag)(w, runes_2.RUNE_NODES.dungeon.flag);
    pl.x = c.x;
    pl.y = c.y + 4;
    pl.facing = "down";
    (0, tasks_1.beginTask)(pl, interactions_1.RULES.rune[interactions_1.RULES.rune.length - 1].task, { kind: "rune", x: c.x, y: c.y, propId: "rune.dungeon" });
    (0, world_1.emit)(w, { t: "teleport", actor: pl.id, first: true, x: c.x, y: c.y });
}
function jumping() {
    const g = new game_1.Game(canvas(), canvas()), w = (0, helpers_1.newWorld)();
    g.resume(w);
    beginFirstJump(w);
    tick(g);
    strict_1.default.ok(g.screens.is("tele"), "the lift-off");
    strict_1.default.equal(g.bars.to, 1, "bars in: the crossing has begun");
    return { g, w };
}
/** The state a finished crossing must leave, however it ended. */
function assertArrived(g, w, shown) {
    const pl = (0, world_1.player)(w);
    strict_1.default.ok(g.screens.is("play"));
    strict_1.default.equal(pl.area, "surface");
    strict_1.default.deepEqual(w.monologue.said, CROSS_LINES, "every line of the crossing is on record, in order");
    strict_1.default.ok(Math.abs((0, daytime_1.worldHour)(w) - daycycle_1.FIRST_MORNING_HOUR) < 0.4 && (0, daytime_1.worldPhase)(w) === "dawn", `the first morning (${(0, daytime_1.worldHour)(w).toFixed(2)})`);
    strict_1.default.equal(g.runeAnim, null);
    strict_1.default.equal(g.hideGolem, false);
    strict_1.default.equal(g.gaze, null);
    strict_1.default.equal(g.look.z, 0);
    strict_1.default.equal(g.bars.to, 0);
    strict_1.default.equal(g.monologue.pinned, false);
    strict_1.default.equal(g.note?.text, "THE SURFACE. THE WILD HAS SWALLOWED ALL TRACE OF THE HALLS.");
    strict_1.default.ok((0, world_1.hasFlag)(w, runes_2.RUNE_NODES.surface.flag), "the far rune is restored");
    if (!shown)
        strict_1.default.equal(g.monologue.lines.length, 0, "skipped lines are not shown");
    const x0 = pl.x;
    g.keyDown("d");
    tick(g, 40);
    g.keyUp("d");
    strict_1.default.ok(pl.x > x0, "control");
    g.render();
}
(0, node_test_1.test)("the first jump plays the crossing through: transit, arrival, first light, the chapter card, then control", () => {
    const { g, w } = jumping(), pl = (0, world_1.player)(w), ui = g.crossingUi;
    g.keyDown("d"); // held throughout: it must do nothing until control
    let frames = 0;
    while (!g.screens.is("crossing") && frames++ < 600)
        tick(g);
    strict_1.default.ok(g.screens.is("crossing"), "the lift-off runs on into the crossing");
    strict_1.default.equal(pl.area, "surface");
    strict_1.default.equal((0, daytime_1.worldPhase)(w), "night", "it comes up in the dark");
    const x0 = pl.x, acts = new Set();
    let sawHidden = false, sawGaze = false, hourAtLight = -1;
    const until = ui.at.chapter + ui.script.promptAfter + 0.2;
    while (ui.screen.t < until) {
        tick(g);
        strict_1.default.ok(g.screens.is("crossing"), `still the cutscene at ${ui.screen.t.toFixed(2)}`);
        strict_1.default.equal(pl.x, x0, "no control during the crossing");
        acts.add(ui.actAt(ui.screen.t));
        if (g.hideGolem)
            sawHidden = true;
        if (g.gaze)
            sawGaze = true;
        if (hourAtLight < 0 && ui.screen.t >= ui.at["first light"])
            hourAtLight = (0, daytime_1.worldHour)(w);
        if (Math.abs(ui.screen.t - 3) < DT || Math.abs(ui.screen.t - 12) < DT || Math.abs(ui.screen.t - until) < DT)
            g.render(); // each act draws
    }
    strict_1.default.deepEqual([...acts], ["transit", "arrival", "firstLight"]);
    strict_1.default.ok(sawHidden && sawGaze, "the golem is summoned (unseen until the flash), then looks about");
    strict_1.default.ok(hourAtLight < daycycle_1.DAY_HOURS.dawn, `still night as the rune wakes (${hourAtLight.toFixed(2)})`);
    strict_1.default.ok((0, daytime_1.worldHour)(w) >= daycycle_1.FIRST_MORNING_HOUR - 0.01, "the clock has run on to morning while it watched");
    g.keyUp("d");
    press(g, "e"); // any key at the chapter card
    assertArrived(g, w, true);
});
(0, node_test_1.test)("the crossing can be skipped with Esc at any stage, and leaves the world as the watched one does", () => {
    // at the lift-off, before the sim has even travelled
    {
        const { g, w } = jumping();
        tick(g, 30);
        strict_1.default.equal((0, world_1.player)(w).area, "dungeon");
        press(g, "Escape");
        assertArrived(g, w, false);
    }
    // in the transit, during the arrival, and at first light
    for (const at of [2.5, 11, 24]) {
        const { g, w } = jumping(), ui = g.crossingUi;
        let frames = 0;
        while (!g.screens.is("crossing") && frames++ < 600)
            tick(g);
        while (ui.screen.t < at)
            tick(g);
        press(g, "Escape");
        assertArrived(g, w, false);
    }
});
(0, node_test_1.test)("left alone the chapter card hands over by itself; R on it wakes the golem again", () => {
    const run = () => {
        const { g, w } = jumping(), ui = g.crossingUi;
        let frames = 0;
        while (!g.screens.is("crossing") && frames++ < 600)
            tick(g);
        while (ui.screen.t < ui.at.chapter + ui.script.promptAfter + 0.1)
            tick(g);
        return { g, w, ui };
    };
    const a = run();
    while (a.g.screens.is("crossing") && a.ui.screen.t < (0, cutscene_1.controlAt)(cutscenes_1.CROSSING) + 1)
        tick(a.g);
    assertArrived(a.g, a.w, true);
    const b = run();
    press(b.g, "r");
    strict_1.default.ok(b.g.screens.is("intro"), "the opening again");
    strict_1.default.notEqual(b.g.world, b.w, "in a fresh world");
    strict_1.default.equal(b.g.pl.area, "dungeon");
    strict_1.default.ok(near((0, daytime_1.worldHour)(b.g.world), daycycle_1.START_HOUR, 0.01));
    strict_1.default.equal(b.g.gaze, null);
    strict_1.default.equal(b.g.runeAnim, null);
});
(0, node_test_1.test)("host: the town's lamps follow the hour, the charter stone never sleeps, and the roof crack lets in the day", () => {
    const g = new game_1.Game(canvas(), canvas()), w = (0, helpers_1.newWorld)(), s = (0, world_1.getArea)(w, "town").start;
    (0, world_1.enterArea)(w, (0, world_1.player)(w), "town", s.x, s.y);
    g.resume(w);
    const lamps = () => [...g.view.lights.values()].filter((L) => L.habit);
    const lit = (habit) => lamps().filter((L) => L.habit === habit && (L.day ?? 1) > 0.5).length;
    const count = (habit) => lamps().filter((L) => L.habit === habit).length;
    strict_1.default.ok(count("rune") > 20 && count("fire") > 15 && count("window") > 20, "the town's lights carry their habits");
    (0, daytime_1.advanceDayTo)(w, 1);
    tick(g, 2);
    strict_1.default.equal(lit("rune"), count("rune"));
    strict_1.default.equal(lit("fire"), count("fire"));
    g.render();
    (0, daytime_1.advanceDayTo)(w, 12);
    tick(g, 2);
    strict_1.default.equal(lit("rune") + lit("fire") + lit("window"), 0, "noon: every tended light is out");
    const cross = [...g.view.lights.values()].filter((L) => !L.habit && !L.sky && L.on && L.cur > 0.5 && (L.day ?? 1) === 1);
    strict_1.default.ok(cross.length >= 1, "but the charter stone's rune is still alight");
    g.render();
    (0, daytime_1.advanceDayTo)(w, 20.9);
    tick(g, 2);
    strict_1.default.equal(lit("rune"), count("rune"), "dusk: the runes are awake again");
    // the halls: the same shaft through the broken roof, moonlight then sunlight; the dark itself does not change
    const h = new game_1.Game(canvas(), canvas()), hw = (0, helpers_1.newWorld)();
    h.resume(hw);
    tick(h, 2);
    const moon = h.view.byId("moon");
    strict_1.default.ok(moon.b > moon.r, "moonlight");
    (0, daytime_1.advanceDayTo)(hw, 12);
    tick(h, 2);
    strict_1.default.ok(moon.r > moon.b && (moon.day ?? 1) > 1, "a sunbeam");
    strict_1.default.equal([...h.view.lights.values()].filter((L) => L.habit).length, 0, "nobody tends the halls: their torches keep no hours");
    h.render();
});
