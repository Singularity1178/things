"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EdgeInputLatch = exports.InputRecorder = exports.SimClock = exports.SPEED_PRESETS = exports.SIM_DT = exports.SIM_HZ = void 0;
exports.runDeterministicReplay = runDeterministicReplay;
exports.SIM_HZ = 60;
exports.SIM_DT = 1 / exports.SIM_HZ;
exports.SPEED_PRESETS = [0, 1, 2, 4, 8];
/** Maximum fixed ticks executed in a single host frame (prevents spiral of death). */
const MAX_TICKS_PER_FRAME = 32;
const TELEPORT_SNAP_DIST = 40;
/**
 * Fixed-timestep accumulator and render-interpolation tracker.
 * Decouples simulation step cadence from browser frame rate while supporting
 * pause / 1x / 2x / 4x / 8x speeds and deterministic replays.
 */
class SimClock {
    constructor() {
        Object.defineProperty(this, "accumulator", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "speed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        Object.defineProperty(this, "tickCount", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "alpha", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        Object.defineProperty(this, "prev", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        Object.defineProperty(this, "curr", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
    }
    reset(w) {
        this.accumulator = 0;
        this.tickCount = 0;
        this.alpha = 1;
        this.prev.clear();
        this.curr.clear();
        if (w)
            this.capture(w, true);
    }
    setSpeed(s) {
        this.speed = s;
        if (s === 0)
            this.accumulator = 0;
    }
    cycleSpeed(dir = 1) {
        const idx = exports.SPEED_PRESETS.indexOf(this.speed);
        const next = exports.SPEED_PRESETS[(idx + dir + exports.SPEED_PRESETS.length) % exports.SPEED_PRESETS.length];
        this.setSpeed(next);
        return next;
    }
    /** Snapshot actor positions before/after a tick for sub-tick interpolation. */
    capture(w, init = false) {
        if (init) {
            this.prev.clear();
            this.curr.clear();
            for (const a of w.actors) {
                const snap = { x: a.x, y: a.y, area: a.area, facing: a.facing };
                this.prev.set(a.id, snap);
                this.curr.set(a.id, { ...snap });
            }
            return;
        }
        this.prev = this.curr;
        this.curr = new Map();
        for (const a of w.actors) {
            this.curr.set(a.id, { x: a.x, y: a.y, area: a.area, facing: a.facing });
        }
    }
    /**
     * Advance the accumulator by `realDt` scaled by `this.speed`.
     * Executes `onTick(SIM_DT, tickIndex)` for each whole fixed step.
     * Returns the number of fixed ticks executed.
     */
    advance(realDt, w, onTick) {
        if (this.speed === 0 || realDt <= 0) {
            this.alpha = 1;
            return 0;
        }
        // Clamp raw frame dt so tab-switching never stalls the browser, then scale by speed.
        const clampedReal = Math.min(0.1, realDt);
        this.accumulator += clampedReal * this.speed;
        let steps = 0;
        while (this.accumulator + 1e-9 >= exports.SIM_DT && steps < MAX_TICKS_PER_FRAME) {
            this.accumulator = Math.max(0, this.accumulator - exports.SIM_DT);
            onTick(exports.SIM_DT, steps);
            this.tickCount++;
            steps++;
        }
        if (steps >= MAX_TICKS_PER_FRAME && this.accumulator > exports.SIM_DT) {
            this.accumulator = this.accumulator % exports.SIM_DT;
        }
        if (steps > 0)
            this.capture(w, false);
        this.alpha = Math.max(0, Math.min(1, this.accumulator / exports.SIM_DT));
        return steps;
    }
    /** Interpolated world position for actor `id` at current `alpha`. */
    interpolatedPos(id, fallbackX, fallbackY, area) {
        const c = this.curr.get(id);
        const p = this.prev.get(id);
        if (!c || !p || c.area !== area || p.area !== area) {
            return { x: fallbackX, y: fallbackY };
        }
        if (Math.hypot(c.x - p.x, c.y - p.y) > TELEPORT_SNAP_DIST) {
            return { x: fallbackX, y: fallbackY };
        }
        const a = this.alpha;
        return {
            x: p.x + (c.x - p.x) * a,
            y: p.y + (c.y - p.y) * a,
        };
    }
}
exports.SimClock = SimClock;
/**
 * Records per-tick player inputs for deterministic replay across speeds (1x vs 8x).
 */
class InputRecorder {
    constructor() {
        Object.defineProperty(this, "frames", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
    }
    record(tick, input) {
        this.frames.push({ tick, input: { ...input } });
    }
    exportLog(seed) {
        return { seed, tickHz: exports.SIM_HZ, frames: this.frames.map((f) => ({ tick: f.tick, input: { ...f.input } })) };
    }
}
exports.InputRecorder = InputRecorder;
/**
 * Latch helper so single-frame edge inputs (E, Space, C, Z) are never dropped
 * when accumulator < SIM_DT, and never fired multiple times in one frame at 8x.
 */
class EdgeInputLatch {
    constructor() {
        Object.defineProperty(this, "use", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "attack", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "core", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "toggleScan", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
    }
    push(edges) {
        if (edges.use)
            this.use = true;
        if (edges.attack)
            this.attack = true;
        if (edges.core)
            this.core = true;
        if (edges.toggleScan)
            this.toggleScan = true;
    }
    consume() {
        const out = { use: this.use, attack: this.attack, core: this.core, toggleScan: this.toggleScan };
        this.use = false;
        this.attack = false;
        this.core = false;
        this.toggleScan = false;
        return out;
    }
    clear() {
        this.use = false;
        this.attack = false;
        this.core = false;
        this.toggleScan = false;
    }
}
exports.EdgeInputLatch = EdgeInputLatch;
/**
 * Run a deterministic replay stream against a World using `stepFn`, simulating
 * browser frames at any `speed` (1x, 2x, 4x, 8x) with fixed SIM_DT ticks.
 */
function runDeterministicReplay(w, stream, speed, stepFn) {
    if (speed === 0)
        return { ticksRun: 0, framesRun: 0 };
    const clock = new SimClock();
    clock.setSpeed(speed);
    clock.capture(w, true);
    let cursor = 0;
    let framesRun = 0;
    // Step with realistic 60Hz browser frame deltas until all `stream.length` ticks have executed.
    while (cursor < stream.length) {
        const remaining = stream.length - cursor;
        // Use exact frame dt so remaining ticks aren't overshot at >1x speeds.
        const frameDt = Math.min(exports.SIM_DT, (remaining * exports.SIM_DT) / speed);
        clock.advance(frameDt, w, (dt) => {
            if (cursor >= stream.length)
                return;
            stepFn(w, dt, stream[cursor++]);
        });
        framesRun++;
    }
    return { ticksRun: cursor, framesRun };
}
