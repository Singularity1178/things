"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FAR_JOB_STRIDE = exports.NEAR_STEP_STRIDE = void 0;
exports.actorBucket = actorBucket;
exports.classifyActorLod = classifyActorLod;
exports.shouldStepLod = shouldStepLod;
exports.catchUpArea = catchUpArea;
const world_1 = require("../world/world");
const folk_1 = require("./folk");
exports.NEAR_STEP_STRIDE = 4;
exports.FAR_JOB_STRIDE = 4;
const HEADLESS_ACTIVE_RADIUS = 280;
const VIEW_PAD = 64;
/** Deterministic integer hash of actor id for staggered LOD buckets. */
function actorBucket(id) {
    let h = 2166136261;
    for (let i = 0; i < id.length; i++) {
        h ^= id.charCodeAt(i);
        h = Math.imul(h, 16777619) >>> 0;
    }
    return h >>> 0;
}
/** Classify an actor into Active / Near / Far LOD relative to the player and camera view. */
function classifyActorLod(w, a, view) {
    const pl = (0, world_1.player)(w);
    if (!pl || a.id === w.playerId)
        return "active";
    if (a.area !== pl.area)
        return "far";
    if (view) {
        if (a.x >= view.x0 - VIEW_PAD &&
            a.x <= view.x1 + VIEW_PAD &&
            a.y >= view.y0 - VIEW_PAD &&
            a.y <= view.y1 + VIEW_PAD) {
            return "active";
        }
        return "near";
    }
    return Math.hypot(a.x - pl.x, a.y - pl.y) <= HEADLESS_ACTIVE_RADIUS ? "active" : "near";
}
/**
 * Decide whether `a` steps on this tick and by what dt multiplier.
 * Deterministic for any (w.time, a.id) so save/load and 1x/8x replays match.
 */
function shouldStepLod(a, lod, tick, bucket) {
    if (lod === "active")
        return { step: true, mult: 1 };
    if (lod === "near") {
        return (tick + bucket) % exports.NEAR_STEP_STRIDE === 0
            ? { step: true, mult: exports.NEAR_STEP_STRIDE }
            : { step: false, mult: 0 };
    }
    // Far tier: only actors carrying an active task or running player job advance in background.
    const hasWork = !!a.task || (!!a.job && a.job.status === "running");
    if (!hasWork)
        return { step: false, mult: 0 };
    return (tick + bucket) % exports.FAR_JOB_STRIDE === 0
        ? { step: true, mult: exports.FAR_JOB_STRIDE }
        : { step: false, mult: 0 };
}
/**
 * Catch up an area when the player enters it after time has elapsed elsewhere.
 * Uses `world.time - area.lastTicked` to advance ritual timers and settle
 * schedule-driven residents where the current hour says.
 */
function catchUpArea(w, areaId) {
    const area = (0, world_1.getArea)(w, areaId);
    const elapsed = Math.max(0, w.time - area.lastTicked);
    if (elapsed > 0 && area.ritual?.active) {
        area.advanceRitual(elapsed);
    }
    if (elapsed > 0) {
        for (const a of w.actors) {
            if (a.area !== areaId)
                continue;
            if ((0, folk_1.isFolk)(a) && !a.task && (!a.job || a.job.status === "done")) {
                if (w.time - a.life.seen > folk_1.STALE || elapsed > folk_1.STALE) {
                    (0, folk_1.settle)(w, a);
                    a.life.seen = w.time;
                }
            }
        }
    }
    area.lastTicked = w.time;
    return elapsed;
}
