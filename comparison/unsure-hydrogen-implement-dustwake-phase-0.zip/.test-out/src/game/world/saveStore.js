"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SaveManager = exports.MemorySaveBackend = exports.MAX_BACKUPS_PER_SLOT = exports.SAVE_SLOTS = void 0;
// Multi-slot save management, rolling backups, autosave and corrupted-save
// recovery. Pure (no DOM / browser APIs): backed by an injected async
// SaveBackend (IndexedDB in browser, MemorySaveBackend in tests).
const world_1 = require("./world");
const save_1 = require("./save");
exports.SAVE_SLOTS = ["autosave", "slot1", "slot2", "slot3"];
exports.MAX_BACKUPS_PER_SLOT = 2;
/** In-memory SaveBackend for headless tests and non-browser environments. */
class MemorySaveBackend {
    constructor() {
        Object.defineProperty(this, "map", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
    }
    async get(key) { return this.map.get(key) ?? null; }
    async set(key, value) { this.map.set(key, value); }
    async del(key) { this.map.delete(key); }
    async keys() { return [...this.map.keys()]; }
    /** Test helper: overwrite raw slot bytes directly (e.g. to simulate corruption). */
    corruptRaw(key, value) { this.map.set(key, value); }
    rawMap() { return this.map; }
}
exports.MemorySaveBackend = MemorySaveBackend;
const primaryKey = (slotId) => `save:${slotId}`;
const backupKey = (slotId, idx) => `backup:${slotId}:${idx}`;
const metaKey = (slotId) => `meta:${slotId}`;
class SaveManager {
    constructor(backend) {
        Object.defineProperty(this, "backend", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: backend
        });
    }
    /** Save `world` to `slotId`, rotating existing primary data into rolling backups. */
    async saveSlot(slotId, world, label) {
        const existing = await this.backend.get(primaryKey(slotId));
        if (existing) {
            // Only rotate valid JSON into backups so a corrupted primary never overwrites a good backup.
            if ((0, save_1.tryLoadSave)(existing)) {
                for (let i = exports.MAX_BACKUPS_PER_SLOT; i >= 2; i--) {
                    const prev = await this.backend.get(backupKey(slotId, i - 1));
                    if (prev !== null)
                        await this.backend.set(backupKey(slotId, i), prev);
                }
                await this.backend.set(backupKey(slotId, 1), existing);
            }
        }
        const data = (0, save_1.serialize)(world);
        const json = JSON.stringify(data);
        await this.backend.set(primaryKey(slotId), json);
        const pl = (0, world_1.player)(world);
        const meta = {
            slotId,
            label: label ?? (slotId === "autosave" ? "Autosave" : slotId.toUpperCase()),
            savedAt: Date.now(),
            playTime: world.playTime,
            day: world.day,
            area: pl?.area ?? "dungeon",
            version: data.version,
            sizeBytes: json.length,
        };
        await this.backend.set(metaKey(slotId), JSON.stringify(meta));
        return meta;
    }
    /** Load a slot, automatically recovering from rolling backups if primary is corrupted. */
    async loadSlot(slotId) {
        const primary = await this.backend.get(primaryKey(slotId));
        const backups = [];
        for (let i = 1; i <= exports.MAX_BACKUPS_PER_SLOT; i++) {
            backups.push(await this.backend.get(backupKey(slotId, i)));
        }
        const res = (0, save_1.tryLoadSave)(primary, backups);
        if (!res)
            return null;
        return { ...res, slotId };
    }
    /** Export a slot (or live world) as a portable save file string. */
    async exportSlot(slotId) {
        const loaded = await this.loadSlot(slotId);
        if (!loaded)
            return null;
        return (0, save_1.exportSaveString)(loaded.world);
    }
    /** Delete a slot and all its rolling backups & metadata. */
    async deleteSlot(slotId) {
        await this.backend.del(primaryKey(slotId));
        await this.backend.del(metaKey(slotId));
        for (let i = 1; i <= exports.MAX_BACKUPS_PER_SLOT; i++) {
            await this.backend.del(backupKey(slotId, i));
        }
    }
    /** List metadata for all known slots (autosave + slot1..slot3 + any custom slots). */
    async listSlots() {
        const allKeys = await this.backend.keys();
        const known = new Set(exports.SAVE_SLOTS);
        for (const k of allKeys) {
            if (k.startsWith("save:"))
                known.add(k.slice(5));
        }
        const out = [];
        for (const id of known) {
            const rawMeta = await this.backend.get(metaKey(id));
            const hasPrimary = (await this.backend.get(primaryKey(id))) !== null;
            if (!rawMeta && !hasPrimary) {
                out.push(null);
                continue;
            }
            if (rawMeta) {
                try {
                    const parsed = JSON.parse(rawMeta);
                    out.push(parsed);
                    continue;
                }
                catch {
                    // Fall through to metadata reconstruction
                }
            }
            out.push({
                slotId: id,
                label: id,
                savedAt: 0,
                playTime: 0,
                day: 0,
                area: "unknown",
                version: 0,
                sizeBytes: 0,
                corrupted: true,
            });
        }
        return out;
    }
    /** Load the most recently saved valid slot (used by Quick Load / Continue). */
    async loadLatest() {
        const list = (await this.listSlots()).filter((m) => !!m && !m.corrupted);
        list.sort((a, b) => b.savedAt - a.savedAt);
        for (const m of list) {
            const res = await this.loadSlot(m.slotId);
            if (res)
                return res;
        }
        return null;
    }
}
exports.SaveManager = SaveManager;
