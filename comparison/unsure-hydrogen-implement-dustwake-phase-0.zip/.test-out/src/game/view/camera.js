"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Camera = void 0;
// Camera controller: smooth tracking, zoom-centered resizing, clamping, and screen shake.
const tiles_1 = require("../content/tiles");
const util_1 = require("../util");
class Camera {
    constructor() {
        Object.defineProperty(this, "x", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "y", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "shakeT", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "shakeMag", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
    }
    shake(t, m, enabled = true) {
        if (!enabled)
            return;
        this.shakeT = Math.max(this.shakeT, t);
        this.shakeMag = Math.max(this.shakeMag, m);
    }
    clearShake() {
        this.shakeT = 0;
        this.shakeMag = 0;
    }
    snap(targetX, targetY, area, vw, vh) {
        this.x = (0, util_1.clamp)(targetX - vw / 2, 0, Math.max(0, area.w * tiles_1.TS - vw));
        this.y = (0, util_1.clamp)(targetY - 12 - vh / 2, 0, Math.max(0, area.h * tiles_1.TS - vh));
    }
    onResize(oldW, oldH, newW, newH, area) {
        this.x -= (newW - oldW) / 2;
        this.y -= (newH - oldH) / 2;
        if (area) {
            this.x = (0, util_1.clamp)(this.x, 0, Math.max(0, area.w * tiles_1.TS - newW));
            this.y = (0, util_1.clamp)(this.y, 0, Math.max(0, area.h * tiles_1.TS - newH));
        }
    }
    update(targetX, targetY, area, vw, vh, dt) {
        const tx = (0, util_1.clamp)(targetX - vw / 2, 0, Math.max(0, area.w * tiles_1.TS - vw));
        const ty = (0, util_1.clamp)(targetY - 12 - vh / 2, 0, Math.max(0, area.h * tiles_1.TS - vh));
        this.x += (tx - this.x) * Math.min(1, dt * 3.5);
        this.y += (ty - this.y) * Math.min(1, dt * 3.5);
        this.shakeT = Math.max(0, this.shakeT - dt);
        if (this.shakeT <= 0)
            this.shakeMag = 0;
    }
    shakenPos(enabled = true) {
        let sx = 0, sy = 0;
        if (enabled && this.shakeT > 0) {
            sx = (Math.random() - 0.5) * this.shakeMag * 2;
            sy = (Math.random() - 0.5) * this.shakeMag * 2;
        }
        return { camX: Math.round(this.x + sx), camY: Math.round(this.y + sy) };
    }
}
exports.Camera = Camera;
