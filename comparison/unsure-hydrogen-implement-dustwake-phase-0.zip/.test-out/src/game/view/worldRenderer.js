"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WorldRenderer = void 0;
// World Renderer extracted from Game (0.6): draws the lit scene at view
// resolution (vw x vh), interpolating actor positions between fixed sim ticks.
const tiles_1 = require("../content/tiles");
const items_1 = require("../content/items");
const flags_1 = require("../content/flags");
const glyphs_1 = require("../content/glyphs");
const props_1 = require("../content/props");
const digging_1 = require("../content/digging");
const daycycle_1 = require("../content/daycycle");
const gear_1 = require("../sim/gear");
const daytime_1 = require("../sim/daytime");
const props_2 = require("../art/props");
const tiles_2 = require("../art/tiles");
const items_2 = require("../art/items");
const util_1 = require("../util");
const golem_1 = require("../golem");
const light_1 = require("../light");
const circle_1 = require("../circle");
const surfaceRune_1 = require("../surfaceRune");
const actors_1 = require("./actors");
const world_1 = require("../world/world");
const BURIED_AMBIENT = [0.05, 0.045, 0.065];
class WorldRenderer {
    constructor(wctx, vw, vh) {
        Object.defineProperty(this, "scene", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "emit", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "lighting", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "outImg", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "circle", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (0, circle_1.buildCircle)()
        });
        Object.defineProperty(this, "shaft", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "sunShaft", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "selfPose", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "runeArtCache", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        this.scene = (0, util_1.makeCanvas)(vw, vh);
        this.emit = (0, util_1.makeCanvas)(vw, vh);
        this.lighting = new light_1.Lighting(vw, vh);
        this.outImg = wctx.createImageData(vw, vh);
        this.shaft = this.buildShaft(["#1c2638", "#121a28", "#26324a"]);
        this.sunShaft = this.buildShaft(["#4a3a1c", "#33280f", "#5e4a22"]);
    }
    get runeArt() {
        return (this.runeArtCache ?? (this.runeArtCache = new surfaceRune_1.SurfaceRuneArt(this.circle.pixels)));
    }
    resize(wctx, vw, vh) {
        this.scene = (0, util_1.makeCanvas)(vw, vh);
        this.emit = (0, util_1.makeCanvas)(vw, vh);
        this.lighting = new light_1.Lighting(vw, vh);
        this.outImg = wctx.createImageData(vw, vh);
    }
    buildShaft(cols) {
        const FOOT = 150, FADE = 0.55;
        return (0, util_1.makeSprite)(80, FOOT + 10, 40, FOOT, 1, (p) => {
            for (let y = 0; y < FOOT + 10; y++) {
                const t = y / FOOT;
                const cx = (0, util_1.lerp)(22, 40, t), hw = (0, util_1.lerp)(7, 24, t);
                const k = (0, util_1.clamp)(t / FADE, 0, 1), dens = k * k * (3 - 2 * k);
                for (let x = 0; x < 80; x++) {
                    const d = Math.abs(x - cx) / hw;
                    if (y > FOOT) {
                        const e = ((x - 40) / 26) ** 2 + ((y - FOOT - 2) / 7) ** 2;
                        if (e < 1 && (x + y) % 2 === 0)
                            p.g(x, y, 1, 1, cols[2]);
                        continue;
                    }
                    if (d < 1 && (x + y) % 2 === 0 && (0, util_1.hash2)(x, y, 2) > d * 0.8 && (0, util_1.hash2)(x, y, 5) < dens) {
                        p.g(x, y, 1, 1, d < 0.5 ? cols[0] : cols[1]);
                    }
                }
            }
        });
    }
    eyeSpot(st) {
        if (st.hideGolem)
            return null;
        const pl = st.pl, lk = st.look, f = pl.facing;
        const pos = st.clock.interpolatedPos(pl.id, pl.x, pl.y, pl.area);
        const y = Math.round(pos.y - lk.z) - 18 + Math.round(lk.dormant * 4) + Math.round(lk.dormant * 3);
        const x = Math.round(pos.x) + (f === "right" ? 2 : f === "left" ? -4 : -2);
        return { x, y, w: f === "down" ? 4 : 2, show: f !== "up" };
    }
    render(wctx, st) {
        const sc = this.scene.ctx, ec = this.emit.ctx;
        const area = st.view.area;
        const { camX, camY } = st.cam.shakenPos(st.screenShake);
        const W = st.vw, H = st.vh;
        const hour = (0, daytime_1.worldHour)(st.world);
        sc.fillStyle = "#000";
        sc.fillRect(0, 0, W, H);
        ec.fillStyle = "#000";
        ec.fillRect(0, 0, W, H);
        st.view.prepare(camX, camY, W, H);
        st.view.idle();
        sc.drawImage(st.view.bg.c, camX, camY, W, H, 0, 0, W, H);
        const spr = (s, x, y) => {
            const dx = Math.round(x - s.ax - camX), dy = Math.round(y - s.ay - camY);
            if (dx > W || dy > H || dx + s.w < 0 || dy + s.h < 0)
                return;
            sc.drawImage(s.a, dx, dy);
            ec.drawImage(s.e, dx, dy);
        };
        const daylight = (0, daycycle_1.sunLevel)(hour);
        if (area.base.interior && daylight > 0)
            for (const pt of area.base.portals ?? []) {
                if (!pt.door || pt.dir !== "down")
                    continue;
                const x = pt.x - 1 - camX, y = pt.y + 4 - camY, ww = pt.w + 2;
                sc.globalAlpha = daylight;
                sc.fillStyle = "#cfc49c";
                sc.fillRect(x, y, ww, 6);
                sc.fillStyle = "#f0e8c8";
                sc.fillRect(x + 1, y + 2, ww - 2, 3);
                sc.globalAlpha = 1;
                ec.globalAlpha = daylight * 0.45;
                ec.fillStyle = "#a89868";
                ec.fillRect(x, y, ww, 6);
                ec.globalAlpha = 1;
            }
        const r = area.ritual;
        if (r) {
            const c = area.ritualPos;
            const schemRead = (0, world_1.hasFlag)(st.world, flags_1.FLAGS.knowSchematic);
            const ccx = c.x - circle_1.CR - camX, ccy = c.y - circle_1.CR - camY;
            if (ccx > -140 && ccx < W + 10 && ccy > -140 && ccy < H + 10) {
                sc.drawImage(this.circle.base, ccx, ccy);
                sc.drawImage(r.carved ? this.circle.gapCarved : this.circle.chalk, ccx, ccy);
                let lvl = r.active ? 0.55 + 0.35 * Math.sin(st.t * 3) + Math.min(0.3, r.actT * 0.1) : 0.16 + 0.06 * Math.sin(st.t * 1.3);
                if (st.fizzT > 0 && st.flashes)
                    lvl = Math.random() * 0.8;
                ec.globalAlpha = (0, util_1.clamp)(lvl, 0, 1);
                ec.drawImage(this.circle.glow, ccx, ccy);
                if (r.carved)
                    ec.drawImage(this.circle.glowGap, ccx, ccy);
                if (!r.carved && schemRead) {
                    ec.globalAlpha = 0.45 + 0.3 * Math.sin(st.t * 4);
                    ec.drawImage(this.circle.ghost, ccx, ccy);
                }
                if (r.active) {
                    ec.globalCompositeOperation = "lighter";
                    ec.globalAlpha = 0.35 + 0.25 * Math.sin(st.t * 5);
                    ec.drawImage(this.circle.glow, ccx, ccy);
                    ec.drawImage(this.circle.glowGap, ccx, ccy);
                    ec.globalCompositeOperation = "source-over";
                }
                ec.globalAlpha = 1;
            }
        }
        for (const p of area.props)
            if (p.kind === "runecircle")
                this.drawSurfaceRune(p, camX, camY, st);
        const list = [];
        const vx0 = camX - 48, vx1 = camX + W + 48, vy0 = camY - 16, vy1 = camY + H + 60;
        for (const p of area.props) {
            if (p.x < vx0 || p.x > vx1 || p.y < vy0 || p.y > vy1)
                continue;
            if (p.kind === "pedestal") {
                const i = Number(p.id.slice(3));
                list.push({ y: p.y, f: () => this.drawPedestal(p, i, spr, camX, camY, st) });
                continue;
            }
            const def = (0, props_1.propDef)(p.kind);
            const lvl = def.habit ? st.tendedLevel(p, hour) : 1;
            const alt = def.alt === "lit" ? !!p.lit && lvl > 0.05 : def.alt === "taken" ? p.taken : p.open;
            const s = (0, props_2.propSprite)(p.kind, (0, digging_1.propLook)(p), alt);
            if (!s)
                continue;
            if (lvl <= 0.01 && def.habit === "window")
                continue;
            list.push({
                y: def.wallMounted ? p.y - 0.5 : def.flat ? p.y - 16 : p.y,
                f: () => {
                    if (lvl < 1 && def.alt !== "lit")
                        this.drawDimmed(s, p, lvl, def.habit === "window", camX, camY, W, H);
                    else if (def.sway && !alt)
                        this.drawSwaying(s, p, camX, camY, st.t, W, H);
                    else
                        spr(s, p.x, p.y);
                    if (p.lit && def.fire && lvl > 0.05)
                        this.drawFlame(p, def.fire.big, camX, camY, st.t);
                    if (p.item && !p.container && !p.taken && items_1.ITEMS[p.item].showOnProp !== false) {
                        const ic = (0, items_2.itemIcon)(p.item);
                        const bob = (0, items_1.isGlyph)(p.item) ? Math.round(Math.sin(st.t * 2) * 0.6) : 0;
                        spr(ic, p.x + (def.itemDx ?? 0), p.y - (p.itemZ ?? 8) + bob);
                    }
                },
            });
        }
        for (const l of area.loose) {
            if (l.taken || l.x < vx0 || l.x > vx1 || l.y < vy0 || l.y > vy1)
                continue;
            list.push({ y: l.y, f: () => spr((0, items_2.itemIcon)(l.item), l.x, l.y + 2) });
        }
        const AW = area.w;
        const tx0 = Math.max(0, Math.floor(camX / tiles_1.TS) - 1), tx1 = Math.min(AW - 1, Math.floor((camX + W) / tiles_1.TS) + 1);
        const ty0 = Math.max(0, Math.floor(camY / tiles_1.TS) - 1), ty1 = Math.min(area.h - 1, Math.floor((camY + H) / tiles_1.TS) + 3);
        for (let ty = ty0; ty <= ty1; ty++) {
            for (let tx = tx0; tx <= tx1; tx++) {
                const t = area.grid[ty * AW + tx];
                const x = tx * tiles_1.TS + 8, y = ty * tiles_1.TS + 16;
                if (t === tiles_1.T.RUBBLE) {
                    const s = (0, tiles_2.rubbleSprite)(Math.floor((0, util_1.hash2)(tx, ty, 5) * 3), false);
                    list.push({ y, f: () => spr(s, x, y) });
                }
                else if (t === tiles_1.T.CRACKED) {
                    const s = (0, tiles_2.rubbleSprite)(0, true);
                    const sh = st.shudder;
                    const jx = sh && sh.tx === tx && ty >= sh.ty && ty <= sh.ty + 2 ? Math.round(Math.sin(st.t * 80) * 2 * Math.min(1, sh.t / 0.3)) : 0;
                    list.push({
                        y,
                        f: () => {
                            spr(s, x + jx, y);
                            if (st.crackFlash > 0 && st.flashes) {
                                ec.globalAlpha = st.crackFlash;
                                ec.drawImage(s.e, Math.round(x + jx - s.ax - camX), Math.round(y - s.ay - camY));
                                ec.globalAlpha = 1;
                            }
                        },
                    });
                }
                else if (t === tiles_1.T.PILLAR) {
                    const s = (0, tiles_2.pillarSprite)(area.tvar[ty * AW + tx] === 1);
                    list.push({ y, f: () => spr(s, x, y) });
                }
                else if (t === tiles_1.T.LOCKED) {
                    const s = (0, tiles_2.doorSprite)();
                    list.push({ y, f: () => spr(s, x, y) });
                }
                else if (t === tiles_1.T.BARS) {
                    const s = (0, tiles_2.barsSprite)();
                    list.push({ y, f: () => spr(s, x, y) });
                }
            }
        }
        for (const a of st.world.actors) {
            if (a.id === st.world.playerId || a.area !== area.id)
                continue;
            const ip = st.clock.interpolatedPos(a.id, a.x, a.y, a.area);
            if (ip.x < vx0 || ip.x > vx1 || ip.y < vy0 || ip.y > vy1)
                continue;
            const drawActorAt = () => {
                if (st.selectedIds?.has(a.id)) {
                    sc.fillStyle = st.selectionColor ?? "#7fe8ff";
                    sc.fillRect(Math.round(ip.x - camX - 7), Math.round(ip.y - camY - 2), 14, 1);
                    sc.fillRect(Math.round(ip.x - camX - 7), Math.round(ip.y - camY + 2), 14, 1);
                }
                const savedX = a.x, savedY = a.y;
                a.x = ip.x;
                a.y = ip.y;
                (0, actors_1.drawActor)(sc, ec, st.world, a, camX, camY, st.t, st.npcLook(a));
                a.x = savedX;
                a.y = savedY;
            };
            list.push({ y: ip.y, f: drawActorAt });
        }
        const pl = st.pl;
        const plPos = st.clock.interpolatedPos(pl.id, pl.x, pl.y, pl.area);
        if (!st.hideGolem)
            list.push({ y: plPos.y, f: () => this.drawPlayer(camX, camY, plPos.x, plPos.y, st) });
        for (const p of st.particles) {
            if (p.kind === "debris" || p.kind === "dust" || p.kind === "smoke" || p.kind === "splash") {
                list.push({
                    y: p.y,
                    f: () => {
                        sc.fillStyle = p.col;
                        const s = p.size;
                        sc.fillRect(Math.round(p.x - camX), Math.round(p.y - p.z - camY), s, s);
                        if (p.emit === false) {
                            ec.fillStyle = "#000";
                            ec.fillRect(Math.round(p.x - camX), Math.round(p.y - p.z - camY), s, s);
                        }
                    },
                });
            }
        }
        list.sort((a, b) => a.y - b.y);
        for (const d of list)
            d.f();
        const moon = st.view.byId("moon");
        if (moon) {
            const sun = daylight, mx = Math.round(moon.x - this.shaft.ax - camX), my = Math.round(moon.y + 2 - this.shaft.ay - camY);
            ec.globalCompositeOperation = "lighter";
            if (sun < 1) {
                ec.globalAlpha = 1 - sun;
                ec.drawImage(this.shaft.e, mx, my);
            }
            if (sun > 0) {
                ec.globalAlpha = sun;
                ec.drawImage(this.sunShaft.e, mx, my);
            }
            ec.globalAlpha = 1;
            ec.globalCompositeOperation = "source-over";
        }
        for (const p of st.particles) {
            if (p.kind === "debris" || p.kind === "dust" || p.kind === "smoke" || p.kind === "splash")
                continue;
            const x = Math.round(p.x - camX), y = Math.round(p.y - p.z - camY);
            if (x < -2 || y < -2 || x > W + 2 || y > H + 2)
                continue;
            if (p.kind === "glint") {
                const a = Math.sin((0, util_1.clamp)(p.life, 0, 1) * Math.PI);
                ec.globalCompositeOperation = "lighter";
                ec.fillStyle = `rgba(255,240,200,${a})`;
                ec.fillRect(x, y, 1, 1);
                if (a > 0.5) {
                    ec.fillStyle = `rgba(255,240,200,${a * 0.5})`;
                    ec.fillRect(x - 1, y, 3, 1);
                    ec.fillRect(x, y - 1, 1, 3);
                }
                ec.globalCompositeOperation = "source-over";
                continue;
            }
            if (p.emit) {
                ec.globalCompositeOperation = "lighter";
                ec.globalAlpha = (0, util_1.clamp)(p.life * 1.5, 0, 1);
                ec.fillStyle = p.col;
                ec.fillRect(x, y, p.size, p.size);
                ec.globalAlpha = 1;
                ec.globalCompositeOperation = "source-over";
            }
            else if (p.kind === "mote") {
                sc.fillStyle = p.col;
                sc.fillRect(x, y, 1, 1);
            }
            else {
                sc.fillStyle = p.col;
                sc.fillRect(x, y, p.size, p.size);
            }
        }
        const sImg = sc.getImageData(0, 0, W, H);
        const eImg = ec.getImageData(0, 0, W, H);
        const active = st.hideGolem ? [] : [st.glight];
        for (const L of st.view.lights.values())
            if (L.on)
                active.push(L);
        this.lighting.accumulate(active, camX, camY);
        const exposure = (0, daytime_1.exposureOf)(area);
        this.lighting.compose(sImg.data, eImg.data, this.outImg.data, (0, daycycle_1.ambientAt)(area.base.ambient ?? BURIED_AMBIENT, hour, exposure), 6, (0, daycycle_1.lampGain)(hour, exposure));
        wctx.putImageData(this.outImg, 0, 0);
        const eye = this.eyeSpot(st);
        st.vision.draw(wctx, st.pl, camX, camY, W, H, st.t, eye && { x: eye.x + eye.w / 2 - 1, y: eye.y, w: eye.w, show: eye.show });
    }
    drawSurfaceRune(p, camX, camY, st) {
        const rs = st.surfaceRuneState();
        const ccx = Math.round(p.x - circle_1.CR - camX), ccy = Math.round(p.y - circle_1.CR - camY);
        if (ccx > -140 && ccx < st.vw + 10 && ccy > -140 && ccy < st.vh + 10) {
            const sc = this.scene.ctx, ec = this.emit.ctx;
            const L = this.runeArt.layers(rs.t);
            sc.drawImage(L.scene, ccx, ccy);
            if (rs.glow > 0) {
                ec.globalAlpha = (0, util_1.clamp)(rs.glow, 0, 1);
                ec.drawImage(L.emit, ccx, ccy);
                if (rs.glow > 1) {
                    ec.globalCompositeOperation = "lighter";
                    ec.globalAlpha = (0, util_1.clamp)(rs.glow - 1, 0, 1);
                    ec.drawImage(L.emit, ccx, ccy);
                    ec.globalCompositeOperation = "source-over";
                }
                ec.globalAlpha = 1;
            }
        }
        if (rs.column > 0)
            this.drawSummonColumn(p.x - camX, p.y - camY, rs.column, st.t);
    }
    drawSummonColumn(x, y, k, t) {
        const ec = this.emit.ctx;
        x = Math.round(x);
        y = Math.round(y);
        const w = Math.round(3 + 7 * k);
        ec.globalCompositeOperation = "lighter";
        for (let yy = y + 4; yy > -2; yy -= 2) {
            const f = 1 - ((y - yy) / Math.max(1, y + 2)) * 0.6;
            const wob = Math.round(Math.sin(yy * 0.21 + t * 9) * k);
            ec.globalAlpha = (0, util_1.clamp)(k * f * 0.5, 0, 1);
            ec.fillStyle = "#9a70ff";
            ec.fillRect(x - w + wob, yy - 2, w * 2, 2);
            ec.globalAlpha = (0, util_1.clamp)(k * f, 0, 1);
            ec.fillStyle = "#e8e0ff";
            ec.fillRect(x - 1 + wob, yy - 2, 2 + Math.round(k * 2), 2);
        }
        ec.globalAlpha = (0, util_1.clamp)(k * 0.6, 0, 1);
        ec.fillStyle = "#c0a0ff";
        ec.fillRect(x - 14, y - 3, 28, 8);
        ec.globalAlpha = 1;
        ec.globalCompositeOperation = "source-over";
    }
    drawDimmed(s, p, lvl, whole, camX, camY, vw, vh) {
        const dx = Math.round(p.x - s.ax - camX), dy = Math.round(p.y - s.ay - camY);
        if (dx > vw || dy > vh || dx + s.w < 0 || dy + s.h < 0)
            return;
        const sc = this.scene.ctx, ec = this.emit.ctx;
        if (whole)
            sc.globalAlpha = lvl;
        sc.drawImage(s.a, dx, dy);
        sc.globalAlpha = 1;
        if (lvl > 0.01) {
            ec.globalAlpha = lvl;
            ec.drawImage(s.e, dx, dy);
            ec.globalAlpha = 1;
        }
    }
    drawSwaying(s, p, camX, camY, t, vw, vh) {
        const dx = Math.round(p.x - s.ax - camX), dy = Math.round(p.y - s.ay - camY);
        if (dx > vw || dy > vh || dx + s.w < 0 || dy + s.h < 0)
            return;
        const sc = this.scene.ctx, ec = this.emit.ctx;
        const wv = Math.sin(t * 1.6 + p.x * 0.031 + p.y * 0.017) + 0.4 * Math.sin(t * 3.7 + p.x * 0.11);
        const o = Math.round(wv * 0.75);
        if (!o) {
            sc.drawImage(s.a, dx, dy);
            ec.drawImage(s.e, dx, dy);
            return;
        }
        const cut = Math.floor(s.h * 0.55);
        for (const [src, ctx] of [[s.a, sc], [s.e, ec]]) {
            ctx.drawImage(src, 0, 0, s.w, cut, dx + o, dy, s.w, cut);
            ctx.drawImage(src, 0, cut, s.w, s.h - cut, dx, dy + cut, s.w, s.h - cut);
        }
    }
    drawFlame(p, big, camX, camY, tNow) {
        const ec = this.emit.ctx;
        const bx = Math.round(p.x - camX), by = Math.round(p.y - camY - 15 + ((0, props_1.propDef)(p.kind).fire?.dy ?? 0));
        const t = tNow * 12 + p.x;
        const cols = ["#ff5a10", "#ff9a30", "#ffd060", "#fff0b0"];
        const w = big ? 8 : 3;
        for (let i = 0; i < w; i++) {
            const hgt = Math.max(1, Math.round((big ? 7 : 4) * (1 - Math.abs(i - (w - 1) / 2) / w) + Math.sin(t + i * 1.7) * 1.5 + Math.sin(t * 1.7 + i) * 0.8));
            for (let j = 0; j < hgt; j++) {
                const k = Math.min(3, Math.floor((j / hgt) * 4));
                ec.fillStyle = cols[3 - k];
                if (j === hgt - 1)
                    ec.fillStyle = cols[0];
                ec.fillRect(bx - Math.floor(w / 2) + i, by - j + (big ? 2 : 0), 1, 1);
            }
        }
    }
    drawPedestal(p, i, spr, camX, camY, st) {
        const s = (0, props_2.propSprite)("pedestal", 0, false);
        spr(s, p.x, p.y);
        const area = st.view.area, r = area.ritual;
        const g = r.sockets[i];
        const ec = this.emit.ctx;
        const topY = p.y - 15;
        if (g >= 0) {
            spr((0, items_2.itemIcon)((0, items_1.glyphItem)(g)), p.x, topY + 4);
            if (r.active) {
                const pen = new util_1.Pen(ec, true);
                (0, items_2.glyphPattern)(pen, g, Math.round(p.x - camX) - 4, Math.round(topY - camY) - 7, glyphs_1.GLYPHS[g].color, true);
            }
            if (r.wrong[i] && st.fizzT > 0 && st.flashes && Math.sin(st.t * 30) > 0) {
                ec.fillStyle = "#ff2040";
                ec.globalAlpha = 0.6;
                ec.fillRect(Math.round(p.x - camX) - 6, Math.round(topY - camY) - 8, 12, 12);
                ec.globalAlpha = 1;
            }
        }
        if ((0, world_1.hasFlag)(st.world, flags_1.FLAGS.knowSchematic) && g !== r.solution[i] && !r.active) {
            const pen = new util_1.Pen(ec, true);
            ec.globalAlpha = 0.35 + 0.2 * Math.sin(st.t * 3 + i);
            const bob = Math.round(Math.sin(st.t * 2 + i) * 1.5);
            (0, items_2.glyphPattern)(pen, r.solution[i], Math.round(p.x - camX) - 3, Math.round(topY - camY) - 16 + bob - (g >= 0 ? 4 : 0), glyphs_1.GLYPHS[r.solution[i]].color, true);
            ec.globalAlpha = 1;
        }
        if (i === 0 && r.core) {
            const c = area.ritualPos;
            const bob = Math.round(Math.sin(st.t * 2) * 1.5) + (r.active ? -3 : 0);
            spr((0, items_2.itemIcon)("core"), c.x, c.y - 4 + bob);
        }
    }
    drawPlayer(camX, camY, px, py, st) {
        const pl = st.pl, lk = st.look, sc = this.scene.ctx;
        sc.fillStyle = "rgba(0,0,0,0.45)";
        const sx = Math.round(px - camX), sy = Math.round(py - camY);
        const sw = Math.max(4, 8 - Math.round(lk.z / 3));
        sc.fillRect(sx - sw, sy - 1, sw * 2, 2);
        sc.fillRect(sx - sw + 2, sy - 2, sw * 2 - 4, 4);
        const a = pl.task;
        let raise = 0, reach = 0, slam, dip;
        if (a) {
            const k = a.t / a.dur;
            if (a.kind === "reach" || a.kind === "push" || a.kind === "dismantle")
                reach = Math.sin(Math.min(1, k) * Math.PI);
            if (a.kind === "smash")
                raise = a.t < 0.5 ? a.t / 0.5 : a.t < 0.62 ? (0, util_1.lerp)(1, -1, (a.t - 0.5) / 0.12) : (0, util_1.lerp)(-1, 0, (0, util_1.clamp)((a.t - 0.62) / 0.5, 0, 1));
            if (a.kind === "carve")
                reach = 0.4 + 0.6 * Math.abs(Math.sin(a.t * 14));
            if (a.kind === "craft")
                reach = 0.3 + 0.7 * Math.abs(Math.sin(a.t * 9));
            if (a.kind === "attach")
                reach = 0.3;
            if (a.kind === "punch") {
                const k2 = a.t / a.dur;
                raise = k2 < 0.35 ? k2 / 0.35 : k2 < 0.5 ? (0, util_1.lerp)(1, -1, (k2 - 0.35) / 0.15) : (0, util_1.lerp)(-1, 0, (0, util_1.clamp)((k2 - 0.5) / 0.4, 0, 1));
            }
            if (a.kind === "channel")
                reach = 0.2;
            if (a.kind === "slam")
                ({ lift: slam, dip } = (0, golem_1.slamPose)(k));
        }
        const pose = {
            facing: st.gaze ?? pl.facing,
            phase: pl.phase,
            moving: pl.moving && !a,
            hasArm: (0, world_1.hasFlag)(st.world, flags_1.FLAGS.golemArm),
            dormant: lk.dormant,
            eye: (0, util_1.clamp)(lk.eye + st.eyeBoost + st.vision.k * 0.35, 0, 1.6),
            core: lk.core,
            raise,
            reach,
            t: st.t,
            eyeFixed: (0, world_1.hasFlag)(st.world, flags_1.FLAGS.golemEye),
            back: pl.gear.back,
            runes: (0, gear_1.runeMarks)(st.world, pl),
            slam,
            dip,
        };
        const ox = px - camX + (a?.kind === "push" ? Math.round(Math.sin(a.t * 40)) : 0);
        const oy = py - camY - lk.z;
        (0, golem_1.drawGolem)(new util_1.Pen(sc, false), ox, oy, pose);
        (0, golem_1.drawGolem)(new util_1.Pen(this.emit.ctx, true), ox, oy, pose);
        this.selfPose = { pose, x: ox + camX, y: oy + camY };
    }
}
exports.WorldRenderer = WorldRenderer;
