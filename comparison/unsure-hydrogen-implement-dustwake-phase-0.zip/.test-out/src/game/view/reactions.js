"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventReactor = void 0;
// Event-reaction layer extracted from Game (0.6): translates SimEvents into
// audio, particles, UI callbacks, NPC look easing, and NotificationFeed alerts.
const items_1 = require("../content/items");
const crafting_1 = require("../content/crafting");
const tasks_1 = require("../content/tasks");
const vision_1 = require("../content/vision");
const flags_1 = require("../content/flags");
const runes_1 = require("../content/runes");
const actors_1 = require("../content/actors");
const npcs_1 = require("../content/npcs");
const power_1 = require("../sim/power");
const actorStats_1 = require("../sim/actorStats");
const monologue_1 = require("../sim/monologue");
const dialogue_1 = require("../sim/dialogue");
const portals_1 = require("../sim/portals");
const folk_1 = require("../sim/folk");
const shops_1 = require("../sim/shops");
const items_2 = require("../art/items");
const light_1 = require("../light");
const workerAnim_1 = require("../workerAnim");
const actors_2 = require("./actors");
const audience_1 = require("./audience");
const world_1 = require("../world/world");
const FOLK_EARSHOT = 170;
const FOLK_MAX_LINES = 3;
class EventReactor {
    constructor() {
        Object.defineProperty(this, "npcLooks", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        Object.defineProperty(this, "bubbles", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        Object.defineProperty(this, "lastAnalyzed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { prop: "", t: -1 }
        });
    }
    clear() {
        this.npcLooks.clear();
        this.bubbles.clear();
        this.lastAnalyzed = { prop: "", t: -1 };
    }
    npcLook(w, a) {
        let L = this.npcLooks.get(a.id);
        if (!L) {
            const on = (0, dialogue_1.isAwake)(w, a.id) ? 1 : 0;
            L = { awake: on, eye: on, wakeT: 99, sleepT: 99, reach: 0, flare: 0, lift: 0, seen: -99, arrived: false };
            this.npcLooks.set(a.id, L);
        }
        return L;
    }
    drainEvents(h) {
        (0, monologue_1.reactToEvents)(h.world);
        const evs = h.world.events;
        if (!evs.length)
            return;
        h.world.events = [];
        for (const e of evs) {
            if (e.t === "travelled" && e.actor !== h.world.playerId) {
                this.workerTravelled(h, e);
                continue;
            }
            if (e.t === "portal" && (0, world_1.actorById)(h.world, e.actor)?.kind === "folk")
                continue;
            if (e.t === "portal" && e.actor !== h.world.playerId) {
                this.workerWalked(h, e);
                continue;
            }
            if (e.t === "jobChanged") {
                this.onJobChanged(h, e);
            }
            const aud = (0, audience_1.eventAudience)(h.world, e);
            if (aud === "player")
                this.onEvent(h, e);
            else if (aud === "nearby")
                this.onNearby(h, e);
        }
    }
    onJobChanged(h, e) {
        if (e.actor === h.world.playerId)
            return;
        const worker = (0, world_1.actorById)(h.world, e.actor);
        const label = worker?.name ? `${worker.name}` : "Worker";
        if (e.status === "blocked" || e.status === "paused") {
            const reason = e.reason ?? "blocked";
            const cat = reason === "power" ? "noPower" : reason === "storageFull" ? "storageFull" : "workerBlocked";
            const pause = h.notifications.push({
                simTime: h.world.time,
                day: h.world.day,
                level: reason === "power" ? "alert" : "warn",
                category: cat,
                title: `${label}: ${reason === "power" ? "Out of Power" : reason === "storageFull" ? "Storage Full" : "Order Blocked"}`,
                body: `Reason: ${reason} in ${worker?.area ?? "unknown"}`,
                area: worker?.area,
                x: worker?.x,
                y: worker?.y,
                actorId: e.actor,
            });
            if (pause)
                h.onPauseAlert();
        }
    }
    onNearby(h, e) {
        if (e.t === "step") {
            const a = (0, world_1.actorById)(h.world, e.actor);
            if (a)
                for (let i = 0; i < 2; i++) {
                    h.particles.spawn({ x: a.x + (Math.random() - 0.5) * 8, y: a.y, z: 1, vx: (Math.random() - 0.5) * 12, vz: 6, life: 0.5, kind: "dust", col: "#8a8478", g: 20 });
                }
        }
        else if (e.t === "harvestHit") {
            if (e.kind === "tree" || e.kind === "log")
                h.sfx.thud();
            else
                h.sfx.clink();
            for (let i = 0; i < (e.depleted ? 14 : 6); i++) {
                h.particles.spawn({ x: e.x + (Math.random() - 0.5) * 10, y: e.y, z: 6 + Math.random() * 8, vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.5) * 14, vz: 10 + Math.random() * 20, life: 0.8, kind: "debris", col: e.kind === "rock" ? "#6a6372" : "#6a5034", g: 120 });
            }
        }
        else if (e.t === "cue") {
            if (e.cue === "clank")
                h.sfx.clank();
            else if (e.cue === "scrape")
                h.sfx.scrape();
            else if (e.cue === "dud" || e.cue === "runeDud")
                h.sfx.fizzle();
            else if (e.cue === "scrapeDust") {
                h.sfx.scrape();
                for (let i = 0; i < 4; i++)
                    h.particles.spawn({ x: e.x, y: e.y, z: 2, vx: (Math.random() - 0.5) * 20, vz: 8, life: 0.8, kind: "dust", col: "#9a96a0", g: 20 });
            }
            else if (e.cue === "push") {
                h.sfx.thud();
                for (let i = 0; i < 6; i++)
                    h.particles.spawn({ x: e.x + (Math.random() - 0.5) * 16, y: e.y + 2, z: 20 + Math.random() * 10, vx: (Math.random() - 0.5) * 10, life: 1.5, kind: "debris", col: "#6a6372", g: 80 });
            }
        }
    }
    onEvent(h, e) {
        const pl = h.pl;
        const shake = (t, m) => h.cam.shake(t, m, h.screenShakeEnabled());
        switch (e.t) {
            case "itemGained": {
                const n = e.n ?? 1;
                h.setToast({ icon: (0, items_2.itemIcon)(e.item), name: items_1.ITEM_NAMES[e.item] + (n > 1 ? ` x${n}` : ""), t: 0 });
                h.sfx.pickup();
                if (e.stored)
                    for (let i = 0; i < 10; i++) {
                        h.particles.spawn({ x: pl.x, y: pl.y - 4, z: 14, vx: (Math.random() - 0.5) * 30, vy: (Math.random() - 0.5) * 20, vz: 20 + Math.random() * 20, life: 0.6, kind: "glint", col: "#fff0c0", emit: true, g: 40 });
                    }
                const def = items_1.ITEMS[e.item], id = e.item;
                if (def.opensOnPickup)
                    h.later(0.5, () => { if (h.isPlayScreen())
                        def.opens === "book" ? h.openBook(id) : h.openSchematic(); });
                break;
            }
            case "itemDropped":
                h.sfx.thud();
                for (let i = 0; i < 6; i++)
                    h.particles.spawn({ x: e.x + (Math.random() - 0.5) * 8, y: e.y, z: 2, vx: (Math.random() - 0.5) * 14, vz: 8, life: 0.6, kind: "dust", col: "#8a8478", g: 20 });
                if (e.reason !== "drop")
                    h.say(e.reason === "full" ? "PACK FULL - LEFT ON THE GROUND" : "NO ROOM - DROPPED ON THE GROUND");
                break;
            case "packFull":
                h.say("YOUR PACK IS FULL");
                h.sfx.tone(180, 0.1, "square", 0.04);
                h.notifications.push({ simTime: h.world.time, day: h.world.day, level: "warn", category: "storageFull", title: "Pack Full", body: `Could not pick up ${items_1.ITEM_NAMES[e.item]}` });
                break;
            case "message":
                h.say(e.text);
                break;
            case "folkSpoke": {
                const a = (0, world_1.actorById)(h.world, e.folk);
                const label = a?.person ? (0, folk_1.folkLabel)(a) : a?.keeper ? (0, shops_1.keeperLabel)(a) : null;
                if (a && label) {
                    this.bubbles.set(a.id, { text: e.line, t: 0, dur: 2.4 + e.line.length * 0.055 });
                    h.say(label);
                    h.sfx.tone(520, 0.05, "triangle", 0.03);
                }
                break;
            }
            case "folkSay": {
                const a = (0, world_1.actorById)(h.world, e.folk);
                if (!a || a.area !== h.pl.area)
                    break;
                const cur = this.bubbles.get(a.id);
                if (cur?.text && !cur.talk)
                    break;
                const near = Math.hypot(a.x - h.pl.x, a.y - h.pl.y) < FOLK_EARSHOT;
                const partner = e.to ? this.bubbles.get(e.to) : undefined;
                let others = 0;
                for (const [id, b] of this.bubbles)
                    if (b.text && id !== a.id && id !== e.to && b.t < b.dur - 0.3)
                        others++;
                if (!near || (others >= FOLK_MAX_LINES && !partner?.talk && !cur?.talk))
                    break;
                if (partner?.talk && e.to)
                    this.bubbles.delete(e.to);
                this.bubbles.set(a.id, { text: e.line, t: 0, dur: (0, folk_1.sayTime)(e.line), talk: true });
                break;
            }
            case "folkChat": {
                const a = (0, world_1.actorById)(h.world, e.folk);
                if (a && a.area === h.pl.area && !this.bubbles.get(a.id)?.text)
                    this.bubbles.set(a.id, { icon: e.icon, t: 0, dur: 1.5 });
                break;
            }
            case "analyzed":
                if (this.lastAnalyzed.prop !== e.prop || h.t - this.lastAnalyzed.t > 0.2)
                    h.sfx.analyzed();
                this.lastAnalyzed = { prop: e.prop, t: h.t };
                break;
            case "learned": {
                h.sfx.insight();
                h.setEyeBoost(1.5);
                const text = (0, flags_1.learnedText)(e.flag);
                h.say(text);
                h.notifications.push({ simTime: h.world.time, day: h.world.day, level: "info", category: "discovery", title: "Insight Learned", body: text });
                break;
            }
            case "thought":
                h.monologue.push(e.line);
                break;
            case "harvestHit": {
                const tree = e.kind === "tree" || e.kind === "log";
                if (tree)
                    h.sfx.thud();
                else
                    h.sfx.clink();
                shake(e.depleted ? 0.35 : 0.12, e.depleted ? 2 : 1);
                if (e.depleted && !tree)
                    h.sfx.smash();
                const cols = tree ? ["#5b3d24", "#7a5634", "#3e6a30", "#5a8a40"] : ["#8a8392", "#6a6372", "#4b4552"];
                for (let i = 0; i < (e.depleted ? 26 : 10); i++) {
                    h.particles.spawn({ x: e.x + (Math.random() - 0.5) * 12, y: e.y, z: tree && i % 2 ? 20 + Math.random() * 14 : 6 + Math.random() * 6, vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.5) * 20, vz: 10 + Math.random() * 30, life: 1 + Math.random(), kind: "debris", col: cols[(Math.random() * cols.length) | 0], g: tree && i % 2 ? 30 : 120 });
                }
                break;
            }
            case "deconstructed":
                h.sfx.clink();
                h.sfx.noise(0.2, 0.1, "bandpass", 900, 2);
                for (let i = 0; i < 12; i++)
                    h.particles.spawn({ x: e.x + (Math.random() - 0.5) * 10, y: e.y, z: e.kind === "torch" || e.kind === "banner" ? 10 : 4, vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.5) * 16, vz: 10 + Math.random() * 20, life: 0.7, kind: "debris", col: Math.random() < 0.5 ? "#7a5634" : "#6a6372", g: 120 });
                break;
            case "openStation":
                if (e.actor === h.world.playerId && h.isPlayScreen() && (0, crafting_1.isStation)(e.station))
                    h.openCrafting(e.station, e.prop);
                break;
            case "dug": {
                const stone = e.material === "stone";
                if (stone)
                    h.sfx.clink();
                else
                    h.sfx.thud();
                shake(e.opened ? 0.6 : 0.12, e.opened ? 3 : 1);
                const cols = stone ? ["#8a8392", "#6a6372", "#4b4552"] : ["#4e3c2a", "#5a4630", "#3e2e20"];
                for (let i = 0; i < (e.opened ? 32 : 12); i++) {
                    h.particles.spawn({ x: e.x + (Math.random() - 0.5) * 30, y: e.y + (Math.random() - 0.5) * 20, z: 2 + Math.random() * 6, vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.5) * 20, vz: 14 + Math.random() * 30, life: 0.8 + Math.random() * 0.6, kind: "debris", col: cols[(Math.random() * cols.length) | 0], g: 120 });
                }
                if (e.actor !== h.world.playerId)
                    break;
                if (e.opened) {
                    h.sfx.smash();
                    h.say("THE VAULT GIVES WAY. THE OLD STAIR IS OPEN: WALK DOWN INTO IT FROM ITS SOUTH END");
                }
                else if (e.next === "stone")
                    h.say("THE EARTH IS OUT. FALLEN STONE LIES UNDER IT: THAT NEEDS A PICKAXE HEAD");
                break;
            }
            case "openStorage":
                if (e.actor === h.world.playerId && h.isPlayScreen())
                    h.openStorage(e.prop);
                break;
            case "manageActor":
                if (e.actor === h.world.playerId && h.isPlayScreen() && (0, world_1.actorById)(h.world, e.target))
                    h.openManage(e.target);
                break;
            case "coreSlotted": {
                const a = (0, world_1.actorById)(h.world, e.target);
                if (!a)
                    break;
                const L = this.npcLook(h.world, a), name = items_1.ITEM_NAMES[e.item];
                if (e.inserted) {
                    h.sfx.coreIn(e.powered);
                    if (e.powered)
                        L.flare = 1;
                    this.coreSparks(h, a, e.powered ? 6 : 5, e.powered);
                    h.say(e.powered ? `${name} SLOTTED - IT POWERS ON` : `${name} SLOTTED`);
                }
                else {
                    const ran = (0, power_1.coreCheck)(a, e.item).sufficient;
                    h.sfx.coreOut(ran);
                    L.flare = 0;
                    for (let i = 0; i < 6; i++)
                        h.particles.spawn({ x: a.x + (Math.random() - 0.5) * 10, y: a.y, z: 6 + Math.random() * 6, vx: (Math.random() - 0.5) * 14, vz: 4 + Math.random() * 6, life: 0.8, kind: "dust", col: "#8a8478", g: 10 });
                    h.say(ran ? `${name} TAKEN OUT - IT POWERS DOWN` : `${name} TAKEN OUT`);
                }
                break;
            }
            case "built":
                h.sfx.place();
                h.sfx.tone(520, 0.2, "triangle", 0.05);
                for (let i = 0; i < 10; i++)
                    h.particles.spawn({ x: e.x, y: e.y - 14, z: 2, vx: (Math.random() - 0.5) * 30, vz: 10 + Math.random() * 20, life: 0.6, kind: "spark", col: "#ffb040", emit: true, g: 80 });
                break;
            case "runeAwakened":
            case "travelled":
                h.onTravelled();
                break;
            case "step":
                h.sfx.step(e.heavy);
                for (let i = 0; i < (e.heavy ? 4 : 2); i++) {
                    h.particles.spawn({ x: pl.x + (Math.random() - 0.5) * 10, y: pl.y, z: 1, vx: (Math.random() - 0.5) * 16, vy: (Math.random() - 0.5) * 6, vz: 8, life: 0.6, kind: "dust", col: "#8a8478", g: 20 });
                }
                if (!e.heavy && !h.hasArm)
                    h.sfx.scrape();
                break;
            case "taskTick": {
                const a = e.task;
                if (a.kind === "attach") {
                    if (Math.random() < 0.5)
                        h.sparkBurst(2);
                }
                else if (a.kind === "slam") {
                    const k0 = (a.t - e.dt) / a.dur, k1 = a.t / a.dur, down = tasks_1.SLAM_HIT * 0.88;
                    if (k0 <= 0.02 && k1 > 0.02)
                        h.sfx.slamWindup();
                    if (k0 < down && k1 >= down)
                        h.sfx.slamSwing();
                    if (!h.hasArm && k1 < tasks_1.SLAM_HIT && Math.random() < 0.12)
                        h.sparkBurst(1);
                }
                else if (a.kind === "dismantle" && a.target) {
                    if (Math.floor(a.t / 0.3) !== Math.floor((a.t - e.dt) / 0.3))
                        h.sfx.clink();
                    if (Math.random() < 0.3)
                        h.particles.spawn({ x: a.target.x + (Math.random() - 0.5) * 10, y: a.target.y, z: 4 + Math.random() * 8, vx: (Math.random() - 0.5) * 20, vz: 8, life: 0.5, kind: "dust", col: "#8a8478", g: 30 });
                }
                else if (a.kind === "scan" && e.actor === pl.id) {
                    const fire = a.dur * 0.85, k0 = (a.t - e.dt) / fire, k1 = a.t / fire;
                    if (k0 <= 0 && k1 > 0)
                        h.sfx.scanStart();
                    if (k1 < 1 && Math.floor(k1 * 9) !== Math.floor(k0 * 9))
                        h.sfx.scanTick(k1);
                }
                else if (a.kind === "craft") {
                    if (Math.floor(a.t / 0.25) !== Math.floor((a.t - e.dt) / 0.25)) {
                        h.sfx.clink();
                        if (a.target)
                            for (let i = 0; i < 2; i++)
                                h.particles.spawn({ x: a.target.x + (Math.random() - 0.5) * 14, y: a.target.y - 6, z: 8, vx: (Math.random() - 0.5) * 30, vz: 12 + Math.random() * 14, life: 0.4, kind: "spark", col: "#e8d8a0", emit: true, g: 120 });
                    }
                }
                else if (a.kind === "carve") {
                    const c = h.area.ritualPos;
                    const k = Math.floor(a.t / 0.22), kp = Math.floor((a.t - e.dt) / 0.22);
                    if (k !== kp && a.t < a.dur - 0.3) {
                        h.sfx.clink();
                        const ang = 0.26 + Math.random() * 1.05, r = 44 + Math.random() * 13;
                        for (let i = 0; i < 4; i++)
                            h.particles.spawn({ x: c.x + Math.cos(ang) * r, y: c.y + Math.sin(ang) * r, z: 1, vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.5) * 30, vz: 20 + Math.random() * 20, life: 0.4, kind: "spark", col: "#d0c0ff", emit: true, g: 120 });
                        h.particles.spawn({ x: c.x + Math.cos(ang) * r, y: c.y + Math.sin(ang) * r, z: 1, vz: 6, life: 1, kind: "dust", col: "#8a8690", g: 4 });
                    }
                }
                break;
            }
            case "cue":
                if (e.cue === "clank") {
                    h.sfx.clank();
                    shake(0.1, 1);
                }
                else if (e.cue === "scrape")
                    h.sfx.scrape();
                else if (e.cue === "dud") {
                    h.sfx.fizzle();
                    h.setFizz(0.5);
                }
                else if (e.cue === "runeDud")
                    this.runeRefused(h, e.x, e.y);
                else if (e.cue === "scrapeDust") {
                    h.sfx.scrape();
                    for (let i = 0; i < 4; i++)
                        h.particles.spawn({ x: e.x, y: e.y, z: 2, vx: (Math.random() - 0.5) * 20, vz: 8, life: 0.8, kind: "dust", col: "#9a96a0", g: 20 });
                }
                else if (e.cue === "push") {
                    h.sfx.thud();
                    shake(0.2, 1);
                    for (let i = 0; i < 6; i++)
                        h.particles.spawn({ x: e.x + (Math.random() - 0.5) * 16, y: e.y + 2, z: 20 + Math.random() * 10, vx: (Math.random() - 0.5) * 10, life: 1.5, kind: "debris", col: "#6a6372", g: 80 });
                    h.setCrackFlash(1);
                }
                break;
            case "equipped":
                h.sfx.clank();
                shake(0.15, 1);
                h.sparkBurst(14);
                break;
            case "gearOn":
            case "gearOff":
                if (e.actor !== h.world.playerId)
                    break;
                if (items_1.ITEMS[e.item].worn)
                    h.sfx.tone(e.t === "gearOn" ? 700 : 420, 0.14, "triangle", 0.05);
                else if (e.t === "gearOn")
                    h.sfx.strap();
                else
                    h.sfx.unstrap();
                h.say(e.t === "gearOn" ? (e.slot === "back" ? `${items_1.ITEM_NAMES[e.item]} ON YOUR BACK` : `${items_1.ITEM_NAMES[e.item]} EQUIPPED`) : `${items_1.ITEM_NAMES[e.item]} TAKEN OFF`);
                break;
            case "crafted":
                if (e.actor === h.world.playerId) {
                    h.sfx.place();
                    h.say(`MADE ${e.n} ${items_1.ITEM_NAMES[e.item]}`);
                }
                break;
            case "containerOpened":
                h.sfx.open();
                for (let i = 0; i < 8; i++)
                    h.particles.spawn({ x: e.x + (Math.random() - 0.5) * 12, y: e.y, z: 6, vx: (Math.random() - 0.5) * 20, vz: 10, life: 1, kind: "dust", col: "#7a7468", g: 10 });
                break;
            case "doorUnlocked":
                h.sfx.unlock();
                break;
            case "wallBroken": {
                h.sfx.smash();
                shake(0.7, 3.5);
                const cx = e.x, cy = e.y;
                for (let i = 0; i < 40; i++)
                    h.particles.spawn({ x: cx + (Math.random() - 0.5) * 16, y: cy + (Math.random() - 0.5) * 20, z: 4 + Math.random() * 18, vx: (Math.random() - 0.5) * 120, vy: (Math.random() - 0.5) * 60, vz: 20 + Math.random() * 60, life: 1.6 + Math.random(), kind: "debris", col: ["#8a8392", "#6a6372", "#4b4552"][(Math.random() * 3) | 0], g: 160, size: Math.random() < 0.4 ? 2 : 1 });
                for (let i = 0; i < 40; i++)
                    h.particles.spawn({ x: cx + (Math.random() - 0.5) * 24, y: cy + (Math.random() - 0.5) * 24, z: Math.random() * 20, vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.5) * 30, vz: Math.random() * 10, life: 2 + Math.random() * 2, kind: "smoke", col: "#7a7470", g: -2, size: 2 });
                break;
            }
            case "slam": {
                h.sfx.slam();
                shake(0.18, 1.2);
                for (let i = 0; i < 16; i++) {
                    const ang = Math.random() * Math.PI * 2, v = 14 + Math.random() * 24;
                    h.particles.spawn({ x: e.x + Math.cos(ang) * 3, y: e.y + Math.sin(ang) * 2, z: 1, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v * 0.5, vz: 6 + Math.random() * 10, life: 0.6 + Math.random() * 0.5, kind: "dust", col: Math.random() < 0.5 ? "#8a8478" : "#a09a8c", g: 20 });
                }
                if (!h.hasArm)
                    h.sparkBurst(5);
                break;
            }
            case "withstood": {
                h.sfx.impact();
                shake(0.3, 2);
                h.setCrackFlash(1);
                if (e.tx !== undefined && e.ty !== undefined)
                    h.setShudder(e.tx, e.ty, 0.45);
                for (let i = 0; i < 14; i++)
                    h.particles.spawn({ x: e.x + (Math.random() - 0.5) * 16, y: e.y + 2, z: 4 + Math.random() * 20, vx: (Math.random() - 0.5) * 60, vy: Math.random() * 24, vz: 10 + Math.random() * 30, life: 0.9 + Math.random() * 0.6, kind: "debris", col: ["#8a8392", "#6a6372", "#4b4552"][(Math.random() * 3) | 0], g: 140 });
                for (let i = 0; i < 16; i++)
                    h.particles.spawn({ x: e.x + (Math.random() - 0.5) * 20, y: e.y + 3, z: Math.random() * 14, vx: (Math.random() - 0.5) * 24, vy: Math.random() * 10, vz: 2 + Math.random() * 6, life: 1 + Math.random(), kind: "dust", col: "#8a8478", g: 6, size: Math.random() < 0.4 ? 2 : 1 });
                break;
            }
            case "corePlaced":
                h.sfx.place();
                h.sfx.tone(660, 1, "sine", 0.06);
                break;
            case "carved":
                h.sfx.tone(392, 1.2, "sine", 0.07);
                break;
            case "glyphPlaced":
                h.sfx.place();
                break;
            case "runeActivated":
                h.sfx.activate();
                shake(1.5, 1.5);
                break;
            case "runeFizzled": {
                h.setFizz(1.2);
                h.sfx.fizzle();
                shake(0.4, 2);
                const c = h.area.ritualPos;
                for (let i = 0; i < 40; i++) {
                    const a = Math.random() * Math.PI * 2, rr = 44 + Math.random() * 13;
                    h.particles.spawn({ x: c.x + Math.cos(a) * rr, y: c.y + Math.sin(a) * rr, z: 1, vx: (Math.random() - 0.5) * 60, vy: (Math.random() - 0.5) * 40, vz: 30 + Math.random() * 30, life: 0.5, kind: "spark", col: Math.random() < 0.5 ? "#ff6a8a" : "#a070ff", emit: true, g: 120 });
                }
                break;
            }
            case "runeDeactivated":
                h.sfx.setHum(0);
                break;
            case "teleport":
                h.onStartTeleport(e.x, e.y, pl.task?.dur ?? 4.6, e.first);
                if (e.first) {
                    (0, monologue_1.playerThinks)(h.world, "cross.engage");
                }
                break;
            case "areaEntered": break;
            case "dayPhase":
                h.onDayPhase(e.phase);
                break;
            case "portal": {
                const dest = h.world.areas.get(e.toArea), out = dest && (0, portals_1.portalById)(dest, e.to);
                h.particles.clear();
                h.onPortal(!!out?.door);
                if (out?.label)
                    h.say(out.label);
                break;
            }
            case "dialogue":
                if (h.isPlayScreen())
                    h.openDialogue(e.npc, e.script, e.segment);
                break;
            case "npcState": {
                const a = (0, dialogue_1.npcActor)(h.world, e.npc);
                if (!a)
                    break;
                const L = this.npcLook(h.world, a);
                if (e.awake) {
                    L.wakeT = 0;
                    h.sfx.wakeSputter();
                    this.npcSparks(h, a, 10);
                    h.later(0.5, () => this.npcSparks(h, a, 6));
                }
                else {
                    L.sleepT = 0;
                    h.sfx.powerDown();
                    h.later(1.1, () => { shake(0.2, 1); this.npcDust(h, a); });
                }
                break;
            }
            case "eyeRepaired":
                h.onEyeRepaired(e.by);
                break;
        }
    }
    onVisionCue(h, c) {
        switch (c.t) {
            case "on":
                h.sfx.visionOn();
                break;
            case "off":
                h.sfx.visionOff();
                break;
            case "ping":
                if (c.n < 10)
                    h.sfx.visionPing(c.category, c.pending, c.n);
                break;
            case "lock": {
                const col = vision_1.VISION_CATEGORIES[c.target.category].color;
                for (let i = 0; i < 18; i++) {
                    const edge = Math.random() < 0.5, px = c.x + (edge ? (Math.random() < 0.5 ? 0 : c.w) : Math.random() * c.w), py = c.y + (edge ? Math.random() * c.h : (Math.random() < 0.5 ? 0 : c.h));
                    const zx = c.target.y - py;
                    h.particles.spawn({ x: px, y: c.target.y, z: zx, vx: (px - (c.x + c.w / 2)) * (1.5 + Math.random() * 2), vz: 6 + Math.random() * 16, life: 0.5 + Math.random() * 0.5, kind: "rune", col: Math.random() < 0.35 ? "#ffffff" : col, emit: true, g: -6 });
                }
                h.setEyeBoost(0.6);
                break;
            }
        }
    }
    updateNpcLooks(h, dt) {
        const area = h.area;
        for (const a of h.world.actors) {
            if (a.area !== area.id || a.id === h.world.playerId)
                continue;
            if (a.kind === "folk") {
                this.updateFolkLook(h, a);
                continue;
            }
            if (a.kind === "keeper")
                continue;
            if (!(0, npcs_1.npcDef)(a.npc)) {
                this.updateWorkerLook(h, a, dt);
                continue;
            }
            if (a.kind !== "npc")
                continue;
            const def = (0, actors_1.actorDef)(a);
            const L = this.npcLook(h.world, a), on = (0, dialogue_1.isAwake)(h.world, a.id);
            L.wakeT += dt;
            L.sleepT += dt;
            const target = on ? (L.wakeT > 0.6 ? 1 : 0) : (L.sleepT > 0.7 ? 0 : 1);
            L.awake += Math.max(-dt / 1.1, Math.min(dt / 1.1, target - L.awake));
            if (on)
                L.eye = L.wakeT < 0.9 ? (Math.random() < 0.45 + L.wakeT * 0.5 ? 1 : 0.12) : 1;
            else
                L.eye = Math.max(0, Math.min(L.eye, 1 - L.sleepT / 1.2));
            if (on && L.wakeT < 0.05)
                L.flare = 0.8;
            L.flare = Math.max(0, L.flare - dt * 1.5);
            L.reach = Math.max(0, L.reach - dt * 0.7);
            const el = def.eyeLight;
            if (el) {
                const lt = h.view.dynamicLight("npc:" + a.id, () => (0, light_1.makeLight)(a.x + el.dx, a.y + el.dy, el.rad, el.col, 0, 0.05, "npc:" + a.id));
                lt.int = L.eye * 0.42 + L.flare * 0.5 + (L.reach > 0.8 ? 0.25 : 0);
            }
        }
    }
    updateWorkerLook(h, a, dt) {
        const L = this.npcLook(h.world, a);
        const inp = { powered: (0, actorStats_1.powered)(a), active: (0, actors_2.actorActive)(a), moving: a.moving, hasCore: !!a.powerCore };
        if (!L.worker || h.t - L.seen > 0.5) {
            L.worker = (0, workerAnim_1.initWorkerAnim)(inp);
            if (!L.arrived)
                L.lift = 0;
        }
        L.seen = h.t;
        L.arrived = false;
        (0, workerAnim_1.stepWorkerAnim)(L.worker, dt, inp);
        for (const cue of (0, workerAnim_1.drainCues)(L.worker))
            this.workerCue(h, a, cue);
        L.flare = Math.max(0, L.flare - dt * 0.8);
        const task = a.task;
        if (task?.kind === "channel" && task.target) {
            const c = task.target, lift = task.dur - 1.0;
            L.lift = Math.min(task.t, lift) * 5.5 + Math.sin(task.t * 3);
            const n = Math.floor(dt * 150 + Math.random());
            for (let i = 0; i < n; i++) {
                const ang = Math.random() * Math.PI * 2, r = 12 + Math.random() * 26;
                h.particles.spawn({ x: c.x + Math.cos(ang) * r, y: c.y + Math.sin(ang) * r, z: 1, vx: -Math.cos(ang) * r * 0.8, vy: -Math.sin(ang) * r * 0.8, vz: 8 + Math.random() * 16, life: 1.0, kind: "rune", col: Math.random() < 0.5 ? "#c0a0ff" : "#80e0ff", emit: true, g: -5 });
            }
            if (task.t - dt <= 0)
                this.runeBlip(h, c.x, c.y, 0.7);
        }
        else
            L.lift = Math.max(0, L.lift - dt * 26);
        const lt = h.view.dynamicLight("npc:" + a.id, () => (0, light_1.makeLight)(a.x, a.y - 9, 38, [1, 0.38, 0.34], 0, 0.07, "npc:" + a.id));
        lt.x = a.x;
        lt.y = a.y - 9 - L.lift;
        if (Math.abs(lt.x - lt.vx) > 2 || Math.abs(lt.y - lt.vy) > 2)
            (0, light_1.computeVis)(lt, h.area);
        lt.int = L.worker.out.core * 0.2 + L.worker.out.eye * 0.1 + (task?.kind === "channel" ? 0.3 : 0);
    }
    updateFolkLook(h, a) {
        if ((0, folk_1.archetypeOf)(a).garb !== "watch")
            return;
        const on = (0, folk_1.folkPresent)(a) && (0, actors_2.folkLantern)(h.world, a);
        const side = a.facing === "left" ? -1 : a.facing === "right" ? 1 : -4 / 3;
        const lx = a.x + side * 4, ly = a.y - 6;
        const lt = h.view.dynamicLight("folk:" + a.id, () => (0, light_1.makeLight)(lx, ly, 70, [1, 0.7, 0.38], 0, 0.14, "folk:" + a.id));
        lt.x = lx;
        lt.y = ly;
        if (on && (Math.abs(lt.x - lt.vx) > 2 || Math.abs(lt.y - lt.vy) > 2))
            (0, light_1.computeVis)(lt, h.area);
        lt.int = on ? 0.62 : 0;
    }
    workerCue(h, a, cue) {
        const near = h.volAt(a.x, a.y) > 0.15;
        const dust = (n) => { for (let i = 0; i < n; i++)
            h.particles.spawn({ x: a.x + (Math.random() - 0.5) * 12, y: a.y + 1, z: 1, vx: (Math.random() - 0.5) * 22, vy: (Math.random() - 0.5) * 8, vz: 6 + Math.random() * 6, life: 0.6, kind: "dust", col: "#8a7a68", g: 20 }); };
        switch (cue) {
            case "spark":
                this.coreSparks(h, a, 9, true);
                if (near)
                    h.sfx.spark();
                break;
            case "creak":
                if (near)
                    h.sfx.scrape();
                break;
            case "lamp":
                this.coreSparks(h, a, 3, true);
                if (near)
                    h.sfx.wakeSputter();
                break;
            case "plant":
                dust(7);
                if (near)
                    h.sfx.thud();
                break;
            case "jolt":
                this.coreSparks(h, a, 8, false);
                dust(3);
                if (near)
                    h.sfx.clank();
                break;
            case "lampOut":
                if (near)
                    h.sfx.tone(420, 0.25, "sine", 0.03, 110);
                break;
            case "settle":
                if (near)
                    h.sfx.tone(190, 0.7, "sine", 0.035, 70);
                break;
        }
    }
    runeBlip(h, x, y, k = 1) {
        const v = h.volAt(x, y) * k;
        if (v > 0.05) {
            h.sfx.tone(520, 0.35, "sine", 0.06 * v, 1040);
            h.sfx.tone(780, 0.5, "triangle", 0.04 * v, undefined, 0.07);
        }
    }
    runeBurst(h, x, y) {
        this.runeBlip(h, x, y);
        for (let i = 0; i < 26; i++) {
            const ang = Math.random() * Math.PI * 2, sp = 14 + Math.random() * 30;
            h.particles.spawn({ x, y, z: 2 + Math.random() * 10, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp * 0.5, vz: 10 + Math.random() * 30, life: 0.7, kind: "rune", col: Math.random() < 0.4 ? "#ffffff" : Math.random() < 0.5 ? "#c0a0ff" : "#80e0ff", emit: true, g: 10 });
        }
    }
    runeRefused(h, x, y) {
        h.sfx.fizzle();
        h.setFizz(0.5);
        h.setRuneDud(x, y);
        h.cam.shake(0.25, 1.2, h.screenShakeEnabled());
        for (let i = 0; i < 18; i++) {
            const a = Math.random() * Math.PI * 2, rr = 44 + Math.random() * 13;
            h.particles.spawn({ x: x + Math.cos(a) * rr, y: y + Math.sin(a) * rr, z: 1, vx: (Math.random() - 0.5) * 60, vy: (Math.random() - 0.5) * 40, vz: 30 + Math.random() * 30, life: 0.5, kind: "spark", col: Math.random() < 0.5 ? "#ff6a8a" : "#a070ff", emit: true, g: 120 });
        }
    }
    workerWalked(h, e) {
        const here = h.pl.area, a = (0, world_1.actorById)(h.world, e.actor);
        const from = e.fromArea === here ? (0, portals_1.portalById)(h.area, e.from) : undefined;
        const out = !from && a && e.toArea === here ? (0, portals_1.portalById)(h.area, e.to) : undefined;
        const at = from ? { x: from.x + from.w / 2, y: from.y + from.h / 2, door: !!from.door } : out && a ? { x: a.x, y: a.y, door: !!out.door } : null;
        if (!at || h.volAt(at.x, at.y) < 0.15)
            return;
        if (at.door)
            h.sfx.open();
        else
            h.sfx.step(true);
    }
    workerTravelled(h, e) {
        const a = (0, world_1.actorById)(h.world, e.actor), pa = h.pl.area;
        const from = runes_1.RUNE_NODES[e.from], p = from && from.area === pa ? h.area.prop(from.prop) : null;
        if (p)
            this.runeBurst(h, p.x, p.y);
        if (a && a.area === pa) {
            const L = this.npcLook(h.world, a);
            L.lift = 13;
            L.arrived = true;
            this.runeBurst(h, a.x, a.y);
        }
    }
    coreSparks(h, a, n, bright) {
        const z = (0, actors_1.actorDef)(a).body.height * 0.55;
        for (let i = 0; i < n; i++) {
            h.particles.spawn({ x: a.x + (Math.random() - 0.5) * 4, y: a.y + 1, z: z + Math.random() * 3, vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.2) * 16, vz: 8 + Math.random() * 24, life: 0.3 + Math.random() * 0.4, kind: "spark", col: bright ? (Math.random() < 0.5 ? "#ff5a70" : "#ffc0c8") : "#8a3040", emit: true, g: 110 });
        }
    }
    npcSparks(h, a, n) {
        for (let i = 0; i < n; i++) {
            h.particles.spawn({ x: a.x + (Math.random() - 0.5) * 16, y: a.y - 2, z: 18 + Math.random() * 14, vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.5) * 20, vz: 10 + Math.random() * 30, life: 0.3 + Math.random() * 0.4, kind: "spark", col: Math.random() < 0.5 ? "#fff2a0" : "#7fe8ff", emit: true, g: 120 });
        }
    }
    npcDust(h, a) {
        for (let i = 0; i < 12; i++) {
            h.particles.spawn({ x: a.x + (Math.random() - 0.5) * 26, y: a.y, z: 2 + Math.random() * 6, vx: (Math.random() - 0.5) * 24, vz: 6 + Math.random() * 8, life: 1, kind: "dust", col: "#8a8478", g: 14 });
        }
    }
}
exports.EventReactor = EventReactor;
