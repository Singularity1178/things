"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InputManager = exports.UI_H = exports.UI_W = exports.UI_SCALE = void 0;
// Input v2 (0.5): unified mouse (hover, click, drag-select, wheel, right-click),
// keyboard (with SettingsStore remapping) and gamepad parity.
const zoom_1 = require("../view/zoom");
exports.UI_SCALE = 2;
exports.UI_W = zoom_1.BASE_W * exports.UI_SCALE; // 640
exports.UI_H = zoom_1.BASE_H * exports.UI_SCALE; // 360
const DRAG_THRESHOLD_PX = 5;
class InputManager {
    constructor(settings) {
        Object.defineProperty(this, "settings", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: settings
        });
        Object.defineProperty(this, "keys", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Set()
        });
        Object.defineProperty(this, "pressed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Set()
        });
        Object.defineProperty(this, "typed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "mouse", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: {
                x: exports.UI_W / 2,
                y: exports.UI_H / 2,
                bx: zoom_1.BASE_W / 2,
                by: zoom_1.BASE_H / 2,
                inside: false,
                leftDown: false,
                rightDown: false,
                leftClick: false,
                rightClick: false,
                leftRelease: false,
                wheelY: 0,
                dragStart: null,
                dragging: false,
                draggedBox: null,
            }
        });
        /** Gamepad axes & previous button state for edge detection. */
        Object.defineProperty(this, "gpAxis", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { ix: 0, iy: 0 }
        });
        Object.defineProperty(this, "gpPrevButtons", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "gpPrevDir", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { u: false, d: false, l: false, r: false }
        });
        /** Raw last key pressed this frame (for keybinding capture in Settings). */
        Object.defineProperty(this, "lastRawKey", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
    }
    keyDown(raw) {
        const k = raw.toLowerCase();
        this.lastRawKey = k;
        if (!this.keys.has(k))
            this.pressed.add(k);
        this.keys.add(k);
        if (raw.length === 1)
            this.typed.push(raw);
        else if (k === "backspace")
            this.typed.push("\b");
    }
    keyUp(raw) {
        this.keys.delete(raw.toLowerCase());
    }
    pointerMove(uiX, uiY) {
        this.mouse.x = Math.max(0, Math.min(exports.UI_W, uiX));
        this.mouse.y = Math.max(0, Math.min(exports.UI_H, uiY));
        this.mouse.bx = this.mouse.x / exports.UI_SCALE;
        this.mouse.by = this.mouse.y / exports.UI_SCALE;
        this.mouse.inside = true;
        if (this.mouse.leftDown && this.mouse.dragStart) {
            const dist = Math.hypot(this.mouse.x - this.mouse.dragStart.x, this.mouse.y - this.mouse.dragStart.y);
            if (dist >= DRAG_THRESHOLD_PX)
                this.mouse.dragging = true;
        }
    }
    pointerDown(uiX, uiY, button) {
        this.pointerMove(uiX, uiY);
        if (button === 0) {
            this.mouse.leftDown = true;
            this.mouse.leftClick = true;
            this.mouse.dragStart = { x: this.mouse.x, y: this.mouse.y };
            this.mouse.dragging = false;
            this.pressed.add("click");
        }
        else if (button === 2) {
            this.mouse.rightDown = true;
            this.mouse.rightClick = true;
            this.pressed.add("rightclick");
        }
    }
    pointerUp(uiX, uiY, button) {
        this.pointerMove(uiX, uiY);
        if (button === 0) {
            if (this.mouse.dragging && this.mouse.dragStart) {
                this.mouse.draggedBox = {
                    x0: Math.min(this.mouse.dragStart.x, this.mouse.x),
                    y0: Math.min(this.mouse.dragStart.y, this.mouse.y),
                    x1: Math.max(this.mouse.dragStart.x, this.mouse.x),
                    y1: Math.max(this.mouse.dragStart.y, this.mouse.y),
                };
            }
            this.mouse.leftDown = false;
            this.mouse.leftRelease = true;
            this.mouse.dragging = false;
            this.mouse.dragStart = null;
        }
        else if (button === 2) {
            this.mouse.rightDown = false;
        }
    }
    wheel(deltaY) {
        this.mouse.wheelY += deltaY;
    }
    /** Poll connected standard gamepad (no-op in headless Node). */
    pollGamepad() {
        this.gpAxis.ix = 0;
        this.gpAxis.iy = 0;
        if (typeof navigator === "undefined" || typeof navigator.getGamepads !== "function")
            return;
        let pads = [];
        try {
            pads = Array.from(navigator.getGamepads() ?? []);
        }
        catch {
            return;
        }
        const gp = pads.find((p) => p && p.connected);
        if (!gp)
            return;
        const dead = 0.28;
        const ax0 = Math.abs(gp.axes[0] ?? 0) > dead ? gp.axes[0] : 0;
        const ax1 = Math.abs(gp.axes[1] ?? 0) > dead ? gp.axes[1] : 0;
        const dLeft = gp.buttons[14]?.pressed || ax0 < -0.5;
        const dRight = gp.buttons[15]?.pressed || ax0 > 0.5;
        const dUp = gp.buttons[12]?.pressed || ax1 < -0.5;
        const dDown = gp.buttons[13]?.pressed || ax1 > 0.5;
        this.gpAxis.ix = ax0 !== 0 ? ax0 : (dRight ? 1 : 0) - (dLeft ? 1 : 0);
        this.gpAxis.iy = ax1 !== 0 ? ax1 : (dDown ? 1 : 0) - (dUp ? 1 : 0);
        // Directional edge triggers for menu navigation
        if (dUp && !this.gpPrevDir.u)
            this.pressed.add("arrowup");
        if (dDown && !this.gpPrevDir.d)
            this.pressed.add("arrowdown");
        if (dLeft && !this.gpPrevDir.l)
            this.pressed.add("arrowleft");
        if (dRight && !this.gpPrevDir.r)
            this.pressed.add("arrowright");
        this.gpPrevDir = { u: !!dUp, d: !!dDown, l: !!dLeft, r: !!dRight };
        // Standard mapping: A(0)->e, B(1)->escape, X(2)->space, Y(3)->i, LB(4)->q, RB(5)->r, Start(9)->escape
        const map = {
            0: "e",
            1: "escape",
            2: " ",
            3: "i",
            4: "q",
            5: "r",
            9: "escape",
        };
        for (const [idxStr, key] of Object.entries(map)) {
            const idx = Number(idxStr);
            const down = !!gp.buttons[idx]?.pressed;
            const prev = !!this.gpPrevButtons[idx];
            if (down && !prev)
                this.pressed.add(key);
            this.gpPrevButtons[idx] = down;
        }
    }
    /** Clear per-frame edges after screen update. */
    endFrame() {
        this.pressed.clear();
        this.typed.length = 0;
        this.lastRawKey = null;
        this.mouse.leftClick = false;
        this.mouse.rightClick = false;
        this.mouse.leftRelease = false;
        this.mouse.wheelY = 0;
        this.mouse.draggedBox = null;
    }
    has(...k) {
        return k.some((x) => this.keys.has(x));
    }
    hit(...k) {
        return k.some((x) => this.pressed.has(x));
    }
    /** Check whether a remapped logical action is currently held. */
    actionDown(act) {
        const keys = this.settings.data.keybinds[act];
        return keys.some((k) => this.keys.has(k));
    }
    /** Check whether a remapped logical action was triggered this frame. */
    actionHit(act) {
        const keys = this.settings.data.keybinds[act];
        return keys.some((k) => this.pressed.has(k));
    }
    /** Convert 2x UI coordinates to world coordinates given camera and view size. */
    toWorld(uiX, uiY, cam, vw, vh) {
        return {
            x: cam.x + (uiX / exports.UI_W) * vw,
            y: cam.y + (uiY / exports.UI_H) * vh,
        };
    }
    /** Current drag rectangle in 2x UI coordinates (if actively dragging). */
    currentDragRect() {
        if (!this.mouse.dragging || !this.mouse.dragStart)
            return null;
        return {
            x0: Math.min(this.mouse.dragStart.x, this.mouse.x),
            y0: Math.min(this.mouse.dragStart.y, this.mouse.y),
            x1: Math.max(this.mouse.dragStart.x, this.mouse.x),
            y1: Math.max(this.mouse.dragStart.y, this.mouse.y),
        };
    }
}
exports.InputManager = InputManager;
