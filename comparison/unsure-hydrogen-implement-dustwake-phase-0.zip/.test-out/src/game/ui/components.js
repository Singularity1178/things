"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UiContextMenu = exports.UiModal = exports.UiSlider = exports.UiTable = exports.UiScrollList = exports.UiTabs = exports.HitRegistry = exports.inRect = void 0;
exports.drawPanel2x = drawPanel2x;
exports.drawButton2x = drawButton2x;
exports.drawTooltip = drawTooltip;
exports.drawToggle2x = drawToggle2x;
exports.drawGraph2x = drawGraph2x;
// Reusable UI v2 components (0.5) rendered on the 2x UI layer (640x360) with
// the mixed-case proportional font, mouse interaction (hover, click, drag,
// wheel, right-click context), tooltips, and keyboard/gamepad parity.
const kit_1 = require("./kit");
const input_1 = require("./input");
const propFont_1 = require("./propFont");
const inRect = (mx, my, r) => mx >= r.x && mx < r.x + r.w && my >= r.y && my < r.y + r.h;
exports.inRect = inRect;
/** Per-frame hit & tooltip tracker for UI v2 elements. */
class HitRegistry {
    constructor() {
        Object.defineProperty(this, "hits", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "hoveredId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "tooltip", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
    }
    begin() {
        this.hits = [];
        this.hoveredId = null;
        this.tooltip = null;
    }
    add(id, rect, opts) {
        this.hits.push({ id, rect, tooltip: opts?.tooltip, onClick: opts?.onClick });
    }
    resolve(input) {
        const { x, y, inside, leftClick } = input.mouse;
        if (!inside)
            return false;
        // Topmost (last registered) wins
        for (let i = this.hits.length - 1; i >= 0; i--) {
            const h = this.hits[i];
            if ((0, exports.inRect)(x, y, h.rect)) {
                this.hoveredId = h.id;
                if (h.tooltip) {
                    this.tooltip = { x, y, title: h.tooltip };
                }
                if (leftClick && h.onClick) {
                    h.onClick();
                    return true;
                }
                return false;
            }
        }
        return false;
    }
}
exports.HitRegistry = HitRegistry;
/** Crisp 2x bevelled panel. */
function drawPanel2x(ctx, x, y, w, h, fill = "#141117", edge = "#4e4856", hi = "#6a6372") {
    ctx.fillStyle = "#08070a";
    ctx.fillRect(x - 1, y - 1, w + 2, h + 2);
    ctx.fillStyle = edge;
    ctx.fillRect(x, y, w, h);
    ctx.fillStyle = hi;
    ctx.fillRect(x, y, w, 1);
    ctx.fillRect(x, y, 1, h);
    ctx.fillStyle = fill;
    ctx.fillRect(x + 2, y + 2, w - 4, h - 4);
}
/** Draw a clickable 2x button with hover & focus states. */
function drawButton2x(ctx, x, y, w, h, label, opts = {}) {
    const fill = opts.active ? "#2a2434" : opts.hovered ? "#221e2a" : "#18151d";
    const edge = opts.focused ? "#c8b88a" : opts.hovered ? "#8a8098" : "#3e3848";
    drawPanel2x(ctx, x, y, w, h, fill, edge, opts.focused ? "#e8d8a8" : "#5a5464");
    const col = opts.disabled ? kit_1.UI.dim : opts.color ?? (opts.active || opts.hovered ? kit_1.UI.title : kit_1.UI.text);
    const clipped = (0, propFont_1.clipPropText)(label, w - 8);
    (0, propFont_1.drawPropTextS)(ctx, clipped, Math.round(x + w / 2), Math.round(y + (h - 7) / 2), col, 1, "center");
}
/** Draw a clamped floating tooltip near `(spec.x, spec.y)` in 2x UI space. */
function drawTooltip(ctx, spec) {
    const pad = 6;
    const maxW = 190;
    const titleLines = (0, propFont_1.wrapPropText)(spec.title, maxW - pad * 2);
    const bodyLines = spec.body ? (0, propFont_1.wrapPropText)(spec.body, maxW - pad * 2) : [];
    const all = [...titleLines, ...bodyLines];
    const contentW = all.reduce((m, l) => Math.max(m, (0, propFont_1.propTextWidth)(l)), 24);
    const w = Math.min(maxW, contentW + pad * 2);
    const h = all.length * propFont_1.PROP_LINE_HEIGHT + pad * 2 - 2;
    let x = spec.x + 10;
    let y = spec.y + 12;
    if (x + w > input_1.UI_W - 4)
        x = spec.x - w - 6;
    if (y + h > input_1.UI_H - 4)
        y = spec.y - h - 6;
    x = Math.max(4, Math.min(input_1.UI_W - w - 4, x));
    y = Math.max(4, Math.min(input_1.UI_H - h - 4, y));
    drawPanel2x(ctx, x, y, w, h, "#100e14", "#7a7088", "#9a90aa");
    let cy = y + pad;
    for (let i = 0; i < titleLines.length; i++) {
        (0, propFont_1.drawPropTextS)(ctx, titleLines[i], x + pad, cy, kit_1.UI.title);
        cy += propFont_1.PROP_LINE_HEIGHT;
    }
    for (let i = 0; i < bodyLines.length; i++) {
        (0, propFont_1.drawPropText)(ctx, bodyLines[i], x + pad, cy, kit_1.UI.mid);
        cy += propFont_1.PROP_LINE_HEIGHT;
    }
}
class UiTabs {
    constructor(items) {
        Object.defineProperty(this, "items", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: items
        });
        Object.defineProperty(this, "index", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
    }
    handleInput(input, x, y, tabW, h, gap = 4) {
        let changed = false;
        if (input.hit("q")) {
            this.index = (this.index + this.items.length - 1) % this.items.length;
            changed = true;
        }
        else if (input.hit("r")) {
            this.index = (this.index + 1) % this.items.length;
            changed = true;
        }
        for (let i = 0; i < this.items.length; i++) {
            if (input.hit(String(i + 1))) {
                this.index = i;
                changed = true;
            }
            if (input.mouse.leftClick && (0, exports.inRect)(input.mouse.x, input.mouse.y, { x: x + i * (tabW + gap), y, w: tabW, h })) {
                this.index = i;
                changed = true;
            }
        }
        return changed;
    }
    draw(ctx, input, x, y, tabW, h, gap = 4) {
        this.items.forEach((item, i) => {
            const rx = x + i * (tabW + gap);
            const hovered = input.mouse.inside && (0, exports.inRect)(input.mouse.x, input.mouse.y, { x: rx, y, w: tabW, h });
            const active = i === this.index;
            drawButton2x(ctx, rx, y, tabW, h, item.label, { active, hovered, focused: active });
        });
    }
}
exports.UiTabs = UiTabs;
// ------------------------------------------------------------------ UiScrollList
class UiScrollList {
    constructor(rowHeight = 16) {
        Object.defineProperty(this, "rowHeight", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: rowHeight
        });
        Object.defineProperty(this, "selected", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "scroll", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "hovered", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: -1
        });
    }
    visibleCount(h) {
        return Math.max(1, Math.floor(h / this.rowHeight));
    }
    clamp(count, h) {
        if (count <= 0) {
            this.selected = 0;
            this.scroll = 0;
            return;
        }
        this.selected = Math.max(0, Math.min(count - 1, this.selected));
        const vis = this.visibleCount(h);
        const maxScroll = Math.max(0, count - vis);
        if (this.selected < this.scroll)
            this.scroll = this.selected;
        if (this.selected >= this.scroll + vis)
            this.scroll = this.selected - vis + 1;
        this.scroll = Math.max(0, Math.min(maxScroll, this.scroll));
    }
    handleInput(input, rect, count, keyboardActive = true) {
        let changed = false;
        let activated = false;
        this.clamp(count, rect.h);
        const vis = this.visibleCount(rect.h);
        const maxScroll = Math.max(0, count - vis);
        if (input.mouse.inside && (0, exports.inRect)(input.mouse.x, input.mouse.y, rect)) {
            const relY = input.mouse.y - rect.y;
            const idx = this.scroll + Math.floor(relY / this.rowHeight);
            this.hovered = idx >= 0 && idx < count ? idx : -1;
            if (input.mouse.wheelY !== 0) {
                const dir = input.mouse.wheelY > 0 ? 1 : -1;
                this.scroll = Math.max(0, Math.min(maxScroll, this.scroll + dir));
            }
            if (input.mouse.leftClick && this.hovered >= 0) {
                if (this.selected === this.hovered)
                    activated = true;
                this.selected = this.hovered;
                changed = true;
            }
        }
        else {
            this.hovered = -1;
        }
        if (keyboardActive && count > 0) {
            if (input.hit("arrowup", "w")) {
                this.selected = Math.max(0, this.selected - 1);
                changed = true;
            }
            else if (input.hit("arrowdown", "s")) {
                this.selected = Math.min(count - 1, this.selected + 1);
                changed = true;
            }
            else if (input.hit("e", "enter")) {
                activated = true;
            }
        }
        this.clamp(count, rect.h);
        return { activated, changed };
    }
    draw(ctx, rect, items, renderRow) {
        drawPanel2x(ctx, rect.x, rect.y, rect.w, rect.h, "#100e14", "#36313e", "#484252");
        const vis = this.visibleCount(rect.h);
        const hasBar = items.length > vis;
        const innerW = rect.w - 6 - (hasBar ? 7 : 0);
        for (let i = 0; i < vis; i++) {
            const idx = this.scroll + i;
            if (idx >= items.length)
                break;
            const rr = { x: rect.x + 3, y: rect.y + 2 + i * this.rowHeight, w: innerW, h: this.rowHeight - 1 };
            const selected = idx === this.selected;
            const hovered = idx === this.hovered;
            if (selected || hovered) {
                ctx.fillStyle = selected ? "#282234" : "#1c1824";
                ctx.fillRect(rr.x, rr.y, rr.w, rr.h);
                if (selected) {
                    ctx.fillStyle = "#c8b88a";
                    ctx.fillRect(rr.x, rr.y, 2, rr.h);
                }
            }
            renderRow(ctx, items[idx], idx, rr, { selected, hovered });
        }
        if (hasBar) {
            const bx = rect.x + rect.w - 7;
            const by = rect.y + 3;
            const bh = rect.h - 6;
            ctx.fillStyle = "#1b1822";
            ctx.fillRect(bx, by, 4, bh);
            const thumbH = Math.max(10, Math.round((vis / items.length) * bh));
            const maxScroll = Math.max(1, items.length - vis);
            const thumbY = by + Math.round((this.scroll / maxScroll) * (bh - thumbH));
            ctx.fillStyle = "#6a6372";
            ctx.fillRect(bx, thumbY, 4, thumbH);
        }
    }
}
exports.UiScrollList = UiScrollList;
class UiTable {
    constructor() {
        Object.defineProperty(this, "list", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new UiScrollList(15)
        });
        Object.defineProperty(this, "sortKey", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "sortAsc", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
    }
    sortRows(rows, cols) {
        const out = [...rows];
        if (!this.sortKey)
            return out;
        const col = cols.find((c) => c.key === this.sortKey);
        if (!col)
            return out;
        const dir = this.sortAsc ? 1 : -1;
        out.sort((a, b) => {
            const av = col.sortValue ? col.sortValue(a) : col.value(a);
            const bv = col.sortValue ? col.sortValue(b) : col.value(b);
            if (av < bv)
                return -dir;
            if (av > bv)
                return dir;
            return 0;
        });
        return out;
    }
    handleInput(input, rect, rows, cols, keyboardActive = true) {
        const headerH = 16;
        if (input.mouse.leftClick && (0, exports.inRect)(input.mouse.x, input.mouse.y, { x: rect.x, y: rect.y, w: rect.w, h: headerH })) {
            let cx = rect.x + 4;
            for (const col of cols) {
                if (input.mouse.x >= cx && input.mouse.x < cx + col.w) {
                    if (this.sortKey === col.key)
                        this.sortAsc = !this.sortAsc;
                    else {
                        this.sortKey = col.key;
                        this.sortAsc = true;
                    }
                    break;
                }
                cx += col.w;
            }
        }
        return this.list.handleInput(input, { x: rect.x, y: rect.y + headerH, w: rect.w, h: rect.h - headerH }, rows.length, keyboardActive);
    }
    draw(ctx, rect, rows, cols) {
        const headerH = 16;
        drawPanel2x(ctx, rect.x, rect.y, rect.w, headerH, "#1c1824", "#403a4a", "#5a5268");
        let cx = rect.x + 5;
        for (const col of cols) {
            const arrow = this.sortKey === col.key ? (this.sortAsc ? " ^" : " v") : "";
            const txt = (0, propFont_1.clipPropText)(col.label + arrow, col.w - 6);
            const tx = col.align === "right" ? cx + col.w - 6 : cx;
            (0, propFont_1.drawPropTextS)(ctx, txt, tx, rect.y + 5, kit_1.UI.title, 1, col.align ?? "left");
            cx += col.w;
        }
        const bodyRect = { x: rect.x, y: rect.y + headerH, w: rect.w, h: rect.h - headerH };
        this.list.draw(ctx, bodyRect, rows, (c, row, _i, rr, st) => {
            let rx = rr.x + 4;
            for (const col of cols) {
                const txt = (0, propFont_1.clipPropText)(col.value(row), col.w - 6);
                const tx = col.align === "right" ? rx + col.w - 6 : rx;
                (0, propFont_1.drawPropText)(c, txt, tx, rr.y + 4, st.selected ? kit_1.UI.title : kit_1.UI.text, 1, col.align ?? "left");
                rx += col.w;
            }
        });
    }
}
exports.UiTable = UiTable;
// ------------------------------------------------------------------ UiSlider
class UiSlider {
    constructor() {
        Object.defineProperty(this, "dragging", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
    }
    handleInput(input, trackRect, value, min, max, step, focused) {
        const { x, y, leftDown, leftClick, leftRelease } = input.mouse;
        if (leftClick && (0, exports.inRect)(x, y, { x: trackRect.x - 4, y: trackRect.y - 4, w: trackRect.w + 8, h: trackRect.h + 8 })) {
            this.dragging = true;
        }
        if (leftRelease || !leftDown)
            this.dragging = false;
        if (this.dragging) {
            const frac = Math.max(0, Math.min(1, (x - trackRect.x) / Math.max(1, trackRect.w)));
            const raw = min + frac * (max - min);
            return Math.max(min, Math.min(max, Math.round(raw / step) * step));
        }
        if (focused) {
            if (input.hit("arrowleft", "a"))
                return Math.max(min, value - step);
            if (input.hit("arrowright", "d"))
                return Math.min(max, value + step);
        }
        return null;
    }
    draw(ctx, trackRect, value, min, max, focused, accent = "#7fe8ff") {
        const frac = Math.max(0, Math.min(1, (value - min) / Math.max(1e-6, max - min)));
        const midY = trackRect.y + Math.floor(trackRect.h / 2) - 2;
        ctx.fillStyle = "#18151f";
        ctx.fillRect(trackRect.x, midY, trackRect.w, 4);
        ctx.fillStyle = accent;
        ctx.fillRect(trackRect.x, midY, Math.round(trackRect.w * frac), 4);
        const kx = trackRect.x + Math.round(trackRect.w * frac) - 3;
        ctx.fillStyle = focused ? "#e8d8a8" : "#d8d0b8";
        ctx.fillRect(kx, midY - 3, 6, 10);
    }
}
exports.UiSlider = UiSlider;
// ------------------------------------------------------------------ UiToggle
function drawToggle2x(ctx, x, y, on, hovered, focused, onColor = "#7ae08a") {
    const w = 26, h = 12;
    drawPanel2x(ctx, x, y, w, h, on ? "#1d2c22" : "#1a1720", focused ? "#e8d8a8" : hovered ? "#8a8098" : "#403a4a");
    ctx.fillStyle = on ? onColor : "#6a6372";
    ctx.fillRect(on ? x + 14 : x + 3, y + 3, 9, 6);
}
function drawGraph2x(ctx, rect, series, opts = {}) {
    drawPanel2x(ctx, rect.x, rect.y, rect.w, rect.h, "#0d0b10", "#3a3544", "#504a5c");
    const padL = 8, padR = 8, padT = opts.title ? 16 : 6, padB = 14;
    if (opts.title)
        (0, propFont_1.drawPropTextS)(ctx, opts.title, rect.x + 6, rect.y + 5, kit_1.UI.title);
    const gx = rect.x + padL, gy = rect.y + padT;
    const gw = Math.max(10, rect.w - padL - padR);
    const gh = Math.max(10, rect.h - padT - padB);
    let lo = opts.min ?? Infinity;
    let hi = opts.max ?? -Infinity;
    for (const s of series)
        for (const v of s.values) {
            if (opts.min === undefined && v < lo)
                lo = v;
            if (opts.max === undefined && v > hi)
                hi = v;
        }
    if (!Number.isFinite(lo))
        lo = 0;
    if (!Number.isFinite(hi) || hi <= lo)
        hi = lo + 1;
    // Gridlines
    ctx.fillStyle = "#201c28";
    for (let i = 0; i <= 2; i++) {
        const yy = gy + Math.round((gh * i) / 2);
        ctx.fillRect(gx, yy, gw, 1);
    }
    // Plot samples as connected pixel segments / bars
    for (const s of series) {
        const n = s.values.length;
        if (!n)
            continue;
        ctx.fillStyle = s.color;
        let prevPx = -1, prevPy = -1;
        for (let i = 0; i < n; i++) {
            const px = gx + Math.round((i / Math.max(1, n - 1)) * (gw - 2));
            const frac = Math.max(0, Math.min(1, (s.values[i] - lo) / (hi - lo)));
            const py = gy + gh - 1 - Math.round(frac * (gh - 2));
            if (prevPx >= 0) {
                const steps = Math.max(1, Math.abs(px - prevPx), Math.abs(py - prevPy));
                for (let k = 0; k <= steps; k++) {
                    const ix = Math.round(prevPx + ((px - prevPx) * k) / steps);
                    const iy = Math.round(prevPy + ((py - prevPy) * k) / steps);
                    ctx.fillRect(ix, iy, 2, 2);
                }
            }
            else {
                ctx.fillRect(px, py, 2, 2);
            }
            prevPx = px;
            prevPy = py;
        }
    }
    // Legend + bounds
    const unit = opts.unit ?? "";
    (0, propFont_1.drawPropText)(ctx, `${hi.toFixed(1)}${unit}`, gx, gy + 2, kit_1.UI.dim);
    let lx = gx + gw;
    for (let i = series.length - 1; i >= 0; i--) {
        const s = series[i];
        const w = (0, propFont_1.propTextWidth)(s.label);
        lx -= w;
        (0, propFont_1.drawPropText)(ctx, s.label, lx, gy + gh + 3, s.color);
        lx -= 8;
    }
}
class UiModal {
    constructor() {
        Object.defineProperty(this, "focusBtn", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "open", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "title", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: ""
        });
        Object.defineProperty(this, "body", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: ""
        });
        Object.defineProperty(this, "buttons", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
    }
    show(title, body, buttons) {
        this.open = true;
        this.title = title;
        this.body = body;
        this.buttons = buttons;
        this.focusBtn = 0;
    }
    close() {
        this.open = false;
    }
    handleInput(input) {
        if (!this.open)
            return false;
        const w = 280, h = 120;
        const x = Math.round((input_1.UI_W - w) / 2), y = Math.round((input_1.UI_H - h) / 2);
        if (input.hit("escape")) {
            this.close();
            return true;
        }
        if (input.hit("arrowleft", "a")) {
            this.focusBtn = (this.focusBtn + this.buttons.length - 1) % Math.max(1, this.buttons.length);
        }
        if (input.hit("arrowright", "d")) {
            this.focusBtn = (this.focusBtn + 1) % Math.max(1, this.buttons.length);
        }
        if (input.hit("e", "enter", " ") && this.buttons[this.focusBtn]) {
            this.buttons[this.focusBtn].onClick();
            return true;
        }
        if (input.mouse.leftClick) {
            // Close [X]
            if ((0, exports.inRect)(input.mouse.x, input.mouse.y, { x: x + w - 20, y: y + 4, w: 16, h: 14 })) {
                this.close();
                return true;
            }
            // Buttons
            const bw = 76, bh = 18, gap = 8;
            const total = this.buttons.length * bw + Math.max(0, this.buttons.length - 1) * gap;
            let bx = Math.round(x + (w - total) / 2);
            const by = y + h - 26;
            for (const b of this.buttons) {
                if ((0, exports.inRect)(input.mouse.x, input.mouse.y, { x: bx, y: by, w: bw, h: bh })) {
                    b.onClick();
                    return true;
                }
                bx += bw + gap;
            }
            if (!(0, exports.inRect)(input.mouse.x, input.mouse.y, { x, y, w, h })) {
                this.close();
            }
        }
        return true;
    }
    draw(ctx, input) {
        if (!this.open)
            return;
        ctx.fillStyle = "rgba(0,0,0,0.6)";
        ctx.fillRect(0, 0, input_1.UI_W, input_1.UI_H);
        const w = 280, h = 120;
        const x = Math.round((input_1.UI_W - w) / 2), y = Math.round((input_1.UI_H - h) / 2);
        drawPanel2x(ctx, x, y, w, h, "#16131b", "#6e657d", "#9a90aa");
        (0, propFont_1.drawPropTextS)(ctx, this.title, x + 10, y + 7, kit_1.UI.title);
        drawButton2x(ctx, x + w - 20, y + 4, 16, 14, "X", {
            hovered: input.mouse.inside && (0, exports.inRect)(input.mouse.x, input.mouse.y, { x: x + w - 20, y: y + 4, w: 16, h: 14 }),
        });
        const lines = (0, propFont_1.wrapPropText)(this.body, w - 20);
        lines.forEach((l, i) => (0, propFont_1.drawPropText)(ctx, l, x + 10, y + 26 + i * propFont_1.PROP_LINE_HEIGHT, kit_1.UI.text));
        const bw = 76, bh = 18, gap = 8;
        const total = this.buttons.length * bw + Math.max(0, this.buttons.length - 1) * gap;
        let bx = Math.round(x + (w - total) / 2);
        const by = y + h - 26;
        this.buttons.forEach((b, i) => {
            const hovered = input.mouse.inside && (0, exports.inRect)(input.mouse.x, input.mouse.y, { x: bx, y: by, w: bw, h: bh });
            drawButton2x(ctx, bx, by, bw, bh, b.label, { hovered, focused: i === this.focusBtn, color: b.color });
            bx += bw + gap;
        });
    }
}
exports.UiModal = UiModal;
class UiContextMenu {
    constructor() {
        Object.defineProperty(this, "open", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "x", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "y", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "items", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "cursor", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
    }
    show(x, y, items) {
        if (!items.length)
            return;
        this.open = true;
        this.items = items;
        this.cursor = 0;
        const w = this.width();
        const h = this.height();
        this.x = Math.max(4, Math.min(input_1.UI_W - w - 4, Math.round(x)));
        this.y = Math.max(4, Math.min(input_1.UI_H - h - 4, Math.round(y)));
    }
    close() {
        this.open = false;
        this.items = [];
    }
    width() {
        let m = 72;
        for (const it of this.items)
            m = Math.max(m, (0, propFont_1.propTextWidth)(it.label) + 18);
        return Math.min(180, m);
    }
    height() {
        return this.items.length * 16 + 6;
    }
    handleInput(input) {
        if (!this.open)
            return false;
        const w = this.width(), h = this.height();
        if (input.hit("escape")) {
            this.close();
            return true;
        }
        if (input.hit("arrowup", "w")) {
            this.cursor = (this.cursor + this.items.length - 1) % this.items.length;
            return true;
        }
        if (input.hit("arrowdown", "s")) {
            this.cursor = (this.cursor + 1) % this.items.length;
            return true;
        }
        if (input.hit("e", "enter", " ")) {
            const it = this.items[this.cursor];
            if (it && !it.disabled) {
                it.onSelect();
                this.close();
            }
            return true;
        }
        if (input.mouse.inside && (0, exports.inRect)(input.mouse.x, input.mouse.y, { x: this.x, y: this.y, w, h })) {
            const idx = Math.floor((input.mouse.y - this.y - 3) / 16);
            if (idx >= 0 && idx < this.items.length)
                this.cursor = idx;
            if (input.mouse.leftClick) {
                const it = this.items[idx];
                if (it && !it.disabled) {
                    it.onSelect();
                    this.close();
                }
                return true;
            }
        }
        else if (input.mouse.leftClick || input.mouse.rightClick) {
            this.close();
            return true;
        }
        return false;
    }
    draw(ctx) {
        if (!this.open)
            return;
        const w = this.width(), h = this.height();
        drawPanel2x(ctx, this.x, this.y, w, h, "#141118", "#6e657d", "#9a90aa");
        this.items.forEach((it, i) => {
            const ry = this.y + 3 + i * 16;
            const sel = i === this.cursor;
            if (sel) {
                ctx.fillStyle = "#282234";
                ctx.fillRect(this.x + 3, ry, w - 6, 15);
            }
            (0, propFont_1.drawPropTextS)(ctx, it.label, this.x + 8, ry + 4, it.disabled ? kit_1.UI.dim : sel ? kit_1.UI.title : kit_1.UI.text);
        });
    }
}
exports.UiContextMenu = UiContextMenu;
