"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationFeed = void 0;
// Notification feed (0.5): alerts, warnings, discoveries, and pause-on-alert options.
// Pure state + 2x UI renderer.
const kit_1 = require("./kit");
const palettes_1 = require("./palettes");
const components_1 = require("./components");
const propFont_1 = require("./propFont");
const MAX_HISTORY = 50;
const TOAST_TTL = 6.5;
class NotificationFeed {
    constructor(settings) {
        Object.defineProperty(this, "settings", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: settings
        });
        Object.defineProperty(this, "items", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "drawerOpen", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "seq", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
    }
    clear() {
        this.items = [];
    }
    unreadCount() {
        let n = 0;
        for (const it of this.items)
            if (!it.read)
                n++;
        return n;
    }
    /**
     * Push a notification. Returns true if settings dictate the simulation should pause
     * on this alert.
     */
    push(opts) {
        const item = {
            id: this.seq++,
            simTime: opts.simTime,
            day: opts.day,
            level: opts.level,
            category: opts.category,
            title: opts.title,
            body: opts.body,
            area: opts.area,
            x: opts.x,
            y: opts.y,
            actorId: opts.actorId,
            read: false,
            ttl: TOAST_TTL,
        };
        this.items.unshift(item);
        if (this.items.length > MAX_HISTORY)
            this.items.length = MAX_HISTORY;
        const s = this.settings.data;
        if (opts.level === "alert" && s.pauseOnAlert)
            return true;
        if (opts.category === "workerBlocked" && s.pauseWorkerBlocked)
            return true;
        if (opts.category === "noPower" && s.pauseNoPower)
            return true;
        if (opts.category === "storageFull" && s.pauseStorageFull)
            return true;
        return false;
    }
    markAllRead() {
        for (const it of this.items)
            it.read = true;
    }
    dismiss(id) {
        this.items = this.items.filter((x) => x.id !== id);
    }
    update(dt) {
        for (const it of this.items) {
            if (it.ttl > 0)
                it.ttl = Math.max(0, it.ttl - dt);
        }
    }
    toggleDrawer() {
        this.drawerOpen = !this.drawerOpen;
        if (this.drawerOpen)
            this.markAllRead();
    }
    /**
     * Render compact top-left notification badge + active toasts (or expanded history drawer)
     * on the 2x UI canvas.
     */
    draw(ctx, input, hits, onFocus) {
        const pal = palettes_1.PALETTES[this.settings.data.palette];
        const colOf = (lvl) => (lvl === "alert" ? pal.alert : lvl === "warn" ? pal.warn : pal.info);
        const unread = this.unreadCount();
        // Top-left Alerts toggle button
        const bx = 6, by = 6, bw = 72, bh = 16;
        const hovered = input.mouse.inside && (0, components_1.inRect)(input.mouse.x, input.mouse.y, { x: bx, y: by, w: bw, h: bh });
        const label = unread > 0 ? `Alerts (${unread})` : `Alerts (${this.items.length})`;
        (0, components_1.drawButton2x)(ctx, bx, by, bw, bh, label, {
            hovered,
            active: this.drawerOpen,
            color: unread > 0 ? pal.warn : kit_1.UI.text,
        });
        hits.add("alerts.toggle", { x: bx, y: by, w: bw, h: bh }, {
            tooltip: "Toggle Notification Feed (N)",
            onClick: () => this.toggleDrawer(),
        });
        if (this.drawerOpen) {
            const dx = 6, dy = 26, dw = 236, dh = 190;
            (0, components_1.drawPanel2x)(ctx, dx, dy, dw, dh, "#121017", "#4e4856", "#6a6372");
            (0, propFont_1.drawPropTextS)(ctx, "Notification Feed", dx + 8, dy + 6, kit_1.UI.title);
            const clrRect = { x: dx + dw - 52, y: dy + 4, w: 46, h: 13 };
            (0, components_1.drawButton2x)(ctx, clrRect.x, clrRect.y, clrRect.w, clrRect.h, "Clear", {
                hovered: input.mouse.inside && (0, components_1.inRect)(input.mouse.x, input.mouse.y, clrRect),
            });
            hits.add("alerts.clear", clrRect, {
                tooltip: "Clear all notifications",
                onClick: () => this.clear(),
            });
            const shown = this.items.slice(0, 8);
            if (!shown.length) {
                (0, propFont_1.drawPropText)(ctx, "No notifications yet.", dx + 10, dy + 28, kit_1.UI.dim);
            }
            else {
                shown.forEach((it, idx) => {
                    const ry = dy + 22 + idx * 20;
                    const rowRect = { x: dx + 5, y: ry, w: dw - 10, h: 18 };
                    const hov = input.mouse.inside && (0, components_1.inRect)(input.mouse.x, input.mouse.y, rowRect);
                    ctx.fillStyle = hov ? "#221e2b" : "#18151f";
                    ctx.fillRect(rowRect.x, rowRect.y, rowRect.w, rowRect.h);
                    ctx.fillStyle = colOf(it.level);
                    ctx.fillRect(rowRect.x, rowRect.y, 3, rowRect.h);
                    const dayNum = Math.floor(it.day) + 1;
                    (0, propFont_1.drawPropTextS)(ctx, (0, propFont_1.clipPropText)(it.title, dw - 58), rowRect.x + 7, ry + 2, kit_1.UI.text);
                    (0, propFont_1.drawPropText)(ctx, `D${dayNum}`, rowRect.x + rowRect.w - 22, ry + 2, kit_1.UI.dim);
                    if (it.body) {
                        (0, propFont_1.drawPropText)(ctx, (0, propFont_1.clipPropText)(it.body, dw - 24), rowRect.x + 7, ry + 10, kit_1.UI.mid);
                    }
                    hits.add(`alerts.item.${it.id}`, rowRect, {
                        tooltip: it.body ? `${it.title}: ${it.body}` : it.title,
                        onClick: () => {
                            it.read = true;
                            onFocus?.(it);
                        },
                    });
                });
            }
            return;
        }
        // Compact live toast stack (up to 3 fading items)
        const active = this.items.filter((it) => it.ttl > 0).slice(0, 3);
        active.forEach((it, i) => {
            const ty = 26 + i * 22;
            const tw = 200, th = 19;
            const rect = { x: 6, y: ty, w: tw, h: th };
            const alpha = Math.min(1, it.ttl / 0.8);
            ctx.globalAlpha = alpha;
            (0, components_1.drawPanel2x)(ctx, rect.x, rect.y, rect.w, rect.h, "#121017", colOf(it.level));
            ctx.fillStyle = colOf(it.level);
            ctx.fillRect(rect.x + 2, rect.y + 2, 3, rect.h - 4);
            (0, propFont_1.drawPropTextS)(ctx, (0, propFont_1.clipPropText)(it.title, tw - 16), rect.x + 9, rect.y + 6, kit_1.UI.title);
            ctx.globalAlpha = 1;
            hits.add(`alerts.toast.${it.id}`, rect, {
                tooltip: it.body ?? it.title,
                onClick: () => {
                    it.read = true;
                    it.ttl = 0;
                    onFocus?.(it);
                },
            });
        });
    }
}
exports.NotificationFeed = NotificationFeed;
