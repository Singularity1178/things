"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SettingsStore = exports.DEFAULT_SETTINGS = exports.DEFAULT_KEYBINDS = exports.ACTION_LABELS = void 0;
exports.formatKeyName = formatKeyName;
exports.ACTION_LABELS = {
    moveUp: "Move Up",
    moveDown: "Move Down",
    moveLeft: "Move Left",
    moveRight: "Move Right",
    interact: "Interact / Use",
    attack: "Slam / Attack",
    core: "Slot / Remove Core",
    scan: "Toggle Scan Mode",
    pack: "Open Pack",
    build: "Open Build Menu",
    map: "Open Schematic",
    pause: "System / Pause Menu",
    quicksave: "Quick Save",
    quickload: "Quick Load",
    notifications: "Toggle Alerts Feed",
    settings: "Open Settings",
};
exports.DEFAULT_KEYBINDS = {
    moveUp: ["w", "arrowup"],
    moveDown: ["s", "arrowdown"],
    moveLeft: ["a", "arrowleft"],
    moveRight: ["d", "arrowright"],
    interact: ["e", "enter"],
    attack: [" "],
    core: ["c"],
    scan: ["z"],
    pack: ["i", "tab"],
    build: ["b"],
    map: ["m"],
    pause: ["escape"],
    quicksave: ["k"],
    quickload: ["l"],
    notifications: ["n"],
    settings: ["o"],
};
exports.DEFAULT_SETTINGS = {
    masterVol: 0.55,
    sfxVol: 1,
    ambientVol: 1,
    screenShake: true,
    flashes: true,
    uiScale: 2,
    palette: "default",
    pauseOnAlert: false,
    pauseWorkerBlocked: true,
    pauseNoPower: true,
    pauseStorageFull: false,
    autosaveIntervalSec: 120,
    keybinds: Object.fromEntries(Object.entries(exports.DEFAULT_KEYBINDS).map(([k, v]) => [k, [...v]])),
};
const STORAGE_KEY = "dustwake.settings";
function formatKeyName(key) {
    if (key === " ")
        return "Space";
    if (key === "arrowup")
        return "Up";
    if (key === "arrowdown")
        return "Down";
    if (key === "arrowleft")
        return "Left";
    if (key === "arrowright")
        return "Right";
    if (key === "escape")
        return "Esc";
    if (key === "enter")
        return "Enter";
    if (key === "tab")
        return "Tab";
    return key.length === 1 ? key.toUpperCase() : key;
}
class SettingsStore {
    constructor(storage) {
        Object.defineProperty(this, "storage", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: storage
        });
        Object.defineProperty(this, "data", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "listeners", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        this.data = this.load();
    }
    load() {
        const base = structuredCloneCompat(exports.DEFAULT_SETTINGS);
        if (!this.storage)
            return base;
        try {
            const raw = this.storage.getItem(STORAGE_KEY);
            if (!raw)
                return base;
            const p = JSON.parse(raw);
            if (typeof p.masterVol === "number")
                base.masterVol = clamp01(p.masterVol);
            if (typeof p.sfxVol === "number")
                base.sfxVol = clamp01(p.sfxVol);
            if (typeof p.ambientVol === "number")
                base.ambientVol = clamp01(p.ambientVol);
            if (typeof p.screenShake === "boolean")
                base.screenShake = p.screenShake;
            if (typeof p.flashes === "boolean")
                base.flashes = p.flashes;
            if (p.uiScale === 1 || p.uiScale === 1.5 || p.uiScale === 2)
                base.uiScale = p.uiScale;
            if (p.palette)
                base.palette = p.palette;
            if (typeof p.pauseOnAlert === "boolean")
                base.pauseOnAlert = p.pauseOnAlert;
            if (typeof p.pauseWorkerBlocked === "boolean")
                base.pauseWorkerBlocked = p.pauseWorkerBlocked;
            if (typeof p.pauseNoPower === "boolean")
                base.pauseNoPower = p.pauseNoPower;
            if (typeof p.pauseStorageFull === "boolean")
                base.pauseStorageFull = p.pauseStorageFull;
            if (typeof p.autosaveIntervalSec === "number")
                base.autosaveIntervalSec = Math.max(0, p.autosaveIntervalSec);
            if (p.keybinds && typeof p.keybinds === "object") {
                for (const k of Object.keys(exports.DEFAULT_KEYBINDS)) {
                    const arr = p.keybinds[k];
                    if (Array.isArray(arr) && arr.length > 0 && arr.every((x) => typeof x === "string")) {
                        base.keybinds[k] = arr.map((x) => x.toLowerCase());
                    }
                }
            }
        }
        catch {
            // Ignore corrupt settings
        }
        return base;
    }
    save() {
        if (this.storage) {
            try {
                this.storage.setItem(STORAGE_KEY, JSON.stringify(this.data));
            }
            catch {
                // Ignore storage quota errors
            }
        }
        for (const fn of this.listeners)
            fn(this.data);
    }
    onChange(fn) {
        this.listeners.push(fn);
        return () => {
            this.listeners = this.listeners.filter((x) => x !== fn);
        };
    }
    set(key, val) {
        this.data[key] = val;
        this.save();
    }
    /** Rebind the primary key for an action (keeping secondary alias if distinct). */
    rebind(action, newKey) {
        const k = newKey.toLowerCase();
        const cur = this.data.keybinds[action];
        const secondary = cur.length > 1 && cur[1] !== k ? [cur[1]] : [];
        this.data.keybinds[action] = [k, ...secondary];
        this.save();
    }
    resetKeybinds() {
        this.data.keybinds = Object.fromEntries(Object.entries(exports.DEFAULT_KEYBINDS).map(([k, v]) => [k, [...v]]));
        this.save();
    }
    resetDefaults() {
        this.data = structuredCloneCompat(exports.DEFAULT_SETTINGS);
        this.save();
    }
}
exports.SettingsStore = SettingsStore;
const clamp01 = (v) => Math.max(0, Math.min(1, v));
const structuredCloneCompat = (v) => JSON.parse(JSON.stringify(v));
