"use strict";
// Mixed-case proportional pixel font for the 2x hi-res UI layer (640x360).
// Pure (no DOM text measurement; renders pixel-crisp via fillRect in both
// browser and headless RCanvas). Cap height: 7px (rows 0..6), descenders:
// rows 7..8 (total line height 9px).
Object.defineProperty(exports, "__esModule", { value: true });
exports.PROP_GLYPHS = exports.PROP_LINE_HEIGHT = exports.PROP_FONT_HEIGHT = void 0;
exports.propTextWidth = propTextWidth;
exports.clipPropText = clipPropText;
exports.wrapPropText = wrapPropText;
exports.drawPropText = drawPropText;
exports.drawPropTextS = drawPropTextS;
// Each row string uses '#' for lit pixels, '.' for empty.
// Baseline is row 6; rows 7..8 are descenders.
const GLYPHS = {
    // Uppercase
    A: { w: 4, rows: [".##.", "#..#", "#..#", "####", "#..#", "#..#", "#..#"] },
    B: { w: 4, rows: ["###.", "#..#", "#..#", "###.", "#..#", "#..#", "###."] },
    C: { w: 4, rows: [".###", "#...", "#...", "#...", "#...", "#...", ".###"] },
    D: { w: 4, rows: ["###.", "#..#", "#..#", "#..#", "#..#", "#..#", "###."] },
    E: { w: 4, rows: ["####", "#...", "#...", "###.", "#...", "#...", "####"] },
    F: { w: 4, rows: ["####", "#...", "#...", "###.", "#...", "#...", "#..."] },
    G: { w: 4, rows: [".###", "#...", "#...", "#.##", "#..#", "#..#", ".###"] },
    H: { w: 4, rows: ["#..#", "#..#", "#..#", "####", "#..#", "#..#", "#..#"] },
    I: { w: 3, rows: ["###", ".#.", ".#.", ".#.", ".#.", ".#.", "###"] },
    J: { w: 4, rows: ["..##", "...#", "...#", "...#", "#..#", "#..#", ".##."] },
    K: { w: 4, rows: ["#..#", "#.#.", "##..", "#...", "##..", "#.#.", "#..#"] },
    L: { w: 4, rows: ["#...", "#...", "#...", "#...", "#...", "#...", "####"] },
    M: { w: 5, rows: ["#...#", "##.##", "#.#.#", "#...#", "#...#", "#...#", "#...#"] },
    N: { w: 4, rows: ["#..#", "##.#", "#.##", "#..#", "#..#", "#..#", "#..#"] },
    O: { w: 4, rows: [".##.", "#..#", "#..#", "#..#", "#..#", "#..#", ".##."] },
    P: { w: 4, rows: ["###.", "#..#", "#..#", "###.", "#...", "#...", "#..."] },
    Q: { w: 4, rows: [".##.", "#..#", "#..#", "#..#", "#.##", "#..#", ".###"] },
    R: { w: 4, rows: ["###.", "#..#", "#..#", "###.", "#.#.", "#..#", "#..#"] },
    S: { w: 4, rows: [".###", "#...", "#...", ".##.", "...#", "...#", "###."] },
    T: { w: 5, rows: ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.."] },
    U: { w: 4, rows: ["#..#", "#..#", "#..#", "#..#", "#..#", "#..#", ".##."] },
    V: { w: 5, rows: ["#...#", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", "..#.."] },
    W: { w: 5, rows: ["#...#", "#...#", "#...#", "#.#.#", "#.#.#", "##.##", "#...#"] },
    X: { w: 4, rows: ["#..#", "#..#", ".##.", ".##.", ".##.", "#..#", "#..#"] },
    Y: { w: 5, rows: ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#.."] },
    Z: { w: 4, rows: ["####", "...#", "..#.", ".#..", "#...", "#...", "####"] },
    // Lowercase
    a: { w: 4, rows: ["....", "....", ".##.", "...#", ".###", "#..#", ".###"] },
    b: { w: 4, rows: ["#...", "#...", "###.", "#..#", "#..#", "#..#", "###."] },
    c: { w: 4, rows: ["....", "....", ".###", "#...", "#...", "#...", ".###"] },
    d: { w: 4, rows: ["...#", "...#", ".###", "#..#", "#..#", "#..#", ".###"] },
    e: { w: 4, rows: ["....", "....", ".##.", "#..#", "####", "#...", ".###"] },
    f: { w: 3, rows: [".##", "#..", "###", "#..", "#..", "#..", "#.."] },
    g: { w: 4, rows: ["....", "....", ".###", "#..#", "#..#", ".###", "...#", "###."] },
    h: { w: 4, rows: ["#...", "#...", "###.", "#..#", "#..#", "#..#", "#..#"] },
    i: { w: 1, rows: ["#", ".", "#", "#", "#", "#", "#"] },
    j: { w: 2, rows: [".#", "..", ".#", ".#", ".#", ".#", ".#", "#."] },
    k: { w: 4, rows: ["#...", "#...", "#..#", "#.#.", "##..", "#.#.", "#..#"] },
    l: { w: 2, rows: ["#.", "#.", "#.", "#.", "#.", "#.", ".#"] },
    m: { w: 5, rows: [".....", ".....", "##.#.", "#.#.#", "#.#.#", "#.#.#", "#.#.#"] },
    n: { w: 4, rows: ["....", "....", "###.", "#..#", "#..#", "#..#", "#..#"] },
    o: { w: 4, rows: ["....", "....", ".##.", "#..#", "#..#", "#..#", ".##."] },
    p: { w: 4, rows: ["....", "....", "###.", "#..#", "#..#", "###.", "#...", "#..."] },
    q: { w: 4, rows: ["....", "....", ".###", "#..#", "#..#", ".###", "...#", "...#"] },
    r: { w: 3, rows: ["...", "...", "#.#", "##.", "#..", "#..", "#.."] },
    s: { w: 4, rows: ["....", "....", ".###", "#...", ".##.", "...#", "###."] },
    t: { w: 3, rows: [".#.", "###", ".#.", ".#.", ".#.", ".#.", "..#"] },
    u: { w: 4, rows: ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###"] },
    v: { w: 4, rows: ["....", "....", "#..#", "#..#", "#..#", ".##.", ".##."] },
    w: { w: 5, rows: [".....", ".....", "#...#", "#...#", "#.#.#", "#.#.#", ".#.#."] },
    x: { w: 4, rows: ["....", "....", "#..#", ".##.", ".##.", "#..#", "#..#"] },
    y: { w: 4, rows: ["....", "....", "#..#", "#..#", ".###", "...#", "...#", "##.."] },
    z: { w: 4, rows: ["....", "....", "####", "..#.", ".#..", "#...", "####"] },
    // Digits
    "0": { w: 4, rows: [".##.", "#..#", "#.##", "##.#", "#..#", "#..#", ".##."] },
    "1": { w: 3, rows: [".#.", "##.", ".#.", ".#.", ".#.", ".#.", "###"] },
    "2": { w: 4, rows: [".##.", "#..#", "...#", "..#.", ".#..", "#...", "####"] },
    "3": { w: 4, rows: ["###.", "...#", "...#", ".##.", "...#", "...#", "###."] },
    "4": { w: 4, rows: ["#..#", "#..#", "#..#", "####", "...#", "...#", "...#"] },
    "5": { w: 4, rows: ["####", "#...", "###.", "...#", "...#", "#..#", ".##."] },
    "6": { w: 4, rows: [".##.", "#...", "#...", "###.", "#..#", "#..#", ".##."] },
    "7": { w: 4, rows: ["####", "...#", "..#.", "..#.", ".#..", ".#..", ".#.."] },
    "8": { w: 4, rows: [".##.", "#..#", "#..#", ".##.", "#..#", "#..#", ".##."] },
    "9": { w: 4, rows: [".##.", "#..#", "#..#", ".###", "...#", "...#", ".##."] },
    // Punctuation
    " ": { w: 2, rows: [] },
    ".": { w: 1, rows: [".", ".", ".", ".", ".", ".", "#"] },
    ",": { w: 2, rows: ["..", "..", "..", "..", "..", ".#", "#."] },
    ":": { w: 1, rows: [".", ".", "#", ".", ".", "#", "."] },
    ";": { w: 2, rows: ["..", "..", ".#", "..", "..", ".#", "#."] },
    "!": { w: 1, rows: ["#", "#", "#", "#", "#", ".", "#"] },
    "?": { w: 4, rows: [".##.", "#..#", "...#", "..#.", ".#..", "....", ".#.."] },
    "'": { w: 1, rows: ["#", "#", ".", ".", ".", ".", "."] },
    '"': { w: 3, rows: ["#.#", "#.#", "...", "...", "...", "...", "..."] },
    "-": { w: 3, rows: ["...", "...", "...", "###", "...", "...", "..."] },
    "+": { w: 3, rows: ["...", ".#.", "###", ".#.", "...", "...", "..."] },
    "=": { w: 3, rows: ["...", "...", "###", "...", "###", "...", "..."] },
    "/": { w: 3, rows: ["..#", "..#", ".#.", ".#.", ".#.", "#..", "#.."] },
    "\\": { w: 3, rows: ["#..", "#..", ".#.", ".#.", ".#.", "..#", "..#"] },
    "(": { w: 2, rows: [".#", "#.", "#.", "#.", "#.", "#.", ".#"] },
    ")": { w: 2, rows: ["#.", ".#", ".#", ".#", ".#", ".#", "#."] },
    "[": { w: 2, rows: ["##", "#.", "#.", "#.", "#.", "#.", "##"] },
    "]": { w: 2, rows: ["##", ".#", ".#", ".#", ".#", ".#", "##"] },
    "<": { w: 3, rows: ["...", "..#", ".#.", "#..", ".#.", "..#", "..."] },
    ">": { w: 3, rows: ["...", "#..", ".#.", "..#", ".#.", "#..", "..."] },
    "#": { w: 5, rows: [".#.#.", "#####", ".#.#.", ".#.#.", "#####", ".#.#.", "....."] },
    "%": { w: 5, rows: ["#...#", "#..#.", "..#..", ".#...", "#..#.", "...#.", "....."] },
    "&": { w: 5, rows: [".##..", "#..#.", ".##..", "#.#.#", "#..#.", ".##.#", "....."] },
    "*": { w: 3, rows: ["...", "#.#", ".#.", "#.#", "...", "...", "..."] },
    "_": { w: 4, rows: ["....", "....", "....", "....", "....", "....", "....", "####"] },
    "|": { w: 1, rows: ["#", "#", "#", "#", "#", "#", "#"] },
    "@": { w: 5, rows: [".###.", "#...#", "#.##.", "#.#.#", "#.##.", "#....", ".###."] },
    "^": { w: 3, rows: [".#.", "#.#", "...", "...", "...", "...", "..."] },
    "~": { w: 4, rows: ["....", "....", ".#.#", "#.#.", "....", "....", "...."] },
};
exports.PROP_FONT_HEIGHT = 7;
exports.PROP_LINE_HEIGHT = 10;
exports.PROP_GLYPHS = new Set(Object.keys(GLYPHS));
function glyphOf(ch) {
    return GLYPHS[ch] ?? GLYPHS["?"];
}
/** Width in pixels of `text` when rendered in the proportional font. */
function propTextWidth(text, scale = 1) {
    if (!text.length)
        return 0;
    let w = 0;
    for (let i = 0; i < text.length; i++) {
        w += glyphOf(text[i]).w * scale;
        if (i < text.length - 1)
            w += scale;
    }
    return w;
}
/** Clip `text` with "..." so its proportional width fits within `maxPx`. */
function clipPropText(text, maxPx, scale = 1) {
    if (propTextWidth(text, scale) <= maxPx)
        return text;
    const ell = "...";
    const ew = propTextWidth(ell, scale);
    if (maxPx <= ew)
        return "";
    let out = "";
    for (const ch of text) {
        const next = out + ch;
        if (propTextWidth(next, scale) + scale + ew > maxPx)
            break;
        out = next;
    }
    return out + ell;
}
/** Word-wrap `text` into lines fitting `maxPx` width. Preserves explicit `\n`. */
function wrapPropText(text, maxPx, scale = 1) {
    const lines = [];
    for (const para of text.split("\n")) {
        const words = para.split(/\s+/).filter((w) => w.length > 0);
        if (!words.length) {
            lines.push("");
            continue;
        }
        let cur = words[0];
        for (let i = 1; i < words.length; i++) {
            const cand = `${cur} ${words[i]}`;
            if (propTextWidth(cand, scale) <= maxPx)
                cur = cand;
            else {
                lines.push(cur);
                cur = words[i];
            }
        }
        lines.push(cur);
    }
    return lines;
}
/** Draw mixed-case proportional pixel text. */
function drawPropText(ctx, text, x, y, color, scale = 1, align = "left") {
    if (!text)
        return;
    let sx = Math.round(x);
    if (align === "center")
        sx = Math.round(x - propTextWidth(text, scale) / 2);
    else if (align === "right")
        sx = Math.round(x - propTextWidth(text, scale));
    const sy = Math.round(y);
    ctx.fillStyle = color;
    for (let i = 0; i < text.length; i++) {
        const g = glyphOf(text[i]);
        for (let r = 0; r < g.rows.length; r++) {
            const row = g.rows[r];
            for (let c = 0; c < row.length; c++) {
                if (row[c] === "#")
                    ctx.fillRect(sx + c * scale, sy + r * scale, scale, scale);
            }
        }
        sx += (g.w + 1) * scale;
    }
}
/** Draw proportional text with a 1px drop shadow. */
function drawPropTextS(ctx, text, x, y, color, scale = 1, align = "left", shadow = "#08070a") {
    drawPropText(ctx, text, x + scale, y + scale, shadow, scale, align);
    drawPropText(ctx, text, x, y, color, scale, align);
}
