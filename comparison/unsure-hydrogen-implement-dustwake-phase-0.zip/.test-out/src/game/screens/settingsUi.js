"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SettingsUi = void 0;
// Settings & Accessibility screen (0.7) rendered on the 2x UI layer (640x360)
// using UI v2 components (tabs, sliders, toggles, scroll list, key capture).
const kit_1 = require("../ui/kit");
const input_1 = require("../ui/input");
const palettes_1 = require("../ui/palettes");
const settings_1 = require("../ui/settings");
const components_1 = require("../ui/components");
const propFont_1 = require("../ui/propFont");
const TABS = [
    { id: "audio", label: "Audio" },
    { id: "display", label: "Accessibility" },
    { id: "alerts", label: "Alerts & Save" },
    { id: "controls", label: "Controls" },
];
const ACTIONS = Object.keys(settings_1.ACTION_LABELS);
const AUTOSAVE_OPTS = [0, 60, 120, 300];
class SettingsUi {
    constructor(host) {
        Object.defineProperty(this, "host", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: host
        });
        Object.defineProperty(this, "screen", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "tabs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new components_1.UiTabs(TABS)
        });
        Object.defineProperty(this, "cursor", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "rebinding", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "ctrlScroll", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "sliders", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [new components_1.UiSlider(), new components_1.UiSlider(), new components_1.UiSlider()]
        });
        this.screen = {
            id: "settings",
            opaque: false,
            hires: true,
            t: 0,
            update: () => this.update(),
            render: () => this.render(),
        };
    }
    open() {
        this.cursor = 0;
        this.rebinding = null;
        this.host.screens.push(this.screen);
    }
    box() {
        return { x: 80, y: 32, w: input_1.UI_W - 160, h: input_1.UI_H - 64 };
    }
    update() {
        const { input, settings, screens } = this.host;
        if (this.rebinding) {
            if (input.hit("escape")) {
                this.rebinding = null;
                return;
            }
            if (input.lastRawKey && input.lastRawKey !== "escape") {
                settings.rebind(this.rebinding, input.lastRawKey);
                this.host.applySettings();
                this.rebinding = null;
            }
            return;
        }
        if (input.hit("escape", "o")) {
            screens.pop();
            return;
        }
        const b = this.box();
        if (this.tabs.handleInput(input, b.x + 12, b.y + 26, 108, 18, 6)) {
            this.cursor = 0;
            this.ctrlScroll = 0;
            return;
        }
        // Close button [X]
        if (input.mouse.leftClick && (0, components_1.inRect)(input.mouse.x, input.mouse.y, { x: b.x + b.w - 22, y: b.y + 6, w: 16, h: 14 })) {
            screens.pop();
            return;
        }
        const tabId = TABS[this.tabs.index].id;
        if (tabId === "audio")
            this.updateAudio(b);
        else if (tabId === "display")
            this.updateDisplay(b);
        else if (tabId === "alerts")
            this.updateAlerts(b);
        else
            this.updateControls(b);
    }
    updateAudio(b) {
        const { input, settings } = this.host;
        const keys = ["masterVol", "sfxVol", "ambientVol"];
        if (input.hit("arrowup", "w"))
            this.cursor = Math.max(0, this.cursor - 1);
        if (input.hit("arrowdown", "s"))
            this.cursor = Math.min(2, this.cursor + 1);
        for (let i = 0; i < 3; i++) {
            const tr = { x: b.x + 190, y: b.y + 68 + i * 36, w: 220, h: 16 };
            if (input.mouse.inside && (0, components_1.inRect)(input.mouse.x, input.mouse.y, { x: b.x + 12, y: tr.y - 4, w: b.w - 24, h: 24 })) {
                if (input.mouse.leftClick)
                    this.cursor = i;
            }
            const next = this.sliders[i].handleInput(input, tr, settings.data[keys[i]], 0, 1, 0.05, this.cursor === i);
            if (next !== null) {
                settings.set(keys[i], Math.round(next * 100) / 100);
                this.host.applySettings();
            }
        }
    }
    updateDisplay(b) {
        const { input, settings } = this.host;
        if (input.hit("arrowup", "w"))
            this.cursor = Math.max(0, this.cursor - 1);
        if (input.hit("arrowdown", "s"))
            this.cursor = Math.min(3, this.cursor + 1);
        const toggleRow = (i) => {
            if (i === 0)
                settings.set("screenShake", !settings.data.screenShake);
            else if (i === 1)
                settings.set("flashes", !settings.data.flashes);
            else if (i === 2) {
                const scales = [1, 1.5, 2];
                const next = scales[(scales.indexOf(settings.data.uiScale) + 1) % scales.length];
                settings.set("uiScale", next);
            }
            else if (i === 3) {
                const next = palettes_1.PALETTE_ORDER[(palettes_1.PALETTE_ORDER.indexOf(settings.data.palette) + 1) % palettes_1.PALETTE_ORDER.length];
                settings.set("palette", next);
            }
            this.host.applySettings();
        };
        if (input.hit("e", "enter", " "))
            toggleRow(this.cursor);
        for (let i = 0; i < 4; i++) {
            const r = { x: b.x + 14, y: b.y + 62 + i * 32, w: b.w - 28, h: 24 };
            if (input.mouse.leftClick && (0, components_1.inRect)(input.mouse.x, input.mouse.y, r)) {
                this.cursor = i;
                toggleRow(i);
            }
        }
    }
    updateAlerts(b) {
        const { input, settings } = this.host;
        if (input.hit("arrowup", "w"))
            this.cursor = Math.max(0, this.cursor - 1);
        if (input.hit("arrowdown", "s"))
            this.cursor = Math.min(4, this.cursor + 1);
        const toggleRow = (i) => {
            if (i === 0)
                settings.set("pauseOnAlert", !settings.data.pauseOnAlert);
            else if (i === 1)
                settings.set("pauseWorkerBlocked", !settings.data.pauseWorkerBlocked);
            else if (i === 2)
                settings.set("pauseNoPower", !settings.data.pauseNoPower);
            else if (i === 3)
                settings.set("pauseStorageFull", !settings.data.pauseStorageFull);
            else if (i === 4) {
                const next = AUTOSAVE_OPTS[(AUTOSAVE_OPTS.indexOf(settings.data.autosaveIntervalSec) + 1) % AUTOSAVE_OPTS.length];
                settings.set("autosaveIntervalSec", next);
            }
            this.host.applySettings();
        };
        if (input.hit("e", "enter", " "))
            toggleRow(this.cursor);
        for (let i = 0; i < 5; i++) {
            const r = { x: b.x + 14, y: b.y + 60 + i * 28, w: b.w - 28, h: 22 };
            if (input.mouse.leftClick && (0, components_1.inRect)(input.mouse.x, input.mouse.y, r)) {
                this.cursor = i;
                toggleRow(i);
            }
        }
    }
    updateControls(b) {
        const { input, settings } = this.host;
        const vis = 8;
        if (input.hit("arrowup", "w"))
            this.cursor = Math.max(0, this.cursor - 1);
        if (input.hit("arrowdown", "s"))
            this.cursor = Math.min(ACTIONS.length - 1, this.cursor + 1);
        if (input.mouse.wheelY !== 0) {
            this.ctrlScroll = Math.max(0, Math.min(ACTIONS.length - vis, this.ctrlScroll + (input.mouse.wheelY > 0 ? 1 : -1)));
        }
        if (this.cursor < this.ctrlScroll)
            this.ctrlScroll = this.cursor;
        if (this.cursor >= this.ctrlScroll + vis)
            this.ctrlScroll = this.cursor - vis + 1;
        if (input.hit("e", "enter", " ")) {
            this.rebinding = ACTIONS[this.cursor];
            return;
        }
        for (let i = 0; i < vis; i++) {
            const idx = this.ctrlScroll + i;
            if (idx >= ACTIONS.length)
                break;
            const r = { x: b.x + 14, y: b.y + 56 + i * 22, w: b.w - 28, h: 20 };
            if (input.mouse.leftClick && (0, components_1.inRect)(input.mouse.x, input.mouse.y, r)) {
                this.cursor = idx;
                this.rebinding = ACTIONS[idx];
                return;
            }
        }
        const resetBtn = { x: b.x + b.w - 134, y: b.y + b.h - 26, w: 120, h: 18 };
        if (input.mouse.leftClick && (0, components_1.inRect)(input.mouse.x, input.mouse.y, resetBtn)) {
            settings.resetKeybinds();
            this.host.applySettings();
        }
    }
    render() {
        const ctx = this.host.hctx;
        const { input, settings } = this.host;
        const b = this.box();
        ctx.fillStyle = "rgba(0,0,0,0.58)";
        ctx.fillRect(0, 0, input_1.UI_W, input_1.UI_H);
        (0, components_1.drawPanel2x)(ctx, b.x, b.y, b.w, b.h, "#121017", "#5a5268", "#7a7088");
        (0, propFont_1.drawPropTextS)(ctx, "Settings & Accessibility", b.x + 12, b.y + 8, kit_1.UI.title);
        (0, components_1.drawButton2x)(ctx, b.x + b.w - 22, b.y + 6, 16, 14, "X", {
            hovered: input.mouse.inside && (0, components_1.inRect)(input.mouse.x, input.mouse.y, { x: b.x + b.w - 22, y: b.y + 6, w: 16, h: 14 }),
        });
        this.tabs.draw(ctx, input, b.x + 12, b.y + 26, 108, 18, 6);
        const tabId = TABS[this.tabs.index].id;
        const pal = palettes_1.PALETTES[settings.data.palette];
        if (tabId === "audio") {
            const rows = [
                { label: "Master Volume", key: "masterVol" },
                { label: "Sound Effects Volume", key: "sfxVol" },
                { label: "Ambient Atmosphere", key: "ambientVol" },
            ];
            rows.forEach((row, i) => {
                const ry = b.y + 68 + i * 36;
                const focused = this.cursor === i;
                (0, propFont_1.drawPropTextS)(ctx, row.label, b.x + 18, ry + 4, focused ? kit_1.UI.title : kit_1.UI.text);
                const tr = { x: b.x + 190, y: ry, w: 220, h: 16 };
                this.sliders[i].draw(ctx, tr, settings.data[row.key], 0, 1, focused, pal.info);
                (0, propFont_1.drawPropText)(ctx, `${Math.round(settings.data[row.key] * 100)}%`, tr.x + tr.w + 14, ry + 4, kit_1.UI.mid);
            });
        }
        else if (tabId === "display") {
            const rows = [
                { label: "Screen Shake", desc: "Camera jolt on slams & tremors", kind: "toggle", on: settings.data.screenShake },
                { label: "Screen Flashes", desc: "Impact & rune arrival flashes", kind: "toggle", on: settings.data.flashes },
                { label: "HUD UI Scale", desc: "Preferred overlay density", kind: "value", val: `${settings.data.uiScale}x` },
                { label: "Overlay Palette", desc: "Colour-blind-safe highlights", kind: "value", val: palettes_1.PALETTES[settings.data.palette].label },
            ];
            rows.forEach((row, i) => {
                const ry = b.y + 62 + i * 32;
                const r = { x: b.x + 14, y: ry, w: b.w - 28, h: 24 };
                const hov = input.mouse.inside && (0, components_1.inRect)(input.mouse.x, input.mouse.y, r);
                if (this.cursor === i || hov) {
                    ctx.fillStyle = "#1c1824";
                    ctx.fillRect(r.x, r.y, r.w, r.h);
                }
                (0, propFont_1.drawPropTextS)(ctx, row.label, r.x + 8, ry + 4, this.cursor === i ? kit_1.UI.title : kit_1.UI.text);
                (0, propFont_1.drawPropText)(ctx, row.desc, r.x + 8, ry + 13, kit_1.UI.dim);
                if (row.kind === "toggle") {
                    (0, components_1.drawToggle2x)(ctx, r.x + r.w - 36, ry + 6, row.on, hov, this.cursor === i, pal.valid);
                }
                else {
                    (0, components_1.drawButton2x)(ctx, r.x + r.w - 134, ry + 4, 126, 16, row.val, { hovered: hov, focused: this.cursor === i });
                }
            });
        }
        else if (tabId === "alerts") {
            const rows = [
                { label: "Pause on Critical Alert", val: settings.data.pauseOnAlert },
                { label: "Pause when Worker Blocked", val: settings.data.pauseWorkerBlocked },
                { label: "Pause when Worker Out of Power", val: settings.data.pauseNoPower },
                { label: "Pause when Storage Full", val: settings.data.pauseStorageFull },
                { label: "Autosave Timer", text: settings.data.autosaveIntervalSec ? `${settings.data.autosaveIntervalSec}s` : "Off" },
            ];
            rows.forEach((row, i) => {
                const ry = b.y + 60 + i * 28;
                const r = { x: b.x + 14, y: ry, w: b.w - 28, h: 22 };
                const hov = input.mouse.inside && (0, components_1.inRect)(input.mouse.x, input.mouse.y, r);
                if (this.cursor === i || hov) {
                    ctx.fillStyle = "#1c1824";
                    ctx.fillRect(r.x, r.y, r.w, r.h);
                }
                (0, propFont_1.drawPropTextS)(ctx, row.label, r.x + 8, ry + 7, this.cursor === i ? kit_1.UI.title : kit_1.UI.text);
                if ("val" in row && row.val !== undefined) {
                    (0, components_1.drawToggle2x)(ctx, r.x + r.w - 36, ry + 5, row.val, hov, this.cursor === i, pal.valid);
                }
                else {
                    (0, components_1.drawButton2x)(ctx, r.x + r.w - 86, ry + 3, 78, 16, row.text, { hovered: hov, focused: this.cursor === i });
                }
            });
        }
        else {
            const vis = 8;
            for (let i = 0; i < vis; i++) {
                const idx = this.ctrlScroll + i;
                if (idx >= ACTIONS.length)
                    break;
                const act = ACTIONS[idx];
                const ry = b.y + 56 + i * 22;
                const r = { x: b.x + 14, y: ry, w: b.w - 28, h: 20 };
                const hov = input.mouse.inside && (0, components_1.inRect)(input.mouse.x, input.mouse.y, r);
                if (this.cursor === idx || hov) {
                    ctx.fillStyle = "#1c1824";
                    ctx.fillRect(r.x, r.y, r.w, r.h);
                }
                (0, propFont_1.drawPropTextS)(ctx, settings_1.ACTION_LABELS[act], r.x + 8, ry + 6, this.cursor === idx ? kit_1.UI.title : kit_1.UI.text);
                const isRebind = this.rebinding === act;
                const bindTxt = isRebind ? "Press a key..." : settings.data.keybinds[act].map(settings_1.formatKeyName).join(" / ");
                (0, components_1.drawButton2x)(ctx, r.x + r.w - 130, ry + 2, 122, 16, bindTxt, {
                    hovered: hov,
                    focused: this.cursor === idx || isRebind,
                    color: isRebind ? kit_1.UI.amber : kit_1.UI.text,
                });
            }
            const resetBtn = { x: b.x + b.w - 134, y: b.y + b.h - 26, w: 120, h: 18 };
            (0, components_1.drawButton2x)(ctx, resetBtn.x, resetBtn.y, resetBtn.w, resetBtn.h, "Reset Defaults", {
                hovered: input.mouse.inside && (0, components_1.inRect)(input.mouse.x, input.mouse.y, resetBtn),
            });
        }
        (0, propFont_1.drawPropText)(ctx, "Esc / O: Close   Q/R or Click: Tabs", b.x + 14, b.y + b.h - 18, kit_1.UI.dim);
    }
}
exports.SettingsUi = SettingsUi;
