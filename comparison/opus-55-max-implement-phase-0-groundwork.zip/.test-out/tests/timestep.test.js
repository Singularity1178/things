"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Phase 0.1 / 0.2: the fixed-timestep clock, deterministic replay at any speed, render interpolation, and
// simulation LOD (tiers, beats, far-area catch-up, determinism across a save and load).
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const clock_1 = require("../src/game/core/clock");
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const lod_1 = require("../src/game/sim/lod");
const replay_1 = require("../src/game/sim/replay");
const interp_1 = require("../src/game/view/interp");
const folk_1 = require("../src/game/sim/folk");
(0, node_test_1.test)("the clock hands out whole ticks: 1/60 fed sixty times is sixty; speed multiplies; pause runs none; a huge frame is capped", () => {
    const c = new clock_1.SimClock(clock_1.TICK);
    let n = 0;
    for (let i = 0; i < 60; i++)
        n += c.advance(1 / 60, 1);
    strict_1.default.equal(n, 60);
    strict_1.default.equal(c.advance(1 / 60, 8), 8);
    strict_1.default.equal(c.advance(1 / 60, 0), 0);
    strict_1.default.equal(c.advance(0.05, 1), 3);
    const capped = new clock_1.SimClock(clock_1.TICK, 10);
    strict_1.default.equal(capped.advance(1, 1), 10);
    strict_1.default.ok(capped.dropped > 0 && capped.acc === 0);
    strict_1.default.equal((0, clock_1.stepSpeed)(1, 1), 2);
    strict_1.default.equal((0, clock_1.stepSpeed)(8, 1), 8);
    strict_1.default.equal((0, clock_1.stepSpeed)(1, -1), 0);
    strict_1.default.equal((0, clock_1.stepSpeed)(0, -1), 0);
    strict_1.default.deepEqual([...clock_1.GAME_SPEEDS], [0, 1, 2, 4, 8]);
});
/** A town afternoon: its people about, the player walking a square and pressing E now and then. */
function townSave(seed = 4242) {
    const w = (0, world_1.createWorld)(seed), pl = (0, world_1.player)(w), town = (0, world_1.getArea)(w, "town");
    (0, world_1.enterArea)(w, pl, "town", town.start.x, town.start.y);
    w.day = Math.floor(w.day) + 1 + 13 / 24;
    w.events = [];
    return JSON.stringify((0, save_1.serialize)(w));
}
const DIRS = [[1, 0], [0, 1], [-1, 0], [0, -1]];
const stream = (t) => { const d = DIRS[Math.floor(t / 240) % 4]; return { ix: d[0], iy: d[1], use: t % 400 === 399 }; };
(0, node_test_1.test)("acceptance (0.1): the same save and input stream give an identical world at 1x and at 8x (LOD on), whatever the frame rate", () => {
    const save = townSave(), TICKS = 1500;
    const run = (speed, frames) => {
        const w = (0, save_1.deserialize)(JSON.parse(save));
        (0, lod_1.enableLod)(w);
        strict_1.default.equal((0, replay_1.playStream)(w, stream, TICKS, speed, frames), TICKS);
        return JSON.stringify((0, save_1.serialize)(w));
    };
    const at1 = run(1, [1 / 60]);
    strict_1.default.equal(run(8, [0.013, 0.021, 1 / 60, 0.04, 0.009]), at1, "8x with a ragged frame rate");
    strict_1.default.equal(run(2, [1 / 144]), at1, "2x on a 144 Hz display");
    // and it was a real run: the clock moved by exactly the ticks, the player walked
    const a = (0, save_1.deserialize)(JSON.parse(at1)), b = (0, save_1.deserialize)(JSON.parse(save));
    strict_1.default.ok(Math.abs(a.time - b.time - TICKS * clock_1.TICK) < 1e-6);
    strict_1.default.notDeepEqual([(0, world_1.player)(a).x, (0, world_1.player)(a).y, (0, world_1.player)(a).area], [(0, world_1.player)(b).x, (0, world_1.player)(b).y, (0, world_1.player)(b).area]);
});
(0, node_test_1.test)("an input log keeps runs, replays tick for tick, and survives JSON", () => {
    const log = new replay_1.InputLog();
    for (let t = 0; t < 1000; t++)
        log.record(t, stream(t));
    strict_1.default.ok(log.runs.length < 40, `${log.runs.length} runs`);
    const back = replay_1.InputLog.fromJSON(JSON.parse(JSON.stringify(log)));
    for (const t of [0, 1, 239, 240, 398, 399, 400, 999])
        strict_1.default.deepEqual(back.at(t), stream(t));
    strict_1.default.throws(() => log.record(5, stream(5)));
});
(0, node_test_1.test)("the picture is drawn between ticks: lerp by alpha, a jump drawn where it lands, and the sim's own positions come back", () => {
    const w = (0, world_1.createWorld)(7), pl = (0, world_1.player)(w), ip = new interp_1.Interpolator();
    ip.capture(w, pl.area);
    const x0 = pl.x;
    pl.x += 2;
    ip.alpha = 0.5;
    const restore = ip.apply(w, pl.area);
    strict_1.default.equal(pl.x, x0 + 1);
    restore();
    strict_1.default.equal(pl.x, x0 + 2);
    ip.capture(w, pl.area);
    pl.x += 100;
    ip.alpha = 0.25;
    const r2 = ip.apply(w, pl.area);
    strict_1.default.equal(pl.x, x0 + 102, "a jump is not swept");
    r2();
    ip.enabled = false;
    ip.capture(w, pl.area);
    pl.x += 1;
    ip.alpha = 0.5;
    ip.apply(w, pl.area)();
    strict_1.default.equal(pl.x, x0 + 103);
});
(0, node_test_1.test)("LOD tiers: in view is active, the rest of the area near, other areas far; the player is always active", () => {
    const w = (0, world_1.createWorld)(11), pl = (0, world_1.player)(w), town = (0, world_1.getArea)(w, "town");
    (0, world_1.enterArea)(w, pl, "town", town.start.x, town.start.y);
    (0, lod_1.enableLod)(w);
    const folk = w.actors.filter(folk_1.isFolk);
    strict_1.default.ok(folk.length > 4);
    const [a, b, c] = folk;
    a.area = "town";
    a.x = pl.x + 30;
    a.y = pl.y;
    b.area = "town";
    b.x = pl.x + 2000;
    b.y = pl.y;
    c.area = "dungeon";
    strict_1.default.equal((0, lod_1.lodTier)(w, pl, pl), "active");
    strict_1.default.equal((0, lod_1.lodTier)(w, a, pl), "active");
    strict_1.default.equal((0, lod_1.lodTier)(w, b, pl), "near");
    strict_1.default.equal((0, lod_1.lodTier)(w, c, pl), "far");
});
(0, node_test_1.test)("near actors step on their beat (every 0.1 s, the step that long, offset per actor); steps are cut to maxStep", () => {
    const w = (0, world_1.createWorld)(12), pl = (0, world_1.player)(w);
    (0, lod_1.enableLod)(w);
    const a = (0, world_1.actorById)(w, "npc.guardian");
    let due = 0, steps = 0;
    for (let i = 0; i < 600; i++) {
        w.time += clock_1.TICK;
        const d = (0, lod_1.lodDue)(w, a, "near", clock_1.TICK, true);
        if (d) {
            steps++;
            due += d;
            strict_1.default.ok(Math.abs(d - 0.1) < 1e-9);
        }
    }
    strict_1.default.ok(Math.abs(steps - 100) <= 1, `${steps} steps in 10 s`);
    strict_1.default.ok(Math.abs(due - 10) < 0.11);
    strict_1.default.equal((0, lod_1.lodDue)(w, a, "far", clock_1.TICK, false), 0, "a far actor with no work is not stepped");
    strict_1.default.equal((0, lod_1.lodDue)(w, pl, "active", clock_1.TICK, true), clock_1.TICK);
    const pieces = [];
    (0, lod_1.stepIn)(w, 0.5, (d) => pieces.push(d));
    strict_1.default.equal(pieces.length, 5);
});
(0, node_test_1.test)("far areas wait and catch up on entry: the circle's charge is advanced by the time away", () => {
    const w = (0, world_1.createWorld)(13), pl = (0, world_1.player)(w), town = (0, world_1.getArea)(w, "town"), d = (0, world_1.getArea)(w, "dungeon");
    (0, world_1.enterArea)(w, pl, "town", town.start.x, town.start.y);
    d.ritual.active = true;
    d.ritual.actT = 0;
    (0, lod_1.enableLod)(w);
    for (let i = 0; i < 120; i++)
        (0, replay_1.simTick)(w);
    strict_1.default.equal(d.ritual.actT, 0, "unticked while the player is away");
    (0, world_1.enterArea)(w, pl, "dungeon", d.start.x, d.start.y);
    (0, replay_1.simTick)(w);
    strict_1.default.ok(Math.abs(d.ritual.actT - 121 * clock_1.TICK) < 1e-6, `caught up to ${d.ritual.actT}`);
    // without LOD every area ticks every step, as before
    const w2 = (0, world_1.createWorld)(13), d2 = (0, world_1.getArea)(w2, "dungeon"), p2 = (0, world_1.player)(w2);
    (0, world_1.enterArea)(w2, p2, "town", (0, world_1.getArea)(w2, "town").start.x, (0, world_1.getArea)(w2, "town").start.y);
    d2.ritual.active = true;
    d2.ritual.actT = 0;
    for (let i = 0; i < 60; i++)
        (0, replay_1.simTick)(w2);
    strict_1.default.ok(Math.abs(d2.ritual.actT - 60 * clock_1.TICK) < 1e-6);
});
(0, node_test_1.test)("LOD is deterministic and survives a save and load exactly (the beat is a function of time and id)", () => {
    const save = townSave(77);
    const w = (0, save_1.deserialize)(JSON.parse(save));
    (0, lod_1.enableLod)(w);
    (0, replay_1.playStream)(w, stream, 600, 1, [1 / 60]);
    const mid = JSON.stringify((0, save_1.serialize)(w));
    const resumed = (0, save_1.deserialize)(JSON.parse(mid));
    (0, lod_1.enableLod)(resumed);
    (0, replay_1.playStream)(w, (t) => stream(t + 600), 600, 1, [1 / 60]);
    (0, replay_1.playStream)(resumed, (t) => stream(t + 600), 600, 4, [1 / 60]);
    strict_1.default.equal(JSON.stringify((0, save_1.serialize)(resumed)), JSON.stringify((0, save_1.serialize)(w)));
});
