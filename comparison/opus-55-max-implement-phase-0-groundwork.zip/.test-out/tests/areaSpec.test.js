"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Phase 0.3 (dynamic areas) and the save changes that go with them (v20: specs, run-length grids).
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const areaSpec_1 = require("../src/game/world/areaSpec");
const rle_1 = require("../src/game/world/rle");
const replay_1 = require("../src/game/sim/replay");
const tiles_1 = require("../src/game/content/tiles");
const spec = (o = {}) => ({ id: "gen.floor.1", kind: "floor", seed: 5, w: 56, h: 36, parent: "dungeon", depth: 1, link: { area: "dungeon", x: 100, y: 100 }, ...o });
(0, node_test_1.test)("a spec builds the same area every time; another seed another; floors and caves both have a way up and stand-on ground", () => {
    const a = (0, areaSpec_1.buildFromSpec)(spec()), b = (0, areaSpec_1.buildFromSpec)(spec()), c = (0, areaSpec_1.buildFromSpec)(spec({ seed: 6 }));
    strict_1.default.deepEqual([...a.grid], [...b.grid]);
    strict_1.default.notDeepEqual([...a.grid], [...c.grid]);
    for (const d of [a, (0, areaSpec_1.buildFromSpec)(spec({ id: "gen.cave.1", kind: "cave", seed: 9 }))]) {
        const up = d.portals?.find((p) => p.id === "up");
        strict_1.default.ok(up, `${d.id} has a way up`);
        strict_1.default.equal(up.to.portal, (0, areaSpec_1.linkPortalId)(d.id));
        const tx = Math.floor(d.start.x / 16), ty = Math.floor((d.start.y - 1) / 16);
        strict_1.default.ok(!(0, tiles_1.isSolidT)(d.grid[ty * d.w + tx]), `${d.id} starts on open ground`);
        strict_1.default.ok(d.w >= 48 && d.h >= 32, "at least the widest view");
    }
    strict_1.default.throws(() => (0, areaSpec_1.buildFromSpec)(spec({ kind: "nope" })), /unknown area kind/);
});
const walk = (w, iy, until, max = 240) => {
    for (let i = 0; i < max && !until(); i++)
        (0, replay_1.simTick)(w, { ix: 0, iy, use: false });
    return until();
};
(0, node_test_1.test)("acceptance (0.3): a generated floor is created, entered, saved, loaded and left (and entered again)", () => {
    const w = (0, world_1.createWorld)(21), pl = (0, world_1.player)(w), d = (0, world_1.getArea)(w, "dungeon");
    const link = { area: "dungeon", x: Math.round(pl.x), y: Math.round(pl.y) };
    const floor = (0, world_1.createArea)(w, { kind: "floor", seed: 99, w: 56, h: 36, parent: "dungeon", depth: 1, link, label: "Test floor" });
    strict_1.default.ok(floor.id.startsWith("gen.floor.") && (0, world_1.hasArea)(w, floor.id));
    strict_1.default.ok(d.base.portals?.some((p) => p.id === (0, areaSpec_1.linkPortalId)(floor.id)), "the parent gained its way down");
    (0, world_1.enterArea)(w, pl, floor.id, floor.base.start.x, floor.base.start.y);
    // change something, so the save carries a diff of the generated area
    const tx = Math.floor(floor.base.start.x / 16) + 2, ty = Math.floor(floor.base.start.y / 16) + 1;
    floor.setTile(tx, ty, tiles_1.T.RUBBLE);
    const save = (0, save_1.serialize)(w);
    strict_1.default.equal(save.version, save_1.SAVE_VERSION);
    strict_1.default.equal(save.specs.length, 1);
    strict_1.default.ok(save.areas[floor.id].tiles.length >= 1);
    const w2 = (0, save_1.deserialize)(JSON.parse(JSON.stringify(save)));
    strict_1.default.equal(JSON.stringify((0, save_1.serialize)(w2)), JSON.stringify(save), "the round trip is exact");
    const f2 = w2.areas.get(floor.id);
    strict_1.default.equal(f2.grid[ty * f2.w + tx], tiles_1.T.RUBBLE);
    strict_1.default.ok(w2.areas.get("dungeon").base.portals?.some((p) => p.id === (0, areaSpec_1.linkPortalId)(floor.id)), "the way down is re-attached on load");
    // leave by the stair nook: push up from where you arrived
    const p2 = (0, world_1.player)(w2);
    strict_1.default.ok(walk(w2, -1, () => p2.area === "dungeon"), "walked up and out");
    strict_1.default.ok(Math.hypot(p2.x - link.x, p2.y - link.y) < 40, "came out beside the link point");
    // and back down through the hole (a player steers onto it; here: step over it, then push down)
    p2.x = link.x;
    p2.y = link.y - 7;
    p2.vx = 0;
    p2.vy = 0;
    strict_1.default.ok(walk(w2, 1, () => p2.area === floor.id), "walked back down");
});
(0, node_test_1.test)("player-built areas keep their whole grid run-length coded; a big edit switches an authored area to the grid; both load back exactly", () => {
    const w = (0, world_1.createWorld)(22);
    const built = (0, world_1.createArea)(w, { kind: "cave", seed: 3, w: 50, h: 34, store: "grid", label: "Dug-out" });
    const s1 = (0, save_1.serialize)(w);
    strict_1.default.ok(s1.areas[built.id].gridRle && s1.areas[built.id].tiles.length === 0);
    const d = (0, world_1.getArea)(w, "dungeon");
    let n = 0;
    for (let i = 0; i < d.grid.length && n <= save_1.RLE_MIN_TILES; i++)
        if (d.grid[i] === tiles_1.T.WALL) {
            d.setTile(i % d.w, Math.floor(i / d.w), tiles_1.T.RUBBLE);
            n++;
        }
    const s2 = (0, save_1.serialize)(w);
    strict_1.default.ok(s2.areas.dungeon.gridRle, "large edits are saved as the grid");
    strict_1.default.ok(s2.areas.dungeon.gridRle.length < 4000, `compressed to ${s2.areas.dungeon.gridRle.length} chars`);
    const w2 = (0, save_1.deserialize)(JSON.parse(JSON.stringify(s2)));
    strict_1.default.deepEqual([...w2.areas.get("dungeon").grid], [...d.grid]);
    strict_1.default.deepEqual([...w2.areas.get(built.id).grid], [...built.grid]);
    strict_1.default.equal(JSON.stringify((0, save_1.serialize)(w2)), JSON.stringify(s2));
});
(0, node_test_1.test)("run-length coding round-trips any grid and refuses a damaged one", () => {
    const g = new Uint8Array(5000);
    for (let i = 0; i < g.length; i++)
        g[i] = i % 977 < 600 ? 1 : (i * 7) % 5;
    strict_1.default.deepEqual([...(0, rle_1.rleDecode)((0, rle_1.rleEncode)(g), g.length)], [...g]);
    strict_1.default.deepEqual([...(0, rle_1.rleDecode)((0, rle_1.rleEncode)(new Uint8Array(0)))], []);
    strict_1.default.throws(() => (0, rle_1.rleDecode)((0, rle_1.rleEncode)(g), g.length + 1));
});
(0, node_test_1.test)("a v19 save still loads (it made no areas at runtime) and plays on; ids never collide", () => {
    const s = (0, save_1.serialize)((0, world_1.createWorld)(23));
    s.version = 19;
    delete s.specs;
    const w = (0, save_1.deserialize)(s);
    strict_1.default.equal(w.specs.size, 0);
    for (let i = 0; i < 30; i++)
        (0, replay_1.simTick)(w);
    const a = (0, world_1.createArea)(w, { kind: "floor", seed: 1, w: 50, h: 32 }), b = (0, world_1.createArea)(w, { kind: "floor", seed: 2, w: 50, h: 32 });
    strict_1.default.notEqual(a.id, b.id);
    strict_1.default.throws(() => (0, world_1.createArea)(w, { id: "town", kind: "floor", seed: 1, w: 50, h: 32 }), /already exists/);
});
