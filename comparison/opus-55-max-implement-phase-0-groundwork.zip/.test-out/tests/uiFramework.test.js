"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Phase 0.5 / 0.7: the v2 font, the widget kit (mouse and keyboard parity), settings and the notification feed.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const font2_1 = require("../src/game/ui/font2");
const gui_1 = require("../src/game/ui/gui");
const settings_1 = require("../src/game/ui/settings");
const notify_1 = require("../src/game/ui/notify");
const vision_1 = require("../src/game/content/vision");
const world_1 = require("../src/game/world/world");
const util_1 = require("../src/game/util");
(0, node_test_1.test)("the v2 font: mixed case, every glyph's rows equally wide, proportional measuring, wrapping and clipping", () => {
    for (const [ch, rows] of (0, font2_1.font2Rows)()) {
        strict_1.default.ok(rows.length >= 7 && rows.length <= 9, `${ch} has ${rows.length} rows`);
        strict_1.default.ok(rows.every((r) => r.length === rows[0].length), `${ch} rows differ in width`);
    }
    for (const c of "AZaz09.,:;!?'\"-+=/()[]<>%#*&@")
        strict_1.default.ok((0, font2_1.fitsFont2)(c), c);
    strict_1.default.ok((0, font2_1.textWidth2)("ill") < (0, font2_1.textWidth2)("MWM"), "proportional");
    strict_1.default.ok((0, font2_1.fitsFont2)("Autosave — every 5 min…"), "typographic marks map onto the glyphs");
    const lines = (0, font2_1.wrapText2)("The quick brown fox jumps over the lazy golem, twice.", 60);
    strict_1.default.ok(lines.length > 1 && lines.every((l) => (0, font2_1.textWidth2)(l) <= 60));
    strict_1.default.ok((0, font2_1.textWidth2)((0, font2_1.clipText2)("A very long label indeed", 40)) <= 40);
});
const ctx = (0, util_1.makeCanvas)(640, 360).ctx;
function frame(gui, o, body) {
    gui.begin(ctx, 640, 360, { ...(0, gui_1.noInput)(), ...o, keys: { ...(0, gui_1.noKeys)(), ...(o.keys ?? {}) }, dt: 1 / 60 });
    const r = body(gui);
    gui.end();
    return r;
}
const two = (g) => [g.button("a", (0, gui_1.rect)(10, 10, 50, 14), "One"), g.button("b", (0, gui_1.rect)(10, 30, 50, 14), "Two")];
(0, node_test_1.test)("buttons: a click is press and release on the same widget; keyboard focus moves with Up / Down and Enter activates", () => {
    const g = new gui_1.Gui();
    strict_1.default.deepEqual(frame(g, { mx: 20, my: 15, pressed: true, down: true }, two), [false, false]);
    strict_1.default.deepEqual(frame(g, { mx: 20, my: 15, released: true }, two), [true, false]);
    frame(g, { mx: 20, my: 15, pressed: true, down: true }, two);
    strict_1.default.deepEqual(frame(g, { mx: 20, my: 35, released: true }, two), [false, false], "dragged off: no click");
    strict_1.default.ok(g.over === false || g.over === true);
    frame(g, { keys: { down: true } }, two);
    strict_1.default.equal(g.focus, "a");
    frame(g, { keys: { down: true } }, two);
    strict_1.default.equal(g.focus, "b");
    strict_1.default.deepEqual(frame(g, { keys: { activate: true } }, two), [false, true]);
    strict_1.default.deepEqual(frame(g, { mx: 300, my: 300, pressed: true, down: true }, () => g.button("x", (0, gui_1.rect)(0, 0, 10, 10), "x", { disabled: true })), false);
});
(0, node_test_1.test)("slider, toggle, choice and tabs: drag, wheel and keys; Q / R switch tabs from anywhere", () => {
    const g = new gui_1.Gui(), r = (0, gui_1.rect)(10, 10, 300, 14);
    let v = 50;
    v = frame(g, { mx: 300, my: 15, pressed: true, down: true }, (x) => x.slider("s", r, "Volume", v, 0, 100, 5));
    strict_1.default.equal(v, 100, "dragged to the end");
    v = frame(g, { mx: 200, my: 15, wheel: 1 }, (x) => x.slider("s", r, "Volume", v, 0, 100, 5));
    strict_1.default.equal(v, 95);
    strict_1.default.equal(g.wantsWheel, true);
    g.focus = "s";
    v = frame(g, { keys: { left: true } }, (x) => x.slider("s", r, "Volume", v, 0, 100, 5));
    strict_1.default.equal(v, 90);
    g.focus = "t";
    strict_1.default.equal(frame(g, { keys: { activate: true } }, (x) => x.toggle("t", r, "Shake", true)), false);
    g.focus = "c";
    const opts = [{ value: "a", label: "A" }, { value: "b", label: "B" }];
    strict_1.default.equal(frame(g, { keys: { right: true } }, (x) => x.choice("c", r, "Pick", opts, "a")), "b");
    strict_1.default.equal(frame(g, { keys: { nextTab: true } }, (x) => x.tabs("tb", r, ["One", "Two", "Three"], 2)), 0);
    strict_1.default.equal(frame(g, { keys: { prevTab: true } }, (x) => x.tabs("tb", r, ["One", "Two", "Three"], 0)), 2);
});
(0, node_test_1.test)("lists scroll with the wheel and move their selection with the keys; tables sort by a clicked column; a modal blocks the rest", () => {
    const g = new gui_1.Gui(), r = (0, gui_1.rect)(10, 10, 200, 62), draw = () => { };
    g.focus = "l";
    let res = frame(g, { keys: { down: true } }, (x) => x.list("l", r, 30, 12, 0, draw));
    strict_1.default.equal(res.sel, 1);
    strict_1.default.equal(g.focus, "l", "the list kept Up / Down for its rows");
    res = frame(g, { mx: 50, my: 30, wheel: 3 }, (x) => x.list("l", r, 30, 12, 1, draw));
    strict_1.default.equal(g.wantsWheel, true);
    const rows = [["b", "2"], ["a", "10"], ["c", "1"]];
    frame(g, { mx: 150, my: 15, released: true }, (x) => x.table("t", (0, gui_1.rect)(10, 10, 200, 80), [{ label: "Name", w: 50 }, { label: "N", w: 50 }], rows, -1));
    const t = frame(g, {}, (x) => x.table("t", (0, gui_1.rect)(10, 10, 200, 80), [{ label: "Name", w: 50 }, { label: "N", w: 50 }], rows, -1));
    strict_1.default.deepEqual(t.order, [2, 0, 1], "sorted by the number column, numerically");
    // a modal: the button under it does not react; Esc answers its last button
    const body = (x) => [x.button("under", (0, gui_1.rect)(300, 170, 40, 14), "Under"), x.modalBox("m", "Sure?", ["Really?"], ["Yes", "No"])];
    frame(g, {}, body);
    const out = frame(g, { mx: 310, my: 175, pressed: true, down: true, released: true }, body);
    strict_1.default.equal(out[0], false);
    strict_1.default.equal(frame(g, { keys: { back: true } }, body)[1], 1);
});
(0, node_test_1.test)("settings: defaults, clamping, a rebound key leaves every other action, and they persist", () => {
    const mem = new Map(), storage = { getItem: (k) => mem.get(k) ?? null, setItem: (k, v) => void mem.set(k, v) };
    const s = new settings_1.Settings(storage);
    strict_1.default.equal(s.num("volMaster"), 100);
    strict_1.default.equal(s.bool("pauseOnAlert"), false);
    s.set("volMaster", 143);
    strict_1.default.equal(s.num("volMaster"), 100);
    s.set("volMaster", 42);
    strict_1.default.equal(s.num("volMaster"), 40, "snapped to the step");
    s.set("uiScale", "huge");
    strict_1.default.equal(s.str("uiScale"), "normal", "not an option");
    s.bind("attack", "e");
    strict_1.default.deepEqual(s.keys("attack").slice(0, 1), ["e"]);
    strict_1.default.ok(!s.keys("interact").includes("e"));
    const again = new settings_1.Settings(storage);
    strict_1.default.equal(again.num("volMaster"), 40);
    strict_1.default.equal(again.keys("attack")[0], "e");
    again.resetAll();
    strict_1.default.deepEqual(again.keys("interact"), settings_1.DEFAULT_KEYS.interact);
    (0, settings_1.registerSetting)({ id: "test.later", label: "A later feature", category: "game", kind: "toggle", def: true });
    strict_1.default.ok((0, settings_1.settingDefs)().some((d) => d.id === "test.later"), "later features register in one place");
});
(0, node_test_1.test)("palettes recolour the vision categories (colour-blind-safe sets)", () => {
    (0, settings_1.applyPalette)("deutan");
    strict_1.default.equal(vision_1.VISION_CATEGORIES.buildable.color, settings_1.PALETTES.deutan.buildable);
    (0, settings_1.applyPalette)("default");
    strict_1.default.equal(vision_1.VISION_CATEGORIES.buildable.color, settings_1.PALETTES.default.buildable);
});
(0, node_test_1.test)("notifications: repeats merge, alerts call back, and sim events become notes", () => {
    const f = new notify_1.NotificationFeed();
    let alerts = 0;
    f.onAlert = () => alerts++;
    f.push("Hello");
    f.push("Hello");
    strict_1.default.equal(f.items.length, 1);
    strict_1.default.equal(f.items[0].count, 2);
    f.push("Blocked", "alert");
    strict_1.default.equal(alerts, 1);
    f.update(100);
    strict_1.default.equal(f.items.length, 0);
    strict_1.default.equal(f.history.length, 2);
    const w = (0, world_1.createWorld)(41), wk = (0, world_1.actorById)(w, "npc.worker.artificery");
    const n = (0, notify_1.noteForEvent)(w, { t: "jobChanged", actor: wk.id, status: "blocked", reason: "storageFull" });
    strict_1.default.equal(n.level, "alert");
    strict_1.default.match(n.text, /blocked: storage full/);
    strict_1.default.equal((0, notify_1.noteForEvent)(w, { t: "jobChanged", actor: w.playerId, status: "blocked" }), null, "the player's own orders are not news");
    strict_1.default.equal((0, notify_1.noteForEvent)(w, { t: "dayPhase", phase: "dawn", day: 2 }).text, "Dawn, day 3");
});
