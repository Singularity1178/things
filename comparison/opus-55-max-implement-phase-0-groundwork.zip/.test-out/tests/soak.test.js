"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Phase 0.8 (and the exit criterion "a 300-actor soak holds the frame budget"): the soak harness and the content
// linter. A soak that breaks the budget or any invariant fails `npm test`.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const soak_1 = require("../src/game/sim/soak");
const contentLint_1 = require("../src/game/sim/contentLint");
const world_1 = require("../src/game/world/world");
const folk_1 = require("../src/game/sim/folk");
const items_1 = require("../src/game/content/items");
/** Mean simulation time per tick allowed (ms): a quarter of a 60 Hz frame, the rest is the renderer's. */
const BUDGET_MS = 4;
(0, node_test_1.test)("acceptance (0.2 / 0.8): a 300-actor soak holds the frame budget and every invariant (stuck, items, places, round trip)", () => {
    const r = (0, soak_1.runSoak)({ residents: 300, seconds: 60, walk: true, roundTripEvery: 1200, budgetMs: BUDGET_MS });
    strict_1.default.ok(r.actors >= 300, `${r.actors} actors`);
    strict_1.default.deepEqual(r.violations, []);
    strict_1.default.ok(r.ms.mean < BUDGET_MS, `mean ${r.ms.mean.toFixed(3)} ms per tick`);
    strict_1.default.ok(r.ms.p95 < 3 * BUDGET_MS, `p95 ${r.ms.p95.toFixed(3)} ms per tick`);
    strict_1.default.ok(r.tiers.far > 0, "LOD had actors in the far tier");
});
(0, node_test_1.test)("the soak catches what it is there for: an item made from nothing, a place held twice, a save that does not round-trip", () => {
    const w = (0, world_1.createWorld)(51), pl = (0, world_1.player)(w), town = (0, world_1.getArea)(w, "town");
    (0, world_1.enterArea)(w, pl, "town", town.start.x, town.start.y);
    (0, soak_1.populateResidents)(w, 40, "town");
    const before = (0, soak_1.itemCensus)(w);
    pl.inventory[0] = { item: "wood", n: 3 };
    strict_1.default.notEqual((0, soak_1.itemCensus)(w).get("wood") ?? 0, before.get("wood") ?? 0);
    const [a, b] = w.actors.filter(folk_1.isFolk);
    a.area = b.area = "town";
    a.life.spot = b.life.spot = "watch.post.test";
    strict_1.default.ok((0, soak_1.doubleHeld)(w).size >= 1);
    strict_1.default.equal((0, soak_1.roundTripDiff)(w), "", "a live world round-trips");
});
(0, node_test_1.test)("content lint (0.8): every content row passes every rule", () => {
    strict_1.default.deepEqual((0, contentLint_1.lintContent)(), []);
});
(0, node_test_1.test)("the linter catches a line the font cannot draw and an item that does not exist", () => {
    const items = items_1.ITEMS;
    items.__lint_probe = { ...items.wood, name: "BAD~NAME" };
    try {
        strict_1.default.ok((0, contentLint_1.lintContent)(["font1"]).some((i) => i.row === "__lint_probe"));
    }
    finally {
        delete items.__lint_probe;
    }
    strict_1.default.deepEqual((0, contentLint_1.lintContent)(["font1"]), []);
});
