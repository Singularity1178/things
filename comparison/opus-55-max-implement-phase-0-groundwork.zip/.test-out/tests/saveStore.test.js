"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Phase 0.4: save system v2 (slots, autosave backups, recovery, export / import, the legacy slot, budgets).
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const saveStore_1 = require("../src/game/world/saveStore");
const soak_1 = require("../src/game/sim/soak");
const replay_1 = require("../src/game/sim/replay");
let clock = 1000;
const store = (b = new saveStore_1.MemoryBackend()) => new saveStore_1.SaveStore(b, () => (clock += 1000));
(0, node_test_1.test)("slots: save, list, load; a manual slot keeps the copy it replaced as a backup", async () => {
    const st = store(), w = (0, world_1.createWorld)(31);
    st.save("slot1", w);
    for (let i = 0; i < 60; i++)
        (0, replay_1.simTick)(w);
    st.save("slot1", w);
    strict_1.default.ok(st.has("slot1") && st.has("slot1.bak"));
    const r = st.load("slot1");
    strict_1.default.equal(r.from, "slot1");
    strict_1.default.ok(Math.abs(r.world.time - w.time) < 1e-9);
    strict_1.default.ok(st.load("slot1.bak").world.time < w.time);
    strict_1.default.equal(st.list()[0].slot, "slot1", "newest first");
    await st.flush();
    strict_1.default.ok((await st.backend.keys()).includes("save:slot1"), "written through to the backend");
});
(0, node_test_1.test)("autosave keeps BACKUPS rolling copies, newest in auto", () => {
    const st = store(), w = (0, world_1.createWorld)(32), times = [];
    for (let k = 0; k < saveStore_1.BACKUPS + 2; k++) {
        (0, replay_1.simTick)(w);
        times.push(w.time);
        st.autosave(w);
    }
    strict_1.default.ok(Math.abs(st.load("auto").world.time - times[times.length - 1]) < 1e-9);
    for (let i = 1; i <= saveStore_1.BACKUPS; i++)
        strict_1.default.ok(Math.abs(st.load(`auto.${i}`).world.time - times[times.length - 1 - i]) < 1e-9);
    strict_1.default.ok(!st.has(`auto.${saveStore_1.BACKUPS + 1}`));
});
(0, node_test_1.test)("recovery: a damaged slot falls back to its backup and says so; when nothing loads, the reason is kept", async () => {
    const backend = new saveStore_1.MemoryBackend(), a = store(backend), w = (0, world_1.createWorld)(33);
    a.save("slot2", w);
    (0, replay_1.simTick)(w);
    a.save("slot2", w);
    a.autosave(w);
    (0, replay_1.simTick)(w);
    a.autosave(w);
    await a.flush();
    // bit rot in the newest copies
    for (const k of ["save:slot2", "save:auto"]) {
        const rec = JSON.parse(backend.map.get(k));
        rec.data = rec.data.replace(/"time":[0-9.e-]+/, '"time":12345');
        backend.map.set(k, JSON.stringify(rec));
    }
    const b = store(backend);
    await b.init();
    const r = b.load("slot2");
    strict_1.default.equal(r.from, "slot2.bak");
    strict_1.default.match(r.recovered, /could not be read.*checksum/);
    strict_1.default.equal(b.load("auto").from, "auto.1");
    strict_1.default.ok(b.list().some((m) => m.slot === "slot2" && !m.ok));
    backend.map.set("save:slot3", "{not json");
    const c = store(backend);
    await c.init();
    strict_1.default.equal(c.load("slot3"), null);
    strict_1.default.match(c.lastError, /not valid JSON/);
});
(0, node_test_1.test)("export and import round-trip a slot; a file that does not load is refused with the reason; a bare save imports too", () => {
    const st = store(), w = (0, world_1.createWorld)(34);
    st.save("quick", w);
    const text = st.exportText("quick");
    const st2 = store();
    const m = st2.importText(text, "slot3");
    strict_1.default.equal(m.slot, "slot3");
    strict_1.default.equal(JSON.stringify((0, save_1.serialize)(st2.load("slot3").world)), JSON.stringify((0, save_1.serialize)(st.load("quick").world)));
    strict_1.default.throws(() => st2.importText("hello", "slot1"), /not valid JSON/);
    strict_1.default.throws(() => st2.importText(JSON.stringify({ format: "dustwake-save", v: 2, meta: { checksum: "0" }, data: "{}" }), "slot1"), /checksum/);
    strict_1.default.throws(() => st2.importText("{\"a\":1}", "slot1"), /not a Dustwake save/);
    const bare = JSON.stringify((0, save_1.serialize)(w));
    strict_1.default.equal((0, saveStore_1.parseRecord)(bare).meta.checksum, (0, saveStore_1.fnv1a)(bare));
    st2.importText(bare, "slot1");
    strict_1.default.ok(st2.load("slot1"));
});
(0, node_test_1.test)("the legacy single localStorage slot is imported into the quick slot once (a v19 save migrates on the way)", () => {
    const st = store(), w = (0, world_1.createWorld)(35);
    const old = (0, save_1.serialize)(w);
    old.version = 19;
    delete old.specs;
    strict_1.default.ok(st.importLegacy(JSON.stringify(old)));
    strict_1.default.ok(st.load("quick"));
    strict_1.default.equal(st.importLegacy(JSON.stringify(old)), false, "never over a quick save that exists");
    strict_1.default.equal(st.importLegacy(null), false);
});
(0, node_test_1.test)("budgets (0.4): saves stay small and load fast, up to a 300-resident town", () => {
    const now = () => globalThis.performance.now();
    const fresh = (0, world_1.createWorld)(36);
    const freshText = JSON.stringify((0, save_1.serialize)(fresh));
    strict_1.default.ok(freshText.length < 24 * 1024, `fresh save ${freshText.length} B`);
    const w = (0, world_1.createWorld)(37), pl = (0, world_1.player)(w), town = (0, world_1.getArea)(w, "town");
    (0, world_1.enterArea)(w, pl, "town", town.start.x, town.start.y);
    for (let i = 0; i < 120; i++)
        (0, replay_1.simTick)(w);
    const townText = JSON.stringify((0, save_1.serialize)(w));
    strict_1.default.ok(townText.length < 160 * 1024, `town save ${townText.length} B`);
    (0, soak_1.populateResidents)(w, 300, "town");
    for (let i = 0; i < 60; i++)
        (0, replay_1.simTick)(w);
    const t0 = now(), bigText = JSON.stringify((0, save_1.serialize)(w)), t1 = now();
    const back = (0, save_1.deserialize)(JSON.parse(bigText)), t2 = now();
    strict_1.default.ok(bigText.length < 1536 * 1024, `300-resident save ${bigText.length} B`);
    strict_1.default.ok(t1 - t0 < 1500, `saved in ${(t1 - t0).toFixed(0)} ms`);
    strict_1.default.ok(t2 - t1 < 2000, `loaded in ${(t2 - t1).toFixed(0)} ms`);
    strict_1.default.equal(back.actors.length, w.actors.length);
});
