"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Phase 0 through the host (game.ts): game speeds over the fixed tick, the system menu, saves through the store
// (quick slot, Continue, autosave on area change), the mouse on the hi-res UI layer, generated floors, settings.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const g0 = globalThis;
g0.localStorage ?? (g0.localStorage = { getItem: () => null, setItem: () => { }, removeItem: () => { } });
const game_1 = require("../src/game/game");
const world_1 = require("../src/game/world/world");
const clock_1 = require("../src/game/core/clock");
const canvas = () => globalThis.document.createElement("canvas");
function host(seed = 61) {
    const g = new game_1.Game(canvas(), canvas());
    g.resume((0, world_1.createWorld)(seed));
    return g;
}
const press = (g, k) => { g.keyDown(k); g.update(1 / 60); g.render(); g.keyUp(k); };
const near = (a, b) => Math.abs(a - b) < 1e-9;
(0, node_test_1.test)("game speed: P pauses, = and - step the ladder; at 8x one frame runs eight ticks; paused runs none", () => {
    const g = host(), w = g.world;
    let t = w.time;
    g.update(1 / 60);
    strict_1.default.ok(near(w.time, t + clock_1.TICK), "1x: one tick per 1/60 frame");
    press(g, "=");
    strict_1.default.equal(g.speed, 2);
    press(g, "-");
    press(g, "-");
    strict_1.default.equal(g.speed, 0);
    t = w.time;
    for (let i = 0; i < 10; i++)
        g.update(1 / 60);
    strict_1.default.equal(w.time, t, "paused: the world does not move");
    press(g, "p");
    strict_1.default.equal(g.speed, 1, "P resumes at the last speed");
    g.setSpeed(8);
    t = w.time;
    g.update(1 / 60);
    strict_1.default.ok(near(w.time, t + 8 * clock_1.TICK), "8x: eight ticks per frame");
});
(0, node_test_1.test)("Esc opens the system menu over play (the world waits behind it); Esc closes it", () => {
    const g = host(), w = g.world;
    press(g, "Escape");
    strict_1.default.ok(g.screens.is("system"));
    const t = w.time;
    for (let i = 0; i < 5; i++) {
        g.update(1 / 60);
        g.render();
    }
    strict_1.default.equal(w.time, t);
    press(g, "Escape");
    strict_1.default.ok(g.screens.is("play"));
});
(0, node_test_1.test)("saves through the host: K to the quick slot, L loads the latest, and an area change autosaves", () => {
    const g = host(), w = g.world;
    press(g, "k");
    strict_1.default.ok(g.store.has("quick"));
    const saved = w.time;
    for (let i = 0; i < 30; i++)
        g.update(1 / 60);
    press(g, "l");
    strict_1.default.notEqual(g.world, w, "a new world was loaded");
    strict_1.default.ok(Math.abs(g.world.time - saved) < 0.05);
    const town = g.world.areas.get("town") ?? null;
    strict_1.default.equal(town, null);
    strict_1.default.ok(g.debugTeleport({ label: "town", group: "t", area: "town", x: 600, y: 600 }) || true);
    for (let i = 0; i < 160; i++)
        g.update(1 / 60);
    strict_1.default.ok(g.store.has("auto"), "autosaved after coming into another area");
});
(0, node_test_1.test)("the mouse: clicking the speed bar on the hi-res layer sets the speed", () => {
    const g = host();
    g.render();
    // the 8x button: logical (90..109, 6..18) on the 640x360 layer = base px (45..54, 3..9)
    g.pointerMove(49.5, 6);
    g.pointerDown(0, 49.5, 6);
    g.update(1 / 60);
    g.render();
    g.pointerUp(0, 49.5, 6);
    g.update(1 / 60);
    g.render();
    strict_1.default.equal(g.speed, 8);
    // a click on the world elsewhere is not the UI's
    g.pointerMove(160, 120);
    g.pointerDown(0, 160, 120);
    g.update(1 / 60);
    g.render();
    g.pointerUp(0, 160, 120);
    g.update(1 / 60);
    g.render();
    strict_1.default.equal(g.speed, 8);
});
(0, node_test_1.test)("generated floors through the host: create, save, load, leave", () => {
    const g = host();
    const floor = g.devCreateFloor("floor");
    strict_1.default.equal(g.area.id, floor.id);
    strict_1.default.ok(g.saveGame("slot1"));
    strict_1.default.ok(g.loadGame("slot1"));
    strict_1.default.equal(g.area.id, floor.id, "loaded back into the floor");
    strict_1.default.ok(g.devLeaveFloor());
    strict_1.default.equal(g.area.id, "dungeon");
});
(0, node_test_1.test)("settings apply at once: shake off stops shakes, LOD follows its toggle, the UI scale resizes the hi-res layer", () => {
    const g = host();
    g.settings.set("shake", false);
    g.shake(1, 3);
    strict_1.default.equal(g.shakeT, 0);
    g.settings.set("lod", false);
    strict_1.default.equal(g.world.lod, null);
    g.settings.set("lod", true);
    strict_1.default.ok(g.world.lod);
    g.settings.set("uiScale", "compact");
    strict_1.default.equal(g.hiCanvas.width, 960);
    strict_1.default.equal(g.flashK, 1);
    g.settings.set("flashes", false);
    strict_1.default.ok(g.flashK < 1);
});
(0, node_test_1.test)("smoke: every system-menu tab and settings category at every UI scale, and the world under the mouse, draw without error", () => {
    const g = host(71);
    g.settings.set("perf", true);
    for (const scale of ["compact", "normal", "large"]) {
        g.settings.set("uiScale", scale);
        press(g, "Escape");
        strict_1.default.ok(g.screens.is("system"));
        for (let tab = 0; tab < 5; tab++) {
            g.systemMenu.tab = tab;
            for (let i = 0; i < 2; i++) {
                g.update(1 / 60);
                g.render();
            }
        }
        g.systemMenu.tab = 2;
        for (let c = 0; c < 4; c++) {
            g.systemMenu.cat = c;
            g.update(1 / 60);
            g.render();
        }
        // keyboard parity inside the menu: move the focus and activate whatever it lands on (Settings tab: a toggle or slider)
        press(g, "ArrowDown");
        press(g, "ArrowDown");
        press(g, "ArrowRight");
        g.systemMenu.tab = 0;
        press(g, "Escape");
        strict_1.default.ok(g.screens.is("play"), `closed at ${scale}`);
    }
    g.settings.set("uiScale", "normal");
    for (let i = 0; i < 20; i++) {
        g.update(1 / 60);
        g.render();
    }
    // hover the golem itself, right-click it, pick the first entry of the context menu
    const pl = g.pl, bx = ((pl.x - g.cam.x) * 320) / g.vw, by = ((pl.y - 10 - g.cam.y) * 180) / g.vh;
    g.pointerMove(bx, by);
    g.update(1 / 60);
    g.render();
    g.pointerDown(2, bx, by);
    g.update(1 / 60);
    g.render();
    g.pointerUp(2, bx, by);
    g.update(1 / 60);
    g.render();
    strict_1.default.ok(g.hud.menu && g.hud.menu.items.some((i) => i.label === "Inspect"), "a context menu with Inspect");
    g.hud.menu.items.find((i) => i.label === "Inspect").run();
    g.hud.menu = null;
    for (let i = 0; i < 3; i++) {
        g.update(1 / 60);
        g.render();
    }
    strict_1.default.ok(g.hud.inspect, "the inspector is open");
    // drag a box across the view, then Esc closes the HUD's things before it opens the menu
    g.pointerMove(10, 30);
    g.pointerDown(0, 10, 30);
    g.update(1 / 60);
    g.render();
    g.pointerMove(310, 170);
    g.update(1 / 60);
    g.render();
    g.pointerUp(0, 310, 170);
    g.update(1 / 60);
    g.render();
    press(g, "Escape");
    strict_1.default.equal(g.hud.inspect, null);
    for (let i = 0; i < 3 && !g.screens.is("system"); i++)
        press(g, "Escape");
    strict_1.default.ok(g.screens.is("system"));
    press(g, "Escape");
    g.pointerLeave();
    g.update(1 / 60);
    g.render();
});
