"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationFeed = exports.NOTE_TTL = void 0;
exports.actorName = actorName;
exports.sentence = sentence;
exports.noteForEvent = noteForEvent;
// The notification feed (pure model; drawn by view/hudHi.ts). Sim events that a
// manager needs to hear about become notes: info (the day turning, an order
// done), warn (a full pack, a worker out of power), alert (a worker blocked). A
// repeat of the same note within a few seconds is counted, not stacked. With
// "pause on alert" on (settings), an alert pauses the game (Game.onAlert).
const world_1 = require("../world/world");
const actors_1 = require("../content/actors");
const flags_1 = require("../content/flags");
exports.NOTE_TTL = { info: 6, warn: 10, alert: 16 };
class NotificationFeed {
    constructor() {
        Object.defineProperty(this, "items", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        /** Everything said this session, newest first (the system menu's log). */
        Object.defineProperty(this, "history", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        /** Shown at once. */
        Object.defineProperty(this, "max", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 6
        });
        Object.defineProperty(this, "onAlert", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "seq", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
    }
    push(text, level = "info", key = text) {
        const same = this.items.find((n) => n.key === key && n.age < 4);
        if (same) {
            same.count++;
            same.age = 0;
            same.text = text;
            return same;
        }
        const n = { id: ++this.seq, text, level, age: 0, ttl: exports.NOTE_TTL[level], count: 1, key };
        this.items.unshift(n);
        if (this.items.length > this.max)
            this.items.length = this.max;
        this.history.unshift(n);
        if (this.history.length > 80)
            this.history.length = 80;
        if (level === "alert")
            this.onAlert?.(n);
        return n;
    }
    update(dt) {
        for (const n of this.items)
            n.age += dt;
        this.items = this.items.filter((n) => n.age < n.ttl);
    }
    dismiss(id) { this.items = this.items.filter((n) => n.id !== id); }
    clear() { this.items = []; }
}
exports.NotificationFeed = NotificationFeed;
/** "BOB - WORKER GOLEM" style names, in sentence case for the v2 font. */
function actorName(a) {
    const kind = sentence((0, actors_1.actorDef)(a).name);
    return a.name ? `${sentence(a.name)} (${kind})` : kind;
}
/** "THE OLD STAIR" -> "The old stair". Mixed-case text is left alone. */
function sentence(s) {
    if (s !== s.toUpperCase())
        return s;
    const t = s.toLowerCase();
    return t.charAt(0).toUpperCase() + t.slice(1);
}
/** "noRoute" -> "no route". */
const words = (s) => s.replace(/([a-z])([A-Z])/g, "$1 $2").toLowerCase();
/** What a sim event says in the feed, if anything. Pure: the tests read it straight. */
function noteForEvent(w, e) {
    switch (e.t) {
        case "jobChanged": {
            const a = (0, world_1.actorById)(w, e.actor);
            if (!a || a.id === w.playerId)
                return null;
            const who = actorName(a);
            if (e.status === "blocked")
                return { text: `${who} is blocked${e.reason ? `: ${words(e.reason)}` : ""}`, level: "alert", key: `job:${a.id}:blocked` };
            if (e.status === "done")
                return { text: `${who} finished its order`, level: "info", key: `job:${a.id}:done` };
            if (e.status === "paused" && e.reason === "power")
                return { text: `${who} has no power`, level: "warn", key: `job:${a.id}:power` };
            return null;
        }
        case "packFull": return e.actor === w.playerId ? { text: "Your pack is full", level: "warn", key: "packFull" } : null;
        case "dayPhase": return { text: `${sentence(e.phase.toUpperCase())}, day ${e.day + 1}`, level: "info", key: `phase:${e.day}:${e.phase}` };
        case "learned": return { text: sentence((0, flags_1.learnedText)(e.flag)), level: "info", key: `learned:${e.flag}` };
        case "entranceOpened": return { text: "A way in has been opened", level: "info", key: `entrance:${e.entrance}` };
        case "powerChanged": {
            const a = (0, world_1.actorById)(w, e.actor);
            if (!a || a.id === w.playerId)
                return null;
            return { text: `${actorName(a)} ${e.powered ? "powered on" : "powered down"}`, level: e.powered ? "info" : "warn", key: `power:${a.id}` };
        }
        default: return null;
    }
}
