"use strict";
// The UI v2 font: mixed case and proportional, for the high-resolution UI layer
// (ui/gui.ts). The old bitmap font (font.ts) is uppercase-only and fixed-width;
// it stays for the world's base-resolution screens. Glyphs are a 9-row cell:
// rows 0..6 are the cap height (row 6 is the baseline row), rows 7..8 hold
// descenders; x-height is rows 2..6. One pixel of space between glyphs.
//
// Drawing goes through one atlas canvas per colour (made on first use), so a
// line of text is one drawImage per character. Measuring, wrapping and the
// glyph check are pure (the content linter and tests use them in Node).
Object.defineProperty(exports, "__esModule", { value: true });
exports.font2Rows = exports.FONT2_GLYPHS = exports.normText2 = exports.LINE_H2 = exports.CELL_H2 = void 0;
exports.fitsFont2 = fitsFont2;
exports.textWidth2 = textWidth2;
exports.clipText2 = clipText2;
exports.wrapText2 = wrapText2;
exports.drawText2 = drawText2;
exports.drawText2S = drawText2S;
/** Glyph rows, top to bottom, "|" between rows, "#" ink. */
const G = {
    A: ".##.|#..#|#..#|####|#..#|#..#|#..#", B: "###.|#..#|#..#|###.|#..#|#..#|###.",
    C: ".##.|#..#|#...|#...|#...|#..#|.##.", D: "###.|#..#|#..#|#..#|#..#|#..#|###.",
    E: "####|#...|#...|###.|#...|#...|####", F: "####|#...|#...|###.|#...|#...|#...",
    G: ".##.|#..#|#...|#.##|#..#|#..#|.###", H: "#..#|#..#|#..#|####|#..#|#..#|#..#",
    I: "###|.#.|.#.|.#.|.#.|.#.|###", J: "..##|...#|...#|...#|#..#|#..#|.##.",
    K: "#..#|#..#|#.#.|##..|#.#.|#..#|#..#", L: "#...|#...|#...|#...|#...|#...|####",
    M: "#...#|##.##|#.#.#|#.#.#|#...#|#...#|#...#", N: "#..#|##.#|##.#|#.##|#.##|#..#|#..#",
    O: ".##.|#..#|#..#|#..#|#..#|#..#|.##.", P: "###.|#..#|#..#|###.|#...|#...|#...",
    Q: ".##.|#..#|#..#|#..#|#..#|#.#.|.#.#", R: "###.|#..#|#..#|###.|#.#.|#..#|#..#",
    S: ".##.|#..#|#...|.##.|...#|#..#|.##.", T: "#####|..#..|..#..|..#..|..#..|..#..|..#..",
    U: "#..#|#..#|#..#|#..#|#..#|#..#|.##.", V: "#...#|#...#|#...#|.#.#.|.#.#.|..#..|..#..",
    W: "#...#|#...#|#...#|#.#.#|#.#.#|##.##|#...#", X: "#...#|#...#|.#.#.|..#..|.#.#.|#...#|#...#",
    Y: "#...#|#...#|.#.#.|..#..|..#..|..#..|..#..", Z: "####|...#|..#.|.#..|#...|#...|####",
    a: "....|....|.##.|...#|.###|#..#|.###", b: "#...|#...|###.|#..#|#..#|#..#|###.",
    c: "...|...|.##|#..|#..|#..|.##", d: "...#|...#|.###|#..#|#..#|#..#|.###",
    e: "....|....|.##.|#..#|####|#...|.##.", f: ".##|#..|###|#..|#..|#..|#..",
    g: "....|....|.###|#..#|#..#|#..#|.###|...#|.##.", h: "#...|#...|###.|#..#|#..#|#..#|#..#",
    i: "#|.|#|#|#|#|#", j: ".#|..|.#|.#|.#|.#|.#|.#|#.",
    k: "#...|#...|#..#|#.#.|##..|#.#.|#..#", l: "#.|#.|#.|#.|#.|#.|.#",
    m: ".....|.....|##.#.|#.#.#|#.#.#|#.#.#|#.#.#", n: "....|....|###.|#..#|#..#|#..#|#..#",
    o: "....|....|.##.|#..#|#..#|#..#|.##.", p: "....|....|###.|#..#|#..#|#..#|###.|#...|#...",
    q: "....|....|.###|#..#|#..#|#..#|.###|...#|...#", r: "...|...|#.#|##.|#..|#..|#..",
    s: "....|....|.###|#...|.##.|...#|###.", t: ".#.|.#.|###|.#.|.#.|.#.|..#",
    u: "....|....|#..#|#..#|#..#|#..#|.###", v: ".....|.....|#...#|#...#|.#.#.|.#.#.|..#..",
    w: ".....|.....|#...#|#...#|#.#.#|#.#.#|.#.#.", x: "....|....|#..#|#..#|.##.|#..#|#..#",
    y: "....|....|#..#|#..#|#..#|#..#|.###|...#|.##.", z: "....|....|####|..#.|.#..|#...|####",
    "0": ".##.|#..#|#.##|##.#|#..#|#..#|.##.", "1": ".#.|##.|.#.|.#.|.#.|.#.|###",
    "2": ".##.|#..#|...#|..#.|.#..|#...|####", "3": "###.|...#|...#|.##.|...#|...#|###.",
    "4": "..#.|.##.|#.#.|#.#.|####|..#.|..#.", "5": "####|#...|###.|...#|...#|#..#|.##.",
    "6": ".##.|#...|#...|###.|#..#|#..#|.##.", "7": "####|...#|..#.|..#.|.#..|.#..|.#..",
    "8": ".##.|#..#|#..#|.##.|#..#|#..#|.##.", "9": ".##.|#..#|#..#|.###|...#|...#|.##.",
    ".": ".|.|.|.|.|.|#", ",": "..|..|..|..|..|.#|.#|#.", ":": ".|.|.|#|.|.|#", ";": "..|..|..|.#|..|.#|.#|#.",
    "!": "#|#|#|#|#|.|#", "?": ".##.|#..#|...#|..#.|.#..|....|.#..", "'": "#|#|.|.|.|.|.", "\"": "#.#|#.#|...|...|...|...|...",
    "-": "...|...|...|...|###|...|...", "+": "...|...|...|.#.|###|.#.|...", "=": "...|...|...|###|...|###|...",
    "/": "..#|..#|.#.|.#.|.#.|#..|#..", "\\": "#..|#..|.#.|.#.|.#.|..#|..#",
    "(": ".#|#.|#.|#.|#.|#.|.#", ")": "#.|.#|.#|.#|.#|.#|#.", "[": "##|#.|#.|#.|#.|#.|##", "]": "##|.#|.#|.#|.#|.#|##",
    "<": "...|...|..#|.#.|#..|.#.|..#", ">": "...|...|#..|.#.|..#|.#.|#..",
    "%": "##...|##..#|...#.|..#..|.#...|#..##|...##", "#": ".#.#.|.#.#.|#####|.#.#.|#####|.#.#.|.#.#.",
    "*": "...|#.#|.#.|#.#|...|...|...", "_": "....|....|....|....|....|....|....|####",
    "&": ".##..|#..#.|#.#..|.#...|#.#.#|#..#.|.##.#", "@": ".###.|#...#|#.###|#.#.#|#.###|#....|.###.",
    "$": "..#..|.####|#.#..|.###.|..#.#|####.|..#..", "^": ".#.|#.#|...|...|...|...|...",
    "|": "#|#|#|#|#|#|#", "~": "....|....|....|.#.#|#.#.|....|....", "°": ".#.|#.#|.#.|...|...|...|...",
};
/** Cell height (px) and the line height (cell plus leading). */
exports.CELL_H2 = 9;
exports.LINE_H2 = 11;
/** Width of a space (px), before the 1 px gap. */
const SPACE = 3;
/** Typographic characters mapped onto the glyphs the font has. */
const NORM = { "—": "-", "–": "-", "…": "...", "’": "'", "‘": "'", "“": "\"", "”": "\"", "×": "x", "→": "->", "←": "<-", "·": ".", "\u00a0": " " };
const normText2 = (s) => s.replace(/[—–…’‘“”×→←·\u00a0]/g, (c) => NORM[c] ?? c);
exports.normText2 = normText2;
const GLYPHS = new Map();
let atlasW = 0;
for (const [ch, def] of Object.entries(G)) {
    const rows = def.split("|");
    GLYPHS.set(ch, { w: rows[0].length, rows, ax: atlasW });
    atlasW += rows[0].length + 1;
}
const FALLBACK = GLYPHS.get("?");
/** Characters the v2 font can draw (besides space). */
exports.FONT2_GLYPHS = new Set(GLYPHS.keys());
/** Every glyph's rows, for the font's own tests (rows of one glyph must be equally wide). */
const font2Rows = () => new Map([...GLYPHS].map(([k, g]) => [k, g.rows]));
exports.font2Rows = font2Rows;
/** Can the v2 font draw all of `s` (after the typographic mapping)? */
function fitsFont2(s) {
    for (const ch of (0, exports.normText2)(s))
        if (ch !== " " && ch !== "\n" && !GLYPHS.has(ch))
            return false;
    return true;
}
function textWidth2(s) {
    let w = 0, n = 0;
    for (const ch of (0, exports.normText2)(s)) {
        if (ch === "\n")
            continue;
        w += ch === " " ? SPACE : (GLYPHS.get(ch) ?? FALLBACK).w;
        n++;
    }
    return n ? w + n - 1 : 0;
}
/** Cut to `maxW` px, ending in "..." if anything was cut. */
function clipText2(s, maxW) {
    if (textWidth2(s) <= maxW)
        return s;
    let t = (0, exports.normText2)(s);
    while (t.length && textWidth2(t + "...") > maxW)
        t = t.slice(0, -1);
    return t.trimEnd() + "...";
}
/** Word-wrap to `maxW` px. "\n" breaks a line; a word longer than a line is cut. */
function wrapText2(s, maxW) {
    const out = [];
    for (const para of (0, exports.normText2)(s).split("\n")) {
        let line = "";
        for (const word of para.split(/ +/)) {
            const next = line ? `${line} ${word}` : word;
            if (textWidth2(next) <= maxW || !line)
                line = textWidth2(next) <= maxW ? next : clipText2(word, maxW);
            else {
                out.push(line);
                line = textWidth2(word) <= maxW ? word : clipText2(word, maxW);
            }
        }
        out.push(line);
    }
    return out;
}
const atlases = new Map();
/** The glyphs drawn once in `color` (null where there is no canvas: plain rects are drawn instead). */
function atlas(color) {
    if (atlases.has(color))
        return atlases.get(color);
    let img = null;
    try {
        const doc = globalThis.document;
        if (doc) {
            const c = doc.createElement("canvas");
            c.width = atlasW;
            c.height = exports.CELL_H2;
            const x = c.getContext("2d");
            if (x) {
                x.fillStyle = color;
                for (const g of GLYPHS.values())
                    g.rows.forEach((row, ry) => { for (let i = 0; i < row.length; i++)
                        if (row[i] === "#")
                            x.fillRect(g.ax + i, ry, 1, 1); });
                img = c;
            }
        }
    }
    catch {
        img = null;
    }
    atlases.set(color, img);
    return img;
}
/** Draw `s` with its top-left (or top-centre / top-right) at (x, y), in logical px of the layer. */
function drawText2(ctx, s, x, y, color, align = "left") {
    s = (0, exports.normText2)(s);
    let cx = align === "left" ? x : align === "center" ? x - textWidth2(s) / 2 : x - textWidth2(s);
    cx = Math.round(cx);
    const cy = Math.round(y), img = atlas(color);
    for (const ch of s) {
        if (ch === " ") {
            cx += SPACE + 1;
            continue;
        }
        if (ch === "\n")
            continue;
        const g = GLYPHS.get(ch) ?? FALLBACK;
        if (img)
            ctx.drawImage(img, g.ax, 0, g.w, exports.CELL_H2, cx, cy, g.w, exports.CELL_H2);
        else {
            ctx.fillStyle = color;
            g.rows.forEach((row, ry) => { for (let i = 0; i < row.length; i++)
                if (row[i] === "#")
                    ctx.fillRect(cx + i, cy + ry, 1, 1); });
        }
        cx += g.w + 1;
    }
}
/** The same with a 1 px shadow down and right. */
function drawText2S(ctx, s, x, y, color, align = "left", shadow = "#000") {
    drawText2(ctx, s, x + 1, y + 1, shadow, align);
    drawText2(ctx, s, x, y, color, align);
}
