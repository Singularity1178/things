"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InputLog = exports.IDLE = void 0;
exports.simTick = simTick;
exports.playStream = playStream;
// Deterministic replay (pure, no DOM). The play screen's input, as data: one
// TickInput per fixed tick (core/clock.ts). `simTick` is exactly what the host
// runs per tick (Game.simulate), so a save plus an input stream reproduces a run
// tick for tick, whatever the frame rate or the game speed it was played at
// (tests/timestep.test.ts plays one stream at 1x and at 8x and compares worlds).
const clock_1 = require("../core/clock");
const step_1 = require("./step");
exports.IDLE = { ix: 0, iy: 0, use: false };
/** One simulation tick as the play screen runs it: the player, play time, then the world. */
function simTick(w, input = exports.IDLE) {
    const r = (0, step_1.stepPlayer)(w, clock_1.TICK, input);
    (0, step_1.addPlayTime)(w, clock_1.TICK);
    (0, step_1.stepWorld)(w, clock_1.TICK);
    return r;
}
const same = (a, b) => a.ix === b.ix && a.iy === b.iy && !!a.use === !!b.use && !!a.attack === !!b.attack && !!a.core === !!b.core && !!a.toggleScan === !!b.toggleScan;
/** An input stream by tick index, stored as runs (a held key is one entry, not one per tick). Serializable. */
class InputLog {
    constructor() {
        Object.defineProperty(this, "runs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
    }
    record(tick, input) {
        const last = this.runs[this.runs.length - 1];
        if (last && last.from > tick)
            throw new Error("input log: ticks must be recorded in order");
        if (!last || !same(last.input, input))
            this.runs.push({ from: tick, input: { ...input } });
    }
    at(tick) {
        let lo = 0, hi = this.runs.length - 1, best = -1;
        while (lo <= hi) {
            const mid = (lo + hi) >> 1;
            if (this.runs[mid].from <= tick) {
                best = mid;
                lo = mid + 1;
            }
            else
                hi = mid - 1;
        }
        return best < 0 ? exports.IDLE : this.runs[best].input;
    }
    toJSON() { return { runs: this.runs }; }
    static fromJSON(o) { const l = new InputLog(); l.runs = o.runs.map((r) => ({ from: r.from, input: { ...r.input } })); return l; }
}
exports.InputLog = InputLog;
/**
 * Play `ticks` ticks of an input stream into `w`, driven through a SimClock at `speed` that is fed the real frame
 * times in `frames` (cycled). Events are drained each tick, as the host does. Returns the ticks run.
 */
function playStream(w, input, ticks, speed, frames, onTick) {
    const clock = new clock_1.SimClock(clock_1.TICK, 1e6);
    let t = 0, f = 0;
    while (t < ticks) {
        const n = clock.advance(frames[f++ % frames.length], speed);
        for (let i = 0; i < n && t < ticks; i++, t++) {
            simTick(w, input(t));
            w.events = [];
            onTick?.(w, t);
        }
    }
    return t;
}
