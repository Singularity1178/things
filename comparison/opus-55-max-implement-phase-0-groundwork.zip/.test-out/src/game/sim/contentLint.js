"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RULES = void 0;
exports.lintContent = lintContent;
// Content linter (pure, no DOM). Generalises the repo's data-resolution tests
// (every shop step resolves, every line fits the font) into rules run on every
// content row: display text fits the font it is drawn in, references resolve
// (items, props, stations, archetypes, routines, areas), ids are unique. Run by
// tests/soak.test.ts on every `npm test`, and by scripts/lint-content.mjs.
// Add a rule: push to RULES (docs/testing/soak.md).
const font_1 = require("../font");
const font2_1 = require("../ui/font2");
const items_1 = require("../content/items");
const props_1 = require("../content/props");
const build_1 = require("../content/build");
const crafting_1 = require("../content/crafting");
const monologue_1 = require("../content/monologue");
const dialogue_1 = require("../content/dialogue");
const talk_1 = require("../content/talk");
const shops_1 = require("../content/shops");
const harvest_1 = require("../content/harvest");
const folk_1 = require("../content/folk");
const flags_1 = require("../content/flags");
const actors_1 = require("../content/actors");
const areas_1 = require("../world/areas");
const areaSpec_1 = require("../world/areaSpec");
const settings_1 = require("../ui/settings");
/** Keys whose string values are shown to the player in the bitmap font. */
const DISPLAY = new Set(["name", "label", "desc", "description", "text", "line", "lines", "note", "closedNote", "title", "hint", "pages", "say", "says", "greet", "greeting", "idle", "farewell", "body", "caption"]);
/** The base font draws uppercase only (it uppercases what it is given); anything else shows as "?". */
const fitsFont1 = (s) => [...shown(s).toUpperCase()].every((c) => c === "\n" || font_1.FONT_GLYPHS.has(c));
/** What of a line is drawn: talk templates fill `{name}` slots at runtime, and "@table" lines stand for a line drawn from another table. */
const shown = (s) => (s.startsWith("@") ? "" : s.replace(/\{[a-z0-9_]+\}/gi, ""));
/** Every string under a display key (arrays inherit their key), as [path, text]. */
function displayStrings(v, key = "", path = "") {
    if (typeof v === "string")
        return DISPLAY.has(key) ? [[path, v]] : [];
    if (Array.isArray(v))
        return v.flatMap((x, i) => displayStrings(x, key, `${path}[${i}]`));
    if (v && typeof v === "object")
        return Object.entries(v).flatMap(([k, x]) => displayStrings(x, k, path ? `${path}.${k}` : k));
    return [];
}
/** Every `{ item: "..." }` reference inside a value, as [path, item id]. */
function itemRefs(v, path = "") {
    if (Array.isArray(v))
        return v.flatMap((x, i) => itemRefs(x, `${path}[${i}]`));
    if (v && typeof v === "object") {
        const o = v, out = [];
        if (typeof o.item === "string")
            out.push([path, o.item]);
        for (const [k, x] of Object.entries(o))
            if (k !== "item")
                out.push(...itemRefs(x, path ? `${path}.${k}` : k));
        return out;
    }
    return [];
}
const rows = (t) => (Array.isArray(t) ? t.map((r, i) => [String(r?.id ?? i), r]) : Object.entries((t ?? {})));
/** The content tables shown in the bitmap font, by name. */
const FONT1_TABLES = { ITEMS: items_1.ITEMS, PROPS: props_1.PROPS, RECIPES: build_1.RECIPES, CRAFT_RECIPES: crafting_1.CRAFT_RECIPES, STATIONS: crafting_1.STATIONS, THOUGHTS: monologue_1.THOUGHTS, DIALOGUE: dialogue_1.DIALOGUE, EXCHANGES: talk_1.EXCHANGES, SHOPS: shops_1.SHOPS, VISITS: shops_1.VISITS, LEARNED_TEXT: flags_1.LEARNED_TEXT, ACTORS: actors_1.ACTORS };
/** Tables that are plain lines (no keys) in the bitmap font. */
const LINE_TABLES = { PEER_LINES: talk_1.PEER_LINES, GRIPES: talk_1.GRIPES, NEWS: talk_1.NEWS, REACTIONS: talk_1.REACTIONS, MUTTERS: talk_1.MUTTERS };
exports.RULES = [
    {
        id: "font1", run: () => {
            const out = [];
            for (const [table, t] of Object.entries(FONT1_TABLES))
                for (const [row, r] of rows(t))
                    for (const [p, s] of displayStrings(r)) {
                        if (!fitsFont1(s))
                            out.push({ rule: "font1", table, row, problem: `${p}: "${s}" has characters the bitmap font cannot draw (${[...new Set([...shown(s).toUpperCase()].filter((c) => c !== "\n" && !font_1.FONT_GLYPHS.has(c)))].join(" ")})` });
                    }
            for (const [table, t] of Object.entries(LINE_TABLES))
                for (const [p, s] of displayStrings(t, "line")) {
                    if (!fitsFont1(s))
                        out.push({ rule: "font1", table, row: p, problem: `"${s}" has characters the bitmap font cannot draw` });
                }
            for (const [row, s] of Object.entries(flags_1.LEARNED_TEXT))
                if (typeof s === "string" && !fitsFont1(s))
                    out.push({ rule: "font1", table: "LEARNED_TEXT", row, problem: `"${s}" does not fit the bitmap font` });
            return out;
        },
    },
    {
        id: "font2", run: () => {
            const out = [];
            for (const d of (0, settings_1.settingDefs)())
                for (const s of [d.label, d.help ?? "", ...(d.options ?? []).map((o) => o.label)])
                    if (!(0, font2_1.fitsFont2)(s))
                        out.push({ rule: "font2", table: "SETTINGS", row: d.id, problem: `"${s}" does not fit the v2 font` });
            for (const a of settings_1.ACTIONS)
                if (!(0, font2_1.fitsFont2)(a.label))
                    out.push({ rule: "font2", table: "ACTIONS", row: a.id, problem: `"${a.label}" does not fit the v2 font` });
            return out;
        },
    },
    {
        id: "items", run: () => {
            const out = [];
            for (const [table, t] of Object.entries({ RECIPES: build_1.RECIPES, CRAFT_RECIPES: crafting_1.CRAFT_RECIPES, HARVEST: harvest_1.HARVEST, SHOPS: shops_1.SHOPS, VISITS: shops_1.VISITS }))
                for (const [row, r] of rows(t))
                    for (const [p, id] of itemRefs(r)) {
                        if (!(id in items_1.ITEMS))
                            out.push({ rule: "items", table, row, problem: `${p || "item"}: unknown item "${id}"` });
                    }
            return out;
        },
    },
    {
        id: "props", run: () => {
            const out = [];
            for (const [row, r] of rows(build_1.RECIPES)) {
                const k = r.prop;
                if (k && !(k in props_1.PROPS))
                    out.push({ rule: "props", table: "RECIPES", row, problem: `builds unknown prop kind "${k}"` });
            }
            for (const k of Object.keys(harvest_1.HARVEST))
                if (!(k in props_1.PROPS))
                    out.push({ rule: "props", table: "HARVEST", row: k, problem: `harvests unknown prop kind "${k}"` });
            return out;
        },
    },
    {
        id: "stations", run: () => rows(crafting_1.CRAFT_RECIPES).flatMap(([row, r]) => {
            const s = r.station;
            return s && !(s in crafting_1.STATIONS) ? [{ rule: "stations", table: "CRAFT_RECIPES", row, problem: `unknown station "${s}"` }] : [];
        }),
    },
    {
        id: "census", run: () => {
            const out = [];
            for (const r of folk_1.CENSUS) {
                if (!(r.archetype in folk_1.ARCHETYPES))
                    out.push({ rule: "census", table: "CENSUS", row: r.id, problem: `unknown archetype "${r.archetype}"` });
                if (r.routine && !(r.routine in folk_1.ROUTINES))
                    out.push({ rule: "census", table: "CENSUS", row: r.id, problem: `unknown routine "${r.routine}"` });
                if (!(r.area in areas_1.AREAS))
                    out.push({ rule: "census", table: "CENSUS", row: r.id, problem: `unknown area "${r.area}"` });
            }
            for (const [id, a] of Object.entries(folk_1.ARCHETYPES))
                for (const rt of a.routines ?? [])
                    if (!(rt in folk_1.ROUTINES))
                        out.push({ rule: "census", table: "ARCHETYPES", row: id, problem: `unknown routine "${rt}"` });
            return out;
        },
    },
    {
        id: "ids", run: () => {
            const out = [];
            for (const [table, t] of Object.entries({ CENSUS: folk_1.CENSUS, THOUGHTS: monologue_1.THOUGHTS, CRAFT_RECIPES: crafting_1.CRAFT_RECIPES })) {
                if (!Array.isArray(t))
                    continue;
                const seen = new Set();
                for (const r of t) {
                    if (!r.id)
                        continue;
                    if (seen.has(r.id))
                        out.push({ rule: "ids", table, row: r.id, problem: "duplicate id" });
                    seen.add(r.id);
                }
            }
            return out;
        },
    },
    {
        id: "areas", run: () => {
            const out = [];
            for (const id of Object.keys(areas_1.AREAS))
                if (id.startsWith("gen."))
                    out.push({ rule: "areas", table: "AREAS", row: id, problem: `authored id in the generated namespace "gen."` });
            for (const k of Object.keys(areaSpec_1.AREA_KINDS))
                if (k in areas_1.AREAS)
                    out.push({ rule: "areas", table: "AREA_KINDS", row: k, problem: "an area kind shares its name with an authored area" });
            return out;
        },
    },
];
/** Run every rule (or the named ones). An empty list means the content is clean. */
function lintContent(only) {
    return exports.RULES.filter((r) => !only || only.includes(r.id)).flatMap((r) => r.run());
}
