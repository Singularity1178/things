"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.populateResidents = populateResidents;
exports.itemCensus = itemCensus;
exports.exclusivePlace = exclusivePlace;
exports.doubleHeld = doubleHeld;
exports.roundTripDiff = roundTripDiff;
exports.runSoak = runSoak;
// Soak-test harness (pure, no DOM). Runs N in-game days (or seconds) of a town
// with M residents, headless, at the fixed tick, and checks invariants as it goes:
//
//   stuck      nobody stays walking without getting anywhere for longer than X s
//   items      no item is duplicated or deleted (a census of every pack, worn slot,
//              core, prop and loose stack is the same at the end as at the start)
//   place      no place (a spot, a lamp on the round) is held by two people
//   roundTrip  save -> load -> save gives the same save as the live world
//   budget     the mean simulation time per tick stays within the frame budget
//
// tests/soak.test.ts runs a short 300-actor soak on every `npm test`;
// scripts/soak.mjs runs long ones from the command line (docs/testing/soak.md).
const world_1 = require("../world/world");
const folk_1 = require("../content/folk");
const daycycle_1 = require("../content/daycycle");
const folk_2 = require("./folk");
const lod_1 = require("./lod");
const save_1 = require("../world/save");
const replay_1 = require("./replay");
const clock_1 = require("../core/clock");
/** Fill `area` up to `n` townsfolk, cloning its census rows (homes and routines reused, ids and people new). */
function populateResidents(w, n, area = "town") {
    (0, world_1.getArea)(w, area);
    const rows = folk_1.CENSUS.filter((r) => r.area === area);
    if (!rows.length)
        throw new Error(`no census rows for area "${area}"`);
    const have = w.actors.filter((a) => (0, folk_2.isFolk)(a) && a.person?.origin === area).length;
    const taken = new Set(w.actors.filter(folk_2.isFolk).map((a) => a.person.name.split(" ")[0]));
    const made = [];
    for (let i = have; i < n; i++) {
        const row = { ...rows[i % rows.length], id: `folk.soak.${area}.${i}` };
        const a = (0, folk_2.makeFolk)(w, row, taken);
        w.actors.push(a);
        made.push(a);
    }
    return made;
}
/** Every item in the world, by id: packs, worn gear, cores, props (on them and in them), loose stacks. `areas`: only these. */
function itemCensus(w, areas, actors = true) {
    const m = new Map(), add = (id, n = 1) => m.set(id, (m.get(id) ?? 0) + n);
    if (actors)
        for (const a of w.actors) {
            for (const s of a.inventory)
                if (s)
                    add(s.item, s.n);
            for (const it of Object.values(a.gear))
                if (it)
                    add(it);
            if (a.powerCore)
                add(a.powerCore);
        }
    for (const area of w.areas.values()) {
        if (areas && !areas.has(area.id))
            continue;
        for (const p of area.props) {
            if (p.item && !p.taken)
                add(p.item);
            for (const s of p.inventory ?? [])
                if (s)
                    add(s.item, s.n);
        }
        for (const l of area.loose)
            if (!l.taken)
                add(l.item, l.n ?? 1);
    }
    return m;
}
const inColl = (c, x) => c.includes(x);
/** Is a held place one person's at a time (content/folk.ts: EXCLUSIVE_KINDS / EXCLUSIVE_IDS, and the lamps on the round)? A household's door is not. */
function exclusivePlace(w, area, spot) {
    if (spot.startsWith("lamp:") || folk_1.EXCLUSIVE_IDS.some((p) => spot.startsWith(p)))
        return true;
    const s = w.areas.get(area)?.base.spots?.find((x) => x.id === spot);
    return !!s && inColl(folk_1.EXCLUSIVE_KINDS, s.kind);
}
/** Exclusive places held by more than one person: "area|spot" -> the holders. */
function doubleHeld(w) {
    const by = new Map();
    for (const a of w.actors) {
        if (!(0, folk_2.isFolk)(a) || !a.life.spot || !exclusivePlace(w, a.area, a.life.spot))
            continue;
        const k = `${a.area}|${a.life.spot}`;
        by.set(k, [...(by.get(k) ?? []), a.id]);
    }
    return new Map([...by].filter(([, ids]) => ids.length > 1));
}
/** Does save -> load -> save give the live world's save? (Empty string: yes; else where they first differ.) */
function roundTripDiff(w) {
    const a = JSON.stringify((0, save_1.serialize)(w));
    const b = JSON.stringify((0, save_1.serialize)((0, save_1.deserialize)(JSON.parse(a))));
    if (a === b)
        return "";
    let i = 0;
    while (i < a.length && a[i] === b[i])
        i++;
    return `differs at ${i}: ...${a.slice(Math.max(0, i - 60), i + 40)}... vs ...${b.slice(Math.max(0, i - 60), i + 40)}...`;
}
const diffCensus = (a, b) => {
    const out = [];
    for (const k of new Set([...a.keys(), ...b.keys()]))
        if ((a.get(k) ?? 0) !== (b.get(k) ?? 0))
            out.push(`${k} ${a.get(k) ?? 0} -> ${b.get(k) ?? 0}`);
    return out;
};
/** The walker's square: west into the town first (it starts at the east gate), so it stays among the people. */
const WALK = [{ ix: -1, iy: 0, use: false }, { ix: 0, iy: 1, use: false }, { ix: 1, iy: 0, use: false }, { ix: 0, iy: -1, use: false }];
function runSoak(o = {}) {
    const seed = o.seed ?? 1234, area = o.area ?? "town", stuckS = o.stuckSeconds ?? 45, budget = o.budgetMs ?? 4;
    const now = o.now ?? (() => globalThis.performance?.now?.() ?? Date.now());
    const w = (0, world_1.createWorld)(seed);
    if (o.lod !== false)
        (0, lod_1.enableLod)(w);
    w.day = Math.floor(w.day) + 1 + (o.hour ?? 12) / 24;
    const pl = (0, world_1.player)(w), at = (0, world_1.getArea)(w, area);
    (0, world_1.enterArea)(w, pl, area, at.start.x, at.start.y);
    populateResidents(w, o.residents ?? 300, area);
    w.events = [];
    const ticks = Math.max(1, Math.round((o.seconds ?? (o.days ?? 1) * daycycle_1.DAY_SECONDS) / clock_1.TICK));
    const violations = [];
    const v = (kind, detail) => { if (violations.length < 50)
        violations.push({ kind, at: w.time, detail }); };
    const before = itemCensus(w), known = new Set(w.areas.keys());
    const walking = new Map();
    const times = [];
    const tiers = { active: 0, near: 0, far: 0 };
    let firstMs = 0;
    for (let t = 0; t < ticks; t++) {
        const t0 = now();
        (0, replay_1.simTick)(w, o.walk ? WALK[Math.floor(t / 300) % 4] : replay_1.IDLE);
        const ms = now() - t0;
        if (t < Math.round(1 / clock_1.TICK))
            firstMs += ms;
        else
            times.push(ms);
        w.events.length = 0;
        if (t % 30 === 0) {
            for (const a of w.actors)
                if (a.id !== w.playerId)
                    tiers[(0, lod_1.lodTier)(w, a, pl)]++;
            // an area loaded since (the walker went through a door) comes with its builder's items: they join the census
            for (const id of w.areas.keys())
                if (!known.has(id)) {
                    known.add(id);
                    for (const [k, n] of itemCensus(w, new Set([id]), false))
                        before.set(k, (before.get(k) ?? 0) + n);
                }
            for (const a of w.actors) {
                if (!(0, folk_2.isFolk)(a))
                    continue;
                const L = a.life;
                // only people being simulated can be stuck: far ones are abstract (sim/lod.ts) and set down on re-entry
                if (L.state !== "walk" || a.area !== pl.area) {
                    walking.delete(a.id);
                    continue;
                }
                const s = walking.get(a.id);
                if (!s || Math.hypot(a.x - s.x, a.y - s.y) > 2)
                    walking.set(a.id, { x: a.x, y: a.y, since: w.time, told: false });
                else if (!s.told && w.time - s.since > stuckS) {
                    s.told = true;
                    v("stuck", `${a.id} walking in place at ${Math.round(a.x)},${Math.round(a.y)} in ${a.area} for ${Math.round(w.time - s.since)} s`);
                }
            }
            for (const [k, ids] of doubleHeld(w))
                v("place", `${k} held by ${ids.join(", ")}`);
        }
        if (o.roundTripEvery && t > 0 && t % o.roundTripEvery === 0) {
            const d = roundTripDiff(w);
            if (d)
                v("roundTrip", d);
        }
        if (o.onProgress && t % 600 === 0)
            o.onProgress(t, ticks);
    }
    for (const d of diffCensus(before, itemCensus(w)))
        v("items", d);
    const rt = roundTripDiff(w);
    if (rt)
        v("roundTrip", rt);
    const sorted = [...times].sort((a, b) => a - b), total = times.reduce((s, x) => s + x, 0);
    const ms = { mean: times.length ? total / times.length : 0, p95: sorted[Math.floor(sorted.length * 0.95)] ?? 0, max: sorted[sorted.length - 1] ?? 0, total: total + firstMs };
    if (ms.mean > budget)
        v("budget", `mean ${ms.mean.toFixed(3)} ms per tick is over the ${budget} ms budget`);
    const n = Math.max(1, Math.ceil(ticks / 30));
    return {
        seed, residents: w.actors.filter(folk_2.isFolk).length, actors: w.actors.length, ticks, simSeconds: ticks * clock_1.TICK, ms, firstMs,
        tiers: { active: tiers.active / n, near: tiers.near / n, far: tiers.far / n },
        items: [...itemCensus(w).values()].reduce((s, x) => s + x, 0), violations, ok: violations.length === 0,
    };
}
