"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_LOD = void 0;
exports.enableLod = enableLod;
exports.disableLod = disableLod;
exports.lodTier = lodTier;
exports.lodDue = lodDue;
exports.stepIn = stepIn;
exports.focusTick = focusTick;
const daycycle_1 = require("../content/daycycle");
/** The widest view is 640 x 360 world px (2x zoom); a 96 px margin keeps edge-walkers full-rate as they come in. */
exports.DEFAULT_LOD = { halfW: 320 + 96, halfH: 180 + 96, nearDt: 0.1, farDt: 0.5, maxStep: 0.1 };
function enableLod(w, policy = {}) {
    w.lod = { policy: { ...exports.DEFAULT_LOD, ...policy }, focusArea: null, counts: { active: 0, near: 0, far: 0 }, steps: 0 };
    return w.lod;
}
function disableLod(w) { w.lod = null; }
/** Which tier `a` is in this tick (the player is always active). */
function lodTier(w, a, pl) {
    if (!pl || a.id === pl.id)
        return "active";
    if (a.area !== pl.area)
        return "far";
    const P = w.lod?.policy ?? exports.DEFAULT_LOD;
    return Math.abs(a.x - pl.x) <= P.halfW && Math.abs(a.y - pl.y) <= P.halfH ? "active" : "near";
}
/**
 * Seconds to step `a` this tick (0: not this tick). `dt` is the tick just run, ending at `w.time`. Active actors
 * step every tick; near (and far ones with work) on their beat, offset per actor so the load spreads over ticks.
 */
function lodDue(w, a, tier, dt, hasWork) {
    const lod = w.lod;
    if (lod)
        lod.counts[tier]++;
    if (!lod || tier === "active")
        return dt;
    if (tier === "far" && !hasWork)
        return 0;
    const period = tier === "near" ? lod.policy.nearDt : lod.policy.farDt;
    if (dt >= period)
        return dt;
    const t1 = w.time + (0, daycycle_1.hash01)(a.id, 77) * period, t0 = t1 - dt;
    return Math.floor(t1 / period) !== Math.floor(t0 / period) ? period : 0;
}
/** Run `step` for `total` seconds in pieces no longer than the policy's `maxStep`. */
function stepIn(w, total, step) {
    const m = w.lod?.policy.maxStep ?? total;
    if (w.lod)
        w.lod.steps++;
    if (total <= m) {
        step(total);
        return;
    }
    let left = total;
    while (left > 1e-9) {
        const d = Math.min(m, left);
        step(d);
        left -= d;
    }
}
/**
 * Called by stepWorld at the start of each tick: when the player has come into another area, run the catch-up
 * hooks for the time that area went unticked. Returns the area that is in focus now.
 */
function focusTick(w, dt, area, hooks) {
    const lod = w.lod;
    if (!lod || !area)
        return;
    lod.counts = { active: 0, near: 0, far: 0 };
    lod.steps = 0;
    if (lod.focusArea === area.id)
        return;
    const elapsed = w.time - dt - area.lastTicked;
    if (lod.focusArea !== null && elapsed > 1e-6)
        for (const h of hooks)
            h(w, area, elapsed);
    lod.focusArea = area.id;
}
