"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Interpolator = void 0;
/** A move larger than this in one tick is a jump, not a walk (px). */
const SNAP = 12;
const NOOP = () => { };
class Interpolator {
    constructor() {
        /** Where between the previous tick (0) and the latest (1) to draw. */
        Object.defineProperty(this, "alpha", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        /** Off: draw exactly where the sim says (settings: "Smooth motion"). */
        Object.defineProperty(this, "enabled", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "prev", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
    }
    /** Remember where the actors of `area` stand before a tick runs. */
    capture(w, area) {
        for (const a of w.actors) {
            if (a.area !== area)
                continue;
            const p = this.prev.get(a.id);
            if (p) {
                p.area = a.area;
                p.x = a.x;
                p.y = a.y;
            }
            else
                this.prev.set(a.id, { area: a.area, x: a.x, y: a.y });
        }
    }
    clear() { this.prev.clear(); this.alpha = 1; }
    /** The position `a` is drawn at this frame (no swapping). */
    drawn(a) {
        const p = this.prev.get(a.id);
        if (!this.enabled || !p || p.area !== a.area)
            return { x: a.x, y: a.y };
        const dx = a.x - p.x, dy = a.y - p.y;
        if (Math.abs(dx) > SNAP || Math.abs(dy) > SNAP)
            return { x: a.x, y: a.y };
        return { x: p.x + dx * this.alpha, y: p.y + dy * this.alpha };
    }
    /** Swap drawn positions in for the actors of `area`; call the returned function to put the sim's back. */
    apply(w, area) {
        if (!this.enabled || this.alpha >= 1)
            return NOOP;
        const saved = [];
        for (const a of w.actors) {
            if (a.area !== area)
                continue;
            const p = this.prev.get(a.id);
            if (!p || p.area !== a.area)
                continue;
            const dx = a.x - p.x, dy = a.y - p.y;
            if ((dx === 0 && dy === 0) || Math.abs(dx) > SNAP || Math.abs(dy) > SNAP)
                continue;
            saved.push([a, a.x, a.y]);
            a.x = p.x + dx * this.alpha;
            a.y = p.y + dy * this.alpha;
        }
        if (!saved.length)
            return NOOP;
        return () => { for (const [a, x, y] of saved) {
            a.x = x;
            a.y = y;
        } };
    }
}
exports.Interpolator = Interpolator;
