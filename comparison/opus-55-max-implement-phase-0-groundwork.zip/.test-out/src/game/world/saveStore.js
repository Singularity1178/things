"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SaveStore = exports.slotName = exports.BACKUPS = exports.AUTO = exports.MANUAL_SLOTS = exports.MemoryBackend = void 0;
exports.fnv1a = fnv1a;
exports.makeRecord = makeRecord;
exports.parseRecord = parseRecord;
exports.worldOf = worldOf;
// Save system v2 (pure, no DOM). Several slots over an async key-value backend
// (IndexedDB in the browser: view/persistence.ts; memory in tests), autosave with
// rolling backups, export / import as text (a file in the browser), checksums
// and a recovery path for damaged saves.
//
// Records are cached in memory once `init()` has read them, so reads are
// synchronous (the game's load paths stay simple); writes update the cache at
// once and reach the backend asynchronously (`flush()` awaits them).
//
// Recovery: a slot that fails its checksum, does not parse, or does not load
// falls back to its backups in order (a manual slot keeps one, `<slot>.bak`, the
// copy it overwrote; the autosave keeps BACKUPS rolling copies). What was used is
// reported, never silently hidden. The legacy single localStorage slot (v1 of
// the save system) is imported into the quick slot once.
const save_1 = require("./save");
const daytime_1 = require("../sim/daytime");
/** An in-memory backend (tests, and the game before the browser store is open). */
class MemoryBackend {
    constructor() {
        Object.defineProperty(this, "map", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
    }
    async get(k) { return this.map.get(k) ?? null; }
    async set(k, v) { this.map.set(k, v); }
    async delete(k) { this.map.delete(k); }
    async keys() { return [...this.map.keys()]; }
}
exports.MemoryBackend = MemoryBackend;
/** Manual slots, in the order menus list them. "quick" is K / L. */
exports.MANUAL_SLOTS = ["quick", "slot1", "slot2", "slot3"];
exports.AUTO = "auto";
/** Rolling autosave copies kept besides the newest. */
exports.BACKUPS = 3;
const PREFIX = "save:";
const slotName = (slot) => slot === "quick" ? "Quick save" : slot.startsWith("slot") && !slot.includes(".") ? `Slot ${slot.slice(4)}`
    : slot === exports.AUTO ? "Autosave" : slot.startsWith(`${exports.AUTO}.`) ? `Autosave backup ${slot.slice(exports.AUTO.length + 1)}`
        : slot.endsWith(".bak") ? `${(0, exports.slotName)(slot.slice(0, -4))} (backup)` : slot;
exports.slotName = slotName;
/** FNV-1a over the text, as 8 hex digits: cheap, and enough to tell a damaged save from a good one. */
function fnv1a(s) {
    let h = 0x811c9dc5;
    for (let i = 0; i < s.length; i++) {
        h ^= s.charCodeAt(i);
        h = Math.imul(h, 0x01000193) >>> 0;
    }
    return h.toString(16).padStart(8, "0");
}
function makeRecord(slot, w, now, label) {
    const data = JSON.stringify((0, save_1.serialize)(w));
    const pl = w.actors.find((a) => a.id === w.playerId);
    return {
        format: "dustwake-save", v: 2,
        meta: {
            slot, label: label ?? (0, exports.slotName)(slot), savedAt: now, version: save_1.SAVE_VERSION, area: pl?.area ?? "?",
            day: Math.floor(w.day), hour: (0, daytime_1.worldHour)(w), playTime: w.playTime, size: data.length, checksum: fnv1a(data),
        },
        data,
    };
}
/**
 * Read a record from text: a v2 record, or a bare save (the legacy slot, an old export). Throws with a reason when
 * it is neither, or when the checksum does not match.
 */
function parseRecord(text, slot = "import") {
    let raw;
    try {
        raw = JSON.parse(text);
    }
    catch {
        throw new Error("not valid JSON");
    }
    const r = raw;
    if (r && r.format === "dustwake-save" && typeof r.data === "string" && r.meta) {
        if (fnv1a(r.data) !== r.meta.checksum)
            throw new Error("checksum mismatch (the save is damaged)");
        return r;
    }
    if (r && typeof r.version === "number") {
        const data = JSON.stringify(raw);
        return {
            format: "dustwake-save", v: 2, data,
            meta: { slot, label: (0, exports.slotName)(slot), savedAt: 0, version: r.version, area: "?", day: 0, hour: 0, playTime: 0, size: data.length, checksum: fnv1a(data) },
        };
    }
    throw new Error("not a Dustwake save");
}
/** A record's world (migrated, settled). Throws on anything that does not load. */
function worldOf(rec) {
    return (0, save_1.settle)((0, save_1.deserialize)(JSON.parse(rec.data)));
}
class SaveStore {
    constructor(backend, now = () => Date.now()) {
        Object.defineProperty(this, "backend", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: backend
        });
        Object.defineProperty(this, "now", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: now
        });
        Object.defineProperty(this, "cache", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        Object.defineProperty(this, "writes", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: Promise.resolve()
        });
        /** The last error a write or a load ran into (shown by the saves screen). */
        Object.defineProperty(this, "lastError", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        /** Called after an asynchronous write fails (the host notifies the player). */
        Object.defineProperty(this, "onError", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
    }
    /** Read every record into the cache. */
    async init() {
        for (const k of await this.backend.keys()) {
            if (!k.startsWith(PREFIX))
                continue;
            const v = await this.backend.get(k);
            if (v != null)
                this.cache.set(k.slice(PREFIX.length), v);
        }
    }
    /** Every stored slot, newest first, with whether it reads cleanly. */
    list() {
        const out = [];
        for (const [slot, text] of this.cache) {
            try {
                const r = parseRecord(text, slot);
                out.push({ ...r.meta, slot, ok: true });
            }
            catch (e) {
                out.push({ slot, label: (0, exports.slotName)(slot), savedAt: 0, version: 0, area: "?", day: 0, hour: 0, playTime: 0, size: text.length, checksum: "", ok: false, reason: e.message });
            }
        }
        return out.sort((a, b) => b.savedAt - a.savedAt);
    }
    has(slot) { return this.cache.has(slot); }
    meta(slot) {
        const t = this.cache.get(slot);
        if (!t)
            return null;
        try {
            return parseRecord(t, slot).meta;
        }
        catch {
            return null;
        }
    }
    /** Raw stored text (tests, and the export of a slot as it is). */
    raw(slot) { return this.cache.get(slot) ?? null; }
    /** Save `w` into a manual slot. The copy it replaces is kept as `<slot>.bak`. Throws if the world will not serialize. */
    save(slot, w, label) {
        const rec = makeRecord(slot, w, this.now(), label);
        const prev = this.cache.get(slot);
        if (prev)
            this.put(`${slot}.bak`, prev);
        this.put(slot, JSON.stringify(rec));
        return rec.meta;
    }
    /** The autosave: the newest copy in `auto`, the older ones rolled down auto.1 .. auto.BACKUPS. */
    autosave(w) {
        const rec = makeRecord(exports.AUTO, w, this.now());
        for (let i = exports.BACKUPS; i >= 1; i--) {
            const from = i === 1 ? exports.AUTO : `${exports.AUTO}.${i - 1}`, t = this.cache.get(from);
            if (t)
                this.put(`${exports.AUTO}.${i}`, t);
        }
        this.put(exports.AUTO, JSON.stringify(rec));
        return rec.meta;
    }
    /** The slots tried, in order, when loading `slot`. */
    chain(slot) {
        if (slot === exports.AUTO)
            return [exports.AUTO, ...Array.from({ length: exports.BACKUPS }, (_, i) => `${exports.AUTO}.${i + 1}`)];
        return [slot, `${slot}.bak`];
    }
    /** Load a slot, falling back along its chain. Null if nothing in it loads (lastError says why). */
    load(slot) {
        const errors = [];
        for (const s of this.chain(slot)) {
            const text = this.cache.get(s);
            if (!text)
                continue;
            try {
                const rec = parseRecord(text, s);
                const world = worldOf(rec);
                const res = { world, meta: rec.meta, from: s };
                if (s !== slot)
                    res.recovered = `${(0, exports.slotName)(slot)} could not be read (${errors[0] ?? "missing"}); loaded ${(0, exports.slotName)(s)} instead.`;
                this.lastError = null;
                return res;
            }
            catch (e) {
                errors.push(e.message);
            }
        }
        this.lastError = errors.length ? `${(0, exports.slotName)(slot)}: ${errors.join("; ")}` : `${(0, exports.slotName)(slot)} is empty`;
        return null;
    }
    /** The newest save of any slot that loads (Continue). */
    loadLatest() {
        const primary = this.list().filter((m) => !m.slot.endsWith(".bak") && !/^auto\.\d+$/.test(m.slot));
        for (const m of primary) {
            const r = this.load(m.slot);
            if (r)
                return r;
        }
        for (const m of this.list()) {
            const r = this.load(m.slot);
            if (r)
                return r;
        }
        return null;
    }
    delete(slot) {
        this.cache.delete(slot);
        this.queue(() => this.backend.delete(PREFIX + slot));
    }
    /** The text of a slot for a file (the v2 record: meta, checksum and data). */
    exportText(slot) { return this.cache.get(slot) ?? null; }
    /** Store text from a file in `slot`, after checking that it loads. Throws with the reason if it does not. */
    importText(text, slot) {
        const rec = parseRecord(text, slot);
        worldOf(rec);
        const meta = { ...rec.meta, slot, label: rec.meta.label || (0, exports.slotName)(slot) };
        const prev = this.cache.get(slot);
        if (prev)
            this.put(`${slot}.bak`, prev);
        this.put(slot, JSON.stringify({ ...rec, meta }));
        return meta;
    }
    /** The legacy single slot (localStorage "dustwake.save"): copied into the quick slot once, if that is empty. */
    importLegacy(raw) {
        if (!raw || this.cache.has("quick"))
            return false;
        try {
            this.importText(raw, "quick");
            return true;
        }
        catch (e) {
            this.lastError = `old save: ${e.message}`;
            return false;
        }
    }
    /** Wait for every write so far to reach the backend. */
    flush() { return this.writes; }
    put(slot, text) {
        this.cache.set(slot, text);
        this.queue(() => this.backend.set(PREFIX + slot, text));
    }
    queue(op) {
        this.writes = this.writes.then(op).catch((e) => {
            this.lastError = `write failed: ${e?.message ?? e}`;
            this.onError?.(this.lastError);
        });
    }
}
exports.SaveStore = SaveStore;
