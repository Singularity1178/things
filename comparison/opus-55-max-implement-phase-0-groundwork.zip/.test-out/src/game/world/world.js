"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clearFlag = exports.setFlag = exports.hasFlag = exports.actorHasFlag = exports.isBodyFlag = exports.emit = exports.currentArea = exports.areaOf = exports.actorById = exports.player = exports.hasArea = void 0;
exports.createWorld = createWorld;
exports.makeActor = makeActor;
exports.makeNpc = makeNpc;
exports.getArea = getArea;
exports.createArea = createArea;
exports.enterArea = enterArea;
exports.setActorFlag = setActorFlag;
// The World: everything that is simulated and saved. No DOM, no audio, no
// canvas. Presentation reads it and drains `events`.
const rng_1 = require("../core/rng");
const area_1 = require("./area");
const areas_1 = require("./areas");
const actors_1 = require("../content/actors");
const npcs_1 = require("../content/npcs");
const daycycle_1 = require("../content/daycycle");
const folk_1 = require("../sim/folk");
const shops_1 = require("../sim/shops");
const areaSpec_1 = require("./areaSpec");
function createWorld(seed) {
    const w = {
        seed, rng: new rng_1.SeededRng(seed), time: 0, playTime: 0, day: daycycle_1.START_HOUR / 24, flags: new Set(),
        areas: new Map(), actors: [], playerId: "golem", scheduled: [], monologue: { said: [], ready: {} }, events: [],
        specs: new Map(), lod: null,
    };
    const dungeon = getArea(w, "dungeon");
    // The player first; the dungeon's NPCs were spawned by getArea.
    w.actors.unshift(makeActor("golem", "golem", dungeon.id, dungeon.start.x, dungeon.start.y));
    return w;
}
function makeActor(id, kind, area, x, y) {
    return {
        id, kind, definition: actors_1.ACTORS[kind] ? kind : "golem", area, x, y, vx: 0, vy: 0,
        facing: "down", phase: 0, moving: false, steps: 0, task: null, queue: [], inventory: [], gear: {},
        upgrades: [], powerCore: null, mode: "normal", job: null, jobSeq: 0,
    };
}
/** An NPC actor from an area's spawn row. Its inventory starts empty (it is still per actor). */
function makeNpc(s, area) {
    const a = makeActor(s.id, npcs_1.NPCS[s.npc]?.actor ?? s.npc, area, s.x, s.y);
    a.kind = "npc";
    a.npc = s.npc;
    if (s.facing)
        a.facing = s.facing;
    return a;
}
/** Instantiate an area from its definition on first visit (and spawn its NPCs). */
function getArea(w, id) {
    let a = w.areas.get(id);
    if (!a) {
        const spec = w.specs?.get(id);
        const build = spec ? () => (0, areaSpec_1.buildFromSpec)(spec) : areas_1.AREAS[id];
        if (!build)
            throw new Error(`unknown area "${id}"`);
        a = new area_1.Area(build());
        a.lastTicked = w.time;
        // the ways down to runtime areas linked under this one (world/areaSpec.ts)
        if (w.specs?.size)
            (0, areaSpec_1.attachLinks)(w.specs.values(), a);
        if (a.base.ritual)
            a.initRitual(shuffle(w.rng, [0, 1, 2, 3]));
        w.areas.set(id, a);
        for (const s of a.base.npcs ?? [])
            if (!(0, exports.actorById)(w, s.id))
                w.actors.push(makeNpc(s, id));
        // the people who live here (content/folk.ts: CENSUS), made once from the world seed (never from w.rng)
        (0, folk_1.populateFolk)(w, id);
        // and the keeper of the shop, if this is a shop's room (sim/shops.ts)
        (0, shops_1.populateKeepers)(w, id);
    }
    return a;
}
/** Is there an area called `id`: authored (world/areas.ts) or made at runtime (a spec)? */
const hasArea = (w, id) => !!areas_1.AREAS[id] || !!w.specs?.has(id);
exports.hasArea = hasArea;
/**
 * Make an area at runtime from a spec (world/areaSpec.ts) and instantiate it. With a `link`, the parent gains its
 * way down at the link point (and keeps it across saves: the spec is saved, the link re-attached on load).
 */
function createArea(w, spec) {
    const id = spec.id ?? (0, areaSpec_1.nextSpecId)(w.specs, spec.kind, (x) => !!areas_1.AREAS[x] || w.areas.has(x));
    if ((0, exports.hasArea)(w, id))
        throw new Error(`area "${id}" already exists`);
    const full = { ...spec, id };
    w.specs.set(id, full);
    const area = getArea(w, id);
    const parent = full.link && w.areas.get(full.link.area);
    if (parent)
        (0, areaSpec_1.attachLinks)([full], parent);
    return area;
}
const player = (w) => w.actors.find((a) => a.id === w.playerId);
exports.player = player;
const actorById = (w, id) => w.actors.find((a) => a.id === id);
exports.actorById = actorById;
const areaOf = (w, a) => getArea(w, a.area);
exports.areaOf = areaOf;
/** The area the player is in — what gets rendered. */
const currentArea = (w) => (0, exports.areaOf)(w, (0, exports.player)(w));
exports.currentArea = currentArea;
/**
 * Move an actor to another area (travel). The current task ends; queued work
 * aimed at the area being left is dropped (it could only misfire elsewhere).
 * Inventory travels with the actor untouched.
 */
function enterArea(w, a, areaId, x, y) {
    getArea(w, areaId);
    a.area = areaId;
    a.x = x;
    a.y = y;
    a.vx = 0;
    a.vy = 0;
    a.task = null;
    a.queue = a.queue.filter((t) => !t.area || t.area === areaId);
    if (a.job)
        a.job.nav = null;
    (0, exports.emit)(w, { t: "areaEntered", actor: a.id, area: areaId });
}
const emit = (w, e) => { w.events.push(e); };
exports.emit = emit;
const isBodyFlag = (f) => f === "golem.arm" || f.startsWith("golem.slot.");
exports.isBodyFlag = isBodyFlag;
const actorHasFlag = (a, f) => a.upgrades.includes(f);
exports.actorHasFlag = actorHasFlag;
function setActorFlag(a, f, on = true) {
    if (on && !a.upgrades.includes(f))
        a.upgrades.push(f);
    if (!on)
        a.upgrades = a.upgrades.filter((x) => x !== f);
}
// Compatibility for the tutorial and debug keys. Body state is stored only on
// the player actor; sim rules for other actors use actorFlags requirements.
const hasFlag = (w, f) => (0, exports.isBodyFlag)(f) ? !!(0, exports.player)(w)?.upgrades.includes(f) : w.flags.has(f);
exports.hasFlag = hasFlag;
const setFlag = (w, f) => { if ((0, exports.isBodyFlag)(f))
    setActorFlag((0, exports.player)(w), f);
else
    w.flags.add(f); };
exports.setFlag = setFlag;
const clearFlag = (w, f) => { if ((0, exports.isBodyFlag)(f))
    setActorFlag((0, exports.player)(w), f, false);
else
    w.flags.delete(f); };
exports.clearFlag = clearFlag;
function shuffle(rng, perm) {
    for (let i = perm.length - 1; i > 0; i--) {
        const j = Math.floor(rng.next() * (i + 1));
        [perm[i], perm[j]] = [perm[j], perm[i]];
    }
    return perm;
}
