"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Area = void 0;
exports.unionRect = unionRect;
const tiles_1 = require("../content/tiles");
const props_1 = require("../content/props");
const items_1 = require("../content/items");
const ritual_1 = require("../content/ritual");
/** Tiles of context re-baked around a change (AO, wall rims and decals reach this far). */
const DIRTY_PAD = 2;
class Area {
    constructor(base) {
        Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "base", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "w", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "h", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "grid", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "plan", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "style", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "tvar", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "props", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "loose", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** base.decals followed by decals added during play (append-only). */
        Object.defineProperty(this, "decals", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "lights", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "ritual", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "revision", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "layoutRevision", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "interactionRevision", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "storageRevision", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        /** Id counters for things created during play (saved, so ids are never reused). */
        Object.defineProperty(this, "looseSeq", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "propSeq", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        /** World time this area's own features (the ritual's charge) were last ticked: LOD catches it up from here (sim/lod.ts). */
        Object.defineProperty(this, "lastTicked", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "listeners", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "propIndex", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        this.base = base;
        this.id = base.id;
        this.w = base.w;
        this.h = base.h;
        this.grid = base.grid.slice();
        this.plan = base.plan;
        this.style = base.style;
        this.tvar = base.tvar;
        this.decals = base.decals.slice();
        this.lights = base.lights;
        this.props = base.props.map((p) => this.instProp(p));
        this.loose = base.loose.map((l) => ({ ...l, taken: false }));
    }
    instProp(p, dyn = false) {
        // (`openBox`: a footprint that only blocks once the prop is open; sim/collision.ts: propBlocks decides)
        const bx = (0, props_1.propDef)(p.kind).box ?? (0, props_1.propDef)(p.kind).openBox;
        const inst = { ...p, open: !!p.open, taken: false, dmg: 0, box: bx ? [p.x - bx[0] / 2, p.y - bx[1], p.x + bx[0] / 2, p.y] : null };
        const storage = (0, props_1.propDef)(p.kind).storage;
        if (storage) {
            if ((p.inventory?.length ?? 0) > storage.slots)
                throw new Error("authored storage exceeds capacity");
            inst.inventory = Array.from({ length: storage.slots }, (_, i) => p.inventory?.[i] ? { ...p.inventory[i] } : null);
        }
        if (dyn)
            inst.dyn = true;
        this.propIndex.set(p.id, inst);
        return inst;
    }
    // ---- static-ish accessors (pass-through so an Area is usable as MapData)
    get rooms() { return this.base.rooms; }
    get exits() { return this.base.exits; }
    get drips() { return this.base.drips; }
    get start() { return this.base.start; }
    /** Translocation circle centre (only areas with a ritual). */
    get ritualPos() { return this.base.ritual; }
    initRitual(solution) {
        this.setRitual({
            solution, sockets: new Array(ritual_1.SOCKET_COUNT).fill(-1), core: false, carved: false,
            active: false, actT: 0, wrong: new Array(ritual_1.SOCKET_COUNT).fill(false),
        });
    }
    tile(tx, ty) {
        if (tx < 0 || ty < 0 || tx >= this.w || ty >= this.h)
            return tiles_1.T.WALL;
        return this.grid[ty * this.w + tx];
    }
    tileAtPx(px, py) { return this.tile(Math.floor(px / tiles_1.TS), Math.floor(py / tiles_1.TS)); }
    prop(id) { return this.propIndex.get(id); }
    looseItem(id) { return this.loose.find((l) => l.id === id); }
    // ---- mutations
    setTile(tx, ty, t) {
        if (tx < 0 || ty < 0 || tx >= this.w || ty >= this.h)
            return;
        this.grid[ty * this.w + tx] = t;
        this.markDirty(tx - DIRTY_PAD, ty - DIRTY_PAD, tx + DIRTY_PAD, ty + DIRTY_PAD);
    }
    addDecal(d) {
        this.decals.push(d);
        const tx = Math.floor(d.x / tiles_1.TS), ty = Math.floor(d.y / tiles_1.TS);
        this.markDirty(tx - DIRTY_PAD, ty - DIRTY_PAD, tx + DIRTY_PAD, ty + DIRTY_PAD, false);
    }
    setPropState(id, s) {
        const p = this.propIndex.get(id);
        if (!p)
            return;
        if (s.name !== undefined) {
            if (s.name)
                p.name = s.name;
            else
                delete p.name;
        }
        const layout = s.taken !== undefined && s.taken !== p.taken;
        if (s.open !== undefined)
            p.open = s.open;
        if (s.taken !== undefined)
            p.taken = s.taken;
        if (s.lit !== undefined)
            p.lit = s.lit;
        if (s.dmg !== undefined)
            p.dmg = s.dmg;
        if (s.item !== undefined)
            p.item = s.item ?? undefined;
        this.touch(layout ? "layout" : "interaction");
    }
    /** Give a prop a name of the player's own, or (`undefined`) take it back to its default label. */
    setPropName(id, name) {
        const p = this.propIndex.get(id);
        if (!p)
            return;
        if (name)
            p.name = name;
        else
            delete p.name;
        this.touch("state");
    }
    /** Harvest progress: add damage to a prop. */
    damageProp(id, n) {
        const p = this.propIndex.get(id);
        if (!p)
            return;
        p.dmg += n;
        this.touch("state");
    }
    /** Create a prop during play (building). Ids are `kind#b<n>`, never reused. */
    addProp(kind, x, y, o = {}, id) {
        const pid = id ?? `${kind}#b${this.propSeq++}`;
        if (this.propIndex.has(pid))
            throw new Error(`duplicate prop id "${pid}"`);
        const inst = this.instProp({ v: 0, ...o, id: pid, kind, x, y }, true);
        this.props.push(inst);
        this.touch("layout");
        return inst;
    }
    /**
     * Remove a prop (deconstruction). Built props simply vanish; for authored
     * props the save diff records the removal (base ids missing from the area).
     * Lights a prop owns and cached interactables follow through `revision`.
     */
    removeProp(id) {
        const p = this.propIndex.get(id);
        if (!p)
            return undefined;
        this.propIndex.delete(id);
        this.props = this.props.filter((q) => q !== p);
        this.touch("layout");
        return p;
    }
    takeLoose(id) {
        const l = this.looseItem(id);
        if (l) {
            l.taken = true;
            this.touch();
        }
    }
    /** A loose stack created during play (dropped / overflow). Ids are `drop<n>`, never reused. */
    addLoose(item, n, x, y, id) {
        const l = { id: id ?? `drop${this.looseSeq++}`, item, x, y, taken: false, dyn: true };
        if (n !== 1)
            l.n = n;
        this.loose.push(l);
        this.touch();
        return l;
    }
    setLooseCount(id, n) {
        const l = this.looseItem(id);
        if (!l)
            return;
        if (n <= 0)
            l.taken = true;
        else if (n === 1)
            delete l.n;
        else
            l.n = n;
        this.touch();
    }
    /** Atomic replacement: callers never receive a mutable storage handle. */
    setInventory(id, slots) {
        const p = this.prop(id), cap = p && (0, props_1.propDef)(p.kind).storage?.slots;
        if (!p || cap === undefined || slots.length > cap)
            throw new Error("invalid storage inventory");
        if (slots.some((s) => s && (!Number.isSafeInteger(s.n) || s.n <= 0 || s.n > (0, items_1.maxStack)(s.item))))
            throw new Error("invalid storage stack");
        p.inventory = Array.from({ length: cap }, (_, i) => slots[i] ? { ...slots[i] } : null);
        this.touch("storage");
    }
    setRitual(state) {
        this.ritual = state ? { ...state, solution: [...state.solution], sockets: [...state.sockets], wrong: [...state.wrong] } : null;
        this.touch();
    }
    updateRitual(state) {
        if (!this.ritual)
            return;
        Object.assign(this.ritual, state);
        if (state.solution)
            this.ritual.solution = [...state.solution];
        if (state.sockets)
            this.ritual.sockets = [...state.sockets];
        if (state.wrong)
            this.ritual.wrong = [...state.wrong];
        this.touch();
    }
    advanceRitual(dt) {
        if (this.ritual?.active) {
            this.ritual.actT += dt;
            this.touch("state");
        }
    }
    restoreCounters(loose, props) { this.looseSeq = loose; this.propSeq = props; }
    /** Revisions describe dependencies, not merely how often state changes. */
    touch(change = "interaction") {
        this.revision++;
        if (change === "storage")
            this.storageRevision++;
        if (change === "layout")
            this.layoutRevision++;
        if (change === "layout" || change === "interaction")
            this.interactionRevision++;
    }
    // ---- change propagation
    onChange(fn) {
        this.listeners.push(fn);
        return () => { this.listeners = this.listeners.filter((l) => l !== fn); };
    }
    markDirty(x0, y0, x1, y1, layout = true) {
        this.touch(layout ? "layout" : "state");
        const r = { x0: Math.max(0, x0), y0: Math.max(0, y0), x1: Math.min(this.w - 1, x1), y1: Math.min(this.h - 1, y1) };
        for (const l of this.listeners)
            l(r);
    }
}
exports.Area = Area;
function unionRect(a, b) {
    if (!a)
        return { ...b };
    return { x0: Math.min(a.x0, b.x0), y0: Math.min(a.y0, b.y0), x1: Math.max(a.x1, b.x1), y1: Math.max(a.y1, b.y1) };
}
