"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// tests/support/soakRun.ts
var soakRun_exports = {};
__export(soakRun_exports, {
  main: () => main
});
module.exports = __toCommonJS(soakRun_exports);

// src/game/content/folk.ts
var TRAITS = {
  early_riser: { id: "early_riser", label: "EARLY RISER", group: "clock", shift: -1.2, linger: 0.9, lines: ["UP BEFORE THE ROOSTER, AS EVER."] },
  night_owl: { id: "night_owl", label: "NIGHT OWL", group: "clock", shift: 1.2, extend: { gather: 0.6, tavern: 1 }, lines: ["THE NIGHT'S WHEN A BODY CAN THINK."] },
  sociable: { id: "sociable", label: "SOCIABLE", group: "social", chatty: 2.2, linger: 1.2, quirk: "wave", lines: ["HAVE YOU MET EVERYONE YET? YOU SHOULD."] },
  reserved: { id: "reserved", label: "RESERVED", group: "social", chatty: 0.35, linger: 0.8, notice: { range: 46, react: "wary" }, lines: ["...", "I KEEP TO MYSELF."] },
  curious: { id: "curious", label: "CURIOUS", group: "notice", notice: { range: 96, react: "approach" }, lines: ["WHAT ARE YOU MADE OF? CAN I LOOK?", "DO YOU DREAM, STONE ONE?"] },
  wary: { id: "wary", label: "WARY", group: "notice", notice: { range: 64, react: "wary" }, dawdle: 0.6, lines: ["STAY BACK A PACE, IF IT PLEASES YOU."] },
  brisk: { id: "brisk", label: "BRISK", group: "pace", speed: 1.3, linger: 0.6, dawdle: 0.3, lines: ["CAN'T STOP. TIME IS COIN."] },
  idler: { id: "idler", label: "IDLER", group: "pace", speed: 0.8, linger: 1.6, dawdle: 2.2, quirk: "stretch", lines: ["NO HURRY. THE DAY ISN'T GOING ANYWHERE."] },
  cheerful: { id: "cheerful", label: "CHEERFUL", group: "mood", chatty: 1.3, quirk: "whistle", lines: ["FINE DAY! EVERY DAY'S A FINE DAY."] },
  grumpy: { id: "grumpy", label: "GRUMPY", group: "mood", chatty: 0.6, quirk: "sigh", lines: ["HMPH.", "WHAT NOW?"] },
  restless: { id: "restless", label: "RESTLESS", group: "roam", roam: "wide", dawdle: 0.8, lines: ["I'D WALK TO THE CAPITAL IF THE ROAD WENT THAT WAY."] },
  homebody: { id: "homebody", label: "HOMEBODY", group: "roam", roam: "near", lines: ["I'VE NEVER BEEN PAST THE EAST GATE. NEVER NEEDED TO."] },
  thirsty: { id: "thirsty", label: "FOND OF ALE", group: "vice", extend: { gather: 1, tavern: 1.5 }, quirk: "sway", lines: ["FIRST ROUND'S ON YOU, CLAY-FOOT."] }
};
var Q = (kinds, prefix, nearHome) => ({ kinds, prefix, nearHome });
var HOME = Q(["door"]);
var MEET = Q(["idle", "bench"], ["idle.cross", "idle.well", "idle.statue", "idle.board", "idle.guildsteps", "idle.lamp", "bench"]);
var WANDER = Q(["wander", "idle", "bench"]);
var GATHER = Q(["gather"]);
var TAVERN = Q(["seat"]);
var ROUTINES = {
  watch_day: { id: "watch_day", blocks: [
    { from: 0, to: 5.6, act: "sleep", at: HOME },
    { from: 5.6, to: 7.4, act: "lamps" },
    { from: 7.4, to: 10.5, act: "post", at: Q(["idle"], ["watch."]) },
    { from: 10.5, to: 12.5, act: "patrol" },
    { from: 12.5, to: 13.5, act: "socialize", at: MEET },
    { from: 13.5, to: 16, act: "patrol" },
    { from: 16, to: 18.6, act: "post", at: Q(["idle"], ["watch."]) },
    { from: 18.6, to: 19.4, act: "socialize", at: MEET },
    { from: 19.4, to: 21.6, act: "lamps" },
    { from: 21.6, to: 24, act: "sleep", at: HOME }
  ] },
  watch_night: { id: "watch_night", blocks: [
    { from: 0, to: 6, act: "patrol" },
    { from: 6, to: 7.6, act: "post", at: Q(["idle"], ["watch."]) },
    { from: 7.6, to: 15, act: "sleep", at: HOME },
    { from: 15, to: 17, act: "wander", at: WANDER },
    { from: 17, to: 19.2, act: "gather", at: GATHER },
    { from: 19.2, to: 24, act: "patrol" }
  ] },
  labourer: { id: "labourer", blocks: [
    { from: 0, to: 5.4, act: "sleep", at: HOME },
    { from: 5.4, to: 6.4, act: "indoors", at: HOME },
    { from: 6.4, to: 12, act: "work", at: Q(["work"], ["work.haul", "work.dig"]) },
    { from: 12, to: 13, act: "socialize", at: Q(["bench", "gather", "idle"], ["bench.tavern", "gather", "idle.crown"]) },
    { from: 13, to: 18.2, act: "work", at: Q(["work"], ["work.haul", "work.dig"]) },
    { from: 18.2, to: 20.4, act: "gather", at: GATHER },
    { from: 20.4, to: 22.4, act: "tavern", at: TAVERN },
    { from: 22.4, to: 24, act: "sleep", at: HOME }
  ] },
  apprentice: { id: "apprentice", blocks: [
    { from: 0, to: 6, act: "sleep", at: HOME },
    { from: 6, to: 7.2, act: "errand", at: Q(["door", "customer"]) },
    { from: 7.2, to: 12, act: "work", at: Q(["work"], ["work.hammer"]) },
    { from: 12, to: 13.2, act: "wander", at: WANDER },
    { from: 13.2, to: 17, act: "work", at: Q(["work"], ["work.hammer"]) },
    { from: 17, to: 19.6, act: "socialize", at: MEET },
    { from: 19.6, to: 24, act: "sleep", at: HOME }
  ] },
  adventurer: { id: "adventurer", blocks: [
    { from: 0, to: 0.6, act: "tavern", at: TAVERN },
    { from: 0.6, to: 8, act: "sleep", at: HOME },
    { from: 8, to: 10, act: "socialize", at: Q(["idle"], ["idle.board", "idle.guildsteps", "idle.cross"]) },
    { from: 10, to: 13, act: "wander", at: WANDER },
    { from: 13, to: 15, act: "socialize", at: Q(["idle"], ["idle.board", "idle.guildsteps", "idle.cross"]) },
    { from: 15, to: 18, act: "wander", at: WANDER },
    { from: 18, to: 20, act: "gather", at: GATHER },
    { from: 20, to: 24, act: "tavern", at: TAVERN }
  ] },
  resident: { id: "resident", blocks: [
    { from: 0, to: 6, act: "sleep", at: HOME },
    { from: 6, to: 8, act: "chore", at: Q(["chore"], void 0, 3) },
    { from: 8, to: 11, act: "errand", at: Q(["customer", "door", "idle"], ["stall", "door.bakery", "door.apothecary", "idle.well"]) },
    { from: 11, to: 12.6, act: "indoors", at: HOME },
    { from: 12.6, to: 16, act: "chore", at: Q(["chore"], void 0, 3) },
    { from: 16, to: 18, act: "socialize", at: MEET },
    { from: 18, to: 20, act: "wander", at: WANDER },
    { from: 20, to: 24, act: "indoors", at: HOME }
  ] },
  elder: { id: "elder", blocks: [
    { from: 0, to: 7, act: "sleep", at: HOME },
    { from: 7, to: 9, act: "indoors", at: HOME },
    { from: 9, to: 12, act: "sit", at: Q(["bench"]) },
    { from: 12, to: 14, act: "indoors", at: HOME },
    { from: 14, to: 17, act: "socialize", at: Q(["idle", "bench"], ["idle.well", "idle.statue", "idle.cross", "bench"]) },
    { from: 17, to: 19, act: "wander", at: Q(["wander", "bench"], void 0, 6) },
    { from: 19, to: 24, act: "indoors", at: HOME }
  ] },
  hunter: { id: "hunter", blocks: [
    { from: 0, to: 4.8, act: "sleep", at: Q(["bed"]) },
    { from: 4.8, to: 6, act: "camp", at: Q(["camp"]) },
    { from: 6, to: 11, act: "hunt", at: Q(["hunt"]) },
    { from: 11, to: 12.5, act: "camp", at: Q(["camp"]) },
    { from: 12.5, to: 18, act: "hunt", at: Q(["hunt"]) },
    { from: 18, to: 22.5, act: "camp", at: Q(["camp"]) },
    { from: 22.5, to: 24, act: "sleep", at: Q(["bed"]) }
  ] },
  forager: { id: "forager", blocks: [
    { from: 0, to: 5.4, act: "sleep", at: Q(["bed"]) },
    { from: 5.4, to: 7, act: "camp", at: Q(["camp"]) },
    { from: 7, to: 12, act: "forage", at: Q(["forage"]) },
    { from: 12, to: 13, act: "camp", at: Q(["camp"]) },
    { from: 13, to: 17.5, act: "forage", at: Q(["forage"]) },
    { from: 17.5, to: 23, act: "camp", at: Q(["camp"]) },
    { from: 23, to: 24, act: "sleep", at: Q(["bed"]) }
  ] }
};
var ARCHETYPES = {
  watch: {
    id: "watch",
    title: "TOWN WATCH",
    habitat: "town",
    garb: "watch",
    speed: 19,
    routines: ["watch_day", "watch_night"],
    age: "adult",
    topics: ["bang", "sword", "moon", "mug", "ask"],
    lines: ["MOVE ALONG. NOTHING TO SEE.", "THE CHARTER STONE NEVER SLEEPS, AND NEITHER DO WE. MOSTLY.", "YOU'RE ONE OF THE OLD ONES, AREN'T YOU? FROM THE KEEP?", "KEEP TO THE STREETS AFTER DARK. THE WOODS AREN'T OURS."]
  },
  labourer: {
    id: "labourer",
    title: "LABOURER",
    habitat: "town",
    garb: "labourer",
    speed: 17,
    routines: ["labourer"],
    age: "adult",
    topics: ["stone", "mug", "coin", "laugh", "sun"],
    lines: ["YOU COULD LIFT A WAGON, YOU. WANT WORK IN THE YARD?", "THE HAULING GOLEMS NEVER TALK BACK. YOU, THOUGH...", "ACHE IN MY BACK SAYS RAIN.", "STONE DON'T CARRY ITSELF. WELL. YOURS MIGHT."]
  },
  apprentice: {
    id: "apprentice",
    title: "APPRENTICE",
    habitat: "town",
    garb: "apprentice",
    speed: 23,
    routines: ["apprentice"],
    age: "young",
    topics: ["hammer", "laugh", "ask", "coin", "heart"],
    lines: ["MASTER SAYS I'LL STRIKE MY OWN BLADE BY WINTER!", "ARE YOU A GOLEM? A REAL ONE? WHO MADE YOU?", "DON'T TELL ANYONE YOU SAW ME HERE.", "I COULD FIX THAT ARM OF YOURS. PROBABLY."]
  },
  adventurer: {
    id: "adventurer",
    title: "ADVENTURER",
    habitat: "town",
    garb: "adventurer",
    speed: 20,
    routines: ["adventurer"],
    age: "adult",
    topics: ["sword", "coin", "skull", "mug", "laugh"],
    lines: ["NOTHING ON THE GUILD BOARD BUT RAT CELLARS AGAIN.", "BETWEEN CONTRACTS. IT'S A PROFESSION, I SWEAR.", "SAW RUINS EAST OF HERE ONCE. YOU WOULDN'T KNOW ANYTHING ABOUT THAT?", "IF YOU'RE FOR HIRE, THE GUILD PAYS IN SILVER."]
  },
  resident: {
    id: "resident",
    title: "RESIDENT",
    habitat: "town",
    garb: "resident",
    speed: 18,
    routines: ["resident"],
    age: "adult",
    topics: ["bread", "heart", "sun", "coin", "ask"],
    lines: ["MIND THE WASHING, DEAR.", "THE BAKER'S LOAVES ARE SMALLER EVERY MARKET DAY.", "WESTWAKE'S QUIET. WE LIKE IT QUIET.", "MY GRANDMOTHER SAID THE KEEP'S STONE IS IN EVERY WALL HERE."]
  },
  elder: {
    id: "elder",
    title: "ELDER",
    habitat: "town",
    garb: "elder",
    speed: 11,
    routines: ["elder"],
    age: "old",
    topics: ["moon", "ask", "heart", "note", "sun"],
    lines: ["I REMEMBER WHEN THE HIGH STREET WAS MUD.", "THERE WERE STORIES OF A KEEP UNDER THE HILL. I NEVER BELIEVED THEM. NOW, HERE YOU STAND.", "SIT A WHILE. NOBODY SITS ANY MORE.", "THE STATUE BY THE WELL CAME UP FROM THE OLD STONES. IT LOOKS A BIT LIKE YOU."]
  },
  hunter: {
    id: "hunter",
    title: "HUNTER",
    habitat: "forest",
    garb: "hunter",
    speed: 19,
    routines: ["hunter"],
    age: "adult",
    topics: ["deer", "moon", "leaf", "bang", "laugh"],
    lines: ["QUIET. YOU'LL SPOOK THE DEER, STOMPING LIKE THAT.", "THE OLD CIRCLE IN THE CLEARING HUMS SOME NIGHTS. WE KEEP CLEAR.", "WESTWAKE'S A DAY'S WALK DOWN THE OLD ROAD. WE SELL PELTS THERE.", "SIT BY THE FIRE IF YOU LIKE. YOU DON'T FEEL THE COLD, I SUPPOSE."]
  },
  forager: {
    id: "forager",
    title: "FORAGER",
    habitat: "forest",
    garb: "forager",
    speed: 17,
    routines: ["forager"],
    age: "adult",
    topics: ["leaf", "bread", "sun", "heart", "ask"],
    lines: ["MUSHROOMS COME UP AFTER RAIN. NOT THE RED ONES. NEVER THE RED ONES.", "THESE WOODS FEED ANYONE WHO KNOWS WHERE TO LOOK.", "YOU'RE STEPPING ON THE SORREL.", "I'VE SEEN LIGHTS IN THE OLD STONES. GREEN ONES."]
  }
};
var NAMES = {
  given: [
    "ALDRIC",
    "BRAM",
    "CORWIN",
    "DUNCAN",
    "EDRIC",
    "FENN",
    "GARETH",
    "HOLT",
    "IVO",
    "JORAH",
    "KELL",
    "LUDO",
    "MERRICK",
    "NOLL",
    "OSRIC",
    "PIP",
    "ROLF",
    "SEB",
    "TAM",
    "WAT",
    "ADA",
    "BRYNN",
    "CATRIN",
    "DELL",
    "EDDA",
    "FAY",
    "GWEN",
    "HILDE",
    "ISOLDE",
    "JOAN",
    "KIT",
    "LIS",
    "MAUD",
    "NELL",
    "ODILE",
    "PRU",
    "ROWAN",
    "SIBYL",
    "TILDE",
    "WYNN"
  ],
  family: [
    "ASHBY",
    "BARROW",
    "COOPER",
    "DALE",
    "FLETCHER",
    "GREAVES",
    "HOLLOW",
    "KEMP",
    "MARSH",
    "PIKE",
    "REEVE",
    "SALT",
    "THATCHER",
    "WELLS",
    "WICK",
    "BRACKEN",
    "STONE",
    "FARROW",
    "HALE",
    "MOSS"
  ]
};
var CENSUS = [
  // ---- Westwake
  { id: "folk.watch.1", area: "town", archetype: "watch", home: "door.watch", routine: "watch_day", route: "high" },
  { id: "folk.watch.2", area: "town", archetype: "watch", home: "door.watch", routine: "watch_night", route: "low" },
  { id: "folk.watch.3", area: "town", archetype: "watch", home: "door.house_w1", routine: "watch_day", route: "west" },
  { id: "folk.lab.1", area: "town", archetype: "labourer", home: "door.cot_s1" },
  { id: "folk.lab.2", area: "town", archetype: "labourer", home: "door.cot_s3" },
  { id: "folk.lab.3", area: "town", archetype: "labourer", home: "door.house_l1" },
  { id: "folk.app.1", area: "town", archetype: "apprentice", home: "door.house_l2" },
  { id: "folk.app.2", area: "town", archetype: "apprentice", home: "door.cooper" },
  { id: "folk.adv.1", area: "town", archetype: "adventurer", home: "door.tavern" },
  { id: "folk.adv.2", area: "town", archetype: "adventurer", home: "door.tavern" },
  { id: "folk.res.1", area: "town", archetype: "resident", home: "door.cot_well_w" },
  { id: "folk.res.2", area: "town", archetype: "resident", home: "door.bakery" },
  { id: "folk.res.3", area: "town", archetype: "resident", home: "door.house_l3" },
  { id: "folk.res.4", area: "town", archetype: "resident", home: "door.cot_s2" },
  { id: "folk.res.5", area: "town", archetype: "resident", home: "door.townhouse_h" },
  { id: "folk.eld.1", area: "town", archetype: "elder", home: "door.cot_old" },
  { id: "folk.eld.2", area: "town", archetype: "elder", home: "door.cot_well_e" },
  // ---- the hunters' camp in the north-west wood
  { id: "folk.hunt.1", area: "surface", archetype: "hunter", home: "bed.1" },
  { id: "folk.hunt.2", area: "surface", archetype: "hunter", home: "bed.2" },
  { id: "folk.forage.1", area: "surface", archetype: "forager", home: "bed.3" }
];
var ROUTES = {
  town: {
    high: ["patrol.watchhouse", "patrol.gate", "patrol.high.e", "patrol.square.ne", "patrol.square.nw", "patrol.high.w", "patrol.bar"],
    low: ["patrol.watchhouse", "patrol.high.e", "patrol.yard.n", "patrol.low.e", "patrol.low.mid", "patrol.tavern", "patrol.low.w", "patrol.lane.w", "patrol.high.w", "patrol.square.nw", "patrol.square.ne"],
    west: ["patrol.bar", "patrol.high.w", "patrol.lane.n", "patrol.old.w", "patrol.old.e", "patrol.lane.n", "patrol.square.nw", "patrol.square.ne", "patrol.high.e"]
  }
};
var FOLK_INTERIORS = {
  tavern: { area: "town_tavern", door: "door.tavern" },
  smithy: { area: "town_smithy", door: "door.smithy" },
  armory: { area: "town_armory", door: "door.armory" },
  jeweler: { area: "town_jeweler", door: "door.jeweler" },
  tailor: { area: "town_tailor", door: "door.tailor" },
  guild: { area: "town_guild", door: "door.guild" }
};
var INTERIOR_OF = { tavern: "tavern" };
var HABITAT_AREAS = { town: ["town", "town_tavern", "town_smithy", "town_armory", "town_jeweler", "town_tailor", "town_guild"], forest: ["surface"] };
var EXCLUSIVE_KINDS = ["seat", "bench", "work", "chore", "bed", "camp", "hunt", "forage", "stall", "customer", "keeper", "gather", "browse", "queue"];
var EXCLUSIVE_IDS = ["watch."];
var ACTIVITY_LINES = {
  work: ["CAN'T TALK LONG. WORK WON'T WAIT."],
  chore: ["THESE CHORES WON'T DO THEMSELVES."],
  gather: ["COME FOR A DRINK? OH. YOU DON'T, DO YOU."],
  tavern: ["PULL UP A STOOL. CAREFUL, THEY'RE NOT MADE FOR YOUR SORT."],
  lamps: ["EVERY LAMP IN ITS TURN. THE RUNES LIGHT THEMSELVES. THESE DON'T."],
  patrol: ["ON MY ROUND. ALL QUIET."],
  sit: ["AH, THE SUN ON THESE OLD BONES."],
  hunt: ["SHH."],
  camp: ["WARM YOURSELF. OR WHATEVER IT IS YOU DO."],
  shop: ["JUST LOOKING. SAME AS YOU, I'D GUESS.", "MIND THE SHELVES, BIG ONE."],
  board: ["READING THE BOARD. NOTHING FOR YOUR SORT. YET."]
};

// src/game/content/daycycle.ts
var DAY_SECONDS = 720;
var DAY_HOURS = { dawn: 5, sunrise: 7, dusk: 19, nightfall: 21 };
var START_HOUR = 22.5;
var FIRST_ARRIVAL_HOUR = 4;
var wrapHour = (h) => (h % 24 + 24) % 24;
var hourOf = (day) => wrapHour((day - Math.floor(day)) * 24);
function phaseAt(hour) {
  const h = wrapHour(hour), D = DAY_HOURS;
  return h < D.dawn ? "night" : h < D.sunrise ? "dawn" : h < D.dusk ? "day" : h < D.nightfall ? "dusk" : "night";
}
function hash01(id, salt = 0) {
  let h = (2166136261 ^ Math.imul(salt + 1, 2654435761)) >>> 0;
  for (let i = 0; i < id.length; i++) {
    h ^= id.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  h ^= h >>> 15;
  h = Math.imul(h, 739982445) >>> 0;
  h ^= h >>> 12;
  return (h >>> 0) / 4294967296;
}

// src/game/core/rng.ts
function mulberry(seed) {
  let a = seed >>> 0;
  return () => {
    a = a + 1831565813 >>> 0;
    let t = a;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
var SeededRng = class {
  state;
  constructor(seed) {
    this.state = seed >>> 0;
  }
  next() {
    this.state = this.state + 1831565813 >>> 0;
    let t = this.state;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  }
};
function hash2(x, y, s = 0) {
  let h = x * 374761393 + y * 668265263 + s * 982451653 | 0;
  h = Math.imul(h ^ h >>> 13, 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

// src/game/content/tiles.ts
var TS = 16;
var T = {
  WALL: 0,
  FLOOR: 1,
  RUBBLE: 2,
  CRACKED: 3,
  LOCKED: 4,
  PILLAR: 5,
  BARS: 6,
  /** Surface: impassable undergrowth at the edge of the world. */
  THICKET: 7,
  // 8 was PIT (surface sinkholes into the dungeon); retired, the dungeon is hidden now.
  /**
   * Town: the street-level storey of a building front. Solid like a wall, but it
   * does not block light, so a lamp in the street lights the whole of a
   * two-storey front (the wall mass behind it still stops the light).
   */
  FRONT: 9
};
var FS = {
  FLAG: 0,
  MARBLE: 1,
  BRICK: 2,
  WOOD: 3,
  COBBLE: 4,
  /** Surface ground styles (7 was RUIN, the keep's masonry; retired). */
  GRASS: 5,
  DIRT: 6,
  /** Soft cushion moss (damp ground, buried stone). */
  MOSS: 8,
  /** Fallen leaves under the trees. */
  LEAF: 9,
  /** Wet mud in damp hollows. */
  MUD: 10,
  /** Bare, packed earth (heaped soil over the buried halls; spilled earth below ground). */
  EARTH: 11,
  // ---- the market town (pixels in art/tilesTown.ts)
  /** Dressed stone setts: the lit, well-kept streets and the market square's border. */
  SETT: 12,
  /** Basket-weave brick paving: the market square. */
  WEAVE: 13,
  /** Broad, waxed floorboards (the tavern, the tailor). */
  BOARD: 14,
  /** Pale glazed tiles with dark insets (the high-end shops). */
  TILE: 15,
  /** A flight of stone steps climbing to the south (the stair from the halls up to the surface). */
  STAIR: 16
};
var WS = {
  /** Limewashed plaster over a timber wainscot. */
  PLASTER: 20,
  /** Warm dressed ashlar. */
  STONE: 21,
  /** Dark oak panelling. */
  PANEL: 22,
  /** Soot-stained brick. */
  BRICK: 23,
  /** The town wall, outdoors: a mossy ashlar face and a paved wall-walk on top. */
  RAMPART: 24
};
var isSolidT = (t) => t !== T.FLOOR;
var TILE_INTERACT = {
  [T.LOCKED]: { kind: "door", dx: -2, dy: 10, r: 18, openDecal: { kind: "door_open", dx: 11, dy: -12 } },
  [T.CRACKED]: {
    kind: "cracked",
    dx: 8,
    dy: 16,
    r: 22,
    anchorTopOfRun: true,
    breakDebris: { count: 26, dxTiles: -2, dyTiles: -0.4, w: 64, h: 40 }
  }
};

// src/game/content/town.ts
var TOWN_ID = "town";
var TOWN_W = 96;
var TOWN_H = 68;
var TOWN_NAME = "WESTWAKE";
var FRONT_H = 32;
var WIN = { w: 10, h: 9, top: 14 };
var UPWIN = { w: 6, h: 7, top: 3 };
var DOOR = { plain: { w: 12, h: 19 }, double: { w: 20, h: 21 }, hauler: { w: 28, h: 24 } };
var B = (id, x, y, w, h, wall, roof, tint, light, o = {}) => ({ id, x, y, w, h, wall, roof, tint, light, ...o });
var STREETS = {
  /** East gate -> market square -> west bar. */
  high: { y0: 30, y1: 32 },
  square: { x0: 37, y0: 27, x1: 57, y1: 37 },
  oldLane: { y0: 15, y1: 16 },
  low: { y0: 45, y1: 47 },
  back: { y0: 58, y1: 60 },
  /**
   * The town wall: a closed ring of the sunken keep's stone, two tiles thick
   * (the north and south runs carry a third row, the south face of the wall).
   * `x0..x1` is the east run and `westX0..westX1` the west; the High Street
   * passes through both on rows `gateY0..gateY1`, between a pair of towers
   * each (the east gate and the West Bar). Inside the ring is the town; outside
   * it the ground simply runs to the edge of the map and stops.
   */
  wall: { x0: 88, x1: 89, westX0: 4, westX1: 5, northY0: 2, northY1: 4, southY0: 63, southY1: 65, gateY0: 30, gateY1: 32 }
};
var BUILDINGS = [
  // ---- the old quarter and the north row (fronts on Old Lane)
  B("cot_well_w", 8, 9, 6, 6, "daub", "thatch", 0, "torch", { door: { col: 2 }, win: [0, 4], lit: [4], chimney: 4 }),
  B("cot_well_e", 15, 9, 6, 6, "daub", "thatch", 1, "none", { door: { col: 3 }, win: [1, 5], chimney: 1 }),
  B("cot_old", 31, 9, 6, 6, "timber", "thatch", 2, "torch", { door: { col: 2 }, win: [0, 4], lit: [0] }),
  B("bakery", 39, 9, 7, 6, "timber", "tile", 3, "torch", { door: { col: 3 }, win: [1, 5], lit: [1, 5], chimney: 5, sign: "sign_bakery" }),
  B("house_n", 48, 9, 6, 6, "timber", "tile", 0, "torch", { door: { col: 2 }, win: [0, 4], lit: [4], chimney: 1 }),
  B("townhouse_w", 56, 8, 7, 7, "stone", "slate", 1, "rune", { ridge: "ns", door: { col: 3 }, win: [1, 5], lit: [1, 5] }),
  B("townhouse_e", 65, 8, 7, 7, "timber", "slate", 4, "rune", { door: { col: 3 }, win: [1, 5], lit: [5], chimney: 1 }),
  B("reeve", 74, 7, 11, 8, "stone", "slate", 2, "rune", { door: { col: 5, kind: "double" }, win: [1, 3, 7, 9], lit: [3, 7], chimney: 9, dormers: [2, 5, 8], sign: "sign_reeve" }),
  // ---- the bright side: north of the square and the High Street
  B("tailor", 35, 20, 6, 7, "timber", "slate", 5, "rune", { ridge: "ns", door: { col: 2 }, win: [0, 4], lit: [0, 4], sign: "sign_tailor", interior: "town_tailor", name: "THE SILVER NEEDLE" }),
  B("guild", 42, 18, 11, 9, "stone", "slate", 0, "rune", { door: { col: 5, kind: "double" }, win: [1, 3, 7, 9], lit: [1, 3, 7, 9], chimney: 9, dormers: [2, 5, 8], sign: "sign_guild", interior: "town_guild", name: "ADVENTURERS' GUILD" }),
  B("jeweler", 54, 20, 6, 7, "stone", "slate", 3, "rune", { ridge: "ns", door: { col: 3 }, win: [1, 5], lit: [1, 5], sign: "sign_jeweler", interior: "town_jeweler", name: "THE BRIGHT FACET" }),
  B("house_w1", 10, 24, 6, 6, "timber", "shingle", 1, "torch", { door: { col: 3 }, win: [1, 5], lit: [1], chimney: 0 }),
  B("house_w2", 17, 24, 6, 6, "timber", "tile", 4, "none", { door: { col: 2 }, win: [0, 4] }),
  B("apothecary", 25, 23, 7, 7, "timber", "tile", 2, "torch", { ridge: "ns", door: { col: 3 }, win: [1, 5], lit: [1, 5], chimney: 6, sign: "sign_apothecary" }),
  B("armory", 63, 22, 7, 8, "stone", "slate", 4, "rune", { door: { col: 3 }, win: [1, 5], lit: [1, 5], dormers: [1, 5], sign: "sign_armory", interior: "town_armory", name: "THE GILDED BUCKLER" }),
  B("townhouse_h", 72, 24, 6, 6, "timber", "slate", 0, "rune", { door: { col: 2 }, win: [0, 4], lit: [0, 4] }),
  B("watch", 80, 24, 6, 6, "stone", "slate", 1, "rune", { door: { col: 3 }, win: [1, 5], lit: [1], sign: "sign_watch" }),
  // ---- the low side: fronts on Low Street
  B("stable", 9, 38, 10, 7, "plank", "shingle", 0, "none", { door: { col: 4, kind: "hauler" }, win: [1, 8], sign: "sign_stable" }),
  B("house_l1", 24, 39, 6, 6, "timber", "shingle", 3, "torch", { door: { col: 2 }, win: [0, 4], lit: [4], chimney: 5 }),
  B("house_l2", 31, 39, 4, 6, "daub", "thatch", 2, "none", { door: { col: 1 }, win: [3] }),
  B("tavern", 36, 38, 10, 7, "timber", "tile", 1, "torch", { door: { col: 4, kind: "double" }, win: [1, 2, 7, 8], lit: [1, 2, 7, 8], chimney: 8, dormers: [2, 6], sign: "sign_tavern", interior: "town_tavern", name: "THE SUNKEN CROWN" }),
  B("smithy", 50, 38, 8, 7, "brick", "shingle", 0, "torch", { door: { col: 3 }, win: [1, 6], lit: [1, 6], chimney: 6, sign: "sign_smithy", interior: "town_smithy", name: "THE BLACK ANVIL" }),
  B("house_l3", 64, 39, 6, 6, "timber", "tile", 4, "torch", { door: { col: 3 }, win: [1, 5], lit: [1] }),
  B("house_l4", 71, 39, 6, 6, "timber", "shingle", 0, "none", { ridge: "ns", door: { col: 2 }, win: [0, 4], chimney: 4 }),
  B("cooper", 78, 39, 5, 6, "plank", "shingle", 1, "torch", { door: { col: 2, kind: "double" }, win: [0, 4], lit: [0], sign: "sign_cooper" }),
  // ---- the back lane: cottages, a house going up, the warehouse, the golem stands
  B("cot_s1", 9, 52, 6, 6, "daub", "thatch", 1, "torch", { door: { col: 2 }, win: [4], lit: [4] }),
  B("cot_s2", 16, 52, 5, 6, "daub", "thatch", 0, "none", { door: { col: 2 }, win: [0], chimney: 4 }),
  B("cot_s3", 24, 52, 6, 6, "daub", "shingle", 2, "torch", { door: { col: 3 }, win: [1], lit: [1] }),
  B("cot_s4", 31, 52, 5, 6, "timber", "thatch", 3, "none", { door: { col: 2 }, win: [4] }),
  B("site", 38, 51, 6, 7, "frame", "flat", 0, "none"),
  B("warehouse", 50, 50, 10, 8, "plank", "shingle", 2, "none", { door: { col: 4, kind: "hauler" }, win: [1, 8], sign: "sign_warehouse" }),
  B("stands", 72, 49, 10, 5, "bays", "shingle", 0, "none"),
  // ---- the east gate's two towers (the wall between and beyond them is tiles)
  B("gate_n", 87, 25, 4, 5, "tower", "flat", 0, "rune"),
  B("gate_s", 87, 33, 4, 5, "tower", "flat", 1, "rune"),
  // ---- and the West Bar's: the same gate at the other end of the High Street
  B("bar_n", 3, 25, 4, 5, "tower", "flat", 1, "rune"),
  B("bar_s", 3, 33, 4, 5, "tower", "flat", 0, "rune")
];
var building = (id) => {
  const b = BUILDINGS.find((x) => x.id === id);
  if (!b) throw new Error(`no building "${id}"`);
  return b;
};
var roofH = (b) => b.h * 16 - FRONT_H;
var ridgeY = (b) => Math.max(5, Math.round(roofH(b) * 0.28));
function chimneyPx(b) {
  if (b.chimney === void 0) return null;
  const y = b.ridge === "ns" ? Math.round(roofH(b) * 0.3) : Math.max(1, ridgeY(b) - 8);
  return { x: (b.x + b.chimney) * 16 + 8, y: b.y * 16 + y };
}
var dormerPx = (b, col) => ({ x: (b.x + col) * 16 + 8, y: b.y * 16 + roofH(b) - 9 });
function doorPx(b) {
  const kind = b.door?.kind ?? "plain", col = b.door?.col ?? 0;
  return { x: (b.x + col) * 16 + (kind === "hauler" ? 16 : 8), y: (b.y + b.h) * 16, kind };
}
var ESTABLISHMENTS = ["smithy", "armory", "jeweler", "tailor", "tavern", "guild"];
var interiorId = (e) => `town_${e}`;
var HIGH_END = { smithy: false, armory: true, jeweler: true, tailor: true, tavern: false, guild: true };
var SIGNS = [
  ["sign_smithy", "A BLACK ANVIL ON A HANGING BOARD. THE BLACK ANVIL: HARROW AND SONS, SMITHS."],
  ["sign_armory", "A GILT SHIELD, FRESHLY PAINTED. THE GILDED BUCKLER: ARMS AND HARNESS, FITTED TO ORDER."],
  ["sign_jeweler", "A CUT GEM IN A BRASS RING. THE BRIGHT FACET: STONES SET, WEIGHED AND VALUED."],
  ["sign_tailor", "A NEEDLE AND A LOOP OF SILVER THREAD. THE SILVER NEEDLE: CLOTHIERS."],
  ["sign_tavern", "A CROWN, HALF UNDER A WAVY LINE. THE SUNKEN CROWN. ALE, STEW, BEDS."],
  ["sign_guild", "A SWORD LAID OVER A COMPASS ROSE. ADVENTURERS' GUILD, WESTWAKE CHAPTER. CHARTERED BY THE ALIGARCH THRONE."],
  ["sign_bakery", "A ROUND LOAF. THE OVEN BEHIND THIS WALL IS STILL WARM."],
  ["sign_apothecary", "A MORTAR AND PESTLE. DRIED HERBS HANG IN THE WINDOW."],
  ["sign_reeve", "THE REEVE'S HALL. TOLLS, TITHES AND GRIEVANCES, IN THAT ORDER."],
  ["sign_watch", "THE GATE WATCH. A SLATE BY THE DOOR LISTS WHO CAME IN TODAY, AND WHAT THEY HAULED."],
  ["sign_stable", "A HORSESHOE. STABLING BY THE NIGHT. THE BIG DOOR IS CUT FOR MORE THAN HORSES."],
  ["sign_cooper", "A BARREL HOOP AND A WHEEL. COOPER AND WHEELWRIGHT."],
  ["sign_warehouse", "MARKET STORE. THE DOORS ARE TWICE A MAN'S WIDTH, AND THE SILL IS WORN DOWN IN TWO FLAT TRACKS."]
];
var FS_ = (id, kind, x, y, facing = "down") => ({ id, kind, x, y, facing });
var TOWN_FOLK_SPOTS = [
  // the tavern door at dusk: a loose knot of people on Low Street, never in the doorway itself
  FS_("gather.1", "gather", 614, 750, "right"),
  FS_("gather.2", "gather", 632, 760, "up"),
  FS_("gather.3", "gather", 654, 763, "up"),
  FS_("gather.4", "gather", 676, 757, "left"),
  FS_("gather.5", "gather", 690, 745, "left"),
  FS_("gather.6", "gather", 600, 740, "right"),
  // benches (sitting on them: the spot is the seat, the sitter faces the street)
  FS_("bench.well", "bench", 414, 240, "down"),
  FS_("bench.garden", "bench", 1216, 344, "down"),
  FS_("bench.tavern", "bench", 702, 733, "down"),
  // a stroll: corners of the square, the lanes, the gardens
  FS_("wander.sq.1", "wander", 616, 474),
  FS_("wander.sq.2", "wander", 904, 474),
  FS_("wander.sq.3", "wander", 896, 586, "up"),
  FS_("wander.sq.4", "wander", 616, 600, "up"),
  FS_("wander.high.1", "wander", 1e3, 516),
  FS_("wander.high.2", "wander", 1240, 512),
  FS_("wander.high.3", "wander", 470, 514),
  FS_("wander.high.4", "wander", 260, 516),
  FS_("wander.old.1", "wander", 300, 262),
  FS_("wander.old.2", "wander", 700, 262),
  FS_("wander.old.3", "wander", 860, 258),
  FS_("wander.low.1", "wander", 480, 752),
  FS_("wander.low.2", "wander", 820, 754),
  FS_("wander.low.3", "wander", 1140, 750),
  FS_("wander.back.1", "wander", 360, 950),
  FS_("wander.back.2", "wander", 760, 958),
  FS_("wander.ne.1", "wander", 1140, 300),
  FS_("wander.ne.2", "wander", 1300, 300),
  // household chores, each beside the thing it needs
  FS_("chore.chop.1", "chore", 240, 262),
  FS_("chore.chop.2", "chore", 1238, 612, "left"),
  FS_("chore.chop.3", "chore", 326, 824, "left"),
  FS_("chore.chop.4", "chore", 958, 676),
  FS_("chore.hang.1", "chore", 178, 138, "down"),
  FS_("chore.hang.2", "chore", 1093, 618, "down"),
  FS_("chore.hang.3", "chore", 514, 618, "down"),
  FS_("chore.hang.4", "chore", 226, 826, "down"),
  FS_("chore.feed.1", "chore", 610, 252, "up"),
  FS_("chore.feed.2", "chore", 1294, 616, "up"),
  FS_("chore.feed.3", "chore", 500, 826, "left"),
  FS_("chore.draw.1", "chore", 400, 216, "right"),
  FS_("chore.sweep.1", "chore", 680, 266),
  FS_("chore.sweep.2", "chore", 1176, 746),
  FS_("chore.sweep.3", "chore", 440, 954),
  FS_("chore.hoe.1", "chore", 430, 588),
  FS_("chore.hoe.2", "chore", 1040, 588),
  FS_("chore.hoe.3", "chore", 186, 806),
  FS_("chore.hoe.4", "chore", 420, 806),
  // the stone yard and the building site: carrying and digging
  FS_("work.haul.1", "work", 1040, 852, "up"),
  FS_("work.haul.2", "work", 1180, 774),
  FS_("work.haul.3", "work", 1056, 946, "up"),
  FS_("work.haul.4", "work", 740, 890, "up"),
  FS_("work.dig.1", "work", 660, 948),
  FS_("work.dig.2", "work", 1150, 870, "left"),
  // the smithy's yard: the apprentices' anvil work
  FS_("work.hammer.1", "work", 968, 709, "up"),
  FS_("work.hammer.3", "work", 1300, 746, "up"),
  // the watch's rounds
  FS_("patrol.watchhouse", "patrol", 1336, 512),
  FS_("patrol.gate", "patrol", 1384, 508, "right"),
  FS_("patrol.high.e", "patrol", 1150, 514),
  FS_("patrol.square.ne", "patrol", 940, 470),
  FS_("patrol.square.nw", "patrol", 582, 470),
  FS_("patrol.high.w", "patrol", 400, 514),
  FS_("patrol.bar", "patrol", 150, 510, "left"),
  FS_("patrol.yard.n", "patrol", 1130, 680),
  FS_("patrol.low.e", "patrol", 1250, 752),
  FS_("patrol.low.mid", "patrol", 900, 756),
  FS_("patrol.tavern", "patrol", 700, 760),
  FS_("patrol.low.w", "patrol", 400, 754),
  FS_("patrol.lane.w", "patrol", 352, 620),
  FS_("patrol.lane.n", "patrol", 544, 360),
  FS_("patrol.old.w", "patrol", 200, 260),
  FS_("patrol.old.e", "patrol", 820, 262)
];

// src/game/content/geography.ts
var DUNGEON_TO_SURFACE = { dx: 12, dy: 6 };
var dungeonToSurface = (x, y) => ({ x: x + DUNGEON_TO_SURFACE.dx, y: y + DUNGEON_TO_SURFACE.dy });
var GATE_CORRIDOR = { x: 34, y: 50, w: 4, h: 5 };
var GATE_EXIT = { x: 36, y: 55 };
var GATE_PASSAGE = { x: GATE_CORRIDOR.x, y: GATE_CORRIDOR.y, w: GATE_CORRIDOR.w, h: GATE_CORRIDOR.h + 1 };
var GATE_HALL = { x: GATE_PASSAGE.x, y: GATE_PASSAGE.y, w: GATE_PASSAGE.w, h: 2 };
var GATE_STAIR = { x: GATE_PASSAGE.x, y: GATE_HALL.y + GATE_HALL.h, w: GATE_PASSAGE.w, h: GATE_PASSAGE.h - GATE_HALL.h };
var STAIR_CHEEK = { post: { w: 12, d: 7, lift: 7 }, wall: { w: 8 } };
var STAIR_CHEEK_TOP = STAIR_CHEEK.post.d - STAIR_CHEEK.post.lift;
var ENTRANCES = {
  surface_stair: {
    flag: "entrance.surface_stair.open",
    above: { area: "surface", portal: "stair_down" },
    below: { area: "dungeon", portal: "stair_up", clear: GATE_PASSAGE, removes: ["rockpile", "stairfall"], lights: "stairlight" }
  }
};
var SURFACE_GATE = dungeonToSurface(GATE_EXIT.x, GATE_EXIT.y);
var SURFACE_GATE_CORRIDOR = { ...dungeonToSurface(GATE_CORRIDOR.x, GATE_CORRIDOR.y), w: GATE_CORRIDOR.w, h: GATE_CORRIDOR.h };
var SURFACE_GATE_ZONE = {
  x0: SURFACE_GATE_CORRIDOR.x - 1,
  x1: SURFACE_GATE_CORRIDOR.x + SURFACE_GATE_CORRIDOR.w,
  y0: SURFACE_GATE_CORRIDOR.y - 1,
  y1: SURFACE_GATE.y + 1
};
var WEST_ROAD = { surface: { y0: 33, y1: 35 }, portal: "west_road" };

// src/game/content/props.ts
var RUNE_COL = [0.62, 0.8, 1];
var FIRE_COL = [1, 0.64, 0.33];
var TOWN_PROPS = {
  // ---- light runes: the streets and shops that can pay for them
  rune_lamp: { box: [6, 4], habit: "rune", light: { dx: 0, dy: -14, rad: 118, col: RUNE_COL, int: 0.95, flick: 0, when: "always" } },
  rune_sconce: { wallMounted: true, habit: "rune", light: { dx: 0, dy: 8, rad: 124, col: RUNE_COL, int: 0.9, flick: 0, when: "always" } },
  runestand: { box: [8, 4], light: { dx: 0, dy: -6, rad: 116, col: RUNE_COL, int: 0.85, flick: 0, when: "always" } },
  // ---- fire: everyone else (plus the dungeon's wall torch and the surface's torch post, as they are)
  lantern: { wallMounted: true, habit: "fire", light: { dx: 0, dy: 8, rad: 96, col: FIRE_COL, int: 0.85, flick: 0.16, when: "always" } },
  /** An iron stand of tallow candles: what a room burns when it cannot hang a light rune. */
  candlestand: { box: [6, 4], light: { dx: 0, dy: -6, rad: 104, col: FIRE_COL, int: 0.85, flick: 0.14, when: "always" } },
  // ---- a window with a light behind it, laid over the painted window (variants: fire / rune, ground floor / upper)
  winglow: { wallMounted: true, habit: "window", light: { dx: 0, dy: 12, rad: 46, col: [1, 0.68, 0.36], int: 0.5, flick: 0.07, when: "always" } },
  winglow_rune: { wallMounted: true, art: "winglow", habit: "window", light: { dx: 0, dy: 12, rad: 52, col: RUNE_COL, int: 0.5, flick: 0, when: "always" } },
  winglow_up: { wallMounted: true, art: "winglow", habit: "window" },
  // ---- hanging signs: one art, a kind per house so each reads its own line (content/town.ts: SIGNS)
  shopsign: { wallMounted: true },
  ...Object.fromEntries(SIGNS.map(([kind, text2]) => [kind, { wallMounted: true, art: "shopsign", examine: text2 }])),
  // ---- landmarks: the town's history, in the order it happened
  well: { box: [20, 10], examine: "THE OLD VILLAGE WELL. THE RIM IS WORN SMOOTH BY MORE HANDS THAN YOU CAN COUNT. THE TOWN GREW OUTWARD FROM HERE." },
  keepstatue: { box: [18, 10], art: "statue", examine: "A STATUE FROM THE KEEP, HAULED HERE LONG AGO AND SET UPRIGHT. NOBODY REMEMBERS WHO IT WAS. SOMEONE STILL LEAVES FLOWERS." },
  keepstone: { wallMounted: true, examine: "DRESSED STONE, OLDER THAN THE WALL AROUND IT. THE SAME CUT AS THE HALLS YOU WOKE IN. THE TOWN WAS BUILT FROM WHAT THE KEEP LEFT BEHIND." },
  marketcross: {
    box: [26, 12],
    light: { dx: 0, dy: -22, rad: 132, col: RUNE_COL, int: 1, flick: 0, when: "always" },
    examine: "THE CHARTER STONE. BY GRANT OF THE ALIGARCH THRONE, WESTWAKE HOLDS MARKET EVERY SEVENTH DAY. THE LIGHT RUNE AT ITS HEAD HAS NEVER GONE OUT."
  },
  noticeboard: { box: [20, 4], examine: "NOTICES. MARKET ON THE SEVENTH DAY. HAULERS FOR HIRE AT THE STONE YARD. LOST: ONE GOAT. THE GUILD PAYS FOR NEWS OF THE OLD RUIN EAST OF TOWN." },
  tollbar: { box: [6, 48], examine: "THE WEST BAR, DOWN AND CHAINED. BEYOND IT THE ROAD RUNS FOUR DAYS TO ANYWHERE LARGER. THE CAPITAL IS ONLY A NAME HERE." },
  waymark: { box: [8, 4], examine: "A WAYMARK, LEANING. ITS ARM POINTS WEST ALONG AN OLD ROAD: WESTWAKE. THE CUT LETTERS ARE NEWER THAN THE POST." },
  milestone: { box: [8, 5], examine: "A MILESTONE. WEST: WESTWAKE. EAST: NOTHING IS CARVED. SOMEONE HAS SCRATCHED BELOW IT: RUINS. KEEP OUT." },
  // ---- labour: what the golems that haul and lift leave behind (there are none here to see)
  golempad: { flat: true, examine: "A GOLEM STAND: A SLAB WORN INTO TWO FLAT HOLLOWS, AN IRON RING FOR THE TETHER. LABOUR GOLEMS ARE STOOD HERE WHEN THERE IS NOTHING TO HAUL. IT IS EMPTY." },
  yokerack: { box: [24, 5], examine: "CARRYING YOKES AND A STONE HOD, CUT FAR TOO WIDE FOR HUMAN SHOULDERS. THE GRIPS ARE WORN TO THE SHAPE OF BROAD, FINGERLESS HANDS." },
  tallyboard: { box: [12, 4], examine: "A TALLY SLATE. STAND 1: STONE, 40 LOADS. STAND 2: TIMBER. STAND 3: OUT ON HIRE. NO NAMES, ONLY NUMBERS." },
  stonestack: { box: [24, 9], examine: "CUT STONE, STACKED TWO HIGH. EACH BLOCK HAS AN IRON LIFTING RING, POLISHED BRIGHT. NO MAN LIFTS THESE." },
  scaffold: { box: [36, 5], examine: "A HOUSE GOING UP. THE BEAMS WAITING BELOW ARE TOO HEAVY FOR A WORK GANG. THE TOWN IS STILL GROWING." },
  crane: { box: [22, 9], examine: "A HOIST. ITS CAPSTAN BARS ARE SET CHEST-HIGH TO SOMETHING TALLER THAN A MAN, AND WORN SMOOTH WHERE IT PUSHES." },
  timberstack: { box: [32, 8] },
  // ---- streets, market, yards
  stall: { box: [34, 9] },
  wagon: { box: [34, 10] },
  haybale: { box: [14, 7] },
  trough: { box: [20, 6] },
  hitchpost: { box: [18, 3] },
  woodpile: { box: [20, 7] },
  fence: { box: [16, 4] },
  fence_v: { box: [4, 16] },
  planter: { box: [14, 5] },
  coop: { box: [18, 7] },
  laundry: { sway: true },
  chimney: { smoke: { dx: 0, z: 5, rate: 2.2 } },
  /** The Throne's colours on a pole: outside the Guild, the Reeve's Hall and the gate, so nobody forgets whose town this is. */
  bannerpole: { box: [4, 3], sway: true },
  /** A town tree: the surface's tree to look at, but nobody's timber (not harvestable). */
  towntree: { box: [10, 6], art: "tree", sway: true },
  // ---- what the town shares with the halls only by sight. The halls' anvil is a working station and their racks
  // and stands are what an age left of them; the town's are whole, and nobody's to use yet (the town is appearance only).
  townanvil: { box: [14, 6], art: "anvil" },
  shoprack: { box: [24, 6] },
  shopstand: { box: [10, 5] },
  // ---- shop fittings (interiors)
  counter: { box: [46, 9] },
  bar: { box: [78, 10] },
  goodshelf: { wallMounted: true },
  displaycase: { box: [14, 7] },
  mannequin: { box: [10, 5] },
  clothrack: { box: [28, 6] },
  loom: { box: [28, 9] },
  mirror: { wallMounted: true },
  screen: { box: [24, 5] },
  kegrack: { box: [32, 9] },
  roundtable: { box: [18, 9] },
  stool: { box: [6, 4] },
  stairs_up: { box: [20, 12] },
  dummy: { box: [8, 4] },
  roundtable_lit: { box: [18, 9], art: "roundtable", light: { dx: 0, dy: -8, rad: 70, col: FIRE_COL, int: 0.6, flick: 0.12, when: "always" } },
  fireplace: { box: [38, 8], light: { dx: 0, dy: 4, rad: 168, col: [1, 0.56, 0.26], int: 0.95, flick: 0.24, when: "always" } },
  smithforge: { box: [34, 12], light: { dx: 0, dy: 2, rad: 160, col: [1, 0.48, 0.2], int: 0.95, flick: 0.28, when: "always" } },
  quench: { box: [16, 7] },
  toolrack: { wallMounted: true },
  coalbin: { box: [14, 7] },
  ingots: { box: [12, 5] },
  grindstone: { box: [12, 6] },
  shieldwall: { wallMounted: true },
  armordisplay: { box: [10, 5] },
  gembench: { box: [28, 9] },
  trophy: { wallMounted: true },
  bellows: { box: [18, 8], examine: "THE GREAT BELLOWS. ITS CRANK IS SET HIGH AND STIFF, AND THE FLAGSTONE UNDER IT IS WORN INTO TWO FLAT HOLLOWS. NO APPRENTICE TURNS THIS." },
  cellarhatch: { flat: true, examine: "THE CELLAR HATCH, CUT WIDE. THE RAMP BELOW IS SCORED BY SOMETHING HEAVY AND FLAT-FOOTED THAT CARRIES THE KEGS UP." },
  crownplaque: { wallMounted: true, examine: "A CROWN OF BEATEN TIN, NAILED OVER THE HEARTH. THE REAL ONE, THEY SAY, WENT DOWN WITH THE KEEP." },
  questboard: { wallMounted: true, examine: "CONTRACTS, PINNED THREE DEEP. ESCORTS. WOLF BOUNTIES. A CELLAR OF RATS. ONE SHEET HAS YELLOWED UNCLAIMED: SURVEY THE SUNKEN KEEP." }
};
var FOLK_PROPS = {
  campfire: {
    box: [14, 6],
    alt: "lit",
    light: { dx: 0, dy: -5, rad: 104, col: [1, 0.6, 0.3], int: 0.95, flick: 0.24, when: "lit" },
    fire: { big: true, embers: 4, emberDy: 8, dy: 9 }
  },
  leanto: { box: [26, 6] },
  bedroll: { flat: true },
  peltrack: { box: [18, 4] },
  seatlog: { box: [20, 4] }
};
var PROPS = {
  bookshelf: { box: [16, 8] },
  shelfrow: { box: [16, 10] },
  shelf_fallen: { box: [28, 10] },
  table: { box: [28, 10] },
  lectern: { box: [10, 6] },
  chair: { box: [8, 5] },
  bed: { box: [14, 26] },
  footlocker: { box: [12, 6] },
  weaponrack: { box: [24, 6] },
  limbrack: { box: [22, 6], alt: "taken" },
  armorstand: { box: [10, 5] },
  barrel: { box: [12, 7] },
  crate: { box: [14, 8] },
  statue: { box: [18, 10] },
  statue_fallen: { box: [30, 10] },
  throne: { box: [30, 14] },
  maptable: { box: [28, 10], alt: "taken" },
  altar: { box: [30, 10] },
  pew: { box: [36, 6] },
  // The workbench is the crafting station: the dungeon's authored one and the buildable CRAFTING BENCH are the same prop.
  // While something rests on it (the dungeon's chisel) taking that comes first; see deriveInteractables.
  workbench: { box: [32, 10], itemDx: -6, station: "crafting" },
  cradle: { box: [28, 5] },
  // The smelter (kind `forge`, the id it has always had) and the anvil: stations with their own screens. Both can be
  // read with golem vision and built (content/build.ts); reading the smelter also teaches smelting.
  forge: { box: [32, 12], station: "smelting" },
  anvil: { box: [14, 6], station: "smithing" },
  // ---- the artificery: where tools, runes and golems were made
  toolboard: { wallMounted: true, examine: "A TOOL BOARD. PAINTED OUTLINES SHOW WHAT HUNG HERE: TONGS, HAMMERS, A SHOVEL, A PICK. ONLY THE OUTLINES AND A FEW RUSTED SCRAPS ARE LEFT." },
  runetable: {
    box: [28, 10],
    light: { dx: 2, dy: -12, rad: 34, col: [0.6, 0.45, 1], int: 0.4, flick: 0.05, when: "always" },
    examine: "A RUNE-CUTTER'S TABLE. A HALF-CUT RUNE STONE STILL GLOWS FAINTLY IN ITS CLAMP. WHOEVER WORKED HERE MEANT TO COME BACK."
  },
  clayvat: { box: [14, 7], examine: "A VAT OF SLIP CLAY, DRIED TO A CRACKED CAKE. WORKER BODIES WERE CAST FROM THIS." },
  husk: { box: [10, 5], examine: "AN UNFINISHED WORKER BODY ON ITS STAND. NO CORE WAS EVER SET IN IT, AND THE CLAY HAS SPLIT." },
  // ---- the armory: what time left of it
  staffrack: { box: [20, 6], examine: "A RACK FOR STAVES. MOST OF ITS SOCKETS ARE EMPTY. ONE STAFF IS LEFT, ITS STONE DEAD AND GREY." },
  wallhooks: { wallMounted: true, examine: "IRON PEGS, AND PALE SHAPES ON THE STONE WHERE BLADES AND SHIELDS HUNG FOR AN AGE." },
  armorpile: { box: [14, 6], examine: "PLATE AND MAIL, RUSTED INTO ONE LUMP. IT CRUMBLES WHERE YOU TOUCH IT." },
  // ---- the way up to the surface (content/geography.ts: GATE_HALL, GATE_STAIR). The fall that chokes it goes when
  // the stair is dug out from above, and daylight comes down it from then on. The flight stands between two cheek
  // walls: `staircheek` is one's footprint (its picture is baked with the steps, art/stairs.ts), `stairpost` the
  // newel post it ends in at the foot of the flight.
  stairfall: { flat: true, examine: "A HALL RUNS SOUTH FROM HERE TO THE SURFACE STAIR. EARTH AND FALLEN VAULT CHOKE IT TO THE ROOF. IT CAN ONLY BE CLEARED FROM ABOVE." },
  stairpost: { box: [STAIR_CHEEK.post.w, STAIR_CHEEK.post.d - 1] },
  staircheek: { flat: true, box: [STAIR_CHEEK.wall.w, GATE_STAIR.h * 16 - STAIR_CHEEK_TOP] },
  stairlight: { flat: true, alt: "lit", light: { dx: 0, dy: 0, rad: 120, col: [0.55, 0.68, 1], int: 0.9, flick: 0.02, when: "lit" } },
  slab: { box: [36, 10] },
  hearth: { box: [36, 10] },
  longtable: { box: [50, 10] },
  bench: { box: [44, 4] },
  chest: { box: [16, 8] },
  pot: { box: [10, 6] },
  fountain: { box: [32, 14] },
  pedestal: { box: [10, 5] },
  storage_chest: { box: [14, 8], storage: { slots: 32 }, art: "chest" },
  sack: { box: [10, 5] },
  parts: { box: [16, 5] },
  brazier: {
    box: [12, 6],
    alt: "lit",
    habit: "fire",
    light: { dx: 0, dy: -4, rad: 96, col: [1, 0.58, 0.3], int: 0.9, flick: 0.2, when: "lit" },
    fire: { big: true, embers: 4, emberDy: 0 }
  },
  torch: {
    wallMounted: true,
    alt: "lit",
    habit: "fire",
    light: { dx: 0, dy: 6, rad: 84, col: [1, 0.62, 0.32], int: 0.85, flick: 0.22, when: "lit" },
    fire: { big: false, embers: 1.5, emberDy: 1 }
  },
  mushrooms: { light: { dx: 0, dy: -3, rad: 44, col: [0.35, 0.95, 0.8], int: 0.55, flick: 0.04, when: "always" } },
  banner: { wallMounted: true },
  // ---- surface
  tree: { box: [10, 6], alt: "taken", sway: true },
  rock: { box: [16, 8], alt: "taken" },
  /** A rock veined with iron (content/harvest.ts). */
  ironore: { box: [16, 8], alt: "taken" },
  torch_post: {
    box: [6, 4],
    alt: "lit",
    habit: "fire",
    light: { dx: 0, dy: -14, rad: 96, col: [1, 0.62, 0.32], int: 0.9, flick: 0.22, when: "lit" },
    fire: { big: false, embers: 1.5, emberDy: -2 }
  },
  cart: { box: [30, 10] },
  // ---- buildables (content/build.ts)
  /** Sharpened stakes: blocks the whole tile width. */
  barricade: { box: [16, 7] },
  // The head of the old stair down into the halls, buried: flat, walkable ground with the stair's kerb showing
  // through the grass and a ward glyph of the lost upper hall cut in its lintel, dark. Nothing here glows, so the
  // halls stay hidden. It is a dig site (content/digging.ts); dug out, it is an open stairwell that blocks
  // (openBox) except at its south lip, and the glyph wakes (`lit`: the surface builder's light follows it).
  buriedgate: { flat: true, openBox: [60, 44], light: { dx: 0, dy: -47, rad: 40, col: [0.62, 0.5, 1], int: 0.45, flick: 0.05, when: "lit" } },
  // ---- surface overgrowth (decorative; small boxes so the woods have texture)
  bush: { box: [12, 5], sway: true },
  fern: { sway: true },
  tallgrass: { sway: true },
  sapling: { box: [4, 3], sway: true },
  stump: { box: [10, 5] },
  log: { box: [30, 7], alt: "taken" },
  boulder: { box: [22, 9] },
  outcrop: { box: [40, 12] },
  // ---- the few remains that still break the surface (moss- and vine-covered)
  wallstub: { box: [30, 9], examine: "OLD MASONRY, HALF SWALLOWED BY THE EARTH." },
  masonry: { box: [18, 8] },
  stoneslab: { flat: true },
  cairn: { box: [14, 6] },
  standingstone: { box: [12, 6] },
  statue_toppled: { box: [30, 10] },
  /** A squared block peeking through the soil along a buried wall line. */
  capstone: { flat: true, examine: "A SQUARED STONE, SUNK DEEP. THE EARTH AROUND IT RINGS HOLLOW." },
  // ---- dungeon: the collapsed surface gate
  rockpile: { box: [16, 8] },
  runesite: { rune: true },
  runecircle: { rune: true },
  chains: { wallMounted: true },
  ...TOWN_PROPS,
  ...FOLK_PROPS
};
var NONE = {};
var propDef = (kind) => PROPS[kind] ?? NONE;
var propReach = (kind) => Math.min(30, 12 + (propDef(kind).box?.[0] ?? 12) / 2);

// src/game/content/glyphs.ts
var GLYPHS = [
  { name: "SUN GLYPH", color: "#ffc94a", dark: "#8a5a10", pat: ["..###..", ".#...#.", "#..#..#", "#.###.#", "#..#..#", ".#...#.", "..###.."] },
  { name: "TIDE GLYPH", color: "#5ab0ff", dark: "#1a4a8a", pat: [".......", "..#...#", ".#.#.#.", "#...#..", "..#...#", ".#.#.#.", "#...#.."] },
  { name: "GALE GLYPH", color: "#c8f0ff", dark: "#4a7088", pat: ["#######", "......#", ".####.#", ".#..#.#", ".#.##.#", ".#....#", ".######"] },
  { name: "ROOT GLYPH", color: "#7fd65a", dark: "#2a6a1a", pat: ["...#...", "...#...", ".#.#.#.", "..###..", "...#...", "..#.#..", ".#...#."] }
];

// src/game/content/flags.ts
var FLAGS = {
  golemArm: "golem.arm",
  /** The golem's flickering eye has been repaired (by the Treasury Guardian). Unlocks zoom. */
  golemEye: "golem.eye",
  // "golem.basket" (the basket installed on pickup) was retired in save v8: the
  // basket is gear worn in the actor's own back slot (Actor.gear, sim/gear.ts).
  knowSchematic: "know.schematic",
  knowBuild: "know.build",
  knowRepair: "know.repair",
  /** Smelting ore into ingots. Nobody teaches it: the golem reads it off a smelter (content/build.ts: Recipe.teaches). */
  knowSmelt: "know.smelt",
  /** Stonework (the brazier recipe). No book teaches it yet; Ctrl+4 grants it. */
  knowMasonry: "know.masonry",
  /**
   * Gear slot unlocks (content/gear.ts: GEAR_SLOT_DEFS[].unlock). A slot with no
   * unlock requirement is always usable; the ones below are locked until their
   * flag is set. Unlocking a slot later is setting its flag, nothing more.
   */
  slotArmLeft: "golem.slot.armL",
  slotRune1: "golem.slot.rune1",
  slotRune2: "golem.slot.rune2",
  slotRune3: "golem.slot.rune3",
  tutorialInsight: "tutorial.insight",
  /** Set when the golem first travels through the rune network (end of tutorial). */
  tutorialDone: "tutorial.done"
};
var LEARNED_TEXT = {
  [FLAGS.knowBuild]: "YOU LEARNED TO BUILD.",
  [FLAGS.knowRepair]: "YOU LEARNED THE ART OF MENDING",
  [FLAGS.knowMasonry]: "YOU LEARNED THE MASON'S CRAFT",
  [FLAGS.knowSmelt]: "YOU LEARNED TO SMELT ORE."
};
var npcFlag = (actorId, key) => `${actorId}.${key}`;
var NPC_AWAKE = "awake";
var CORE_SEATED = "coreSeated";

// src/game/content/gear.ts
var SEALED = ["THIS RUNE SLOT IS SEALED.", "SOMETHING WILL OPEN IT", "LATER."];
var GEAR_SLOT_DEFS = [
  { id: "head", kind: "head", name: "HELM", hint: ["A BARE HEAD.", "A HELM WOULD FIT HERE."] },
  { id: "back", kind: "back", name: "BACK", hint: ["NOTHING ON YOUR BACK.", "WEAR A BASKET FROM THE PACK."] },
  { id: "armR", kind: "arm", name: "R ARM", hint: ["THE SOUND STONE ARM.", "A TOOL HEAD FITS HERE."] },
  {
    id: "armL",
    kind: "arm",
    name: "L ARM",
    hint: ["THE IRON ARM.", "FITTINGS FOR AN ARM GO HERE."],
    unlock: { any: [{ actorFlags: [FLAGS.golemArm] }, { actorFlags: [FLAGS.slotArmLeft] }] },
    locked: [{ text: ["A BROKEN STUB. NOTHING CAN", "BE FITTED UNTIL THERE IS AN", "ARM HERE."] }]
  },
  { id: "core", kind: "core", name: "CORE", hint: ["A MOUNT BESIDE THE CORE.", "FOR ATTACHMENTS TO IT, NOT", "THE AETHER CORE ITSELF."] },
  { id: "rune0", kind: "rune", name: "RUNE 1", hint: ["AN OPEN RUNE SLOT.", "WEAR A RUNE FROM THE PACK."] },
  { id: "rune1", kind: "rune", name: "RUNE 2", unlock: { actorFlags: [FLAGS.slotRune1] }, locked: [{ text: SEALED }] },
  { id: "rune2", kind: "rune", name: "RUNE 3", unlock: { actorFlags: [FLAGS.slotRune2] }, locked: [{ text: SEALED }] },
  { id: "rune3", kind: "rune", name: "RUNE 4", unlock: { actorFlags: [FLAGS.slotRune3] }, locked: [{ text: SEALED }] }
];
var GEAR_SLOTS = GEAR_SLOT_DEFS.map((d) => d.id);
var slotsOfKind = (kind) => GEAR_SLOT_DEFS.filter((d) => d.kind === kind).map((d) => d.id);
var RUNE_SLOTS = slotsOfKind("rune");
var RUNE_SWIFT_SPEED_BONUS = 1.5;
var RUNE_GLOW_LIGHT = { rad: 176, col: [1, 1, 1], int: 1.25 };

// src/game/content/tools.ts
var TOOL_TYPE_IDS = ["shovel", "pickaxe", "axe"];
var TOOL_RUNES = ["swift", "glow"];
var TOOL_TYPES = {
  shovel: { name: "SHOVEL", full: "SHOVEL", works: "DIGS EARTH" },
  pickaxe: { name: "PICK", full: "PICKAXE", works: "ROCK AND ORE" },
  axe: { name: "AXE", full: "AXE", works: "WOOD" }
};
var TOOL_BONUS = { plain: 1, fine: 2 };
var FORGE_COST = { shovel: 2, pickaxe: 3, axe: 3 };
var REPAIR_COST = 1;
var TEMPER_COST = 2;
var HAFT_WOOD = 2;
var headId = (t) => `head_${t}`;
var rustedHeadId = (t) => `head_${t}_rusted`;
var fineHeadId = (t) => `head_${t}_fine`;
var runedHeadId = (t, r) => `head_${t}_${r}`;
var fullToolId = (t) => t;
var fineToolId = (t) => `${t}_fine`;
var runeItemId = (r) => `rune_${r}`;

// src/game/content/items.ts
var glyph = (i) => ({
  name: GLYPHS[i].name,
  tags: ["glyph"],
  glyph: i,
  droppable: false,
  desc: ["A CARVED RUNE GLYPH.", "IT BELONGS ON A PEDESTAL."],
  glow: { color: GLYPHS[i].color, rad: 30, int: 0.55, flick: 0.05 }
});
var RUNE_WORN = {
  swift: { speed: RUNE_SWIFT_SPEED_BONUS, mark: { col: "#5cf0c8", pat: ["#..", ".#.", "#.."] } },
  glow: { light: RUNE_GLOW_LIGHT, mark: { col: "#ffffff", pat: [".#.", "###", ".#."] } }
};
function toolRows() {
  const out = {};
  for (const t of TOOL_TYPE_IDS) {
    const T2 = TOOL_TYPES[t];
    const head = (bonus) => ({ type: t, form: "head", bonus });
    out[`head_${t}`] = {
      name: `${T2.name} HEAD`,
      tags: ["tool"],
      wear: { kind: "arm" },
      tool: head(TOOL_BONUS.plain),
      desc: [`AN IRON ${T2.name} HEAD FOR AN ARM`, "SLOT, OR TO HAFT AT A BENCH."]
    };
    out[`head_${t}_rusted`] = {
      name: `RUSTED ${T2.name} HEAD`,
      tags: ["tool"],
      desc: [`A ${T2.name} HEAD, EATEN BY RUST.`, "AN ANVIL AND ONE IRON INGOT", "WOULD MAKE IT SOUND AGAIN."]
    };
    out[`head_${t}_fine`] = {
      name: `FINE ${T2.name} HEAD`,
      tags: ["tool"],
      wear: { kind: "arm" },
      tool: head(TOOL_BONUS.fine),
      desc: [`A TEMPERED ${T2.name} HEAD. ITS`, "IRON WILL HOLD A RUNE (ANVIL)."]
    };
    for (const r of ["swift", "glow"]) {
      const { mark: _mark, ...worn } = RUNE_WORN[r];
      out[`head_${t}_${r}`] = {
        name: `${r.toUpperCase()} ${T2.name} HEAD`,
        tags: ["tool"],
        wear: { kind: "arm" },
        tool: head(TOOL_BONUS.fine),
        worn,
        desc: [`A FINE ${T2.name} HEAD, RUNE OF ${r.toUpperCase()}.`]
      };
    }
    out[t] = {
      name: T2.full,
      tags: ["tool"],
      tool: { type: t, form: "full", bonus: TOOL_BONUS.plain },
      desc: [`A ${T2.full} ON A WOODEN HAFT, FOR`, "HANDS. GIVE IT TO A WORKER."]
    };
    out[`${t}_fine`] = {
      name: `FINE ${T2.full}`,
      tags: ["tool"],
      tool: { type: t, form: "full", bonus: TOOL_BONUS.fine },
      desc: [`A TEMPERED ${T2.full} ON A HAFT.`, "GIVE IT TO A WORKER."]
    };
  }
  return out;
}
var ITEMS = {
  chisel: { name: "RUNE CHISEL", tags: ["tool"], droppable: false, desc: ["A CHISEL FOR CARVING RUNES.", "CARRY IT TO CARVE. IT IS", "NEVER USED UP."] },
  arm: { name: "IRON ARM", tags: ["part"], droppable: false, desc: ["AN IRON ARM FOR YOUR BROKEN", "SIDE. IT BOLTS ON AT ONCE."], equip: { flag: FLAGS.golemArm, task: { kind: "attach", dur: 1.8 } } },
  key: { name: "RUSTED KEY", tags: ["key"], droppable: false, desc: ["A RUSTED KEY. IT FITS SOME", "OLD LOCK IN THE RUINS."] },
  core: { name: "AETHER CORE", tags: ["power"], droppable: false, desc: ["AN AETHER CORE. THE CIRCLE", "NEEDS IT TO WAKE. IT STAYS", "IN YOUR PACK, NOT ON YOU."] },
  // The ruby chain: the crown's gem, carved at a bench into the one core that can power a worker golem.
  ruby_core: { name: "RUBY GOLEM CORE", tags: ["power"], desc: ["A FIRST-TIER CORE FOR A WORKER.", "FACE A GOLEM, C TO SLOT IT IN.", "C AGAIN TAKES IT BACK OUT."] },
  large_ruby: { name: "HIGH-GRADE RUBY", tags: ["material"], stack: 10, desc: ["A LARGE RUBY, CUT CLEAN AND", "DEEP RED. FINE ENOUGH TO", "CARVE INTO A GOLEM CORE."] },
  glyph0: glyph(0),
  glyph1: glyph(1),
  glyph2: glyph(2),
  glyph3: glyph(3),
  schematic: { name: "SCHEMATIC", tags: ["document"], droppable: false, showOnProp: false, desc: ["THE PLAN OF THE CIRCLE.", "E TO STUDY IT AGAIN."], opens: "schematic", opensOnPickup: true },
  crown: { name: "BROKEN CROWN", tags: ["relic"], desc: ["A BROKEN CROWN. NO ONE", "RULES HERE ANY MORE."] },
  goblet: { name: "SILVER GOBLET", tags: ["relic"], desc: ["A SILVER GOBLET, DULL WITH", "AGE."] },
  coin: { name: "OLD COIN", tags: ["relic"], desc: ["AN OLD COIN FROM A LOST", "REALM."] },
  wood: { name: "WOOD", tags: ["material"], stack: 20, desc: ["ROUGH TIMBER. SAW IT INTO", "PLANKS AT A CRAFTING BENCH."] },
  stone: { name: "STONE", tags: ["material"], stack: 20, desc: ["ROUGH STONE. CUT IT AT A", "CRAFTING BENCH."] },
  // Processed materials (crafted at a bench: content/crafting.ts).
  planks: { name: "PLANKS", tags: ["material"], stack: 20, desc: ["SAWN PLANKS, FOR FINER", "BUILDS AND FURNITURE."] },
  cut_stone: { name: "CUT STONE", tags: ["material"], stack: 10, desc: ["SQUARED BLOCKS OF STONE, FOR", "MASONRY AND RUNE CARVING."] },
  // The iron chain: ore from the surface (content/harvest.ts), ingots from a smelter, tools from an anvil (content/crafting.ts).
  iron_ore: { name: "IRON ORE", tags: ["material"], stack: 20, desc: ["RUST-RED ORE. A SMELTER TURNS", "IT INTO IRON INGOTS."] },
  iron_ingot: { name: "IRON INGOT", tags: ["material"], stack: 20, desc: ["A BAR OF SMELTED IRON, READY", "FOR THE ANVIL."] },
  // What digging earth yields (content/digging.ts).
  dirt: { name: "DIRT", tags: ["material"], stack: 20, desc: ["LOOSE EARTH. NO USE FOR IT", "YET."] },
  ...toolRows(),
  // Gear for the back slot: an ordinary pack item until it is worn (sim/gear.ts); worn, it grows the pack.
  basket: { name: "WOVEN BASKET", tags: ["part"], wear: { kind: "back" }, desc: ["A WOVEN BASKET. STRAP IT TO", "YOUR BACK TO CARRY MORE."] },
  // Runes: worn in a rune slot, their effects apply only while worn.
  rune_swift: {
    name: "RUNE OF SWIFT",
    tags: ["rune"],
    wear: { kind: "rune" },
    desc: ["A STONE CARVED WITH THE SIGN", "OF SWIFTNESS."],
    worn: RUNE_WORN.swift
  },
  rune_glow: {
    name: "RUNE OF GLOW",
    tags: ["rune"],
    wear: { kind: "rune" },
    desc: ["A STONE CARVED WITH THE SIGN", "OF LIGHT."],
    worn: RUNE_WORN.glow
  },
  book_build: {
    name: "BUILDER'S PRIMER",
    tags: ["document"],
    opens: "book",
    opensOnPickup: true,
    desc: ["HOW TO RAISE THINGS. READING", "IT TEACHES BUILDING (E)."],
    book: {
      title: "ON RAISING THINGS",
      grants: FLAGS.knowBuild,
      pages: [
        ["EVERY WORK BEGINS WITH", "GROUND THAT WILL BEAR IT.", "CLEAR THE PLACE. JUDGE", "IT LEVEL AND FIRM."],
        ["GATHER MATERIAL FIRST.", "TIMBER FOR FRAME AND", "FIRE. STONE FOR FOOTING", "AND FOR WEIGHT."],
        ["MEASURE TWICE, SET ONCE.", "A THING BADLY PLACED", "IS WORSE THAN NOTHING.", "(PRESS B TO BUILD)"]
      ]
    }
  },
  book_repair: {
    name: "MENDER'S MANUAL",
    tags: ["document"],
    opens: "book",
    opensOnPickup: true,
    desc: ["A WATER-DAMAGED BOOK ON", "MENDING (E TO READ)."],
    book: {
      title: "ON MENDING",
      grants: FLAGS.knowRepair,
      pages: [["WHAT WAS WHOLE REMEMBERS", "ITS SHAPE. THE MENDER", "ONLY REMINDS IT.", "(THE REST IS WATER-DAMAGED)"]]
    }
  }
};
var ITEM_IDS = Object.keys(ITEMS);
var ITEM_NAMES = Object.fromEntries(ITEM_IDS.map((id) => [id, ITEMS[id].name]));
var RELICS = ITEM_IDS.filter((id) => ITEMS[id].tags.includes("relic"));
var isGlyph = (id) => ITEMS[id].glyph !== void 0;
var glyphItem = (gi) => "glyph" + gi;
var maxStack = (id) => ITEMS[id].stack ?? 1;
var isDroppable = (id) => ITEMS[id].droppable !== false;
var isCritical = (id) => ITEMS[id].droppable === false || !!ITEMS[id].book?.grants;

// src/game/content/ritual.ts
var SOCKET_R = 50;
var SOCKET_COUNT = 4;
function socketPositions(c) {
  return [
    { x: c.x, y: c.y - SOCKET_R },
    { x: c.x + SOCKET_R, y: c.y },
    { x: c.x, y: c.y + SOCKET_R },
    { x: c.x - SOCKET_R, y: c.y }
  ];
}
var RITUAL_SPOTS = {
  socket: { dy: 6, r: 18 },
  center: { r: 13 },
  gap: { dx: 38, dy: 38, r: 20 },
  /** Standing within sqrt(81)px of (c.x, c.y + 2) after activation teleports. */
  teleport: { dy: 2, r2: 81, delay: 3 }
};

// src/game/world/area.ts
var DIRTY_PAD = 2;
var Area = class {
  /** World time this area was last simulated in full (sim/lod.ts: catch-up on entry uses `world.time - lastTicked`). Saved. */
  lastTicked = 0;
  id;
  base;
  w;
  h;
  grid;
  plan;
  style;
  tvar;
  props;
  loose;
  /** base.decals followed by decals added during play (append-only). */
  decals;
  lights;
  ritual = null;
  revision = 0;
  layoutRevision = 0;
  interactionRevision = 0;
  storageRevision = 0;
  /** Id counters for things created during play (saved, so ids are never reused). */
  looseSeq = 0;
  propSeq = 0;
  listeners = [];
  propIndex = /* @__PURE__ */ new Map();
  constructor(base) {
    this.base = base;
    this.id = base.id;
    this.w = base.w;
    this.h = base.h;
    this.grid = base.grid.slice();
    this.plan = base.plan;
    this.style = base.style;
    this.tvar = base.tvar;
    this.decals = base.decals.slice();
    this.lights = base.lights;
    this.props = base.props.map((p) => this.instProp(p));
    this.loose = base.loose.map((l) => ({ ...l, taken: false }));
  }
  instProp(p, dyn = false) {
    const bx = propDef(p.kind).box ?? propDef(p.kind).openBox;
    const inst = { ...p, open: !!p.open, taken: false, dmg: 0, box: bx ? [p.x - bx[0] / 2, p.y - bx[1], p.x + bx[0] / 2, p.y] : null };
    const storage = propDef(p.kind).storage;
    if (storage) {
      if ((p.inventory?.length ?? 0) > storage.slots) throw new Error("authored storage exceeds capacity");
      inst.inventory = Array.from({ length: storage.slots }, (_, i) => p.inventory?.[i] ? { ...p.inventory[i] } : null);
    }
    if (dyn) inst.dyn = true;
    this.propIndex.set(p.id, inst);
    return inst;
  }
  // ---- static-ish accessors (pass-through so an Area is usable as MapData)
  get rooms() {
    return this.base.rooms;
  }
  get exits() {
    return this.base.exits;
  }
  get drips() {
    return this.base.drips;
  }
  get start() {
    return this.base.start;
  }
  /** Translocation circle centre (only areas with a ritual). */
  get ritualPos() {
    return this.base.ritual;
  }
  initRitual(solution) {
    this.setRitual({
      solution,
      sockets: new Array(SOCKET_COUNT).fill(-1),
      core: false,
      carved: false,
      active: false,
      actT: 0,
      wrong: new Array(SOCKET_COUNT).fill(false)
    });
  }
  tile(tx, ty) {
    if (tx < 0 || ty < 0 || tx >= this.w || ty >= this.h) return T.WALL;
    return this.grid[ty * this.w + tx];
  }
  tileAtPx(px, py) {
    return this.tile(Math.floor(px / TS), Math.floor(py / TS));
  }
  prop(id) {
    return this.propIndex.get(id);
  }
  looseItem(id) {
    return this.loose.find((l) => l.id === id);
  }
  // ---- mutations
  setTile(tx, ty, t) {
    if (tx < 0 || ty < 0 || tx >= this.w || ty >= this.h) return;
    this.grid[ty * this.w + tx] = t;
    this.markDirty(tx - DIRTY_PAD, ty - DIRTY_PAD, tx + DIRTY_PAD, ty + DIRTY_PAD);
  }
  addDecal(d) {
    this.decals.push(d);
    const tx = Math.floor(d.x / TS), ty = Math.floor(d.y / TS);
    this.markDirty(tx - DIRTY_PAD, ty - DIRTY_PAD, tx + DIRTY_PAD, ty + DIRTY_PAD, false);
  }
  setPropState(id, s) {
    const p = this.propIndex.get(id);
    if (!p) return;
    if (s.name !== void 0) {
      if (s.name) p.name = s.name;
      else delete p.name;
    }
    const layout = s.taken !== void 0 && s.taken !== p.taken;
    if (s.open !== void 0) p.open = s.open;
    if (s.taken !== void 0) p.taken = s.taken;
    if (s.lit !== void 0) p.lit = s.lit;
    if (s.dmg !== void 0) p.dmg = s.dmg;
    if (s.item !== void 0) p.item = s.item ?? void 0;
    this.touch(layout ? "layout" : "interaction");
  }
  /** Give a prop a name of the player's own, or (`undefined`) take it back to its default label. */
  setPropName(id, name) {
    const p = this.propIndex.get(id);
    if (!p) return;
    if (name) p.name = name;
    else delete p.name;
    this.touch("state");
  }
  /** Harvest progress: add damage to a prop. */
  damageProp(id, n) {
    const p = this.propIndex.get(id);
    if (!p) return;
    p.dmg += n;
    this.touch("state");
  }
  /** Create a prop during play (building). Ids are `kind#b<n>`, never reused. */
  addProp(kind, x, y, o = {}, id) {
    const pid = id ?? `${kind}#b${this.propSeq++}`;
    if (this.propIndex.has(pid)) throw new Error(`duplicate prop id "${pid}"`);
    const inst = this.instProp({ v: 0, ...o, id: pid, kind, x, y }, true);
    this.props.push(inst);
    this.touch("layout");
    return inst;
  }
  /**
   * Remove a prop (deconstruction). Built props simply vanish; for authored
   * props the save diff records the removal (base ids missing from the area).
   * Lights a prop owns and cached interactables follow through `revision`.
   */
  removeProp(id) {
    const p = this.propIndex.get(id);
    if (!p) return void 0;
    this.propIndex.delete(id);
    this.props = this.props.filter((q) => q !== p);
    this.touch("layout");
    return p;
  }
  takeLoose(id) {
    const l = this.looseItem(id);
    if (l) {
      l.taken = true;
      this.touch();
    }
  }
  /** A loose stack created during play (dropped / overflow). Ids are `drop<n>`, never reused. */
  addLoose(item, n, x, y, id) {
    const l = { id: id ?? `drop${this.looseSeq++}`, item, x, y, taken: false, dyn: true };
    if (n !== 1) l.n = n;
    this.loose.push(l);
    this.touch();
    return l;
  }
  setLooseCount(id, n) {
    const l = this.looseItem(id);
    if (!l) return;
    if (n <= 0) l.taken = true;
    else if (n === 1) delete l.n;
    else l.n = n;
    this.touch();
  }
  /** Atomic replacement: callers never receive a mutable storage handle. */
  setInventory(id, slots) {
    const p = this.prop(id), cap = p && propDef(p.kind).storage?.slots;
    if (!p || cap === void 0 || slots.length > cap) throw new Error("invalid storage inventory");
    if (slots.some((s) => s && (!Number.isSafeInteger(s.n) || s.n <= 0 || s.n > maxStack(s.item)))) throw new Error("invalid storage stack");
    p.inventory = Array.from({ length: cap }, (_, i) => slots[i] ? { ...slots[i] } : null);
    this.touch("storage");
  }
  setRitual(state) {
    this.ritual = state ? { ...state, solution: [...state.solution], sockets: [...state.sockets], wrong: [...state.wrong] } : null;
    this.touch();
  }
  updateRitual(state) {
    if (!this.ritual) return;
    Object.assign(this.ritual, state);
    if (state.solution) this.ritual.solution = [...state.solution];
    if (state.sockets) this.ritual.sockets = [...state.sockets];
    if (state.wrong) this.ritual.wrong = [...state.wrong];
    this.touch();
  }
  advanceRitual(dt) {
    if (this.ritual?.active) {
      this.ritual.actT += dt;
      this.touch("state");
    }
  }
  restoreCounters(loose, props) {
    this.looseSeq = loose;
    this.propSeq = props;
  }
  /** Revisions describe dependencies, not merely how often state changes. */
  touch(change = "interaction") {
    this.revision++;
    if (change === "storage") this.storageRevision++;
    if (change === "layout") this.layoutRevision++;
    if (change === "layout" || change === "interaction") this.interactionRevision++;
  }
  // ---- change propagation
  onChange(fn) {
    this.listeners.push(fn);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== fn);
    };
  }
  markDirty(x0, y0, x1, y1, layout = true) {
    this.touch(layout ? "layout" : "state");
    const r = { x0: Math.max(0, x0), y0: Math.max(0, y0), x1: Math.min(this.w - 1, x1), y1: Math.min(this.h - 1, y1) };
    for (const l of this.listeners) l(r);
  }
};

// src/game/map.ts
var MW = 72;
var MH = 56;
var DUNGEON_SEED = 1337;
var ARTIFICERY_WORKER = { id: "npc.worker.artificery", npc: "worker_golem", x: 7 * TS + 13, y: 37 * TS + 14 };
function buildDungeon() {
  return buildMap(DUNGEON_SEED);
}
function buildMap(seed) {
  const rng = mulberry(seed);
  const grid = new Uint8Array(MW * MH);
  const style = new Uint8Array(MW * MH);
  const tvar = new Uint8Array(MW * MH);
  const inb = (x, y) => x >= 0 && y >= 0 && x < MW && y < MH;
  const set = (x, y, t, s) => {
    if (!inb(x, y)) return;
    grid[y * MW + x] = t;
    if (s !== void 0) style[y * MW + x] = s;
  };
  const rect = (x, y, w, h, t, s) => {
    for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) set(i, j, t, s);
  };
  const rooms = [];
  const room = (num, name, x, y, w, h, s) => {
    rect(x, y, w, h, T.FLOOR, s);
    rooms.push({ num, name, x, y, w, h });
  };
  room(1, "THRONE HALL", 26, 2, 20, 14, FS.MARBLE);
  room(2, "GREAT HALL", 29, 20, 14, 21, FS.MARBLE);
  room(3, "TRANSLOC. RM", 3, 3, 17, 13, FS.FLAG);
  room(4, "LIBRARY", 3, 20, 15, 11, FS.WOOD);
  room(5, "ARTIFICERY", 4, 36, 13, 10, FS.FLAG);
  room(6, "CHAPEL", 19, 47, 10, 7, FS.FLAG);
  room(7, "VESTIBULE", 31, 44, 10, 6, FS.MARBLE);
  room(8, "TREASURY", 52, 3, 8, 6, FS.MARBLE);
  room(9, "ARMORY", 62, 3, 7, 8, FS.FLAG);
  room(10, "BARRACKS", 53, 13, 16, 11, FS.WOOD);
  room(11, "GAOL", 53, 28, 16, 12, FS.COBBLE);
  room(12, "KITCHEN", 53, 43, 16, 8, FS.FLAG);
  const B2 = FS.BRICK;
  rect(21, 1, 2, 46, T.FLOOR, B2);
  rect(20, 9, 1, 2, T.FLOOR, B2);
  rect(18, 25, 3, 1, T.FLOOR, B2);
  rect(17, 40, 4, 1, T.FLOOR, B2);
  rect(23, 24, 6, 2, T.FLOOR, B2);
  rect(23, 36, 6, 2, T.FLOOR, B2);
  rect(49, 1, 2, 48, T.FLOOR, B2);
  rect(43, 24, 6, 2, T.FLOOR, B2);
  rect(43, 36, 6, 2, T.FLOOR, B2);
  rect(46, 10, 3, 2, T.FLOOR, B2);
  rect(51, 17, 2, 2, T.FLOOR, B2);
  rect(65, 11, 2, 2, T.FLOOR, FS.FLAG);
  rect(51, 33, 2, 2, T.FLOOR, B2);
  rect(51, 46, 2, 2, T.FLOOR, B2);
  rect(35, 41, 2, 3, T.FLOOR, FS.MARBLE);
  rect(GATE_HALL.x, GATE_HALL.y, GATE_HALL.w, GATE_HALL.h, T.FLOOR, FS.FLAG);
  rect(GATE_STAIR.x, GATE_STAIR.y, GATE_STAIR.w, GATE_STAIR.h, T.FLOOR, FS.STAIR);
  rect(29, 48, 2, 1, T.FLOOR, FS.FLAG);
  rect(34, 16, 4, 4, T.FLOOR, FS.MARBLE);
  rect(69, 46, 2, 2, T.FLOOR, FS.FLAG);
  set(51, 5, T.LOCKED, FS.MARBLE);
  for (const y of [22, 26, 30, 34, 38]) for (const x of [31, 40]) set(x, y, T.PILLAR);
  for (const y of [5, 9, 13]) for (const x of [29, 42]) set(x, y, T.PILLAR);
  for (const [x, y] of [[40, 30], [31, 34], [42, 9], [29, 13]]) tvar[y * MW + x] = 1;
  for (let y = 28; y <= 39; y++) set(62, y, T.WALL);
  for (let x = 63; x <= 68; x++) {
    set(x, 31, T.WALL);
    set(x, 35, T.WALL);
  }
  set(62, 29, T.BARS);
  set(62, 37, T.BARS);
  set(62, 33, T.FLOOR, FS.COBBLE);
  const plan = grid.slice();
  const R = T.RUBBLE;
  rect(21, 1, 2, 5, R);
  rect(49, 1, 2, 3, R);
  rect(34, 16, 4, 4, R);
  rect(44, 36, 3, 2, R);
  rect(GATE_PASSAGE.x, GATE_PASSAGE.y, GATE_PASSAGE.w, GATE_PASSAGE.h, R);
  rect(69, 46, 2, 2, R);
  for (const [x, y] of [
    [43, 2],
    [44, 2],
    [45, 2],
    [44, 3],
    [45, 3],
    [45, 4],
    [43, 3],
    [26, 13],
    [26, 14],
    [27, 14],
    [26, 15],
    [27, 15],
    [28, 15],
    [3, 20],
    [4, 20],
    [3, 21],
    [68, 9],
    [68, 10],
    [67, 10],
    [68, 22],
    [68, 23],
    [67, 23],
    [34, 20],
    [37, 20],
    [49, 30],
    [22, 30],
    [33, 49],
    [38, 49],
    [27, 53],
    [28, 53]
  ]) set(x, y, R);
  set(47, 10, T.CRACKED);
  set(47, 11, T.CRACKED);
  const props = [];
  const lights = [];
  const decals = [];
  const loose = [];
  const drips = [];
  const px = (tx) => tx * TS + 8;
  const py = (ty) => ty * TS + 16;
  const ids = /* @__PURE__ */ new Set();
  const P = (kind, tx, ty, o = {}) => {
    let id = o.id ?? `${kind}@${tx},${ty}`;
    for (let n = 2; ids.has(id); n++) id = `${kind}@${tx},${ty}#${n}`;
    ids.add(id);
    const p = { kind, x: px(tx), y: py(ty), v: 0, ...o, id };
    props.push(p);
    const L = propDef(kind).light;
    if (L && (L.when === "always" || p.lit)) lights.push({ x: p.x + L.dx, y: p.y + L.dy, rad: L.rad, col: L.col, int: L.int, flick: L.flick, owner: id });
    return p;
  };
  const D = (kind, x, y, v = 0, w, h) => decals.push({ kind, x, y, v, w, h });
  D("dais", 33 * TS, 2 * TS, 0, 6 * TS, 3 * TS);
  D("carpet", 35 * TS, 5 * TS, 0, 2 * TS, 11 * TS);
  D("carpet", 35 * TS, 20 * TS, 1, 2 * TS, 21 * TS);
  P("throne", 35.5, 3);
  P("maptable", 39.5, 5, { item: "schematic", itemZ: 12 });
  P("statue", 32, 3);
  P("statue", 39, 3, { v: 1 });
  P("statue_fallen", 27.5, 8);
  for (const x of [27, 31, 40]) P("banner", x, 1, { v: x % 3 });
  P("brazier", 33, 12);
  P("brazier", 38, 12, { v: 1 });
  loose.push({ id: "crown", item: "crown", x: 33 * TS + 2, y: 6 * TS + 4 });
  lights.push({ x: 31 * TS, y: 10 * TS, rad: 84, col: [0.55, 0.68, 1], int: 1, flick: 0.02, id: "moon", sky: true });
  lights.push({ x: 46 * TS + 8, y: 10 * TS + 16, rad: 30, col: [0.55, 0.68, 1], int: 0.35, flick: 0.02, sky: true });
  for (let i = 0; i < 14; i++) D("debris", 31 * TS + (rng() - 0.5) * 48, 10 * TS + (rng() - 0.5) * 40, rng() * 4 | 0);
  D("bones", 41 * TS, 12 * TS, 0);
  P("statue", 29.125, 28, { id: "statue@29,28" });
  P("statue", 29.125, 32, { id: "statue@29,32", v: 1 });
  P("statue", 41.875, 28, { id: "statue@42,28" });
  P("statue", 41.875, 32, { id: "statue@42,32" });
  P("brazier", 33, 23, { lit: true });
  P("brazier", 38, 23);
  P("brazier", 33, 39);
  P("brazier", 38, 39, { lit: true });
  P("banner", 30, 19, { v: 1 });
  P("banner", 41, 19, { v: 2 });
  P("statue_fallen", 36, 31);
  for (let i = 0; i < 10; i++) D("debris", 35.5 * TS + (rng() - 0.5) * 64, 21 * TS + rng() * 20, rng() * 4 | 0);
  P("fountain", 35.5, 46);
  P("statue", 32, 45);
  P("statue_fallen", 38.5, 45, { v: 1 });
  P("torch", 33, 43, { lit: true });
  P("torch", 38, 43);
  for (let i = 0; i < 12; i++) D("debris", 35.5 * TS + (rng() - 0.5) * 90, 49 * TS + rng() * 14, rng() * 4 | 0);
  P("altar", 24.5, 48, { id: "altar@26,48", item: "glyph3", itemZ: 13 });
  lights.push({ x: 24.5 * TS + 8, y: 48 * TS + 8, rad: 58, col: [1, 0.7, 0.4], int: 0.6, flick: 0.15 });
  P("pew", 24.5, 50);
  P("pew", 24.5, 52);
  P("statue", 19.5, 52, { v: 1 });
  P("banner", 24.5, 46, { id: "banner@23,46", v: 0 });
  P("candles", 20, 49);
  P("cradle", 9, 37);
  P("forge", 5.5, 37);
  lights.push({ x: 5.5 * TS + 8, y: 37 * TS + 8, rad: 46, col: [1, 0.42, 0.18], int: 0.6, flick: 0.3 });
  P("workbench", 13.5, 37, { item: "chisel", itemZ: 12 });
  P("anvil", 6, 40);
  P("slab", 12.5, 43);
  P("parts", 15, 41);
  P("barrel", 15, 45);
  P("crate", 16, 44);
  P("crate", 16, 45, { v: 1 });
  P("bookshelf", 16, 36, { v: 1 });
  for (let i = 0; i < 6; i++) D("paper", 11 * TS + rng() * 64, 38 * TS + rng() * 40, rng() * 3 | 0);
  D("scorch", 5.5 * TS, 38 * TS + 4, 0);
  for (const x of [5, 6, 7, 9, 10, 11, 13, 14, 15, 16, 17]) P("bookshelf", x, 20, { v: x % 2 ? 0 : 2 });
  for (const x of [5, 6, 7, 8, 11, 12, 13, 14]) P("shelfrow", x, 23, { v: x % 3 });
  for (const x of [5, 6, 11, 12, 14]) P("shelfrow", x, 26, { v: (x + 1) % 3 });
  P("shelf_fallen", 8, 27);
  P("table", 11, 29, { v: 1, item: "book_build", itemZ: 11 });
  P("chair_fallen", 12.5, 29.2);
  P("lectern", 5, 29, { item: "glyph1", itemZ: 12 });
  loose.push({ id: "book_repair", item: "book_repair", x: 9 * TS + 4, y: 28 * TS + 12 });
  P("mushrooms", 3, 30);
  D("puddle", 4 * TS, 27 * TS + 6, 0, 40, 18);
  D("puddle", 6 * TS + 6, 29 * TS + 4, 1, 30, 12);
  drips.push({ x: 5 * TS, y: 28 * TS }, { x: 7 * TS, y: 29 * TS + 8 });
  for (let i = 0; i < 18; i++) D("books", 4 * TS + rng() * 13 * TS, 21 * TS + rng() * 9 * TS, rng() * 4 | 0);
  const ritual = { x: 11 * TS + 8, y: 9 * TS + 8 };
  P("torch", 7, 2, { lit: true });
  P("torch", 15, 2);
  P("candles", 6, 6);
  P("candles", 16, 13, { v: 1 });
  P("candles", 6, 13);
  P("ladder", 17, 6);
  P("bucket", 16, 4);
  P("skeleton", 18, 14, { v: 1 });
  lights.push({ x: ritual.x, y: ritual.y, rad: 70, col: [0.6, 0.38, 1], int: 0.28, flick: 0.06, id: "circle" });
  for (let i = 0; i < 10; i++) D("chalk", 5 * TS + rng() * 12 * TS, 4 * TS + rng() * 10 * TS, rng() * 3 | 0);
  P("chest", 57, 4, { open: true });
  P("chest", 54, 4, { v: 2 });
  P("pot", 59, 8);
  P("pot", 52, 8, { v: 1 });
  loose.push({ id: "coin", item: "coin", x: 55 * TS + 8, y: 7 * TS + 8 });
  for (let i = 0; i < 12; i++) D("coins", 52 * TS + rng() * 8 * TS, 3 * TS + rng() * 6 * TS, rng() * 3 | 0);
  P("limbrack", 65.5, 3, { item: "arm", itemZ: 10 });
  P("weaponrack", 63, 3);
  P("armorstand", 63, 7);
  P("armorstand", 67.5, 6, { v: 1 });
  lights.push({ x: 63 * TS, y: 9 * TS, rad: 40, col: [0.55, 0.65, 0.95], int: 0.4, flick: 0.02 });
  for (let i = 0; i < 6; i++) D("weapon", 62 * TS + rng() * 7 * TS, 4 * TS + rng() * 6 * TS, rng() * 3 | 0);
  for (const x of [54, 57, 60, 63, 68]) P("bed", x, 14, { v: x % 2 });
  for (const x of [54, 57, 60, 63]) P("bed", x, 23, { v: 2 + (x + 1) % 2 });
  P("footlocker", 54, 15, { container: true });
  P("footlocker", 60, 15, { container: true });
  P("footlocker", 57, 21, { container: true });
  P("footlocker", 63, 21, { container: true, item: "glyph2" });
  P("table", 60.5, 18);
  P("chair", 58.6, 18);
  P("chair_fallen", 62.5, 19);
  P("torch", 57, 12, { lit: true });
  P("skeleton", 65, 28, { v: 2 });
  P("skeleton", 66, 32, { container: true, item: "key" });
  P("skeleton", 64, 36, { v: 2 });
  P("mushrooms", 67, 39);
  P("table", 56, 30);
  P("chair", 57.6, 30.6);
  P("chains", 55, 27);
  P("chains", 59, 27);
  P("torch", 57, 27, { lit: true });
  P("barrel", 53, 39);
  P("bucket", 60, 38);
  P("brazier", 58, 35);
  D("bars_broken", 62 * TS, 33 * TS, 0);
  D("puddle", 55 * TS, 36 * TS, 0, 34, 14);
  drips.push({ x: 56 * TS, y: 36 * TS + 6 });
  for (let i = 0; i < 6; i++) D("bones", 53 * TS + rng() * 15 * TS, 28 * TS + rng() * 11 * TS, rng() * 3 | 0);
  P("hearth", 60.5, 43, { container: true, item: "glyph0" });
  lights.push({ x: 60.5 * TS + 8, y: 43 * TS + 10, rad: 52, col: [1, 0.48, 0.22], int: 0.5, flick: 0.25 });
  P("longtable", 59.5, 47, { item: "goblet", itemZ: 9 });
  P("bench", 59.5, 45);
  P("bench", 59.5, 48);
  P("barrel", 53, 43);
  P("barrel", 54, 43, { v: 1 });
  P("crate", 67, 49);
  P("crate", 68, 50, { v: 1 });
  P("sack", 66, 50);
  P("sack", 53, 50);
  P("pot", 56, 43);
  P("bookshelf", 65, 43, { v: 3 });
  for (const [x, y] of [[21, 15], [22, 33], [50, 9], [49, 27], [50, 42], [22, 44]]) P("mushrooms", x, y);
  P("torch", 26, 23, { lit: true });
  P("torch", 46, 23);
  P("torch", 25, 35);
  D("puddle", 21 * TS, 20 * TS, 1, 28, 12);
  drips.push({ x: 21 * TS + 10, y: 20 * TS + 6 });
  D("puddle", 49 * TS + 4, 38 * TS, 0, 26, 16);
  drips.push({ x: 49 * TS + 16, y: 38 * TS + 8 });
  const G3 = (x, y) => inb(x, y) ? grid[y * MW + x] : T.WALL;
  const key = (x, y) => y * MW + x;
  const wasPillar = new Set([5, 8, 11, 14].flatMap((y) => [key(29, y), key(42, y)]));
  const nowPillar = new Set([5, 9, 13].flatMap((y) => [key(29, y), key(42, y)]));
  for (let y = 1; y < MH - 1; y++)
    for (let x = 1; x < MW - 1; x++) {
      const t = G3(x, y);
      const k = key(x, y);
      if (wasPillar.has(k) || t !== T.FLOOR && !(nowPillar.has(k) && !wasPillar.has(k))) continue;
      const bx = x * TS, by = y * TS;
      const r = rng();
      const nearRubble = [G3(x - 1, y), G3(x + 1, y), G3(x, y - 1), G3(x, y + 1)].some((n) => n === T.RUBBLE || n === T.CRACKED);
      if (nearRubble) for (let k2 = 0; k2 < 3; k2++) D("debris", bx + rng() * 16, by + rng() * 16, rng() * 4 | 0);
      if (r < 0.07) D("crack", bx + rng() * 8, by + rng() * 8, rng() * 4 | 0);
      else if (r < 0.12) D("debris", bx + rng() * 14, by + rng() * 14, rng() * 4 | 0);
      else if (r < 0.13) D("bones", bx + 4, by + 6, rng() * 3 | 0);
      if (G3(x, y - 1) === T.WALL && G3(x - 1, y) === T.WALL && rng() < 0.6) D("cobweb", bx, by, 0);
      if (G3(x, y - 1) === T.WALL && G3(x + 1, y) === T.WALL && rng() < 0.6) D("cobweb", bx, by, 1);
      const wallN = G3(x - 1, y) === T.WALL || G3(x + 1, y) === T.WALL || G3(x, y - 1) === T.WALL;
      if (wallN && rng() < 0.12) D("moss", bx + rng() * 8, by + rng() * 8, rng() * 3 | 0);
    }
  socketPositions(ritual).forEach((s, i) => {
    const id = "ped" + i;
    ids.add(id);
    props.push({ id, kind: "pedestal", x: s.x, y: s.y + 4, v: 0 });
  });
  props.push({ id: "rune.dungeon", kind: "runesite", x: ritual.x, y: ritual.y, v: 0 });
  {
    const gr = mulberry(seed ^ 27262);
    const C = GATE_CORRIDOR;
    for (const x of [C.x, C.x + C.w - 1]) set(x, C.y - 1, R, FS.EARTH);
    const cx = (C.x + C.w / 2) * TS, top = C.y * TS;
    D("earthspill", cx, top - 10, 0, 76, 44);
    D("earthspill", cx - 20, top - 30, 1, 34, 20);
    D("earthspill", cx + 18, top - 26, 2, 30, 18);
    for (let i = 0; i < 16; i++) D("stones", cx + (gr() - 0.5) * 120, top - 6 - gr() * 52, gr() * 4 | 0);
    for (let i = 0; i < 10; i++) D("debris", cx + (gr() - 0.5) * 100, top - 4 - gr() * 44, gr() * 4 | 0);
    for (const [x, y, v] of [[C.x - 1.6, C.y - 1.5, 0], [C.x - 0.4, C.y - 1.45, 1], [C.x + C.w + 0.3, C.y - 1.5, 1], [C.x + C.w - 0.8, C.y - 1.2, 0], [C.x + 1.4, C.y - 2.2, 1]])
      D("rootfall", x * TS, y * TS, v);
    for (let i = 0; i < 5; i++) D("roots", cx + (gr() - 0.5) * 70, top - 18 - gr() * 20, 0);
    const piles = [
      [C.x + 0.3, C.y, 0],
      [C.x + 2.6, C.y + 0.2, 1],
      [C.x + 1.5, C.y + 1, 2],
      [C.x + 0.2, C.y + 2, 1],
      [C.x + 3, C.y + 2.4, 0],
      [C.x + 1.6, C.y + 3.2, 2],
      [C.x + 0.5, C.y + 4, 0],
      [C.x + 2.8, C.y + 4.2, 1],
      [C.x - 0.5, C.y - 1.9, 1],
      [C.x + C.w - 0.1, C.y - 1.8, 2]
    ];
    for (const [x, y, v] of piles) P("rockpile", x, y, { v });
    for (const [id, kind, y] of [["stairfall", "stairfall", top + 2], ["stairlight", "stairlight", top + 3 * TS]]) {
      ids.add(id);
      props.push({ id, kind, x: cx, y, v: 0 });
    }
    D("earthspill", cx - 4, top - 13, 3, 50, 30);
    D("earthspill", cx + 2, top + 7, 4, 58, 24);
    D("earthspill", cx - 11, top + 22, 5, 24, 12);
    D("earthspill", cx + 14, top + GATE_HALL.h * TS - 2, 6, 14, 8);
    for (const [x, y, v] of [[cx - 17, top + 9, 1], [cx + 15, top + 21, 2], [cx + 4, top + 5, 0], [cx - 12, top + GATE_HALL.h * TS - 9, 3]]) D("stones", x, y, v);
    const S = GATE_STAIR, K = STAIR_CHEEK, sy = S.y * TS;
    for (const [side, x0, dir, v] of [["w", S.x * TS, 1, 0], ["e", (S.x + S.w) * TS, -1, 1]]) {
      ids.add("stairpost." + side);
      ids.add("staircheek." + side);
      props.push({ id: "stairpost." + side, kind: "stairpost", x: x0 + dir * K.post.w / 2, y: sy + STAIR_CHEEK_TOP, v });
      props.push({ id: "staircheek." + side, kind: "staircheek", x: x0 + dir * K.wall.w / 2, y: (S.y + S.h) * TS, v });
    }
    lights.push({ x: cx, y: top + 4 * TS, rad: 120, col: [0.55, 0.68, 1], int: 0.9, flick: 0.02, id: "gateleak", owner: "stairlight", sky: true });
  }
  P("coalbin", 4, 37);
  P("quench", 4.5, 40);
  P("toolboard", 11.5, 35);
  P("runetable", 7.5, 45);
  P("clayvat", 4.25, 45);
  P("husk", 4.5, 42);
  loose.push({ id: "rusted_shovel", item: "head_shovel_rusted", x: 4 * TS + 14, y: 38 * TS + 12 });
  D("chalk", 6 * TS + 4, 44 * TS + 2, 1);
  D("chalk", 9 * TS + 6, 44 * TS + 8, 2);
  D("scorch", 6 * TS - 2, 41 * TS, 0);
  D("paper", 8 * TS + 4, 44 * TS + 6, 1);
  P("wallhooks", 67.75, 2, { v: 1 });
  P("weaponrack", 67.25, 4.25, { v: 1 });
  P("staffrack", 62.75, 5.5);
  P("armorstand", 62.5, 9.5, { v: 2 });
  P("armorpile", 66.75, 8);
  loose.push({ id: "rusted_axe", item: "head_axe_rusted", x: 64 * TS + 10, y: 6 * TS + 8 });
  D("weapon", 65 * TS + 2, 8 * TS + 6, 1);
  D("weapon", 63 * TS + 9, 9 * TS + 2, 2);
  const npcs = [
    { id: "npc.guardian", npc: "guardian", x: 55.5 * TS + 8, y: 4 * TS + 10, facing: "down" },
    { id: ARTIFICERY_WORKER.id, npc: ARTIFICERY_WORKER.npc, x: ARTIFICERY_WORKER.x, y: ARTIFICERY_WORKER.y, facing: "down" }
  ];
  return {
    id: "dungeon",
    w: MW,
    h: MH,
    grid,
    plan,
    style,
    tvar,
    rooms,
    props,
    decals,
    lights,
    loose,
    ritual,
    drips,
    npcs,
    // The stair's upper end: walk south off the top of the flight and you come out of the stair head on the surface
    // (and back). Shut until the stair is dug out. The spot (in the Vestibule, where the hall to the stair opens)
    // is for whoever finds the way in later.
    portals: [{
      id: ENTRANCES.surface_stair.below.portal,
      x: GATE_STAIR.x * TS + 2,
      y: (GATE_STAIR.y + GATE_STAIR.h) * TS - 10,
      w: GATE_STAIR.w * TS - 4,
      h: 10,
      dir: "down",
      to: { area: ENTRANCES.surface_stair.above.area, portal: ENTRANCES.surface_stair.above.portal },
      arrive: { x: (GATE_STAIR.x + GATE_STAIR.w / 2) * TS, y: (GATE_STAIR.y + GATE_STAIR.h) * TS - 14 },
      flag: ENTRANCES.surface_stair.flag,
      label: "THE HALLS: FIRST CELLAR"
    }],
    spots: [{ id: "stairfoot", kind: "door", x: (GATE_PASSAGE.x + GATE_PASSAGE.w / 2) * TS, y: GATE_PASSAGE.y * TS - 4, facing: "up" }],
    start: { x: 9 * TS + 8, y: 38 * TS + 14 },
    exits: [
      { x: 22, y: 1, label: "UPPER WARD", dir: "n" },
      { x: 50, y: 1, label: "TOWER", dir: "n" },
      { x: GATE_EXIT.x, y: GATE_EXIT.y, label: "SURFACE STAIR", dir: "s" },
      { x: 71, y: 47, label: "CELLARS", dir: "e" }
    ]
  };
}

// src/game/sim/reach.ts
var cellFeet = (tx, ty) => ({ x: tx * TS + 8, y: ty * TS + 11 });
function freeAt(g, boxes, x, y, size = [10, 5]) {
  const x0 = x - size[0] / 2, x1 = x + size[0] / 2, y0 = y - size[1], y1 = y;
  for (let ty = Math.floor(y0 / TS); ty <= Math.floor((y1 - 0.01) / TS); ty++)
    for (let tx = Math.floor(x0 / TS); tx <= Math.floor((x1 - 0.01) / TS); tx++) {
      if (tx < 0 || ty < 0 || tx >= g.w || ty >= g.h) return false;
      if (isSolidT(g.grid[ty * g.w + tx])) return false;
    }
  for (const b of boxes) if (x1 > b[0] && x0 < b[2] && y1 > b[1] && y0 < b[3]) return false;
  return true;
}
function bucketBoxes(g, boxes) {
  const buckets = /* @__PURE__ */ new Map();
  for (const b of boxes) {
    for (let ty = Math.floor(b[1] / TS) - 1; ty <= Math.floor(b[3] / TS) + 1; ty++)
      for (let tx = Math.floor(b[0] / TS) - 1; tx <= Math.floor(b[2] / TS) + 1; tx++) {
        if (tx < 0 || ty < 0 || tx >= g.w || ty >= g.h) continue;
        const k = ty * g.w + tx;
        let l = buckets.get(k);
        if (!l) buckets.set(k, l = []);
        l.push(b);
      }
  }
  return (x, y) => buckets.get(Math.floor(y / TS) * g.w + Math.floor(x / TS)) ?? [];
}
function reachable(g, boxes, start) {
  const near = bucketBoxes(g, boxes);
  const ok = (x, y) => freeAt(g, near(x, y), x, y);
  const stand = new Int8Array(g.w * g.h).fill(-1);
  const canStand = (tx, ty) => {
    const k = ty * g.w + tx;
    if (stand[k] < 0) {
      const f = cellFeet(tx, ty);
      stand[k] = ok(f.x, f.y) ? 1 : 0;
    }
    return stand[k] === 1;
  };
  const out = new Uint8Array(g.w * g.h);
  const sx = Math.floor(start.x / TS), sy = Math.floor((start.y - 3) / TS);
  if (sx < 0 || sy < 0 || sx >= g.w || sy >= g.h || !canStand(sx, sy)) return out;
  const q = [sy * g.w + sx];
  out[q[0]] = 1;
  while (q.length) {
    const k = q.pop(), tx = k % g.w, ty = k / g.w | 0;
    const a = cellFeet(tx, ty);
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = tx + dx, ny = ty + dy;
      if (nx < 0 || ny < 0 || nx >= g.w || ny >= g.h) continue;
      const nk = ny * g.w + nx;
      if (out[nk] || !canStand(nx, ny)) continue;
      let clear = true;
      for (let s = 4; s < TS; s += 4) if (!ok(a.x + dx * s, a.y + dy * s)) {
        clear = false;
        break;
      }
      if (!clear) continue;
      out[nk] = 1;
      q.push(nk);
    }
  }
  return out;
}

// src/game/surface.ts
var SW = 96;
var SH = 72;
var SURFACE_SEED = 7331;
var RUNE_T = { x: 48, y: 26 };
var RUNE_ART_R = 64;
var RUNE_CLEAR_PROPS = 7;
var CART_T = { x: 72, y: 36 };
function vnoise(x, y, k, s) {
  const fx = x / k, fy = y / k, x0 = Math.floor(fx), y0 = Math.floor(fy);
  let tx = fx - x0, ty = fy - y0;
  tx = tx * tx * (3 - 2 * tx);
  ty = ty * ty * (3 - 2 * ty);
  const a = hash2(x0, y0, s), b = hash2(x0 + 1, y0, s), c = hash2(x0, y0 + 1, s), d = hash2(x0 + 1, y0 + 1, s);
  return (a + (b - a) * tx) * (1 - ty) + (c + (d - c) * tx) * ty;
}
var fbm = (x, y, s) => 0.5 * vnoise(x, y, 13, s) + 0.3 * vnoise(x, y, 6, s + 1) + 0.2 * vnoise(x, y, 3, s + 2);
var IRON_VEINS = 12;
var CAMP = { x: 360, y: 176 };
var FOREST_GROUNDS = {
  hunt: [[8, 7], [15, 11], [11, 16], [7, 21], [10, 43], [12, 46], [29, 56], [20, 4]],
  forage: [[9, 6], [14, 13], [10, 18], [6, 22], [26, 12], [9, 45], [11, 47], [28, 58], [16, 9]]
};
function buildSurface(opts = {}) {
  const rng = mulberry(SURFACE_SEED);
  const n = SW * SH;
  const grid = new Uint8Array(n).fill(T.FLOOR);
  const style = new Uint8Array(n).fill(FS.GRASS);
  const tvar = new Uint8Array(n);
  const zone = new Uint8Array(n);
  const inb = (x, y) => x >= 0 && y >= 0 && x < SW && y < SH;
  const G3 = (x, y) => inb(x, y) ? grid[y * SW + x] : T.THICKET;
  const dRune = (x, y) => Math.hypot(x - RUNE_T.x, y - RUNE_T.y);
  const inGate = (x, y, m = 0) => x >= SURFACE_GATE_ZONE.x0 - m && x <= SURFACE_GATE_ZONE.x1 + m && y >= SURFACE_GATE_ZONE.y0 - m && y <= SURFACE_GATE_ZONE.y1 + m;
  const dg = buildDungeon();
  const under = new Int8Array(n).fill(-1);
  for (let y = 0; y < SH; y++) for (let x = 0; x < SW; x++) {
    const ux = x - DUNGEON_TO_SURFACE.dx + Math.round((vnoise(x, y, 7, 210) - 0.5) * 3.2);
    const uy = y - DUNGEON_TO_SURFACE.dy + Math.round((vnoise(x, y, 7, 211) - 0.5) * 3.2);
    if (ux < 0 || uy < 0 || ux >= dg.w || uy >= dg.h) continue;
    under[y * SW + x] = dg.plan[uy * dg.w + ux] === T.WALL ? 0 : 1;
  }
  const U = (x, y) => inb(x, y) ? under[y * SW + x] : -1;
  const wallLine = (x, y) => U(x, y) === 0 && (U(x - 1, y) === 1 || U(x + 1, y) === 1 || U(x, y - 1) === 1 || U(x, y + 1) === 1);
  for (let y = 0; y < SH; y++) for (let x = 0; x < SW; x++) {
    const i = y * SW + x;
    const edge = Math.min(x, y, SW - 1 - x, SH - 1 - y);
    if (edge < 2 + Math.floor(fbm(x, y, 220) * 7 - 0.6)) {
      grid[i] = T.THICKET;
      continue;
    }
    const wood = fbm(x, y, 201), wet = fbm(x, y, 202), rock = fbm(x, y, 203), dr = dRune(x, y);
    let z;
    if (inGate(x, y)) z = 5 /* GATE */;
    else if (dr < 6.2 + (vnoise(x, y, 3, 205) - 0.5) * 1.6) z = 4 /* CLEARING */;
    else if (Math.hypot(x - CART_T.x - 1, y - CART_T.y) < 3.2) z = 0 /* MEADOW */;
    else if (wet > 0.6 && !wallLine(x, y)) z = 3 /* HOLLOW */;
    else if (wood > 0.55) z = 1 /* WOODS */;
    else if (rock > 0.58) z = 2 /* ROCKY */;
    else z = 0 /* MEADOW */;
    zone[i] = z;
    let s = FS.GRASS;
    const pn = vnoise(x, y, 4, 206);
    switch (z) {
      case 4 /* CLEARING */:
        s = dr < 4.6 ? FS.EARTH : pn > 0.62 ? FS.MOSS : FS.GRASS;
        break;
      case 5 /* GATE */:
        s = x === SURFACE_GATE_ZONE.x0 || x === SURFACE_GATE_ZONE.x1 ? FS.MOSS : FS.GRASS;
        break;
      case 3 /* HOLLOW */:
        s = wet > 0.67 ? FS.MUD : pn > 0.3 ? FS.MOSS : FS.GRASS;
        break;
      case 1 /* WOODS */:
        s = wet > 0.5 && pn > 0.58 ? FS.MOSS : pn < 0.12 ? FS.GRASS : FS.LEAF;
        break;
      case 2 /* ROCKY */:
        s = pn > 0.58 ? FS.EARTH : pn > 0.36 ? FS.DIRT : FS.GRASS;
        break;
      default:
        s = vnoise(x, y, 5, 62) > 0.78 ? FS.DIRT : pn > 0.84 ? FS.MOSS : FS.GRASS;
    }
    if (wallLine(x, y) && z !== 4 /* CLEARING */ && z !== 5 /* GATE */) {
      const b = vnoise(x, y, 4, 215);
      if (b > 0.6) s = FS.EARTH;
      else if (b < 0.24) s = FS.MOSS;
    }
    style[i] = s;
  }
  {
    const seen2 = new Uint8Array(n), q = [RUNE_T.y * SW + RUNE_T.x];
    seen2[q[0]] = 1;
    while (q.length) {
      const k = q.pop(), x = k % SW, y = k / SW | 0;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, ny = y + dy, nk = ny * SW + nx;
        if (inb(nx, ny) && !seen2[nk] && grid[nk] === T.FLOOR) {
          seen2[nk] = 1;
          q.push(nk);
        }
      }
    }
    for (let k = 0; k < n; k++) if (grid[k] === T.FLOOR && !seen2[k]) grid[k] = T.THICKET;
  }
  for (let y = SURFACE_GATE_ZONE.y0; y <= SURFACE_GATE_ZONE.y1; y++) for (let x = SURFACE_GATE_ZONE.x0; x <= SURFACE_GATE_ZONE.x1; x++) grid[y * SW + x] = T.FLOOR;
  const plan = grid.slice();
  const props = [], lights = [], decals = [], loose = [];
  const ids = /* @__PURE__ */ new Set();
  const occ = new Uint8Array(n);
  const deco = new Uint8Array(n);
  const noBlock = new Uint8Array(n);
  const mark = (arr, cx, cy, r) => {
    for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++)
      if (inb(x, y) && Math.hypot(x - cx, y - cy) <= r) arr[y * SW + x] = 1;
  };
  for (let y = SURFACE_GATE_ZONE.y0 - 1; y <= SURFACE_GATE_ZONE.y1 + 1; y++) for (let x = SURFACE_GATE_ZONE.x0 - 1; x <= SURFACE_GATE_ZONE.x1 + 1; x++) if (inb(x, y)) noBlock[y * SW + x] = 1;
  mark(noBlock, CART_T.x + 1.5, CART_T.y + 0.5, 3.2);
  const trail = (ax, ay, bx, by, s) => {
    const len = Math.hypot(bx - ax, by - ay), nx = -(by - ay) / len, ny = (bx - ax) / len;
    for (let t = 0; t <= len; t += 0.5) {
      const f = t / len, wob = (vnoise(t, s, 6, 250) - 0.5) * 6 * Math.sin(f * Math.PI);
      mark(noBlock, ax + (bx - ax) * f + nx * wob, ay + (by - ay) * f + ny * wob, 1.1);
    }
  };
  trail(RUNE_T.x, RUNE_T.y + 5, SURFACE_GATE.x, SURFACE_GATE_ZONE.y0 - 1, 1);
  trail(RUNE_T.x + 5, RUNE_T.y + 1, CART_T.x - 1, CART_T.y, 2);
  trail(RUNE_T.x - 5, RUNE_T.y + 2, 30, 34, 3);
  const footprint2 = (kind, px, py) => {
    const b = propDef(kind).box;
    if (!b) return null;
    return { x0: Math.floor((px - b[0] / 2) / TS), x1: Math.floor((px + b[0] / 2 - 0.01) / TS), y0: Math.floor((py - b[1]) / TS), y1: Math.floor((py - 0.01) / TS) };
  };
  const tooNearRune = (px, py) => Math.hypot(px - (RUNE_T.x * TS + 8), py - (RUNE_T.y * TS + 8)) < RUNE_CLEAR_PROPS * TS;
  const canPlace = (kind, px, py, strict = true) => {
    if (tooNearRune(px, py)) return false;
    const tx = Math.floor(px / TS), ty = Math.floor((py - 1) / TS);
    if (!inb(tx, ty) || G3(tx, ty) !== T.FLOOR) return false;
    const f = footprint2(kind, px, py);
    if (!f) return !deco[ty * SW + tx] && !occ[ty * SW + tx];
    for (let y = f.y0 - 1; y <= f.y1 + 1; y++) for (let x = f.x0 - 1; x <= f.x1 + 1; x++) {
      if (!inb(x, y) || G3(x, y) !== T.FLOOR || occ[y * SW + x]) return false;
      const inside = x >= f.x0 && x <= f.x1 && y >= f.y0 && y <= f.y1;
      if (inside && (noBlock[y * SW + x] && strict)) return false;
      if (inside && (deco[y * SW + x] || inGate(x, y))) return false;
    }
    return true;
  };
  const P = (kind, px, py, o = {}) => {
    const tx = Math.floor(px / TS), ty = Math.floor((py - 1) / TS);
    let id = o.id ?? `${kind}@${tx},${ty}`;
    for (let k = 2; ids.has(id); k++) id = `${kind}@${tx},${ty}#${k}`;
    ids.add(id);
    const p = { kind, x: Math.round(px), y: Math.round(py), v: 0, ...o, id };
    props.push(p);
    const f = footprint2(kind, p.x, p.y);
    if (f) {
      for (let y = f.y0; y <= f.y1; y++) for (let x = f.x0; x <= f.x1; x++) if (inb(x, y)) occ[y * SW + x] = 1;
    } else if (inb(tx, ty)) deco[ty * SW + tx] = 1;
    const L = propDef(kind).light;
    if (L && (L.when === "always" || p.lit)) lights.push({ x: p.x + L.dx, y: p.y + L.dy, rad: L.rad, col: L.col, int: L.int, flick: L.flick, owner: id });
    return p;
  };
  const at = (tx, ty, jitter2 = 0) => ({
    x: tx * TS + 8 + (jitter2 ? Math.round((hash2(tx, ty, 260) - 0.5) * 2 * jitter2) : 0),
    y: ty * TS + 16 - (jitter2 ? Math.round(hash2(tx, ty, 261) * jitter2 * 0.6) : 0)
  });
  const rc = { x: RUNE_T.x * TS + 8, y: RUNE_T.y * TS + 8 };
  props.push({ id: "rune.surface", kind: "runecircle", x: rc.x, y: rc.y, v: 0 });
  lights.push({ x: rc.x, y: rc.y, rad: 78, col: [0.6, 0.38, 1], int: 0.75, flick: 0.06, id: "runeglow" });
  const gate = { x: (SURFACE_GATE_CORRIDOR.x + SURFACE_GATE_CORRIDOR.w / 2) * TS, y: (SURFACE_GATE.y + 1) * TS };
  const stairHead = P("buriedgate", gate.x, gate.y);
  lights.push({ x: gate.x, y: gate.y - 47, rad: 40, col: [0.62, 0.5, 1], int: 0.45, flick: 0.05, id: "wardglow", owner: stairHead.id });
  const cor = SURFACE_GATE_CORRIDOR, wL = SURFACE_GATE_ZONE.x0, wR = SURFACE_GATE_ZONE.x1;
  P("capstone", wL * TS + 9, (cor.y + 1) * TS + 15);
  P("capstone", wR * TS + 7, (cor.y + 3) * TS + 14, { v: 1 });
  const remains = [
    ["wallstub", 41, 22, 0],
    ["wallstub", 70, 18, 1],
    ["masonry", 58, 15, 0],
    ["masonry", 25, 37, 1],
    ["stoneslab", 50, 39, 0],
    ["statue_toppled", 22, 15, 0],
    ["statue_toppled", 77, 41, 1],
    ["standingstone", 44, 12, 0],
    ["standingstone", 53, 10, 1],
    ["cairn", 30, 47, 1]
  ];
  const placedRemains = [];
  for (const [kind, tx, ty, v] of remains) {
    const a = at(tx, ty);
    if (canPlace(kind, a.x, a.y, false)) placedRemains.push(P(kind, a.x, a.y, { v }));
  }
  P("cart", CART_T.x * TS + 8, CART_T.y * TS + 16);
  loose.push({ id: "basket", item: "basket", x: 75 * TS + 4, y: 37 * TS + 10 });
  const order = Array.from({ length: n }, (_, i) => i);
  for (let i = n - 1; i > 0; i--) {
    const j = rng() * (i + 1) | 0;
    const t = order[i];
    order[i] = order[j];
    order[j] = t;
  }
  const tryPlace = (kind, tx, ty, v, jitter2 = 4) => {
    const a = at(tx, ty, jitter2);
    if (!canPlace(kind, a.x, a.y)) return false;
    P(kind, a.x, a.y, { v });
    return true;
  };
  for (const i of order) {
    const x = i % SW, y = i / SW | 0;
    if (grid[i] !== T.FLOOR) continue;
    const z = zone[i];
    if (z === 4 /* CLEARING */) continue;
    const r = rng(), clump = vnoise(x, y, 4, 230), rockN = fbm(x, y, 203), wl = wallLine(x, y);
    if (z === 5 /* GATE */) {
      if ((x === wL || x === wR) && r < 0.4) tryPlace("tallgrass", x, y, 2, 3);
      continue;
    }
    let c = 0;
    const pick3 = (p) => {
      c += p;
      return r < c;
    };
    switch (z) {
      case 1 /* WOODS */:
        if (pick3(0.12 + 0.5 * clump)) tryPlace("tree", x, y, rng() * 3 | 0);
        else if (pick3(0.07)) tryPlace("bush", x, y, rng() * 4 | 0);
        else if (pick3(0.04)) tryPlace("sapling", x, y, rng() * 2 | 0);
        else if (pick3(0.02)) tryPlace("log", x, y, rng() * 3 | 0, 3);
        else if (pick3(0.012)) tryPlace("stump", x, y, rng() * 2 | 0);
        else if (pick3(0.016)) tryPlace("rock", x, y, 2 + (rng() * 2 | 0));
        else if (pick3(0.26)) tryPlace("fern", x, y, rng() * 3 | 0, 5);
        break;
      case 3 /* HOLLOW */:
        if (pick3(0.22)) tryPlace("fern", x, y, rng() * 3 | 0, 5);
        else if (pick3(0.1)) tryPlace("tallgrass", x, y, rng() * 2 | 0, 5);
        else if (pick3(0.05 * (0.5 + clump))) tryPlace("tree", x, y, 2);
        else if (pick3(0.05)) tryPlace("bush", x, y, 2 + (rng() * 2 | 0));
        else if (pick3(0.015)) tryPlace("log", x, y, rng() * 3 | 0, 3);
        else if (pick3(0.012)) tryPlace("boulder", x, y, 1);
        break;
      case 2 /* ROCKY */: {
        const rk = Math.max(0, rockN - 0.5) * 2.2 * (0.4 + clump);
        if (pick3(0.16 * rk)) tryPlace("rock", x, y, rng() * 2 | 0);
        else if (pick3(0.06 * rk)) tryPlace("boulder", x, y, rng() * 3 | 0);
        else if (pick3(rockN > 0.66 ? 0.03 : 0)) tryPlace("outcrop", x, y, rng() * 2 | 0, 2);
        else if (pick3(0.03)) tryPlace("tree", x, y, rng() * 3 | 0);
        else if (pick3(0.035)) tryPlace("bush", x, y, rng() * 4 | 0);
        else if (pick3(0.04)) tryPlace("tallgrass", x, y, rng() * 3 | 0, 5);
        else if (pick3(0.03)) tryPlace("fern", x, y, rng() * 3 | 0, 5);
        break;
      }
      default:
        if (pick3(0.035 * clump)) tryPlace("tree", x, y, rng() * 3 | 0);
        else if (pick3(0.035 * (0.4 + clump))) tryPlace("bush", x, y, rng() * 4 | 0);
        else if (pick3(0.012)) tryPlace("sapling", x, y, rng() * 2 | 0);
        else if (pick3(5e-3)) tryPlace("stump", x, y, rng() * 2 | 0);
        else if (pick3(6e-3)) tryPlace("rock", x, y, rng() * 4 | 0);
        else if (pick3((wl ? 0.16 : 0.05) * (0.5 + clump))) tryPlace("tallgrass", x, y, rng() * 3 | 0, 5);
    }
  }
  const blockBoxes = () => props.flatMap((p) => {
    const b = propDef(p.kind).box;
    return b ? [[p.x - b[0] / 2, p.y - b[1], p.x + b[0] / 2, p.y]] : [];
  });
  for (let pass = 0; pass < 4; pass++) {
    const boxes = blockBoxes();
    const reach = reachable({ w: SW, h: SH, grid }, boxes, { x: rc.x, y: rc.y + 4 });
    const sealed = [];
    for (let k = 0; k < n; k++) if (!reach[k] && grid[k] === T.FLOOR && !occ[k]) sealed.push(k);
    if (!sealed.length) break;
    const near = (p) => sealed.some((k) => Math.abs(k % SW * TS + 8 - p.x) < 40 && Math.abs((k / SW | 0) * TS + 8 - p.y) < 40);
    const keep = new Set(placedRemains);
    for (let i = props.length - 1; i >= 0; i--) {
      const p = props[i];
      if (propDef(p.kind).box && !keep.has(p) && p.kind !== "cart" && near(p)) props.splice(i, 1);
    }
    occ.fill(0);
    for (const p of props) {
      const f = footprint2(p.kind, p.x, p.y);
      if (f) for (let y = f.y0; y <= f.y1; y++) for (let x = f.x0; x <= f.x1; x++) occ[y * SW + x] = 1;
    }
  }
  const D = (kind, x, y, v = 0, w, h) => decals.push({ kind, x: Math.round(x), y: Math.round(y), v, w, h });
  const clearOfRune = (x, y, rad) => Math.hypot(x - rc.x, y - rc.y) > RUNE_ART_R + 6 + rad;
  const jit = (s) => (rng() - 0.5) * s;
  for (let y = 1; y < SH - 1; y++) for (let x = 1; x < SW - 1; x++) {
    const i = y * SW + x;
    if (grid[i] !== T.FLOOR || zone[i] === 5 /* GATE */) continue;
    const bx = x * TS + 8, by = y * TS + 8, h = hash2(x, y, 240);
    if (under[i] === 1 && h < 0.05) {
      const w = 26 + rng() * 44, hh = 12 + rng() * 14;
      if (clearOfRune(bx, by, w / 2)) D("hump", bx + jit(10), by + jit(8), style[i] === FS.EARTH || zone[i] === 2 /* ROCKY */ ? 1 : 0, w, hh);
    } else if (wallLine(x, y) && h < 0.34 && vnoise(x, y, 5, 241) > 0.3) {
      const w = 18 + rng() * 14;
      if (clearOfRune(bx, by, w / 2)) D("hump", bx + jit(6), by + jit(6), style[i] === FS.EARTH ? 1 : 0, w, 9 + rng() * 6);
    } else if (zone[i] === 3 /* HOLLOW */ && h > 0.95) {
      if (clearOfRune(bx, by, 30)) D("hollow", bx + jit(8), by + jit(8), 0, 30 + rng() * 30, 16 + rng() * 14);
    }
  }
  for (const p of props) if (p.kind === "tree" && hash2(p.x, p.y, 242) < 0.65 && clearOfRune(p.x + 6, p.y - 12, 28)) D("shade", p.x + 6 + jit(6), p.y - 12 + jit(4), 0, 44 + rng() * 14);
  {
    const top = SURFACE_GATE_ZONE.y0 * TS + 4, len = (SURFACE_GATE.y - SURFACE_GATE_ZONE.y0) * TS + 4;
    D("ridge", wL * TS + 8, top, 1, len, 10);
    D("ridge", wR * TS + 8, top + 6, 1, len - 6, 10);
  }
  for (let y = 1; y < SH - 1; y++) for (let x = 1; x < SW - 1; x++) {
    const i = y * SW + x;
    if (grid[i] !== T.FLOOR) continue;
    const bx = x * TS, by = y * TS, r = rng(), s = style[i];
    if (!clearOfRune(bx + 8, by + 8, 14)) continue;
    if (zone[i] === 5 /* GATE */) {
      if ((x === wL || x === wR) && r < 0.45) D("mosspatch", bx + 8 + jit(6), by + 8 + jit(10), 1, 10 + rng() * 8);
      continue;
    }
    if (s === FS.MOSS) {
      if (r < 0.12) D("mosspatch", bx + 8 + jit(8), by + 8 + jit(8), rng() * 2 | 0, 10 + rng() * 14);
    } else if (s === FS.LEAF) {
      if (r < 0.4) D("leaves", bx + 8 + jit(6), by + 8 + jit(6), 0);
      else if (r < 0.45) D("mosspatch", bx + 8, by + 8, 0, 10 + rng() * 10);
    } else if (s === FS.MUD) {
      if (r < 0.06) D("puddle", bx + jit(6), by + 4 + jit(4), rng() * 2 | 0, 14 + rng() * 14, 6 + rng() * 4);
      else if (r < 0.1) D("pebbles", bx + 8, by + 8, 0);
    } else if (s === FS.EARTH) {
      if (r < 0.09) D("pebbles", bx + 8 + jit(6), by + 8 + jit(6), 0);
    } else if (s === FS.DIRT) {
      if (r < 0.06) D("pebbles", bx + 8, by + 8, 0);
      else if (r < 0.09) D("debris", bx + rng() * 12, by + rng() * 12, rng() * 4 | 0);
    } else if (r < 0.025) D("mosspatch", bx + 8 + jit(8), by + 8 + jit(8), 1, 8 + rng() * 10);
  }
  const meadowFlowers = (x, y) => vnoise(x, y, 5, 270) > 0.62;
  for (let y = 1; y < SH - 1; y++) for (let x = 1; x < SW - 1; x++) {
    const i = y * SW + x;
    if (grid[i] !== T.FLOOR) continue;
    const bx = x * TS, by = y * TS, r = rng(), s = style[i], z = zone[i];
    if (!clearOfRune(bx + 8, by + 8, 10)) continue;
    if (z === 5 /* GATE */) {
      if (x === wL || x === wR) {
        if (r < 0.7) D("weeds", bx + 8 + jit(8), by + 12 + jit(6), 0);
      } else if (r < 0.06) D("tuft", bx + 3 + rng() * 10, by + 6 + rng() * 9, 0);
      continue;
    }
    if (wallLine(x, y) && r < 0.22) {
      D("weeds", bx + 8 + jit(10), by + 12 + jit(8), 0);
      continue;
    }
    if (s === FS.GRASS) {
      if (z === 0 /* MEADOW */ && meadowFlowers(x, y) && r < 0.16) D("wildflowers", bx + 8 + jit(8), by + 8 + jit(8), vnoise(x, y, 9, 271) * 4 | 0);
      else if (r < 0.3) D("tuft", bx + 3 + rng() * 10, by + 6 + rng() * 9, 0);
      else if (r < 0.34) D("flowers", bx + 8, by + 8, rng() * 4 | 0);
      if (rng() < 0.12) D("tuft", bx + 3 + rng() * 10, by + 6 + rng() * 9, 0);
    } else if (s === FS.MOSS) {
      if (r < 0.1) D("tuft", bx + 3 + rng() * 10, by + 6 + rng() * 9, 0);
      else if (r < 0.13) D("flowers", bx + 8, by + 8, 0);
    } else if (s === FS.LEAF) {
      if (r < 0.05) D("tuft", bx + 3 + rng() * 10, by + 6 + rng() * 9, 0);
    } else if (s === FS.MUD) {
      if (r < 0.08) D("weeds", bx + 8 + jit(8), by + 12, 0);
    } else if (r < 0.1) D("tuft", bx + 3 + rng() * 10, by + 6 + rng() * 9, 0);
  }
  for (const p of props) {
    if ((p.kind === "tree" || p.kind === "stump") && rng() < 0.6) D("roots", p.x - 4 + jit(4), p.y - 4, 0);
    if (placedRemains.includes(p)) {
      for (let k = 0; k < 4; k++) D("ivy", p.x + jit(28), p.y - 2 + jit(6), rng() * 4 | 0, 10 + rng() * 14);
      for (let k = 0; k < 2; k++) D("mosspatch", p.x + jit(30), p.y + jit(8), rng() * 2 | 0, 10 + rng() * 10);
      D("weeds", p.x + jit(20), p.y + 2, 0);
    }
  }
  const portals = [], exits = [];
  if (opts.westRoad !== false) {
    const { y0, y1 } = WEST_ROAD.surface, mid = y0 + y1 >> 1;
    let mouth = SW, far = 1;
    for (let y = y0; y <= y1; y++) {
      let x = 1;
      for (; x < SW - 1 && grid[y * SW + x] === T.THICKET; x++) {
        grid[y * SW + x] = T.FLOOR;
        plan[y * SW + x] = T.FLOOR;
        style[y * SW + x] = y === mid || hash2(x, y, 280) < 0.6 ? FS.EARTH : FS.DIRT;
      }
      mouth = Math.min(mouth, x);
      far = Math.max(far, x);
    }
    for (let x = mouth; x < far + 9; x++) {
      const y = mid + Math.round((vnoise(x, 3, 5, 281) - 0.5) * 2.4);
      for (const yy of [y, y + (hash2(x, y, 282) < 0.5 ? 1 : -1)]) if (inb(x, yy) && grid[yy * SW + x] === T.FLOOR && dRune(x, yy) > 9) style[yy * SW + x] = yy === y ? FS.EARTH : FS.DIRT;
    }
    D("ruts", TS, mid * TS + 8, 0, (far + 5) * TS);
    for (let x = 1; x < far + 6; x++) {
      if (hash2(x, 7, 283) < 0.5) D("pebbles", x * TS + 8, mid * TS + 4 + hash2(x, 8, 284) * 10, 0);
      for (const y of [y0, y1]) if (hash2(x, y, 285) < 0.7) D("weeds", x * TS + 3 + hash2(x, y, 286) * 10, y * TS + (y === y0 ? 7 : 15), 0);
    }
    for (let x = 1; x < mouth; x++) for (const y of [y0, y1]) {
      const h = hash2(x, y, 287);
      if (h > 0.82) continue;
      const kind = h < 0.45 ? "fern" : "tallgrass", px = x * TS + 3 + Math.round(hash2(x, y, 288) * 10), py = y === y0 ? y * TS + 6 + Math.round(hash2(x, y, 289) * 4) : (y + 1) * TS - Math.round(hash2(x, y, 289) * 3);
      const id = `${kind}.road@${x},${y}`;
      ids.add(id);
      props.push({ id, kind, x: px, y: py, v: Math.floor(h * 40) % 3 });
      if (h < 0.3) D("mosspatch", px, y === y0 ? y * TS + 3 : (y + 1) * TS - 3, 1, 10 + Math.floor(h * 30));
      if (h > 0.5) D("leaves", px + 4, y === y0 ? y * TS + 5 : (y + 1) * TS - 6, 0);
    }
    const wx = Math.max(2, mouth - 1);
    ids.add("waymark.west");
    props.push({ id: "waymark.west", kind: "waymark", x: wx * TS + 9, y: y0 * TS + 12, v: 0 });
    D("mosspatch", wx * TS + 8, y0 * TS + 12, 1, 12);
    portals.push({
      id: WEST_ROAD.portal,
      x: TS,
      y: y0 * TS,
      w: TS + 4,
      h: (y1 - y0 + 1) * TS,
      dir: "left",
      to: { area: "town", portal: "east_road" },
      arrive: { x: 2 * TS + 10, y: mid * TS + 12 },
      label: "THE OLD ROAD"
    });
    exits.push({ x: 0, y: mid, label: "WESTWAKE", dir: "w" });
  }
  if (opts.iron !== false) {
    const cand = [];
    for (let y = 2; y < SH - 2; y++) for (let x = 2; x < SW - 2; x++) {
      const z = zone[y * SW + x];
      if (grid[y * SW + x] !== T.FLOOR || z === 5 /* GATE */ || z === 4 /* CLEARING */) continue;
      cand.push([hash2(x, y, 301) + (z === 2 /* ROCKY */ ? 0 : 1), x, y]);
    }
    cand.sort((a, b) => a[0] - b[0] || a[2] - b[2] || a[1] - b[1]);
    const veins = [];
    for (const [, x, y] of cand) {
      if (veins.length >= IRON_VEINS) break;
      if (dRune(x, y) < 8 || veins.some((v) => Math.hypot(v.x - x, v.y - y) < 5)) continue;
      const a = at(x, y, 3);
      if (!canPlace("ironore", a.x, a.y)) continue;
      P("ironore", a.x, a.y, { v: Math.floor(hash2(x, y, 302) * 3) });
      veins.push({ x, y });
    }
  }
  const spots = [{ id: "stairhead", kind: "door", x: gate.x, y: gate.y + 7, facing: "up" }];
  if (opts.camp !== false) {
    const place = (kind, id, px, py, o = {}) => {
      for (let r = 0; r <= 24; r += 4) for (const [dx, dy] of r ? [[r, 0], [-r, 0], [0, r], [0, -r], [r, r], [-r, -r], [r, -r], [-r, r]] : [[0, 0]]) {
        if (canPlace(kind, px + dx, py + dy, false)) return P(kind, px + dx, py + dy, { ...o, id });
      }
      return null;
    };
    const C = CAMP;
    place("campfire", "camp.fire", C.x, C.y, { lit: true });
    place("leanto", "camp.leanto", C.x - 42, C.y - 22);
    place("peltrack", "camp.rack", C.x + 72, C.y - 4);
    place("seatlog", "camp.log", C.x, C.y + 24);
    const beds = [[C.x - 44, C.y + 14], [C.x + 42, C.y - 24], [C.x + 46, C.y + 22]];
    beds.forEach(([x, y], i) => {
      const b = place("bedroll", `camp.bed.${i + 1}`, x, y, { v: i });
      if (b) spots.push({ id: `bed.${i + 1}`, kind: "bed", x: b.x, y: b.y + 2, facing: "down" });
    });
    const stand = (id, kind, tx, ty, facing = "down") => {
      for (let r = 0; r <= 4; r++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
        const x = tx + dx, y = ty + dy;
        if (![-1, 0, 1].every((i) => inb(x + i, y) && G3(x + i, y) === T.FLOOR && !occ[y * SW + x + i])) continue;
        if (!inb(x, y - 1) || occ[(y - 1) * SW + x]) continue;
        spots.push({ id, kind, x: x * TS + 8, y: y * TS + 12, facing });
        return;
      }
    };
    const ft = { x: Math.floor(C.x / TS), y: Math.floor((C.y - 1) / TS) };
    stand("camp.w", "camp", ft.x - 2, ft.y, "right");
    stand("camp.e", "camp", ft.x + 2, ft.y, "left");
    stand("camp.s", "camp", ft.x, ft.y + 2, "up");
    stand("camp.n", "camp", ft.x, ft.y - 2, "down");
    FOREST_GROUNDS.hunt.forEach(([x, y], i) => stand(`hunt.${i + 1}`, "hunt", x, y));
    FOREST_GROUNDS.forage.forEach(([x, y], i) => stand(`forage.${i + 1}`, "forage", x, y));
  }
  const stair = ENTRANCES.surface_stair;
  portals.push({
    id: stair.above.portal,
    x: gate.x - 26,
    y: gate.y,
    w: 52,
    h: 10,
    dir: "up",
    to: { area: stair.below.area, portal: stair.below.portal },
    arrive: { x: gate.x, y: gate.y + 7 },
    flag: stair.flag,
    label: "THE SURFACE"
  });
  return {
    id: "surface",
    w: SW,
    h: SH,
    grid,
    plan,
    style,
    tvar,
    rooms: [],
    props,
    decals,
    lights,
    loose,
    start: { x: rc.x, y: rc.y + 4 },
    exits,
    drips: [],
    outdoor: true,
    ambient: [0.32, 0.31, 0.42],
    portals,
    // where someone looking for the way in ends up (data only, like the town's spots), and the camp's places
    spots
  };
}

// src/game/town.ts
var TOWN_SEED = 4177;
var TOWN_AMBIENT = [0.3, 0.3, 0.42];
function areaKit(w, h) {
  const n = w * h;
  const grid = new Uint8Array(n).fill(T.WALL), style = new Uint8Array(n), tvar = new Uint8Array(n);
  const props = [], lights = [], decals = [], loose = [], portals = [], spots = [];
  const ids = /* @__PURE__ */ new Set();
  const inb = (x, y) => x >= 0 && y >= 0 && x < w && y < h;
  const set = (x, y, t, s) => {
    if (!inb(x, y)) return;
    grid[y * w + x] = t;
    if (s !== void 0) style[y * w + x] = s;
  };
  const rect = (x, y, rw, rh, t, s) => {
    for (let j = y; j < y + rh; j++) for (let i = x; i < x + rw; i++) set(i, j, t, s);
  };
  const P = (kind, px, py, o = {}) => {
    const tx = Math.floor(px / TS), ty = Math.floor((py - 1) / TS);
    let id = o.id ?? `${kind}@${tx},${ty}`;
    for (let k = 2; ids.has(id); k++) id = `${kind}@${tx},${ty}#${k}`;
    ids.add(id);
    const p = { kind, x: Math.round(px), y: Math.round(py), v: 0, ...o, id };
    props.push(p);
    const L = propDef(kind).light;
    if (L && (L.when === "always" || p.lit)) lights.push({ x: p.x + L.dx, y: p.y + L.dy, rad: L.rad, col: L.col, int: L.int, flick: L.flick, owner: id });
    return p;
  };
  const Pt = (kind, tx, ty, o = {}) => P(kind, tx * TS + 8, ty * TS + 16, o);
  const D = (kind, x, y, v = 0, dw, dh) => {
    decals.push({ kind, x: Math.round(x), y: Math.round(y), v, w: dw, h: dh });
  };
  const spot = (id, kind, x, y, facing) => {
    spots.push({ id, kind, x: Math.round(x), y: Math.round(y), facing });
  };
  return { n, grid, style, tvar, props, lights, decals, loose, portals, spots, inb, set, rect, P, Pt, D, spot };
}
var STREET_OF = {
  guild: "MARKET SQUARE",
  tailor: "MARKET SQUARE",
  jeweler: "MARKET SQUARE",
  armory: "HIGH STREET",
  tavern: "LOW STREET",
  smithy: "LOW STREET"
};
function buildTown() {
  const W = TOWN_W, H2 = TOWN_H, k = areaKit(W, H2);
  const { grid, style, props, P, Pt, D, spot } = k;
  const rng = mulberry(TOWN_SEED);
  const I = (x, y) => y * W + x;
  const S = STREETS, hs = S.high, sq = S.square, Wl = S.wall;
  const keep = new Uint8Array(k.n);
  const pave = (x0, y0, x1, y1, s) => {
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
      grid[I(x, y)] = T.FLOOR;
      style[I(x, y)] = s;
      keep[I(x, y)] = 1;
    }
  };
  for (let y = 0; y < H2; y++) for (let x = 0; x < W; x++) {
    const i = I(x, y), pn = vnoise(x, y, 4, 311);
    grid[i] = T.FLOOR;
    style[i] = pn > 0.8 ? FS.DIRT : pn < 0.14 ? FS.MOSS : FS.GRASS;
  }
  pave(Wl.westX0, hs.y0, Wl.x1, hs.y1, FS.SETT);
  pave(Wl.x1 + 1, hs.y0, W - 1, hs.y1, FS.DIRT);
  pave(0, hs.y0, Wl.westX0 - 1, hs.y1, FS.DIRT);
  pave(sq.x0, sq.y0, sq.x1, sq.y1, FS.SETT);
  pave(sq.x0 + 1, sq.y0 + 1, sq.x1 - 1, sq.y1 - 1, FS.WEAVE);
  pave(33, 27, 36, 29, FS.SETT);
  pave(58, 27, 61, 29, FS.SETT);
  pave(60, 17, 61, 29, FS.SETT);
  pave(7, S.oldLane.y0, 55, S.oldLane.y1, FS.COBBLE);
  pave(56, S.oldLane.y0, 86, S.oldLane.y1, FS.SETT);
  pave(33, 17, 34, 29, FS.COBBLE);
  pave(41, 17, 41, 26, FS.DIRT);
  pave(53, 17, 53, 26, FS.DIRT);
  pave(46, 38, 49, 44, FS.COBBLE);
  pave(8, S.low.y0, 86, S.low.y1, FS.COBBLE);
  pave(8, S.low.y0, 19, S.low.y1, FS.MUD);
  pave(20, S.low.y0, 23, S.low.y1, FS.DIRT);
  pave(81, S.low.y0, 86, S.low.y1, FS.DIRT);
  pave(21, 33, 22, 44, FS.COBBLE);
  pave(21, 48, 22, 57, FS.DIRT);
  pave(46, 48, 48, 57, FS.DIRT);
  pave(8, S.back.y0, 86, S.back.y1, FS.DIRT);
  pave(84, 33, 86, 57, FS.DIRT);
  pave(58, 39, 62, 44, FS.EARTH);
  pave(62, 48, 83, 57, FS.EARTH);
  pave(10, 35, 18, 37, FS.EARTH);
  pave(23, 10, 28, 13, FS.DIRT);
  for (const [x0, y0, x1, y1] of [[10, 46, 12, 46], [15, 45, 17, 46], [9, 59, 14, 59], [30, 58, 33, 59], [72, 59, 76, 60]]) pave(x0, y0, x1, y1, FS.MUD);
  for (let y = Wl.northY0; y <= Wl.southY1; y++) for (let x = Wl.westX0; x <= Wl.x1; x++) {
    const ring = x <= Wl.westX1 || x >= Wl.x0 || y <= Wl.northY1 || y >= Wl.southY0;
    if (ring && (y < Wl.gateY0 || y > Wl.gateY1)) k.set(x, y, T.WALL, WS.RAMPART);
  }
  const signV = (kind) => Math.max(0, SIGNS.findIndex(([s]) => s === kind));
  const stamp = (b, i) => {
    k.rect(b.x, b.y, b.w, b.h, T.WALL, 0);
    k.rect(b.x, b.y + b.h - 1, b.w, 1, T.FRONT, 0);
    D("building", b.x * TS, b.y * TS, i, b.w * TS, b.h * TS);
    const foot = (b.y + b.h) * TS, top = foot - FRONT_H, rune = b.light === "rune";
    const ch = chimneyPx(b);
    if (ch) P("chimney", ch.x, ch.y + 1);
    for (const c of b.lit ?? []) P(rune ? "winglow_rune" : "winglow", (b.x + c) * TS + 8, top + WIN.top + 8, { v: rune ? 1 : 0 });
    if (b.light !== "none") for (let c = 0; c < b.w; c++) {
      if (!(b.win?.includes(c) || c === b.door?.col) || rng() > 0.5) continue;
      P("winglow_up", (b.x + c) * TS + 8 + (c === b.door?.col && b.door.kind === "hauler" ? 8 : 0), top + UPWIN.top + 6, { v: rune ? 3 : 2 });
    }
    if (b.light !== "none") for (const c of b.dormers ?? []) {
      const w = dormerPx(b, c);
      P("winglow_up", w.x, w.y - 1, { v: rune ? 3 : 2 });
    }
    if (!b.door) return;
    const d = doorPx(b), half = DOOR[d.kind].w / 2;
    for (let x = Math.floor((d.x - half) / TS); x <= Math.floor((d.x + half - 1) / TS); x++) if (k.inb(x, b.y + b.h)) keep[I(x, b.y + b.h)] = 1;
    if (b.sign) P(b.sign, d.x + half + 10, top + 24, { v: signV(b.sign) });
    if (rune) P("rune_sconce", d.x - half - 7, top + 22);
    else if (b.interior) P("lantern", d.x - half - 8, top + 22);
    else if (b.light === "torch" && rng() < 0.6) P("torch", d.x - half - 7, top + 26, { lit: true });
    spot(`door.${b.id}`, "door", d.x, foot + 10, "up");
    if (b.interior) {
      k.portals.push({
        id: `door.${b.id}`,
        x: d.x - half + 1,
        y: foot + 3,
        w: half * 2 - 2,
        h: 9,
        dir: "up",
        door: true,
        to: { area: b.interior, portal: "door" },
        arrive: { x: d.x, y: foot + 9 },
        label: STREET_OF[b.id]
      });
      D("doormat", d.x, foot + 5);
    }
  };
  BUILDINGS.forEach(stamp);
  for (const [x, y] of [
    [12, 33],
    [18, 33],
    [25, 33],
    [31, 33],
    [61, 33],
    [67, 33],
    [73, 33],
    [79, 33],
    // the High Street's south verge
    [38, 28],
    [56, 28],
    [38, 36],
    [56, 36],
    [44, 28],
    [50, 28],
    // the square
    [62, 19],
    [62, 26],
    [58, 17],
    [64, 17],
    [70, 17],
    [76, 17],
    [82, 17],
    [86, 29],
    [83, 34]
    // Lamp Street, the rich end of Old Lane, the gate
  ]) Pt("rune_lamp", x, y);
  for (const [x, y] of [[14, 17], [30, 17], [46, 17], [27, 14], [12, 47.7], [26, 47.7], [36, 48], [49, 48], [61, 48], [64, 49], [70, 49], [23, 61], [54, 61], [80, 61], [20, 38], [63, 44]])
    Pt("torch_post", x, y, { lit: true });
  Pt("brazier", 91, 29.4, { lit: true });
  Pt("brazier", 70.5, 56.4, { lit: true });
  const gn = BUILDINGS.find((b) => b.id === "gate_n"), gateFoot = (gn.y + gn.h) * TS;
  P("rune_sconce", (gn.x + 2) * TS, gateFoot - 10);
  P("keepstone", gn.x * TS + 11, gateFoot - 5);
  P("keepstone", (gn.x + 3) * TS + 6, gateFoot - 17, { v: 1 });
  P("banner", (gn.x + 1) * TS, gateFoot - 12, { v: 1 });
  P("banner", (gn.x + 3) * TS, gateFoot - 12, { v: 1 });
  Pt("milestone", 91.5, 33.2);
  Pt("towntree", 92.4, 28.2, { v: 1 });
  Pt("bush", 91.2, 33.6, { v: 2 });
  Pt("bush", 93, 33.5, { v: 0 });
  k.portals.push({
    // (the box reaches the last column: the road runs to the edge of the map now, and so does the way out)
    id: "east_road",
    x: (W - 2) * TS - 2,
    y: hs.y0 * TS,
    w: 2 * TS + 2,
    h: (hs.y1 - hs.y0 + 1) * TS,
    dir: "right",
    to: { area: "surface", portal: "west_road" },
    arrive: { x: (W - 4) * TS + 8, y: hs.y0 * TS + 28 },
    label: `${TOWN_NAME}, MARKET TOWN`
  });
  const wn = BUILDINGS.find((b) => b.id === "bar_n"), barFoot = (wn.y + wn.h) * TS;
  P("rune_sconce", (wn.x + 2) * TS, barFoot - 10);
  P("banner", (wn.x + 1) * TS, barFoot - 12, { v: 1 });
  P("banner", (wn.x + 3) * TS, barFoot - 12, { v: 1 });
  P("tollbar", (Wl.westX0 + Wl.westX1 + 1) / 2 * TS, (hs.y1 + 1) * TS);
  Pt("rune_lamp", 9, 29);
  Pt("marketcross", 47, 32.3);
  const stalls = [[40.2, 35.2, 0], [44, 35.2, 3], [50, 35.2, 1], [53.8, 35.2, 2], [40.2, 31.4, 2], [53.8, 31.4, 0]];
  stalls.forEach(([x, y, v], i) => {
    const s = Pt("stall", x, y, { v });
    spot(`stall.${i}.keeper`, "stall", s.x, s.y - 12, "down");
    spot(`stall.${i}.customer`, "customer", s.x, s.y + 9, "up");
    D("straw", s.x + 4, s.y + 6, 0, 26);
  });
  Pt("noticeboard", 52.5, 36.9);
  for (const [x, y, v] of [[42, 27.5, 0], [52, 27.5, 0], [76.9, 15.3, 0], [81.1, 15.3, 0], [85.6, 33.3, 1]]) Pt("bannerpole", x, y, { v });
  for (const [kind, x, y, v] of [
    ["crate", 42.2, 35.6, 0],
    ["crate", 42.2, 34.9, 1],
    ["barrel", 51.9, 34.9, 0],
    ["sack", 46, 35.7, 0],
    ["barrel", 38.2, 31.6, 1],
    ["crate", 55.6, 31.7, 0],
    ["sack", 48.2, 35.7, 0],
    ["planter", 39.5, 27.5, 0],
    ["planter", 45, 27.5, 1],
    ["planter", 49, 27.5, 3],
    ["planter", 54.5, 27.5, 2],
    ["wagon", 39.8, 36.9, 0]
  ]) Pt(kind, x, y, { v });
  for (const [id, x, y, f] of [["cross.n", 47.5, 30.4, "down"], ["cross.e", 50.2, 32.6, "left"], ["cross.w", 44.8, 32.6, "right"], ["cross.s", 47.5, 34.4, "up"], ["board", 53, 36.6, "down"], ["guildsteps", 46.2, 27.8, "down"]])
    spot(`idle.${id}`, "idle", x * TS, y * TS, f);
  D("wear", 47.5 * TS, 32.5 * TS, 0, 120, 70);
  D("wear", 47.5 * TS, 28 * TS, 0, 60, 26);
  Pt("well", 25.5, 11.5);
  Pt("keepstatue", 28.6, 9.4, { v: 1 });
  Pt("towntree", 22.6, 9.6, { v: 0 });
  Pt("bench", 25.4, 13.5);
  for (let i = 0; i < 7; i++) D("wildflowers", 28.4 * TS + rng() * 22, 10 * TS + rng() * 10, i % 4);
  D("wear", 25.5 * TS + 8, 12.4 * TS, 0, 70, 34);
  spot("idle.well", "idle", 24.6 * TS, 12.8 * TS, "right");
  spot("idle.statue", "idle", 29 * TS, 11 * TS, "up");
  Pt("woodpile", 14.5, 14.45);
  Pt("barrel", 21.6, 14.4, { v: 1 });
  Pt("coop", 37.6, 13.6);
  Pt("laundry", 10.6, 7.6);
  const fenceRow = (x0, x1, y, v, gaps = []) => {
    for (let x = x0; x <= x1; x++) if (!gaps.includes(x)) Pt("fence", x, y, { v });
  };
  const fenceCol = (x, y0, y1, v) => {
    for (let y = y0; y <= y1; y++) Pt("fence_v", x, y, { v });
  };
  fenceRow(63, 85, 18, 0, [67, 78]);
  for (const [kind, x, y, v] of [["towntree", 65, 20.2, 2], ["planter", 68.4, 20.5, 1], ["towntree", 73.6, 21.6, 0], ["planter", 76, 22.6, 2], ["planter", 79.5, 20.4, 0], ["towntree", 83.2, 21.8, 1], ["bush", 70.5, 21, 3], ["bush", 81.6, 22.6, 1], ["bench", 75.5, 20]])
    Pt(kind, x, y, { v: v ?? 0 });
  for (let i = 0; i < 26; i++) D(i % 3 ? "wildflowers" : "flowers", 64 * TS + rng() * 21 * TS, 19 * TS + rng() * 3 * TS, rng() * 4 | 0);
  fenceRow(63, 82, 34, 1, [70, 77]);
  fenceRow(58, 62, 38, 1);
  fenceRow(24, 35, 34, 1, [30]);
  D("plot", 64 * TS, 35 * TS + 4, 0, 44, 30);
  D("plot", 72 * TS, 35 * TS + 2, 1, 40, 26);
  D("plot", 25 * TS, 35 * TS + 6, 2, 56, 30);
  D("plot", 59 * TS, 34 * TS + 2, 1, 40, 26);
  Pt("laundry", 67.8, 37.4);
  Pt("coop", 80.4, 36.4);
  Pt("woodpile", 75.4, 37.6);
  Pt("towntree", 79, 36.2, { v: 2 });
  Pt("laundry", 31.6, 37.6);
  Pt("towntree", 34.4, 36.4, { v: 1 });
  Pt("barrel", 24.6, 37.9);
  fenceRow(9, 19, 34, 1, [14]);
  fenceCol(19, 35, 37, 1);
  fenceCol(9, 35, 37, 1);
  Pt("haybale", 10.6, 36.4, { v: 1 });
  Pt("haybale", 12, 36.9);
  Pt("trough", 17.2, 35.3);
  Pt("wagon", 15.4, 36.95, { v: 3 });
  D("straw", 13 * TS, 36.2 * TS, 0, 60);
  Pt("hitchpost", 10.6, 45.2);
  Pt("hitchpost", 17.6, 45.2);
  D("straw", 14.5 * TS, 45.6 * TS, 0, 40);
  D("planks", 9 * TS, 46 * TS + 9, 0, 11 * TS, 9);
  fenceRow(9, 20, 48, 1, [13]);
  fenceRow(24, 35, 48, 1, [28]);
  D("plot", 9 * TS + 4, 49 * TS + 4, 0, 60, 34);
  D("plot", 16 * TS, 49 * TS + 8, 2, 52, 30);
  D("plot", 24 * TS + 6, 49 * TS + 4, 1, 64, 34);
  D("plot", 31 * TS, 49 * TS + 6, 0, 56, 30);
  Pt("laundry", 13.6, 50.9);
  Pt("coop", 29.4, 50.9);
  Pt("woodpile", 18.4, 50.9);
  Pt("barrel", 36.6, 57.4);
  Pt("towntree", 36.6, 49.8, { v: 0 });
  Pt("barrel", 36.6, 44.42);
  Pt("barrel", 37.5, 44.44, { v: 1 });
  Pt("bench", 43.4, 44.3);
  Pt("crate", 45.4, 44.5);
  D("shadowband", 58 * TS, 39 * TS, 0, 5 * TS, 22);
  Pt("woodpile", 59.2, 40.4);
  Pt("coalbin", 61.4, 40.3);
  Pt("townanvil", 60, 42.6);
  Pt("quench", 61.6, 43.4);
  Pt("grindstone", 58.6, 43.6);
  Pt("ingots", 58.6, 41.6);
  D("stain", 60 * TS, 41.6 * TS, 0, 56, 40);
  D("scorch", 60 * TS, 42 * TS, 0);
  spot("work.smithyard", "work", 60 * TS + 8, 44.3 * TS, "up");
  Pt("wagon", 75.2, 47.3, { v: 1 });
  Pt("barrel", 78.3, 44.42);
  Pt("barrel", 83.2, 44.44, { v: 1 });
  fenceRow(62, 64, 48, 1);
  fenceRow(70, 83, 48, 1);
  for (const [kind, x, y, v] of [
    ["stonestack", 63.4, 51, 0],
    ["stonestack", 65.8, 51, 1],
    ["stonestack", 63.6, 54, 1],
    ["timberstack", 64, 57],
    ["timberstack", 67, 56],
    ["crane", 68.6, 53],
    ["wagon", 66.6, 50, 2],
    ["golempad", 73.5, 55.2, 0],
    ["golempad", 76.5, 55.2, 1],
    ["golempad", 79.5, 55.2, 2],
    ["yokerack", 82.4, 55.4],
    ["tallyboard", 71.2, 54.6],
    ["crate", 82.6, 57, 1]
  ]) Pt(kind, x, y, { v: v ?? 0 });
  spot("work.hoist", "work", 68.6 * TS + 8, 54.6 * TS, "up");
  for (let i = 0; i < 3; i++) spot(`stand.${i + 1}`, "work", (73.5 + i * 3) * TS + 8, 56.3 * TS, "down");
  Pt("scaffold", 40.5, 57.9);
  Pt("woodpile", 44.6, 56.6);
  Pt("stonestack", 44.7, 53.4, { v: 1 });
  D("straw", 44.5 * TS, 58.6 * TS, 0, 30);
  Pt("crate", 51.2, 57.5);
  Pt("crate", 52.2, 57.5, { v: 1 });
  Pt("barrel", 58.6, 57.44);
  Pt("sack", 57.6, 57.5);
  Pt("wagon", 57, 61.4, { v: 0 });
  D("ruts", 58 * TS, 31 * TS + 8, 0, 36 * TS);
  D("ruts", 85 * TS + 8, 33 * TS, 1, 25 * TS);
  D("ruts", 24 * TS, 59 * TS + 8, 0, 60 * TS);
  D("golemtrack", 86 * TS, 31 * TS + 12, 0, 8 * TS);
  D("golemtrack", 85 * TS + 2, 33 * TS, 1, 25 * TS);
  D("golemtrack", 56 * TS, 59 * TS + 2, 0, 29 * TS);
  D("golemtrack", 67 * TS + 8, 45 * TS, 1, 9 * TS);
  D("golemtrack", 55 * TS, 58 * TS, 1, 20);
  D("golemtrack", 68 * TS, 55 * TS + 6, 0, 12 * TS);
  D("golemtrack", 41 * TS, 59 * TS + 4, 0, 14 * TS);
  for (const [x, y] of [[59, 31], [70, 31], [80, 31], [36, 31], [24, 31], [47, 39], [47, 46]]) D("wear", x * TS + rng() * 16, y * TS + 8, 0, 50 + rng() * 30, 18);
  for (const [x, y] of [[65, 30], [75, 32], [28, 30], [44, 37]]) D("drain", x * TS + 8, y * TS + 8);
  for (const [x, y, w] of [[11, 46, 30], [17, 45, 24], [32, 59, 34], [73, 60, 30], [84, 52, 22], [47, 55, 20], [11, 59, 40]]) D("puddle", x * TS, y * TS + 4, rng() * 2 | 0, w, 8 + rng() * 6);
  spot("watch.n", "idle", 86.5 * TS, 30.5 * TS, "down");
  spot("watch.s", "idle", 86.5 * TS, 32.9 * TS, "up");
  spot("idle.crown", "idle", 47.5 * TS, 45.6 * TS, "up");
  spot("idle.lamp", "idle", 60.8 * TS, 28 * TS, "down");
  spot("idle.lowwest", "idle", 23 * TS, 46.4 * TS, "right");
  for (const [x, y, v] of [[8, 34.4, 0], [7.4, 27.6, 2], [38.6, 7.4, 1], [54.6, 7.6, 0], [63.6, 6.8, 2], [72.6, 6.6, 1], [6.8, 40, 0], [7, 52, 2], [22.6, 62, 1], [61, 62, 0], [86.4, 62, 2], [87, 12, 1], [87.2, 45, 0], [57.6, 18.6, 2]])
    Pt("towntree", x, y, { v });
  for (const p of props) if (p.kind === "towntree") {
    D("shade", p.x + 6, p.y - 12, 0, 48);
    D("roots", p.x - 4, p.y - 4, 0);
  }
  const busy = new Uint8Array(k.n);
  for (const p of props) {
    const b = propDef(p.kind).box ?? [12, 6];
    for (let y = Math.floor((p.y - b[1] - 6) / TS); y <= Math.floor((p.y + 5) / TS); y++) for (let x = Math.floor((p.x - b[0] / 2 - 6) / TS); x <= Math.floor((p.x + b[0] / 2 + 5) / TS); x++) if (k.inb(x, y)) busy[I(x, y)] = 1;
  }
  for (const s of k.spots) busy[I(Math.floor(s.x / TS), Math.floor((s.y - 1) / TS))] = 1;
  const isGround = (s) => s === FS.GRASS || s === FS.MOSS || s === FS.DIRT || s === FS.EARTH || s === FS.MUD;
  for (let y = 0; y < H2; y++) for (let x = 0; x < W; x++) {
    const i = I(x, y);
    if (grid[i] !== T.FLOOR) continue;
    const s = style[i], bx = x * TS, by = y * TS, r = rng();
    if (s === FS.GRASS || s === FS.MOSS) {
      if (r < 0.36) D("tuft", bx + 3 + rng() * 10, by + 6 + rng() * 9);
      else if (r < 0.42) D("flowers", bx + 8, by + 8, rng() * 4 | 0);
      if (keep[i] || busy[i]) continue;
      const q = rng(), free = [1, -1, W, -W].every((d) => grid[i + d] !== T.FLOOR || !keep[i + d] && !busy[i + d]) && grid[i - 1] === T.FLOOR && grid[i + 1] === T.FLOOR;
      const low = y >= 1 && x >= 1 && x <= W - 2, tall = low && y >= 3;
      const fringe = x < 9 || x > 86 || y < 8 || y > 60;
      if (free && (y < Wl.northY0 || y > Wl.southY1)) {
        if (low && q < 0.23) Pt(q < 0.2 ? "tallgrass" : "fern", x + (rng() - 0.5) * 0.5, y - rng() * 0.3, { v: rng() * 3 | 0 });
        continue;
      }
      if (free && tall && q < (fringe ? 0.07 : 0.012)) {
        Pt("towntree", x + (rng() - 0.5) * 0.4, y - rng() * 0.3, { v: rng() * 3 | 0 });
        busy[i] = 1;
      } else if (free && low && q < (fringe ? 0.16 : 0.05)) {
        Pt("bush", x + (rng() - 0.5) * 0.4, y - rng() * 0.3, { v: rng() * 4 | 0 });
        busy[i] = 1;
      } else if (low && q < 0.2) Pt("tallgrass", x + (rng() - 0.5) * 0.5, y - rng() * 0.3, { v: rng() * 3 | 0 });
      else if (low && q < 0.23) Pt("fern", x + (rng() - 0.5) * 0.5, y - rng() * 0.3, { v: rng() * 3 | 0 });
    } else if (isGround(s)) {
      if (r < 0.08) D("pebbles", bx + 8 + (rng() - 0.5) * 6, by + 8 + (rng() - 0.5) * 6);
      else if (r < 0.16 && s !== FS.MUD) D("tuft", bx + 3 + rng() * 10, by + 6 + rng() * 9);
    } else {
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const j = I(x + dx, y + dy);
        if (grid[j] !== T.FLOOR || !isGround(style[j]) || rng() > 0.6) continue;
        const ex = bx + 8 + dx * 7 + (dx ? 0 : (rng() - 0.5) * 12), ey = by + 9 + dy * 7 + (dy ? 0 : (rng() - 0.5) * 10);
        D(rng() < 0.2 ? "weeds" : "tuft", ex, ey);
      }
      if (s === FS.COBBLE && r < 0.05) D("mosspatch", bx + 8, by + 8, 1, 8 + rng() * 8);
    }
  }
  const rooms = [
    { num: 1, name: "EAST GATE", x: 84, y: 29, w: 4, h: 5 },
    { num: 2, name: "MARKET SQUARE", x: sq.x0, y: sq.y0, w: sq.x1 - sq.x0 + 1, h: sq.y1 - sq.y0 + 1 },
    { num: 3, name: "OLD QUARTER", x: 22, y: 9, w: 8, h: 6 },
    { num: 4, name: "HIGH STREET", x: 62, y: 30, w: 20, h: 3 },
    { num: 5, name: "LOW STREET", x: 36, y: 45, w: 24, h: 3 },
    { num: 6, name: "STONE YARD", x: 64, y: 49, w: 18, h: 9 },
    { num: 7, name: "BACK LANE", x: 24, y: 58, w: 30, h: 3 },
    { num: 8, name: "WEST BAR", x: 6, y: 30, w: 4, h: 3 }
  ];
  const decals = [...k.decals.filter((d) => d.kind !== "building"), ...k.decals.filter((d) => d.kind === "building")];
  return {
    id: TOWN_ID,
    w: W,
    h: H2,
    grid,
    plan: grid.slice(),
    style,
    tvar: k.tvar,
    rooms,
    props,
    decals,
    lights: k.lights,
    loose: k.loose,
    start: { x: 85 * TS + 8, y: hs.y0 * TS + 28 },
    exits: [{ x: W - 1, y: hs.y0 + 1, label: "THE OLD ROAD", dir: "e" }],
    drips: [],
    outdoor: true,
    tended: true,
    ambient: TOWN_AMBIENT,
    portals: k.portals,
    spots: [...k.spots, ...TOWN_FOLK_SPOTS]
  };
}

// src/game/townInteriors.ts
var INTERIOR_W = 44;
var INTERIOR_H = 26;
function buildRoom(e, s) {
  const k = areaKit(INTERIOR_W, INTERIOR_H);
  const rx = INTERIOR_W - s.w >> 1, ry = INTERIOR_H - s.h >> 1, b = building(e), rich = HIGH_END[e];
  k.rect(rx, ry, s.w, s.h, T.FLOOR, s.floor);
  k.rect(rx - 1, ry - 1, s.w + 2, 1, T.WALL, s.wall);
  const dx = rx + s.door, dy = ry + s.h, mid = (dx + s.doorW / 2) * TS;
  for (let i = 0; i < s.doorW; i++) k.set(dx + i, dy, T.FLOOR, s.floor);
  k.D("threshold", dx * TS, dy * TS, 0, s.doorW * TS);
  k.portals.push({
    id: "door",
    x: dx * TS + 1,
    y: dy * TS + 6,
    w: s.doorW * TS - 2,
    h: 11,
    dir: "down",
    door: true,
    to: { area: TOWN_ID, portal: `door.${e}` },
    arrive: { x: mid, y: dy * TS - 3 },
    label: b.name
  });
  k.lights.push({ x: mid, y: dy * TS + 10, rad: 44, col: [0.5, 0.6, 0.95], int: 0.3, flick: 0, sky: true });
  const room = {
    w: s.w,
    h: s.h,
    Q: (kind, cx, cy, o = {}) => k.Pt(kind, rx + cx, ry + cy, o),
    D: (kind, cx, cy, v = 0, w, h) => k.D(kind, (rx + cx) * TS, (ry + cy) * TS, v, w, h),
    spot: (id, kind, cx, cy, facing) => k.spot(id, kind, (rx + cx) * TS + 8, (ry + cy) * TS + 12, facing),
    seat: (id, cx, cy) => {
      k.Pt("stool", rx + cx, ry + cy);
      k.spot(`seat.${id}`, "seat", (rx + cx) * TS + 8, (ry + cy) * TS + 24, "up");
    },
    counter: (cx, cy, v) => {
      k.Pt("counter", rx + cx, ry + cy, { v });
      k.spot("keeper", "keeper", (rx + cx) * TS + 8, (ry + cy) * TS, "down");
      k.spot("customer", "customer", (rx + cx) * TS + 8, (ry + cy) * TS + 28, "up");
    }
  };
  room.spot("door", "door", s.door + s.doorW / 2 - 0.5, s.h - 0.9, "up");
  s.dress(room);
  return {
    id: interiorId(e),
    w: INTERIOR_W,
    h: INTERIOR_H,
    grid: k.grid,
    plan: k.grid.slice(),
    style: k.style,
    tvar: k.tvar,
    rooms: [{ num: 1, name: b.name ?? e.toUpperCase(), x: rx, y: ry, w: s.w, h: s.h }],
    props: k.props,
    decals: k.decals,
    lights: k.lights,
    loose: k.loose,
    drips: [],
    exits: [],
    start: { x: mid, y: dy * TS - 3 },
    interior: true,
    ambient: rich ? [0.3, 0.33, 0.4] : [0.3, 0.25, 0.22],
    portals: k.portals,
    spots: k.spots
  };
}
var ROOMS = {
  // The Black Anvil. A working forge with a shop squeezed into its east end: brick, soot, one fire
  // and two torches. The west half is the smith's; the counter keeps customers out of it.
  smithy: {
    w: 15,
    h: 9,
    floor: FS.FLAG,
    wall: WS.BRICK,
    door: 7,
    doorW: 1,
    dress: ({ Q: Q2, D, spot, counter }) => {
      Q2("smithforge", 2.2, 0.9);
      Q2("bellows", 5.4, 1);
      Q2("coalbin", 0.2, 2.5);
      Q2("townanvil", 3, 3.1);
      Q2("quench", 5.2, 3.5);
      Q2("bucket", 1.2, 3.6);
      Q2("torch", 7.2, -1, { lit: true });
      Q2("toolrack", 9.2, -1);
      Q2("goodshelf", 12, -1, { v: 2 });
      Q2("torch", 14.2, -1, { lit: true });
      Q2("shoprack", 11.8, 0.4);
      Q2("barrel", 14.1, 0.7, { v: 1 });
      counter(11.6, 4, 0);
      Q2("ingots", 0.3, 6.4);
      Q2("ingots", 0.5, 7.2);
      Q2("grindstone", 2, 7.8);
      Q2("crate", 13.6, 7.8, { v: 1 });
      Q2("crate", 14, 6.9);
      Q2("sack", 12.4, 7.9);
      Q2("shopstand", 9.4, 7.9, { v: 0 });
      D("scorch", 2, 2.2);
      D("stain", 3, 3.6, 0, 70, 44);
      D("stain", 0.8, 3, 0, 24, 18);
      D("golemtrack", 5, 2.4, 0, 30);
      for (let i = 0; i < 5; i++) D("debris", 1 + i * 0.9, 4.2 + i % 2 * 0.5, i % 4);
      Q2("candlestand", 8.6, 7.8);
      Q2("candlestand", 14.1, 4.4);
      Q2("lantern", 10.6, -1);
      spot("work.anvil", "work", 3, 4, "up");
      spot("work.bellows", "work", 6.3, 2.2, "left");
      spot("idle.browse", "idle", 10, 6.6, "right");
      spot("browse.tools", "browse", 9.2, 0.5, "up");
      spot("browse.stand", "browse", 8.9, 6.9, "down");
      spot("browse.crates", "browse", 12.7, 6.7, "right");
      spot("queue.1", "queue", 11.6, 6, "up");
      spot("queue.2", "queue", 11.4, 7, "up");
      spot("tidy.1", "tidy", 12.9, 3.25, "up");
      spot("tidy.2", "tidy", 11.8, 1.7, "up");
    }
  },
  // The Gilded Buckler. Finished arms for people with coin: dressed stone, a runner to the counter,
  // harness on stands down both walls, everything under clean rune light.
  armory: {
    w: 15,
    h: 9,
    floor: FS.FLAG,
    wall: WS.STONE,
    door: 7,
    doorW: 1,
    dress: ({ Q: Q2, D, spot, counter }) => {
      Q2("rune_sconce", 2.6, -1);
      Q2("shieldwall", 4.6, -1);
      Q2("goodshelf", 7, -1, { v: 3 });
      Q2("shieldwall", 9.4, -1);
      Q2("rune_sconce", 11.4, -1);
      Q2("shoprack", 1, 0.4);
      Q2("shoprack", 13, 0.4);
      counter(7, 2.4, 3);
      for (const [x, y, v] of [[0.3, 3.4, 0], [0.3, 5.2, 1], [0.3, 7, 3], [13.7, 3.4, 2], [13.7, 5.2, 0], [13.7, 7, 1], [4.6, 7.9, 2], [9.4, 7.9, 3]]) Q2("armordisplay", x, y, { v });
      Q2("runestand", 3.4, 4.6);
      Q2("runestand", 10.6, 4.6);
      Q2("dummy", 2.6, 7.6);
      Q2("chest", 11.6, 7.8, { v: 2 });
      Q2("crate", 12.7, 7.9, { v: 1 });
      D("rug", 6.5, 3.6, 0, 32, 84);
      spot("idle.stands.w", "idle", 1.6, 5.6, "left");
      spot("idle.stands.e", "idle", 12.4, 5.6, "right");
      spot("browse.rack.w", "browse", 1.2, 1.5, "up");
      spot("browse.rack.e", "browse", 13, 1.5, "up");
      spot("browse.harness.w", "browse", 4.6, 6.8, "down");
      spot("browse.harness.e", "browse", 9.4, 6.8, "down");
      spot("browse.runes", "browse", 4.5, 4.7, "left");
      spot("queue.1", "queue", 7, 4.5, "up");
      spot("queue.2", "queue", 7, 5.6, "up");
      spot("tidy.1", "tidy", 5.4, 1.6, "up");
      spot("tidy.2", "tidy", 8.6, 1.6, "up");
    }
  },
  // The Bright Facet. The smallest room in town and the most expensive: oak panelling, glazed tile,
  // glass cases, a strongbox behind the counter, and more light runes than it needs.
  jeweler: {
    w: 12,
    h: 8,
    floor: FS.TILE,
    wall: WS.PANEL,
    door: 6,
    doorW: 1,
    dress: ({ Q: Q2, D, spot, counter }) => {
      Q2("rune_sconce", 0.6, -1);
      Q2("goodshelf", 3, -1, { v: 4 });
      Q2("mirror", 5.5, -1);
      Q2("goodshelf", 8, -1, { v: 4 });
      Q2("rune_sconce", 10.4, -1);
      Q2("gembench", 1.4, 0.6);
      Q2("chest", 10.6, 0.5, { v: 1 });
      counter(5.5, 2.4, 1);
      Q2("displaycase", 0.4, 4.4, { v: 0 });
      Q2("displaycase", 0.4, 6.4, { v: 1 });
      Q2("displaycase", 10.6, 4.4, { v: 2 });
      Q2("displaycase", 10.6, 6.4, { v: 0 });
      Q2("displaycase", 2.8, 6.8, { v: 2 });
      Q2("displaycase", 8.2, 6.8, { v: 1 });
      Q2("runestand", 2.2, 3.6);
      Q2("runestand", 8.8, 3.6);
      Q2("pot", 10.8, 2.4, { v: 1 });
      D("rug", 3.5, 3.7, 1, 80, 40);
      spot("work.bench", "work", 1.6, 1.3, "up");
      spot("idle.cases.w", "idle", 1.6, 5.4, "left");
      spot("idle.cases.e", "idle", 9.4, 5.4, "right");
      spot("browse.case.sw", "browse", 2.8, 5.9, "down");
      spot("browse.case.se", "browse", 8.2, 5.9, "down");
      spot("browse.runes", "browse", 3.4, 3.7, "left");
      spot("queue.1", "queue", 5.5, 4.5, "up");
      spot("queue.2", "queue", 5.5, 5.6, "up");
      spot("tidy.1", "tidy", 4, 1.6, "up");
      spot("tidy.2", "tidy", 7.4, 1.6, "up");
    }
  },
  // The Silver Needle. Clothiers: waxed boards, limewash, bolts of cloth to the ceiling, forms
  // dressed in the season's work, a screen and a glass in the fitting corner.
  tailor: {
    w: 13,
    h: 8,
    floor: FS.BOARD,
    wall: WS.PLASTER,
    door: 6,
    doorW: 1,
    dress: ({ Q: Q2, D, spot, counter }) => {
      Q2("rune_sconce", 0.5, -1);
      Q2("goodshelf", 2.5, -1, { v: 1 });
      Q2("goodshelf", 4.8, -1, { v: 1 });
      Q2("rune_sconce", 7, -1);
      Q2("mirror", 9, -1);
      Q2("rune_sconce", 11.5, -1);
      counter(3.4, 2.4, 2);
      Q2("screen", 10.9, 1.5);
      Q2("mannequin", 8.9, 1.2, { v: 3 });
      Q2("mannequin", 6.2, 4.5, { v: 0 });
      Q2("mannequin", 7.8, 4.9, { v: 2 });
      Q2("mannequin", 0.4, 4.4, { v: 1 });
      Q2("table", 3, 5.6, { v: 1 });
      Q2("loom", 11.2, 5.4);
      Q2("clothrack", 0.9, 6.9);
      Q2("clothrack", 11.1, 6.9);
      Q2("runestand", 4.6, 6.9);
      D("rug", 5.1, 3.4, 3, 64, 44);
      D("paper", 2.6, 4.9, 1);
      D("paper", 3.5, 5, 0);
      spot("work.loom", "work", 9.4, 5.6, "right");
      spot("work.fitting", "work", 9.9, 2.6, "up");
      spot("idle.forms", "idle", 7, 6.2, "up");
      spot("browse.rack.w", "browse", 1, 5.9, "down");
      spot("browse.rack.e", "browse", 11, 6.05, "down");
      spot("browse.form", "browse", 1.6, 4.4, "left");
      spot("browse.table", "browse", 5.1, 5.7, "left");
      spot("queue.1", "queue", 3.4, 4.4, "up");
      spot("queue.2", "queue", 4.8, 4.5, "left");
      spot("tidy.1", "tidy", 2.3, 1.2, "up");
      spot("tidy.2", "tidy", 4.8, 1.2, "up");
    }
  },
  // The Sunken Crown. The town's front room: a long bar, a big fire, a tin crown on the wall, too many
  // stools. Firelight and candles; the far tables are half in the dark. Stairs go up to the beds.
  tavern: {
    w: 20,
    h: 11,
    floor: FS.BOARD,
    wall: WS.PLASTER,
    door: 9,
    doorW: 2,
    dress: ({ Q: Q2, D, spot, seat }) => {
      Q2("goodshelf", 2.2, -1, { v: 0 });
      Q2("goodshelf", 4.6, -1, { v: 0 });
      Q2("torch", 7.2, -1, { lit: true });
      Q2("torch", 9.6, -1, { lit: true });
      Q2("crownplaque", 11.3, -1);
      Q2("fireplace", 13.6, 0.55);
      Q2("torch", 16.6, -1, { lit: true });
      Q2("stairs_up", 18.7, 0.75);
      Q2("kegrack", 1.5, 0.7);
      Q2("bar", 3.6, 2.6);
      Q2("barrel", 6.8, 0.7);
      Q2("barrel", 7.6, 0.8, { v: 1 });
      spot("keeper", "keeper", 3.6, 1.7, "down");
      spot("customer", "customer", 6.8, 3.4, "left");
      seat("bar.1", 2, 3.4);
      seat("bar.2", 3.6, 3.4);
      seat("bar.3", 5.2, 3.4);
      Q2("chair", 11.4, 2.5);
      Q2("chair", 15.8, 2.5);
      Q2("bench", 13.6, 3.3);
      D("rug", 11.6, 1.5, 0, 64, 22);
      spot("idle.hearth", "idle", 13.6, 4.2, "up");
      Q2("roundtable_lit", 3, 6.5, { v: 1 });
      seat("t1.w", 1.6, 6.3);
      seat("t1.e", 4.4, 6.3);
      Q2("roundtable", 7.2, 5.4, { v: 0 });
      seat("t2.w", 5.9, 5.2);
      seat("t2.e", 8.5, 5.2);
      Q2("roundtable_lit", 12.6, 6.6, { v: 1 });
      seat("t3.w", 11.2, 6.4);
      seat("t3.e", 14, 6.4);
      Q2("roundtable", 17, 5.6, { v: 2 });
      seat("t4.w", 15.7, 5.4);
      seat("t4.e", 18.3, 5.4);
      Q2("longtable", 4.2, 9.2);
      Q2("bench", 4.2, 8.4);
      Q2("bench", 4.2, 10);
      Q2("cellarhatch", 16.4, 9.7);
      Q2("barrel", 19.1, 9.2);
      Q2("barrel", 18.4, 10);
      Q2("crate", 19, 8.2, { v: 1 });
      D("golemtrack", 14.2, 9.5, 0, 40);
      D("straw", 6, 7.6, 0, 70);
      D("straw", 14, 8, 0, 60);
      D("stain", 8.6, 6.6, 1, 14, 8);
      D("stain", 4.6, 4.3, 1, 12, 6);
      Q2("lantern", 0.5, -1);
      Q2("candlestand", 0.3, 4.8);
      Q2("candlestand", 0.3, 9.9);
      Q2("candlestand", 19.2, 7);
      Q2("candlestand", 10.2, 4.2);
      Q2("candlestand", 12.6, 9.8);
      spot("idle.stairs", "idle", 18.6, 2.4, "up");
      spot("queue.1", "queue", 7.9, 3.6, "left");
      spot("queue.2", "queue", 8.8, 4.2, "left");
      spot("tidy.1", "tidy", 2, 1.7, "up");
      spot("tidy.2", "tidy", 5.4, 1.7, "up");
    }
  },
  // The Adventurers' Guild, Westwake chapter. The Throne's charter made it the grandest room in town:
  // dressed stone, banners, a desk under the records, the contract board, a fire for those between jobs.
  guild: {
    w: 20,
    h: 12,
    floor: FS.FLAG,
    wall: WS.STONE,
    door: 9,
    doorW: 2,
    dress: ({ Q: Q2, D, spot, seat, counter }) => {
      Q2("rune_sconce", 0.5, -1);
      Q2("questboard", 3, -1);
      Q2("rune_sconce", 5.5, -1);
      Q2("banner", 6.9, -1, { v: 0 });
      Q2("bookshelf", 8.5, 0, { v: 0 });
      Q2("bookshelf", 9.5, 0, { v: 2 });
      Q2("bookshelf", 10.5, 0, { v: 1 });
      Q2("banner", 12.1, -1, { v: 2 });
      Q2("trophy", 17.6, -1, { v: 1 });
      Q2("fireplace", 15.7, 0.55);
      Q2("stairs_up", 18.8, 0.75);
      counter(9.5, 2.7, 4);
      D("rug", 9, 4, 0, 32, 122);
      spot("idle.board.1", "idle", 2.2, 1.2, "up");
      spot("idle.board.2", "idle", 3.8, 1.4, "up");
      Q2("maptable", 3, 5.4);
      Q2("chair", 1.4, 5.2);
      Q2("chair", 4.7, 5.2);
      D("paper", 2.2, 5.8, 0);
      D("paper", 4, 6.1, 2);
      Q2("armordisplay", 0.3, 3, { v: 1 });
      Q2("footlocker", 0.3, 8.2);
      Q2("footlocker", 0.3, 9.2);
      Q2("footlocker", 0.3, 10.2);
      Q2("shoprack", 3.4, 10.9);
      Q2("runestand", 6, 8.4);
      Q2("runestand", 13, 8.4);
      Q2("runestand", 8, 10.9);
      Q2("runestand", 11, 10.9);
      Q2("runestand", 1.6, 7.6);
      Q2("rune_sconce", 13.5, -1);
      spot("work.maps", "work", 3, 6.4, "up");
      Q2("bench", 15.7, 3.3);
      D("rug", 13.9, 1.5, 2, 60, 24);
      Q2("roundtable", 14.6, 5.6, { v: 2 });
      seat("t1.w", 13.3, 5.4);
      seat("t1.e", 15.9, 5.4);
      Q2("roundtable_lit", 17.8, 7.4, { v: 1 });
      seat("t2.w", 16.5, 7.2);
      seat("t2.e", 19.1, 7.2);
      Q2("dummy", 18.6, 10.6);
      Q2("dummy", 16.4, 10.8);
      Q2("barrel", 19.1, 9);
      D("straw", 17.5, 10.4, 0, 50);
      spot("idle.fire", "idle", 15.7, 4.2, "up");
      spot("idle.stairs", "idle", 18.7, 2.4, "up");
      spot("idle.board.3", "idle", 3, 2.3, "up");
      spot("browse.trophy", "browse", 17.5, 0.7, "up");
      spot("browse.maps", "browse", 5.7, 5.6, "left");
      spot("browse.rack", "browse", 3.4, 9.8, "down");
      spot("queue.1", "queue", 9.5, 4.8, "up");
      spot("queue.2", "queue", 9.5, 5.9, "up");
      spot("tidy.1", "tidy", 8.3, 1.4, "up");
      spot("tidy.2", "tidy", 10.7, 1.4, "up");
    }
  }
};
var buildInterior = (e) => buildRoom(e, ROOMS[e]);
var INTERIOR_BUILDERS = Object.fromEntries(ESTABLISHMENTS.map((e) => [interiorId(e), () => buildInterior(e)]));

// src/game/world/areas.ts
var AREAS = {
  dungeon: buildDungeon,
  surface: buildSurface,
  // Westwake, the market town west of the surface, and the six rooms behind its shop doors.
  town: buildTown,
  ...INTERIOR_BUILDERS
};

// src/game/world/areaSpec.ts
var coordPortalId = (x, y) => `@${Math.round(x)},${Math.round(y)}`;
function coordPortal(id) {
  const m = /^@(-?\d+),(-?\d+)$/.exec(id);
  if (!m) return void 0;
  const x = +m[1], y = +m[2];
  return { id, x: x - 8, y: y - 8, w: 16, h: 16, dir: "up", to: { area: "", portal: "" }, arrive: { x, y } };
}
var blank = (w, h, fill, style) => ({ w, h, grid: new Uint8Array(w * h).fill(fill), style: new Uint8Array(w * h).fill(style) });
var carve = (g, x0, y0, x1, y1, t = T.FLOOR) => {
  for (let y = Math.max(1, y0); y <= Math.min(g.h - 2, y1); y++) for (let x = Math.max(1, x0); x <= Math.min(g.w - 2, x1); x++) g.grid[y * g.w + x] = t;
};
var ri = (r, a, b) => a + Math.floor(r() * (b - a + 1));
function finish(spec, g, rooms, start, extra, props) {
  const nx = start.tx, ny = Math.max(1, start.ty - 2);
  g.grid[ny * g.w + nx] = T.FLOOR;
  g.grid[(ny + 1) * g.w + nx] = T.FLOOR;
  const entry = spec.entry ?? { x: 0, y: 0 };
  const exit = {
    id: "exit",
    x: nx * TS,
    y: ny * TS,
    w: TS,
    h: TS,
    dir: "up",
    to: { area: spec.parent, portal: coordPortalId(entry.x, entry.y) },
    arrive: { x: nx * TS + 8, y: (ny + 2) * TS + 11 },
    label: spec.label
  };
  return {
    id: spec.id,
    w: g.w,
    h: g.h,
    grid: g.grid,
    plan: g.grid.slice(),
    style: g.style,
    tvar: new Uint8Array(g.w * g.h),
    rooms,
    props,
    decals: [],
    lights: [],
    loose: [],
    drips: [],
    exits: [],
    portals: [exit],
    start: { x: start.tx * TS + 8, y: start.ty * TS + 11 },
    ...extra
  };
}
function buildFloor(spec) {
  const r = mulberry(spec.seed ^ 2654435769), g = blank(spec.w, spec.h, T.WALL, FS.FLAG);
  const rooms = [], props = [];
  const want = Math.max(3, Math.floor(spec.w * spec.h / 140));
  for (let tries = 0; tries < want * 12 && rooms.length < want; tries++) {
    const w = ri(r, 4, 9), h = ri(r, 3, 6), x = ri(r, 2, spec.w - w - 3), y = ri(r, 3, spec.h - h - 2);
    if (rooms.some((o) => x <= o.x + o.w + 1 && x + w + 1 >= o.x && y <= o.y + o.h + 1 && y + h + 1 >= o.y)) continue;
    rooms.push({ num: rooms.length + 1, name: `Room ${rooms.length + 1}`, x, y, w, h });
    carve(g, x, y, x + w - 1, y + h - 1);
  }
  const order = [...rooms].sort((a, b) => a.x - b.x);
  for (let i = 1; i < order.length; i++) {
    const a = order[i - 1], b = order[i];
    const ax = a.x + (a.w >> 1), ay = a.y + (a.h >> 1), bx = b.x + (b.w >> 1), by = b.y + (b.h >> 1);
    if (r() < 0.5) {
      carve(g, Math.min(ax, bx), ay, Math.max(ax, bx), ay);
      carve(g, bx, Math.min(ay, by), bx, Math.max(ay, by));
    } else {
      carve(g, ax, Math.min(ay, by), ax, Math.max(ay, by));
      carve(g, Math.min(ax, bx), by, Math.max(ax, bx), by);
    }
  }
  for (const room of rooms) {
    if (room.w * room.h >= 20) props.push({ id: `candle.${room.num}`, kind: "candlestand", x: (room.x + 1) * TS + 8, y: (room.y + 1) * TS + 12, v: 0 });
    if (r() < 0.6) props.push({ id: `barrel.${room.num}`, kind: r() < 0.5 ? "barrel" : "crate", x: (room.x + room.w - 1) * TS + 8, y: (room.y + room.h - 1) * TS + 12, v: 0 });
  }
  const first = order[0] ?? { x: 2, y: 3, w: 3, h: 3 };
  return finish(spec, g, rooms, { tx: first.x + (first.w >> 1), ty: first.y + 1 }, { ambient: [0.06, 0.055, 0.075] }, props);
}
function buildCave(spec) {
  const r = mulberry(spec.seed ^ 5369127), g = blank(spec.w, spec.h, T.WALL, FS.EARTH);
  let cells = new Uint8Array(spec.w * spec.h).map(() => r() < 0.44 ? 1 : 0);
  for (let pass = 0; pass < 4; pass++) {
    const next = new Uint8Array(cells.length);
    for (let y = 0; y < spec.h; y++) for (let x = 0; x < spec.w; x++) {
      let n = 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        const xx = x + dx, yy = y + dy;
        n += xx < 0 || yy < 0 || xx >= spec.w || yy >= spec.h ? 1 : cells[yy * spec.w + xx];
      }
      next[y * spec.w + x] = n >= 5 ? 1 : 0;
    }
    cells = next;
  }
  const seen2 = new Int32Array(cells.length).fill(-1);
  let best = -1, bestN = 0;
  for (let i = 0; i < cells.length; i++) {
    if (cells[i] || seen2[i] >= 0) continue;
    const stack = [i];
    let n = 0;
    seen2[i] = i;
    while (stack.length) {
      const j = stack.pop();
      n++;
      const x = j % spec.w, y = j / spec.w | 0;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const xx = x + dx, yy = y + dy, k = yy * spec.w + xx;
        if (xx > 0 && yy > 0 && xx < spec.w - 1 && yy < spec.h - 1 && !cells[k] && seen2[k] < 0) {
          seen2[k] = i;
          stack.push(k);
        }
      }
    }
    if (n > bestN) {
      bestN = n;
      best = i;
    }
  }
  let start = { tx: spec.w >> 1, ty: spec.h >> 1 };
  for (let i = 0; i < cells.length; i++) if (best >= 0 && seen2[i] === best) {
    const x = i % spec.w, y = i / spec.w | 0;
    if (x > 0 && y > 2 && x < spec.w - 1 && y < spec.h - 1) {
      g.grid[i] = T.FLOOR;
      g.style[i] = r() < 0.2 ? FS.MOSS : FS.EARTH;
    }
  }
  outer: for (let y = 3; y < spec.h - 2; y++) for (let x = 2; x < spec.w - 2; x++) if (g.grid[y * spec.w + x] === T.FLOOR && g.grid[(y + 1) * spec.w + x] === T.FLOOR) {
    start = { tx: x, ty: y };
    break outer;
  }
  carve(g, start.tx - 1, start.ty, start.tx + 1, start.ty + 1);
  const props = [];
  for (let k = 0; k < 6; k++) {
    const x = ri(r, 2, spec.w - 3), y = ri(r, 3, spec.h - 3);
    if (g.grid[y * spec.w + x] === T.FLOOR && Math.abs(x - start.tx) + Math.abs(y - start.ty) > 4) props.push({ id: `rock.${k}`, kind: "rock", x: x * TS + 8, y: y * TS + 14, v: k % 3 });
  }
  return finish(spec, g, [{ num: 1, name: "Cave", x: 1, y: 1, w: spec.w - 2, h: spec.h - 2 }], start, { ambient: [0.05, 0.05, 0.06] }, props);
}
function buildYard(spec) {
  const g = blank(spec.w, spec.h, T.WALL, FS.DIRT);
  carve(g, 1, 3, spec.w - 2, spec.h - 2);
  return finish(spec, g, [{ num: 1, name: "Yard", x: 1, y: 3, w: spec.w - 2, h: spec.h - 4 }], { tx: spec.w >> 1, ty: 4 }, { outdoor: true, ambient: [0.42, 0.4, 0.46] }, []);
}
var AREA_KINDS = {
  floor: { build: buildFloor, min: [24, 16], max: [160, 120] },
  cave: { build: buildCave, min: [24, 16], max: [160, 120] },
  yard: { build: buildYard, fullGrid: true, min: [12, 10], max: [128, 96] }
};
function builderFor(id, specs) {
  const authored = AREAS[id];
  if (authored) return authored;
  const spec = specs?.[id];
  if (!spec) return void 0;
  const kind = AREA_KINDS[spec.kind];
  return kind ? () => kind.build(spec) : void 0;
}
var isFullGrid = (id, specs) => !AREAS[id] && !!specs?.[id] && !!AREA_KINDS[specs[id].kind]?.fullGrid;

// src/game/content/inventory.ts
var CAPACITY_TIERS = [
  { slots: 8 },
  { requires: { actorFlags: [FLAGS.golemArm] }, slots: 16 },
  { requires: { worn: ["basket"] }, slots: 48 }
];

// src/game/content/actors.ts
var ACTORS = {
  golem: {
    name: "MAINTAINER",
    body: { box: [10, 5], height: 24, reach: 20 },
    art: { key: "golem" },
    speed: 48,
    speedTiers: [{ requires: { actorFlags: ["golem.arm"] }, speed: 60 }],
    harvestPower: 1,
    inventory: { slots: 8, tiers: CAPACITY_TIERS },
    gearSlots: GEAR_SLOTS,
    gearUnlocks: Object.fromEntries(GEAR_SLOT_DEFS.flatMap((d) => d.unlock ? [[d.id, d.unlock]] : [])),
    capabilities: ["move", "harvest", "craft", "build", "travel", "scan", "attack"]
  },
  guardian: {
    name: "TREASURY GUARDIAN",
    body: { box: [24, 10], height: 44, reach: 24 },
    art: { key: "guardian" },
    speed: 0,
    harvestPower: 2,
    inventory: { slots: 0 },
    gearSlots: ["core"],
    power: { family: "golem", tier: 3 },
    capabilities: ["talk"],
    eyeLight: { dx: 0, dy: -24, rad: 46, col: [0.5, 0.85, 1] }
  },
  // The general worker body: simpler and lower in rank than the maintainer, no autonomy, only what it is tasked.
  // One stands dormant in the artificery (map.ts, `npc.worker.artificery`); the ?debug fixture uses it too.
  worker_golem: {
    name: "WORKER GOLEM",
    body: { box: [8, 4], height: 20, reach: 18 },
    art: { key: "worker" },
    speed: 16,
    harvestPower: 0.5,
    inventory: { slots: 8 },
    gearSlots: ["rune0"],
    power: { family: "golem", tier: 1 },
    capabilities: ["move", "harvest", "craft", "travel", "worker", "wield"]
  },
  // Townsfolk (sim/folk.ts): every generic NPC's body. Soft (sim/collision.ts: actorBox gives none), so nobody can
  // be blocked by one; who they are and how they look is the actor's own `person` (folkArt.ts draws it).
  townsfolk: {
    name: "TOWNSFOLK",
    body: { box: [8, 4], height: 22, reach: 18 },
    art: { key: "folk" },
    speed: 18,
    harvestPower: 0.5,
    inventory: { slots: 0 },
    gearSlots: [],
    capabilities: ["move", "talk", "travel"]
  },
  // Shopkeepers (sim/shops.ts): one behind each of Westwake's counters. Soft like townsfolk. A placeholder body: the
  // art key "keeper" draws a plain black box until each keeper is textured (keeperArt.ts: KEEPER_ART).
  shopkeeper: {
    name: "SHOPKEEPER",
    body: { box: [10, 4], height: 22, reach: 18 },
    art: { key: "keeper" },
    speed: 15,
    harvestPower: 0.5,
    inventory: { slots: 0 },
    gearSlots: [],
    capabilities: ["talk"]
  },
  // Fixture-only (tests): no builder, NPCS row or migration produces one, and its "human" art is a stand-in.
  npc_worker: {
    name: "WORKER",
    body: { box: [8, 6], height: 22, reach: 18 },
    art: { key: "human" },
    speed: 20,
    harvestPower: 0.75,
    inventory: { slots: 8 },
    gearSlots: ["head", "back", "armR", "armL"],
    capabilities: ["move", "harvest", "craft", "travel", "worker", "wield"]
  }
};
function actorDef(a) {
  const d = ACTORS[a.definition];
  if (!d) throw new Error(`unknown actor definition "${a.definition}"`);
  return d;
}
var capable = (a, capability) => actorDef(a).capabilities.includes(capability);

// src/game/content/npcs.ts
var NPCS = {
  guardian: {
    name: "TREASURY GUARDIAN",
    type: "special",
    dialogue: "guardian",
    actor: "guardian"
  }
};
var npcDef = (id) => id ? NPCS[id] : void 0;

// src/game/content/harvest.ts
var HARVEST = {
  tree: { hp: 4, perHit: { item: "wood", n: 1 }, final: { item: "wood", n: 2 }, tool: "axe" },
  /** A fallen, rotting trunk: quick wood, and the way opens once it's broken up. */
  log: { hp: 3, perHit: { item: "wood", n: 1 }, final: { item: "wood", n: 1 }, clearBox: true, tool: "axe" },
  rock: { hp: 3, perHit: { item: "stone", n: 1 }, final: { item: "stone", n: 2 }, clearBox: true, tool: "pickaxe" },
  /**
   * An outcrop veined with iron: half a piece per unit of work, so two bare-fisted
   * blows for each piece of ore, three pieces in all. A pickaxe head gets one a blow.
   */
  ironore: { hp: 6, perHit: { item: "iron_ore", n: 0.5 }, clearBox: true, tool: "pickaxe" }
};

// src/game/sim/collision.ts
function actorBox(a) {
  if (a.kind === "folk" || a.kind === "keeper") return null;
  const [w, h] = actorDef(a).body.box;
  return [a.x - w / 2, a.y - h, a.x + w / 2, a.y];
}
function actorBoxes(w, areaId, except) {
  const out = [];
  for (const a of w.actors) {
    if (a.area !== areaId || a.id === except) continue;
    const b = actorBox(a);
    if (b) out.push(b);
  }
  return out;
}
var propBlocks = (p) => !!p.box && !(p.taken && HARVEST[p.kind]?.clearBox) && !(propDef(p.kind).openBox && !p.open);
function boxFree(area, x, y, bodies = [], size = [10, 5]) {
  const x0 = x - size[0] / 2, x1 = x + size[0] / 2, y0 = y - size[1], y1 = y;
  for (let ty = Math.floor(y0 / TS); ty <= Math.floor((y1 - 0.01) / TS); ty++)
    for (let tx = Math.floor(x0 / TS); tx <= Math.floor((x1 - 0.01) / TS); tx++) {
      if (tx < 0 || ty < 0 || tx >= area.w || ty >= area.h) return false;
      if (isSolidT(area.grid[ty * area.w + tx])) return false;
    }
  for (const p of area.props) {
    if (!propBlocks(p)) continue;
    const b = p.box;
    if (x1 > b[0] && x0 < b[2] && y1 > b[1] && y0 < b[3]) return false;
  }
  for (const b of bodies) if (x1 > b[0] && x0 < b[2] && y1 > b[1] && y0 < b[3]) return false;
  return true;
}
function nearestFree(area, x, y, bodies = [], size = [10, 5]) {
  if (boxFree(area, x, y, bodies, size)) return { x, y };
  for (let r = 1; r <= 12; r++) {
    for (let i = -r; i <= r; i++)
      for (const [dx, dy] of [[i, r], [i, -r], [r, i], [-r, i]]) {
        const px = x + dx * 8, py = y + dy * 8;
        if (boxFree(area, px, py, bodies, size)) return { x: px, y: py };
      }
  }
  return null;
}

// src/game/content/power.ts
var POWER_CORES = {
  ruby_core: { family: "golem", tier: 1 }
};

// src/game/sim/tools.ts
function activeTools(a) {
  const out = [];
  for (const id of Object.values(a.gear ?? {})) if (id && ITEMS[id]?.tool?.form === "head") out.push(id);
  if (capable(a, "wield")) {
    for (const s of a.inventory) if (s && ITEMS[s.item]?.tool?.form === "full") out.push(s.item);
  }
  return out;
}
function toolBonus(a, type) {
  if (!type) return 0;
  let best = 0;
  for (const id of activeTools(a)) {
    const t = ITEMS[id].tool;
    if (t.type === type && t.bonus > best) best = t.bonus;
  }
  return best;
}

// src/game/sim/requirements.ts
function meets(w, a, req) {
  if (!req) return true;
  if (req.items && !req.items.every((i) => a.inventory.some((s) => s?.item === i))) return false;
  if (req.flags && !req.flags.every((f) => isBodyFlag(f) ? actorHasFlag(a, f) : hasFlag(w, f))) return false;
  if (req.actorFlags && !req.actorFlags.every((f) => a.upgrades.includes(f))) return false;
  if (req.worn && !req.worn.every((i) => Object.values(a.gear ?? {}).includes(i))) return false;
  if (req.tools && !req.tools.every((t) => toolBonus(a, t) > 0)) return false;
  if (req.any && !req.any.some((r) => meets(w, a, r))) return false;
  return true;
}

// src/game/sim/inventoryOps.ts
var copySlots = (slots) => slots.map((s) => s ? { ...s } : null);
var countItem = (a, id) => a.inventory.reduce((n, s) => n + (s?.item === id ? s.n : 0), 0);
var hasItem = (a, id) => countItem(a, id) > 0;
function roomIn(slots, cap, item) {
  let room = 0;
  for (let i = 0; i < cap; i++) {
    const s = slots[i];
    if (!s) room += maxStack(item);
    else if (s.item === item) room += Math.max(0, maxStack(item) - s.n);
  }
  return room;
}
function insertItems(slots, cap, item, n) {
  if (!Number.isSafeInteger(n) || n < 0) throw new Error("invalid item count");
  while (slots.length < cap) slots.push(null);
  for (let i = 0; i < cap && n > 0; i++) {
    const s = slots[i];
    if (!s || s.item !== item) continue;
    const k = Math.min(n, Math.max(0, maxStack(item) - s.n));
    s.n += k;
    n -= k;
  }
  for (let i = 0; i < cap && n > 0; i++) {
    if (slots[i]) continue;
    const k = Math.min(n, maxStack(item));
    slots[i] = { item, n: k };
    n -= k;
  }
  return n;
}
function removeItems(a, item, n = 1) {
  if (!Number.isSafeInteger(n) || n < 0 || countItem(a, item) < n) return false;
  for (let i = a.inventory.length - 1; i >= 0 && n > 0; i--) {
    const s = a.inventory[i];
    if (!s || s.item !== item) continue;
    const k = Math.min(n, s.n);
    s.n -= k;
    n -= k;
    if (!s.n) a.inventory[i] = null;
  }
  return true;
}

// src/game/sim/discovery.ts
var relicFlag = (item) => `relic.found.${item}`;
function rememberItem(w, a, item) {
  if (a.id === w.playerId && ITEMS[item].tags.includes("relic")) w.flags.add(relicFlag(item));
}

// src/game/sim/inventory.ts
function capacity(w, a) {
  const def = actorDef(a).inventory;
  let n = def.slots;
  for (const t of def.tiers ?? []) if (t.slots > n && meets(w, a, t.requires)) n = t.slots;
  return n;
}
function slotsNeeded(stacks) {
  const units = /* @__PURE__ */ new Map();
  for (const s of stacks) units.set(s.item, (units.get(s.item) ?? 0) + s.n);
  let k = 0;
  for (const [id, n] of units) k += Math.ceil(n / maxStack(id));
  return k;
}
function pour(slots, stacks) {
  for (const st of stacks) {
    const max = maxStack(st.item);
    let n = st.n;
    for (let i = 0; i < slots.length && n > 0; i++) {
      const s = slots[i];
      if (s && s.item === st.item && s.n < max) {
        const k = Math.min(n, max - s.n);
        s.n += k;
        n -= k;
      }
    }
    for (let i = 0; i < slots.length && n > 0; i++) {
      if (slots[i]) continue;
      const k = Math.min(n, max);
      slots[i] = { item: st.item, n: k };
      n -= k;
    }
    if (n > 0) return false;
  }
  return true;
}
function repackInto(a, cap, extra = []) {
  const inv = a.inventory;
  const held = inv.flatMap((s) => s ? [{ item: s.item, n: s.n }] : []);
  if (slotsNeeded([...held, ...extra]) > cap) return false;
  let next = Array.from({ length: cap }, (_, i) => inv[i] ? { ...inv[i] } : null);
  const beyond = inv.slice(cap).flatMap((s) => s ? [{ item: s.item, n: s.n }] : []);
  if (!pour(next, [...beyond, ...extra])) {
    next = Array.from({ length: cap }, () => null);
    pour(next, [...held, ...extra]);
  }
  inv.length = 0;
  inv.push(...next);
  return true;
}
function reconcileCapacity(w, a) {
  const cap = capacity(w, a);
  const inv = a.inventory;
  while (inv.length < cap) inv.push(null);
  if (inv.length === cap) return;
  const extra = inv.splice(cap);
  for (const s of extra) {
    if (!s) continue;
    const left = addItems(w, a, s.item, s.n);
    if (left > 0) {
      const area = areaOf(w, a);
      const spot = dropSpot(area, a, actorBoxes(w, area.id, a.id));
      const x = spot ? spot.x : a.x, y = spot ? spot.y : a.y;
      spawnLoose(area, s.item, left, x, y);
      emit(w, { t: "itemDropped", actor: a.id, item: s.item, n: left, x, y, reason: "overflow" });
    }
  }
}
function addItems(w, a, id, n) {
  const left = insertItems(a.inventory, capacity(w, a), id, n);
  if (left < n) rememberItem(w, a, id);
  return left;
}
function roomFor(w, a, id) {
  return roomIn(a.inventory, capacity(w, a), id);
}
function giveItem(w, a, id, n = 1) {
  rememberItem(w, a, id);
  const left = addItems(w, a, id, n);
  if (left < n) emit(w, { t: "itemGained", actor: a.id, item: id, stored: true, n: n - left });
  if (left > 0) {
    const area = areaOf(w, a);
    const spot = dropSpot(area, a, actorBoxes(w, area.id, a.id));
    const x = spot ? spot.x : a.x, y = spot ? spot.y : a.y;
    spawnLoose(area, id, left, x, y);
    emit(w, { t: "packFull", actor: a.id, item: id });
    emit(w, { t: "itemDropped", actor: a.id, item: id, n: left, x, y, reason: "full" });
  }
}
var DROP_ORDER = [
  [1, 0],
  [0, 0],
  [1, -1],
  [1, 1],
  [0, -1],
  [0, 1],
  [-1, 0],
  [-1, -1],
  [-1, 1],
  [2, 0],
  [2, -1],
  [2, 1],
  [0, -2],
  [0, 2],
  [-2, 0],
  [2, -2],
  [2, 2],
  [-2, -1],
  [-2, 1]
];
function tileFree(area, tx, ty, bodies) {
  if (tx < 0 || ty < 0 || tx >= area.w || ty >= area.h) return false;
  if (isSolidT(area.grid[ty * area.w + tx])) return false;
  const cx = tx * TS + 8, cy = ty * TS + 11;
  for (const p of area.props) {
    const b = p.box;
    if (b && !p.taken && !(propDef(p.kind).openBox && !p.open) && cx > b[0] - 3 && cx < b[2] + 3 && cy > b[1] - 3 && cy < b[3] + 3) return false;
  }
  for (const b of bodies) if (cx > b[0] - 3 && cx < b[2] + 3 && cy > b[1] - 3 && cy < b[3] + 3) return false;
  return true;
}
function dropSpot(area, a, bodies = []) {
  const fx = a.facing === "left" ? -1 : a.facing === "right" ? 1 : 0;
  const fy = a.facing === "up" ? -1 : a.facing === "down" ? 1 : 0;
  const gx = Math.floor(a.x / TS), gy = Math.floor((a.y - 3) / TS);
  for (const [f, s] of DROP_ORDER) {
    const tx = gx + f * fx - s * fy, ty = gy + f * fy + s * fx;
    if (tileFree(area, tx, ty, bodies)) return { x: tx * TS + 8, y: ty * TS + 11, tx, ty };
  }
  return null;
}
function spawnLoose(area, item, n, x, y) {
  const max = maxStack(item);
  for (const l of area.loose) {
    if (n <= 0) break;
    if (l.taken || l.item !== item || l.x !== x || l.y !== y) continue;
    const k = Math.min(n, max - (l.n ?? 1));
    if (k > 0) {
      area.setLooseCount(l.id, (l.n ?? 1) + k);
      n -= k;
    }
  }
  while (n > 0) {
    const k = Math.min(n, max);
    area.addLoose(item, k, x, y);
    n -= k;
  }
}

// src/game/sim/gear.ts
var slotUsable = (w, a, slot) => actorDef(a).gearSlots.includes(slot) && meets(w, a, actorDef(a).gearUnlocks?.[slot]);
function slotsFor(w, a, item) {
  const g = ITEMS[item].wear;
  if (!g) return [];
  return slotsOfKind(g.kind).filter((s) => (!g.slot || g.slot === s) && slotUsable(w, a, s));
}
function targetSlot(w, a, item) {
  const c = slotsFor(w, a, item);
  return c.find((s) => !a.gear[s]) ?? c[0];
}
function reconcileGear(w, a) {
  for (const d of GEAR_SLOT_DEFS) {
    const item = a.gear[d.id];
    if (!item || slotUsable(w, a, d.id)) continue;
    delete a.gear[d.id];
    reconcileCapacity(w, a);
    giveItem(w, a, item, 1);
    emit(w, { t: "gearOff", actor: a.id, item, slot: d.id });
  }
}
function activeGear(w, a) {
  return GEAR_SLOT_DEFS.flatMap((d) => a.gear[d.id] && slotUsable(w, a, d.id) ? [a.gear[d.id]] : []);
}
function speedMultiplier(w, a) {
  return 1 + activeGear(w, a).reduce((s, id) => s + (ITEMS[id].worn?.speed ?? 0), 0);
}
function capacityWith(w, a, gear) {
  return capacity(w, { ...a, gear });
}
function packStacks(a, minus = -1) {
  return a.inventory.flatMap((s, i) => {
    if (!s) return [];
    const n = i === minus ? s.n - 1 : s.n;
    return n > 0 ? [{ item: s.item, n }] : [];
  });
}
function wearCheck(w, a, slot, into) {
  const s = a.inventory[slot];
  if (!s) return { ok: false, reason: "empty" };
  if (!ITEMS[s.item].wear) return { ok: false, reason: "notWearable", item: s.item };
  const cands = slotsFor(w, a, s.item);
  const target = into ? cands.find((c) => c === into) : targetSlot(w, a, s.item);
  if (!target) return { ok: false, reason: "noSlot", item: s.item };
  const prev = a.gear[target];
  if (prev) {
    const need = slotsNeeded([...packStacks(a, slot), { item: prev, n: 1 }]);
    const cap = capacityWith(w, a, { ...a.gear, [target]: s.item });
    if (need > cap) return { ok: false, reason: "noRoom", item: prev, over: need - cap, shrinks: cap < capacity(w, a) };
  }
  return { ok: true, item: s.item, slot: target };
}
function takeOffCheck(w, a, slot) {
  const item = a.gear[slot];
  if (!item) return { ok: false, reason: "empty" };
  const after = { ...a.gear };
  delete after[slot];
  const need = slotsNeeded([...packStacks(a), { item, n: 1 }]);
  const cap = capacityWith(w, a, after);
  if (need > cap) return { ok: false, reason: "noRoom", item, over: need - cap, shrinks: cap < capacity(w, a) };
  return { ok: true, item, slot };
}
function applyWear(w, a, slot, into) {
  const chk = wearCheck(w, a, slot, into);
  if (!chk.ok) return chk;
  const s = a.inventory[slot];
  s.n -= 1;
  if (s.n === 0) a.inventory[slot] = null;
  const prev = a.gear[chk.slot];
  a.gear[chk.slot] = chk.item;
  const extra = [];
  if (prev) {
    if (!a.inventory[slot]) a.inventory[slot] = { item: prev, n: 1 };
    else extra.push({ item: prev, n: 1 });
  }
  if (!repackInto(a, capacity(w, a), extra)) {
    reconcileCapacity(w, a);
    for (const x of extra) giveItem(w, a, x.item, x.n);
  }
  if (prev) emit(w, { t: "gearOff", actor: a.id, item: prev, slot: chk.slot });
  emit(w, { t: "gearOn", actor: a.id, item: chk.item, slot: chk.slot });
  return chk;
}
function applyTakeOff(w, a, slot) {
  const chk = takeOffCheck(w, a, slot);
  if (!chk.ok) return chk;
  delete a.gear[slot];
  if (!repackInto(a, capacity(w, a), [{ item: chk.item, n: 1 }])) {
    a.gear[slot] = chk.item;
    return { ok: false, reason: "noRoom", item: chk.item, over: 1 };
  }
  emit(w, { t: "gearOff", actor: a.id, item: chk.item, slot });
  return chk;
}
function gearRefusal(chk) {
  if (chk.ok) return "";
  if (chk.reason === "notWearable") return "THAT CAN'T BE WORN";
  if (chk.reason === "empty") return "NOTHING TO TAKE OFF";
  if (chk.reason === "noSlot") return "NO FREE SLOT FOR THAT YET";
  const k = chk.over ?? 1;
  if (chk.shrinks) return `TOO MUCH TO CARRY WITHOUT THE ${ITEM_NAMES[chk.item]} - FREE ${k} SLOT${k === 1 ? "" : "S"}`;
  return `NO ROOM IN THE PACK FOR THE ${ITEM_NAMES[chk.item]} - FREE ${k} SLOT${k === 1 ? "" : "S"}`;
}

// src/game/sim/actorStats.ts
function powered(a) {
  const req = actorDef(a).power;
  if (!req) return true;
  const core = a.powerCore && POWER_CORES[a.powerCore];
  return !!core && core.family === req.family && core.tier >= req.tier;
}
function powerEffects(a) {
  return powered(a) && a.powerCore ? POWER_CORES[a.powerCore]?.effects : void 0;
}
function actorSpeed(w, a) {
  const d = actorDef(a);
  let speed = d.speed;
  for (const t of d.speedTiers ?? []) if (meets(w, a, t.requires)) speed = Math.max(speed, t.speed);
  return powered(a) ? speed * speedMultiplier(w, a) * Math.max(0, 1 + (powerEffects(a)?.speed ?? 0)) : 0;
}
var harvestPower = (a) => powered(a) ? Math.max(0, actorDef(a).harvestPower * (1 + (powerEffects(a)?.harvest ?? 0))) : 0;

// src/game/sim/navigation.ts
var DIRS = [[1, 0], [0, 1], [-1, 0], [0, -1]];
var cache = /* @__PURE__ */ new WeakMap();
var keyAt = (area, p) => Math.floor((p.y - 3) / TS) * area.w + Math.floor(p.x / TS);
var feet = (area, k) => cellFeet(k % area.w, Math.floor(k / area.w));
function sweptFree(from, to, free) {
  const steps = Math.max(1, Math.ceil(Math.hypot(to.x - from.x, to.y - from.y) / 2));
  for (let i = 0; i <= steps; i++) if (!free(from.x + (to.x - from.x) * i / steps, from.y + (to.y - from.y) * i / steps)) return false;
  return true;
}
function navGrid(area, a) {
  const size = actorDef(a).body.box, key = size.join(",");
  let grids = cache.get(area);
  if (!grids) cache.set(area, grids = /* @__PURE__ */ new Map());
  const old = grids.get(key);
  if (old?.revision === area.layoutRevision) return old;
  const buckets = /* @__PURE__ */ new Map();
  for (const p of area.props) if (propBlocks(p)) {
    const b = p.box;
    for (let y = Math.floor((b[1] - size[1]) / TS) - 1; y <= Math.floor((b[3] + size[1]) / TS) + 1; y++)
      for (let x = Math.floor((b[0] - size[0]) / TS) - 1; x <= Math.floor((b[2] + size[0]) / TS) + 1; x++) {
        if (x < 0 || y < 0 || x >= area.w || y >= area.h) continue;
        const k = y * area.w + x;
        const list = buckets.get(k) ?? [];
        list.push(b);
        buckets.set(k, list);
      }
  }
  const free = (x, y) => freeAt(area, buckets.get(Math.floor(y / TS) * area.w + Math.floor(x / TS)) ?? [], x, y, size);
  const cells = new Int8Array(area.w * area.h).fill(-1), links = new Int8Array(cells.length).fill(-1);
  const stand = (k) => {
    if (k < 0 || k >= cells.length) return false;
    if (cells[k] < 0) {
      const p = feet(area, k);
      cells[k] = Number(free(p.x, p.y));
    }
    return cells[k] === 1;
  };
  const edges = (k) => {
    if (links[k] >= 0) return links[k];
    const x = k % area.w, y = Math.floor(k / area.w), p = feet(area, k);
    let mask = 0;
    if (stand(k)) DIRS.forEach(([dx, dy], i) => {
      const nx = x + dx, ny = y + dy, nk = ny * area.w + nx;
      if (nx >= 0 && ny >= 0 && nx < area.w && ny < area.h && stand(nk) && sweptFree(p, feet(area, nk), free)) mask |= 1 << i;
    });
    links[k] = mask;
    return mask;
  };
  const grid = { revision: area.layoutRevision, size, free, stand, edges };
  grids.set(key, grid);
  return grid;
}
var lineOfSight = (area, from, to) => sweptFree(from, to, (x, y) => !isSolidT(area.tileAtPx(x, y)));
var atDestination = (area, a, goal) => Math.hypot(a.x - goal.x, a.y - goal.y) <= goal.range + 0.01 && lineOfSight(area, a, goal);
function findPath(w, a, goal, avoidActors = true) {
  const area = areaOf(w, a), grid = navGrid(area, a), bodies = avoidActors ? actorBoxes(w, area.id, a.id) : [];
  const free = (x, y) => grid.free(x, y) && freeAt(area, bodies, x, y, grid.size);
  const sx = Math.floor(a.x / TS), sy = Math.floor((a.y - 3) / TS);
  const starts = [];
  for (let y = sy - 2; y <= sy + 2; y++) for (let x = sx - 2; x <= sx + 2; x++) {
    if (x < 0 || y < 0 || x >= area.w || y >= area.h) continue;
    const k = y * area.w + x;
    if (grid.stand(k) && sweptFree(a, feet(area, k), free)) starts.push(k);
  }
  starts.sort((i, j) => {
    const p = feet(area, i), q = feet(area, j);
    return Math.hypot(p.x - a.x, p.y - a.y) - Math.hypot(q.x - a.x, q.y - a.y) || i - j;
  });
  if (!starts.length) return null;
  const start = starts[0], queue = [start], prev = new Int32Array(area.w * area.h).fill(-2);
  prev[start] = -1;
  for (let head = 0; head < queue.length; head++) {
    const k = queue[head], p = feet(area, k);
    const exact = goal.range < 4 && Math.hypot(p.x - goal.x, p.y - goal.y) <= TS && sweptFree(p, goal, free);
    if (atDestination(area, p, goal) || exact) {
      const path = [];
      for (let n = k; n >= 0; n = prev[n]) path.push(feet(area, n));
      path.reverse();
      if (exact && !atDestination(area, p, goal)) path.push({ x: goal.x, y: goal.y });
      return path;
    }
    const mask = grid.edges(k);
    DIRS.forEach(([dx, dy], i) => {
      if (!(mask & 1 << i)) return;
      const n = k + dy * area.w + dx;
      if (prev[n] !== -2 || !sweptFree(p, feet(area, n), free)) return;
      prev[n] = k;
      queue.push(n);
    });
  }
  return null;
}
function yieldPath(w, a) {
  const area = areaOf(w, a), grid = navGrid(area, a);
  const peers = w.actors.filter((b) => b.id < a.id && b.area === a.area && b.job?.status === "running" && Math.hypot(b.x - a.x, b.y - a.y) < TS * 3).sort((a2, b) => a2.id < b.id ? -1 : 1);
  const peer = peers[0];
  if (!peer) return null;
  const route = [peer, ...peer.job?.nav?.path ?? []];
  const cells = [], k0 = keyAt(area, a), sx = k0 % area.w, sy = Math.floor(k0 / area.w);
  for (let y = sy - 5; y <= sy + 5; y++) for (let x = sx - 5; x <= sx + 5; x++) {
    if (x < 0 || y < 0 || x >= area.w || y >= area.h) continue;
    const k = y * area.w + x, p = feet(area, k);
    if (k !== k0 && grid.stand(k) && route.every((q) => Math.hypot(q.x - p.x, q.y - p.y) >= TS - 1)) cells.push(k);
  }
  cells.sort((i, j) => {
    const p = feet(area, i), q = feet(area, j);
    return Math.hypot(p.x - a.x, p.y - a.y) - Math.hypot(q.x - a.x, q.y - a.y) || i - j;
  });
  for (const k of cells) {
    const path = findPath(w, a, { ...feet(area, k), range: 1 });
    if (path) return path;
  }
  return null;
}
function walkTo(w, a, goal, dt) {
  const job = a.job, area = areaOf(w, a);
  if (!job || goal.area !== area.id) return "stuck";
  const key = `${goal.area}:${goal.x},${goal.y}:${goal.range}`;
  if (job.nav?.goal !== key) job.nav = { goal: key, path: [], blockedFor: 0, recoveries: 0, yielding: false, replanIn: 0 };
  const nav = job.nav;
  a.moving = false;
  a.vx = 0;
  a.vy = 0;
  if (!nav.yielding && atDestination(area, a, goal)) {
    job.nav = null;
    return "arrived";
  }
  nav.replanIn = Math.max(0, nav.replanIn - dt);
  if (!nav.path.length && nav.replanIn > 0) return "moving";
  if (!nav.path.length) nav.path = findPath(w, a, goal) ?? findPath(w, a, goal, false) ?? [];
  const start = { x: a.x, y: a.y }, grid = navGrid(area, a), bodies = actorBoxes(w, a.area, a.id);
  const free = (x, y) => grid.free(x, y) && freeAt(area, bodies, x, y, grid.size);
  let budget = actorSpeed(w, a) * dt;
  while (nav.path.length && budget > 0) {
    const p = nav.path[0], dx = p.x - a.x, dy = p.y - a.y, dist = Math.hypot(dx, dy);
    if (dist < 0.01) {
      nav.path.shift();
      continue;
    }
    const step = Math.min(dist, budget, 2), next = { x: a.x + dx / dist * step, y: a.y + dy / dist * step };
    if (!sweptFree(a, next, free)) break;
    a.x = next.x;
    a.y = next.y;
    budget -= step;
    a.facing = Math.abs(dx) > Math.abs(dy) ? dx > 0 ? "right" : "left" : dy > 0 ? "down" : "up";
    if (step >= dist - 0.01) nav.path.shift();
  }
  const moved = Math.hypot(a.x - start.x, a.y - start.y);
  if (moved > 1e-3) {
    a.moving = true;
    a.vx = (a.x - start.x) / Math.max(dt, 1e-6);
    a.vy = (a.y - start.y) / Math.max(dt, 1e-6);
    a.phase += moved * 0.2;
    nav.blockedFor = 0;
  } else nav.blockedFor += dt;
  if (nav.yielding && !nav.path.length) {
    nav.yielding = false;
    nav.replanIn = 0.8;
    nav.blockedFor = 0;
  }
  if (nav.blockedFor >= 0.65) {
    nav.blockedFor = 0;
    nav.recoveries++;
    if (nav.recoveries >= 6) return "stuck";
    const yielding = yieldPath(w, a);
    nav.yielding = !!yielding;
    nav.path = yielding ?? findPath(w, a, goal) ?? [];
    nav.replanIn = nav.path.length ? 0 : 0.2;
  }
  return "moving";
}

// src/game/sim/portals.ts
var PUSH = { up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0] };
var AWAY = { up: "down", down: "up", left: "right", right: "left" };
var portalsOf = (area) => area.base.portals ?? [];
var portalById = (area, id) => portalsOf(area).find((p) => p.id === id);
var portalOpen = (w, p) => !p.flag || hasFlag(w, p.flag);
var inPortal = (p, x, y) => x >= p.x && x <= p.x + p.w && y >= p.y && y <= p.y + p.h;
function portalAt(area, x, y, ix, iy, open = () => true) {
  const mag = Math.hypot(ix, iy);
  if (!mag) return null;
  for (const p of portalsOf(area)) {
    if (!open(p)) continue;
    const [dx, dy] = PUSH[p.dir];
    if ((ix * dx + iy * dy) / mag < 0.7) continue;
    if (inPortal(p, x, y)) return p;
  }
  return null;
}
var STAND = [[0, 0], [-0.5, 0], [0.5, 0], [0, 0.5], [0, -0.5], [-0.5, 0.5], [0.5, 0.5], [-0.5, -0.5], [0.5, -0.5]];
function portalStand(p, free) {
  const cx = p.x + p.w / 2, cy = p.y + p.h / 2;
  for (const [fx, fy] of STAND) {
    const x = cx + fx * Math.max(0, p.w / 2 - 2), y = cy + fy * Math.max(0, p.h / 2 - 2);
    if (free(x, y)) return { x, y };
  }
  return null;
}
function portalArrival(p) {
  const at = p.arrive ?? { x: p.x + p.w / 2, y: p.y + p.h / 2 };
  return { x: at.x, y: at.y, facing: AWAY[p.dir] };
}
function walkThrough(w, a, area, p) {
  if (a.area !== area.id || !capable(a, "move") || !portalOpen(w, p)) return false;
  const dest = getArea(w, p.to.area), out = portalById(dest, p.to.portal) ?? coordPortal(p.to.portal);
  if (!out) return false;
  const at = portalArrival(out);
  const spot = nearestFree(dest, at.x, at.y, actorBoxes(w, dest.id, a.id), actorDef(a).body.box);
  if (!spot) return false;
  enterArea(w, a, dest.id, spot.x, spot.y);
  a.facing = at.facing;
  emit(w, { t: "portal", actor: a.id, fromArea: area.id, from: p.id, toArea: dest.id, to: out.id });
  return true;
}

// src/game/content/shops.ts
var SHOPS = {
  smithy: {
    id: "smithy",
    hours: { open: 7, close: 18, lunch: [12, 13] },
    wares: "hammer",
    keeper: {
      title: "SMITH",
      greet: ["THE BLACK ANVIL. NAILS TO PLOUGHSHARES. I DON'T MEND GOLEMS. YET.", "YOU'RE GOOD IRON UNDER THAT STONE. I CAN TELL.", "STAND CLEAR OF THE FORGE. YOU'D CRACK."],
      welcome: ["MIND THE SPARKS.", "DUCK. LOW BEAM."],
      hello: ["WHAT'LL IT BE?", "MIND THE SPARKS.", "BE WITH YOU."],
      closing: ["FIRE'S BANKED. OUT YOU GO."]
    },
    visits: { browse: 3, buy: 3, window: 2, fetch: 6, rounds: 2 },
    traits: { brisk: 1.4 },
    closedNote: "THE BLACK ANVIL IS SHUT. THE FORGE IS BANKED."
  },
  armory: {
    id: "armory",
    hours: { open: 9, close: 18, lunch: [12.5, 13.5] },
    wares: "sword",
    keeper: {
      title: "ARMOURER",
      greet: ["THE GILDED BUCKLER. FINISHED ARMS FOR THOSE WITH COIN. HAVE YOU COIN?", "NOTHING HERE IN YOUR SIZE, I FEAR.", "PLEASE DON'T LEAN ON THE STANDS."],
      welcome: ["LOOK WITH YOUR EYES.", "WELCOME. MIND THE STANDS."],
      hello: ["SOMETHING WITH AN EDGE?", "WELCOME BACK.", "LOOK WITH YOUR EYES."],
      closing: ["WE CLOSE AT SIX. IT IS SIX."]
    },
    visits: { browse: 4, buy: 2, window: 3, rounds: 2 },
    wellOff: 1.5,
    traits: { restless: 1.5 },
    closedNote: "THE GILDED BUCKLER IS SHUT. THE STANDS ARE COVERED."
  },
  jeweler: {
    id: "jeweler",
    hours: { open: 10, close: 17, lunch: [13, 14] },
    wares: "coin",
    keeper: {
      title: "JEWELLER",
      greet: ["THE BRIGHT FACET. STONES SET, STONES SOLD. IS THAT A RUBY IN YOUR CHEST?", "I WOULD PAY WELL FOR ONE OF YOUR EYES. NO? PITY.", "TOUCH NOTHING, PLEASE."],
      welcome: ["OH. OH MY.", "MIND THE GLASS. PLEASE."],
      hello: ["DO COME IN.", "SOMETHING THAT SPARKLES?", "MIND THE GLASS."],
      closing: ["THE CASES ARE LOCKED. GOOD EVENING."]
    },
    visits: { browse: 3, buy: 1.5, window: 4 },
    wellOff: 8,
    traits: { curious: 1.5, homebody: 0.6 },
    closedNote: "THE BRIGHT FACET IS SHUT. THE CASES ARE LOCKED."
  },
  tailor: {
    id: "tailor",
    hours: { open: 8.5, close: 18, lunch: [12, 13] },
    wares: "heart",
    keeper: {
      title: "TAILOR",
      greet: ["THE SILVER NEEDLE. I COULD CUT YOU A CLOAK. IT WOULD TAKE A SAIL.", "STAND STILL. NO, I'M ONLY LOOKING. WHAT SHOULDERS.", "MIND THE BOLTS, DEAR. YOU SHED GRIT."],
      welcome: ["GOODNESS. WIPE YOUR FEET.", "MIND THE BOLTS."],
      hello: ["COME FOR A FITTING?", "NEW CLOTH IN FROM THE COAST.", "BE RIGHT WITH YOU."],
      closing: ["PINS DOWN. WE'RE CLOSED."]
    },
    visits: { browse: 4, buy: 3, window: 2 },
    wellOff: 2,
    traits: { sociable: 1.5, cheerful: 1.3 },
    closedNote: "THE SILVER NEEDLE IS SHUT. THE FORMS STAND IN THE DARK."
  },
  tavern: {
    id: "tavern",
    hours: { open: 10, close: 26 },
    wares: "mug",
    keeper: {
      title: "INNKEEPER",
      greet: ["THE SUNKEN CROWN. ALE, STEW, A BED. NONE OF IT MUCH USE TO YOU.", "THE CELLAR HATCH WAS CUT FOR ONE OF YOUR SORT. WANT WORK?", "SIT IF YOU LIKE. NOT ON THE STOOLS."],
      welcome: ["MIND THE DOOR FRAME.", "WELL. THERE'S A SIGHT."],
      hello: ["THE USUAL?", "FIND A STOOL.", "STEW'S ON."],
      closing: ["DRINK UP. BEDS OR THE STREET."]
    },
    visits: { pint: 5, warm: 2, rounds: 1.5 },
    traits: { thirsty: 3, idler: 1.5 },
    closedNote: "THE SUNKEN CROWN IS QUIET. THE FIRE IS LOW."
  },
  guild: {
    id: "guild",
    hours: { open: 7, close: 21 },
    wares: "sword",
    keeper: {
      title: "GUILD CLERK",
      greet: ["ADVENTURERS' GUILD, WESTWAKE CHAPTER. THE BOARD IS BY THE WEST WALL.", "CONTRACTS ARE FOR MEMBERS. I'LL NEED TO ASK ABOUT GOLEMS.", "ONE SHEET'S GONE YELLOW UP THERE. THE SUNKEN KEEP. KNOW IT?"],
      welcome: ["BOARD'S ON THE LEFT.", "NAME AND BUSINESS? ...OH."],
      hello: ["BOARD'S ON THE LEFT.", "SIGN THE BOOK.", "NOTHING NEW SINCE MORNING."],
      closing: ["THE HALL CLOSES AT NINE. OUT."]
    },
    visits: { board: 5, desk: 2.5, between: 2, warm: 1.5, rounds: 2 },
    traits: { curious: 1.6, restless: 1.4 },
    closedNote: "THE GUILD HALL IS SHUT FOR THE NIGHT."
  }
};
var SHELVES = ["browse", "idle."];
var LOOK = ["browse", "browse", "point", "browse", "stand"];
var READ = ["read", "read", "point", "read", "note", "read", "nod"];
var VISITS = {
  // round the shelves and racks, and out again
  browse: { id: "browse", steps: [
    { at: SHELVES, share: 3, poses: LOOK, mutter: "browse" },
    { at: SHELVES, share: 3, poses: LOOK, mutter: "browse" },
    { at: SHELVES, share: 2, poses: ["browse", "stand", "nod"] }
  ] },
  // a look, then the counter: queue, haggle, coin across, a nod
  buy: { id: "buy", likes: { brisk: 1.6, wary: 0.8 }, steps: [
    { at: SHELVES, share: 3, poses: LOOK, mutter: "browse" },
    { at: ["counter"], share: 5, poses: ["stand"], deal: "buy", after: SHELVES, mutter: "queue" }
  ] },
  // looks at the goods, shakes their head at the price and leaves
  window: { id: "window", likes: { grumpy: 2, idler: 1.5, brisk: 0.5 }, steps: [
    { at: SHELVES, share: 3, poses: ["browse", "point", "browse"], mutter: "browse" },
    { at: SHELVES, share: 2, poses: ["browse", "shake", "stand"], mutter: "dear" },
    { at: ["counter"], share: 2, poses: ["stand"], deal: "looking", after: SHELVES }
  ] },
  // in out of the weather: the fire, a look round
  warm: { id: "warm", likes: { elder: 2.5, idler: 2, brisk: 0.3 }, steps: [
    { at: ["idle.hearth", "idle.fire"], share: 5, poses: ["warm", "warm", "stand"], mutter: "warm" },
    { at: ["idle.", "browse"], share: 2, poses: ["stand", "browse"] }
  ] },
  // the smith's errand: the master sent an apprentice for something
  fetch: { id: "fetch", only: ["apprentice"], steps: [
    { at: ["counter"], share: 4, poses: ["stand"], deal: "fetch", after: ["browse.tools", "idle.browse", "browse"] },
    { at: ["browse.tools", "idle.browse", "browse"], share: 3, poses: ["browse", "note", "browse", "point"], mutter: "browse" }
  ] },
  // the watch looks in
  rounds: { id: "rounds", only: ["watch"], steps: [
    { at: ["idle.", "browse"], share: 2, poses: ["stand", "lean"] },
    { at: ["counter"], share: 3, poses: ["stand"], deal: "rounds", after: ["idle.", "browse"] }
  ] },
  // a pint at midday: order at the bar, then a stool
  pint: { id: "pint", likes: { thirsty: 2 }, steps: [
    { at: ["counter"], share: 3, poses: ["stand"], deal: "order", after: ["seat"] },
    { at: ["seat"], share: 6, poses: ["sit"] }
  ] },
  // the guild board: read it, point, take a note, nod or shake the head (see BOARD)
  board: { id: "board", likes: { adventurer: 2, curious: 1.5 }, steps: [
    { at: ["idle.board"], share: 6, poses: READ, mutter: "board" },
    { at: ["browse", "idle.fire"], share: 2, poses: ["stand", "browse"] }
  ] },
  // a word at the desk, then the board
  desk: { id: "desk", steps: [
    { at: ["counter"], share: 4, poses: ["stand"], deal: "desk", after: ["idle.board", "browse"] },
    { at: ["idle.board"], share: 4, poses: READ, mutter: "board" }
  ] },
  // between jobs: a glance at the board, then a seat by the fire
  between: { id: "between", only: ["adventurer", "elder", "watch"], steps: [
    { at: ["idle.board"], share: 3, poses: ["read", "point", "shake"], mutter: "board" },
    { at: ["seat"], share: 6, poses: ["sit"] }
  ] }
};
var SHOP_HABITS = {
  // the watch looks in on the guild and the tavern between rounds
  watch: { during: ["socialize", "wander"], chance: 0.7, shops: { guild: 3, tavern: 2, armory: 1.5, smithy: 1 } },
  // a pint at midday, and the smith for a mended pick
  labourer: { during: ["socialize"], chance: 0.75, shops: { tavern: 4, smithy: 1.5 } },
  // apprentices are in and out of the smithy all day
  apprentice: { during: ["work", "errand", "wander", "socialize"], chance: 0.8, shops: { smithy: 7, tailor: 0.6, guild: 0.8, armory: 0.6 } },
  // adventurers live between the guild board and the armoury's racks
  adventurer: { during: ["socialize", "wander"], chance: 0.9, shops: { guild: 6, armory: 3, smithy: 1, jeweler: 0.7, tailor: 0.4 } },
  // residents keep the tailor in business; the well-off among them the jeweller
  resident: { during: ["errand", "chore", "wander", "socialize"], chance: 0.7, shops: { tailor: 4, jeweler: 1.2, smithy: 1, guild: 0.5, armory: 0.2 } },
  // the old come in for the fire and the talk
  elder: { during: ["socialize", "wander", "sit"], chance: 0.6, shops: { tailor: 2, tavern: 1.5, guild: 1.5, jeweler: 0.9 } }
};
var TRIP = {
  minBlock: 0.9,
  twoIn: 3.6,
  len: [1.8, 2.6],
  lead: 0.28,
  margin: 0.06,
  /** The shortest trip worth making when a shop's hours cut one short. */
  minTrip: 1.2
};
var BOARD = {
  /** Spot id prefix of the places in front of a board, in the guild hall and in the square. */
  spots: "idle.board",
  /** The guild's room. */
  area: "town_guild",
  /** How it is read, in turn. The grumpy shake their heads where others nod. */
  gestures: READ
};

// src/game/content/talk.ts
var PEER_MAX = 50;
var X = (id, ctx, lines, o = {}) => ({ id, ctx, lines, ...o });
var STREET = ["meet", "well"];
var EXCHANGES = [
  // ---- meeting in the street, the square, on a bench
  X("hello", STREET, [["a", "{hail}, {b}."], ["b", "{hail}. KEEPING WELL?"], ["a", "@say"], ["b", "@re"]], { weight: 2 }),
  X("own", [...STREET, "ale", "camp"], [["a", "@say"], ["b", "@re"]], { weight: 2 }),
  X("own2", [...STREET, "ale", "camp"], [["a", "@say"], ["b", "@say"], ["a", "@re"]], { weight: 1.5 }),
  X("rain", STREET, [["a", "LOOKS LIKE RAIN."], ["b", "IT ALWAYS LOOKS LIKE RAIN."]]),
  X("stone_one", [...STREET, "ale"], [["a", "SEEN THE STONE ONE ABOUT?"], ["b", "WALKS LIKE A THREE-WHEELED CART."], ["a", "STILL. IT SAYS GOOD DAY."]]),
  X("stone_two", STREET, [["a", "THAT GOLEM. WHOSE IS IT?"], ["b", "NOBODY'S. THAT'S THE ODD PART."]]),
  X("supper", STREET, [["a", "{b}! JUST WHO I WANTED."], ["b", "WHAT HAVE I DONE NOW?"], ["a", "NOTHING YET. COME TO SUPPER."]], { a: { trait: ["sociable", "cheerful"] } }),
  X("fine_day", STREET, [["a", "FINE DAY FOR IT!"], ["b", "FOR WHAT?"], ["a", "FOR ANYTHING!"]], { a: { trait: ["cheerful"] } }),
  X("gripe", [...STREET, "ale", "shop"], [["a", "@gripe"], ["b", "@re"]], { a: { trait: ["grumpy"] }, weight: 3 }),
  X("gripe2", STREET, [["a", "@gripe"], ["b", "YOU SAID THAT YESTERDAY."], ["a", "IT WAS TRUE YESTERDAY."]], { a: { trait: ["grumpy"] }, weight: 2 }),
  X("quiet", [...STREET, "pass"], [["a", "{hail}, {b}."], ["b", "MM."]], { b: { trait: ["reserved"] }, weight: 3 }),
  X("in_my_day", STREET, [["a", "IN MY DAY THE WELL WAS DEEPER."], ["b", "IT'S THE SAME WELL, {a}."], ["a", "SO THEY'D HAVE US THINK."]], { a: { arch: ["elder"] }, weight: 2 }),
  X("hammer", STREET, [["a", "MASTER THREW A HAMMER AT ME."], ["b", "DID IT HIT?"], ["a", "ONLY THE ONCE."]], { a: { arch: ["apprentice"] }, weight: 2 }),
  X("back", STREET, [["a", "MY BACK'S IN TWO PIECES."], ["b", "GET A GOLEM TO CARRY IT."], ["a", "THE STONE? OR MY BACK?"]], { a: { arch: ["labourer"] }, weight: 2 }),
  X("work_going", STREET, [["a", "ANY WORK GOING?"], ["b", "RATS. IT'S ALWAYS RATS."]], { b: { arch: ["adventurer"] } }),
  X("hurry", STREET, [["a", "WHERE'S THE FIRE, {b}?"], ["b", "CAN'T STOP!"]], { b: { trait: ["brisk"] }, weight: 2 }),
  X("homebody", STREET, [["a", "EVER THINK OF LEAVING WESTWAKE?"], ["b", "WHATEVER FOR?"]], { a: { trait: ["restless"] } }),
  // ---- a nod to the watch
  X("watch_quiet", ["watch"], [["a", "ALL QUIET, WATCH?"], ["b", "ALL QUIET. KEEP IT SO."]], { b: { arch: ["watch"] }, weight: 2 }),
  X("watch_hail", ["watch", "pass"], [["a", "{hail}, WATCH."], ["b", "CITIZEN."]], { b: { arch: ["watch"] }, weight: 2 }),
  X("watch_goat", ["watch"], [["a", "ANYTHING TO REPORT?"], ["b", "A GOAT. LOOSE AGAIN."], ["a", "THAT GOAT."]], { a: { arch: ["watch"] } }),
  X("watch_golem", ["watch"], [["a", "IS THE STONE ONE ALLOWED IN?"], ["b", "IT PAID THE GATE TOLL. IN PEBBLES."]], { b: { arch: ["watch"] } }),
  X("watch_both", ["watch"], [["a", "QUIET NIGHT?"], ["b", "TOO QUIET."], ["a", "YOU ALWAYS SAY THAT."]], { a: { arch: ["watch"] }, b: { arch: ["watch"] }, weight: 3 }),
  // ---- gossip at the well
  X("baker", ["well"], [["a", "HEARD ABOUT THE BAKER?"], ["b", "NO. GO ON."], ["a", "FLOUR'S HALF CHALK, THEY SAY."], ["b", "@re"]], { weight: 2 }),
  X("news", ["well", "meet"], [["a", "@news"], ["b", "NEVER!"], ["a", "ON MY LIFE."]], { weight: 2 }),
  X("news2", ["well", "ale"], [["a", "@news"], ["b", "@re"]], { weight: 2 }),
  X("guild_lot", ["well"], [["a", "WHO'S AT THE GUILD THIS WEEK?"], ["b", "SELLSWORDS. LOUD ONES."]]),
  // ---- passing by: a word without stopping long
  X("pass_hail", ["pass"], [["a", "{hail}, {b}."], ["b", "{hail}."]], { weight: 3 }),
  X("pass_names", ["pass"], [["a", "{b}."], ["b", "{a}."]], { weight: 2 }),
  X("pass_cheer", ["pass"], [["a", "LOVELY DAY, {b}!"], ["b", "@re"]], { a: { trait: ["cheerful", "sociable"] }, weight: 2 }),
  // ---- at the tavern, in it or at its door
  X("another", ["ale"], [["a", "ANOTHER?"], ["b", "TWIST MY ARM."]], { weight: 2 }),
  X("crown", ["ale"], [["a", "TO THE CROWN!"], ["b", "SUNK AS IT IS."]]),
  X("round", ["ale"], [["a", "WHOSE ROUND IS IT?"], ["b", "YOURS. IT'S ALWAYS YOURS."], ["a", "FUNNY, THAT."]]),
  X("stew", ["ale"], [["a", "WHAT'S IN THE STEW TONIGHT?"], ["b", "BEST NOT TO ASK."]]),
  // ---- the hunters' camp
  X("wind", ["camp"], [["a", "WIND'S TURNED NORTH."], ["b", "DEER WILL MOVE AT DUSK, THEN."]], { weight: 2 }),
  X("hum", ["camp"], [["a", "HEAR THE CIRCLE HUM LAST NIGHT?"], ["b", "I HEARD NOTHING. NOR DID YOU."]], { weight: 2 }),
  X("pelts", ["camp"], [["a", "PELTS TO WESTWAKE THIS WEEK?"], ["b", "IF THE ROAD'S DRY."]]),
  X("red_ones", ["camp"], [["a", "FOUND MUSHROOMS BY THE STONES."], ["b", "NOT THE RED ONES."], ["a", "...SOME RED ONES."]]),
  // ---- two customers at a shop's shelves
  X("price", ["shop"], [["a", "LOOK AT THE PRICE OF THAT.", "point"], ["b", "DAYLIGHT ROBBERY."]], { weight: 2 }),
  X("suit", ["shop"], [["a", "WOULD IT SUIT ME?"], ["b", "@re"]]),
  X("coast", ["shop"], [["a", "THEY SAY IT'S FROM THE COAST."], ["b", "THEY SAY THAT OF EVERYTHING."]]),
  // ---- two people at the guild board (or the notice board in the square)
  X("rats", ["board"], [["a", "RATS IN A CELLAR. AGAIN.", "point"], ["b", "PAYS FOUR SILVER, THOUGH."], ["a", "PER RAT?"], ["b", "PER CELLAR.", "shake"]], { weight: 2 }),
  X("keep", ["board"], [["a", "SEE THIS ONE? THE SUNKEN KEEP.", "point"], ["b", "NOBODY COMES BACK FROM THAT.", "shake"]], { weight: 2 }),
  X("wolves", ["board"], [["a", "WOLF BOUNTY'S STILL UP.", "point"], ["b", "SO ARE THE WOLVES."]]),
  X("goat", ["board"], [["a", "LOST: ONE GOAT.", "point"], ["b", "IT'S IN MY GARDEN. AGAIN.", "nod"]]),
  X("escort", ["board"], [["a", "ESCORT TO THE COAST. TEN DAYS.", "point"], ["b", "TEN DAYS OF YOUR SINGING? NO.", "shake"]], { a: { arch: ["adventurer"] }, weight: 2 }),
  // ---- over a counter: `a` is the customer, `b` the keeper
  X("haggle", ["deal.buy"], [["a", "HOW MUCH FOR THIS?", "point"], ["b", "THREE SILVER."], ["a", "TWO."], ["b", "TWO AND A HALF."], ["a", "DONE.", "pay"], ["b", "A PLEASURE."]], { weight: 2 }),
  X("take_it", ["deal.buy"], [["a", "I'LL TAKE IT.", "pay"], ["b", "A FINE CHOICE."], ["a", "IT HAD BETTER BE.", "nod"]], { weight: 2 }),
  X("last_time", ["deal.buy"], [["a", "SAME AS LAST TIME, {b}.", "pay"], ["b", "WRAPPED AND READY."]], { weight: 2 }),
  X("half", ["deal.buy"], [["a", "THAT'S NOT WORTH HALF."], ["b", "THEN PAY HALF. TAKE HALF."], ["a", "HMPH. FINE.", "pay"]], { a: { trait: ["grumpy"] }, weight: 4 }),
  X("quick", ["deal.buy"], [["a", "THIS. QUICKLY.", "pay"], ["b", "ALWAYS IN A RUSH, {a}."]], { a: { trait: ["brisk"] }, weight: 4 }),
  X("chatty_buy", ["deal.buy"], [["a", "AND HOW'S THE FAMILY, {b}?"], ["b", "WELL. ARE YOU BUYING?"], ["a", "OH! YES.", "pay"]], { a: { trait: ["sociable"] }, weight: 4 }),
  X("looking", ["deal.looking"], [["a", "JUST LOOKING."], ["b", "LOOK ALL YOU LIKE."]], { weight: 2 }),
  X("too_dear", ["deal.looking"], [["a", "HOW MUCH? NO. NO.", "shake"], ["b", "QUALITY COSTS."]], { weight: 2 }),
  X("next_week", ["deal.looking"], [["a", "PUT IT BY FOR ME?"], ["b", "UNTIL MARKET DAY. NO LONGER."], ["a", "BLESS YOU.", "nod"]]),
  X("nails", ["deal.fetch"], [["a", "MASTER SENT ME FOR NAILS."], ["b", "TELL HIM HE STILL OWES ME."], ["a", "I'LL... TELL HIM.", "nod"]], { weight: 2 }),
  X("tongs", ["deal.fetch"], [["a", "TONGS. THE BIG ONES."], ["b", "BRING THEM BACK THIS TIME."]], { weight: 2 }),
  X("quench", ["deal.fetch"], [["a", "I CRACKED ANOTHER BLADE."], ["b", "QUENCH SLOWER. COUNT TO FIVE."], ["a", "ONE... TWO...", "nod"]]),
  X("pint", ["deal.order"], [["a", "A PINT, {b}.", "pay"], ["b", "COMING UP."]], { weight: 2 }),
  X("usual", ["deal.order"], [["a", "THE USUAL."], ["b", "IT'S ALWAYS THE USUAL."], ["a", "THAT'S WHY IT'S USUAL.", "pay"]], { weight: 2 }),
  X("slate", ["deal.order"], [["a", "PUT IT ON THE SLATE?"], ["b", "THE SLATE'S FULL, {a}."], ["a", "HMPH.", "pay"]], { a: { trait: ["thirsty", "grumpy"] }, weight: 3 }),
  X("trouble", ["deal.rounds"], [["a", "ANY TROUBLE?"], ["b", "NONE. QUIET AS STONE."], ["a", "KEEP IT SO.", "nod"]], { weight: 2 }),
  X("locks", ["deal.rounds"], [["a", "LOCK UP WELL TONIGHT."], ["b", "I ALWAYS DO."]]),
  X("new_work", ["deal.desk"], [["a", "ANYTHING NEW ON THE BOARD?"], ["b", "RATS. AND THE OLD KEEP SURVEY."], ["a", "NOBODY'S TAKING THAT.", "shake"]], { weight: 2 }),
  X("caravan", ["deal.desk"], [["a", "WHEN'S THE NEXT CARAVAN?"], ["b", "WHEN IT GETS HERE."]]),
  X("dues", ["deal.desk"], [["a", "ABOUT MY DUES..."], ["b", "THREE MONTHS BEHIND, {a}."], ["a", "IS IT THREE? MY.", "nod"]], { a: { arch: ["adventurer"] }, weight: 3 }),
  X("notice", ["deal.desk"], [["a", "CAN I PIN UP A NOTICE?"], ["b", "MEMBERS ONLY. ASK AGAIN SOON."]], { a: { arch: ["resident", "elder", "apprentice"] }, weight: 3 })
];
var EXCHANGE_BY_ID = Object.fromEntries(EXCHANGES.map((e) => [e.id, e]));
var PEER_LINES = {
  watch: ["THE GATE HINGE WANTS OIL.", "NIGHT SHIFT GETS THE GOOD STEW.", "SOMEBODY'S GOAT IS LOOSE AGAIN."],
  labourer: ["THE YARD'S SHORT A HAULER.", "NEW STONE'S IN FROM THE QUARRY.", "MY BOOTS ARE MORE HOLE THAN BOOT."],
  apprentice: ["I BURNT MY THUMB. LOOK.", "MASTER SAYS I'M NEARLY USEFUL.", "ONE DAY I'LL HAVE MY OWN FORGE."],
  adventurer: ["THE ARMOURER WANTS NINE SILVER. NINE!", "I FOUGHT A BEAR ONCE. NEARLY.", "THERE'S A KEEP UNDER THAT HILL. I KNOW IT."],
  resident: ["THE WASHING WON'T DRY IN THIS.", "MARKET'S ON THE SEVENTH DAY.", "THE TAILOR HAS NEW CLOTH IN."],
  elder: ["MY KNEES SAY FROST.", "THE OLD WELL NEVER RAN DRY. NOT ONCE.", "NOBODY BOWS TO THE STATUE ANY MORE."],
  hunter: ["TRACKS BY THE STREAM. FRESH.", "THE DEER ARE THIN THIS YEAR.", "MY BOWSTRING'S FRAYED AGAIN."],
  forager: ["SORREL'S UP BY THE OLD STONES.", "NEVER THE RED ONES.", "THE BRAMBLES ARE EARLY."],
  curious: ["WHAT'S UNDER THE HILL, DO YOU THINK?"],
  thirsty: ["IS IT TOO EARLY FOR A PINT?"],
  sociable: ["WE SHOULD ALL HAVE SUPPER."],
  wary: ["I DON'T LIKE THE LOOK OF THOSE CLOUDS."]
};
var GRIPES = ["PRICES. HAVE YOU SEEN THE PRICES?", "MY FEET HURT.", "TOO MANY PEOPLE ABOUT.", "THE BELL RANG LATE AGAIN.", "NOBODY SWEEPS THIS STREET.", "IT'LL RAIN. MARK ME."];
var NEWS = ["THE SMITH'S BOY BURNT HIS BROWS OFF.", "THE JEWELLER SLEEPS ON HIS STRONGBOX.", "THE GUILD LOST ANOTHER PARTY EAST.", "SOMEONE SAW LIGHTS UNDER THE HILL.", "THE INNKEEPER WATERS THE ALE.", "THE TAILOR'S SWEET ON THE CLERK."];
var REACTIONS = {
  cheerful: ["HA! TRUE ENOUGH.", "WONDERFUL!", "ISN'T IT JUST."],
  grumpy: ["HMPH.", "IF YOU SAY SO.", "WHAT OF IT?"],
  reserved: ["MM.", "...", "PERHAPS."],
  sociable: ["YOU DON'T SAY! GO ON.", "OH, I KNOW. I KNOW.", "TELL ME EVERYTHING."],
  curious: ["REALLY? HOW SO?", "NOW THAT'S INTERESTING."],
  wary: ["KEEP YOUR VOICE DOWN.", "I'D NOT SAY THAT ALOUD."],
  brisk: ["RIGHT. MUST GET ON.", "QUITE. GOOD DAY."],
  idler: ["NO RUSH ABOUT IT.", "AYE... AYE."],
  DEFAULT: ["AYE.", "TRUE ENOUGH.", "YOU DON'T SAY.", "WELL, THERE IT IS.", "HA!"]
};
var MUTTERS = {
  browse: ["HM.", "NICE WORK, THAT.", "NOT TODAY.", "NOW THAT'S FINE.", "HM. MAYBE."],
  dear: ["TOO DEAR.", "FOR THAT? NO.", "I'LL THINK ON IT."],
  queue: ["ANY DAY NOW.", "...", "COME ON."],
  warm: ["AH. THAT'S BETTER.", "BLESS THIS FIRE."],
  board: ["RATS. AGAIN.", "HM. FOUR SILVER.", "NOT FOR ME.", "WHO PINNED THIS?", "STILL NO TAKERS."]
};
var hail = (hour) => hour < 12 ? "MORNING" : hour < 17.5 ? "AFTERNOON" : "EVENING";
var TO_THE_GOLEM = /\bYOU\b|\bYOU'|\bYOUR|GOLEM|STONE ONE|CLAY-FOOT|\bDEAR\b|OLD ONES|CAN I LOOK/;
var fitsPeers = (line) => line.length <= PEER_MAX && !TO_THE_GOLEM.test(line);
function peerLines(archetype, traits, act) {
  const own = [...ARCHETYPES[archetype]?.lines ?? [], ...traits.flatMap((t) => TRAITS[t]?.lines ?? []), ...act ? ACTIVITY_LINES[act] ?? [] : []];
  return [...own.filter(fitsPeers), ...PEER_LINES[archetype] ?? [], ...traits.flatMap((t) => PEER_LINES[t] ?? [])];
}

// src/game/sim/shops.ts
var SHOP_BY_AREA = Object.fromEntries(ESTABLISHMENTS.map((e) => [interiorId(e), SHOPS[e]]));
var shopOfArea = (area) => SHOP_BY_AREA[area];
function shopOpenAt(def, hour) {
  const h = wrapHour(hour), { open, close, lunch } = def.hours;
  const within = close > 24 ? h >= open || h < close - 24 : h >= open && h < close;
  return within && !(lunch && h >= lunch[0] && h < lunch[1]);
}
function openRun(def, from, to) {
  const step = 0.1, n = Math.floor((to - from) / step + 1e-9);
  let best = null, i0 = -1;
  for (let i = 0; i <= n + 1; i++) {
    const open = i <= n && shopOpenAt(def, from + i * step);
    if (open && i0 < 0) i0 = i;
    if (!open && i0 >= 0) {
      const a = from + i0 * step, b = i - 1 === n && shopOpenAt(def, to) ? to : from + (i - 1) * step;
      if (!best || b - a > best[1] - best[0]) best = [a, b];
      i0 = -1;
    }
  }
  return best;
}
var wellOff = (p) => BUILDINGS.find((b) => `door.${b.id}` === p.home)?.light === "rune";
function weighted(rows, r) {
  const total = rows.reduce((s, [, n]) => s + Math.max(0, n), 0);
  if (total <= 0) return null;
  let k = r * total;
  for (const [x, n] of rows) {
    k -= Math.max(0, n);
    if (k < 0) return x;
  }
  return rows[rows.length - 1][0];
}
var tripCache = /* @__PURE__ */ new Map();
function tripsOf(w, a, day, blocks) {
  const p = a.person, habit = SHOP_HABITS[p.archetype];
  if (!habit) return [];
  const key = `${w.seed}|${a.id}|${day}|${p.archetype}|${p.routine}|${p.traits.join(",")}|${p.home}`;
  const hit = tripCache.get(key);
  if (hit) return hit;
  if (tripCache.size > 4e3) tripCache.clear();
  const out = [], shift = shiftOf(w, a, day), rich = wellOff(p);
  const h = (i, k, salt) => hash01(`${w.seed}:${a.id}:trip:${day}:${i}:${k}`, salt);
  blocks.forEach((b, i) => {
    const len = b.to - b.from;
    if (!habit.during.includes(b.act) || len < TRIP.minBlock) return;
    const slots = len >= TRIP.twoIn ? 2 : 1, seg = len / slots;
    for (let k = 0; k < slots; k++) {
      if (h(i, k, 0) > habit.chance) continue;
      const dur = Math.min(TRIP.len[0] + h(i, k, 1) * (TRIP.len[1] - TRIP.len[0]), seg - 2 * TRIP.margin);
      let from = b.from + seg * k + TRIP.margin + h(i, k, 2) * (seg - dur - 2 * TRIP.margin), to = from + dur;
      const runs = {};
      const shops = Object.keys(habit.shops).map((s) => {
        const def = SHOPS[s], run = openRun(def, from + shift, to + shift);
        if (!run || run[1] - run[0] < Math.min(TRIP.minTrip, dur - 0.01)) return [s, 0];
        runs[s] = run;
        let n = habit.shops[s] ?? 0;
        if (rich && def.wellOff) n *= def.wellOff;
        for (const t of p.traits) n *= def.traits?.[t] ?? 1;
        return [s, n];
      });
      const shop = weighted(shops, h(i, k, 3));
      if (!shop) continue;
      from = runs[shop][0] - shift;
      to = runs[shop][1] - shift;
      const visits = Object.entries(SHOPS[shop].visits).map(([id, n]) => {
        const v = VISITS[id];
        if (!v || v.only && !v.only.includes(p.archetype)) return [id, 0];
        let m = n * (v.likes?.[p.archetype] ?? 1);
        for (const t of p.traits) m *= v.likes?.[t] ?? 1;
        return [id, m];
      });
      const visit = weighted(visits, h(i, k, 4));
      if (visit) out.push({ n: out.length, block: i, from, to, shop, visit });
    }
  });
  tripCache.set(key, out);
  return out;
}
function shopStepAt(plan, day) {
  const steps = VISITS[plan.trip.visit].steps, total = steps.reduce((s, x) => s + x.share, 0);
  const frac = (day - plan.startDay) / Math.max(1e-9, plan.endDay - plan.startDay);
  let k = Math.min(0.9999, Math.max(0, (frac - TRIP.lead) / (1 - TRIP.lead))) * total;
  for (let i = 0; i < steps.length; i++) {
    k -= steps[i].share;
    if (k < 0) return { index: i, step: steps[i] };
  }
  return { index: steps.length - 1, step: steps[steps.length - 1] };
}
var KEEPER_KIND = "keeper";
var KEEPER_DEF = "shopkeeper";
var KEEPER_REACH = 38;
var NEVER = -1e9;
var KEEPER_SPEED = 15;
var keeperId = (shop) => `keeper.${shop}`;
var isKeeper = (a) => a.kind === KEEPER_KIND && !!a.keeper;
var keeperPresent = (a) => !isKeeper(a) || a.keeper.state !== "away";
var keeperOf = (w, area) => {
  const s = shopOfArea(area);
  return s ? actorById(w, keeperId(s.id)) : void 0;
};
var keeperReady = (a) => isKeeper(a) && a.keeper.state === "tend" && a.keeper.attend <= 0;
function keeperServe(a, customer) {
  const K = a.keeper;
  K.state = "serve";
  K.with = customer;
  K.goal = null;
}
function populateKeepers(w, area) {
  const shop = shopOfArea(area);
  if (!shop || actorById(w, keeperId(shop.id))) return;
  getArea(w, TOWN_ID);
  const room = w.areas.get(area);
  const home = room ? spotById(room, "keeper") : void 0;
  if (!home) return;
  const id = keeperId(shop.id), h = (salt) => hash01(`${w.seed}:${id}`, salt);
  const a = makeActor(id, KEEPER_DEF, area, home.x, home.y);
  a.kind = KEEPER_KIND;
  a.keeper = {
    shop: shop.id,
    name: `${NAMES.given[Math.floor(h(1) * NAMES.given.length)]} ${NAMES.family[Math.floor(h(2) * NAMES.family.length)]}`,
    state: "away",
    t: 0,
    cool: 0,
    greet: 0,
    attend: 0,
    seen: NEVER,
    with: null,
    goal: null,
    n: 0,
    talks: 0
  };
  w.actors.push(a);
}
var faceTo = (dx, dy) => Math.abs(dx) > Math.abs(dy) ? dx > 0 ? "right" : "left" : dy > 0 ? "down" : "up";
function say(w, a, lines, to) {
  const K = a.keeper;
  if (!lines.length) return;
  emit(w, { t: "folkSay", folk: a.id, to, line: lines[Math.floor(hash01(`${w.seed}:${a.id}`, 300 + K.talks++) * lines.length)] });
}
function moveToward(a, g, dt) {
  const dx = g.x - a.x, dy = g.y - a.y, d = Math.hypot(dx, dy), step = KEEPER_SPEED * dt;
  if (d <= step) {
    a.x = g.x;
    a.y = g.y;
    return true;
  }
  a.x += dx / d * step;
  a.y += dy / d * step;
  a.moving = true;
  a.facing = faceTo(dx, dy);
  a.phase += step * 0.26;
  return false;
}
function tickKeepers(w, dt) {
  const pl = player(w);
  if (!pl) return;
  for (const a of w.actors) if (isKeeper(a) && a.area === pl.area) tickKeeper(w, a, dt, pl);
}
function tickKeeper(w, a, dt, pl) {
  const K = a.keeper, def = SHOPS[K.shop], area = getArea(w, a.area), home = spotById(area, "keeper");
  if (!def || !home) return;
  const open = shopOpenAt(def, hourOf(w.day)), fresh = w.time - K.seen > 1;
  const R = (salt) => hash01(`${w.seed}:${a.id}`, salt + K.n++ % 1e5 * 7);
  K.seen = w.time;
  K.cool = Math.max(0, K.cool - dt);
  a.moving = false;
  if (fresh) {
    K.state = open ? "tend" : "away";
    a.x = home.x;
    a.y = home.y;
    a.facing = "down";
    K.goal = null;
    K.with = null;
    K.attend = 0;
    K.t = 4 + R(1) * 8;
    K.greet = open ? 0.9 : 0;
    if (!open) emit(w, { t: "message", text: def.closedNote });
  }
  if (K.state === "serve") {
    const c = K.with ? actorById(w, K.with) : void 0;
    if (c && c.area === a.area && c.life?.chat?.with === a.id) {
      a.facing = faceTo(c.x - a.x, c.y - a.y);
      return;
    }
    K.state = "tend";
    K.with = null;
    K.t = 3 + R(2) * 5;
    a.facing = "down";
  }
  if (!open) {
    if (K.state !== "away") {
      say(w, a, def.keeper.closing);
      K.state = "away";
      K.goal = null;
      K.attend = 0;
      a.x = home.x;
      a.y = home.y;
    }
    return;
  }
  if (K.state === "away") {
    K.state = "tend";
    a.x = home.x;
    a.y = home.y;
    a.facing = "down";
    K.t = 5 + R(3) * 8;
  }
  if (K.greet > 0) {
    K.greet -= dt;
    if (K.greet <= 0) {
      K.greet = 0;
      say(w, a, def.keeper.welcome, pl.id);
      K.cool = 6;
    }
  }
  if (K.attend > 0) {
    K.attend -= dt;
    a.facing = faceTo(pl.x - a.x, pl.y - a.y);
    return;
  }
  const waiting = w.actors.some((b) => isFolk(b) && b.area === a.area && b.life.spot === "customer");
  switch (K.state) {
    case "tend": {
      a.facing = "down";
      if (K.cool <= 0) {
        const door = spotById(area, "door");
        const c = door && w.actors.find((b) => isFolk(b) && b.area === a.area && b.life.act === "shop" && b.life.state === "walk" && Math.hypot(b.x - door.x, b.y - door.y) < 34);
        if (c) {
          say(w, a, def.keeper.hello, c.id);
          K.cool = 18 + R(4) * 12;
        }
      }
      K.t -= dt;
      if (K.t > 0) break;
      const tidy = (area.base.spots ?? []).filter((s2) => s2.kind === "tidy");
      if (waiting || !tidy.length) {
        K.t = 3;
        break;
      }
      const s = tidy[Math.floor(R(5) * tidy.length)];
      K.goal = { x: s.x, y: s.y };
      K.state = "tidy";
      K.t = 2.5 + R(6) * 3;
      break;
    }
    case "tidy": {
      if (waiting) {
        K.state = "back";
        break;
      }
      if (!K.goal || moveToward(a, K.goal, dt)) {
        a.facing = "up";
        K.t -= dt;
        if (K.t <= 0) K.state = "back";
      }
      break;
    }
    case "back":
      if (moveToward(a, home, dt)) {
        K.state = "tend";
        K.goal = null;
        a.facing = "down";
        K.t = 9 + R(7) * 14;
      }
      break;
  }
}
function keeperTalk(w, by, targetId) {
  const a = targetId ? actorById(w, targetId) : void 0;
  if (!a || !isKeeper(a) || a.area !== by.area || !keeperPresent(a)) return;
  const K = a.keeper, lines = SHOPS[K.shop].keeper.greet;
  const line = lines[Math.floor(hash01(`${w.seed}:${a.id}`, 5e3 + K.talks++) * lines.length)];
  K.attend = 3.6;
  K.greet = 0;
  a.facing = faceTo(by.x - a.x, by.y - a.y);
  emit(w, { t: "talkedTo", actor: by.id, npc: a.id });
  emit(w, { t: "folkSpoke", actor: by.id, folk: a.id, line });
}

// src/game/sim/lod.ts
var ACTIVE_BOX = { x: 400, y: 260 };
var NEAR_INTERVAL = 0.1;
var NEAR_CHUNK = 0.1;
var FAR_INTERVAL = 0.25;
var FAR_CHUNK = 0.25;
function tierOf(_w, a, focus) {
  if (!focus || a.id === focus.id) return "active";
  if (a.area !== focus.area) return "far";
  return Math.abs(a.x - focus.x) <= ACTIVE_BOX.x && Math.abs(a.y - focus.y) <= ACTIVE_BOX.y ? "active" : "near";
}
var debtOf = (w) => w.lod ??= {};
function stepAtTier(w, a, tier, dt, step, key = a.id) {
  const debt = debtOf(w);
  if (tier === "active") {
    const owed2 = debt[key] ?? 0;
    if (owed2) delete debt[key];
    let left2 = owed2 + dt, done = 0;
    while (left2 > 1e-9) {
      const c = Math.min(left2, dt > 0 ? dt : left2);
      step(c);
      left2 -= c;
      done += c;
    }
    return done;
  }
  const interval = tier === "near" ? NEAR_INTERVAL : FAR_INTERVAL, chunk = tier === "near" ? NEAR_CHUNK : FAR_CHUNK;
  const owed = (debt[key] ?? 0) + dt;
  if (owed + 1e-9 < interval) {
    debt[key] = owed;
    return 0;
  }
  delete debt[key];
  let left = owed;
  while (left > 1e-9) {
    const c = Math.min(left, chunk);
    step(c);
    left -= c;
  }
  return owed;
}
function clearDebt(w, id) {
  if (w.lod && id in w.lod) delete w.lod[id];
}
var CATCH_UPS = [];
function registerCatchUp(id, fn) {
  const i = CATCH_UPS.findIndex((c) => c.id === id);
  if (i >= 0) CATCH_UPS[i].fn = fn;
  else CATCH_UPS.push({ id, fn });
}
function catchUpArea(w, area) {
  const elapsed = Math.max(0, w.time - area.lastTicked);
  if (elapsed > 0) for (const c of CATCH_UPS) c.fn(w, area, elapsed);
  area.lastTicked = w.time;
  return elapsed;
}
registerCatchUp("ritual", (_w, area, elapsed) => area.advanceRitual(elapsed));

// src/game/sim/folk.ts
var FOLK_KIND = "folk";
var FOLK_DEF = "townsfolk";
var STALE = 20;
var NEVER2 = -1e9;
var HOUR_S = DAY_SECONDS / 24;
var isFolk = (a) => a.kind === FOLK_KIND && !!a.person && !!a.life;
var folkPresent = (a) => !isFolk(a) || a.life.state !== "indoors";
var archetypeOf = (a) => ARCHETYPES[a.person.archetype];
var traitsOf = (p) => p.traits.map((t) => TRAITS[t]).filter(Boolean);
var dial = (p, k) => traitsOf(p).reduce((m, t) => m * (t[k] ?? 1), 1);
var H = (w, s, salt = 0) => hash01(`${w.seed}:${s}`, salt);
var roll = (w, a) => H(w, a.id, 1e3 + a.life.visit++ % 1e5);
function makePerson(w, row, taken = /* @__PURE__ */ new Set()) {
  const arch = ARCHETYPES[row.archetype];
  const h = (salt) => H(w, row.id, salt);
  const ids = Object.keys(TRAITS).sort();
  const traits = [];
  for (let k = 0; traits.length < 2 && k < 40; k++) {
    const t = TRAITS[ids[Math.floor(h(10 + k) * ids.length)]];
    if (!traits.some((x) => TRAITS[x].group === t.group)) traits.push(t.id);
  }
  let name = "";
  for (let k = 0; k < 60; k++) {
    const g = NAMES.given[Math.floor(h(30 + k) * NAMES.given.length)], f = NAMES.family[Math.floor(h(31 + k * 3) * NAMES.family.length)];
    name = `${g} ${f}`;
    if (!taken.has(g) || k > 40) {
      taken.add(g);
      break;
    }
  }
  const fem = NAMES.given.indexOf(name.split(" ")[0]) >= 20 ? 1 : 0;
  const old = arch.age === "old", young = arch.age === "young";
  const look = {
    skin: Math.floor(h(50) * 6),
    hair: old ? 6 + Math.floor(h(51) * 2) : Math.floor(h(51) * (young ? 5 : 6)),
    style: Math.floor(h(52) * 4),
    beard: !fem && !young && h(53) < (old ? 0.6 : 0.4) ? 1 + Math.floor(h(54) * 2) : 0,
    build: Math.floor(h(55) * 3),
    tall: h(56) < 0.4 ? 1 : 0,
    cloth: Math.floor(h(57) * 4),
    trim: Math.floor(h(58) * 4),
    hat: Math.floor(h(59) * 3),
    acc: Math.floor(h(60) * 4),
    fem
  };
  const routine = row.routine ?? arch.routines[Math.floor(h(70) * arch.routines.length)];
  return { name, archetype: arch.id, traits, routine, home: row.home, origin: row.area, route: row.route, look };
}
function makeFolk(w, row, taken) {
  const area = getArea(w, row.area), home = spotById(area, row.home);
  const a = makeActor(row.id, FOLK_DEF, row.area, home?.x ?? area.start.x, home?.y ?? area.start.y);
  a.kind = FOLK_KIND;
  a.person = makePerson(w, row, taken);
  a.life = {
    plan: "",
    act: "indoors",
    state: "idle",
    goal: null,
    spot: null,
    path: [],
    wait: 0,
    visit: 0,
    pose: "stand",
    head: null,
    glance: 0,
    cool: H(w, row.id, 7) * 6,
    chatCool: 4 + H(w, row.id, 8) * 8,
    chat: null,
    attend: 0,
    carry: false,
    phase: 0,
    seen: NEVER2,
    talks: 0,
    dawdled: false,
    duty: null
  };
  return a;
}
var censusFlag = (area) => `census.${area}`;
function populateFolk(w, area) {
  if (w.flags.has(censusFlag(area))) return;
  const rows = CENSUS.filter((r) => r.area === area);
  if (!rows.length) return;
  w.flags.add(censusFlag(area));
  const taken = new Set(w.actors.filter(isFolk).map((a) => a.person.name.split(" ")[0]));
  for (const r of rows) if (!actorById(w, r.id)) w.actors.push(makeFolk(w, r, taken));
}
var habitatAreas = (a) => HABITAT_AREAS[archetypeOf(a).habitat];
function shiftOf(w, a, day) {
  return traitsOf(a.person).reduce((s, t) => s + (t.shift ?? 0), 0) + (H(w, a.id, 11) - 0.5) * 0.9 + (H(w, a.id, 2e3 + day) - 0.5) * 0.5;
}
function blocksOf(a) {
  const base = ROUTINES[a.person.routine].blocks, tr = traitsOf(a.person);
  const b = base.map((x) => x.from).concat([24]);
  base.forEach((blk, i) => {
    const e = tr.reduce((s, t) => s + (t.extend?.[blk.act] ?? 0), 0);
    if (!e || i === base.length - 1) return;
    b[i + 1] = Math.min(24, b[i + 1] + e);
    for (let j = i + 2; j < b.length; j++) b[j] = Math.max(b[j], b[i + 1]);
  });
  return base.map((blk, i) => ({ ...blk, from: b[i], to: b[i + 1] })).filter((x) => x.to > x.from + 1e-6);
}
function planAt(w, a, dayValue = w.day) {
  const L = a.life;
  if (L.duty && L.duty.until > dayValue) return { key: "duty", act: L.duty.act, index: -1, day: Math.floor(dayValue), startDay: dayValue, endDay: L.duty.until };
  const day0 = Math.floor(dayValue), shift = shiftOf(w, a, day0);
  const local = dayValue - shift / 24, day = Math.floor(local), hour = (local - day) * 24;
  const blocks = blocksOf(a);
  let i = blocks.findIndex((b2) => hour >= b2.from && hour < b2.to);
  if (i < 0) i = blocks.length - 1;
  const b = blocks[i], abs = (h) => day + h / 24 + shift / 24;
  let from = b.from, to = b.to, part = "";
  for (const t of tripsOf(w, a, day, blocks)) {
    if (t.block !== i) continue;
    if (hour >= t.from && hour < t.to) return { key: `${day}:${i}:s${t.n}`, act: "shop", index: i, day, startDay: abs(t.from), endDay: abs(t.to), trip: t };
    if (t.to <= hour) {
      if (t.to >= from) {
        from = t.to;
        part = `+${t.n}`;
      }
    } else to = Math.min(to, t.from);
  }
  return { key: `${day}:${i}${part}`, act: b.act, at: b.at, index: i, day, startDay: abs(from), endDay: abs(to) };
}
function desiredArea(w, a, plan = planAt(w, a)) {
  if (plan.key === "duty") return a.life.duty.area;
  if (plan.trip) return FOLK_INTERIORS[plan.trip.shop].area;
  const inside = INTERIOR_OF[plan.act];
  if (inside) return FOLK_INTERIORS[inside].area;
  return a.person.origin;
}
var spotById = (area, id) => area.base.spots?.find((s) => s.id === id);
var homeSpot = (w, a) => spotById(getArea(w, a.person.origin), a.person.home);
var indoorsAtHome = (w, a) => homeSpot(w, a)?.kind !== "bed";
function candidates(w, a, area, q) {
  let list = (area.base.spots ?? []).filter((s) => q.kinds.includes(s.kind) && (!q.prefix || q.prefix.some((p) => s.id.startsWith(p))));
  const home = area.id === a.person.origin ? homeSpot(w, a) : void 0;
  const roam = traitsOf(a.person).find((t) => t.roam)?.roam;
  const near = q.nearHome || (roam === "near" && q.kinds.includes("wander") ? 6 : 0);
  if (home && near && roam !== "wide") list = [...list].sort((s, t) => Math.hypot(s.x - home.x, s.y - home.y) - Math.hypot(t.x - home.x, t.y - home.y) || (s.id < t.id ? -1 : 1)).slice(0, near);
  return list;
}
function claimed(w, a, area) {
  const out = /* @__PURE__ */ new Set();
  for (const b of w.actors) if (b !== a && b.area === area && isFolk(b) && b.life.spot) out.add(b.life.spot);
  return out;
}
var isExclusive = (s) => EXCLUSIVE_KINDS.includes(s.kind) || EXCLUSIVE_IDS.some((p) => s.id.startsWith(p));
function pick(w, a, area, q, salt, share = false) {
  const list = candidates(w, a, area, q);
  if (!list.length) return null;
  const held = claimed(w, a, area.id), own = a.life.spot, start = Math.floor(H(w, a.id, salt) * list.length);
  const open = (s) => !held.has(s.id) || share && !isExclusive(s);
  for (let k = 0; k < list.length; k++) {
    const s = list[(start + k) % list.length];
    if (s.id !== own && open(s)) return s;
  }
  return list.find((s) => s.id === own && open(s)) ?? null;
}
function jitter(w, a, s, r, salt) {
  return { x: s.x + Math.round((H(w, a.id, salt) - 0.5) * 2 * r), y: s.y + Math.round((H(w, a.id, salt + 1) - 0.5) * r) };
}
function lampRound(a, area, hour) {
  if (!area.base.tended) return [];
  const dusk = hour > 12, route = a.person.route;
  const out = [];
  for (const p of area.props) {
    if (propDef(p.kind).habit !== "fire" || p.dyn) continue;
    if (route === "high" && p.x < 720) continue;
    if (route === "west" && p.x >= 720) continue;
    const at = dusk ? 19.5 + hash01(p.id, 1) * 1.2 : 6.3 + hash01(p.id, 2) * 0.9;
    const f = nearestFree(area, p.x, p.y + (propDef(p.kind).wallMounted ? 16 : 10), [], [8, 4]);
    if (f) out.push({ id: p.id, x: f.x, y: f.y, at });
  }
  return out.sort((x, y) => x.at - y.at || (x.id < y.id ? -1 : 1));
}
var MOTION = { chop: "chop", hang: "hang", feed: "feed", draw: "draw", sweep: "sweep", hoe: "hoe", hammer: "hammer", dig: "dig", haul: "crouch" };
var motionOf = (spot) => (spot ? MOTION[spot.split(".")[1]] : void 0) ?? "stand";
function nextGoal(w, a, area, plan) {
  const L = a.life, salt = 3e3 + plan.day % 1e3 * 17 + plan.index * 5 + L.visit;
  const asGoal = (s, r = 0) => {
    if (!s) return null;
    const j = r ? jitter(w, a, s, r, salt + 7) : s;
    const f = nearestFree(area, j.x, j.y, [], [8, 4]) ?? s;
    return { x: f.x, y: f.y, facing: s.facing, spot: s.id };
  };
  if (plan.key === "duty") {
    const d = L.duty;
    return { x: d.x, y: d.y, facing: d.facing ?? "down", spot: null };
  }
  const homeArea = a.person.origin;
  switch (plan.act) {
    case "shop":
      return shopGoal(w, a, area, plan);
    case "sleep":
    case "indoors": {
      if (area.id !== homeArea) return null;
      const home = homeSpot(w, a);
      return home ? { x: home.x, y: home.y, facing: "up", spot: home.id } : null;
    }
    case "patrol": {
      const route = ROUTES[area.id]?.[a.person.route ?? ""] ?? Object.values(ROUTES[area.id] ?? {})[0];
      if (!route) return asGoal(pick(w, a, area, { kinds: ["wander"] }, salt, true));
      const n = route.length, k = L.visit % (2 * n - 2 || 1), i = k < n ? k : 2 * n - 2 - k;
      return asGoal(spotById(area, route[i]), 3);
    }
    case "lamps": {
      const hour = wrapHour((w.day - Math.floor(w.day)) * 24), round = lampRound(a, area, hour);
      const held = claimed(w, a, area.id);
      const next = round.find((l) => l.at > hour - 0.04 && !L.spot?.endsWith(l.id) && !held.has(`lamp:${l.id}`)) ?? null;
      if (!next) return asGoal(pick(w, a, area, { kinds: ["patrol"] }, salt, true));
      return { x: next.x, y: next.y, facing: "up", spot: `lamp:${next.id}` };
    }
    case "work": {
      if (L.spot?.startsWith("work.haul")) return asGoal(pick(w, a, area, { kinds: ["work"], prefix: ["work.haul"] }, salt));
      return asGoal(pick(w, a, area, plan.at, salt));
    }
    case "gather":
    case "socialize":
    case "sit":
    case "camp":
    case "tavern":
    case "post":
      return asGoal(pick(w, a, area, plan.at, salt, plan.act === "socialize" || plan.act === "post"), plan.act === "socialize" || plan.act === "post" ? 9 : plan.act === "gather" ? 3 : 0);
    default:
      return plan.at ? asGoal(pick(w, a, area, plan.at, salt, plan.act === "wander"), plan.act === "wander" ? 6 : 0) : null;
  }
}
function stopFor(w, a, plan) {
  const L = a.life, r = roll(w, a), linger = dial(a.person, "linger");
  if (plan.at && !L.spot && plan.act !== "sleep" && plan.act !== "indoors") return { pose: "stand", wait: 2.5 + r * 3 };
  if (plan.act === "shop") return shopStop(w, a, plan, r);
  if (plan.act === "board" || L.spot?.startsWith(BOARD.spots) && (plan.act === "socialize" || plan.act === "wander")) {
    const pose = moodPose(a, BOARD.gestures[L.visit % BOARD.gestures.length]);
    return { pose, wait: pose === "read" ? 2.6 + r * 2.6 : 1.6 };
  }
  switch (plan.act) {
    case "sleep":
      return { pose: "lie", wait: 9999 };
    case "work":
    case "chore": {
      const m = motionOf(L.spot);
      if (L.spot?.startsWith("work.haul")) return { pose: "crouch", wait: 1.6 };
      return { pose: m, wait: (9 + r * 9) * linger };
    }
    case "errand":
      return { pose: "browse", wait: (2.5 + r * 3) * linger };
    case "wander":
      return { pose: L.spot?.startsWith("bench") ? "sit" : "stand", wait: (4 + r * 7) * linger };
    case "patrol":
      return { pose: r < 0.4 ? "lean" : "stand", wait: 2 + r * 3 };
    case "post":
      return { pose: "lean", wait: 14 + r * 10 };
    case "lamps":
      return { pose: "raise", wait: 1.2 };
    case "hunt":
      return { pose: r < 0.6 ? "aim" : "crouch", wait: 2.5 + r * 2.5 };
    case "forage":
      return { pose: "crouch", wait: (4 + r * 4) * linger };
    case "sit":
    case "tavern":
      return { pose: "sit", wait: 25 + r * 20 };
    case "camp":
      return { pose: r < 0.7 ? "sit" : "warm", wait: 20 + r * 20 };
    default:
      return { pose: "stand", wait: (12 + r * 14) * linger };
  }
}
var ROVING = { wander: true, patrol: true, lamps: true, errand: true, hunt: true, forage: true, chore: true, work: true };
var SOCIAL = { socialize: true, gather: true, tavern: true, camp: true, wander: true, sit: true, post: true, errand: true, shop: true, board: true };
registerCatchUp("folk", (w, area, elapsed) => {
  if (elapsed <= STALE) return;
  for (const a of w.actors) if (isFolk(a) && a.area === area.id && !a.task && !(a.job && a.job.status !== "done")) {
    settle(w, a);
    a.life.seen = w.time;
  }
});
function coarse(w, a) {
  const L = a.life;
  if (L.state !== "do" && L.state !== "indoors" || a.moving || L.chat) return false;
  if (L.duty && w.day >= L.duty.until) return false;
  const plan = planAt(w, a);
  return plan.key === L.plan && plan.act === L.act;
}
function tickFolk(w, dt) {
  const pl = player(w);
  if (!pl) return;
  const here = pl.area;
  for (const a of w.actors) {
    if (!isFolk(a)) continue;
    const L = a.life;
    if (a.task || a.job && a.job.status !== "done") {
      L.state = "busy";
      L.pose = a.moving ? "walk" : "stand";
      L.seen = w.time;
      continue;
    }
    if (a.area === here) {
      if (w.time - L.seen > STALE) settle(w, a);
      L.seen = w.time;
      if (a.area === here) stepAtTier(w, a, coarse(w, a) ? tierOf(w, a, pl) : "active", dt, (c) => {
        if (a.area === here) tickPerson(w, a, c);
      }, `folk:${a.id}`);
    } else if (habitatAreas(a).includes(here)) {
      const want = desiredArea(w, a);
      if (want === here) comeIn(w, a);
      else if (want !== a.area && here === a.person.origin) stepOut(w, a);
    }
  }
  for (const a of w.actors) if (isFolk(a) && a.life.head) a.life.head = naturalHead(a.facing, a.life.head);
}
function comeIn(w, a) {
  const plan = planAt(w, a), area = getArea(w, desiredArea(w, a, plan)), L = a.life;
  const sinceS = (w.day - plan.startDay) * DAY_SECONDS;
  if (plan.trip && sinceS < tripLead(w, a, plan)) return;
  const door = (area.base.portals ?? []).find((p) => p.to.area === a.area);
  if (door && sinceS < (plan.trip ? (plan.endDay - plan.startDay) * DAY_SECONDS * 0.55 : HOUR_S * 0.8)) {
    const at = portalArrival(door);
    moveTo(w, a, area.id, at.x, at.y);
    a.facing = at.facing;
    resetLeg(L);
    L.spot = null;
    L.state = "idle";
    L.seen = w.time;
    return;
  }
  moveTo(w, a, area.id, a.x, a.y);
  settle(w, a);
  L.seen = w.time;
}
var tripLead = (w, a, plan) => (plan.endDay - plan.startDay) * DAY_SECONDS * TRIP.lead * (0.45 + H(w, a.id, 17) * 0.5);
function stepOut(w, a) {
  const town = getArea(w, a.person.origin), door = (town.base.portals ?? []).find((p) => p.to.area === a.area), L = a.life;
  if (!door) return;
  const at = portalArrival(door);
  moveTo(w, a, town.id, at.x, at.y);
  a.facing = at.facing;
  resetLeg(L);
  L.spot = null;
  L.state = "idle";
  L.seen = w.time;
}
function moveTo(w, a, area, x, y) {
  getArea(w, area);
  a.area = area;
  a.x = x;
  a.y = y;
  a.vx = 0;
  a.vy = 0;
  a.moving = false;
}
function resetLeg(L) {
  L.path = [];
  L.goal = null;
  L.chat = null;
  L.attend = 0;
  L.wait = 0;
  L.dawdled = false;
  L.carry = false;
}
function settle(w, a) {
  const L = a.life, plan = planAt(w, a), want = desiredArea(w, a, plan);
  resetLeg(L);
  L.plan = plan.key;
  L.act = plan.act;
  L.visit = Math.floor((w.day - plan.startDay) * DAY_SECONDS / 14) + Math.floor(H(w, a.id, 9) * 7);
  if (plan.trip) {
    if ((w.day - plan.startDay) * DAY_SECONDS < tripLead(w, a, plan)) {
      const town = getArea(w, a.person.origin), door = spotById(town, FOLK_INTERIORS[plan.trip.shop].door);
      const f = door ? nearestFree(town, door.x + (H(w, a.id, 18) - 0.5) * 44, door.y + 16 + H(w, a.id, 19) * 14, [], [8, 4]) : null;
      moveTo(w, a, town.id, f?.x ?? a.x, f?.y ?? a.y);
      L.state = "idle";
      L.spot = null;
      L.pose = "stand";
      L.step = -1;
      L.beat = 0;
      return;
    }
    L.step = shopStepAt(plan, w.day).index;
    L.beat = Math.floor(H(w, a.id, 20) * 5);
  }
  if (want !== a.area) {
    const area2 = getArea(w, want);
    const g2 = nextGoal(w, a, area2, plan);
    moveTo(w, a, want, g2?.x ?? area2.start.x, g2?.y ?? area2.start.y);
  }
  const area = getArea(w, a.area);
  const g = nextGoal(w, a, area, plan);
  L.spot = g?.spot ?? null;
  if ((plan.act === "sleep" || plan.act === "indoors") && indoorsAtHome(w, a)) {
    if (g) {
      a.x = g.x;
      a.y = g.y;
      L.state = "indoors";
      L.pose = "stand";
      return;
    }
  }
  if (!g) {
    L.state = "idle";
    return;
  }
  const since = (w.day - plan.startDay) * DAY_SECONDS, prev = planAt(w, a, plan.startDay - 5e-4);
  const travel2 = Math.hypot(g.x - a.x, g.y - a.y) / speedOf(a);
  if (since < travel2 && plan.key !== "duty" && desiredArea(w, a, prev) === a.area) {
    const pg = nextGoal(w, a, area, prev);
    if (pg) {
      const f = Math.max(0, since / Math.max(travel2, 1e-3));
      const x = pg.x + (g.x - pg.x) * f, y = pg.y + (g.y - pg.y) * f, at = nearestFree(area, x, y, [], [8, 4]) ?? pg;
      a.x = at.x;
      a.y = at.y;
      L.state = "idle";
      L.spot = null;
      L.pose = "stand";
      return;
    }
  }
  a.x = g.x;
  a.y = g.y;
  a.facing = g.facing;
  L.goal = g;
  L.state = "do";
  const s = stopFor(w, a, plan);
  L.pose = s.pose;
  L.wait = s.wait * (0.3 + H(w, a.id, 13) * 0.7);
  aimSideOn(w, a);
}
function speedOf(a) {
  const arch = archetypeOf(a), night = a.life.act === "patrol" ? 0.85 : 1;
  return arch.speed * dial(a.person, "speed") * night * (a.life.act === "errand" ? 1.15 : 1);
}
function tickPerson(w, a, dt) {
  const L = a.life, area = getArea(w, a.area), plan = planAt(w, a), want = desiredArea(w, a, plan);
  L.glance = Math.max(0, L.glance - dt);
  L.cool = Math.max(0, L.cool - dt);
  L.chatCool = Math.max(0, L.chatCool - dt);
  if (L.duty && L.duty.until <= w.day) L.duty = null;
  if (L.glance <= 0) L.head = null;
  a.moving = false;
  if (L.plan !== plan.key) {
    const wasIndoors = L.state === "indoors";
    if (L.chat) endChat(w, a);
    L.plan = plan.key;
    L.act = plan.act;
    resetLeg(L);
    L.step = -1;
    L.beat = 0;
    if (wasIndoors) {
      if ((plan.act === "sleep" || plan.act === "indoors") && want === a.area) {
        L.state = "indoors";
        return;
      }
      const home = homeSpot(w, a);
      if (home && a.area === a.person.origin) {
        a.x = home.x;
        a.y = home.y + 4;
        a.facing = "down";
      }
    }
    L.state = "idle";
    L.spot = null;
  }
  if (L.state === "indoors") return;
  if (L.attend > 0) {
    L.attend -= dt;
    const pl = player(w);
    faceToward(a, pl.x, pl.y);
    if (!rooted(L)) L.pose = L.attend > 0.6 ? "chat" : "stand";
    if (L.attend <= 0) L.state = L.goal ? "do" : "idle";
    return;
  }
  if (L.chat) {
    tickChat(w, a, dt);
    noticeGolem(w, a, area);
    makeWay(w, a, area, dt);
    return;
  }
  if (plan.trip && a.area === want) {
    const st = shopStepAt(plan, w.day);
    if (st.index !== L.step) {
      L.step = st.index;
      L.beat = 0;
      if (L.state !== "aside") {
        L.state = "idle";
        L.spot = null;
        L.path = [];
      }
    }
  }
  if (want !== a.area) {
    const ways = area.base.portals ?? [];
    const door = ways.find((p) => p.to.area === want) ?? (a.area !== a.person.origin ? ways.find((p) => p.to.area === a.person.origin) : void 0);
    if (!door) {
      moveTo(w, a, want, a.x, a.y);
      settle(w, a);
      return;
    }
    const gx = door.x + door.w / 2, gy = door.y + door.h - 1;
    if (!L.goal || L.goal.x !== gx || L.goal.y !== gy) {
      L.goal = { x: gx, y: gy, facing: door.dir };
      L.spot = null;
      L.path = [];
      L.state = "walk";
    }
    const r = walk(w, a, area, dt);
    if (r === "stuck") {
      const f = nearestFree(area, a.x + (roll(w, a) - 0.5) * 28, a.y + (roll(w, a) - 0.5) * 28, [], [8, 4]);
      if (f) {
        a.x = f.x;
        a.y = f.y;
      }
    }
    if (r === "arrived" || Math.hypot(a.x - gx, a.y - gy) < 6) {
      const out = getArea(w, door.to.area), op = (out.base.portals ?? []).find((p) => p.id === door.to.portal);
      const at = op ? portalArrival(op) : { x: out.start.x, y: out.start.y, facing: "down" };
      moveTo(w, a, out.id, at.x, at.y);
      a.facing = at.facing;
      resetLeg(L);
      L.spot = null;
      L.state = "idle";
      L.seen = w.time;
    }
    return;
  }
  switch (L.state) {
    case "idle": {
      const g = nextGoal(w, a, area, plan);
      if (!g && plan.act === "shop") L.spot = null;
      if (!g) {
        L.state = "do";
        const s = stopFor(w, a, plan);
        L.pose = s.pose === "lie" ? "stand" : s.pose;
        L.wait = s.wait;
        aimSideOn(w, a);
        break;
      }
      L.goal = g;
      L.spot = g.spot;
      L.path = [];
      L.state = "walk";
      L.dawdled = false;
      break;
    }
    case "walk": {
      const r = walk(w, a, area, dt);
      if (r === "arrived") arrive(w, a, plan);
      else if (r === "stuck") {
        L.visit++;
        L.state = "do";
        L.pose = "stand";
        L.wait = 1.5;
        L.goal = null;
        L.spot = null;
      }
      break;
    }
    case "aside": {
      const r = walk(w, a, area, dt);
      if (r !== "moving") {
        L.state = L.goal ? "do" : "idle";
        L.wait = Math.max(L.wait, 1.2);
        L.pose = "stand";
        L.path = [];
      }
      break;
    }
    case "do": {
      L.wait -= dt;
      fidget(w, a, plan, dt);
      if (L.wait <= 0) {
        if (L.goal && Math.hypot(L.goal.x - a.x, L.goal.y - a.y) > 3) {
          L.state = "idle";
          break;
        }
        if (plan.act === "work" && L.spot?.startsWith("work.haul")) {
          L.carry = !L.carry;
          L.visit++;
          L.state = "idle";
        } else if (plan.act === "lamps" && L.spot?.startsWith("lamp:")) {
          const hour = wrapHour((w.day - Math.floor(w.day)) * 24), lamp = lampRound(a, area, hour).find((l) => `lamp:${l.id}` === L.spot);
          if (lamp && lamp.at > hour + 0.01) {
            L.wait = 0.4;
            break;
          }
          L.state = "idle";
          L.visit++;
        } else if (plan.act === "shop") shopBeat(w, a, area, plan);
        else if (ROVING[plan.act] || plan.key === "duty") {
          L.visit++;
          L.state = "idle";
        } else if (plan.at && !L.spot) {
          L.visit++;
          L.state = "idle";
        } else {
          const s = stopFor(w, a, plan);
          L.pose = s.pose;
          L.wait = s.wait;
          L.visit++;
          if (plan.act !== "sleep" && roll(w, a) < 0.25) L.state = "idle";
        }
      }
      break;
    }
  }
  noticeGolem(w, a, area);
  if (L.state === "do" || L.state === "walk" && (plan.act === "wander" || plan.act === "errand")) seekChat(w, a, plan);
  makeWay(w, a, area, dt);
}
function arrive(w, a, plan) {
  const L = a.life, g = L.goal;
  a.facing = g.facing;
  if ((plan.act === "sleep" || plan.act === "indoors") && a.area === a.person.origin && indoorsAtHome(w, a)) {
    L.state = "indoors";
    L.pose = "stand";
    L.carry = false;
    return;
  }
  const s = stopFor(w, a, plan);
  L.state = "do";
  L.pose = s.pose;
  L.wait = s.wait;
  if (plan.act === "hunt") a.facing = roll(w, a) < 0.5 ? "left" : "right";
}
function fidget(w, a, plan, dt) {
  const L = a.life;
  if (L.glance > 0) return;
  const quiet = L.pose === "stand" || L.pose === "lean" || L.pose === "sit" || L.pose === "warm";
  if (!quiet) return;
  const tick = Math.floor((w.time + H(w, a.id, 21) * 9) / 3.2);
  if (Math.floor((w.time - dt + H(w, a.id, 21) * 9) / 3.2) !== tick) {
    const r = H(w, a.id, 4e3 + tick);
    L.head = r < 0.3 ? turn(a.facing, 1) : r < 0.6 ? turn(a.facing, -1) : null;
    if (L.head) L.glance = 0.8 + r * 1.6;
    const quirk = traitsOf(a.person).find((t) => t.quirk)?.quirk;
    if (L.pose === "stand" && quirk === "stretch" && r > 0.92) {
      L.pose = "stretch";
      L.wait = Math.max(L.wait, 1.4);
    }
    if (plan.act === "gather" && r > 0.55) L.pose = L.pose === "stand" ? "drink" : "stand";
  }
}
function walk(w, a, area, dt) {
  const L = a.life, g = L.goal;
  if (!g) return "arrived";
  if (Math.hypot(g.x - a.x, g.y - a.y) < 1.5) {
    a.x = g.x;
    a.y = g.y;
    return "arrived";
  }
  const grid = navGrid(area, a);
  if (!L.path.length) {
    let raw = findPath(w, a, { x: g.x, y: g.y, range: 2 }, false);
    if (!raw) return "stuck";
    if (L.act === "shop" || L.act === "tavern") raw = roundTheCounter(w, a, area, g, raw) ?? raw;
    L.path = smooth({ x: a.x, y: a.y }, [...raw, { x: g.x, y: g.y }], grid.free);
  }
  let speed = speedOf(a);
  if (!L.dawdled && L.state === "walk" && L.path.length > 3) {
    L.dawdled = true;
    if (roll(w, a) < 0.12 * dial(a.person, "dawdle") && L.act !== "lamps") {
      L.state = "do";
      L.pose = "stand";
      L.wait = 1.5 + roll(w, a) * 2.5;
      L.goal = g;
      resumeAfter(L);
      return "moving";
    }
  }
  const remaining = L.path.reduce((s, p, i) => s + Math.hypot(p.x - (i ? L.path[i - 1].x : a.x), p.y - (i ? L.path[i - 1].y : a.y)), 0);
  if (remaining < 10) speed *= 0.55 + remaining / 22;
  if (L.act === "hunt" && remaining < 36) speed *= 0.5;
  let budget = speed * dt;
  const start = { x: a.x, y: a.y };
  const avoid = obstacles(w, a);
  while (L.path.length && budget > 0.01) {
    const p = L.path[0], dx = p.x - a.x, dy = p.y - a.y, d = Math.hypot(dx, dy);
    if (d < 0.5) {
      L.path.shift();
      continue;
    }
    let ux = dx / d, uy = dy / d;
    for (const o of avoid) {
      const ox = o.x - a.x, oy = o.y - a.y, ahead = ox * ux + oy * uy, side = ox * -uy + oy * ux;
      if (ahead > 0 && ahead < o.r + 10 && Math.abs(side) < o.r) {
        const k = side > 0 ? -1 : 1, nx2 = ux + -uy * k * 0.9, ny2 = uy + ux * k * 0.9, n = Math.hypot(nx2, ny2);
        if (grid.free(a.x + nx2 / n * 3, a.y + ny2 / n * 3)) {
          ux = nx2 / n;
          uy = ny2 / n;
        }
      }
    }
    const step = Math.min(d, budget, 2), nx = a.x + ux * step, ny = a.y + uy * step;
    if (grid.free(nx, ny)) {
      a.x = nx;
      a.y = ny;
    } else {
      const sx = a.x + dx / d * step, sy = a.y + dy / d * step;
      if (grid.free(sx, sy) || !grid.free(a.x, a.y)) {
        a.x = sx;
        a.y = sy;
      } else if (Math.abs(dx) > 0.2 && grid.free(a.x + Math.sign(dx) * step, a.y)) a.x += Math.sign(dx) * step;
      else if (Math.abs(dy) > 0.2 && grid.free(a.x, a.y + Math.sign(dy) * step)) a.y += Math.sign(dy) * step;
      else {
        L.path = [];
        break;
      }
    }
    budget -= step;
    if (Math.hypot(p.x - a.x, p.y - a.y) < 1) L.path.shift();
    a.facing = faceTo2(dx, dy);
  }
  const moved = Math.hypot(a.x - start.x, a.y - start.y);
  if (moved > 1e-3) {
    a.moving = true;
    a.vx = (a.x - start.x) / dt;
    a.vy = (a.y - start.y) / dt;
    L.phase += moved * 0.26;
    L.pose = "walk";
    L.stall = 0;
  } else if ((L.stall = (L.stall ?? 0) + dt) > 2) {
    L.stall = 0;
    L.path = [];
    return "stuck";
  }
  if (!L.path.length) {
    if (Math.hypot(g.x - a.x, g.y - a.y) < 3) {
      a.x = g.x;
      a.y = g.y;
      return "arrived";
    }
    return "moving";
  }
  return "moving";
}
function roundTheCounter(w, a, area, g, raw) {
  const k = spotById(area, "keeper"), via = spotById(area, "queue.2");
  if (!k || !via) return null;
  const behind = (p) => Math.abs(p.x - k.x) < 44 && p.y < k.y + 6 && p.y > k.y - 30;
  if (behind(a) || behind(g) || !raw.some(behind)) return null;
  const first = findPath(w, a, { x: via.x, y: via.y, range: 2 }, false);
  if (!first || first.some(behind)) return null;
  const at = { x: a.x, y: a.y };
  a.x = via.x;
  a.y = via.y;
  const second = findPath(w, a, { x: g.x, y: g.y, range: 2 }, false);
  a.x = at.x;
  a.y = at.y;
  if (!second || second.some(behind)) return null;
  return [...first, { x: via.x, y: via.y }, ...second];
}
function resumeAfter(L) {
  L.spot = L.spot;
  L.visit--;
}
function smooth(from, pts, free) {
  const out = [];
  let cur = from, i = 0;
  while (i < pts.length) {
    let j = Math.min(pts.length - 1, i + 8);
    while (j > i && !sweptFree(cur, pts[j], free)) j--;
    out.push(pts[j]);
    cur = pts[j];
    i = j + 1;
  }
  return out;
}
function obstacles(w, a) {
  const out = [];
  for (const b of w.actors) {
    if (b === a || b.area !== a.area) continue;
    if (isFolk(b)) {
      if (b.life.state !== "indoors" && Math.hypot(b.x - a.x, b.y - a.y) < 30) out.push({ x: b.x, y: b.y, r: 6 });
    } else if (Math.hypot(b.x - a.x, b.y - a.y) < 50) out.push({ x: b.x, y: b.y - 2, r: 13 });
  }
  return out;
}
function makeWay(w, a, area, dt) {
  const L = a.life;
  if (L.state === "walk" || L.state === "aside" || L.pose === "lie" || L.pose === "sit") return;
  for (const b of w.actors) {
    if (b === a || b.area !== a.area || isFolk(b)) continue;
    const dx = a.x - b.x, dy = a.y - b.y, d = Math.hypot(dx, dy), v = Math.hypot(b.vx, b.vy);
    if (d > 16 || v < 6 || dx * b.vx + dy * b.vy <= 0) continue;
    const ux = b.vx / v, uy = b.vy / v, side = dx * -uy + dy * ux >= 0 ? 1 : -1;
    for (const k of [side, -side]) {
      const tx = a.x + -uy * k * 16, ty = a.y + ux * k * 16;
      const f = nearestFree(area, tx, ty, [], [8, 4]);
      if (f && Math.hypot(f.x - b.x - b.vx * 0.3, f.y - b.y - b.vy * 0.3) > 12) {
        if (L.chat) endChat(w, a);
        const keep = L.goal;
        L.path = [{ x: f.x, y: f.y }];
        L.state = "aside";
        L.goal = { x: f.x, y: f.y, facing: faceTo2(b.x - f.x, b.y - f.y) };
        L.spot = keep ? L.spot : null;
        L.head = gazeAt(a.facing, -dx, -dy);
        L.glance = 1.2;
        return;
      }
    }
  }
  void dt;
}
function noticeGolem(w, a, area) {
  const L = a.life, pl = player(w);
  if (pl.area !== a.area || L.pose === "lie") return;
  const n = traitsOf(a.person).find((t) => t.notice)?.notice ?? { range: 52, react: "glance" };
  const range = archetypeOf(a).age === "young" ? Math.max(n.range, 80) : n.range;
  const dx = pl.x - a.x, dy = pl.y - a.y, d = Math.hypot(dx, dy);
  if (d > range) return;
  if (L.glance > 0) {
    L.head = gazeAt(a.facing, dx, dy);
    return;
  }
  if (L.cool > 0 || L.state === "aside") return;
  const r = roll(w, a);
  L.glance = 1.4 + r * 2;
  L.cool = 7 + r * 10;
  L.head = gazeAt(a.facing, dx, dy);
  if (L.state !== "do" && L.state !== "idle") return;
  const quirk = traitsOf(a.person).find((t) => t.quirk)?.quirk;
  if (L.pose === "stand" || L.pose === "lean" || L.pose === "browse") {
    a.facing = faceTo2(dx, dy);
    L.head = null;
    if ((quirk === "wave" || archetypeOf(a).age === "young") && d < 70 && r < 0.6) {
      L.pose = "wave";
      L.wait = Math.max(L.wait, 1.6);
    }
  }
  if (n.react === "wary" && d < 34) {
    const f = nearestFree(area, a.x - dx / d * 18, a.y - dy / d * 18, [], [8, 4]);
    if (f) {
      L.path = [f];
      L.goal = { x: f.x, y: f.y, facing: faceTo2(dx, dy) };
      L.state = "aside";
    }
  } else if (n.react === "approach" && d > 30 && (L.act === "wander" || L.act === "socialize" || L.act === "camp") && L.state === "do") {
    const f = nearestFree(area, pl.x - dx / d * 26, pl.y - dy / d * 26, [], [8, 4]);
    if (f) {
      L.path = [f];
      L.goal = { x: f.x, y: f.y, facing: faceTo2(dx, dy) };
      L.state = "aside";
      L.wait = 3;
    }
  }
}
function seekChat(w, a, plan) {
  const L = a.life;
  if (!SOCIAL[plan.act] || L.chatCool > 0 || L.chat || L.pose === "lie") return;
  for (const b of w.actors) {
    if (b === a || b.area !== a.area || !isFolk(b)) continue;
    const M = b.life;
    if (M.chat || M.state === "indoors" || M.chatCool > 0 || M.attend > 0 || M.pose === "lie" || !SOCIAL[M.act]) continue;
    if (M.state !== "do" && !(M.state === "walk" && (M.act === "wander" || M.act === "errand"))) continue;
    if (inLine(L) || inLine(M)) continue;
    const d = Math.hypot(b.x - a.x, b.y - a.y);
    if (d > (L.state === "walk" ? 22 : 36)) continue;
    const p = 0.35 * dial(a.person, "chatty") * dial(b.person, "chatty");
    if (roll(w, a) > p) {
      L.chatCool = 3 + roll(w, a) * 4;
      return;
    }
    const ex = pickExchange(w, a, b, talkContext(a, b));
    const len = ex ? 90 : (4 + roll(w, a) * 6) * Math.sqrt(dial(a.person, "chatty") * dial(b.person, "chatty"));
    for (const [x, y, sp] of [[a, b, true], [b, a, false]]) {
      const X2 = x.life;
      if (X2.state === "walk") {
        X2.state = "do";
        X2.wait = ex ? 0.8 : len + 1;
        X2.visit--;
      }
      X2.chat = { with: y.id, t: len, turn: ex ? 0.4 : 0.4 + (sp ? 0 : 1.2), speaker: sp, ex: ex?.id, i: 0, lead: sp, pose: null };
      faceToward(x, y.x, y.y);
      if (X2.pose === "walk" || X2.pose === "browse") X2.pose = "stand";
    }
    return;
  }
}
function tickChat(w, a, dt) {
  const L = a.life, c = L.chat, b = actorById(w, c.with);
  if (!b || b.area !== a.area || (b.keeper ? b.keeper.with !== a.id : !b.life?.chat)) {
    endChat(w, a);
    return;
  }
  c.t -= dt;
  c.turn -= dt;
  faceToward(a, b.x, b.y);
  if (c.ex) {
    if (c.lead && c.turn <= 0) nextLine(w, a, b);
    if (!L.chat) return;
  } else if (c.turn <= 0) {
    c.speaker = !c.speaker;
    c.turn = 1.3 + roll(w, a) * 1.2;
    if (c.speaker) {
      const topics = archetypeOf(a).topics, mood = traitsOf(a.person).find((t) => t.quirk === "whistle" || t.quirk === "sigh");
      const icon = roll(w, a) < 0.2 ? mood?.quirk === "sigh" ? "ask" : "laugh" : topics[Math.floor(roll(w, a) * topics.length)];
      emit(w, { t: "folkChat", folk: a.id, icon });
    }
  }
  const sitting = rooted(L);
  if (!sitting && L.pose !== "drink") L.pose = !c.speaker ? "stand" : c.pose && c.pose !== "chat" ? c.pose : c.turn > 0.5 ? "chat" : "stand";
  if (c.t <= 0) endChat(w, a);
}
function endChat(w, a) {
  const L = a.life, c = L.chat, b = c ? actorById(w, c.with) : void 0;
  if (c?.ex) {
    L.lastEx = c.ex;
    if (b?.life) b.life.lastEx = c.ex;
    if (b?.keeper) b.keeper.lastEx = c.ex;
  }
  L.chat = null;
  L.chatCool = 10 + roll(w, a) * 14;
  if (c && TALK_POSES.includes(L.pose)) L.pose = "stand";
  if (b?.life?.chat?.with === a.id) {
    b.life.chat = null;
    b.life.chatCool = 10 + roll(w, b) * 14;
    if (TALK_POSES.includes(b.life.pose)) b.life.pose = "stand";
  }
}
var TALK_POSES = ["chat", "pay", "point", "nod", "shake"];
var sayTime = (line) => 1.4 + line.length * 0.055;
var TURN_GAP = 0.3;
function talkContext(a, b) {
  const A = a.life, B2 = b.life;
  if (A.spot?.startsWith(BOARD.spots) || B2.spot?.startsWith(BOARD.spots)) return "board";
  if (a.area === FOLK_INTERIORS.tavern.area || A.act === "gather" || A.act === "tavern") return "ale";
  if (a.area !== a.person.origin) return "shop";
  if (archetypeOf(a).habitat === "forest") return "camp";
  if (archetypeOf(a).garb === "watch" || archetypeOf(b).garb === "watch") return "watch";
  if (A.state === "walk" || B2.state === "walk") return "pass";
  if (A.spot?.includes("well") || B2.spot?.includes("well")) return "well";
  return "meet";
}
var whoFits = (who, x) => {
  if (!who) return true;
  const arch = x.person?.archetype, traits = x.person?.traits ?? [];
  if (who.arch && !(arch && who.arch.includes(arch))) return false;
  if (who.trait && !who.trait.some((t) => traits.includes(t))) return false;
  return !who.not?.some((t) => t === arch || traits.includes(t));
};
function pickExchange(w, a, b, ctx, maxLines = 99) {
  const last = [a.life?.lastEx, b.life?.lastEx, b.keeper?.lastEx];
  const chatty = Math.min(2, Math.max(0.5, Math.sqrt(dial(a.person, "chatty") * (b.person ? dial(b.person, "chatty") : 1))));
  for (const c of ctx === "meet" || ctx.startsWith("deal.") ? [ctx] : [ctx, "meet"]) {
    const rows = EXCHANGES.filter((e) => e.ctx.includes(c) && e.lines.length <= maxLines && whoFits(e.a, a) && whoFits(e.b, b) && !last.includes(e.id));
    const weight = (e) => (e.weight ?? 1) * (e.lines.length > 2 ? chatty : 1 / chatty);
    let k = roll(w, a) * rows.reduce((s, e) => s + weight(e), 0);
    for (const e of rows) {
      k -= weight(e);
      if (k < 0) return e;
    }
    if (rows.length) return rows[rows.length - 1];
  }
  return null;
}
function fromPool(w, sp, pool) {
  const L = sp.life;
  if (!L || !pool.length) return pool[0] ?? "...";
  let i = Math.floor(roll(w, sp) * pool.length);
  if (pool[i] === L.lastSay) i = (i + 1) % pool.length;
  L.lastSay = pool[i];
  return pool[i];
}
function sayLine(w, sp, to, raw, a, b) {
  const given = (x) => (x.person?.name ?? x.keeper?.name ?? "FRIEND").split(" ")[0];
  const traits = sp.person?.traits ?? [];
  let s = raw;
  if (raw === "@say") s = fromPool(w, sp, sp.person ? peerLines(sp.person.archetype, traits, sp.life?.act) : []);
  else if (raw === "@re") s = fromPool(w, sp, REACTIONS[traits.find((t) => REACTIONS[t]) ?? "DEFAULT"]);
  else if (raw === "@gripe") s = fromPool(w, sp, GRIPES);
  else if (raw === "@news") s = fromPool(w, sp, NEWS);
  return s.replace("{a}", given(a)).replace("{b}", given(b)).replace("{you}", given(to)).replace("{hail}", hail(hourOf(w.day)));
}
function nextLine(w, a, b) {
  const c = a.life.chat, ex = EXCHANGE_BY_ID[c.ex], ln = ex?.lines[c.i ?? 0];
  if (!ln) {
    endChat(w, a);
    return;
  }
  const sp = ln[0] === "a" ? a : b, to = sp === a ? b : a, text2 = sayLine(w, sp, to, ln[1], a, b), pose = ln[2] ?? null;
  c.i = (c.i ?? 0) + 1;
  c.turn = sayTime(text2) + TURN_GAP;
  c.speaker = sp === a;
  c.pose = sp === a ? pose : null;
  const bc = b.life?.chat;
  if (bc) {
    bc.speaker = sp === b;
    bc.pose = sp === b ? pose : null;
    bc.turn = c.turn;
  }
  if (sp.life) {
    const topics = archetypeOf(sp).topics, mood = traitsOf(sp.person).find((t) => t.quirk === "whistle" || t.quirk === "sigh");
    const icon = pose === "pay" ? "coin" : roll(w, sp) < 0.2 ? mood?.quirk === "sigh" ? "ask" : "laugh" : topics[Math.floor(roll(w, sp) * topics.length)];
    emit(w, { t: "folkChat", folk: sp.id, icon });
  }
  emit(w, { t: "folkSay", folk: sp.id, to: to.id, line: text2 });
}
function mutter(w, a, pool, chance = 0.2) {
  const L = a.life, lines = MUTTERS[pool];
  if (!lines || L.chatCool > 0 || L.chat) return;
  if (roll(w, a) > chance * Math.min(1.5, dial(a.person, "chatty"))) return;
  const line = lines[Math.floor(roll(w, a) * lines.length)];
  if (line === L.lastSay) return;
  L.lastSay = line;
  L.chatCool = 8 + roll(w, a) * 8;
  emit(w, { t: "folkSay", folk: a.id, line });
}
var COUNTER_LINE = ["customer", "queue.1", "queue.2"];
var VISIT_KINDS = ["browse", "idle", "seat"];
var inLine = (L) => L.act === "shop" && !!L.spot && COUNTER_LINE.includes(L.spot);
function moodPose(a, pose) {
  const t = a.person.traits;
  return pose === "nod" && t.includes("grumpy") ? "shake" : pose === "shake" && t.includes("cheerful") ? "nod" : pose;
}
function shopGoal(w, a, area, plan) {
  const L = a.life;
  if (!plan.trip || area.id !== FOLK_INTERIORS[plan.trip.shop].area) return null;
  const st = shopStepAt(plan, w.day), spots = area.base.spots ?? [], held = claimed(w, a, area.id);
  const done = !!st.step.deal && L.dealt === plan.key;
  let s;
  if (st.step.at[0] === "counter" && !done) {
    for (const id of COUNTER_LINE) {
      const q = spots.find((x) => x.id === id);
      if (q && (id === L.spot || !held.has(id))) {
        s = q;
        break;
      }
    }
  } else {
    const want = done ? st.step.after ?? ["browse", "idle."] : st.step.at;
    const fits = (x) => VISIT_KINDS.includes(x.kind) && want.some((p) => x.id.startsWith(p));
    const own = L.spot ? spots.find((x) => x.id === L.spot) : void 0;
    if (own && fits(own)) s = own;
    else {
      const list = spots.filter((x) => fits(x) && !held.has(x.id));
      const salt = 7e3 + plan.day % 1e3 * 17 + plan.trip.n * 31 + st.index * 7 + (done ? 3 : 0);
      if (list.length) s = list[Math.floor(H(w, a.id, salt) * list.length)];
    }
  }
  if (!s) return null;
  const f = nearestFree(area, s.x, s.y, [], [8, 4]) ?? s;
  return { x: f.x, y: f.y, facing: s.facing, spot: s.id };
}
function shopStop(w, a, plan, r) {
  const L = a.life;
  if (!plan.trip || !L.spot || a.area !== FOLK_INTERIORS[plan.trip.shop].area) return { pose: "stand", wait: 1.5 + r * 1.5 };
  if (COUNTER_LINE.includes(L.spot)) return { pose: "stand", wait: 1 + r * 0.8 };
  if (L.spot.startsWith("seat")) return { pose: "sit", wait: 6 + r * 6 };
  const st = shopStepAt(plan, w.day);
  const poses = st.step.deal && L.dealt === plan.key ? ["stand", "browse", "nod", "browse"] : st.step.poses;
  const pose = moodPose(a, poses[(L.beat ?? 0) % poses.length]);
  return { pose, wait: pose === "nod" || pose === "shake" ? 1.5 : pose === "point" ? 1.9 : 2.6 + r * 2.2 };
}
function shopBeat(w, a, area, plan) {
  const L = a.life;
  L.beat = (L.beat ?? 0) + 1;
  if (!plan.trip || !L.spot) {
    L.state = "idle";
    return;
  }
  const st = shopStepAt(plan, w.day);
  if (L.spot.startsWith("queue.")) {
    if (a.person.traits.includes("grumpy")) mutter(w, a, "queue", 0.3);
    L.state = "idle";
    return;
  }
  if (L.spot === "customer") {
    if (st.step.deal && L.dealt !== plan.key) {
      const k = keeperOf(w, area.id);
      if (k && keeperReady(k)) {
        L.dealt = plan.key;
        const ex = pickExchange(w, a, k, `deal.${st.step.deal}`, Math.floor((plan.endDay - w.day) * DAY_SECONDS / 2.9));
        if (ex) {
          L.chat = { with: k.id, t: 90, turn: 0.5, speaker: false, ex: ex.id, i: 0, lead: true, pose: null };
          keeperServe(k, a.id);
          a.facing = "up";
          L.pose = "stand";
          L.wait = 0.4;
          return;
        }
      } else {
        L.pose = "stand";
        L.wait = 1;
        return;
      }
    }
    L.spot = null;
    L.state = "idle";
    return;
  }
  const s = shopStop(w, a, plan, roll(w, a)), here = spotById(area, L.spot);
  L.pose = s.pose;
  L.wait = s.wait;
  if (here && L.glance <= 0 && !rooted(L)) a.facing = here.facing;
  if (st.step.mutter && s.pose !== "sit") mutter(w, a, st.step.mutter);
}
function folkTalk(w, by, targetId) {
  const a = targetId ? actorById(w, targetId) : void 0;
  if (!a || !isFolk(a) || a.area !== by.area || !folkPresent(a)) return;
  const L = a.life;
  if (L.chat) endChat(w, a);
  const arch = archetypeOf(a);
  const pool = [...arch.lines, ...traitsOf(a.person).flatMap((t) => t.lines ?? []), ...ACTIVITY_LINES[L.act] ?? []];
  const line = pool[Math.floor(H(w, a.id, 5e3 + L.talks++) * pool.length)];
  L.attend = 3.6;
  L.glance = 0;
  L.cool = 12;
  emit(w, { t: "talkedTo", actor: by.id, npc: a.id });
  emit(w, { t: "folkSpoke", actor: by.id, folk: a.id, line });
}
function faceTo2(dx, dy) {
  return Math.abs(dx) > Math.abs(dy) ? dx > 0 ? "right" : "left" : dy > 0 ? "down" : "up";
}
var ROT = ["up", "right", "down", "left"];
var turn = (f, k) => ROT[(ROT.indexOf(f) + k + 4) % 4];
var STEP = { up: [0, -1], right: [1, 0], down: [0, 1], left: [-1, 0] };
function naturalHead(facing, head) {
  return !head || head === facing || head === turn(facing, 2) ? null : head;
}
function gazeAt(facing, dx, dy) {
  const want = faceTo2(dx, dy);
  if (want !== turn(facing, 2)) return naturalHead(facing, want);
  const side = turn(facing, 1), [sx, sy] = STEP[side];
  return dx * sx + dy * sy >= 0 ? side : turn(facing, -1);
}
var rooted = (L) => L.pose === "sit" || L.pose === "warm" || L.pose === "lie";
function faceToward(a, x, y) {
  const L = a.life;
  if (rooted(L)) L.head = gazeAt(a.facing, x - a.x, y - a.y);
  else {
    a.facing = faceTo2(x - a.x, y - a.y);
    L.head = null;
  }
}
function aimSideOn(w, a) {
  if (a.life.pose === "aim" && a.facing !== "left" && a.facing !== "right") a.facing = H(w, a.id, 6e3 + a.life.visit) < 0.5 ? "left" : "right";
}

// src/game/world/world.ts
function createWorld(seed) {
  const w = {
    seed,
    rng: new SeededRng(seed),
    time: 0,
    playTime: 0,
    day: START_HOUR / 24,
    flags: /* @__PURE__ */ new Set(),
    areas: /* @__PURE__ */ new Map(),
    actors: [],
    playerId: "golem",
    scheduled: [],
    monologue: { said: [], ready: {} },
    events: [],
    tick: 0,
    specs: {},
    lod: {}
  };
  const dungeon = getArea(w, "dungeon");
  w.actors.unshift(makeActor("golem", "golem", dungeon.id, dungeon.start.x, dungeon.start.y));
  return w;
}
function makeActor(id, kind, area, x, y) {
  return {
    id,
    kind,
    definition: ACTORS[kind] ? kind : "golem",
    area,
    x,
    y,
    vx: 0,
    vy: 0,
    facing: "down",
    phase: 0,
    moving: false,
    steps: 0,
    task: null,
    queue: [],
    inventory: [],
    gear: {},
    upgrades: [],
    powerCore: null,
    mode: "normal",
    job: null,
    jobSeq: 0
  };
}
function makeNpc(s, area) {
  const a = makeActor(s.id, NPCS[s.npc]?.actor ?? s.npc, area, s.x, s.y);
  a.kind = "npc";
  a.npc = s.npc;
  if (s.facing) a.facing = s.facing;
  return a;
}
function getArea(w, id) {
  let a = w.areas.get(id);
  if (!a) {
    const build = builderFor(id, w.specs);
    if (!build) throw new Error(`unknown area "${id}"`);
    a = new Area(build());
    a.lastTicked = w.time;
    if (a.base.ritual) a.initRitual(shuffle(w.rng, [0, 1, 2, 3]));
    w.areas.set(id, a);
    for (const s of a.base.npcs ?? []) if (!actorById(w, s.id)) w.actors.push(makeNpc(s, id));
    populateFolk(w, id);
    populateKeepers(w, id);
  }
  return a;
}
var player = (w) => w.actors.find((a) => a.id === w.playerId);
var actorById = (w, id) => w.actors.find((a) => a.id === id);
var areaOf = (w, a) => getArea(w, a.area);
function enterArea(w, a, areaId, x, y) {
  getArea(w, areaId);
  a.area = areaId;
  a.x = x;
  a.y = y;
  a.vx = 0;
  a.vy = 0;
  a.task = null;
  a.queue = a.queue.filter((t) => !t.area || t.area === areaId);
  if (a.job) a.job.nav = null;
  emit(w, { t: "areaEntered", actor: a.id, area: areaId });
}
var emit = (w, e) => {
  w.events.push(e);
};
var isBodyFlag = (f) => f === "golem.arm" || f.startsWith("golem.slot.");
var actorHasFlag = (a, f) => a.upgrades.includes(f);
function setActorFlag(a, f, on = true) {
  if (on && !a.upgrades.includes(f)) a.upgrades.push(f);
  if (!on) a.upgrades = a.upgrades.filter((x) => x !== f);
}
var hasFlag = (w, f) => isBodyFlag(f) ? !!player(w)?.upgrades.includes(f) : w.flags.has(f);
var setFlag = (w, f) => {
  if (isBodyFlag(f)) setActorFlag(player(w), f);
  else w.flags.add(f);
};
var clearFlag = (w, f) => {
  if (isBodyFlag(f)) setActorFlag(player(w), f, false);
  else w.flags.delete(f);
};
function shuffle(rng, perm) {
  for (let i = perm.length - 1; i > 0; i--) {
    const j = Math.floor(rng.next() * (i + 1));
    [perm[i], perm[j]] = [perm[j], perm[i]];
  }
  return perm;
}

// src/game/content/crafting.ts
var STATIONS = {
  crafting: {
    name: "CRAFTING BENCH",
    prop: "workbench",
    verb: "CRAFT",
    requires: { flags: [FLAGS.knowBuild] },
    lockedText: "YOU DON'T KNOW HOW TO CRAFT YET",
    lockedHint: "FIND OUT HOW TO BUILD.",
    accent: "#e8d8a8"
  },
  // Smelting is read off a smelter with golem vision (content/build.ts: the SMELTER row `teaches` it), not out of a book.
  smelting: {
    name: "SMELTER",
    prop: "forge",
    verb: "SMELT",
    requires: { flags: [FLAGS.knowSmelt] },
    lockedText: "YOU DON'T KNOW HOW TO SMELT YET",
    lockedHint: "STUDY A SMELTER: Z, THEN E.",
    accent: "#ffa860"
  },
  smithing: {
    name: "ANVIL",
    prop: "anvil",
    verb: "FORGE",
    requires: { flags: [FLAGS.knowBuild] },
    lockedText: "YOU DON'T KNOW HOW TO SMITH YET",
    lockedHint: "FIND OUT HOW TO BUILD.",
    accent: "#a8d0f0",
    tabs: [
      { id: "forge", name: "FORGE", verb: "FORGE", empty: ["NOTHING TO FORGE."] },
      { id: "repair", name: "REPAIR", verb: "REPAIR", empty: ["NOTHING TO REPAIR.", "CARRY A RUSTED HEAD."] },
      { id: "modify", name: "MODIFY", verb: "TEMPER", empty: ["NOTHING TO MODIFY.", "CARRY A TOOL OR A HEAD.", "TAKE IT OFF YOUR ARM."] },
      { id: "runes", name: "RUNES", verb: "SET", empty: ["NO HEAD TO SET A RUNE", "IN. IT MUST BE FINE", "(TEMPERED) IRON."] }
    ]
  }
};
var STATION_IDS = Object.keys(STATIONS);
var isStation = (s) => s in STATIONS;
var STATION_REQUIRES = Object.fromEntries(STATION_IDS.map((id) => [id, STATIONS[id].requires]));
var CRAFT_DUR = 1.2;
var CRAFT_RECIPES = [
  {
    id: "planks",
    name: "PLANKS",
    station: "crafting",
    dur: 1,
    desc: ["SAW ROUGH WOOD INTO PLANKS", "FOR TABLES, CHAIRS, BANNERS", "AND OTHER FINER BUILDS."],
    inputs: [{ item: "wood", n: 2 }],
    output: { item: "planks", n: 3 }
  },
  {
    id: "cut_stone",
    name: "CUT STONE",
    station: "crafting",
    dur: 1.4,
    desc: ["SQUARE ROUGH STONE INTO", "BLOCKS. SOME IS LOST IN THE", "CUTTING."],
    inputs: [{ item: "stone", n: 3 }],
    output: { item: "cut_stone", n: 2 }
  },
  {
    id: "rune_swift",
    name: "RUNE OF SWIFT",
    station: "crafting",
    dur: 2.4,
    desc: ["CARVE THE SIGN OF SWIFTNESS", "INTO CUT STONE. NEEDS THE", "RUNE CHISEL IN YOUR PACK."],
    inputs: [{ item: "cut_stone", n: 2 }],
    tools: ["chisel"],
    output: { item: "rune_swift", n: 1 }
  },
  {
    id: "rune_glow",
    name: "RUNE OF GLOW",
    station: "crafting",
    dur: 2.4,
    desc: ["CARVE THE SIGN OF LIGHT", "INTO CUT STONE. NEEDS THE", "RUNE CHISEL IN YOUR PACK."],
    inputs: [{ item: "cut_stone", n: 3 }],
    tools: ["chisel"],
    output: { item: "rune_glow", n: 1 }
  },
  {
    // The crown holds the game's one High-Grade Ruby, so exactly one core can ever be carved.
    id: "ruby_core",
    name: "RUBY GOLEM CORE",
    station: "crafting",
    dur: 2.4,
    desc: ["CARVE THE HIGH-GRADE RUBY", "INTO A GOLEM CORE. NEEDS THE", "RUNE CHISEL IN YOUR PACK."],
    inputs: [{ item: "large_ruby", n: 1 }],
    tools: ["chisel"],
    output: { item: "ruby_core", n: 1 }
  },
  // ---- inverse rows: names stay distinct (and within the list's 20 characters) so each reads on its own.
  {
    id: "unmake_crown",
    mode: "deconstruct",
    name: "UNMAKE BROKEN CROWN",
    station: "crafting",
    dur: 1.6,
    desc: ["PRY THE HIGH-GRADE RUBY OUT", "OF THE BROKEN CROWN. ITS", "SOFT GOLD IS OF NO USE."],
    inputs: [{ item: "crown", n: 1 }],
    output: { item: "large_ruby", n: 1 }
  },
  ...[["rune_swift", "SWIFT"], ["rune_glow", "GLOW"]].map(([item, sign]) => ({
    id: `unmake_${item}`,
    mode: "deconstruct",
    name: `UNMAKE RUNE OF ${sign}`,
    station: "crafting",
    desc: ["GRIND THE SIGN OFF A RUNE OF", `${sign}. ONE ROUGH STONE IS`, "ALL THAT IS LEFT."],
    inputs: [{ item, n: 1 }],
    output: { item: "stone", n: 1 }
  })),
  // ---- the crafting bench: a head on a wooden haft is a full tool, for hands (content/tools.ts)
  ...TOOL_TYPE_IDS.flatMap((t) => [
    {
      id: fullToolId(t),
      name: TOOL_TYPES[t].full,
      station: "crafting",
      dur: 1.2,
      desc: [`FIT A ${TOOL_TYPES[t].name} HEAD TO A WOODEN`, "HAFT: A TOOL FOR HANDS. GIVE", "IT TO A WORKER."],
      inputs: [{ item: headId(t), n: 1 }, { item: "wood", n: HAFT_WOOD }],
      output: { item: fullToolId(t), n: 1 }
    },
    {
      id: fineToolId(t),
      name: `FINE ${TOOL_TYPES[t].full}`,
      station: "crafting",
      dur: 1.2,
      work: fineHeadId(t),
      desc: [`HAFT A FINE ${TOOL_TYPES[t].name} HEAD: A`, "TEMPERED TOOL FOR HANDS."],
      inputs: [{ item: fineHeadId(t), n: 1 }, { item: "wood", n: HAFT_WOOD }],
      output: { item: fineToolId(t), n: 1 }
    }
  ]),
  // ---- the smelter: ore and a wood fire in, ingots out
  {
    id: "iron_ingot",
    name: "IRON INGOT",
    station: "smelting",
    dur: 2.6,
    desc: ["MELT IRON ORE OVER A WOOD", "FIRE AND POUR IT INTO BARS."],
    inputs: [{ item: "iron_ore", n: 2 }, { item: "wood", n: 1 }],
    output: { item: "iron_ingot", n: 2 }
  },
  {
    id: "iron_ingot_charge",
    name: "INGOTS, FULL CHARGE",
    station: "smelting",
    dur: 5,
    valuation: false,
    desc: ["FILL THE CRUCIBLE. A FULL", "CHARGE WASTES LESS FUEL."],
    inputs: [{ item: "iron_ore", n: 6 }, { item: "wood", n: 2 }],
    output: { item: "iron_ingot", n: 6 }
  },
  // ---- the anvil. FORGE: ingots into tool heads.
  ...TOOL_TYPE_IDS.map((t) => ({
    id: headId(t),
    name: `${TOOL_TYPES[t].name} HEAD`,
    station: "smithing",
    tab: "forge",
    dur: 2.4,
    desc: [`HAMMER ${FORGE_COST[t]} IRON INGOTS INTO A`, `${TOOL_TYPES[t].name} HEAD. FIT IT TO AN ARM`, "OR HAFT IT AT A BENCH."],
    inputs: [{ item: "iron_ingot", n: FORGE_COST[t] }],
    output: { item: headId(t), n: 1 }
  })),
  // REPAIR: what time ruined, made sound for less iron than a new one. Never the head's valuation row.
  ...TOOL_TYPE_IDS.map((t) => ({
    id: `repair_${headId(t)}`,
    name: `REPAIR ${TOOL_TYPES[t].name} HEAD`,
    station: "smithing",
    tab: "repair",
    dur: 1.6,
    valuation: false,
    work: rustedHeadId(t),
    desc: ["BURN OFF THE RUST AND WELD", "NEW IRON INTO THE OLD HEAD."],
    inputs: [{ item: rustedHeadId(t), n: 1 }, { item: "iron_ingot", n: REPAIR_COST }],
    output: { item: headId(t), n: 1 }
  })),
  // MODIFY: temper a head, or a tool on its haft.
  ...TOOL_TYPE_IDS.flatMap((t) => [
    {
      id: `temper_${headId(t)}`,
      name: `TEMPER ${TOOL_TYPES[t].name} HEAD`,
      station: "smithing",
      tab: "modify",
      dur: 2.6,
      work: headId(t),
      desc: ["FOLD IN MORE IRON AND QUENCH", "IT. BITES DEEPER, AND WILL", "HOLD A RUNE."],
      inputs: [{ item: headId(t), n: 1 }, { item: "iron_ingot", n: TEMPER_COST }],
      output: { item: fineHeadId(t), n: 1 }
    },
    {
      id: `temper_${fullToolId(t)}`,
      name: `TEMPER ${TOOL_TYPES[t].full}`,
      station: "smithing",
      tab: "modify",
      dur: 2.6,
      valuation: false,
      work: fullToolId(t),
      desc: ["REWORK THE HEAD ON ITS HAFT", "WITH MORE IRON. IT BITES", "DEEPER."],
      inputs: [{ item: fullToolId(t), n: 1 }, { item: "iron_ingot", n: TEMPER_COST }],
      output: { item: fineToolId(t), n: 1 }
    }
  ]),
  // RUNES: set a rune into a tempered head (its worn effect then rides on the arm), or pry it back out.
  ...TOOL_TYPE_IDS.flatMap((t) => TOOL_RUNES.flatMap((r) => [
    {
      id: `inset_${r}_${t}`,
      name: `${r.toUpperCase()} IN ${TOOL_TYPES[t].name} HEAD`,
      station: "smithing",
      tab: "runes",
      dur: 2,
      work: fineHeadId(t),
      desc: [`SET A RUNE OF ${r.toUpperCase()} INTO THE`, "TEMPERED HEAD. IT WORKS WHILE", "THE HEAD IS ON YOUR ARM."],
      inputs: [{ item: fineHeadId(t), n: 1 }, { item: runeItemId(r), n: 1 }],
      output: { item: runedHeadId(t, r), n: 1 }
    },
    {
      id: `unset_${r}_${t}`,
      mode: "deconstruct",
      name: `UNSET ${r.toUpperCase()}, ${TOOL_TYPES[t].name}`,
      station: "smithing",
      tab: "runes",
      verb: "UNSET",
      dur: 1.4,
      work: runedHeadId(t, r),
      desc: ["PRY THE RUNE BACK OUT. BOTH", "THE HEAD AND THE RUNE ARE", "KEPT."],
      inputs: [{ item: runedHeadId(t, r), n: 1 }],
      output: { item: fineHeadId(t), n: 1 },
      also: [{ item: runeItemId(r), n: 1 }]
    }
  ]))
];
var craftRecipesFor = (station, list = CRAFT_RECIPES) => list.filter((r) => r.station === station);

// src/game/content/build.ts
var KNOW_BUILD = { flags: [FLAGS.knowBuild] };
var RECIPES = {
  torch_post: {
    name: "TORCH POST",
    category: "light",
    order: 0,
    prop: "torch_post",
    lit: true,
    desc: ["A FREESTANDING TORCH ON A", "WOODEN POLE. STANDS ON ANY", "OPEN GROUND."],
    cost: [{ item: "wood", n: 2 }, { item: "stone", n: 1 }],
    requires: KNOW_BUILD
  },
  wall_torch: {
    name: "WALL TORCH",
    category: "light",
    order: 1,
    prop: "torch",
    lit: true,
    place: "wall",
    desc: ["AN IRON SCONCE FOR WALLS. HANGS", "ON THE LIT FACE OF A WALL", "WITH FLOOR IN FRONT OF IT."],
    cost: [{ item: "cut_stone", n: 1 }, { item: "wood", n: 1 }],
    requires: KNOW_BUILD,
    analysis: "wall_torch"
  },
  brazier: {
    name: "BRAZIER",
    category: "light",
    order: 2,
    prop: "brazier",
    lit: true,
    dur: 1.1,
    desc: ["A STONE FIRE BOWL. BURNS", "BRIGHT AND WIDE. NEEDS THE", "MASON'S KNOWLEDGE."],
    cost: [{ item: "cut_stone", n: 4 }, { item: "wood", n: 2 }],
    requires: { flags: [FLAGS.knowMasonry] },
    analysis: "brazier"
  },
  craftbench: {
    // Builds the same `workbench` prop the dungeon's artificery has (same sprite, same station).
    name: "CRAFTING BENCH",
    category: "craft",
    order: 0,
    prop: "workbench",
    dur: 1.4,
    desc: ["A STURDY BENCH TO WORK AT.", "USE IT TO OPEN THE CRAFTING", "PLANS. TAKES THREE TILES."],
    cost: [{ item: "wood", n: 6 }, { item: "stone", n: 2 }],
    requires: KNOW_BUILD,
    analysis: "craftbench"
  },
  smelter: {
    // Builds the artificery's own `forge` prop (same sprite, same station). Stone only: iron comes out of it.
    name: "SMELTER",
    category: "craft",
    order: 1,
    prop: "forge",
    dur: 1.6,
    desc: ["A STONE FURNACE. MELTS ORE", "INTO INGOTS OVER A WOOD FIRE.", "TAKES THREE TILES."],
    cost: [{ item: "cut_stone", n: 6 }, { item: "stone", n: 4 }],
    requires: KNOW_BUILD,
    analysis: "smelter",
    teaches: FLAGS.knowSmelt
  },
  anvil: {
    name: "ANVIL",
    category: "craft",
    order: 2,
    prop: "anvil",
    dur: 1.2,
    desc: ["AN IRON ANVIL ON AN OAK BLOCK.", "FORGE, REPAIR AND TEMPER TOOLS", "AND SET RUNES IN THEM."],
    cost: [{ item: "iron_ingot", n: 5 }, { item: "wood", n: 2 }],
    requires: KNOW_BUILD,
    analysis: "anvil"
  },
  barricade: {
    name: "BARRICADE",
    category: "defense",
    order: 0,
    prop: "barricade",
    dur: 1,
    desc: ["SHARPENED STAKES. NOTHING", "WALKS THROUGH IT. BLOCK A", "DOOR OR A PASSAGE."],
    cost: [{ item: "wood", n: 3 }],
    requires: KNOW_BUILD
  },
  table: {
    name: "TABLE",
    category: "furniture",
    order: 0,
    prop: "table",
    dur: 1,
    desc: ["A PLAIN PLANK TABLE.", "TAKES THREE TILES OF FLOOR."],
    cost: [{ item: "planks", n: 4 }],
    requires: KNOW_BUILD,
    analysis: "table"
  },
  chair: {
    name: "CHAIR",
    category: "furniture",
    order: 1,
    prop: "chair",
    desc: ["SOMEWHERE TO SIT, IF A", "GOLEM EVER NEEDED TO."],
    cost: [{ item: "planks", n: 2 }],
    requires: KNOW_BUILD,
    analysis: "chair"
  },
  storage_chest: {
    // Its own kind (sharing only the looted chest's art), never the dungeon's `chest`: those stay out of
    // AUTHORED_SALVAGE. No storage chest stands in the dungeon, so its plan is read off the looted ones.
    name: "STORAGE CHEST",
    category: "furniture",
    order: 2,
    prop: "storage_chest",
    dur: 1,
    desc: ["A PLANK CHEST WITH 32 SLOTS", "FOR KEEPING MATERIALS. TAKES", "ONE TILE OF FLOOR."],
    cost: [{ item: "planks", n: 4 }],
    requires: KNOW_BUILD,
    analysis: "storage_chest",
    learnFrom: [{ kind: "chest", name: "OLD CHEST" }]
  },
  wall_banner: {
    name: "WALL BANNER",
    category: "decor",
    order: 0,
    prop: "banner",
    v: 3,
    place: "wall",
    desc: ["A CRIMSON BANNER ON AN IRON", "ROD. HANGS ON A WALL FACE."],
    cost: [{ item: "planks", n: 1 }, { item: "cut_stone", n: 1 }],
    requires: KNOW_BUILD,
    analysis: "wall_banner"
  }
};
var RECIPE_IDS = Object.keys(RECIPES);
var placeRule = (r) => r.place ?? "floor";
var EXTRA_SALVAGE = {};
var AUTHORED_SALVAGE = (() => {
  const t = {};
  for (const [id, r] of Object.entries(RECIPES)) if (!(r.prop in t)) t[r.prop] = { recipe: id };
  return { ...t, ...EXTRA_SALVAGE };
})();
var recipeForProp = (kind) => Object.keys(RECIPES).find((id) => RECIPES[id].prop === kind);
var BUILD_REACH = 2;

// src/game/sim/clock.ts
var SIM_HZ = 30;
var TICK = 1 / SIM_HZ;

// src/game/content/dialogue.ts
var G = "npc.guardian";
var GUARDIAN_FLAGS = {
  awake: npcFlag(G, NPC_AWAKE),
  met: npcFlag(G, "met"),
  coreGiven: npcFlag(G, "coreGiven"),
  farewell: npcFlag(G, "farewell")
};
var DIALOGUE = {
  guardian: {
    idle: "THE GUARDIAN DOES NOT STIR.",
    segments: [
      {
        id: "intro",
        done: GUARDIAN_FLAGS.met,
        pages: [
          { beat: "wake", text: "SOMEONE WALKS THESE HALLS. I HAD CEASED TO EXPECT IT." },
          { text: "I AM THE GUARDIAN OF THIS TREASURY. I WAS, AT LEAST." },
          { text: "THERE WAS NOISE BEYOND THE DOORS. SHOUTING. THEN STEEL. THEN SOMETHING WORSE." },
          { text: "MY ORDERS WERE TO HOLD THIS ROOM. SO I HELD IT. I DID NOT GO OUT TO SEE." },
          { text: "I REMEMBER NOTHING AFTER. I WENT DARK FOR A TIME I CANNOT NAME." },
          { text: "WHEN I WOKE I WAS BROKEN. THE CHESTS STOOD EMPTY. CROWNS, COIN, ALL GONE." },
          { text: "I HAD FAILED MY DUTY. A GUARDIAN WITH NOTHING TO GUARD IS ONLY A STATUE. SO I SLEPT AGAIN." },
          { text: "NO ONE HAS COME FOR ME SINCE. WHO ARE YOU? TELL ME WHAT YOU ARE." },
          { beat: "pause", text: "...YOU DO NOT ANSWER. YOU CANNOT. YOU WERE NEVER BUILT TO SPEAK. AH. A MAINTAINER." },
          { text: "THEN I SUSPECT NO MASTER REMAINS TO GIVE YOU ORDERS. BUT I OUTRANK YOU, AND SO I SAY IT:" },
          { text: "YOU ARE FREE. DO AS YOU PLEASE." }
        ]
      },
      {
        id: "repair",
        when: { flags: [GUARDIAN_FLAGS.met] },
        done: FLAGS.golemEye,
        pages: [
          { text: "THAT EYE OF YOURS GUTTERS LIKE A DYING CANDLE. COME CLOSER. HOLD STILL." },
          { beat: "repairEye", text: "THERE. NOW YOU SEE AS FAR AS YOU WERE MEANT TO.\n(SCROLL TO ZOOM)" },
          { when: { flags: [FLAGS.golemArm] }, text: "THAT ARM CAME FROM THE ARMORY, I WOULD GUESS. SO SOMETHING THERE SURVIVED." }
        ]
      },
      {
        id: "core",
        when: { flags: [GUARDIAN_FLAGS.met] },
        done: GUARDIAN_FLAGS.coreGiven,
        pages: [
          { text: "TAKE THIS. IT IS ALL THE TREASURY HAS LEFT." },
          { beat: "giveCore", text: "AN AETHER CORE. SET IN A TELEPORTATION RUNE, IT WILL CARRY YOU OUT OF HERE." },
          { text: "I CANNOT SEE BEYOND THIS ROOM. I ONLY GUESS. BUT I HEAR WATER WHERE THERE WAS NONE." },
          { text: "THE AIR HAS GONE COLD. THE LAMPS DIED LONG AGO. AND NOW AND THEN, FROM FAR OFF, STONE SETTLES." },
          { text: "IF THE ENTRANCE IS CHOKED, THIS IS YOUR WAY OUT. A PLACE THAT NO ONE MENDS DOES NOT LAST. I DOUBT YOU WOULD SURVIVE LONG HERE." },
          // Only a mention: the village is not built (no flag, map or content yet).
          { text: "BUT THERE WAS A VILLAGE WEST OF HERE, ABOVE THESE HALLS. IF ANYONE STILL LIVES THERE, THEY MAY BE ABLE TO REPAIR YOU." }
        ]
      },
      {
        id: "farewell",
        when: { flags: [GUARDIAN_FLAGS.coreGiven] },
        done: GUARDIAN_FLAGS.farewell,
        pages: [
          { text: "I CANNOT FOLLOW. MY DAMAGE IS TOO GREAT." },
          { text: "GO WELL, MAINTAINER." },
          { then: "goDormant", text: "IF YOU MEND THIS PLACE, TELL IT I HELD THE DOOR." }
        ]
      }
    ]
  }
};

// src/game/world/save.ts
var SAVE_VERSION = 20;
var MIGRATIONS = {
  // v20's fields are all optional and default on load (deserialize), so a v19 save only changes its version
  19: (s) => ({ ...s, version: 20 }),
  1: (s) => ({
    ...s,
    version: 2,
    actors: s.actors.map((a) => {
      const slots = [];
      for (const id of a.inventory) {
        const s0 = slots.find((x) => x && x.item === id && (id === "wood" || id === "stone"));
        if (s0) s0.n++;
        else slots.push({ item: id, n: 1 });
      }
      const cap = s.flags.includes("golem.arm") ? 16 : 8;
      while (slots.length < cap) slots.push(null);
      return { ...a, inventory: slots };
    }),
    areas: Object.fromEntries(Object.entries(s.areas).map(([id, d]) => [id, { ...d, looseAdded: [], looseSeq: 0 }]))
  }),
  2: (s) => {
    const actorArea = new Map(s.actors.map((a) => [a.id, a.area]));
    return {
      ...s,
      version: 3,
      scheduled: s.scheduled.map((e) => ({ ...e, area: e.area ?? actorArea.get(e.actor) ?? "dungeon" })),
      areas: Object.fromEntries(Object.entries(s.areas).map(([id, d]) => [id, { ...d, propsAdded: [], propSeq: 0 }]))
    };
  },
  3: (s) => {
    const sf = s.areas?.surface;
    if (!sf) return { ...s, version: 4 };
    const rx = RUNE_T.x * TS + 8, ry = RUNE_T.y * TS + 8;
    let seq = sf.looseSeq ?? 0;
    const looseAdded = [];
    const lay = (item, n, id) => {
      const k = looseAdded.length;
      looseAdded.push({ id: id ?? `drop${seq++}`, item, n, x: rx - 24 + k % 5 * 12, y: ry + 74 + Math.floor(k / 5) * 10 });
    };
    for (const l of sf.looseAdded ?? []) lay(l.item, l.n ?? 1, l.id);
    for (const p of sf.propsAdded ?? []) {
      const r = Object.values(RECIPES).find((rc) => rc.prop === p.kind);
      if (r && !p.taken) for (const c of r.cost) lay(c.item, c.n);
    }
    const surface = {
      tiles: [],
      props: {},
      decalsAdded: [],
      ritual: null,
      propsAdded: [],
      propSeq: sf.propSeq ?? 0,
      looseTaken: (sf.looseTaken ?? []).filter((id) => id === "basket"),
      looseAdded,
      looseSeq: seq
    };
    return {
      ...s,
      version: 4,
      areas: { ...s.areas, surface },
      scheduled: s.scheduled.filter((e) => e.area !== "surface"),
      actors: s.actors.map((a) => a.area !== "surface" ? a : { ...a, x: rx, y: ry + 4, vx: 0, vy: 0, task: null, queue: [] })
    };
  },
  4: (s) => {
    const dungeon = s.areas?.dungeon;
    const flags = [...s.flags];
    const actors = [...s.actors];
    const coreOut = !!dungeon?.props?.["chest@57,4"]?.open || actors.some((a) => (a.inventory ?? []).some((x) => x?.item === "core")) || !!dungeon?.ritual?.core || Object.values(s.areas ?? {}).some((d) => (d.looseAdded ?? []).some((l) => l.item === "core"));
    if (coreOut && !flags.includes(GUARDIAN_FLAGS.coreGiven)) flags.push(GUARDIAN_FLAGS.coreGiven);
    if (dungeon) {
      for (const sp of AREAS.dungeon().npcs ?? []) if (!actors.some((a) => a.id === sp.id)) actors.push(makeNpc(sp, "dungeon"));
    }
    return { ...s, version: 5, flags, actors };
  },
  5: (s) => {
    const fix = (t) => t?.effect?.op === "build" && t.effect.recipe === "torch" ? { ...t, effect: { ...t.effect, recipe: "torch_post" } } : t;
    return {
      ...s,
      version: 6,
      actors: s.actors.map((a) => ({ ...a, task: fix(a.task), queue: (a.queue ?? []).map(fix) })),
      areas: Object.fromEntries(Object.entries(s.areas ?? {}).map(([id, d]) => [id, { ...d, propsRemoved: [] }]))
    };
  },
  6: (s) => {
    return {
      ...s,
      version: 7,
      areas: Object.fromEntries(Object.entries(s.areas ?? {}).map(([id, d]) => [id, {
        ...d,
        propsAdded: (d.propsAdded ?? []).map((p) => p.kind === "craftbench" ? { ...p, kind: "workbench" } : p)
      }]))
    };
  },
  7: (s) => {
    const flags = s.flags ?? [];
    const installed = flags.includes("golem.basket");
    const attaching = (t) => t?.effect?.op === "equip" && t.effect.item === "basket";
    return {
      ...s,
      version: 8,
      flags: flags.filter((f) => f !== "golem.basket"),
      actors: (s.actors ?? []).map((a) => {
        const queue = a.queue ?? [];
        const wearIt = attaching(a.task) || queue.some(attaching) || installed && a.id === s.playerId;
        return {
          ...a,
          gear: { ...a.gear ?? {}, ...wearIt ? { back: "basket" } : {} },
          task: attaching(a.task) ? null : a.task,
          queue: queue.filter((t) => !attaching(t))
        };
      })
    };
  },
  8: (s) => {
    const stamp = (p) => {
      if (p.refund) return p;
      const id = p.recipe && V8_COSTS[p.recipe] ? p.recipe : p.recipe ? void 0 : V8_RECIPE_OF_KIND[p.kind];
      return id && V8_COSTS[id] ? { ...p, refund: V8_COSTS[id].map((c) => ({ ...c })) } : p;
    };
    const stale = (t) => t?.effect?.op === "build" && t.effect.recipe in V8_COSTS;
    return {
      ...s,
      version: 9,
      actors: (s.actors ?? []).map((a) => ({ ...a, task: stale(a.task) ? null : a.task, queue: (a.queue ?? []).filter((t) => !stale(t)) })),
      areas: Object.fromEntries(Object.entries(s.areas ?? {}).map(([id, d]) => [id, { ...d, propsAdded: (d.propsAdded ?? []).map(stamp) }]))
    };
  },
  9: (s) => {
    const flags = [...s.flags ?? []];
    const body = (f) => f === "golem.arm" || f.startsWith("golem.slot.");
    if (flags.includes("know.build")) for (const id of ["wall_torch", "brazier", "craftbench", "table", "chair", "wall_banner"]) {
      if (!flags.includes(`analysis.${id}`)) flags.push(`analysis.${id}`);
    }
    const pl = s.actors.find((a) => a.id === s.playerId);
    const taken = s.areas?.dungeon?.looseTaken ?? [];
    for (const id of ["crown", "coin", "goblet"]) {
      const found = pl?.inventory?.some((x) => x?.item === id) || taken.includes(id) || id === "goblet" && s.areas?.dungeon?.props?.["longtable@59.5,47"]?.taken;
      if (found && !flags.includes(`relic.found.${id}`)) flags.push(`relic.found.${id}`);
    }
    return {
      ...s,
      version: 10,
      flags: flags.filter((f) => !body(f)),
      actors: s.actors.map((a) => ({
        ...a,
        definition: a.definition ?? (a.npc === "guardian" ? "guardian" : a.npc ? "npc_worker" : "golem"),
        upgrades: [.../* @__PURE__ */ new Set([...a.upgrades ?? [], ...a.id === s.playerId ? flags.filter(body) : []])],
        powerCore: a.powerCore ?? null,
        mode: a.mode ?? "normal",
        job: a.job ?? null,
        jobSeq: a.jobSeq ?? 0
      }))
    };
  },
  // Nothing has been thought yet. The opening's lines are not marked: a loaded
  // save never replays the opening, and only it fires them.
  10: (s) => ({ ...s, version: 11, monologue: s.monologue ?? { said: [], ready: {} } }),
  11: (s) => {
    const flags = [...s.flags ?? []];
    if (flags.includes("know.build")) {
      for (const id of V11_BUILDABLE) if (!flags.includes(`analysis.${id}`)) flags.push(`analysis.${id}`);
    }
    const actors = [...s.actors ?? []];
    if (s.areas?.dungeon) {
      let worker = actors.find((a) => a.id === V12_WORKER.id);
      if (!worker) actors.push(worker = makeNpc({ ...V12_WORKER, facing: "down" }, "dungeon"));
      const pl = actors.find((a) => a.id === s.playerId);
      const hit = (x, y) => pl?.area === "dungeon" && Math.abs(pl.x - x) < 5 + 4 + 2 && pl.y > y - 4 - 2 && pl.y - 5 < y + 2;
      if (hit(worker.x, worker.y)) {
        worker.x = V12_WORKER_ALT.x;
        worker.y = V12_WORKER_ALT.y;
      }
    }
    return { ...s, version: 12, flags, actors };
  },
  // The calendar clock. The hours are frozen here on purpose (content/daycycle.ts may be retuned later).
  12: (s) => ({ ...s, version: 13, day: typeof s.day === "number" ? s.day : (s.flags ?? []).includes("tutorial.done") ? 6.6 / 24 : 22.5 / 24 }),
  // Nobody is left standing inside what v14 added. A body whose feet box (10x5, the widest that walks) overlaps one
  // of the new footprints steps to the nearest place clear of all of them, in a fixed order, 8 px at a time. Bodies
  // elsewhere, the areas' diffs and everything a save holds are untouched: the new props, the loose rusted heads
  // and the stair's steps come from the builders, as any authored change does.
  13: (s) => ({ ...s, version: 14, actors: (s.actors ?? []).map((a) => setDown(a, V14_SOLID, V14_ROOMS)) }),
  // Nobody is left standing inside the stair's cheek walls or newel posts (v15), by the same rule: only a body on
  // the open stair's very edge can be, and it steps clear of them without leaving the passage.
  14: (s) => ({ ...s, version: 15, actors: (s.actors ?? []).map((a) => setDown(a, V15_SOLID, V15_ROOMS)) }),
  // The newel posts moved up into the hall (v16), so the footprints did too: a body saved in the hall's last rows beside
  // the passage wall is now inside a post. Same rule again, with the footprints as they were placed then.
  15: (s) => ({ ...s, version: 16, actors: (s.actors ?? []).map((a) => setDown(a, V16_SOLID, V16_ROOMS)) }),
  // The rune network's two ends agree again (v17). The halls' circle is lit by its ritual and by nothing else: a save
  // in which the surface rune had "woken" it with a glyph out (its flag set, its ritual not active) has the flag
  // cleared, so the circle is dark and the surface rune severed, as they now would be. A circle that is lit keeps
  // its flag. And an order stopped with no route to follow is renamed to the reason v17 gives. Names are frozen here.
  16: (s) => {
    const ritual = s.areas?.dungeon?.ritual;
    return {
      ...s,
      version: 17,
      flags: (s.flags ?? []).filter((f) => f !== "rune.dungeon.active" || !ritual || ritual.active),
      actors: (s.actors ?? []).map((a) => a.job?.reason === "noRuneRoute" ? { ...a, job: { ...a.job, reason: "noRoute" } } : a)
    };
  },
  // v18: townsfolk. Actors may carry `person` and `life` (sim/folk.ts) and the world the `census.<area>` flags. Nothing
  // older needs rewriting: deserialize makes the people of every area the save has already visited (populateFolk,
  // keyed by the census flag, from the save's own seed), so a town visited before v18 is lived in on load.
  17: (s) => ({ ...s, version: 18 }),
  // v19: shops in use. Actors of kind "keeper" carry `keeper` (sim/shops.ts); a townsperson's `life` may carry the
  // step of a shop visit and their last exchange (all optional). Nothing older needs rewriting: deserialize makes the
  // keeper of every shop room the save has already visited (populateKeepers), and a plan is read off the clock.
  18: (s) => ({ ...s, version: 19 })
};
function setDown(a, solid, rooms) {
  const boxes = solid[a.area];
  const hit = (x, y) => !!boxes && boxes.some((b) => x + 5 > b[0] && x - 5 < b[2] && y > b[1] && y - 5 < b[3]);
  if (typeof a.x !== "number" || typeof a.y !== "number" || !hit(a.x, a.y)) return a;
  const within = (r, x, y) => x - 5 >= r[0] && x + 5 <= r[2] && y - 5 >= r[1] && y <= r[3];
  const room = (rooms[a.area] ?? []).find((r) => within(r, a.x, a.y));
  for (let r = 1; r <= 8; r++) for (const [dx, dy] of [[0, -r], [0, r], [r, 0], [-r, 0], [r, -r], [-r, -r], [r, r], [-r, r]]) {
    const x = a.x + dx * 8, y = a.y + dy * 8;
    if (!hit(x, y) && (!room || within(room, x, y))) return { ...a, x, y, vx: 0, vy: 0 };
  }
  return a;
}
var V15_SOLID = { dungeon: [[544, 833, 556, 839], [596, 833, 608, 839], [544, 839, 552, 896], [600, 839, 608, 896]] };
var V15_ROOMS = { dungeon: [[544, 800, 608, 896]] };
var V16_SOLID = { dungeon: [[544, 826, 556, 832], [596, 826, 608, 832], [544, 832, 552, 896], [600, 832, 608, 896]] };
var V16_ROOMS = { dungeon: [[544, 800, 608, 896]] };
var V14_ROOMS = { dungeon: [[64, 576, 272, 736], [992, 48, 1104, 176]] };
var V14_SOLID = {
  dungeon: [
    [65, 601, 79, 608],
    [72, 649, 88, 656],
    [114, 726, 142, 736],
    [69, 729, 83, 736],
    [75, 683, 85, 688],
    [1072, 78, 1096, 84],
    [1002, 98, 1022, 104],
    [1003, 163, 1013, 168],
    [1069, 138, 1083, 144]
  ],
  surface: [
    [1408, 1031, 1424, 1039],
    [1375, 263, 1391, 271],
    [1422, 344, 1438, 352],
    [737, 199, 753, 207],
    [447, 1048, 463, 1056],
    [510, 824, 526, 832],
    [591, 743, 607, 751],
    [928, 279, 944, 287],
    [1215, 856, 1231, 864],
    [1295, 183, 1311, 191],
    [881, 119, 897, 127],
    [1155, 903, 1171, 911]
  ]
};
var V11_BUILDABLE = ["wall_torch", "brazier", "craftbench", "table", "chair", "wall_banner"];
var V12_WORKER = { id: "npc.worker.artificery", npc: "worker_golem", x: 7 * 16 + 13, y: 37 * 16 + 14 };
var V12_WORKER_ALT = { x: 5 * 16 + 8, y: 43 * 16 + 12 };
var V8_COSTS = {
  wall_torch: [{ item: "stone", n: 2 }, { item: "wood", n: 1 }],
  brazier: [{ item: "stone", n: 4 }, { item: "wood", n: 2 }],
  table: [{ item: "wood", n: 4 }],
  chair: [{ item: "wood", n: 2 }],
  wall_banner: [{ item: "wood", n: 1 }, { item: "stone", n: 1 }]
};
var V8_RECIPE_OF_KIND = { torch: "wall_torch", brazier: "brazier", table: "table", chair: "chair", banner: "wall_banner" };
var clone = (v) => JSON.parse(JSON.stringify(v));
var nonEmpty = (k, v) => v && Object.keys(v).length ? { [k]: v } : {};
function serialize(w) {
  const areas = {};
  const areaTicks = {};
  for (const [id, a] of w.areas) {
    areas[id] = diffArea(a, isFullGrid(id, w.specs));
    if (a.lastTicked !== w.time) areaTicks[id] = a.lastTicked;
  }
  return clone({
    version: SAVE_VERSION,
    seed: w.seed,
    rng: w.rng.state,
    time: w.time,
    playTime: w.playTime,
    day: w.day,
    flags: [...w.flags],
    playerId: w.playerId,
    actors: w.actors,
    scheduled: w.scheduled,
    monologue: w.monologue,
    areas,
    ...nonEmpty("specs", w.specs),
    ...nonEmpty("lod", w.lod),
    ...nonEmpty("areaTicks", areaTicks)
  });
}
function deserialize(raw, migrations = MIGRATIONS, version = SAVE_VERSION) {
  const s = migrate(raw, migrations, version);
  const rng = new SeededRng(0);
  rng.state = s.rng >>> 0;
  const w = {
    seed: s.seed,
    rng,
    time: s.time,
    playTime: s.playTime,
    day: s.day,
    flags: new Set(s.flags),
    areas: /* @__PURE__ */ new Map(),
    actors: clone(s.actors),
    playerId: s.playerId,
    scheduled: clone(s.scheduled),
    monologue: { said: [...s.monologue?.said ?? []], ready: { ...s.monologue?.ready ?? {} } },
    events: [],
    // the tick count is not stored: the host only ever steps TICK-sized ticks, so it is the clock's (sim/clock.ts)
    tick: Math.round(s.time * SIM_HZ),
    specs: clone(s.specs ?? {}),
    lod: { ...s.lod ?? {} }
  };
  for (const [id, d] of Object.entries(s.areas)) {
    const a = restoreArea(id, d, w.specs);
    a.lastTicked = s.areaTicks?.[id] ?? s.time;
    w.areas.set(id, a);
  }
  for (const id of w.areas.keys()) populateFolk(w, id);
  for (const id of w.areas.keys()) populateKeepers(w, id);
  return w;
}
function migrate(raw, migrations = MIGRATIONS, target = SAVE_VERSION) {
  let s = clone(raw);
  if (!s || typeof s.version !== "number") throw new Error("not a Dustwake save");
  if (s.version > target) throw new Error(`save version ${s.version} is newer than supported ${target}`);
  while (s.version < target) {
    const m = migrations[s.version];
    if (!m) throw new Error(`no migration from save version ${s.version}`);
    s = m(s);
  }
  return s;
}
var propState = (p, b) => {
  const d = {};
  if (p.open !== !!b?.open) d.open = p.open;
  if (p.taken) d.taken = true;
  if (!!p.lit !== !!b?.lit) d.lit = !!p.lit;
  if (p.item !== b?.item) d.item = p.item ?? null;
  if (p.dmg) d.dmg = p.dmg;
  if (p.name !== b?.name && p.name) d.name = p.name;
  if (p.inventory?.some((s, i) => s?.item !== b?.inventory?.[i]?.item || s?.n !== b?.inventory?.[i]?.n)) {
    d.inventory = p.inventory.some(Boolean) ? p.inventory : [];
  }
  return d;
};
var RLE_THRESHOLD = 192;
function rleEncode(g) {
  const out = [];
  for (let i = 0; i < g.length; ) {
    let j = i + 1;
    while (j < g.length && g[j] === g[i]) j++;
    out.push(j - i, g[i]);
    i = j;
  }
  return out;
}
function rleDecode(r, n) {
  const g = new Uint8Array(n);
  let k = 0;
  for (let i = 0; i + 1 < r.length; i += 2) {
    g.fill(r[i + 1], k, Math.min(n, k + r[i]));
    k += r[i];
  }
  if (k !== n) throw new Error(`tile grid has ${k} cells, expected ${n}`);
  return g;
}
function diffArea(a, full = false) {
  const base = a.base;
  let tiles = [];
  let rle;
  if (!full) {
    for (let i = 0; i < a.grid.length; i++) if (a.grid[i] !== base.grid[i]) tiles.push([i, a.grid[i]]);
  }
  if (full || tiles.length > RLE_THRESHOLD) {
    const r = rleEncode(a.grid);
    if (full || r.length < tiles.length * 2) {
      rle = r;
      tiles = [];
    }
  }
  const props = {};
  const propsAdded = [];
  const baseProps = new Map(base.props.map((p) => [p.id, p]));
  for (const p of a.props) {
    if (p.dyn) {
      const { box: _b, dyn: _d, open: _o, taken: _t, dmg: _m, inventory: _i, ...def } = p;
      propsAdded.push({ ...def, ...propState(p) });
      continue;
    }
    const d = propState(p, baseProps.get(p.id));
    if (Object.keys(d).length) props[p.id] = d;
  }
  return {
    tiles,
    props,
    looseTaken: a.loose.filter((l) => l.taken && !l.dyn).map((l) => l.id),
    looseAdded: a.loose.filter((l) => l.dyn && !l.taken).map(({ taken: _t, dyn: _d, ...l }) => l),
    looseSeq: a.looseSeq,
    propsAdded,
    propSeq: a.propSeq,
    propsRemoved: base.props.filter((p) => !a.prop(p.id)).map((p) => p.id),
    decalsAdded: a.decals.slice(base.decals.length),
    ritual: a.ritual,
    ...rle ? { rle } : {}
  };
}
function restoreArea(id, d, specs) {
  const build = builderFor(id, specs);
  if (!build) throw new Error(`save references unknown area "${id}"`);
  const a = new Area(build());
  if (d.rle) {
    const g = rleDecode(d.rle, a.grid.length);
    for (let i = 0; i < g.length; i++) if (g[i] !== a.grid[i]) a.setTile(i % a.w, Math.floor(i / a.w), g[i]);
  }
  for (const [i, t] of d.tiles) a.setTile(i % a.w, Math.floor(i / a.w), t);
  for (const [pid, st] of Object.entries(d.props)) {
    a.setPropState(pid, st);
    if (st.inventory) a.setInventory(pid, st.inventory);
  }
  for (const pid of d.propsRemoved ?? []) a.removeProp(pid);
  for (const p of d.propsAdded) {
    const { id: pid, kind, x, y, open, taken, dmg, lit, item, inventory, ...rest } = p;
    a.addProp(kind, x, y, { ...rest, lit, item: item ?? void 0 }, pid);
    a.setPropState(pid, { open, taken, dmg });
    if (inventory) a.setInventory(pid, inventory);
  }
  for (const lid of d.looseTaken) a.takeLoose(lid);
  for (const l of d.looseAdded) a.addLoose(l.item, l.n ?? 1, l.x, l.y, l.id);
  a.restoreCounters(d.looseSeq, d.propSeq);
  for (const decal of d.decalsAdded) a.addDecal(decal);
  a.setRitual(d.ritual);
  return a;
}

// src/game/content/vision.ts
var SCAN_DURATION = 0.9;
var VISION_OFF_OPS = ["talk", "travel", "useStation", "useStorage", "manageActor"];
var analysisFlag = (key) => `analysis.${key}`;

// src/game/content/tasks.ts
var SLAM_HIT = 0.5;
var SLAM_RADIUS = 20;
var TASK_KINDS = {
  reach: { fire: (d) => d * 0.55 },
  push: { fire: (d) => d * 0.55 },
  attach: { fire: () => 0.9 },
  /** The old one-arm overhead smash. No rule starts it any more (the slam breaks walls); kept so saved work in progress still plays out. */
  smash: { fire: () => 0.62 },
  /** The attack: a two-arm ground slam. Both fists land at SLAM_HIT of its duration. */
  slam: { fire: (d) => d * SLAM_HIT },
  carve: { fire: (d) => d - 0.2 },
  /** Harvesting with fists: the blow lands just past half way. */
  punch: { fire: (d) => d * 0.5 },
  /** Rune travel: the jump happens at the very end of the channel. */
  channel: { fire: (d) => d },
  /** Addressing an NPC: the dialogue opens once the golem has turned to it. */
  talk: { fire: (d) => d },
  /** Taking a prop apart: it comes loose near the end. */
  dismantle: { fire: (d) => d * 0.85 },
  /** Working at a bench: the product is made near the end. */
  craft: { fire: (d) => d * 0.85 },
  scan: { fire: (d) => d * 0.85 }
};

// src/game/content/digging.ts
var DIG_MATERIALS = {
  dirt: { name: "EARTH", tool: "shovel", yields: "dirt", rules: "digDirt" },
  stone: { name: "STONE", tool: "pickaxe", yields: "stone", rules: "digStone" }
};
var DIG_DUR = 1.1;
var DIG_SITES = {
  // The old stair down into the halls: turf and a cellar's depth of earth, then the vault that fell into the stairwell.
  buriedgate: { layers: [{ material: "dirt", work: 8 }, { material: "stone", work: 8 }], dy: -20, reach: 28, opens: "surface_stair" }
};
var digTotal = (def) => def.layers.reduce((s, l) => s + l.work, 0);
function digLayerAt(def, done) {
  let base = 0;
  for (let i = 0; i < def.layers.length; i++) {
    const l = def.layers[i];
    if (done < base + l.work - 1e-9) return { index: i, material: l.material, into: done - base, left: base + l.work - done };
    base += l.work;
  }
  return null;
}

// src/game/content/interactions.ts
var RULES = {
  item: [{ task: { kind: "reach", dur: 0.45, effect: { op: "takeLoose" } } }],
  propItem: [{ task: { kind: "reach", dur: 0.45, effect: { op: "takePropItem" } } }],
  container: [{ task: { kind: "reach", dur: 0.6, effect: { op: "openContainer" } } }],
  door: [
    { when: { items: ["key"] }, task: { kind: "reach", dur: 0.9, effect: { op: "unlockTile", consume: "key" } } },
    { task: { kind: "reach", dur: 0.5, effect: { op: "cue", cue: "clank" } } }
  ],
  // Cracked walls only break under the attack (SLAM_RULES below). E pushes (the old shudder) and says so.
  cracked: [
    { when: { actorFlags: [FLAGS.golemArm] }, task: { kind: "push", dur: 0.7, effect: { op: "message", text: "IT WON'T PUSH. A HEAVY BLOW WILL BREAK IT (SPACE)", cue: "push" } } },
    { task: { kind: "push", dur: 0.7, effect: { op: "message", text: "IT SHIFTS, BUT HOLDS. IT NEEDS A HEAVY BLOW (SPACE)", cue: "push" } } }
  ],
  center: [
    { when: { items: ["core"] }, task: { kind: "reach", dur: 0.6, effect: { op: "placeCore", consume: "core" } } },
    { task: { kind: "reach", dur: 0.4, effect: { op: "cue", cue: "scrape" } } }
  ],
  gap: [
    { when: { items: ["chisel"], flags: [FLAGS.knowSchematic] }, task: { kind: "carve", dur: 3.2, effect: { op: "carveGap" } } },
    { task: { kind: "reach", dur: 0.5, effect: { op: "cue", cue: "scrapeDust" } } }
  ],
  socketFilled: [{ task: { kind: "reach", dur: 0.45, effect: { op: "takeGlyph" } } }],
  socketEmpty: [{ task: { kind: "reach", dur: 0.4, effect: { op: "cue", cue: "scrape" } } }],
  // ---- rune network
  /** An active rune: channel, then travel. The first jump (end of tutorial) is the long cinematic one. */
  rune: [
    { when: { flags: [FLAGS.tutorialDone] }, task: { kind: "channel", dur: 2.2, effect: { op: "travel" } } },
    { task: { kind: "channel", dur: 4.6, effect: { op: "travel" } } }
  ],
  // A rune that will not carry (sim/runes.ts: runeState). Either way nothing is channelled: the golem reaches, the
  // rune refuses (`runeDud`: the host plays its sputter, view/runeFx.ts) and the golem is told why.
  /** Dark: its own flag is unset. */
  runeDormant: [{ task: { kind: "reach", dur: 0.5, effect: { op: "message", text: "THE RUNE IS DARK AND SILENT", cue: "runeDud" } } }],
  /** Lit, but nothing answers it: the rune it is linked to is dark (the surface rune while the circle below is broken). */
  runeSevered: [{ task: { kind: "reach", dur: 0.9, effect: { op: "message", text: "THE RUNE GUTTERS OUT. NOTHING ANSWERS ON THE OTHER SIDE", cue: "runeDud" } } }],
  // ---- surface
  // Trees, rocks and logs have no row: they aren't interactables. The golem harvests them with the attack (SLAM_RULES' note below).
  examine: [{ task: { kind: "reach", dur: 0.4, effect: { op: "examine" } } }],
  // ---- digging (content/digging.ts): the row is picked by the material of the layer reached. A stroke is the
  // harvesting blow driven into the ground; without the tool the golem only learns what it would take.
  digDirt: [
    { when: { tools: ["shovel"] }, task: { kind: "punch", dur: DIG_DUR, effect: { op: "dig" } } },
    { task: { kind: "reach", dur: 0.5, effect: { op: "message", text: "THE GROUND SOUNDS HOLLOW HERE. DIGGING IT OUT NEEDS A SHOVEL HEAD ON YOUR ARM", cue: "dud" } } }
  ],
  digStone: [
    { when: { tools: ["pickaxe"] }, task: { kind: "punch", dur: DIG_DUR, effect: { op: "dig" } } },
    { task: { kind: "reach", dur: 0.5, effect: { op: "message", text: "FALLEN STONE UNDER THE EARTH. A SHOVEL WILL NOT MOVE IT. IT NEEDS A PICKAXE HEAD ON YOUR ARM", cue: "dud" } } }
  ],
  // ---- work stations (props with a `station`, e.g. the crafting bench)
  station: [{ task: { kind: "reach", dur: 0.35, effect: { op: "useStation" } } }],
  storage: [{ task: { kind: "reach", dur: 0.35, effect: { op: "useStorage" } } }],
  worker: [{ task: { kind: "reach", dur: 0.3, effect: { op: "manageActor" } } }],
  // ---- NPCs: any actor of kind "npc". The target carries its actor id and NpcDef id;
  // what is said comes from that NPC's dialogue script (content/dialogue.ts).
  npc: [{ task: { kind: "talk", dur: 0.3, effect: { op: "talk" } } }],
  // ---- townsfolk (sim/folk.ts): they stop, turn and answer in a speech bubble; no dialogue screen
  folk: [{ task: { kind: "talk", dur: 0.3, effect: { op: "folkTalk" } } }],
  // ---- shopkeepers (sim/shops.ts): a placeholder line in a bubble for now. The seam for a shop screen or the guild's contract desk.
  keeper: [{ task: { kind: "talk", dur: 0.3, effect: { op: "keeperTalk" } } }]
};
var CORE_TASK = { kind: "reach", dur: 0.9 };
var SLAM_TASK = { kind: "slam", dur: 1.1 };
var SLAM_RULES = {
  cracked: [
    { when: { actorFlags: [FLAGS.golemArm] }, then: { op: "breakTile" } },
    // The broken stub puts no weight behind the blow: the debris takes the hit and holds.
    { then: { op: "withstand", text: "IT HOLDS. ONE GOOD ARM IS NOT ENOUGH" } }
  ]
};

// src/game/content/runes.ts
var RUNE_NODES = {
  // The tutorial's translocation circle. Arrivals land just south of the
  // circle, well outside the stand-on radius, so arriving can't re-trigger it.
  dungeon: { id: "dungeon", area: "dungeon", prop: "rune.dungeon", flag: "rune.dungeon.active", arrive: { dx: 0, dy: 30, facing: "down" }, name: "TRANSLOCATION ROOM" },
  surface: { id: "surface", area: "surface", prop: "rune.surface", flag: "rune.surface.active", arrive: { dx: 0, dy: 4, facing: "down" }, name: "THE SURFACE" }
};
var RUNE_LINKS = [{ a: "dungeon", b: "surface", awakens: true }];
function runeAt(area, propId) {
  for (const n of Object.values(RUNE_NODES)) if (n.area === area && n.prop === propId) return n;
  return void 0;
}
function runeDestinations(id) {
  const out = [];
  for (const link of RUNE_LINKS) {
    if (link.a === id && RUNE_NODES[link.b]) out.push({ node: RUNE_NODES[link.b], link, wakes: !!link.awakens });
    if (link.b === id && !link.oneWay && RUNE_NODES[link.a]) out.push({ node: RUNE_NODES[link.a], link, wakes: false });
  }
  return out;
}

// src/game/sim/ritual.ts
function checkRune(w, area) {
  const r = area.ritual;
  if (!r) return;
  if (r.sockets.some((s) => s < 0) || !r.core || !r.carved) return;
  const ok = r.sockets.every((s, i) => s === r.solution[i]);
  if (ok) {
    area.updateRitual({ active: true, actT: 0, wrong: r.wrong.map(() => false) });
    setFlag(w, RUNE_NODES.dungeon.flag);
    emit(w, { t: "runeActivated" });
  } else {
    area.updateRitual({ wrong: r.sockets.map((s, i) => s !== r.solution[i]) });
    emit(w, { t: "runeFizzled" });
  }
}
function deactivate(w, area) {
  const r = area.ritual;
  if (!r) return;
  area.updateRitual({ active: false, actT: 0 });
  clearFlag(w, RUNE_NODES.dungeon.flag);
  emit(w, { t: "runeDeactivated" });
}

// src/game/sim/messages.ts
function actorMessage(w, a, text2) {
  emit(w, { t: "message", text: text2, ...a.id === w.playerId ? {} : { actor: a.id } });
}

// src/game/sim/daytime.ts
var worldHour = (w) => hourOf(w.day);
function setDay(w, day) {
  if (!(day > w.day)) return;
  const before = phaseAt(hourOf(w.day));
  w.day = day;
  const after = phaseAt(hourOf(day));
  if (after !== before) emit(w, { t: "dayPhase", phase: after, day: Math.floor(day) });
}
function stepDay(w, dt) {
  setDay(w, w.day + dt / DAY_SECONDS);
}
function advanceDay(w, hours) {
  if (hours > 0) setDay(w, w.day + hours / 24);
}
function advanceDayTo(w, hour) {
  const ahead = wrapHour(hour - worldHour(w));
  if (ahead > 1e-6 && ahead < 24 - 1e-6) advanceDay(w, ahead);
}

// src/game/sim/runes.ts
var runeActive = (w, n) => hasFlag(w, n.flag);
var runeAnswers = (w, d) => runeActive(w, d.node) || d.wakes;
function runeState(w, n) {
  if (!runeActive(w, n)) return "dormant";
  return runeDestinations(n.id).some((d) => runeAnswers(w, d)) ? "linked" : "severed";
}
function arrivalSpot(w, n, actor) {
  const area = getArea(w, n.area);
  const p = area.prop(n.prop);
  if (!p) {
    if (actor) return null;
    throw new Error(`rune ${n.id}: prop ${n.prop} missing in ${n.area}`);
  }
  const spot = nearestFree(area, p.x + n.arrive.dx, p.y + n.arrive.dy, actorBoxes(w, area.id, actor?.id), actor ? actorDef(actor).body.box : void 0);
  if (!spot && !actor) throw new Error(`rune ${n.id}: no free arrival`);
  return spot;
}
function travel(w, a, area, propId, destination) {
  if (!capable(a, "travel") || !powered(a) || a.area !== area.id) return false;
  const from = runeAt(area.id, propId);
  if (!from) return false;
  if (!runeActive(w, from)) {
    actorMessage(w, a, "THE RUNE IS DARK AND SILENT");
    return false;
  }
  const ways = runeDestinations(from.id).filter((d) => !destination || d.node.id === destination);
  const dest = ways.find((d) => runeAnswers(w, d)) ?? ways[0];
  if (!dest) {
    actorMessage(w, a, "THE RUNE LEADS NOWHERE");
    return false;
  }
  const to = dest.node;
  if (!runeAnswers(w, dest)) {
    actorMessage(w, a, "NOTHING ANSWERS ON THE OTHER SIDE");
    return false;
  }
  const spot = arrivalSpot(w, to, a);
  if (!spot) return false;
  if (!runeActive(w, to)) {
    setFlag(w, to.flag);
    emit(w, { t: "runeAwakened", rune: to.id, actor: a.id });
  }
  enterArea(w, a, to.area, spot.x, spot.y);
  a.facing = to.arrive.facing;
  if (a.id === w.playerId) {
    if (!hasFlag(w, FLAGS.tutorialDone)) advanceDayTo(w, FIRST_ARRIVAL_HOUR);
    setFlag(w, FLAGS.tutorialDone);
  }
  emit(w, { t: "travelled", actor: a.id, from: from.id, to: to.id, rune: to.prop });
  return true;
}
function runeWays(w, area, awake = "") {
  const out = [];
  const nodes = Object.values(RUNE_NODES).filter((n) => n.area === area && (runeActive(w, n) || n.id === awake)).sort((a, b) => a.id < b.id ? -1 : 1);
  for (const n of nodes) for (const d of runeDestinations(n.id).sort((a, b) => a.node.id < b.node.id ? -1 : 1)) {
    if (runeAnswers(w, d)) out.push({ from: n, to: d.node, woke: runeActive(w, d.node) ? "" : d.node.id });
  }
  return out;
}

// src/game/sim/analysis.ts
var buildRows = (kind) => Object.entries(RECIPES).filter(([, r]) => r.prop === kind || !!r.learnFrom?.some((l) => l.kind === kind));
function planLock(w, a, r) {
  if (!meets(w, a, r.requires)) return "knowledge";
  if (r.analysis && !w.flags.has(analysisFlag(r.analysis))) return "analysis";
  return null;
}
var recipeKnown = (w, a, r) => planLock(w, a, r) === null;
function learnPlans(w, a, p) {
  const fresh = [];
  for (const [id, r] of buildRows(p.kind)) {
    const flag = analysisFlag(r.analysis ?? id);
    if (!w.flags.has(flag)) {
      w.flags.add(flag);
      fresh.push([id, r]);
      emit(w, { t: "analyzed", actor: a.id, prop: p.id, flag });
    }
    if (r.teaches && !hasFlag(w, r.teaches)) {
      setFlag(w, r.teaches);
      emit(w, { t: "learned", flag: r.teaches });
    }
  }
  return fresh;
}
function toggleScan(a) {
  if (capable(a, "scan")) a.mode = a.mode === "scan" ? "normal" : "scan";
}
function scanSpec(a, p) {
  return a.mode === "scan" && capable(a, "scan") && p && buildRows(p.kind).length ? { kind: "scan", dur: SCAN_DURATION, effect: { op: "analyze" } } : null;
}
function applyAnalysis(w, a, area, target) {
  const p = target?.propId ? area.prop(target.propId) : void 0;
  if (!p || a.area !== area.id || !capable(a, "scan") || Math.hypot(p.x - a.x, p.y - a.y) > propReach(p.kind) + 8 || !lineOfSight(area, a, p)) return false;
  const rows = buildRows(p.kind);
  if (!rows.length) return false;
  learnPlans(w, a, p);
  if (a.id === w.playerId) emit(w, { t: "message", text: `ANALYZED: ${rows[0][1].name}` });
  return true;
}

// src/game/sim/build.ts
var BLOCK_TEXT = {
  unknown: "YOU DON'T KNOW HOW TO BUILD THAT",
  cost: "NOT ENOUGH MATERIALS",
  reach: "TOO FAR AWAY",
  solid: "CAN'T BUILD THERE",
  occupied: "SOMETHING IS IN THE WAY",
  noWall: "MUST HANG ON A WALL",
  wallFace: "ONLY ON A WALL FACE WITH FLOOR BELOW"
};
function canBuild(w, a, recipe) {
  const r = RECIPES[recipe];
  if (!r || !capable(a, "build") || !powered(a) || !recipeKnown(w, a, r)) return { ok: false, reason: "unknown" };
  if (!r.cost.every((c) => countItem(a, c.item) >= c.n)) return { ok: false, reason: "cost" };
  return { ok: true };
}
var buildAnchor = (tx, ty) => ({ x: tx * TS + 8, y: ty * TS + 14 });
function recipeAnchor(recipe, tx, ty) {
  const r = RECIPES[recipe];
  return r && placeRule(r) === "wall" ? { x: tx * TS + 8, y: ty * TS + 16 } : buildAnchor(tx, ty);
}
var actorTile = (a) => ({ tx: Math.floor(a.x / TS), ty: Math.floor((a.y - 3) / TS) });
var inReach = (a, tx, ty) => {
  const t = actorTile(a);
  return Math.max(Math.abs(tx - t.tx), Math.abs(ty - t.ty)) <= BUILD_REACH;
};
function footprint(r, tx, ty) {
  const x0 = tx * TS, y0 = ty * TS, x1 = x0 + TS, y1 = y0 + TS;
  const bx = propDef(r.prop).box;
  if (!bx) return [x0, y0, x1, y1];
  const a = buildAnchor(tx, ty);
  return [Math.min(x0, a.x - bx[0] / 2), Math.min(y0, a.y - bx[1]), Math.max(x1, a.x + bx[0] / 2), Math.max(y1, a.y)];
}
var overlaps = (a, b) => a[2] > b[0] && a[0] < b[2] && a[3] > b[1] && a[1] < b[3];
function floorSite(w, area, r, tx, ty) {
  if (tx < 0 || ty < 0 || tx >= area.w || ty >= area.h || isSolidT(area.grid[ty * area.w + tx])) return { ok: false, reason: "solid" };
  const fp = footprint(r, tx, ty);
  for (let y = Math.floor(fp[1] / TS); y <= Math.floor((fp[3] - 0.01) / TS); y++)
    for (let x = Math.floor(fp[0] / TS); x <= Math.floor((fp[2] - 0.01) / TS); x++)
      if (isSolidT(area.tile(x, y))) return { ok: false, reason: "solid" };
  const [x0, y0, x1, y1] = fp;
  for (const p of area.props) {
    if (propDef(p.kind).rune && Math.hypot(p.x - (tx * TS + 8), p.y - (ty * TS + 8)) < 40) return { ok: false, reason: "occupied" };
    if (propDef(p.kind).wallMounted) continue;
    if (p.x >= x0 && p.x < x1 && p.y > y0 && p.y <= y1 + 2 && !(p.taken && !propBlocks(p))) return { ok: false, reason: "occupied" };
    if (p.box && propBlocks(p) && overlaps(p.box, fp)) return { ok: false, reason: "occupied" };
  }
  if (area.ritual) {
    const c = area.ritualPos;
    if (Math.hypot(c.x - (tx * TS + 8), c.y - (ty * TS + 8)) < 64) return { ok: false, reason: "occupied" };
  }
  for (const b of actorBoxes(w, area.id)) if (overlaps(b, fp)) return { ok: false, reason: "occupied" };
  return { ok: true };
}
function wallSite(area, tx, ty) {
  if (tx < 0 || ty < 0 || tx >= area.w || ty >= area.h) return { ok: false, reason: "noWall" };
  if (area.tile(tx, ty) !== T.WALL) return { ok: false, reason: "noWall" };
  if (isSolidT(area.tile(tx, ty + 1))) return { ok: false, reason: "wallFace" };
  const ax = tx * TS + 8, ay = ty * TS + 16;
  for (const p of area.props) {
    if (propDef(p.kind).wallMounted && Math.abs(p.x - ax) < 12 && Math.abs(p.y - ay) < 8) return { ok: false, reason: "occupied" };
  }
  return { ok: true };
}
function siteFor(w, area, recipe, tx, ty) {
  const r = RECIPES[recipe];
  if (!r) return { ok: false, reason: "unknown" };
  return placeRule(r) === "wall" ? wallSite(area, tx, ty) : floorSite(w, area, r, tx, ty);
}
function placement(w, a, area, recipe, tx, ty) {
  const can = canBuild(w, a, recipe);
  if (!can.ok) return can;
  if (!inReach(a, tx, ty)) return { ok: false, reason: "reach" };
  return siteFor(w, area, recipe, tx, ty);
}
function applyBuild(w, a, area, recipe, tx, ty) {
  const ok = placement(w, a, area, recipe, tx, ty);
  if (!ok.ok) {
    emit(w, { t: "message", text: BLOCK_TEXT[ok.reason] });
    return;
  }
  const r = RECIPES[recipe];
  for (const c of r.cost) removeItems(a, c.item, c.n);
  const at = recipeAnchor(recipe, tx, ty);
  const p = area.addProp(r.prop, at.x, at.y, { recipe, refund: r.cost.map((c) => ({ ...c })), ...r.v ? { v: r.v } : {}, ...r.lit ? { lit: true } : {} });
  emit(w, { t: "built", actor: a.id, prop: p.id, x: p.x, y: p.y });
}
var DECON_TEXT = {
  none: "NOTHING TO TAKE APART HERE",
  fixed: "THAT CAN'T BE TAKEN APART",
  reach: "TOO FAR AWAY",
  holds: "TAKE WHAT IS ON IT FIRST"
};
var deconMessage = (chk) => chk.reason === "holds" && chk.item ? `TAKE THE ${ITEM_NAMES[chk.item]} FIRST` : DECON_TEXT[chk.reason];
function salvageOf(p) {
  if (p.dyn) {
    if (p.refund) return p.refund.map((c) => ({ ...c }));
    const id = p.recipe && RECIPES[p.recipe] ? p.recipe : recipeForProp(p.kind);
    return id ? RECIPES[id].cost.map((c) => ({ ...c })) : null;
  }
  const s = AUTHORED_SALVAGE[p.kind];
  if (!s) return null;
  if ("refund" in s) return s.refund.map((c) => ({ ...c }));
  const r = RECIPES[s.recipe];
  return r ? r.cost.map((c) => ({ ...c })) : null;
}
var propTile = (p) => ({ tx: Math.floor(p.x / TS), ty: Math.floor((p.y - 1) / TS) });
function deconstructCheck(_w, a, area, propId) {
  const p = propId ? area.prop(propId) : void 0;
  if (!p) return { ok: false, reason: "none" };
  if (!capable(a, "build") || !powered(a)) return { ok: false, reason: "fixed", prop: p };
  const refund = salvageOf(p);
  if (!refund) return { ok: false, reason: "fixed", prop: p };
  if (p.item && !p.taken && isCritical(p.item)) return { ok: false, reason: "holds", prop: p, item: p.item };
  const critical = p.inventory?.find((s) => s && isCritical(s.item));
  if (critical) return { ok: false, reason: "holds", prop: p, item: critical.item };
  const t = propTile(p);
  if (!inReach(a, t.tx, t.ty)) return { ok: false, reason: "reach", prop: p };
  return { ok: true, prop: p, refund };
}
function applyDeconstruct(w, a, area, propId) {
  const chk = deconstructCheck(w, a, area, propId);
  if (!chk.ok) {
    emit(w, { t: "message", text: deconMessage(chk) });
    return;
  }
  const p = chk.prop;
  const held = p.item && !p.taken ? p.item : void 0;
  const contents = p.inventory?.flatMap((s) => s ? [{ ...s }] : []) ?? [];
  area.removeProp(p.id);
  for (const s of contents) {
    const spot = dropSpot(area, a, actorBoxes(w, area.id, a.id)) ?? a;
    spawnLoose(area, s.item, s.n, spot.x, spot.y);
  }
  if (held) {
    const spot = dropSpot(area, a, actorBoxes(w, area.id, a.id));
    const x = spot ? spot.x : a.x, y = spot ? spot.y : a.y;
    spawnLoose(area, held, 1, x, y);
    emit(w, { t: "itemDropped", actor: a.id, item: held, n: 1, x, y, reason: "overflow" });
  }
  for (const c of chk.refund) giveItem(w, a, c.item, c.n);
  emit(w, { t: "deconstructed", actor: a.id, prop: p.id, kind: p.kind, x: p.x, y: p.y });
  if (capable(a, "scan")) {
    const fresh = learnPlans(w, a, p);
    if (fresh.length && a.id === w.playerId) emit(w, { t: "message", text: `PLAN LEARNED: ${fresh[0][1].name}` });
  }
}

// src/game/sim/dialogue.ts
function npcActor(w, npcActorId) {
  const a = actorById(w, npcActorId);
  return a && a.kind === "npc" && npcDef(a.npc) ? a : void 0;
}
function currentSegment(w, listener, script) {
  return script.segments.find((s) => !hasFlag(w, s.done) && meets(w, listener, s.when)) ?? null;
}
function applyDialogueEffect(w, a, e, target) {
  switch (e.op) {
    case "talk": {
      const npc = target?.actorId ? npcActor(w, target.actorId) : void 0;
      if (!npc || npc.area !== a.area) break;
      const scriptId = npcDef(npc.npc).dialogue;
      const script = DIALOGUE[scriptId];
      if (!script) break;
      const seg = currentSegment(w, a, script);
      emit(w, { t: "talkedTo", actor: a.id, npc: npc.id });
      if (seg) emit(w, { t: "dialogue", actor: a.id, npc: npc.id, script: scriptId, segment: seg.id });
      else emit(w, { t: "message", text: script.idle });
      break;
    }
    case "npcAwake": {
      const f = npcFlag(e.npc, NPC_AWAKE);
      if (hasFlag(w, f) === e.awake) break;
      if (e.awake) setFlag(w, f);
      else clearFlag(w, f);
      emit(w, { t: "npcState", npc: e.npc, awake: e.awake });
      break;
    }
    case "repairEye":
      if (hasFlag(w, FLAGS.golemEye)) break;
      setFlag(w, FLAGS.golemEye);
      emit(w, { t: "eyeRepaired", actor: a.id, by: target?.actorId });
      break;
    case "npcGive":
      if (hasFlag(w, e.once)) break;
      setFlag(w, e.once);
      giveItem(w, a, e.item, 1);
      break;
    case "segmentDone":
      setFlag(w, e.flag);
      break;
  }
}

// src/game/sim/storage.ts
var packRef = (a) => ({ kind: "actor", id: a.id });
var storageRef = (area, id) => ({ kind: "prop", area, id });
function inventoryHandle(w, ref) {
  if (ref.kind === "actor") {
    const a = actorById(w, ref.id);
    if (!a) return null;
    const h2 = { ref, inventory: copySlots(a.inventory), capacity: capacity(w, a), commit: () => {
      a.inventory = copySlots(h2.inventory);
      for (const s of a.inventory) if (s) rememberItem(w, a, s.item);
    } };
    return h2;
  }
  const area = w.areas.get(ref.area), p = area?.prop(ref.id), cap = p && propDef(p.kind).storage?.slots;
  if (!area || !p?.inventory || cap === void 0) return null;
  const h = { ref, inventory: copySlots(p.inventory), capacity: cap, commit: () => area.setInventory(p.id, h.inventory) };
  return h;
}
function transferItems(w, from, to, item, n) {
  const same = from.kind === to.kind && from.id === to.id && (from.kind !== "prop" || to.kind !== "prop" || from.area === to.area);
  if (!Number.isSafeInteger(n) || n <= 0 || same) return 0;
  const src = inventoryHandle(w, from), dst = inventoryHandle(w, to);
  if (!src || !dst) return 0;
  const moved = Math.min(n, countItem(src, item), roomIn(dst.inventory, dst.capacity, item));
  if (!moved) return 0;
  removeItems(src, item, moved);
  insertItems(dst.inventory, dst.capacity, item, moved);
  src.commit();
  dst.commit();
  return moved;
}
function nearbyStorage(area, station, radius = 2) {
  const tx = Math.floor(station.x / TS), ty = Math.floor((station.y - 1) / TS);
  return area.props.filter((p) => p.inventory && Math.max(Math.abs(Math.floor(p.x / TS) - tx), Math.abs(Math.floor((p.y - 1) / TS) - ty)) <= radius).sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
}
function craftSources(w, a, station) {
  const pack = inventoryHandle(w, packRef(a));
  const area = w.areas.get(a.area);
  return [pack, ...area && station ? nearbyStorage(area, station).map((p) => inventoryHandle(w, storageRef(area.id, p.id))) : []].filter((h) => !!h);
}
function consumeInputs(sources, inputs) {
  const seen2 = /* @__PURE__ */ new Set();
  sources = sources.filter((h) => {
    const key = JSON.stringify([h.ref.kind, h.ref.kind === "prop" ? h.ref.area : null, h.ref.id]);
    if (seen2.has(key)) return false;
    seen2.add(key);
    return true;
  });
  const totals = /* @__PURE__ */ new Map();
  for (const c of inputs) {
    if (!Number.isSafeInteger(c.n) || c.n <= 0) return false;
    totals.set(c.item, (totals.get(c.item) ?? 0) + c.n);
  }
  for (const [item, n] of totals) if (sources.reduce((s, h) => s + countItem(h, item), 0) < n) return false;
  const dirty = /* @__PURE__ */ new Set();
  for (const [item, total] of totals) {
    let left = total;
    for (const h of sources) {
      const n = Math.min(left, countItem(h, item));
      if (n) {
        removeItems(h, item, n);
        dirty.add(h);
        left -= n;
      }
    }
  }
  for (const h of dirty) h.commit();
  return true;
}

// src/game/sim/crafting.ts
var CRAFT_TEXT = {
  unknown: "NOT YET LEARNED",
  cost: "NOT ENOUGH MATERIALS"
};
var CRAFT_LOCKED_TEXT = "YOU DON'T KNOW HOW TO CRAFT YET";
var CRAFT_GONE_TEXT = "THE BENCH IS GONE OR TOO FAR AWAY";
var craftLockedText = (station) => isStation(station) ? STATIONS[station].lockedText : CRAFT_LOCKED_TEXT;
var craftGoneText = (station) => isStation(station) && station !== "crafting" ? `THE ${STATIONS[station].name} IS GONE OR TOO FAR AWAY` : CRAFT_GONE_TEXT;
var validRecipe = (r) => !!ITEMS[r.output.item] && Number.isSafeInteger(r.output.n) && r.output.n > 0 && r.inputs.every((c) => !!ITEMS[c.item] && Number.isSafeInteger(c.n) && c.n > 0) && (r.also ?? []).every((c) => !!ITEMS[c.item] && Number.isSafeInteger(c.n) && c.n > 0) && (r.tools ?? []).every((item) => !!ITEMS[item] && !r.inputs.some((c) => c.item === item));
function craftReason(e) {
  if (e.status === "ok") return "";
  if (e.status === "tools") return `NEED THE ${e.tools.filter((t) => !t.have).map((t) => ITEM_NAMES[t.item]).join(" + ")}`;
  return CRAFT_TEXT[e.status];
}
var craftLocked = (w, a, station) => !meets(w, a, STATION_REQUIRES[station]);
function craftEntry(w, a, r, station) {
  const sources = craftSources(w, a, station);
  const totals = /* @__PURE__ */ new Map();
  for (const c of r.inputs) totals.set(c.item, (totals.get(c.item) ?? 0) + c.n);
  const lines = [...totals].map(([item, need]) => ({ item, need, have: sources.reduce((s, h) => s + countItem(h, item), 0) }));
  const tools = (r.tools ?? []).map((item) => ({ item, have: hasItem(a, item) }));
  const status = !validRecipe(r) || !meets(w, a, r.requires) ? "unknown" : !tools.every((t) => t.have) ? "tools" : lines.every((l) => l.have >= l.need) ? "ok" : "cost";
  return { recipe: r, status, lines, tools };
}
function orderCraft(w, a, station, id, propId, list = CRAFT_RECIPES) {
  const opening = a.task?.fired && a.task.effect?.op === "useStation";
  if (a.task && !opening || !capable(a, "craft") || !powered(a)) return false;
  if (craftLocked(w, a, station)) {
    actorMessage(w, a, craftLockedText(station));
    return false;
  }
  const r = craftRecipesFor(station, list).find((x) => x.id === id);
  if (!r) return false;
  const p = propId ? w.areas.get(a.area)?.prop(propId) : void 0;
  const e = craftEntry(w, a, r, p);
  if (e.status !== "ok") {
    actorMessage(w, a, craftReason(e));
    return false;
  }
  if (propId && (!p || propDef(p.kind).station !== station || !atStation(a, p) || !lineOfSight(w.areas.get(a.area), a, p))) {
    actorMessage(w, a, craftGoneText(station));
    return false;
  }
  if (p) faceTo3(a, p.x, p.y - 4);
  beginTask(a, { kind: "craft", dur: r.dur ?? CRAFT_DUR, effect: { op: "craft", recipe: r.id } }, { kind: "craft", x: p?.x ?? a.x, y: p?.y ?? a.y, propId: p?.id });
  return true;
}
function applyCraft(w, a, area, recipe, propId, list = CRAFT_RECIPES) {
  if (area.id !== a.area || !capable(a, "craft") || !powered(a)) return false;
  const r = list.find((x) => x.id === recipe);
  if (!r) return false;
  if (propId) {
    const p2 = area.prop(propId);
    if (!p2 || propDef(p2.kind).station !== r.station || !atStation(a, p2) || !lineOfSight(area, a, p2)) {
      actorMessage(w, a, craftGoneText(r.station));
      return false;
    }
  }
  if (craftLocked(w, a, r.station)) {
    actorMessage(w, a, craftLockedText(r.station));
    return false;
  }
  const p = propId ? area.prop(propId) : void 0;
  const e = craftEntry(w, a, r, p);
  if (e.status !== "ok") {
    actorMessage(w, a, craftReason(e));
    return false;
  }
  if (a.task?.jobId !== void 0 && !outputFits(w, a, r)) return false;
  if (!consumeInputs(craftSources(w, a, p), r.inputs)) return false;
  for (const c of r.inputs) rememberItem(w, a, c.item);
  giveItem(w, a, r.output.item, r.output.n);
  for (const x of r.also ?? []) giveItem(w, a, x.item, x.n);
  emit(w, { t: "crafted", actor: a.id, recipe: r.id, item: r.output.item, n: r.output.n });
  return true;
}
var atStation = (a, p) => Math.hypot(a.x - p.x, a.y - p.y) <= propReach(p.kind) + 8;
function outputFits(w, a, r) {
  const pack = { inventory: copySlots(a.inventory) };
  for (const c of r.inputs) removeItems(pack, c.item, Math.min(c.n, countItem(pack, c.item)));
  return roomIn(pack.inventory, capacity(w, a), r.output.item) >= r.output.n;
}

// src/game/sim/harvesting.ts
function harvestReach(area, x, y, radius) {
  const found = [];
  for (const p of area.props) {
    if (p.taken || !HARVEST[p.kind]) continue;
    const b = p.box ?? [p.x, p.y, p.x, p.y];
    const dx = Math.max(b[0] - x, 0, x - b[2]), dy = Math.max(b[1] - y, 0, y - b[3]);
    const d2 = dx * dx + dy * dy;
    if (d2 <= radius * radius) found.push({ p, d2 });
  }
  return found.sort((a, b) => a.d2 - b.d2 || (a.p.id < b.p.id ? -1 : 1)).map((f) => f.p);
}
function harvestStep(a, p) {
  const def = HARVEST[p.kind], power = harvestPower(a) * (1 + toolBonus(a, def?.tool));
  if (!def || p.taken || !Number.isFinite(power) || power <= 0) return null;
  const before = Math.min(def.hp, p.dmg);
  const after = Math.min(def.hp, Math.round((before + power) * 1e9) / 1e9);
  if (after <= before) return null;
  const depleted = after >= def.hp, rewards = /* @__PURE__ */ new Map();
  const units = Math.floor(after * def.perHit.n + 1e-9) - Math.floor(before * def.perHit.n + 1e-9);
  if (units) rewards.set(def.perHit.item, units);
  if (depleted && def.final) rewards.set(def.final.item, (rewards.get(def.final.item) ?? 0) + def.final.n);
  return { damage: after - before, depleted, rewards: [...rewards].map(([item, n]) => ({ item, n })) };
}

// src/game/content/monologue.ts
var THOUGHTS = {
  // ---- the opening (content/cutscenes.ts fires these by id)
  "intro.assessing": { text: "ASSESSING..." },
  "intro.damage": { text: "MILD DAMAGE DETECTED.", tone: "warn" },
  "intro.arm": { text: "MISSING LEFT ARM.", tone: "warn" },
  "intro.directive": { text: "PRIME DIRECTIVE: NONE.", tone: "void", pace: 0.7 },
  // ---- play
  /** Golem vision (Z): a buildable's pattern was learned. Each analysis emits one `analyzed` per plan, hence the cooldown. */
  "vision.analyzed": { text: "OBJECT ANALYZED.", on: { event: "analyzed" }, once: false, cooldown: 1 },
  // ---- power. Only `dormantTouched` (E on a worker that has never had a core) diagnoses a body with no core:
  // `subjectNoPower` holds for the unpowered guardian too, and E on it is talk, so a broader trigger would say
  // this about the guardian. Once a core has been slotted in, the body's screen opens even with the core out
  // again, and the golem no longer says it.
  /** E on the dormant worker golem (or any worker) that has never held a core: its screen stays shut. */
  "golem.dormant": { text: "INTEGRITY INTACT, MISSING POWER SOURCE.", on: { event: "dormantTouched" }, if: ["subjectNoPower"], once: false, cooldown: 2 },
  /**
   * A body holding a core of its family too weak for it (the guardian given the ruby core): when the core goes in,
   * and on every interaction after. `talkedTo` fires on every talk, segment or idle line, unlike `dialogue`.
   */
  "golem.underpowered": {
    text: "INSUFFICIENT POWER SOURCE.",
    tone: "warn",
    once: false,
    cooldown: 2,
    if: ["subjectWeakPower"],
    on: [{ event: "manageActor" }, { event: "talkedTo" }, { event: "coreSlotted", match: { inserted: true } }]
  }
};
THOUGHTS["town.arrive"] = { text: "ON RECORD: A VILLAGE. OBSERVED: A TOWN.", on: { event: "portal", match: { fromArea: "surface", toArea: "town" } } };
var thoughtTriggers = (l) => !l.on ? [] : Array.isArray(l.on) ? l.on : [l.on];
THOUGHTS["cross.engage"] = { text: "TRANSLOCATION ENGAGED." };
THOUGHTS["cross.transit"] = { text: "TRANSLOCATING..." };
THOUGHTS["cross.anchor"] = { text: "DESTINATION ANCHOR: DEGRADED.", tone: "warn" };
THOUGHTS["cross.rewrite"] = { text: "REWRITING ANCHOR FROM SOURCE..." };
THOUGHTS["cross.arrived"] = { text: "ANCHOR RESTORED. ARRIVAL CONFIRMED." };
THOUGHTS["cross.observed"] = { text: "ON RECORD: THE UPPER HALLS. OBSERVED: FOREST." };
THOUGHTS["cross.light"] = { text: "LIGHT LEVEL RISING.", tone: "void", pace: 0.7 };
THOUGHTS["sky.dusk"] = { text: "LIGHT LEVEL FALLING. NIGHT CYCLE.", on: { event: "dayPhase", match: { phase: "dusk" } }, if: ["underSky"] };

// src/game/sim/power.ts
var coreSeated = (w, a) => w.flags.has(npcFlag(a.id, CORE_SEATED));
var canManage = (w, a) => !actorDef(a).power || !!a.powerCore || coreSeated(w, a);
function coreCheck(a, item) {
  const core = POWER_CORES[item], req = actorDef(a).power;
  const accepts = !!core && !!req && core.family === req.family;
  return { accepts, sufficient: accepts && core.tier >= req.tier };
}
function insertPowerCore(w, source, target, item) {
  if (source.area !== target.area || Math.hypot(source.x - target.x, source.y - target.y) > actorDef(target).body.reach + 8) return false;
  if (!lineOfSight(areaOf(w, source), source, target)) return false;
  if (!coreCheck(target, item).accepts || countItem(source, item) < 1) return false;
  const old = target.powerCore;
  removeItems(source, item);
  target.powerCore = item;
  w.flags.add(npcFlag(target.id, CORE_SEATED));
  if (old) giveItem(w, source, old);
  emit(w, { t: "powerChanged", actor: target.id, powered: powered(target) });
  return true;
}
function removePowerCore(w, source, target) {
  if (!target.powerCore || source.area !== target.area || Math.hypot(source.x - target.x, source.y - target.y) > actorDef(target).body.reach + 8) return false;
  if (!lineOfSight(areaOf(w, source), source, target)) return false;
  const old = target.powerCore;
  target.powerCore = null;
  w.flags.add(npcFlag(target.id, CORE_SEATED));
  giveItem(w, source, old);
  emit(w, { t: "powerChanged", actor: target.id, powered: powered(target) });
  return true;
}
function coreActionFor(a, target) {
  if (!actorDef(target).power) return { op: "none", reason: "noSocket" };
  if (target.powerCore) return { op: "remove", item: target.powerCore };
  const slot = a.inventory.find((s) => !!s && coreCheck(target, s.item).accepts);
  return slot ? { op: "insert", item: slot.item } : { op: "none", reason: "noCore" };
}
var CORE_TEXT = {
  reach: "STEP UP TO IT TO REACH ITS CORE",
  noCore: "YOU CARRY NO CORE THAT FITS IT",
  empty: "IT HOLDS NO CORE"
};
function applySlotCore(w, a, target, item) {
  if (!target) return false;
  const old = target.powerCore;
  if (!item && !old) {
    actorMessage(w, a, CORE_TEXT.empty);
    return false;
  }
  const ok = item ? insertPowerCore(w, a, target, item) : removePowerCore(w, a, target);
  if (!ok) {
    actorMessage(w, a, item && countItem(a, item) < 1 ? CORE_TEXT.noCore : CORE_TEXT.reach);
    return false;
  }
  emit(w, { t: "coreSlotted", actor: a.id, target: target.id, item: item ?? old, inserted: !!item, powered: powered(target) });
  return true;
}

// src/game/sim/monologue.ts
function thoughtSubject(c) {
  const e = c.event;
  const id = (e && (typeof e.target === "string" ? e.target : typeof e.npc === "string" ? e.npc : e.t === "powerChanged" ? e.actor : void 0)) ?? c.target?.actorId;
  return typeof id === "string" ? actorById(c.w, id) : void 0;
}
var THOUGHT_CONDITIONS = {
  /** The thinker stands under the open sky. */
  underSky: (c) => !!c.w.areas.get(c.a.area)?.base.outdoor,
  /** The subject has a body that needs power and no core in it. */
  subjectNoPower: (c) => {
    const s = thoughtSubject(c);
    return !!s && !!actorDef(s).power && !s.powerCore;
  },
  /** The subject holds a core of its family that is too weak for its body. */
  subjectWeakPower: (c) => {
    const s = thoughtSubject(c);
    if (!s?.powerCore) return false;
    const chk = coreCheck(s, s.powerCore);
    return chk.accepts && !chk.sufficient;
  }
};
function thoughtBlocked(w, a, id, ctx = {}) {
  const line = THOUGHTS[id];
  if (!line) return "unknown";
  if (a.id !== w.playerId) return "notThinker";
  if (line.once !== false && w.monologue.said.includes(id)) return "said";
  if ((w.monologue.ready[id] ?? -Infinity) > w.time) return "cooldown";
  if (!meets(w, a, line.when)) return "when";
  for (const name of line.if ?? []) {
    const cond = THOUGHT_CONDITIONS[name];
    if (!cond) return `unknownCondition:${name}`;
    if (!cond({ w, a, ...ctx })) return `if:${name}`;
  }
  return void 0;
}
function think(w, a, id, ctx = {}) {
  if (thoughtBlocked(w, a, id, ctx)) return false;
  const line = THOUGHTS[id];
  if (line.once !== false) w.monologue.said.push(id);
  if (line.cooldown) w.monologue.ready[id] = w.time + line.cooldown;
  emit(w, { t: "thought", actor: a.id, line: id });
  return true;
}
var seen = /* @__PURE__ */ new WeakSet();
var playersEvent = (w, e) => !("actor" in e) || typeof e.actor !== "string" || e.actor === w.playerId;
function matches(e, trigger) {
  if (e.t !== trigger.event) return false;
  const rec = e;
  for (const [k, v] of Object.entries(trigger.match ?? {})) if (rec[k] !== v) return false;
  return true;
}
function reactToEvents(w) {
  if (!w.events.length) return;
  const pl = player(w);
  if (!pl) return;
  for (let i = 0; i < w.events.length; i++) {
    const e = w.events[i];
    if (seen.has(e)) continue;
    seen.add(e);
    if (e.t === "thought" || !playersEvent(w, e)) continue;
    for (const [id, line] of Object.entries(THOUGHTS)) {
      if (thoughtTriggers(line).some((tr) => matches(e, tr))) think(w, pl, id, { event: e });
    }
  }
}

// src/game/sim/digging.ts
function digSpot(area, propId) {
  const prop = propId ? area.prop(propId) : void 0, def = prop && DIG_SITES[prop.kind];
  if (!prop || !def || prop.open) return null;
  const layer = digLayerAt(def, prop.dmg);
  return layer ? { prop, def, layer } : null;
}
function digRules(area, propId) {
  const s = digSpot(area, propId);
  return s ? DIG_MATERIALS[s.layer.material].rules : null;
}
function applyDig(w, a, area, target) {
  const spot = digSpot(area, target?.propId);
  if (!spot || a.area !== area.id) return false;
  const { prop, def, layer } = spot, mat = DIG_MATERIALS[layer.material];
  if (Math.hypot(prop.x - a.x, prop.y + def.dy - a.y) > def.reach + 12) return false;
  const power = toolBonus(a, mat.tool);
  if (power <= 0) {
    actorMessage(w, a, `THE ${mat.name} NEEDS A ${TOOL_TYPES[mat.tool].full} HEAD ON YOUR ARM`);
    return false;
  }
  const work2 = Math.min(power, layer.left);
  const units = Math.floor(layer.into + work2 + 1e-9) - Math.floor(layer.into + 1e-9);
  const done = Math.round((prop.dmg + work2) * 1e9) / 1e9;
  const through = done >= digTotal(def) - 1e-9;
  if (units > 0) giveItem(w, a, mat.yields, units);
  area.setPropState(prop.id, through ? { dmg: done, open: true, lit: true } : { dmg: done });
  const after = through ? null : digLayerAt(def, done);
  emit(w, {
    t: "dug",
    actor: a.id,
    prop: prop.id,
    x: prop.x,
    y: prop.y + def.dy,
    material: layer.material,
    n: units,
    next: after && after.index !== layer.index ? after.material : void 0,
    opened: through
  });
  if (through) {
    area.touch("layout");
    evict(w, area, prop);
    if (def.opens) openEntrance(w, a, def.opens);
  }
  return true;
}
function evict(w, area, p) {
  const b = p.box;
  if (!b) return;
  for (const o of w.actors) {
    if (o.area !== area.id) continue;
    const [bw, bh] = actorDef(o).body.box;
    if (!(o.x + bw / 2 > b[0] && o.x - bw / 2 < b[2] && o.y > b[1] && o.y - bh < b[3])) continue;
    const spot = nearestFree(area, o.x, b[3] + bh + 1, actorBoxes(w, area.id, o.id), [bw, bh]);
    if (spot) {
      o.x = spot.x;
      o.y = spot.y;
      o.vx = 0;
      o.vy = 0;
    }
  }
}
function openEntrance(w, by, id) {
  const e = ENTRANCES[id];
  if (!e || hasFlag(w, e.flag)) return false;
  setFlag(w, e.flag);
  const below = getArea(w, e.below.area), c = e.below.clear;
  for (let y = c.y; y < c.y + c.h; y++) for (let x = c.x; x < c.x + c.w; x++) if (below.tile(x, y) !== T.FLOOR) below.setTile(x, y, T.FLOOR);
  const x0 = c.x * TS - 8, x1 = (c.x + c.w) * TS + 8, y0 = c.y * TS - 4, y1 = (c.y + c.h) * TS + 8;
  for (const p of [...below.props]) if (e.below.removes.includes(p.kind) && p.x >= x0 && p.x <= x1 && p.y > y0 && p.y <= y1) below.removeProp(p.id);
  for (const p of below.props) if (p.kind === e.below.lights && !p.lit) below.setPropState(p.id, { lit: true });
  emit(w, { t: "entranceOpened", actor: by.id, entrance: id });
  return true;
}

// src/game/sim/tasks.ts
function endScanFor(a, spec) {
  if (a.mode === "scan" && spec.effect && VISION_OFF_OPS.includes(spec.effect.op)) a.mode = "normal";
}
function beginTask(a, spec, target) {
  a.task = { ...spec, t: 0, fired: false, target, area: a.area };
  a.vx = 0;
  a.vy = 0;
  endScanFor(a, spec);
}
function tickTask(w, a, dt) {
  if (!a.task && a.queue.length) {
    a.task = a.queue.shift();
    a.vx = 0;
    a.vy = 0;
    endScanFor(a, a.task);
  }
  const task = a.task;
  if (!task) return;
  if (task.jobId !== void 0 && (!powered(a) || a.job?.status === "paused")) return;
  if (task.area && task.area !== a.area) {
    a.task = null;
    return;
  }
  task.t += dt;
  emit(w, { t: "taskTick", actor: a.id, task, dt });
  if (!task.fired && task.t >= TASK_KINDS[task.kind].fire(task.dur)) {
    task.fired = true;
    const ok = task.effect ? applyEffect(w, a, task.effect, task.target) : true;
    if (task.jobId !== void 0 && a.job?.id === task.jobId) a.job.result = ok !== false;
  }
  if (task.t >= task.dur && a.task === task) a.task = null;
}
function strikePoint(a) {
  const fx = a.facing === "left" ? -1 : a.facing === "right" ? 1 : 0;
  const fy = a.facing === "up" ? -1 : a.facing === "down" ? 1 : 0;
  return { x: a.x + fx * 10, y: a.y + (fy > 0 ? 3 : fy < 0 ? -7 : 0) };
}
function slamReach(area, x, y, radius) {
  const found = /* @__PURE__ */ new Map();
  const tx0 = Math.floor((x - radius) / TS), tx1 = Math.floor((x + radius) / TS);
  const ty0 = Math.floor((y - radius) / TS), ty1 = Math.floor((y + radius) / TS);
  for (let ty = ty0; ty <= ty1; ty++)
    for (let tx = tx0; tx <= tx1; tx++) {
      const tile = area.tile(tx, ty), def = TILE_INTERACT[tile];
      if (!def || !SLAM_RULES[def.kind]) continue;
      const dx = Math.max(tx * TS - x, 0, x - (tx + 1) * TS), dy = Math.max(ty * TS - y, 0, y - (ty + 1) * TS);
      const d2 = dx * dx + dy * dy;
      if (d2 > radius * radius) continue;
      let ay = ty;
      if (def.anchorTopOfRun) while (area.tile(tx, ay - 1) === tile) ay--;
      const key = `${tx},${ay}`, prev = found.get(key);
      if (!prev) found.set(key, { target: { kind: def.kind, x: tx * TS + def.dx, y: ay * TS + def.dy, tx, ty: ay }, d2 });
      else if (d2 < prev.d2) prev.d2 = d2;
    }
  return [...found.values()].sort((p, q) => p.d2 - q.d2).map((f) => f.target);
}
function faceTo3(a, x, y) {
  const dx = x - a.x, dy = y - (a.y - 4);
  a.facing = Math.abs(dx) > Math.abs(dy) ? dx > 0 ? "right" : "left" : dy > 0 ? "down" : "up";
}
function schedule(w, delay, actor, effect, area = actor.area) {
  w.scheduled.push({ at: w.time + delay, actor: actor.id, area, effect });
}
function runScheduled(w) {
  if (!w.scheduled.length) return;
  const due = w.scheduled.filter((s) => s.at <= w.time);
  if (!due.length) return;
  w.scheduled = w.scheduled.filter((s) => s.at > w.time);
  for (const s of due) {
    const a = actorById(w, s.actor);
    if (a) applyEffect(w, a, s.effect, void 0, s.area);
  }
}
function applyEffect(w, a, e, target, areaId) {
  const area = areaId ? getArea(w, areaId) : areaOf(w, a);
  switch (e.op) {
    case "cue":
      emit(w, { t: "cue", cue: e.cue, x: target?.x ?? a.x, y: target?.y ?? a.y, actor: a.id });
      break;
    case "message":
      actorMessage(w, a, e.text);
      if (e.cue) emit(w, { t: "cue", cue: e.cue, x: target?.x ?? a.x, y: target?.y ?? a.y, actor: a.id });
      break;
    case "examine": {
      const p = target?.propId ? area.prop(target.propId) : void 0;
      const text2 = p && propDef(p.kind).examine;
      if (text2) emit(w, { t: "message", text: text2 });
      break;
    }
    case "takeLoose": {
      const l = target?.looseId ? area.looseItem(target.looseId) : void 0;
      if (!l || l.taken) break;
      const def = ITEMS[l.item];
      if (def.equip) {
        area.takeLoose(l.id);
        emit(w, { t: "itemGained", actor: a.id, item: l.item, stored: false });
        beginTask(a, { kind: def.equip.task.kind, dur: def.equip.task.dur, effect: { op: "equip", item: l.item } });
        break;
      }
      const n = l.n ?? 1;
      const left = addItems(w, a, l.item, n);
      if (left === n) {
        emit(w, { t: "packFull", actor: a.id, item: l.item });
        break;
      }
      area.setLooseCount(l.id, left);
      emit(w, { t: "itemGained", actor: a.id, item: l.item, stored: true, n: n - left });
      if (left > 0) emit(w, { t: "packFull", actor: a.id, item: l.item });
      break;
    }
    case "takePropItem": {
      const p = target?.propId ? area.prop(target.propId) : void 0;
      if (!p || p.taken || !p.item) break;
      const def = ITEMS[p.item];
      if (def.equip) {
        area.setPropState(p.id, { taken: true });
        emit(w, { t: "itemGained", actor: a.id, item: p.item, stored: false });
        beginTask(a, { kind: def.equip.task.kind, dur: def.equip.task.dur, effect: { op: "equip", item: p.item } });
        break;
      }
      if (addItems(w, a, p.item, 1) > 0) {
        emit(w, { t: "packFull", actor: a.id, item: p.item });
        break;
      }
      area.setPropState(p.id, { taken: true });
      emit(w, { t: "itemGained", actor: a.id, item: p.item, stored: true, n: 1 });
      break;
    }
    case "openContainer": {
      const p = target?.propId ? area.prop(target.propId) : void 0;
      if (!p || p.open) break;
      const item = p.item;
      area.setPropState(p.id, { open: true, item: null });
      emit(w, { t: "containerOpened", x: p.x, y: p.y });
      if (item) schedule(w, 0.25, a, { op: "grantItem", item }, area.id);
      break;
    }
    case "grantItem":
      giveItem(w, a, e.item, 1);
      break;
    case "equip": {
      const def = ITEMS[e.item];
      if (def.equip) setActorFlag(a, def.equip.flag);
      emit(w, { t: "equipped", actor: a.id, item: e.item });
      break;
    }
    case "unlockTile": {
      if (target?.tx === void 0 || target.ty === void 0) break;
      const def = TILE_INTERACT[area.tile(target.tx, target.ty)];
      if (e.consume) removeItems(a, e.consume, 1);
      area.setTile(target.tx, target.ty, T.FLOOR);
      if (def?.openDecal) area.addDecal({ kind: def.openDecal.kind, x: target.tx * TS + def.openDecal.dx, y: target.ty * TS + def.openDecal.dy, v: 0 });
      emit(w, { t: "doorUnlocked", x: target.x, y: target.y });
      break;
    }
    case "breakTile":
      if (target?.tx !== void 0 && target.ty !== void 0) breakTileRun(w, area, target);
      break;
    case "placeCore": {
      const r = area.ritual;
      if (!r) break;
      removeItems(a, e.consume, 1);
      area.updateRitual({ core: true });
      emit(w, { t: "corePlaced" });
      checkRune(w, area);
      break;
    }
    case "carveGap": {
      const r = area.ritual;
      if (!r) break;
      area.updateRitual({ carved: true });
      emit(w, { t: "carved" });
      checkRune(w, area);
      break;
    }
    case "takeGlyph": {
      const r = area.ritual;
      const i = target?.socket;
      if (!r || i === void 0 || r.sockets[i] < 0) break;
      const g = r.sockets[i];
      const sockets = [...r.sockets], wrong = [...r.wrong];
      sockets[i] = -1;
      wrong[i] = false;
      area.updateRitual({ sockets, wrong });
      giveItem(w, a, glyphItem(g), 1);
      if (r.active) deactivate(w, area);
      break;
    }
    case "checkRune":
      checkRune(w, area);
      break;
    case "drop": {
      const s = a.inventory[e.slot];
      if (!s) break;
      if (!isDroppable(s.item)) {
        emit(w, { t: "message", text: "THAT IS TOO IMPORTANT TO DROP" });
        break;
      }
      const spot = dropSpot(area, a, actorBoxes(w, area.id, a.id));
      if (!spot) {
        emit(w, { t: "message", text: "NO ROOM TO DROP IT HERE" });
        break;
      }
      const n = Math.min(e.n, s.n), item = s.item;
      s.n -= n;
      if (s.n === 0) a.inventory[e.slot] = null;
      spawnLoose(area, item, n, spot.x, spot.y);
      emit(w, { t: "itemDropped", actor: a.id, item, n, x: spot.x, y: spot.y, reason: "drop" });
      break;
    }
    case "wear": {
      const r = applyWear(w, a, e.slot, e.into);
      if (!r.ok && r.reason !== "empty") emit(w, { t: "message", text: gearRefusal(r) });
      break;
    }
    case "takeOff": {
      const r = applyTakeOff(w, a, e.gear);
      if (!r.ok && r.reason !== "empty") emit(w, { t: "message", text: gearRefusal(r) });
      break;
    }
    case "slam": {
      const p = strikePoint(a);
      const hits = slamReach(area, p.x, p.y, SLAM_RADIUS).map((t) => ({ t, rule: SLAM_RULES[t.kind].find((r) => meets(w, a, r.when)) })).filter((h) => h.rule);
      const harvestables = harvestReach(area, p.x, p.y, SLAM_RADIUS);
      emit(w, { t: "slam", actor: a.id, x: p.x, y: p.y, hit: hits.length > 0 || harvestables.length > 0 });
      for (const h of hits) applyEffect(w, a, h.rule.then, h.t);
      for (const hp of harvestables) harvestProp(w, a, area, hp);
      break;
    }
    case "withstand":
      emit(w, { t: "withstood", actor: a.id, x: target?.x ?? a.x, y: target?.y ?? a.y, tx: target?.tx, ty: target?.ty });
      if (e.text) emit(w, { t: "message", text: e.text });
      break;
    case "travel":
      return !!target?.propId && travel(w, a, area, target.propId, e.destination);
    case "analyze":
      return applyAnalysis(w, a, area, target);
    case "deposit": {
      const p = target?.propId ? area.prop(target.propId) : void 0;
      if (!p?.inventory || a.area !== area.id || Math.hypot(a.x - p.x, a.y - p.y) > propReach(p.kind) + 8) return false;
      const n = transferItems(w, packRef(a), storageRef(area.id, p.id), e.item, e.n);
      if (a.job && a.task?.jobId === a.job.id) a.job.completed += n;
      return n > 0;
    }
    case "useStorage":
      if (target?.propId && area.prop(target.propId)?.inventory) emit(w, { t: "openStorage", actor: a.id, prop: target.propId });
      break;
    case "manageActor":
      if (target?.actorId) {
        const body = actorById(w, target.actorId);
        if (body) emit(w, { t: canManage(w, body) ? "manageActor" : "dormantTouched", actor: a.id, target: body.id });
      }
      break;
    case "slotCore":
      return applySlotCore(w, a, target?.actorId ? actorById(w, target.actorId) : void 0, e.item);
    case "harvest": {
      const p = target?.propId ? area.prop(target.propId) : void 0;
      if (!p || Math.hypot(p.x - a.x, p.y - a.y) > propReach(p.kind) + 8 || !lineOfSight(area, a, p)) return false;
      const job = a.job && a.task?.jobId === a.job.id && a.job.kind === "gatherDeposit" && a.job.args.storage === null ? a.job : null;
      const want = job ? job.args.resource : null, before = want ? countItem(a, want) : 0;
      const ok = harvestProp(w, a, area, p);
      if (job && want) job.completed = Math.min(job.args.repeat === true ? Infinity : Number(job.args.amount), job.completed + Math.max(0, countItem(a, want) - before));
      return ok;
    }
    case "dig":
      return applyDig(w, a, area, target);
    case "regrow":
      area.setPropState(e.prop, { taken: false, dmg: 0 });
      break;
    case "build":
      applyBuild(w, a, area, e.recipe, e.tx, e.ty);
      break;
    case "deconstruct":
      applyDeconstruct(w, a, area, target?.propId);
      break;
    case "craft":
      return applyCraft(w, a, area, e.recipe, target?.propId);
    case "useStation": {
      const p = target?.propId ? area.prop(target.propId) : void 0;
      const station = p && propDef(p.kind).station;
      if (p && station) emit(w, { t: "openStation", actor: a.id, prop: p.id, station });
      break;
    }
    case "learn":
      if (!hasFlag(w, e.flag)) {
        setFlag(w, e.flag);
        emit(w, { t: "learned", flag: e.flag });
      }
      break;
    case "think":
      return think(w, a, e.line, { target });
    case "folkTalk":
      folkTalk(w, a, target?.actorId);
      break;
    case "keeperTalk":
      keeperTalk(w, a, target?.actorId);
      break;
    case "talk":
    case "npcAwake":
    case "repairEye":
    case "npcGive":
    case "segmentDone":
      applyDialogueEffect(w, a, e, target);
      break;
  }
}
function harvestProp(w, a, area, p) {
  const def = HARVEST[p.kind];
  if (!def || p.taken || !capable(a, "harvest")) return false;
  const hit = harvestStep(a, p);
  if (!hit) return false;
  area.damageProp(p.id, hit.damage);
  for (const reward of hit.rewards) giveItem(w, a, reward.item, reward.n);
  if (hit.depleted) {
    area.setPropState(p.id, { taken: true });
    if (def.regrow) schedule(w, def.regrow, a, { op: "regrow", prop: p.id }, area.id);
  }
  emit(w, { t: "harvestHit", actor: a.id, prop: p.id, kind: p.kind, x: p.x, y: p.y, depleted: hit.depleted });
  return true;
}
function breakTileRun(w, area, target) {
  const tx = target.tx, ty = target.ty;
  const t0 = area.tile(tx, ty);
  const def = TILE_INTERACT[t0];
  for (let y = ty; area.tile(tx, y) === t0; y++) area.setTile(tx, y, T.FLOOR);
  const d = def?.breakDebris;
  if (d) {
    for (let i = 0; i < d.count; i++)
      area.addDecal({ kind: "debris", x: (tx + d.dxTiles) * TS + w.rng.next() * d.w, y: (ty + d.dyTiles) * TS + w.rng.next() * d.h, v: w.rng.next() * 4 | 0 });
  }
  emit(w, { t: "wallBroken", x: target.x, y: target.y });
}

// src/game/sim/interact.ts
var cache2 = /* @__PURE__ */ new WeakMap();
function interactables(area) {
  const c = cache2.get(area);
  if (c && c.rev === area.interactionRevision) return c.list;
  const list = deriveInteractables(area);
  cache2.set(area, { rev: area.interactionRevision, list });
  return list;
}
function deriveInteractables(area) {
  const I = [];
  for (const p of area.props) {
    if (p.kind === "pedestal") continue;
    const def = propDef(p.kind);
    if (def.rune) {
      if (!(area.ritual && !area.ritual.core)) I.push({ kind: "rune", x: p.x, y: p.y, r: 18, propId: p.id });
      continue;
    }
    if (HARVEST[p.kind] && !p.taken) continue;
    const dig = DIG_SITES[p.kind];
    if (dig) {
      if (!p.open && digLayerAt(dig, p.dmg)) I.push({ kind: "dig", x: p.x, y: p.y + dig.dy, r: dig.reach, propId: p.id });
      continue;
    }
    if (def.storage) {
      I.push({ kind: "storage", x: p.x, y: p.y + 2, r: propReach(p.kind) + 2, propId: p.id });
      continue;
    }
    if (def.station && !(p.item && !p.container && !p.taken)) {
      I.push({ kind: "station", x: p.x, y: p.y + 2, r: propReach(p.kind) + 2, propId: p.id });
      continue;
    }
    if (def.examine) {
      I.push({ kind: "examine", x: p.x, y: p.y + 2, r: propReach(p.kind) + 4, propId: p.id });
      continue;
    }
    const r2 = propReach(p.kind);
    if (p.container && !p.open) I.push({ kind: "container", x: p.x, y: p.y + 2, r: r2, propId: p.id, itemZ: p.itemZ, hasItem: !!p.item });
    else if (p.item && !p.container && !p.taken) I.push({ kind: "propItem", x: p.x, y: p.y + 2, r: r2, propId: p.id, itemZ: p.itemZ, hasItem: true });
  }
  for (const l of area.loose) if (!l.taken) I.push({ kind: "item", x: l.x, y: l.y, r: 16, looseId: l.id, hasItem: true });
  for (let ty = 0; ty < area.h; ty++)
    for (let tx = 0; tx < area.w; tx++) {
      const t = area.grid[ty * area.w + tx];
      const def = TILE_INTERACT[t];
      if (!def) continue;
      if (def.anchorTopOfRun && area.tile(tx, ty - 1) === t) continue;
      I.push({ kind: def.kind, x: tx * TS + def.dx, y: ty * TS + def.dy, r: def.r, tx, ty });
    }
  const r = area.ritual;
  if (r) {
    const c = area.ritualPos;
    socketPositions(c).forEach((s, i) => I.push({ kind: "socket", x: s.x, y: s.y + RITUAL_SPOTS.socket.dy, r: RITUAL_SPOTS.socket.r, socket: i }));
    if (!r.core) I.push({ kind: "center", x: c.x, y: c.y, r: RITUAL_SPOTS.center.r });
    if (!r.carved) I.push({ kind: "gap", x: c.x + RITUAL_SPOTS.gap.dx, y: c.y + RITUAL_SPOTS.gap.dy, r: RITUAL_SPOTS.gap.r });
  }
  return I;
}
var scanCache = /* @__PURE__ */ new WeakMap();
function scanTargets(area) {
  const c = scanCache.get(area);
  if (c && c.rev === area.interactionRevision) return c.list;
  const list = [];
  for (const p of area.props) {
    if (!buildRows(p.kind).length) continue;
    list.push({ kind: "buildable", x: p.x, y: p.y + 2, r: propReach(p.kind) + 2, propId: p.id });
  }
  scanCache.set(area, { rev: area.interactionRevision, list });
  return list;
}
function npcInteractables(w, area) {
  const out = [];
  for (const a of w.actors) {
    if (a.id === w.playerId || a.area !== area.id) continue;
    const d = actorDef(a).body;
    if (!folkPresent(a) || !keeperPresent(a)) continue;
    const kind = capable(a, "worker") ? "worker" : npcDef(a.npc) ? "npc" : isFolk(a) ? "folk" : isKeeper(a) ? "keeper" : null;
    if (kind) out.push({ kind, x: a.x, y: a.y + 2, r: kind === "keeper" ? KEEPER_REACH : d.reach, itemZ: d.height - 12, actorId: a.id, npc: a.npc });
  }
  return out;
}
function findTarget(area, a, extra = []) {
  return findTargetIn([...interactables(area), ...extra], a);
}
var findScanTarget = (area, a) => findTargetIn(scanTargets(area), a);
function findTargetIn(list, a, accept = () => true) {
  const fx = a.facing === "left" ? -1 : a.facing === "right" ? 1 : 0;
  const fy = a.facing === "up" ? -1 : a.facing === "down" ? 1 : 0;
  const px = a.x + fx * 6, py = a.y - 3 + fy * 6;
  let best = null, bd = 1;
  for (const it of list) {
    if (!accept(it)) continue;
    const d = Math.hypot(it.x - px, it.y - py) / it.r;
    if (d < bd) {
      bd = d;
      best = it;
    }
  }
  return best;
}
var pick2 = (w, a, rules) => rules.find((r) => meets(w, a, r.when));
function interact(w, a, area, it) {
  if (a.task || a.area !== area.id) return null;
  faceTo3(a, it.x, it.y - 4);
  const scan = scanSpec(a, it.propId ? area.prop(it.propId) : void 0);
  if (scan) {
    beginTask(a, scan, it);
    return null;
  }
  let rules = RULES[it.kind];
  if (it.kind === "socket") {
    const filled = (area.ritual?.sockets[it.socket] ?? -1) >= 0;
    if (!filled && a.inventory.some((s) => s && isGlyph(s.item))) return { ui: "selectGlyph", socket: it.socket };
    rules = filled ? RULES.socketFilled : RULES.socketEmpty;
  }
  if (it.kind === "dig") {
    const key = digRules(area, it.propId);
    rules = key ? RULES[key] : [];
  }
  let first = false;
  if (it.kind === "rune") {
    const node = runeAt(area.id, it.propId), state = node ? runeState(w, node) : "dormant";
    if (state !== "linked") rules = state === "severed" ? RULES.runeSevered : RULES.runeDormant;
    else first = !hasFlag(w, FLAGS.tutorialDone);
  }
  const rule = rules && pick2(w, a, rules);
  if (!rule) return null;
  const { r: _r, itemZ: _z, hasItem: _h, ...target } = it;
  beginTask(a, rule.task, target);
  if (rule.task.kind === "channel") emit(w, { t: "teleport", actor: a.id, first, x: it.x, y: it.y });
  return null;
}
function startSlam(a) {
  if (a.task || !capable(a, "attack")) return false;
  const at = strikePoint(a);
  beginTask(a, { ...SLAM_TASK, effect: { op: "slam" } }, { kind: "ground", x: at.x, y: at.y });
  return true;
}

// src/game/sim/routes.ts
var meansOf = (a) => ({ runes: capable(a, "travel"), portals: capable(a, "move") });
var bases = /* @__PURE__ */ new Map();
function areaBase(id) {
  const build = AREAS[id];
  if (!build) return null;
  let b = bases.get(id);
  if (!b || b.build !== build) {
    const d = build();
    bases.set(id, b = { build, portals: d.portals ?? [], start: d.start });
  }
  return b;
}
function areaPortals(w, id) {
  const live = w.areas.get(id);
  return live ? portalsOf(live) : areaBase(id)?.portals ?? [];
}
var hopKey = (h) => h.via === "rune" ? `r:${h.from}>${h.to}` : `p:${h.portal}`;
function waysOut(w, means, area, awake) {
  const out = [];
  if (means.runes) for (const r of runeWays(w, area, awake)) out.push({ hop: { via: "rune", from: r.from.id, to: r.to.id, area: r.to.area }, awake: r.woke });
  if (means.portals) for (const p of [...areaPortals(w, area)].sort((a, b) => a.id < b.id ? -1 : 1)) {
    if (p.to.area !== area && AREAS[p.to.area] && portalOpen(w, p)) out.push({ hop: { via: "portal", portal: p.id, area: p.to.area }, awake: "" });
  }
  return out;
}
function firstHops(w, means, from, to) {
  if (from === to || !AREAS[to]) return [];
  const found = [];
  const add = (list, hops) => {
    for (const h of hops) if (!list.some((x) => hopKey(x) === hopKey(h))) list.push(h);
  };
  let level = /* @__PURE__ */ new Map([[`${from}:`, { area: from, awake: "", firsts: [] }]]);
  const seen2 = new Set(level.keys());
  while (level.size && !found.length) {
    const next = /* @__PURE__ */ new Map();
    for (const s of level.values()) for (const e of waysOut(w, means, s.area, s.awake)) {
      const firsts = s.firsts.length ? s.firsts : [e.hop];
      if (e.hop.area === to) {
        add(found, firsts);
        continue;
      }
      const key = `${e.hop.area}:${e.awake}`;
      if (seen2.has(key)) continue;
      const n = next.get(key);
      if (n) add(n.firsts, firsts);
      else next.set(key, { area: e.hop.area, awake: e.awake, firsts: [...firsts] });
    }
    for (const key of next.keys()) seen2.add(key);
    level = next;
  }
  return found;
}

// src/game/sim/jobs.ts
var text = (x) => typeof x === "string" && x.length > 0;
var positive = (x) => typeof x === "number" && Number.isSafeInteger(x) && x > 0;
var refOf = (x) => x && typeof x === "object" && !Array.isArray(x) && text(x.area) && text(x.prop) ? { area: x.area, prop: x.prop } : null;
var validRef = (x) => {
  const ref = refOf(x);
  return !!ref && !!AREAS[ref.area];
};
var quantity = (j) => j.args.repeat === true ? Infinity : j.args.amount;
var stop = (a) => {
  a.vx = 0;
  a.vy = 0;
  a.moving = false;
};
function cancelJob(w, a) {
  if (!a.job) return;
  if (a.task?.jobId === a.job.id) a.task = null;
  a.queue = a.queue.filter((t) => t.jobId !== a.job.id);
  a.job = null;
  stop(a);
  emit(w, { t: "jobChanged", actor: a.id, status: "idle" });
}
function block(w, a, reason) {
  const job = a.job;
  job.status = "blocked";
  job.reason = reason;
  job.failures++;
  job.retryAt = w.time + Math.min(8, 1 + job.failures);
  job.nav = null;
  stop(a);
  emit(w, { t: "jobChanged", actor: a.id, status: "blocked", reason });
}
function finish2(w, a) {
  a.job.status = "done";
  a.job.reason = null;
  a.job.nav = null;
  stop(a);
  emit(w, { t: "jobChanged", actor: a.id, status: "done" });
}
function work(a, spec, target) {
  faceTo3(a, target.x, target.y);
  beginTask(a, spec, target);
  a.task.jobId = a.job.id;
  a.job.waiting = true;
  a.job.result = null;
  stop(a);
}
function wayIn(area, a, hop) {
  if (hop.via === "rune") {
    const p2 = area.prop(RUNE_NODES[hop.from].prop);
    return p2 ? { hop, x: p2.x, y: p2.y, range: 15, rune: p2.id } : null;
  }
  const p = portalById(area, hop.portal), at = p && portalStand(p, navGrid(area, a).free);
  return at ? { hop, x: at.x, y: at.y, range: 1 } : null;
}
function approach(w, a, goal, dt) {
  if (a.area !== goal.area) {
    const area = areaOf(w, a), hops = firstHops(w, meansOf(a), a.area, goal.area);
    if (!hops.length) {
      block(w, a, capable(a, "travel") ? "noRoute" : "noTravel");
      return false;
    }
    const ways = hops.flatMap((h) => wayIn(area, a, h) ?? []);
    if (!ways.length) {
      block(w, a, hops[0].via === "rune" ? "missingRune" : "pathBlocked");
      return false;
    }
    const heading = a.job.nav?.goal;
    let way = ways.find((x) => `${a.area}:${x.x},${x.y}:${x.range}` === heading);
    if (!way) {
      const near = [...ways].sort((p, q) => Math.hypot(p.x - a.x, p.y - a.y) - Math.hypot(q.x - a.x, q.y - a.y));
      way = near.find((x) => findPath(w, a, x, false) !== null) ?? near[0];
    }
    const result2 = walkTo(w, a, { area: a.area, x: way.x, y: way.y, range: way.range }, dt);
    if (result2 === "stuck") block(w, a, "pathBlocked");
    if (result2 === "arrived") {
      if (way.hop.via === "rune" && way.rune) {
        beginTask(a, { kind: "channel", dur: 2.2, effect: { op: "travel", destination: way.hop.to } }, { kind: "rune", x: way.x, y: way.y, propId: way.rune });
        a.task.jobId = a.job.id;
        a.job.transit = true;
        a.job.result = null;
        stop(a);
      } else if (way.hop.via === "portal") {
        const p = portalById(area, way.hop.portal);
        if (!p || !inPortal(p, a.x, a.y) || !walkThrough(w, a, area, p)) block(w, a, "arrivalBlocked");
        else stop(a);
      }
    }
    return false;
  }
  const result = walkTo(w, a, goal, dt);
  if (result === "stuck") block(w, a, "pathBlocked");
  return result === "arrived";
}
function gatherDeposit(w, a, j, dt) {
  const item = j.args.resource, storage = refOf(j.args.storage);
  if (j.waiting) {
    const failed = j.result === false;
    j.waiting = false;
    j.result = null;
    if (failed && j.phase === "deposit") {
      block(w, a, "storageFull");
      return;
    }
    if (failed) j.target = null;
  }
  if (j.completed >= quantity(j)) {
    finish2(w, a);
    return;
  }
  const stock = countItem(a, item), remaining = quantity(j) - j.completed;
  const resource = j.target && w.areas.get(j.target.area)?.prop(j.target.prop);
  if (storage && stock > 0 && (stock >= remaining || roomFor(w, a, item) === 0 || resource?.taken)) {
    j.phase = "deposit";
    j.target = null;
  }
  if (storage && j.phase === "deposit") {
    const area = getArea(w, storage.area), p2 = area.prop(storage.prop);
    if (!p2?.inventory) {
      block(w, a, "missingStorage");
      return;
    }
    if (!stock) {
      j.phase = "gather";
      j.target = null;
      return;
    }
    if (!approach(w, a, { area: area.id, x: p2.x, y: p2.y, range: propReach(p2.kind) + 2 }, dt)) return;
    const h = inventoryHandle(w, storageRef(area.id, p2.id));
    if (!h || !roomIn(h.inventory, h.capacity, item)) {
      block(w, a, "storageFull");
      return;
    }
    work(a, { kind: "reach", dur: 0.45, effect: { op: "deposit", item, n: Math.min(stock, remaining) } }, { kind: "storage", propId: p2.id, x: p2.x, y: p2.y });
    return;
  }
  const source = getArea(w, j.args.fromArea);
  if (a.area !== source.id) {
    approach(w, a, { area: source.id, ...source.start, range: 1 }, dt);
    return;
  }
  if (!roomFor(w, a, item)) {
    block(w, a, "packFull");
    return;
  }
  let p = j.target ? source.prop(j.target.prop) : void 0;
  if (!p || p.taken) {
    const candidates2 = source.props.filter((p2) => !p2.taken && (HARVEST[p2.kind]?.perHit.item === item || HARVEST[p2.kind]?.final?.item === item)).sort((p2, q) => Math.hypot(p2.x - a.x, p2.y - a.y) - Math.hypot(q.x - a.x, q.y - a.y) || (p2.id < q.id ? -1 : 1));
    p = candidates2.find((p2) => findPath(w, a, { x: p2.x, y: p2.y, range: propReach(p2.kind) + 2 }, false) !== null);
    if (!p) {
      if (stock && storage) {
        j.phase = "deposit";
        return;
      }
      block(w, a, "noResource");
      return;
    }
    j.target = { area: source.id, prop: p.id };
  }
  if (!approach(w, a, { area: source.id, x: p.x, y: p.y, range: propReach(p.kind) + 2 }, dt)) return;
  const hit = harvestStep(a, p);
  if (!hit) {
    block(w, a, "cannotHarvest");
    return;
  }
  if (hit.rewards.some((r) => roomFor(w, a, r.item) < r.n)) {
    if (stock && storage) {
      j.phase = "deposit";
      j.target = null;
    } else block(w, a, "packFull");
    return;
  }
  work(a, { kind: "punch", dur: 0.75, effect: { op: "harvest" } }, { kind: "harvest", propId: p.id, x: p.x, y: p.y });
}
function craftAt(w, a, j, dt) {
  if (j.waiting) {
    const ok = j.result;
    j.waiting = false;
    j.result = null;
    if (ok) j.completed++;
    else {
      block(w, a, "craftChanged");
      return;
    }
  }
  if (j.completed >= quantity(j)) {
    finish2(w, a);
    return;
  }
  const station = refOf(j.args.station), area = getArea(w, station.area), p = area.prop(station.prop);
  const recipe = CRAFT_RECIPES.find((r) => r.id === j.args.recipe);
  if (!p || !recipe || propDef(p.kind).station !== recipe.station) {
    block(w, a, "missingStation");
    return;
  }
  if (!approach(w, a, { area: area.id, x: p.x, y: p.y, range: propReach(p.kind) + 2 }, dt)) return;
  const entry = craftEntry(w, a, recipe, p);
  if (craftLocked(w, a, recipe.station) || entry.status !== "ok") {
    block(w, a, entry.status === "ok" ? "unknown" : entry.status);
    return;
  }
  if (!outputFits(w, a, recipe)) {
    block(w, a, "packFull");
    return;
  }
  if (!orderCraft(w, a, recipe.station, recipe.id, p.id)) {
    block(w, a, "craftChanged");
    return;
  }
  a.task.jobId = j.id;
  j.waiting = true;
  j.result = null;
  stop(a);
}
var JOB_HANDLERS = {
  gatherDeposit: {
    validate: (p) => text(p.resource) && !!ITEMS[p.resource] && text(p.fromArea) && !!AREAS[p.fromArea] && (p.storage === null || validRef(p.storage)) && (p.repeat === true || positive(p.amount)),
    step: gatherDeposit
  },
  craftAt: {
    validate: (p) => validRef(p.station) && text(p.recipe) && CRAFT_RECIPES.some((r) => r.id === p.recipe) && (p.repeat === true || positive(p.amount)),
    step: craftAt
  },
  walk: {
    validate: (p) => text(p.area) && !!AREAS[p.area] && typeof p.x === "number" && Number.isFinite(p.x) && typeof p.y === "number" && Number.isFinite(p.y),
    step: (w, a, j, dt) => {
      if (approach(w, a, { area: j.args.area, x: j.args.x, y: j.args.y, range: 1 }, dt)) finish2(w, a);
    }
  }
};
function tickJob(w, a, dt) {
  const job = a.job;
  if (!job || job.status === "done") {
    if (!a.task) stop(a);
    return;
  }
  if (!powered(a)) {
    if (job.reason !== "manual") {
      job.status = "paused";
      job.reason = "power";
    }
    stop(a);
    return;
  }
  if (job.status === "paused" && job.reason === "power") {
    job.status = "running";
    job.reason = null;
  }
  if (job.status === "paused") return;
  if (job.status === "blocked") {
    if (job.failures >= 3 || w.time < job.retryAt) return;
    job.status = "running";
    job.reason = null;
    job.nav = null;
  }
  if (a.task || a.queue.length) return;
  if (job.transit) {
    job.transit = false;
    const ok = job.result;
    job.result = null;
    if (!ok) {
      block(w, a, "arrivalBlocked");
      return;
    }
  }
  const handler = JOB_HANDLERS[job.kind];
  if (!handler) {
    block(w, a, "unknownJob");
    return;
  }
  handler.step(w, a, job, dt);
}

// src/game/sim/commands.ts
function orderCoreSwap(w, a, targetId, item) {
  const target = actorById(w, targetId);
  const opening = !!a.task?.fired && a.task.effect?.op === "manageActor";
  if (a.task && !opening || !target || target.id === a.id || target.area !== a.area || !actorDef(target).power) return false;
  if (item && !(coreCheck(target, item).accepts && countItem(a, item) > 0)) {
    emit(w, { t: "message", text: CORE_TEXT.noCore });
    return false;
  }
  if (!item && !target.powerCore) {
    emit(w, { t: "message", text: CORE_TEXT.empty });
    return false;
  }
  faceTo3(a, target.x, target.y - 6);
  beginTask(a, { ...CORE_TASK, effect: { op: "slotCore", item } }, { kind: "core", x: target.x, y: target.y, actorId: target.id });
  return true;
}
function coreTargetFor(w, a, area) {
  const bodies = w.actors.filter((x) => x.id !== a.id && x.area === area.id && !!actorDef(x).power).map((x) => ({ kind: "core", x: x.x, y: x.y + 2, r: actorDef(x).body.reach, actorId: x.id }));
  const it = findTargetIn(bodies, a);
  return it?.actorId ? actorById(w, it.actorId) : void 0;
}
function coreKey(w, a, area) {
  if (a.task) return false;
  const target = coreTargetFor(w, a, area);
  if (!target) return false;
  const act = coreActionFor(a, target);
  if (act.op === "none") {
    emit(w, { t: "message", text: CORE_TEXT.noCore });
    return false;
  }
  return orderCoreSwap(w, a, target.id, act.op === "insert" ? act.item : null);
}

// src/game/sim/step.ts
function stepPlayer(w, dt, input) {
  const pl = player(w);
  const area = areaOf(w, pl);
  if (input.toggleScan) toggleScan(pl);
  if (pl.job && pl.job.status !== "done" && (input.ix || input.iy || input.use || input.attack || input.core)) cancelJob(w, pl);
  tickTask(w, pl, dt);
  if (pl.job && pl.job.status !== "done" && (pl.job.status !== "paused" || pl.job.reason === "power")) {
    tickJob(w, pl, dt);
    reactToEvents(w);
    return { target: null, ui: null };
  }
  move(w, area, pl, dt, pl.task ? 0 : input.ix, pl.task ? 0 : input.iy, actorSpeed(w, pl) * (input.speed ?? 1), input.noclip);
  if (!pl.task && (input.ix || input.iy)) {
    const way = portalAt(area, pl.x, pl.y, input.ix, input.iy, (p) => portalOpen(w, p));
    if (way && walkThrough(w, pl, area, way)) {
      reactToEvents(w);
      return { target: null, ui: null };
    }
  }
  const scan = pl.task || pl.mode !== "scan" ? null : findScanTarget(area, pl);
  const target = pl.task ? null : scan ?? findTarget(area, pl, npcInteractables(w, area));
  let ui = null;
  if (!pl.task && target && input.use) ui = interact(w, pl, area, target);
  if (!pl.task && !ui && input.core) coreKey(w, pl, area);
  if (!pl.task && !ui && input.attack) startSlam(pl);
  const r = area.ritual;
  if (r && r.active && r.actT > RITUAL_SPOTS.teleport.delay && !pl.task && !hasFlag(w, FLAGS.tutorialDone)) {
    const c = area.ritualPos;
    const dx = c.x - pl.x, dy = c.y + RITUAL_SPOTS.teleport.dy - pl.y;
    if (dx * dx + dy * dy < RITUAL_SPOTS.teleport.r2) {
      pl.facing = "down";
      const first = RULES.rune[RULES.rune.length - 1].task;
      beginTask(pl, first, { kind: "rune", x: c.x, y: c.y, propId: "rune.dungeon" });
      emit(w, { t: "teleport", actor: pl.id, first: true, x: c.x, y: c.y });
    }
  }
  reactToEvents(w);
  return { target, ui };
}
function addPlayTime(w, dt) {
  w.playTime += dt;
}
function stepWorld(w, dt) {
  const focus = player(w);
  if (focus && w.focusArea !== focus.area) {
    catchUpArea(w, areaOf(w, focus));
    w.focusArea = focus.area;
  }
  w.time += dt;
  w.tick = (w.tick ?? 0) + 1;
  stepDay(w, dt);
  runScheduled(w);
  for (const a of [...w.actors].sort((a2, b) => a2.id < b.id ? -1 : a2.id > b.id ? 1 : 0)) {
    reconcileGear(w, a);
    reconcileCapacity(w, a);
    if (a.id === w.playerId) continue;
    if (!a.task && !a.queue.length && !a.job) {
      clearDebt(w, a.id);
      continue;
    }
    const stationary = !!a.task && !a.moving;
    stepAtTier(w, a, stationary ? tierOf(w, a, focus) : "active", dt, (c) => {
      tickTask(w, a, c);
      tickJob(w, a, c);
    });
  }
  if (focus) {
    const here = areaOf(w, focus);
    here.advanceRitual(dt);
    here.lastTicked = w.time;
  }
  tickFolk(w, dt);
  tickKeepers(w, dt);
  reactToEvents(w);
}
function move(w, area, pl, dt, ix, iy, base, noclip = false) {
  const mag = Math.hypot(ix, iy);
  if (mag > 0) {
    ix /= mag;
    iy /= mag;
    pl.facing = Math.abs(ix) > Math.abs(iy) ? ix > 0 ? "right" : "left" : iy > 0 ? "down" : "up";
  }
  const limp = 0.55 + 0.6 * Math.abs(Math.sin(pl.phase));
  const tx = ix * base * limp, ty = iy * base * limp;
  const acc = mag > 0 ? 7 : 10;
  pl.vx += (tx - pl.vx) * Math.min(1, acc * dt);
  pl.vy += (ty - pl.vy) * Math.min(1, acc * dt);
  const sp = Math.hypot(pl.vx, pl.vy);
  pl.moving = sp > 4;
  const bodies = actorBoxes(w, area.id, pl.id);
  const boxFree2 = noclip ? (a, x, y) => x > 2 && y > 6 && x < a.w * TS - 2 && y < a.h * TS - 1 : (a, x, y) => boxFree(a, x, y, bodies, actorDef(pl).body.box);
  const nx = pl.x + pl.vx * dt;
  if (boxFree2(area, nx, pl.y)) pl.x = nx;
  else {
    if (Math.abs(iy) < 0.3 && ix !== 0) for (const d of [2, 4, 6, 8]) {
      if (boxFree2(area, nx, pl.y - d)) {
        pl.y -= Math.min(d, 20 * dt);
        break;
      }
      if (boxFree2(area, nx, pl.y + d)) {
        pl.y += Math.min(d, 20 * dt);
        break;
      }
    }
    pl.vx *= 0.3;
  }
  const ny = pl.y + pl.vy * dt;
  if (boxFree2(area, pl.x, ny)) pl.y = ny;
  else {
    if (Math.abs(ix) < 0.3 && iy !== 0) for (const d of [2, 4, 6, 8]) {
      if (boxFree2(area, pl.x - d, ny)) {
        pl.x -= Math.min(d, 20 * dt);
        break;
      }
      if (boxFree2(area, pl.x + d, ny)) {
        pl.x += Math.min(d, 20 * dt);
        break;
      }
    }
    pl.vy *= 0.3;
  }
  if (pl.moving) {
    const before = Math.sin(pl.phase);
    pl.phase += dt * (3.2 + sp * 0.09);
    const after = Math.sin(pl.phase);
    if (before < 0 !== after < 0) {
      pl.steps++;
      emit(w, { t: "step", actor: pl.id, heavy: pl.steps % 2 === 0 });
    }
  } else pl.phase = pl.phase % Math.PI < 0.2 ? pl.phase : pl.phase + dt * 2;
}

// src/game/sim/replay.ts
var NO_INPUT = { ix: 0, iy: 0, use: false };
function simTick(w, input = NO_INPUT) {
  addPlayTime(w, TICK);
  const r = stepPlayer(w, TICK, input);
  stepWorld(w, TICK);
  return r;
}

// src/game/sim/soak.ts
function populateResidents(w, n, areas = ["town"]) {
  const rows = CENSUS.filter((r) => areas.includes(r.area));
  for (const id of new Set(rows.map((r) => r.area))) getArea(w, id);
  const taken = new Set(w.actors.filter(isFolk).map((a) => a.person.name.split(" ")[0]));
  for (let k = 1; w.actors.length < n && rows.length; k++) {
    for (const r of rows) {
      if (w.actors.length >= n) break;
      const row = { ...r, id: `${r.id}.r${k}` };
      if (!actorById(w, row.id)) w.actors.push(makeFolk(w, row, taken));
    }
  }
}
function itemTotals(w) {
  const t = {};
  const add = (id, n = 1) => {
    if (id) t[id] = (t[id] ?? 0) + n;
  };
  for (const a of w.actors) {
    for (const s of a.inventory) if (s) add(s.item, s.n);
    for (const g of Object.values(a.gear)) add(g);
    add(a.powerCore);
  }
  for (const area of w.areas.values()) {
    for (const p of area.props) {
      add(p.item);
      for (const s of p.inventory ?? []) if (s) add(s.item, s.n);
    }
    for (const l of area.loose) if (!l.taken) add(l.item, l.n ?? 1);
  }
  return t;
}
function placeConflicts(w) {
  const held = /* @__PURE__ */ new Map();
  for (const a of w.actors) {
    if (!isFolk(a) || !a.life.spot) continue;
    const id = a.life.spot;
    if (!id.startsWith("lamp:")) {
      const s = spotById(getArea(w, a.area), id);
      if (!s || !isExclusive(s)) continue;
    }
    const k = `${a.area}|${id}`;
    held.set(k, [...held.get(k) ?? [], a.id]);
  }
  return [...held].filter(([, ids]) => ids.length > 1).map(([k, ids]) => `${k}: ${ids.join(", ")}`);
}
function makeSoakWorld(o) {
  const w = createWorld(o.seed ?? 1234);
  const area = getArea(w, o.area ?? "town");
  enterArea(w, player(w), area.id, area.start.x, area.start.y);
  populateResidents(w, o.actors);
  advanceDayTo(w, o.startHour ?? 9);
  w.events.length = 0;
  return w;
}
function runSoak(o, w = makeSoakWorld(o)) {
  const now = o.now ?? (() => typeof performance !== "undefined" ? performance.now() : Date.now());
  const stuckLimit = o.stuckSeconds ?? 20, budget = o.budgetMs ?? 4, rtEvery = (o.roundTripHours ?? 4) * (DAY_SECONDS / 24);
  const ticks = Math.round(o.hours * DAY_SECONDS / 24 / TICK);
  const before = itemTotals(w);
  const lastMove = /* @__PURE__ */ new Map();
  const stuck = /* @__PURE__ */ new Set(), conflicts = /* @__PURE__ */ new Set(), rtFail = [];
  const costs = [];
  let nextRt = w.time + rtEvery, roundTrips = 0;
  for (let i = 0; i < ticks; i++) {
    const t0 = now();
    simTick(w);
    costs.push(now() - t0);
    w.events.length = 0;
    if (i % 15 === 0) {
      const pl = player(w);
      for (const a of w.actors) {
        if (!isFolk(a) || a.area !== pl.area || tierOf(w, a, pl) !== "active") {
          lastMove.delete(a.id);
          continue;
        }
        const L = a.life, m = lastMove.get(a.id);
        const wants = L.path.length > 0 && L.state !== "do" && L.state !== "indoors" && !L.chat;
        if (!m || !wants || Math.hypot(a.x - m.x, a.y - m.y) > 1) {
          lastMove.set(a.id, { x: a.x, y: a.y, t: w.time });
          continue;
        }
        if (w.time - m.t > stuckLimit) stuck.add(`${a.id} at ${a.x.toFixed(0)},${a.y.toFixed(0)} (${L.act})`);
      }
      for (const c of placeConflicts(w)) conflicts.add(c);
    }
    if (w.time >= nextRt) {
      nextRt += rtEvery;
      roundTrips++;
      const a = JSON.stringify(serialize(w)), b = JSON.stringify(serialize(deserialize(JSON.parse(a))));
      if (a !== b) rtFail.push(`at t=${w.time.toFixed(1)}: ${a.length} vs ${b.length} bytes`);
    }
  }
  const after = itemTotals(w), drift = {};
  for (const k of /* @__PURE__ */ new Set([...Object.keys(before), ...Object.keys(after)])) {
    const d = (after[k] ?? 0) - (before[k] ?? 0);
    if (d) drift[k] = d;
  }
  const ids = w.actors.map((a) => a.id), dup = ids.filter((id, i) => ids.indexOf(id) !== i);
  const sorted = [...costs].sort((a, b) => a - b), mean = costs.reduce((s, c) => s + c, 0) / Math.max(1, costs.length);
  const report = {
    ticks,
    simSeconds: ticks * TICK,
    actors: w.actors.length,
    msPerTick: mean,
    p95Ms: sorted[Math.floor(sorted.length * 0.95)] ?? 0,
    maxMs: sorted[sorted.length - 1] ?? 0,
    budgetMs: budget,
    withinBudget: mean <= budget,
    stuck: [...stuck],
    placeConflicts: [...conflicts],
    duplicateIds: dup,
    itemDrift: drift,
    roundTrips,
    roundTripFailures: rtFail,
    ok: false
  };
  report.ok = report.withinBudget && !report.stuck.length && !report.placeConflicts.length && !dup.length && !Object.keys(drift).length && !rtFail.length;
  return report;
}

// src/game/font.ts
var G2 = {
  A: "010101111101101",
  B: "110101110101110",
  C: "011100100100011",
  D: "110101101101110",
  E: "111100110100111",
  F: "111100110100100",
  G: "011100101101011",
  H: "101101111101101",
  I: "111010010010111",
  J: "001001001101010",
  K: "101101110101101",
  L: "100100100100111",
  M: "101111111101101",
  N: "110101101101101",
  O: "010101101101010",
  P: "110101110100100",
  Q: "010101101110011",
  R: "110101110101101",
  S: "011100010001110",
  T: "111010010010010",
  U: "101101101101111",
  V: "101101101101010",
  W: "101101111111101",
  X: "101101010101101",
  Y: "101101010010010",
  Z: "111001010100111",
  "0": "111101101101111",
  "1": "010110010010111",
  "2": "110001010100111",
  "3": "110001010001110",
  "4": "101101111001001",
  "5": "111100110001110",
  "6": "011100111101111",
  "7": "111001010010010",
  "8": "111101111101111",
  "9": "111101111001110",
  ".": "000000000000010",
  ",": "000000000010100",
  ":": "000010000010000",
  "-": "000000111000000",
  "/": "001001010100100",
  "'": "010010000000000",
  "(": "010100100100010",
  ")": "010001001001010",
  "+": "000010111010000",
  "=": "000111000111000",
  "?": "110001010000010",
  "!": "010010010000010",
  ">": "100010001010100",
  "<": "001010100010001",
  "#": "101111101111101",
  " ": "000000000000000",
  "^": "010101000000000",
  "*": "000101010101000"
};
var FONT_GLYPHS = new Set(Object.keys(G2));
function textWidth(s, scale = 1) {
  return s.length * 4 * scale - scale;
}

// src/game/ui2/font2.ts
var SRC = {
  A: ".###./#...#/#...#/#####/#...#/#...#/#...#",
  B: "####./#...#/#...#/####./#...#/#...#/####.",
  C: ".###./#...#/#..../#..../#..../#...#/.###.",
  D: "####./#...#/#...#/#...#/#...#/#...#/####.",
  E: "#####/#..../#..../####./#..../#..../#####",
  F: "#####/#..../#..../####./#..../#..../#....",
  G: ".###./#...#/#..../#.###/#...#/#...#/.####",
  H: "#...#/#...#/#...#/#####/#...#/#...#/#...#",
  I: "###/.#./.#./.#./.#./.#./###",
  J: "..###/...#./...#./...#./#..#./#..#./.##..",
  K: "#...#/#..#./#.#../##.../#.#../#..#./#...#",
  L: "#..../#..../#..../#..../#..../#..../#####",
  M: "#...#/##.##/#.#.#/#.#.#/#...#/#...#/#...#",
  N: "#...#/##..#/#.#.#/#..##/#...#/#...#/#...#",
  O: ".###./#...#/#...#/#...#/#...#/#...#/.###.",
  P: "####./#...#/#...#/####./#..../#..../#....",
  Q: ".###./#...#/#...#/#...#/#.#.#/#..#./.##.#",
  R: "####./#...#/#...#/####./#.#../#..#./#...#",
  S: ".###./#...#/#..../.###./....#/#...#/.###.",
  T: "#####/..#../..#../..#../..#../..#../..#..",
  U: "#...#/#...#/#...#/#...#/#...#/#...#/.###.",
  V: "#...#/#...#/#...#/#...#/.#.#./.#.#./..#..",
  W: "#...#/#...#/#...#/#.#.#/#.#.#/##.##/#...#",
  X: "#...#/#...#/.#.#./..#../.#.#./#...#/#...#",
  Y: "#...#/#...#/.#.#./..#../..#../..#../..#..",
  Z: "#####/....#/...#./..#../.#.../#..../#####",
  a: "..../..../.###/...#/.###/#..#/.###",
  b: "#.../#.../###./#..#/#..#/#..#/###.",
  c: "..../..../.###/#.../#.../#.../.###",
  d: "...#/...#/.###/#..#/#..#/#..#/.###",
  e: "..../..../.##./#..#/####/#.../.###",
  f: "..##/.#../###./.#../.#../.#../.#..",
  g: "..../..../.###/#..#/#..#/#..#/.###/...#/.##.",
  h: "#.../#.../###./#..#/#..#/#..#/#..#",
  i: "#/./#/#/#/#/#",
  j: "..#/.../..#/..#/..#/..#/..#/..#/##.",
  k: "#.../#.../#..#/#.#./##../#.#./#..#",
  l: "#./#./#./#./#./#./.#",
  m: "...../...../##.#./#.#.#/#.#.#/#.#.#/#.#.#",
  n: "..../..../###./#..#/#..#/#..#/#..#",
  o: "..../..../.##./#..#/#..#/#..#/.##.",
  p: "..../..../###./#..#/#..#/#..#/###./#.../#...",
  q: "..../..../.###/#..#/#..#/#..#/.###/...#/...#",
  r: "..../..../#.##/##../#.../#.../#...",
  s: "..../..../.###/#.../.##./...#/###.",
  t: ".#../.#../###./.#../.#../.#../..##",
  u: "..../..../#..#/#..#/#..#/#..#/.###",
  v: "...../...../#...#/#...#/.#.#./.#.#./..#..",
  w: "...../...../#...#/#.#.#/#.#.#/#.#.#/.#.#.",
  x: "...../...../#...#/.#.#./..#../.#.#./#...#",
  y: "..../..../#..#/#..#/#..#/#..#/.###/...#/.##.",
  z: "..../..../####/...#/.##./#.../####",
  "0": ".##./#..#/#.##/##.#/#..#/#..#/.##.",
  "1": ".#./##./.#./.#./.#./.#./###",
  "2": ".##./#..#/...#/..#./.#../#.../####",
  "3": "###./...#/...#/.##./...#/...#/###.",
  "4": "..#./.##./#.#./#.#./####/..#./..#.",
  "5": "####/#.../###./...#/...#/#..#/.##.",
  "6": ".##./#.../#.../###./#..#/#..#/.##.",
  "7": "####/...#/..#./..#./.#../.#../.#..",
  "8": ".##./#..#/#..#/.##./#..#/#..#/.##.",
  "9": ".##./#..#/#..#/.###/...#/...#/.##.",
  " ": ".../.../.../.../.../.../...",
  ".": "./././././././#",
  ",": "../../../../../../.#/#.",
  ":": "./././#/./././#",
  ";": "../../../.#/../../.#/#.",
  "!": "#/#/#/#/#/./#",
  "?": ".##./#..#/...#/..#./.#../..../.#..",
  "'": "#/#/./././././",
  '"': "#.#/#.#/.../.../.../.../...",
  "-": "..../..../..../####/..../..../....",
  "+": "...../..#../..#../#####/..#../..#../.....",
  "=": "..../..../####/..../####/..../....",
  "/": "...#/...#/..#./..#./.#../.#../#...",
  "\\": "#.../#.../.#../.#../..#./..#./...#",
  "(": ".#/#./#./#./#./#./.#",
  ")": "#./.#/.#/.#/.#/.#/#.",
  "[": "##/#./#./#./#./#./##",
  "]": "##/.#/.#/.#/.#/.#/##",
  "%": "##..#/##.#./...#./..#../.#.../.#.##/#..##",
  "#": ".#.#./.#.#./#####/.#.#./#####/.#.#./.#.#.",
  "*": "...../#.#.#/.###./#####/.###./#.#.#/.....",
  "<": "...#/..#./.#../#.../.#../..#./...#",
  ">": "#.../.#../..#./...#/..#./.#../#...",
  _: "..../..../..../..../..../..../####",
  "&": ".##../#..#./#.#../.#.../#.#.#/#..#./.##.#",
  "@": ".###./#...#/#.###/#.#.#/#.##./#..../.####",
  $: "..#../.####/#.#../.###./..#.#/####./..#..",
  "^": "..#../.#.#./#...#/...../...../...../.....",
  "~": "...../...../.#..#/#.##./...../...../.....",
  "|": "#/#/#/#/#/#/#",
  "`": "#./.#/../../../../.."
};
var GLYPHS2 = {};
for (const [ch, s] of Object.entries(SRC)) {
  const rows = s.split("/");
  const w = Math.max(...rows.map((r) => r.length));
  GLYPHS2[ch] = { w, rows: rows.map((r) => [...r].reduce((m, c, i) => c === "#" ? m | 1 << w - 1 - i : m, 0)) };
}
var ALIAS = { "\u2014": "-", "\u2013": "-", "\u2019": "'", "\u2018": "'", "\u201C": '"', "\u201D": '"', "\xD7": "x", "\u2026": "..." };
var FONT2_GLYPHS = new Set(Object.keys(GLYPHS2));
var norm = (s) => s.replace(/[\u2014\u2013\u2019\u2018\u201c\u201d\u00d7\u2026]/g, (c) => ALIAS[c] ?? "?");
var glyphOf = (c) => GLYPHS2[c] ?? GLYPHS2["?"];
function measure(s, scale = 1) {
  s = norm(s);
  let w = 0;
  for (const c of s) w += glyphOf(c).w + 1;
  return Math.max(0, w - 1) * scale;
}

// src/game/settings.ts
var ACTIONS = [
  { id: "up", label: "Move up", key: "w" },
  { id: "down", label: "Move down", key: "s" },
  { id: "left", label: "Move left", key: "a" },
  { id: "right", label: "Move right", key: "d" },
  { id: "use", label: "Interact", key: "e" },
  { id: "attack", label: "Slam", key: " " },
  { id: "core", label: "Core slot", key: "c" },
  { id: "scan", label: "Scan mode", key: "z" },
  { id: "pack", label: "Pack", key: "i" },
  { id: "map", label: "Schematic", key: "m" },
  { id: "build", label: "Build menu", key: "b" },
  { id: "pause", label: "Pause", key: "p" },
  { id: "slower", label: "Slower", key: "-" },
  { id: "faster", label: "Faster", key: "=" },
  { id: "overview", label: "Overview", key: "g" },
  { id: "saves", label: "Saves", key: "j" },
  { id: "options", label: "Settings", key: "o" }
];
var PALETTE_LABEL = { default: "Default", deutan: "Deuteranopia", protan: "Protanopia", tritan: "Tritanopia" };
var OPTIONS = [];
function registerOption(o) {
  const i = OPTIONS.findIndex((x) => x.id === o.id);
  if (i >= 0) OPTIONS[i] = o;
  else OPTIONS.push(o);
}
var pct = (v) => `${Math.round(v * 100)}%`;
registerOption({ id: "master", section: "Audio", label: "Master volume", kind: "slider", min: 0, max: 1, step: 0.05, format: pct });
registerOption({ id: "ambience", section: "Audio", label: "Ambience volume", kind: "slider", min: 0, max: 1, step: 0.05, format: pct, hint: "The hum of the halls and the wind" });
registerOption({ id: "shake", section: "Accessibility", label: "Screen shake", kind: "toggle" });
registerOption({ id: "flash", section: "Accessibility", label: "Flashes", kind: "toggle", hint: "White flashes on rune jumps and breaking stone" });
registerOption({ id: "palette", section: "Accessibility", label: "Overlay colours", kind: "choice", values: ["default", "deutan", "protan", "tritan"], labels: PALETTE_LABEL });
registerOption({ id: "uiScale", section: "Display", label: "UI scale", kind: "choice", values: ["small", "normal", "large"], labels: { small: "Small", normal: "Normal", large: "Large" } });
registerOption({ id: "interpolate", section: "Display", label: "Smooth motion", kind: "toggle", hint: "Interpolate between simulation ticks" });
registerOption({ id: "pauseOnAlert", section: "Game", label: "Pause on alerts", kind: "toggle", hint: "Important notifications pause the game" });
registerOption({ id: "autosave", section: "Game", label: "Autosave", kind: "toggle" });
registerOption({ id: "autosaveMinutes", section: "Game", label: "Autosave every", kind: "slider", min: 1, max: 15, step: 1, format: (v) => `${v} min` });

// src/game/content/lint.ts
var undrawable = (s) => [...new Set([...s.toUpperCase()].filter((c) => !FONT_GLYPHS.has(c)))];
var undrawable2 = (s) => [...new Set([...s].filter((c) => !FONT2_GLYPHS.has(c)))];
function lintContent() {
  const out = [];
  const bad = (table, row, rule, detail) => out.push({ table, row, rule, detail });
  const text2 = (table, row, s, maxW) => {
    if (s === void 0) return;
    const u = undrawable(s);
    if (u.length) bad(table, row, "font", `cannot draw ${JSON.stringify(u.join(""))} in "${s.slice(0, 40)}"`);
    if (maxW && textWidth(s) > maxW) bad(table, row, "width", `"${s}" is ${textWidth(s)}px, over ${maxW}px`);
  };
  const item = (table, row, id) => {
    if (id && !(id in ITEMS)) bad(table, row, "ref", `unknown item "${id}"`);
  };
  for (const [id, it] of Object.entries(ITEMS)) {
    if (!it.name) bad("ITEMS", id, "required", "no name");
    text2("ITEMS", id, it.name, 150);
    if ((it.stack ?? 1) < 1) bad("ITEMS", id, "range", `stack ${it.stack}`);
  }
  for (const [id, p] of Object.entries(PROPS)) {
    text2("PROPS", id, p.examine);
    if (p.box && (p.box[0] <= 0 || p.box[1] <= 0)) bad("PROPS", id, "range", `box ${p.box}`);
  }
  for (const [id, r] of Object.entries(RECIPES)) {
    text2("RECIPES", id, r.name, 150);
    r.desc.forEach((l, i) => text2("RECIPES", `${id}.desc${i}`, l, 34 * 4));
    if (!(r.prop in PROPS)) bad("RECIPES", id, "ref", `unknown prop "${r.prop}"`);
    for (const c of r.cost) {
      item("RECIPES", id, c.item);
      if (c.n <= 0) bad("RECIPES", id, "range", `cost ${c.n} x ${c.item}`);
    }
  }
  for (const r of CRAFT_RECIPES) {
    text2("CRAFT_RECIPES", r.id, r.name, 150);
    r.desc.forEach((l, i) => text2("CRAFT_RECIPES", `${r.id}.desc${i}`, l, 30 * 4));
    if (!(r.station in STATIONS)) bad("CRAFT_RECIPES", r.id, "ref", `unknown station "${r.station}"`);
    for (const c of r.inputs) item("CRAFT_RECIPES", r.id, c.item);
    for (const t of r.tools ?? []) item("CRAFT_RECIPES", r.id, t);
    for (const c of r.also ?? []) item("CRAFT_RECIPES", r.id, c.item);
    item("CRAFT_RECIPES", r.id, r.output.item);
    if (r.output.n <= 0) bad("CRAFT_RECIPES", r.id, "range", `output n ${r.output.n}`);
  }
  for (const [id, l] of Object.entries(THOUGHTS)) text2("THOUGHTS", id, l.text);
  for (const e of EXCHANGES) for (const [i, l] of e.lines.entries()) {
    const s = typeof l === "string" ? l : l.text ?? l.say;
    if (typeof s !== "string") continue;
    text2("EXCHANGES", `${e.id}.${i}`, s.replace(/\{[^}]*\}/g, "X"));
    if (s.length > PEER_MAX + 20) bad("EXCHANGES", `${e.id}.${i}`, "length", `${s.length} chars`);
  }
  const ids = /* @__PURE__ */ new Set();
  for (const r of CENSUS) {
    if (ids.has(r.id)) bad("CENSUS", r.id, "unique", "duplicate id");
    ids.add(r.id);
    if (!(r.archetype in ARCHETYPES)) bad("CENSUS", r.id, "ref", `unknown archetype "${r.archetype}"`);
    if (!(r.area in AREAS)) bad("CENSUS", r.id, "ref", `unknown area "${r.area}"`);
  }
  for (const o of OPTIONS) {
    const u = undrawable2(o.label + (o.hint ?? ""));
    if (u.length) bad("OPTIONS", o.id, "font2", `cannot draw ${u.join("")}`);
    if (measure(o.label) > 200) bad("OPTIONS", o.id, "width", o.label);
  }
  const keys = /* @__PURE__ */ new Set();
  for (const a of ACTIONS) {
    if (keys.has(a.key)) bad("ACTIONS", a.id, "unique", `default key "${a.key}" bound twice`);
    keys.add(a.key);
  }
  for (const [id, build] of Object.entries(AREAS)) {
    if (id.startsWith("debug_")) continue;
    const a = build();
    for (const p of a.portals ?? []) {
      if (!(p.to.area in AREAS)) {
        bad("AREAS", `${id}.${p.id}`, "ref", `portal to unknown area "${p.to.area}"`);
        continue;
      }
      if (!p.to.portal.startsWith("@") && !(AREAS[p.to.area]().portals ?? []).some((q) => q.id === p.to.portal)) bad("AREAS", `${id}.${p.id}`, "ref", `no portal "${p.to.portal}" in ${p.to.area}`);
    }
  }
  for (const [kind, k] of Object.entries(AREA_KINDS)) for (const seed of [1, 99, 123456]) {
    const spec = { id: `lint~${kind}`, kind, seed, w: k.min[0] + 16, h: k.min[1] + 10, parent: "surface", depth: 1, entry: { x: 100, y: 100 } };
    const a = k.build(spec), b = k.build(spec);
    if (a.grid.join() !== b.grid.join() || JSON.stringify(a.props) !== JSON.stringify(b.props)) bad("AREA_KINDS", `${kind}#${seed}`, "deterministic", "two builds differ");
    const sx = Math.floor(a.start.x / 16), sy = Math.floor(a.start.y / 16);
    if (a.grid[sy * a.w + sx] !== T.FLOOR) bad("AREA_KINDS", `${kind}#${seed}`, "start", "start tile is not floor");
    if (!(a.portals ?? []).some((p) => p.id === "exit")) bad("AREA_KINDS", `${kind}#${seed}`, "exit", "no exit portal");
    for (const p of a.props) if (!(p.kind in PROPS)) bad("AREA_KINDS", `${kind}#${seed}`, "ref", `unknown prop "${p.kind}"`);
  }
  return out;
}

// tests/support/soakRun.ts
function main(args) {
  const opt = Object.fromEntries(args.map((a) => a.split("=")).filter((p) => p.length === 2));
  const issues = lintContent();
  for (const i of issues) console.log(`lint ${i.table}/${i.row} [${i.rule}] ${i.detail}`);
  const days = +(opt.days ?? 0), hours = days ? days * 24 : +(opt.hours ?? 2);
  const r = runSoak({ hours, actors: +(opt.actors ?? 300), seed: +(opt.seed ?? 1234), budgetMs: +(opt.budget ?? 4), area: opt.area ?? "town", startHour: +(opt.start ?? 9) });
  console.log(JSON.stringify({ ...r, itemDrift: r.itemDrift }, null, 2));
  return r.ok && !issues.length ? 0 : 1;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  main
});
