# Phase 0: groundwork for a management sim

**Exit criteria, and where they are held:** a mouse-driven UI shell exists (`ui2/`, App.tsx); the sim runs at 8x
deterministically (tests/phase0.test.ts: "identical world at 1x and at 8x"); a generated floor can be created, saved,
loaded and left ("a generated floor can be…"); autosave works (`Autosaver`, tests); a 300-actor soak holds the frame
budget ("frame budget: a 300-actor soak…", 8 ms mean per tick).

## 0.1 Fixed timestep (`sim/clock.ts`, `sim/replay.ts`)
The sim steps only in ticks of `TICK = 1/30 s`. `Game.frame(realDt)` feeds wall time to a `SimClock`, which returns
how many ticks to run at the current speed (pause / 1x / 2x / 4x / 8x; other screens always 1x) and leaves `alpha`.
`Game.update(dt)` is still one raw step (tests call it directly). Rendering interpolates actor positions in view and
the camera between the last two ticks (`withInterpolation`: positions are swapped in for the draw and restored), so
motion is smooth at any refresh rate; teleports snap. Input is bound to ticks: `InputLog` + `simTick` replay a save
to an identical state no matter how many ticks each frame ran. `World.tick` counts ticks; it is derived from `time`
on load (not saved). Paused play still takes menus, saving and the shell, and keeps the scene animating.

## 0.2 Level of detail (`sim/lod.ts`)
Tiers come from sim state only (never the camera), so replays agree: **active** within `ACTIVE_BOX` of the player,
**near** elsewhere in the player's area, **far** in other areas. Only *stationary* work is coarsened (a task in
progress; townsfolk standing at what they do with no new plan due): owed time accumulates per actor in `World.lod`
(saved) and is paid in chunks (near 0.1 s, far 0.25 s); walking always steps in full, because traffic and yielding
need collision-accurate steps. Far townsfolk stay abstract and are set down where the hour says on entry. Entering an
area runs registered catch-up hooks with `world.time - area.lastTicked` (`registerCatchUp`: the ritual's charge,
townsfolk settling). Areas other than the player's no longer advance their features every tick.

## 0.3 Runtime areas (`world/areaSpec.ts`, `sim/expedition.ts`)
`AreaSpec {id, kind, seed, w, h, parent, depth, entry?, label?}` is saved in `World.specs`; `builderFor` picks an
authored builder from `AREAS` or a kind builder (`floor`, `cave`, `yard`) from `AREA_KINDS`. Kind builders are
deterministic, so saves keep the diff model; `fullGrid` kinds (yards) save an RLE grid. Exits use coordinate portals
(`@x,y`) back to where the area was opened. Overview → Areas creates, leaves and forgets them.

## 0.4 Saves v2 (`world/saveStore.ts`, `view/persistence.ts`)
IndexedDB key-value store (localStorage / memory fallbacks), three slots + autosave, checksummed records, rolling
backups (3 for autosave, one `.bak` per slot), corrupted-save recovery (falls back a generation, keeps
`corrupt:<slot>`), export / import to a file, one-time import of the v1 localStorage slot. Save v20 adds `specs`,
`lod`, `areaTicks`, and RLE tile grids when smaller than the diff (`RLE_THRESHOLD`); v19 saves load unchanged.
Budgets (`SAVE_BUDGET`) are held by tests. K quick-saves to slot 1, L loads the newest.

## 0.5 Input and UI v2 (`ui2/`)
A third canvas at 2x (settings: UI scale) holds the shell. `font2.ts` is a mixed-case proportional bitmap font;
`kit2.ts` an immediate-mode kit (button, toggle, slider, choice, tabs, scrolling list, sortable table, graph, modal,
menu, tooltip) with keyboard focus (Tab / arrows / Enter) and gamepad parity (pads arrive as keys). `shell.ts`: the
speed bar, panel buttons, notification feed (`notify.ts`, pause on alert), hover tooltips over actors, click and
drag-select, a right-click context menu, the selection panel, and the Overview / Saves / Settings panels (ordinary
Screens, so the world pauses under them).

## 0.6 The host, split (`view/`)
`game.ts` went from ~2,030 to ~1,100 lines: `view/worldRenderer.ts` (the scene, NPC looks, HUD),
`view/reactions.ts` (event reactions), `view/particles.ts`, `view/camera.ts`. Game keeps one-line delegators, so
`UiHost` and the tests are unchanged. `scripts/dev/splitHost.mjs` is the tool that did it.

## 0.7 Settings (`settings.ts`)
Volume sliders, screen shake and flash toggles, UI scale, smooth motion, pause on alerts, autosave interval, key
remapping (physical keys translate to the default key the code asks for) and colour-blind-safe overlay palettes. New
options register in `OPTIONS` and appear in the settings screen.

## 0.8 Soak and lint (`sim/soak.ts`, `content/lint.ts`, `scripts/soak.mjs`)
Invariants: nobody stuck, item totals conserved, no exclusive place held twice, unique ids, save round trip, frame
budget. The content linter checks every item, prop, recipe, craft row, thought, exchange, census row, setting,
action, authored portal and area kind.
