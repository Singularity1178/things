# Dustwake architecture (index)

The architecture notes are split per system (Phase 0.9). Start with the overview, then read the system you are changing.
Each page keeps the history of its decisions; **docs/phase0.md** describes the management-sim groundwork.

**Main boundary:** the World (`world/`, `sim/`, `content/`) never touches the DOM, canvas, audio or `Math.random`; the
tests import it straight into Node. Presentation (`view/`, `ui/`, `ui2/`, `screens/`, `game.ts`) reads the World,
calls sim entry points, and drains `world.events`.

| Area | Pages |
| --- | --- |
| Overview | [introduction](overview/intro.md) · [layers](overview/layers.md) · [Phase 0 groundwork](phase0.md) · [roadmap](roadmap.md) · [testing](testing.md) |
| Simulation | [time, ticks & determinism](sim/time.md) · [off-screen sim & level of detail](sim/offscreen.md) · [actors & power](sim/actors.md) · [orders & navigation](sim/orders.md) · [tasks & the slam](sim/tasks.md) · [storage & crafting](sim/storage.md) · [inventory & gear](sim/inventory.md) · [harvesting & building](sim/building.md) · [rune network](sim/runes.md) · [routes](sim/routes.md) · [vision & analysis](sim/vision.md) · [production rollout](sim/rollout.md) · [monologue](sim/monologue.md) · [NPCs & dialogue](sim/dialogue.md) · [townsfolk](sim/townsfolk.md) · [shops](sim/shops.md) |
| World | [areas & runtime areas](world/areas.md) · [saves](world/saves.md) · [Westwake](world/town.md) · [dungeon audit](world/dungeon-audit.md) · [the entrance](world/entrance.md) · [the stair below](world/stair-below.md) |
| Content & art | [content as data](content/data.md) · [rocks and stairs](art/rocks-and-stairs.md) |
| UI | [screens, layers & the shell](ui/screens.md) |
| How to add… | [a recipe](howto/add-a-recipe.md) · [a room or area kind](howto/add-a-room.md) · [a species / resident](howto/add-a-species.md) · [a setting](howto/add-a-setting.md) · [a panel](howto/add-a-panel.md) |

Tools: `npm test` (headless tests, incl. the content linter and the 300-actor frame budget), `node scripts/soak.mjs`
(long soak runs), and the preview scripts in `scripts/`.
