# How to add a setting
Add the field to `Settings` and `DEFAULT_SETTINGS` in `src/game/settings.ts`, then `registerOption({ id, section,
label, kind: "toggle" | "slider" | "choice", ... })`. The settings screen lists it under its section automatically;
read it from `game.settings`, and apply side effects in `Game.applySettings`. A remappable key is one more `ACTIONS` row.
