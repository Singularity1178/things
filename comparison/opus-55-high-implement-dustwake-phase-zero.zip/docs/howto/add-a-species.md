# How to add a species or resident type
1. A body: an `ACTORS` row (`content/actors.ts`: body box, speed, capabilities) and its art in `BODY_ART` or a new
   sprite module; NPCs with dialogue also need an `NPCS` row.
2. Townsfolk-like residents: an archetype in `ARCHETYPES` and rows in `CENSUS` (`content/folk.ts`) with a home spot
   in their area; routines are data.
3. Level of detail: if the new actor has its own tick, step it through `stepAtTier` (`sim/lod.ts`) and decide which of
   its states are stationary (safe to coarsen); register a catch-up hook if it should be "set down" on area entry.
4. Run `npm test` and `node scripts/soak.mjs actors=300` to check the invariants and the frame budget.
