# How to add a shell panel
Panels are Screens (so the world pauses under them) drawn on the hi-res layer with the `ui2/kit2.ts` widgets. Add an
id to `PANELS` and a screen in the `Shell` constructor (`ui2/shell.ts`), a draw method called from `Shell.panel`, a HUD
button, and an `ACTIONS` key. Use `ui.table` / `ui.scrollList` / `ui.tabs` for dense data; every widget joins the
keyboard focus order, so gamepad and keyboard work without extra code.
