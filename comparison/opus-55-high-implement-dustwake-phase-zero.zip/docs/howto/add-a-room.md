# How to add a room or an area kind
- **An authored area** (a fixed place): write a deterministic builder returning `AreaData` and register it in `AREAS`
  (`world/areas.ts`). Give it portals paired with portals in its neighbours (the linter checks both ends). Saves store
  only diffs against the builder, so keep prop ids stable across versions.
- **A generated kind** (floors, caves, outposts): add an entry to `AREA_KINDS` in `world/areaSpec.ts` with
  `build(spec)` (deterministic from `spec.seed`, `w`, `h`, `depth`; end with `finish()` so it gets an exit), size
  limits, and `fullGrid: true` if the player will rewrite most tiles. The linter builds every kind on three seeds and
  checks determinism, a floor start tile and the exit. `openGeneratedArea(w, actor, kind)` creates one.
