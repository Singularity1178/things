# How to add a recipe
1. **Build recipe** (a placeable prop): add a row to `RECIPES` in `src/game/content/build.ts` (name in the uppercase
   font, ≤3 desc lines of ≤34 chars, `prop` kind, `cost`). If the prop kind is new, add it to `PROPS`
   (`content/props.ts`) and its art to `PROP_ART` (`art/props*.ts`).
2. **Crafting recipe** (at a station): add a row to `CRAFT_RECIPES` in `content/crafting.ts` with `station`, `inputs`,
   `output`, optional `tools`.
3. Run `npm test`: the content linter checks names fit the font, item and prop references resolve, and amounts are
   positive. Saves need nothing: recipes are data.
