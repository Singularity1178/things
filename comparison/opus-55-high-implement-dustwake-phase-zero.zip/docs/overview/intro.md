# Dustwake architecture: introduction

Content: the tutorial dungeon (with its first NPC, the Treasury Guardian), plus the surface slice (rune travel, harvesting), a catalog-driven build menu with deconstruction, crafting at a bench (planks, cut stone, carved runes), and golem gear slots with an RPG-style paper-doll pack. This structure is the smallest one I could find that lets the planned game (surface, harvesting, construction, NPCs, management screens) grow without another rewrite. Every abstraction here is used either by the tutorial or by the tests.
