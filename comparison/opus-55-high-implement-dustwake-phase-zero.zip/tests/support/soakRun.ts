// Bundled by scripts/soak.mjs: runs the soak harness (src/game/sim/soak.ts) with command-line options.
import { runSoak } from "../../src/game/sim/soak";
import { lintContent } from "../../src/game/content/lint";
export function main(args: string[]): number {
  const opt = Object.fromEntries(args.map((a) => a.split("=")).filter((p) => p.length === 2)) as Record<string, string>;
  const issues = lintContent();
  for (const i of issues) console.log(`lint ${i.table}/${i.row} [${i.rule}] ${i.detail}`);
  const days = +(opt.days ?? 0), hours = days ? days * 24 : +(opt.hours ?? 2);
  const r = runSoak({ hours, actors: +(opt.actors ?? 300), seed: +(opt.seed ?? 1234), budgetMs: +(opt.budget ?? 4), area: opt.area ?? "town", startHour: +(opt.start ?? 9) });
  console.log(JSON.stringify({ ...r, itemDrift: r.itemDrift }, null, 2));
  return r.ok && !issues.length ? 0 : 1;
}
