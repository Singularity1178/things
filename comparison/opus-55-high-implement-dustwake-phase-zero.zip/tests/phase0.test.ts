// Phase 0 groundwork: fixed-timestep determinism, simulation level of detail, runtime areas, save system v2, the
// UI kit and font, settings, notifications, the content linter and the 300-actor soak (docs/phase0.md).
import { test } from "node:test";
import assert from "node:assert/strict";
import { installFakeCanvas } from "./support/fakeCanvas";
installFakeCanvas();
import { SimClock, TICK, SIM_HZ } from "../src/game/sim/clock";
import { InputLog, driveAtSpeed, replay, simTick } from "../src/game/sim/replay";
import { ACTIVE_BOX, FAR_INTERVAL, catchUpArea, registerCatchUp, stepAtTier, tierOf } from "../src/game/sim/lod";
import { createWorld, getArea, enterArea, player, makeActor, forgetArea, type World } from "../src/game/world/world";
import { serialize, deserialize, migrate, rleEncode, rleDecode, SAVE_VERSION, RLE_THRESHOLD } from "../src/game/world/save";
import { MemoryKv, SaveManager, Autosaver, exportText, importText, LEGACY_KEY, SAVE_BUDGET, pack } from "../src/game/world/saveStore";
import { openGeneratedArea, leaveGeneratedArea } from "../src/game/sim/expedition";
import { coordPortal, AREA_KINDS } from "../src/game/world/areaSpec";
import { T, TS } from "../src/game/content/tiles";
import { measure, wrap2, text2, FONT2_GLYPHS } from "../src/game/ui2/font2";
import { Pointer, Ui2 } from "../src/game/ui2/kit2";
import { NotificationFeed } from "../src/game/ui2/notify";
import { DEFAULT_SETTINGS, translateKey, loadSettings, saveSettings, OPTIONS, registerOption } from "../src/game/settings";
import { lintContent } from "../src/game/content/lint";
import { runSoak, makeSoakWorld, itemTotals } from "../src/game/sim/soak";
import { Game } from "../src/game/game";

const json = (w: World) => JSON.stringify(serialize(w));
const fresh = (seed = 42) => { const w = createWorld(seed); w.events.length = 0; return w; };
/** A stub 2D context: every method is a no-op, every property settable. */
const stubCtx = () => new Proxy({} as Record<string, unknown>, { get: (o, k) => (k in o ? o[k as string] : () => undefined), set: (o, k, v) => { o[k as string] = v; return true; } }) as unknown as CanvasRenderingContext2D;

// ---------------------------------------------------------------- 0.1 fixed timestep
test("the clock hands out whole ticks: 8x runs eight times as many, pause runs none, a stall is capped", () => {
  const c = new SimClock();
  let n = 0; for (let i = 0; i < 60; i++) n += c.advance(1 / 60, 1);
  assert.equal(n, SIM_HZ);
  const c8 = new SimClock(); let n8 = 0; for (let i = 0; i < 60; i++) n8 += c8.advance(1 / 60, 8);
  assert.equal(n8, SIM_HZ * 8);
  assert.equal(new SimClock().advance(1, 0), 0);
  assert.equal(new SimClock().advance(10, 1), Math.floor(0.25 / TICK + 1e-7), "a long stall only owes maxFrame");
  const a = new SimClock(); a.advance(TICK * 1.5, 1); assert.ok(Math.abs(a.alpha - 0.5) < 1e-6, "alpha is the leftover fraction");
  const s = new SimClock(); s.setSpeed(4); s.togglePause(); assert.equal(s.speed, 0); s.togglePause(); assert.equal(s.speed, 4); s.stepSpeed(1); assert.equal(s.speed, 8);
});

test("the same save and input stream give an identical world at 1x and at 8x, over any frame timing", () => {
  const base = fresh(7);
  for (let i = 0; i < 30; i++) simTick(base);
  const save = serialize(base);
  const log = new InputLog();
  const t0 = base.tick ?? 0;
  for (let i = 0; i < 240; i++) {
    const phase = Math.floor(i / 40) % 4;
    log.record(t0 + i, { ix: phase === 0 ? 1 : phase === 2 ? -1 : 0, iy: phase === 1 ? 1 : phase === 3 ? -1 : 0, use: i % 97 === 0 });
  }
  const a = deserialize(save), b = deserialize(save), c = deserialize(save);
  assert.equal(a.tick, t0, "the tick count comes back from the clock");
  const fa = driveAtSpeed(a, log, 400, 1, [1 / 60, 1 / 144, 1 / 30, 0.05, 1 / 75]);
  const fb = driveAtSpeed(b, log, 400, 8, [1 / 60]);
  replay(c, log, 400);
  assert.ok(fb < fa / 4, `8x needs far fewer frames (${fb} vs ${fa})`);
  assert.equal(json(a), json(b));
  assert.equal(json(a), json(c));
  assert.notEqual(player(a).x, player(deserialize(save)).x, "the input stream really moved the golem");
});

test("the host steps fixed ticks: frame() at 8x runs eight times the sim time of 1x, and pause runs none", () => {
  const canvas = () => (globalThis as unknown as { document: { createElement(t: string): HTMLCanvasElement } }).document.createElement("canvas");
  const g = new Game(canvas(), canvas(), canvas());
  g.resume(fresh(3));
  const t0 = g.world.time;
  for (let i = 0; i < 30; i++) { g.frame(1 / 60); g.render(); }
  const at1 = g.world.time - t0;
  assert.ok(Math.abs(at1 - 0.5) < TICK + 1e-9, `1x: half a second of frames is half a second of sim (${at1})`);
  g.clock.setSpeed(8);
  const t1 = g.world.time;
  for (let i = 0; i < 30; i++) g.frame(1 / 60);
  assert.ok(Math.abs(g.world.time - t1 - 4) < TICK * 8 + 1e-9, "8x: eight times as much");
  g.clock.setSpeed(0);
  const t2 = g.world.time;
  for (let i = 0; i < 30; i++) { g.frame(1 / 60); g.render(); }
  assert.equal(g.world.time, t2, "paused: no sim time passes");
  // the shell's keyboard: P resumes, = speeds up
  g.keyDown("p"); g.render(); g.keyUp("p");
  assert.equal(g.clock.speed, 8);
});

// ---------------------------------------------------------------- 0.2 level of detail
test("tiers come from sim state: active near the golem, near across its area, far elsewhere", () => {
  const w = fresh(), pl = player(w);
  const near = makeActor("n", "worker_golem", pl.area, pl.x + ACTIVE_BOX.x + 40, pl.y);
  const close = makeActor("c", "worker_golem", pl.area, pl.x + 20, pl.y);
  const far = makeActor("f", "worker_golem", "surface", 100, 100);
  assert.deepEqual([tierOf(w, close, pl), tierOf(w, near, pl), tierOf(w, far, pl), tierOf(w, pl, pl)], ["active", "near", "far", "active"]);
  // far: owed time is paid in chunks once the interval has passed
  const steps: number[] = [];
  for (let i = 0; i < 10; i++) stepAtTier(w, far, "far", TICK, (dt) => steps.push(dt));
  assert.ok(steps.length >= 1 && steps.length <= 2);
  assert.ok(Math.abs(steps.reduce((s, x) => s + x, 0) + (w.lod!.f ?? 0) - 10 * TICK) < 1e-9, "no time is lost or invented");
  assert.ok(steps.every((s) => s <= FAR_INTERVAL + 1e-9));
});

test("entering an area runs its catch-up hooks with world.time - area.lastTicked", () => {
  const w = fresh(), pl = player(w);
  const seen: [string, number][] = [];
  registerCatchUp("test.phase0", (_w, area, elapsed) => seen.push([area.id, elapsed]));
  for (let i = 0; i < 10; i++) simTick(w);
  const surface = getArea(w, "surface");
  const left = surface.lastTicked;
  for (let i = 0; i < 60; i++) simTick(w);
  enterArea(w, pl, "surface", surface.start.x, surface.start.y);
  simTick(w);
  const hit = seen.find(([id]) => id === "surface");
  assert.ok(hit && Math.abs(hit[1] - (w.time - TICK - left)) < 1e-6, JSON.stringify(seen));
  assert.equal(catchUpArea(w, surface), 0, "caught up: nothing more owed");
  registerCatchUp("test.phase0", () => {});
});

// ---------------------------------------------------------------- 0.3 dynamic areas
test("a generated floor can be created, edited, saved, loaded and left", () => {
  const w = fresh(11), pl = player(w);
  const surface = getArea(w, "surface");
  enterArea(w, pl, "surface", surface.start.x, surface.start.y);
  const spec = openGeneratedArea(w, pl, "floor")!;
  assert.ok(spec && pl.area === spec.id && spec.parent === "surface" && spec.depth === 1);
  const floor = getArea(w, spec.id);
  assert.equal(floor.tile(Math.floor(pl.x / TS), Math.floor(pl.y / TS)), T.FLOOR);
  // an edit is saved as a diff against the deterministic builder
  floor.setTile(2, 2, T.FLOOR);
  for (let i = 0; i < 20; i++) simTick(w);
  const s = serialize(w);
  assert.deepEqual(s.specs?.[spec.id], spec);
  const back = deserialize(JSON.parse(JSON.stringify(s)));
  assert.equal(json(back), json(w));
  assert.equal(getArea(back, spec.id).tile(2, 2), T.FLOOR);
  // leaving: out by the exit, back where it was opened
  const bp = player(back);
  assert.ok(leaveGeneratedArea(back, bp));
  assert.equal(bp.area, "surface");
  assert.ok(Math.hypot(bp.x - spec.entry!.x, bp.y - spec.entry!.y) < 24);
  assert.ok(forgetArea(back, spec.id) && !back.specs![spec.id] && !back.areas.has(spec.id));
  assert.ok(coordPortal("@10,20")?.arrive?.x === 10 && !coordPortal("exit"));
});

test("every area kind builds deterministically; a yard saves a run-length full grid", () => {
  for (const kind of Object.keys(AREA_KINDS)) {
    const w = fresh(5), pl = player(w);
    const spec = openGeneratedArea(w, pl, kind)!;
    const s = serialize(w);
    if (AREA_KINDS[kind].fullGrid) assert.ok(s.areas[spec.id].rle && !s.areas[spec.id].tiles.length, kind);
    assert.equal(json(deserialize(s)), json(w), kind);
  }
});

// ---------------------------------------------------------------- 0.4 saves v2
test("run-length grids round-trip, and big diffs are stored as one", () => {
  const g = new Uint8Array(500); g.fill(3, 10, 200); g[499] = 7;
  assert.deepEqual([...rleDecode(rleEncode(g), g.length)], [...g]);
  assert.throws(() => rleDecode([5, 1], 6));
  const w = fresh(), a = getArea(w, "dungeon");
  // a scattered edit stays a diff when that is smaller
  for (let i = 0; i < 40; i++) a.setTile(1 + i, 1, T.RUBBLE);
  assert.ok(!serialize(w).areas.dungeon.rle);
  // the whole floor re-laid: the run-length grid is far smaller than the diff
  for (let y = 0; y < a.h; y++) for (let x = 0; x < a.w; x++) a.setTile(x, y, T.RUBBLE);
  const s = serialize(w);
  assert.ok(a.w * a.h > RLE_THRESHOLD);
  assert.ok(s.areas.dungeon.rle && s.areas.dungeon.tiles.length === 0);
  assert.equal(json(deserialize(s)), json(w));
});

test("a v19 save still loads", () => {
  const w = fresh(9);
  for (let i = 0; i < 30; i++) simTick(w);
  const v19: Record<string, unknown> = JSON.parse(json(w));
  delete v19.specs; delete v19.lod; delete v19.areaTicks; v19.version = 19;
  assert.equal(SAVE_VERSION, 20);
  assert.equal((migrate(v19) as { version: number }).version, 20);
  const back = deserialize(v19);
  assert.equal(player(back).x, player(w).x);
  assert.ok(back.specs && back.lod);
});

test("slots keep backups, a corrupt save recovers from the generation before, and the bad record is kept", async () => {
  const kv = new MemoryKv(), m = new SaveManager(kv, () => 1000);
  const w = fresh(2);
  await m.save("slot1", w, "first");
  for (let i = 0; i < 30; i++) simTick(w);
  await m.save("slot1", w);
  assert.ok(await kv.get("save:slot1.bak"));
  kv.map.set("save:slot1", kv.map.get("save:slot1")!.replace(/"time":[0-9.]+/, '"time":999'));
  const r = await m.load("slot1");
  assert.ok(r.recovered && r.from === "slot1.bak" && /checksum/.test(r.error ?? ""));
  assert.ok(await kv.get("corrupt:slot1"));
  assert.equal(r.world.time, 0, "the older generation");
  // autosave keeps three rolling generations
  for (let i = 0; i < 5; i++) { simTick(w); await m.save("auto", w); }
  assert.ok((await kv.get("save:auto.3")) && !(await kv.get("save:auto.4")));
  kv.map.set("save:auto", "garbage"); kv.map.set("save:auto.1", pack("{not json"));
  const r2 = await m.load("auto");
  assert.equal(r2.from, "auto.2");
  // nothing usable at all
  await assert.rejects(m.load("slot3"));
  assert.equal((await m.list()).length, 4);
});

test("export / import round-trips; junk is refused with a reason; the v1 slot is imported once", async () => {
  const w = fresh(4);
  for (let i = 0; i < 15; i++) simTick(w);
  assert.equal(json(importText(exportText(w))), json(w));
  assert.throws(() => importText("{oops"), /bad JSON/);
  assert.throws(() => importText("{\"x\":1}"), /not a Dustwake save/);
  const legacy = new Map<string, string>([[LEGACY_KEY, JSON.stringify(serialize(w))]]);
  const store = { getItem: (k: string) => legacy.get(k) ?? null, setItem: (k: string, v: string) => void legacy.set(k, v) };
  const m = new SaveManager(new MemoryKv());
  assert.equal(await m.importLegacy(store), true);
  assert.equal(await m.importLegacy(store), false);
  assert.equal((await m.load("slot1")).world.seed, w.seed);
});

test("saves stay within the size and load-time budgets with a lived-in town", async () => {
  const w = makeSoakWorld({ hours: 0, actors: 120 });
  for (let i = 0; i < 60; i++) simTick(w);
  const m = new SaveManager(new MemoryKv());
  const meta = await m.save("slot2", w);
  assert.ok(meta.bytes < SAVE_BUDGET.bytes, `${meta.bytes} bytes`);
  const t0 = performance.now();
  await m.load("slot2");
  assert.ok(performance.now() - t0 < SAVE_BUDGET.loadMs, "load time");
});

test("autosave fires on its timer and on entering another area, not more often than minGap", () => {
  const a = new Autosaver(60, 20);
  assert.equal(a.tick(1, "dungeon"), null);
  assert.equal(a.tick(59.5, "dungeon"), "timer");
  assert.equal(a.tick(5, "surface"), null, "too soon after the last save");
  assert.equal(a.tick(20, "dungeon"), "area");
});

// ---------------------------------------------------------------- 0.5 UI
test("the UI font is mixed case and proportional, and wraps to a width", () => {
  assert.ok(FONT2_GLYPHS.has("a") && FONT2_GLYPHS.has("A") && FONT2_GLYPHS.has("?"));
  assert.ok(measure("iiii") < measure("mmmm"), "proportional");
  assert.equal(measure("Hello", 2), measure("Hello") * 2);
  const lines = wrap2("The quick brown fox jumps over the lazy golem, twice.", 80);
  assert.ok(lines.length > 1 && lines.every((l) => measure(l) <= 80));
  assert.equal(text2(stubCtx(), "Ab", 0, 0, "#fff"), measure("Ab"));
});

test("widgets answer the mouse and the keyboard alike", () => {
  const ptr = new Pointer(), ui = new Ui2(ptr), ctx = stubCtx();
  const frame = (f: () => void) => { ui.begin(ctx, 640, 360, 0); f(); ui.end(); ptr.endFrame(); };
  let clicks = 0;
  const btn = () => { if (ui.button("b", { x: 10, y: 10, w: 50, h: 16 }, "Go")) clicks++; };
  ptr.move(20, 15); ptr.press(0); frame(btn);
  ptr.release(0); frame(btn);
  assert.equal(clicks, 1, "press and release on it");
  assert.ok(ui.overUi());
  ui.keys.add("tab"); frame(btn); assert.equal(ui.focus, "b");
  ui.keys.add("enter"); frame(btn); assert.equal(clicks, 2, "Enter on the focused button");
  let v = 0.5;
  ui.focus = "s";
  ui.keys.add("arrowright"); frame(() => { v = ui.slider("s", { x: 0, y: 40, w: 100, h: 20 }, "Vol", v, 0, 1, 0.1); });
  assert.equal(v, 0.6);
  let on = false;
  ptr.move(5, 75); ptr.press(0); frame(() => { on = ui.toggle("t", { x: 0, y: 70, w: 100, h: 16 }, "Shake", on); });
  ptr.release(0); frame(() => { on = ui.toggle("t", { x: 0, y: 70, w: 100, h: 16 }, "Shake", on); });
  assert.equal(on, true);
  const st = { sort: 0, desc: false, sel: -1 };
  ptr.move(20, 120); ptr.press(0);
  let picked = -1;
  frame(() => { picked = ui.table("tb", { x: 0, y: 100, w: 200, h: 80 }, [{ label: "N", w: 100, get: (r: { n: string }) => r.n }], [{ n: "b" }, { n: "a" }], st); });
  assert.equal(picked, 1, "sorted by name, the first row shown is a: the pick maps back to its index in rows");
  assert.equal(st.sel, 1);
});

test("the notification feed merges repeats and asks to pause on alerts", () => {
  const f = new NotificationFeed();
  f.push("Hello"); f.push("Hello");
  assert.equal(f.items.length, 1); assert.equal(f.items[0].count, 2);
  assert.equal(f.consumePause(), false);
  f.push("Blocked", "alert");
  assert.equal(f.consumePause(), true); assert.equal(f.consumePause(), false);
  f.push("Quiet alert", "alert", { pause: false }); assert.equal(f.consumePause(), false);
  f.update(100); assert.equal(f.visible().length, 0);
});

// ---------------------------------------------------------------- 0.7 settings
test("remapped keys reach the game as the default key; the old key no longer does that action", () => {
  const s = { ...DEFAULT_SETTINGS, keymap: { use: "f" } };
  assert.equal(translateKey(s, "F"), "e");
  assert.equal(translateKey(s, "e"), null);
  assert.equal(translateKey(s, "w"), "w");
  const mem = new Map<string, string>(), store = { getItem: (k: string) => mem.get(k) ?? null, setItem: (k: string, v: string) => void mem.set(k, v) };
  saveSettings({ ...s, master: 0.3 }, store);
  assert.equal(loadSettings(store).master, 0.3);
  assert.deepEqual(loadSettings({ getItem: () => "{bad", setItem: () => {} }).keymap, {});
  const n = OPTIONS.length;
  registerOption({ id: "shake", section: "Accessibility", label: "Screen shake", kind: "toggle" });
  assert.equal(OPTIONS.length, n, "registering again replaces");
});

// ---------------------------------------------------------------- 0.8 lint and soak
test("content lint: every content row resolves and every line fits its font", () => {
  const issues = lintContent();
  assert.deepEqual(issues.map((i) => `${i.table}/${i.row} [${i.rule}] ${i.detail}`), []);
});

test("soak: a small town for two hours keeps every invariant", () => {
  const r = runSoak({ hours: 2, actors: 60, roundTripHours: 0.5, budgetMs: 50 });
  assert.ok(r.roundTrips >= 3);
  assert.deepEqual([r.stuck, r.placeConflicts, r.duplicateIds, r.itemDrift, r.roundTripFailures], [[], [], [], {}, []]);
});

/** The frame budget: mean sim cost of one tick with 300 actors. Two ticks (2x speed at 60 fps) must fit a 16.7 ms frame. */
const TICK_BUDGET_MS = 8;
test(`frame budget: a 300-actor soak holds ${TICK_BUDGET_MS} ms per tick`, () => {
  const w = makeSoakWorld({ hours: 1, actors: 300 });
  const items = itemTotals(w);
  const r = runSoak({ hours: 1, actors: 300, budgetMs: TICK_BUDGET_MS, roundTripHours: 0.5 }, w);
  console.log(`# soak: ${r.actors} actors, ${r.ticks} ticks, ${r.msPerTick.toFixed(2)} ms/tick (p95 ${r.p95Ms.toFixed(2)})`);
  assert.ok(r.actors >= 300);
  assert.ok(r.withinBudget, `${r.msPerTick.toFixed(2)} ms/tick over ${TICK_BUDGET_MS}`);
  assert.ok(r.ok, JSON.stringify({ ...r, items }));
});

test("the shell: every panel and tab draws, the mouse hovers, drag-selects and opens a context menu", () => {
  const canvas = () => (globalThis as unknown as { document: { createElement(t: string): HTMLCanvasElement } }).document.createElement("canvas");
  const g = new Game(canvas(), canvas(), canvas());
  const w = makeSoakWorld({ hours: 0, actors: 40 });
  g.resume(w);
  for (let i = 0; i < 10; i++) { g.frame(1 / 30); g.render(); }
  const sh = g.shell, p = sh.ptr;
  // drag across the whole view: everyone in sight is selected
  p.move(2, 40); p.press(0); g.render(); p.move(630, 350); g.render(); p.release(0); g.render();
  assert.ok(sh.selection.length > 0, "drag-select picked people");
  // right-click opens the context menu; Escape dismisses it
  p.move(320, 200); p.press(2); g.render(); p.release(2); g.render();
  g.keyDown("Escape"); g.render(); g.keyUp("Escape");
  for (const [key, id, tabs] of [["g", "overview", 4], ["j", "saves", 1], ["o", "settings", 5]] as const) {
    g.keyDown(key); g.render(); g.keyUp(key);
    assert.ok(g.screens.is(id), id);
    for (let t = 0; t < tabs; t++) { g.frame(1 / 30); g.render(); g.keyDown("e"); g.render(); g.keyUp("e"); }
    g.keyDown("Escape"); g.render(); g.keyUp("Escape");
    assert.ok(g.screens.is("play"), `${id} closed`);
  }
  // a generated floor from the host, and back out
  g.generateArea("floor");
  assert.ok(g.world.specs && Object.keys(g.world.specs).length === 1 && g.pl.area.includes("~floor"));
  g.leaveGenerated();
  assert.equal(g.pl.area, "town");
});
