import { useEffect, useRef } from "react";
import { Game, W, H } from "./game/game";
import { serialize } from "./game/world/save";
import { saveToStorage, loadFromStorage } from "./game/view/persistence";
import { foundationDemo, registerFoundations } from "./game/sim/debugFoundations";
import { setWorkerOrder } from "./game/sim/jobs";
import type { JobOrder } from "./game/world/jobs";
import { player } from "./game/world/world";

/**
 * Gamepad -> keys (keyboard parity, Phase 0.5): the game and the UI kit only ever see keys, so a pad works wherever
 * the keyboard does. Standard mapping: d-pad / left stick move and navigate, A interact / confirm, B back, X slam,
 * Y pack, Start pause, Select settings, LB / RB slower / faster, LT / RT tab between fields.
 */
const PAD_BUTTONS: Record<number, string> = { 0: "Enter", 1: "Escape", 2: " ", 3: "i", 4: "-", 5: "=", 6: "Tab", 7: "Tab", 8: "o", 9: "p", 12: "ArrowUp", 13: "ArrowDown", 14: "ArrowLeft", 15: "ArrowRight" };

export default function App() {
  const ref = useRef<HTMLCanvasElement>(null);
  const uiRef = useRef<HTMLCanvasElement>(null);
  const hiRef = useRef<HTMLCanvasElement>(null);
  const wrap = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Three stacked layers with the same display rect: the world canvas is sized to the current view (W x H times
    // the zoom level, 1 world px = 1 canvas px), the base UI canvas stays at W x H so the HUD and the original
    // overlays keep their look at every zoom, and the hi-res UI canvas (the management shell: 2x by default,
    // settings: UI scale) holds dense, readable information. All scale with nearest-neighbour (pixelated).
    const canvas = ref.current!;
    const ui = uiRef.current!;
    const hi = hiRef.current!;
    const game = new Game(canvas, ui, hi);
    // Developer hook (not player-facing): open with ?debug to get window.dustwake.
    if (new URLSearchParams(window.location.search).has("debug")) {
      registerFoundations();
      (window as unknown as Record<string, unknown>).dustwake = {
        game,
        serialize: () => serialize(game.world),
        save: () => saveToStorage(game.world),
        load: () => { const w = loadFromStorage(); if (w) game.resume(w); return !!w; },
        foundations: () => { game.resume(foundationDemo()); game.say("FOUNDATION FIXTURE: A WORKER GATHERS THROUGH THE RUNES."); },
        order: (id: string, order: JobOrder | null) => setWorkerOrder(game.world, player(game.world), id, order),
        floor: (kind = "floor") => game.generateArea(kind),
      };
    }
    let raf = 0;
    let last = performance.now();
    let running = true;

    // The display rect is fitted for the base size (integer steps from 2x up, as before), so the HUD never jumps
    // when zooming. The world canvas's scale is derived from the current view size.
    const fit = () => {
      const vw = window.innerWidth, vh = window.innerHeight;
      let s = Math.min(vw / W, vh / H);
      if (s >= 2) s = Math.floor(s);
      const dw = Math.round(W * s), dh = Math.round(H * s);
      const ws = dw / game.vw;
      for (const c of [canvas, ui, hi]) {
        c.style.width = `${dw}px`;
        c.style.height = `${dh}px`;
      }
      canvas.style.width = `${Math.round(game.vw * ws)}px`;
      canvas.style.height = `${Math.round(game.vh * ws)}px`;
    };
    game.onView = fit;
    fit();
    window.addEventListener("resize", fit);

    // "/" and "'" open Firefox quick-find and Backspace may navigate: the build menu's search field uses them.
    const block = new Set(["arrowup", "arrowdown", "arrowleft", "arrowright", " ", "tab", "/", "'", "backspace", "-", "="]);
    const kd = (e: KeyboardEvent) => {
      // Debug keybinds: Ctrl+0 opens the debug menu, Ctrl+1..6 debug kits (see Game.debugKey).
      if (e.ctrlKey && !e.altKey && !e.shiftKey) {
        const n = ({ Digit0: 0, Numpad0: 0, Digit1: 1, Digit2: 2, Digit3: 3, Digit4: 4, Digit5: 5, Digit6: 6, Numpad1: 1, Numpad2: 2, Numpad3: 3, Numpad4: 4, Numpad5: 5, Numpad6: 6 } as Record<string, number>)[e.code];
        if (n !== undefined) {
          e.preventDefault();
          if (!e.repeat) game.debugKey(n);
          return;
        }
      }
      if (block.has(e.key.toLowerCase())) e.preventDefault();
      game.keyDown(e.key, e.shiftKey);
    };
    const ku = (e: KeyboardEvent) => game.keyUp(e.key);

    // Mouse (Phase 0.5): pointer events on the top (hi-res) layer, in its own pixels.
    const ptr = game.shell.ptr;
    const toUi = (e: PointerEvent | MouseEvent) => {
      const r = hi.getBoundingClientRect();
      return { x: ((e.clientX - r.left) / r.width) * hi.width, y: ((e.clientY - r.top) / r.height) * hi.height };
    };
    const pm = (e: PointerEvent) => { const p = toUi(e); ptr.move(p.x, p.y); };
    const pd = (e: PointerEvent) => {
      const p = toUi(e); ptr.move(p.x, p.y); ptr.press(e.button === 2 ? 2 : e.button === 1 ? 1 : 0);
      hi.setPointerCapture?.(e.pointerId);
      // the title card and cutscenes still take any click as a key (as before)
      if (!game.shell.ui.overUi()) game.pointer();
    };
    const pu = (e: PointerEvent) => { const p = toUi(e); ptr.move(p.x, p.y); ptr.release(e.button === 2 ? 2 : e.button === 1 ? 1 : 0); };
    const pl = () => ptr.leave();
    const cm = (e: MouseEvent) => e.preventDefault();
    // Non-passive so the page never scrolls; the shell decides whether the wheel scrolls a list or zooms.
    const wh = (e: WheelEvent) => { e.preventDefault(); ptr.wheel += e.deltaY; };
    window.addEventListener("keydown", kd);
    window.addEventListener("keyup", ku);
    hi.addEventListener("pointermove", pm);
    hi.addEventListener("pointerdown", pd);
    hi.addEventListener("pointerup", pu);
    hi.addEventListener("pointerleave", pl);
    hi.addEventListener("contextmenu", cm);
    window.addEventListener("wheel", wh, { passive: false });
    const blur = () => game.keys.clear();
    window.addEventListener("blur", blur);

    // Gamepad polling: edges of buttons and the left stick become key presses.
    const padHeld = new Set<string>();
    const pollPads = () => {
      const pads = navigator.getGamepads?.() ?? [];
      const now = new Set<string>();
      for (const p of pads) {
        if (!p) continue;
        p.buttons.forEach((b, i) => { const k = PAD_BUTTONS[i]; if (k && b.pressed) now.add(k); });
        const [ax = 0, ay = 0] = p.axes;
        if (ax < -0.5) now.add("ArrowLeft"); if (ax > 0.5) now.add("ArrowRight");
        if (ay < -0.5) now.add("ArrowUp"); if (ay > 0.5) now.add("ArrowDown");
      }
      for (const k of now) if (!padHeld.has(k)) game.keyDown(k);
      for (const k of padHeld) if (!now.has(k)) game.keyUp(k);
      padHeld.clear(); for (const k of now) padHeld.add(k);
    };

    // Fixed-timestep loop (Phase 0.1): real time goes to the clock, which runs whole ticks; drawing interpolates.
    const loop = (now: number) => {
      if (!running) return;
      const dt = Math.max(0, (now - last) / 1000);
      last = now;
      pollPads();
      game.frame(dt);
      game.render();
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      game.onView = null;
      window.removeEventListener("resize", fit);
      window.removeEventListener("keydown", kd);
      window.removeEventListener("keyup", ku);
      window.removeEventListener("blur", blur);
      window.removeEventListener("wheel", wh);
      hi.removeEventListener("pointermove", pm);
      hi.removeEventListener("pointerdown", pd);
      hi.removeEventListener("pointerup", pu);
      hi.removeEventListener("pointerleave", pl);
      hi.removeEventListener("contextmenu", cm);
      game.sfx.ctx?.close();
      game.view.dispose();
      delete (window as unknown as Record<string, unknown>).dustwake;
    };
  }, []);

  return (
    <div ref={wrap} className="fixed inset-0 bg-black flex items-center justify-center overflow-hidden select-none">
      <div className="relative">
        <canvas ref={ref} width={W} height={H} className="block outline-none" style={{ imageRendering: "pixelated" }} />
        <canvas ref={uiRef} width={W} height={H} className="absolute inset-0 block outline-none pointer-events-none" style={{ imageRendering: "pixelated" }} />
        <canvas ref={hiRef} width={W * 2} height={H * 2} tabIndex={0} className="absolute inset-0 block outline-none" style={{ imageRendering: "pixelated", cursor: "default" }} />
      </div>
    </div>
  );
}
