// UI framework v2 (Phase 0.5): an immediate-mode widget kit for the hi-res UI layer. No DOM.
//
// Widgets are called every frame while drawing; each returns what the player did to it this frame. Mouse: hover,
// press/release (left, right), drag, wheel. Keyboard and gamepad parity (the gamepad arrives as keys, App.tsx):
// every interactive widget joins a focus order; Tab / Shift+Tab or Up / Down move focus, Enter or Space activates,
// Left / Right adjust sliders, tabs and choices. The kit records the rectangles it drew, so the host can tell
// whether the pointer is over UI (then the world ignores it). Colours follow the world's palette (ui/kit.ts: UI).
import { LINE_H, ellipsize, measure, text2, text2s, wrap2 } from "./font2";

export const C2 = {
  bg: "rgba(14,12,18,0.94)", panel: "#16131c", edge: "#3a3540", hi: "#4e4856", text: "#e2dac4", dim: "#8a8392", faint: "#5a5462",
  gold: "#d9b25a", amber: "#f0b050", ok: "#7ae08a", bad: "#e08a7a", accent: "#74dce2", focus: "#f0d27a", row: "#201c27", rowHi: "#2c2636", sel: "#3a3248",
} as const;

/** Pointer state in hi-res UI pixels, fed by the host from DOM events. */
export class Pointer {
  x = -1; y = -1;
  inside = false;
  down = [false, false, false];
  pressed = new Set<number>();
  released = new Set<number>();
  wheel = 0;
  /** Where the left button went down (UI px), while it is held. */
  dragFrom: { x: number; y: number } | null = null;
  /** Set once the held pointer has moved far enough to count as a drag. */
  dragging = false;
  move(x: number, y: number) {
    this.x = x; this.y = y; this.inside = true;
    if (this.dragFrom && !this.dragging && Math.hypot(x - this.dragFrom.x, y - this.dragFrom.y) > 6) this.dragging = true;
  }
  press(b: number) { this.down[b] = true; this.pressed.add(b); if (b === 0) { this.dragFrom = { x: this.x, y: this.y }; this.dragging = false; } }
  release(b: number) { this.down[b] = false; this.released.add(b); }
  leave() { this.inside = false; this.x = -1; this.y = -1; }
  /** Clear one-frame state (after the frame has been drawn). */
  endFrame() {
    this.pressed.clear(); this.wheel = 0;
    if (this.released.has(0)) { this.dragFrom = null; this.dragging = false; }
    this.released.clear();
  }
}

export interface Rect { x: number; y: number; w: number; h: number }
const inR = (r: Rect, x: number, y: number) => x >= r.x && y >= r.y && x < r.x + r.w && y < r.y + r.h;

export interface Column<T> { label: string; w: number; get: (row: T) => string; color?: (row: T) => string; align?: "left" | "right" }

export class Ui2 {
  ctx!: CanvasRenderingContext2D;
  w = 640; h = 360; t = 0;
  /** Keys pressed this frame (lowercase), for keyboard parity. Filled by the host, cleared by `end`. */
  keys = new Set<string>();
  shift = false;
  private regions: Rect[] = [];
  private lastRegions: Rect[] = [];
  private focusOrder: string[] = [];
  private lastFocusOrder: string[] = [];
  focus: string | null = null;
  /** The widget the left button went down on (a click needs press and release on the same one). */
  active: string | null = null;
  private tip: { text: string; x: number; y: number } | null = null;
  private scroll = new Map<string, number>();
  private wheelUsed = false;
  /** A modal open this frame: everything outside it ignores the pointer. */
  private modalRect: Rect | null = null;
  constructor(public ptr: Pointer) {}

  begin(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
    this.ctx = ctx; this.w = w; this.h = h; this.t = t;
    this.regions = []; this.focusOrder = []; this.tip = null; this.wheelUsed = false; this.modalRect = null;
  }
  /** Finish the frame: tooltip on top, focus keys, input cleared. */
  end() {
    if (this.tip) this.drawTip(this.tip);
    // focus moves with Tab / Shift+Tab / Up / Down over the order of the frame just drawn
    const order = this.focusOrder;
    if (order.length) {
      const i = this.focus ? order.indexOf(this.focus) : -1;
      const fwd = this.key("tab") && !this.shift || this.key("arrowdown"), back = this.key("tab") && this.shift || this.key("arrowup");
      if (fwd) this.focus = order[(i + 1) % order.length];
      else if (back) this.focus = order[(i - 1 + order.length) % order.length];
      else if (i < 0 && this.focus) this.focus = null;
    }
    this.lastRegions = this.regions; this.lastFocusOrder = order;
    if (this.ptr.released.has(0)) this.active = null;
    this.keys.clear();
  }
  /** Was the pointer over anything the kit drew last frame? (The host asks before letting the world have it.) */
  overUi(): boolean { return this.ptr.inside && this.lastRegions.some((r) => inR(r, this.ptr.x, this.ptr.y)); }
  get hasFocusables() { return this.lastFocusOrder.length > 0; }
  key(k: string) { return this.keys.has(k); }
  /** Claim a rectangle as UI (the world will not get the pointer there). */
  region(r: Rect) { this.regions.push(r); }
  private hover(r: Rect) {
    if (!this.ptr.inside || !inR(r, this.ptr.x, this.ptr.y)) return false;
    if (this.modalRect && !inR(this.modalRect, this.ptr.x, this.ptr.y)) return false;
    return true;
  }
  private focusable(id: string) { this.focusOrder.push(id); return this.focus === id; }
  tooltip(text: string) { this.tip = { text, x: this.ptr.x + 10, y: this.ptr.y + 12 }; }
  private drawTip(t: { text: string; x: number; y: number }) {
    const lines = wrap2(t.text, 180), w = Math.max(...lines.map((l) => measure(l))) + 10, h = lines.length * LINE_H + 6;
    const x = Math.min(t.x, this.w - w - 2), y = Math.min(t.y, this.h - h - 2);
    this.box({ x, y, w, h }, "rgba(8,7,10,0.96)", C2.hi);
    lines.forEach((l, i) => text2(this.ctx, l, x + 5, y + 4 + i * LINE_H, C2.text));
  }

  // ---------------------------------------------------------------- drawing
  box(r: Rect, fill: string = C2.panel, edge: string = C2.edge) {
    const c = this.ctx;
    c.fillStyle = edge; c.fillRect(r.x, r.y, r.w, r.h);
    c.fillStyle = fill; c.fillRect(r.x + 1, r.y + 1, r.w - 2, r.h - 2);
  }
  /** A framed panel with an optional title bar; claims its rectangle. Returns the content rect. */
  panel(r: Rect, title?: string): Rect {
    this.region(r);
    const c = this.ctx;
    c.fillStyle = "#08070a"; c.fillRect(r.x - 1, r.y - 1, r.w + 2, r.h + 2);
    this.box(r, C2.bg, C2.edge);
    c.fillStyle = C2.hi; c.fillRect(r.x + 1, r.y + 1, r.w - 2, 1);
    if (!title) return { x: r.x + 6, y: r.y + 6, w: r.w - 12, h: r.h - 12 };
    c.fillStyle = "#211c29"; c.fillRect(r.x + 1, r.y + 2, r.w - 2, 14);
    text2(c, title, r.x + 7, r.y + 5, C2.gold);
    return { x: r.x + 6, y: r.y + 21, w: r.w - 12, h: r.h - 27 };
  }
  label(s: string, x: number, y: number, color: string = C2.text, align: "left" | "center" | "right" = "left", scale = 1) { return text2(this.ctx, s, x, y, color, scale, align); }
  labelS(s: string, x: number, y: number, color: string = C2.text, align: "left" | "center" | "right" = "left", scale = 1) { return text2s(this.ctx, s, x, y, color, scale, align); }
  paragraph(s: string, r: Rect, color: string = C2.text) {
    const lines = wrap2(s, r.w);
    lines.forEach((l, i) => { if ((i + 1) * LINE_H <= r.h + 2) text2(this.ctx, l, r.x, r.y + i * LINE_H, color); });
    return lines.length * LINE_H;
  }

  // ---------------------------------------------------------------- widgets
  /** A push button. True on click (press and release on it) or Enter/Space while focused. */
  button(id: string, r: Rect, label: string, o: { on?: boolean; disabled?: boolean; tip?: string; color?: string } = {}): boolean {
    this.region(r);
    const hov = !o.disabled && this.hover(r), foc = !o.disabled && this.focusable(id);
    if (hov && this.ptr.pressed.has(0)) this.active = id;
    const held = this.active === id && this.ptr.down[0];
    this.box(r, o.on ? C2.sel : held ? "#0e0c12" : hov ? C2.rowHi : C2.row, foc ? C2.focus : o.on ? C2.gold : hov ? C2.hi : C2.edge);
    text2(this.ctx, ellipsize(label, r.w - 6), r.x + r.w / 2, r.y + Math.round((r.h - 9) / 2) + 1 + (held ? 1 : 0), o.disabled ? C2.faint : o.color ?? (o.on ? C2.gold : C2.text), 1, "center");
    if (hov && o.tip) this.tooltip(o.tip);
    if (o.disabled) return false;
    const clicked = hov && this.ptr.released.has(0) && this.active === id;
    return clicked || (foc && (this.key("enter") || this.key(" ")));
  }
  /** A labelled on/off switch. Returns the (possibly flipped) value. */
  toggle(id: string, r: Rect, label: string, value: boolean, tip?: string): boolean {
    this.region(r);
    const hov = this.hover(r), foc = this.focusable(id);
    if (hov) this.ctx.fillStyle = C2.rowHi, this.ctx.fillRect(r.x, r.y, r.w, r.h);
    if (hov && this.ptr.pressed.has(0)) this.active = id;
    text2(this.ctx, label, r.x + 4, r.y + Math.round((r.h - 9) / 2) + 1, foc ? C2.focus : C2.text);
    const sw = { x: r.x + r.w - 26, y: r.y + Math.round((r.h - 10) / 2), w: 22, h: 10 };
    this.box(sw, value ? "#2f5a3a" : "#2a2530", foc ? C2.focus : C2.hi);
    this.ctx.fillStyle = value ? C2.ok : C2.dim; this.ctx.fillRect(value ? sw.x + sw.w - 9 : sw.x + 1, sw.y + 1, 8, 8);
    if (hov && tip) this.tooltip(tip);
    const flip = (hov && this.ptr.released.has(0) && this.active === id) || (foc && (this.key("enter") || this.key(" ") || this.key("arrowleft") || this.key("arrowright")));
    return flip ? !value : value;
  }
  /** A horizontal slider. Drag or click to set; Left/Right step it while focused. Returns the new value. */
  slider(id: string, r: Rect, label: string, value: number, min: number, max: number, step: number, fmt: (v: number) => string = (v) => v.toFixed(2), tip?: string): number {
    this.region(r);
    const hov = this.hover(r), foc = this.focusable(id);
    if (hov && this.ptr.pressed.has(0)) this.active = id;
    text2(this.ctx, label, r.x + 4, r.y + 2, foc ? C2.focus : C2.text);
    text2(this.ctx, fmt(value), r.x + r.w - 4, r.y + 2, C2.dim, 1, "right");
    const track = { x: r.x + 4, y: r.y + r.h - 7, w: r.w - 8, h: 4 };
    this.box(track, "#2a2530", C2.edge);
    const k = (value - min) / (max - min || 1);
    this.ctx.fillStyle = C2.gold; this.ctx.fillRect(track.x + 1, track.y + 1, Math.round((track.w - 2) * k), 2);
    this.ctx.fillStyle = foc || this.active === id ? C2.focus : C2.text; this.ctx.fillRect(track.x + Math.round((track.w - 4) * k), track.y - 3, 4, 10);
    if (hov && tip) this.tooltip(tip);
    let v = value;
    if (this.active === id && this.ptr.down[0]) v = min + Math.max(0, Math.min(1, (this.ptr.x - track.x) / track.w)) * (max - min);
    if (foc && this.key("arrowleft")) v = value - step;
    if (foc && this.key("arrowright")) v = value + step;
    v = Math.round(v / step) * step;
    return Math.max(min, Math.min(max, +v.toFixed(6)));
  }
  /** A cycling choice (a slider over named values). */
  choice(id: string, r: Rect, label: string, value: string, values: string[], labels?: Record<string, string>, tip?: string): string {
    this.region(r);
    const hov = this.hover(r), foc = this.focusable(id);
    if (hov) { this.ctx.fillStyle = C2.rowHi; this.ctx.fillRect(r.x, r.y, r.w, r.h); }
    if (hov && this.ptr.pressed.has(0)) this.active = id;
    const ty = r.y + Math.round((r.h - 9) / 2) + 1;
    text2(this.ctx, label, r.x + 4, ty, foc ? C2.focus : C2.text);
    const shown = labels?.[value] ?? value;
    text2(this.ctx, `< ${shown} >`, r.x + r.w - 4, ty, C2.gold, 1, "right");
    if (hov && tip) this.tooltip(tip);
    let i = values.indexOf(value);
    if ((hov && this.ptr.released.has(0) && this.active === id) || (foc && (this.key("arrowright") || this.key("enter")))) i++;
    if ((hov && this.ptr.released.has(2)) || (foc && this.key("arrowleft"))) i--;
    return values[(i + values.length) % values.length];
  }
  /** A row of tabs. Returns the selected index. Left/Right switch while any tab is focused; Q/E always. */
  tabs(id: string, x: number, y: number, labels: string[], current: number, w?: number): number {
    let cx = x, sel = current;
    const foc = this.focusable(id);
    labels.forEach((l, i) => {
      const tw = w ?? measure(l) + 14, r = { x: cx, y, w: tw, h: 15 };
      this.region(r);
      const hov = this.hover(r), on = i === current;
      if (hov && this.ptr.pressed.has(0)) sel = i;
      this.box(r, on ? C2.sel : hov ? C2.rowHi : C2.row, on ? (foc ? C2.focus : C2.gold) : C2.edge);
      text2(this.ctx, l, cx + tw / 2, y + 4, on ? C2.gold : C2.text, 1, "center");
      cx += tw + 2;
    });
    if ((foc && this.key("arrowright")) || this.key("e")) sel = (current + 1) % labels.length;
    if ((foc && this.key("arrowleft")) || this.key("q")) sel = (current - 1 + labels.length) % labels.length;
    return sel;
  }
  /** A clipped, wheel-scrolled list. `draw` paints one row. Returns the clicked index (or Enter on the focused row), else -1. */
  scrollList<T>(id: string, r: Rect, items: T[], rowH: number, draw: (it: T, i: number, row: Rect, hover: boolean) => void, selected = -1): number {
    this.region(r);
    const c = this.ctx, hov = this.hover(r), foc = this.focusable(id);
    this.box(r, "#110f15", foc ? C2.focus : C2.edge);
    const total = items.length * rowH, maxS = Math.max(0, total - (r.h - 2));
    let s = this.scroll.get(id) ?? 0;
    if (hov && this.ptr.wheel && !this.wheelUsed) { s += Math.sign(this.ptr.wheel) * rowH * 3; this.wheelUsed = true; }
    let pick = -1;
    if (foc) {
      let sel = selected;
      if (this.key("pagedown")) sel = Math.min(items.length - 1, sel + 8);
      if (this.key("pageup")) sel = Math.max(0, sel - 8);
      if (sel !== selected) pick = sel;
      if (this.key("enter") && selected >= 0) pick = selected;
    }
    if (selected >= 0) { const top = selected * rowH; if (top < s) s = top; if (top + rowH > s + r.h - 2) s = top + rowH - (r.h - 2); }
    s = Math.max(0, Math.min(maxS, s));
    this.scroll.set(id, s);
    c.save(); c.beginPath(); c.rect(r.x + 1, r.y + 1, r.w - 2, r.h - 2); c.clip();
    const first = Math.floor(s / rowH), last = Math.min(items.length, Math.ceil((s + r.h) / rowH) + 1);
    for (let i = first; i < last; i++) {
      const row = { x: r.x + 1, y: r.y + 1 + i * rowH - s, w: r.w - 2 - (maxS ? 5 : 0), h: rowH };
      const rh = hov && inR(row, this.ptr.x, this.ptr.y);
      c.fillStyle = i === selected ? C2.sel : rh ? C2.rowHi : i % 2 ? "#15121a" : "#110f15";
      c.fillRect(row.x, row.y, row.w, row.h);
      draw(items[i], i, row, rh);
      if (rh && this.ptr.pressed.has(0)) pick = i;
    }
    c.restore();
    if (maxS) {
      const th = Math.max(10, (r.h - 4) * ((r.h - 2) / total)), ty = r.y + 2 + (r.h - 4 - th) * (s / maxS);
      c.fillStyle = C2.edge; c.fillRect(r.x + r.w - 5, r.y + 2, 3, r.h - 4);
      c.fillStyle = C2.dim; c.fillRect(r.x + r.w - 5, Math.round(ty), 3, Math.round(th));
    }
    if (!items.length) text2(c, "Nothing here.", r.x + r.w / 2, r.y + r.h / 2 - 4, C2.faint, 1, "center");
    return pick;
  }
  /** A sortable table over a scrolling list. Click a header to sort by it (again to reverse). Returns the clicked row index in `rows`. */
  table<T>(id: string, r: Rect, cols: Column<T>[], rows: T[], state: { sort: number; desc: boolean; sel: number }): number {
    const c = this.ctx;
    let cx = r.x + 1;
    cols.forEach((col, i) => {
      const hr = { x: cx, y: r.y, w: col.w, h: 14 };
      this.region(hr);
      const hov = this.hover(hr);
      if (hov && this.ptr.pressed.has(0)) { if (state.sort === i) state.desc = !state.desc; else { state.sort = i; state.desc = false; } }
      c.fillStyle = hov ? C2.rowHi : "#211c29"; c.fillRect(hr.x, hr.y, hr.w - 1, hr.h);
      text2(c, col.label + (state.sort === i ? (state.desc ? " v" : " ^") : ""), cx + 3, r.y + 3, state.sort === i ? C2.gold : C2.dim);
      cx += col.w;
    });
    const key = cols[state.sort]?.get;
    const order = rows.map((_, i) => i);
    if (key) order.sort((a, b) => { const x = key(rows[a]), y = key(rows[b]); const nx = parseFloat(x), ny = parseFloat(y); const d = !isNaN(nx) && !isNaN(ny) ? nx - ny : x < y ? -1 : x > y ? 1 : 0; return state.desc ? -d : d; });
    const selPos = order.indexOf(state.sel);
    const picked = this.scrollList(id, { x: r.x, y: r.y + 15, w: r.w, h: r.h - 15 }, order, 12, (ri, _i, row) => {
      let x = row.x;
      for (const col of cols) {
        const v = ellipsize(col.get(rows[ri]), col.w - 6);
        text2(c, v, col.align === "right" ? x + col.w - 4 : x + 3, row.y + 2, col.color?.(rows[ri]) ?? C2.text, 1, col.align === "right" ? "right" : "left");
        x += col.w;
      }
    }, selPos);
    if (picked >= 0) state.sel = order[picked];
    if (this.focus === id) {
      if (this.key("arrowright")) state.sel = order[Math.min(order.length - 1, selPos + 1)] ?? state.sel;
      if (this.key("arrowleft")) state.sel = order[Math.max(0, selPos - 1)] ?? state.sel;
    }
    return picked >= 0 ? order[picked] : -1;
  }
  /** A line graph of `series` (newest last), scaled to `max` (default: the series' peak). */
  graph(r: Rect, series: number[], o: { max?: number; color?: string; label?: string; unit?: string; budget?: number } = {}) {
    this.region(r);
    const c = this.ctx;
    this.box(r, "#110f15", C2.edge);
    const max = o.max ?? Math.max(1e-6, ...series, o.budget ?? 0);
    if (o.budget) { const by = r.y + r.h - 2 - (r.h - 4) * Math.min(1, o.budget / max); c.fillStyle = "rgba(224,138,122,0.5)"; for (let x = r.x + 2; x < r.x + r.w - 2; x += 4) c.fillRect(x, Math.round(by), 2, 1); }
    c.fillStyle = o.color ?? C2.accent;
    const n = series.length, w = r.w - 4;
    for (let i = 0; i < n; i++) {
      const x = r.x + 2 + Math.floor((i / Math.max(1, n - 1)) * (w - 1));
      const v = Math.min(1, series[i] / max), hgt = Math.max(1, Math.round(v * (r.h - 4)));
      c.fillRect(x, r.y + r.h - 2 - hgt, 1, 1);
      c.globalAlpha = 0.25; c.fillRect(x, r.y + r.h - 2 - hgt + 1, 1, hgt - 1); c.globalAlpha = 1;
    }
    if (o.label) text2(c, o.label, r.x + 4, r.y + 3, C2.dim);
    const last = series[n - 1];
    if (last !== undefined) text2(c, `${last.toFixed(2)}${o.unit ?? ""}`, r.x + r.w - 4, r.y + 3, C2.text, 1, "right");
  }
  /** Dim everything and draw a centred modal panel; claims the whole screen. Returns its content rect. */
  modal(w: number, h: number, title: string): Rect {
    this.ctx.fillStyle = "rgba(0,0,0,0.55)"; this.ctx.fillRect(0, 0, this.w, this.h);
    this.region({ x: 0, y: 0, w: this.w, h: this.h });
    const r = { x: Math.round((this.w - w) / 2), y: Math.round((this.h - h) / 2), w, h };
    const inner = this.panel(r, title);
    this.modalRect = r;
    return inner;
  }
  /** A small popup menu (right-click context). Returns the index picked, -1 for none, -2 if dismissed. */
  menu(id: string, x: number, y: number, items: string[]): number {
    const w = Math.max(80, ...items.map((s) => measure(s) + 16)), h = items.length * 13 + 4;
    const r = { x: Math.min(x, this.w - w - 2), y: Math.min(y, this.h - h - 2), w, h };
    this.region(r);
    this.box(r, "rgba(12,10,16,0.97)", C2.hi);
    let pick = -1;
    items.forEach((s, i) => {
      const row = { x: r.x + 2, y: r.y + 2 + i * 13, w: r.w - 4, h: 13 };
      const hov = this.hover(row), foc = this.focusable(`${id}.${i}`);
      if (hov || foc) { this.ctx.fillStyle = C2.sel; this.ctx.fillRect(row.x, row.y, row.w, row.h); }
      text2(this.ctx, s, row.x + 6, row.y + 3, hov || foc ? C2.gold : C2.text);
      if ((hov && this.ptr.released.has(0)) || (foc && this.key("enter"))) pick = i;
    });
    if (pick < 0 && ((this.ptr.pressed.size && !this.hover(r)) || this.key("escape"))) return -2;
    return pick;
  }
}
