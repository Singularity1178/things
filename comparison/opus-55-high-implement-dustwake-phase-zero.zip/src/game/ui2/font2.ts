// A mixed-case, proportional bitmap font for the hi-res UI layer (Phase 0.5). No DOM: draws with fillRect runs, so
// it works on any 2D context (and the tests' fake canvas), and measures exactly, so layout and the content linter
// can check that a line fits without a browser. Cap height 7, descenders 2, 1px between glyphs. The world's
// uppercase font (font.ts) is unchanged.

const SRC: Record<string, string> = {
  A: ".###./#...#/#...#/#####/#...#/#...#/#...#", B: "####./#...#/#...#/####./#...#/#...#/####.",
  C: ".###./#...#/#..../#..../#..../#...#/.###.", D: "####./#...#/#...#/#...#/#...#/#...#/####.",
  E: "#####/#..../#..../####./#..../#..../#####", F: "#####/#..../#..../####./#..../#..../#....",
  G: ".###./#...#/#..../#.###/#...#/#...#/.####", H: "#...#/#...#/#...#/#####/#...#/#...#/#...#",
  I: "###/.#./.#./.#./.#./.#./###", J: "..###/...#./...#./...#./#..#./#..#./.##..",
  K: "#...#/#..#./#.#../##.../#.#../#..#./#...#", L: "#..../#..../#..../#..../#..../#..../#####",
  M: "#...#/##.##/#.#.#/#.#.#/#...#/#...#/#...#", N: "#...#/##..#/#.#.#/#..##/#...#/#...#/#...#",
  O: ".###./#...#/#...#/#...#/#...#/#...#/.###.", P: "####./#...#/#...#/####./#..../#..../#....",
  Q: ".###./#...#/#...#/#...#/#.#.#/#..#./.##.#", R: "####./#...#/#...#/####./#.#../#..#./#...#",
  S: ".###./#...#/#..../.###./....#/#...#/.###.", T: "#####/..#../..#../..#../..#../..#../..#..",
  U: "#...#/#...#/#...#/#...#/#...#/#...#/.###.", V: "#...#/#...#/#...#/#...#/.#.#./.#.#./..#..",
  W: "#...#/#...#/#...#/#.#.#/#.#.#/##.##/#...#", X: "#...#/#...#/.#.#./..#../.#.#./#...#/#...#",
  Y: "#...#/#...#/.#.#./..#../..#../..#../..#..", Z: "#####/....#/...#./..#../.#.../#..../#####",
  a: "..../..../.###/...#/.###/#..#/.###", b: "#.../#.../###./#..#/#..#/#..#/###.",
  c: "..../..../.###/#.../#.../#.../.###", d: "...#/...#/.###/#..#/#..#/#..#/.###",
  e: "..../..../.##./#..#/####/#.../.###", f: "..##/.#../###./.#../.#../.#../.#..",
  g: "..../..../.###/#..#/#..#/#..#/.###/...#/.##.", h: "#.../#.../###./#..#/#..#/#..#/#..#",
  i: "#/./#/#/#/#/#", j: "..#/.../..#/..#/..#/..#/..#/..#/##.", k: "#.../#.../#..#/#.#./##../#.#./#..#",
  l: "#./#./#./#./#./#./.#", m: "...../...../##.#./#.#.#/#.#.#/#.#.#/#.#.#", n: "..../..../###./#..#/#..#/#..#/#..#",
  o: "..../..../.##./#..#/#..#/#..#/.##.", p: "..../..../###./#..#/#..#/#..#/###./#.../#...",
  q: "..../..../.###/#..#/#..#/#..#/.###/...#/...#", r: "..../..../#.##/##../#.../#.../#...",
  s: "..../..../.###/#.../.##./...#/###.", t: ".#../.#../###./.#../.#../.#../..##",
  u: "..../..../#..#/#..#/#..#/#..#/.###", v: "...../...../#...#/#...#/.#.#./.#.#./..#..",
  w: "...../...../#...#/#.#.#/#.#.#/#.#.#/.#.#.", x: "...../...../#...#/.#.#./..#../.#.#./#...#",
  y: "..../..../#..#/#..#/#..#/#..#/.###/...#/.##.", z: "..../..../####/...#/.##./#.../####",
  "0": ".##./#..#/#.##/##.#/#..#/#..#/.##.", "1": ".#./##./.#./.#./.#./.#./###", "2": ".##./#..#/...#/..#./.#../#.../####",
  "3": "###./...#/...#/.##./...#/...#/###.", "4": "..#./.##./#.#./#.#./####/..#./..#.", "5": "####/#.../###./...#/...#/#..#/.##.",
  "6": ".##./#.../#.../###./#..#/#..#/.##.", "7": "####/...#/..#./..#./.#../.#../.#..", "8": ".##./#..#/#..#/.##./#..#/#..#/.##.",
  "9": ".##./#..#/#..#/.###/...#/...#/.##.",
  " ": ".../.../.../.../.../.../...", ".": "./././././././#", ",": "../../../../../../.#/#.", ":": "./././#/./././#",
  ";": "../../../.#/../../.#/#.", "!": "#/#/#/#/#/./#", "?": ".##./#..#/...#/..#./.#../..../.#..", "'": "#/#/./././././",
  '"': "#.#/#.#/.../.../.../.../...", "-": "..../..../..../####/..../..../....", "+": "...../..#../..#../#####/..#../..#../.....",
  "=": "..../..../####/..../####/..../....", "/": "...#/...#/..#./..#./.#../.#../#...", "\\": "#.../#.../.#../.#../..#./..#./...#",
  "(": ".#/#./#./#./#./#./.#", ")": "#./.#/.#/.#/.#/.#/#.", "[": "##/#./#./#./#./#./##", "]": "##/.#/.#/.#/.#/.#/##",
  "%": "##..#/##.#./...#./..#../.#.../.#.##/#..##", "#": ".#.#./.#.#./#####/.#.#./#####/.#.#./.#.#.",
  "*": "...../#.#.#/.###./#####/.###./#.#.#/.....", "<": "...#/..#./.#../#.../.#../..#./...#", ">": "#.../.#../..#./...#/..#./.#../#...",
  _: "..../..../..../..../..../..../####", "&": ".##../#..#./#.#../.#.../#.#.#/#..#./.##.#", "@": ".###./#...#/#.###/#.#.#/#.##./#..../.####",
  $: "..#../.####/#.#../.###./..#.#/####./..#..", "^": "..#../.#.#./#...#/...../...../...../.....", "~": "...../...../.#..#/#.##./...../...../.....",
  "|": "#/#/#/#/#/#/#", "`": "#./.#/../../../../..",
};

interface Glyph { w: number; rows: number[] }
const GLYPHS: Record<string, Glyph> = {};
for (const [ch, s] of Object.entries(SRC)) {
  const rows = s.split("/");
  const w = Math.max(...rows.map((r) => r.length));
  GLYPHS[ch] = { w, rows: rows.map((r) => [...r].reduce((m, c, i) => (c === "#" ? m | (1 << (w - 1 - i)) : m), 0)) };
}
const ALIAS: Record<string, string> = { "\u2014": "-", "\u2013": "-", "\u2019": "'", "\u2018": "'", "\u201c": '"', "\u201d": '"', "\u00d7": "x", "\u2026": "..." };

export const FONT2_HEIGHT = 9;
/** Distance between baselines of wrapped lines. */
export const LINE_H = 11;
export const FONT2_GLYPHS: ReadonlySet<string> = new Set(Object.keys(GLYPHS));

const norm = (s: string) => s.replace(/[\u2014\u2013\u2019\u2018\u201c\u201d\u00d7\u2026]/g, (c) => ALIAS[c] ?? "?");
const glyphOf = (c: string) => GLYPHS[c] ?? GLYPHS["?"];

/** Width of `s` in pixels at `scale`. */
export function measure(s: string, scale = 1): number {
  s = norm(s);
  let w = 0;
  for (const c of s) w += glyphOf(c).w + 1;
  return Math.max(0, w - 1) * scale;
}

/** Draw `s` with its top-left at (x, y). Returns the width drawn. */
export function text2(ctx: CanvasRenderingContext2D, s: string, x: number, y: number, color: string, scale = 1, align: "left" | "center" | "right" = "left"): number {
  s = norm(s);
  const w = measure(s, scale);
  let cx = Math.round(align === "center" ? x - w / 2 : align === "right" ? x - w : x);
  const cy = Math.round(y);
  ctx.fillStyle = color;
  for (const c of s) {
    const g = glyphOf(c);
    for (let r = 0; r < g.rows.length; r++) {
      const bits = g.rows[r];
      if (!bits) continue;
      // merge horizontal runs into one rect each
      let i = 0;
      while (i < g.w) {
        if (!(bits & (1 << (g.w - 1 - i)))) { i++; continue; }
        let j = i;
        while (j < g.w && bits & (1 << (g.w - 1 - j))) j++;
        ctx.fillRect(cx + i * scale, cy + r * scale, (j - i) * scale, scale);
        i = j;
      }
    }
    cx += (g.w + 1) * scale;
  }
  return w;
}

/** Draw with a 1px dark drop shadow (readable over the world). */
export function text2s(ctx: CanvasRenderingContext2D, s: string, x: number, y: number, color: string, scale = 1, align: "left" | "center" | "right" = "left") {
  text2(ctx, s, x + scale, y + scale, "rgba(0,0,0,0.85)", scale, align);
  return text2(ctx, s, x, y, color, scale, align);
}

/** Greedy word wrap to `width` px. Words longer than a line are broken. */
export function wrap2(s: string, width: number, scale = 1): string[] {
  const out: string[] = [];
  for (const para of norm(s).split("\n")) {
    let line = "";
    for (const word of para.split(/\s+/).filter(Boolean)) {
      const tryLine = line ? `${line} ${word}` : word;
      if (measure(tryLine, scale) <= width) { line = tryLine; continue; }
      if (line) out.push(line);
      line = word;
      while (measure(line, scale) > width && line.length > 1) {
        let k = line.length - 1;
        while (k > 1 && measure(line.slice(0, k), scale) > width) k--;
        out.push(line.slice(0, k)); line = line.slice(k);
      }
    }
    out.push(line);
  }
  return out;
}

/** Shorten `s` with an ellipsis so it fits `width`. */
export function ellipsize(s: string, width: number, scale = 1): string {
  if (measure(s, scale) <= width) return s;
  let k = s.length;
  while (k > 0 && measure(s.slice(0, k) + "...", scale) > width) k--;
  return s.slice(0, k) + "...";
}
