// The management shell (Phase 0.5): everything drawn on the hi-res UI layer. The HUD bar (game speed, clock, panel
// buttons), the notification feed, mouse interaction with the world (hover tooltips, click and drag-select,
// right-click context menu), the selection panel, and the modal panels (overview, saves, settings), which are
// ordinary Screens on the stack, so the world pauses under them exactly as under the pack.
import type { Game } from "../game";
import type { Screen } from "../ui/screens";
import { C2, Pointer, Ui2, type Rect } from "./kit2";
import { LINE_H, ellipsize, measure, text2 } from "./font2";
import { NotificationFeed } from "./notify";
import { SPEEDS, speedLabel, type Speed } from "../sim/clock";
import { tierOf, tierCounts } from "../sim/lod";
import { ACTIONS, OPTIONS, boundKey, keyName, type Settings } from "../settings";
import { clockText } from "../content/daycycle";
import { worldHour } from "../sim/daytime";
import { TS } from "../content/tiles";
import { isFolk, folkLabel } from "../sim/folk";
import { keeperLabel } from "../sim/shops";
import { npcDef } from "../content/npcs";
import { actorDef } from "../content/actors";
import { generatedAreas, forgetArea } from "../sim/expedition";
import { MANUAL_SLOTS, AUTO_SLOT, type SlotMeta } from "../world/saveStore";
import type { Actor } from "../world/world";

export type PanelId = "overview" | "saves" | "settings";
const PANELS: PanelId[] = ["overview", "saves", "settings"];

export function actorLabel(a: Actor): string {
  if (isFolk(a)) return folkLabel(a);
  if (a.keeper) return keeperLabel(a);
  if (a.name) return `${a.name} - ${actorDef(a).name ?? a.kind}`;
  if (a.npc) return npcDef(a.npc)?.name ?? a.npc;
  return (actorDef(a).name ?? a.kind).toString();
}
export function actorDoing(a: Actor): string {
  if (a.task) return a.task.kind;
  if (a.job && a.job.status !== "done") return `${a.job.status}${a.job.reason ? ` (${a.job.reason})` : ""}`;
  if (a.life) return a.life.state === "do" ? a.life.act : a.life.state;
  if (a.keeper) return "keeping shop";
  return a.moving ? "walking" : "idle";
}
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
const ago = (ms: number) => { const s = Math.max(0, (Date.now() - ms) / 1000); return s < 60 ? `${s | 0}s ago` : s < 3600 ? `${(s / 60) | 0}m ago` : s < 86400 ? `${(s / 3600) | 0}h ago` : `${(s / 86400) | 0}d ago`; };

export class Shell {
  ptr = new Pointer();
  ui = new Ui2(this.ptr);
  feed = new NotificationFeed();
  selection: string[] = [];
  private context: { x: number; y: number; actor: string | null; wx: number; wy: number } | null = null;
  private tab = { overview: 0, settings: 0 };
  private tables = { residents: { sort: 0, desc: false, sel: -1 }, areas: { sort: 0, desc: false, sel: -1 }, saves: { sort: 0, desc: false, sel: 0 } };
  private rebinding: string | null = null;
  slots: (SlotMeta | null)[] = [];
  status: { text: string; ok: boolean; t: number } | null = null;
  /** Rolling performance samples for the overview (ms per sim tick, ms per frame, ticks per frame). */
  perf = { tick: [] as number[], frame: [] as number[], ticks: [] as number[] };
  readonly screens: Record<PanelId, Screen>;

  constructor(private g: Game) {
    const mk = (id: PanelId): Screen => ({ id, opaque: false, t: 0, update: (dt) => g.animate(dt), render: () => {} });
    this.screens = { overview: mk("overview"), saves: mk("saves"), settings: mk("settings") };
  }

  open(p: PanelId) {
    if (this.g.screens.is(p)) return this.close();
    if (PANELS.includes(this.g.screens.top?.id as PanelId)) this.g.screens.pop();
    this.g.screens.push(this.screens[p]);
    this.ui.focus = null; this.rebinding = null;
    if (p === "saves") this.refreshSlots();
    this.g.sfx.tone(600, 0.04, "triangle", 0.03);
  }
  close() { if (PANELS.includes(this.g.screens.top?.id as PanelId)) { this.g.screens.pop(); this.g.sfx.tone(420, 0.04, "triangle", 0.03); } }
  refreshSlots() { this.g.saves.list().then((s) => { this.slots = s; }, () => {}); }
  tell(text: string, ok = true) { this.status = { text, ok, t: this.g.t }; }
  sample(key: keyof Shell["perf"], v: number) { const s = this.perf[key]; s.push(v); if (s.length > 180) s.shift(); }

  /** Per frame, before the sim ticks: notices age, alerts pause, the wheel zooms when it is not over UI. */
  update(realDt: number) {
    const g = this.g;
    this.feed.update(realDt);
    if (this.feed.consumePause() && g.settings.pauseOnAlert && g.screens.is("play") && g.clock.speed !== 0) { g.clock.setSpeed(0); }
    if (this.ptr.wheel && g.screens.is("play") && !this.ui.overUi()) { g.wheel(this.ptr.wheel); this.ptr.wheel = 0; }
  }

  // ---------------------------------------------------------------- coordinates
  /** Hi-res UI px -> world px (the world canvas shows vw x vh over the same display rect). */
  toWorld(ux: number, uy: number) { const g = this.g; return { x: g.cam.x + (ux / this.ui.w) * g.vw, y: g.cam.y + (uy / this.ui.h) * g.vh }; }
  toUi(wx: number, wy: number) { const g = this.g; return { x: ((wx - g.cam.x) / g.vw) * this.ui.w, y: ((wy - g.cam.y) / g.vh) * this.ui.h }; }
  actorAt(wx: number, wy: number): Actor | null {
    const g = this.g;
    let best: Actor | null = null, bd = 1e9;
    for (const a of g.world.actors) {
      if (a.area !== g.pl.area || (a.life && a.life.state === "indoors")) continue;
      const dx = Math.abs(wx - a.x), dy = a.y - wy;
      if (dx <= 9 && dy >= -3 && dy <= 26) { const d = dx + Math.abs(dy - 10); if (d < bd) { bd = d; best = a; } }
    }
    return best;
  }

  // ---------------------------------------------------------------- render
  render(ctx: CanvasRenderingContext2D, w: number, h: number) {
    const g = this.g, ui = this.ui;
    ctx.clearRect(0, 0, w, h);
    ui.begin(ctx, w, h, g.t);
    const top = g.screens.top?.id ?? "";
    const base = top === "play" || PANELS.includes(top as PanelId);
    if (base) {
      if (top === "play") this.worldInput();
      this.drawSelection();
      this.hud();
    }
    this.drawFeed(base);
    if (PANELS.includes(top as PanelId)) this.panel(top as PanelId);
    if (top === "play") this.hotkeys();
    if (this.context && top === "play") this.contextMenu();
    ui.end();
    this.ptr.endFrame();
  }

  private hotkeys() {
    const g = this.g, ui = this.ui;
    if (ui.key("p")) g.clock.togglePause();
    if (ui.key("-")) g.clock.stepSpeed(-1);
    if (ui.key("=") || ui.key("+")) g.clock.stepSpeed(1);
    if (ui.key("g")) this.open("overview");
    if (ui.key("j")) this.open("saves");
    if (ui.key("o")) this.open("settings");
  }

  private hud() {
    const g = this.g, ui = this.ui, W = ui.w;
    const bw = 22, y = 4;
    let x = W - 4 - (SPEEDS.length * (bw + 2)) - 3 * 58 - 8;
    ui.panel({ x: x - 4, y: y - 3, w: W - x + 1, h: 22 });
    for (const s of SPEEDS) {
      const on = g.clock.speed === s;
      if (ui.button(`speed.${s}`, { x, y, w: bw, h: 16 }, s === 0 ? "||" : `${s}x`, { on, tip: s === 0 ? `Pause (${keyName(boundKey(g.settings, "pause"))})` : `Game speed ${s}x (${keyName(boundKey(g.settings, "slower"))} / ${keyName(boundKey(g.settings, "faster"))})` })) g.clock.setSpeed(s as Speed);
      x += bw + 2;
    }
    x += 6;
    const labels: Record<PanelId, string> = { overview: "Overview", saves: "Saves", settings: "Settings" };
    const keys: Record<PanelId, string> = { overview: "overview", saves: "saves", settings: "options" };
    for (const p of PANELS) {
      const unread = p === "overview" && this.feed.unread ? ` ${this.feed.unread}` : "";
      if (ui.button(`panel.${p}`, { x, y, w: 56, h: 16 }, labels[p] + unread, { on: g.screens.is(p), tip: `${labels[p]} (${keyName(boundKey(g.settings, keys[p]))})` })) this.open(p);
      x += 58;
    }
    // under the bar: the day, the hour and the speed, small
    const day = Math.floor(g.world.day) + 1, hour = clockText(worldHour(g.world));
    const info = `Day ${day}  ${hour}  ${speedLabel(g.clock.speed)}`;
    ui.labelS(info, W - 6, 27, g.clock.speed === 0 ? C2.amber : C2.dim, "right");
    if (g.clock.speed === 0 && g.screens.is("play")) ui.labelS("PAUSED", W / 2, 8, C2.amber, "center", 2);
  }

  private drawFeed(base: boolean) {
    const ui = this.ui, list = this.feed.visible(base ? 5 : 2);
    let y = 40;
    for (const n of list) {
      const text = n.count > 1 ? `${n.text} (x${n.count})` : n.text;
      const w = Math.min(230, measure(text) + 14), r = { x: ui.w - w - 6, y, w, h: 15 };
      const fade = Math.min(1, (8 - n.age) / 1.5);
      ui.ctx.globalAlpha = Math.max(0.15, fade);
      ui.box(r, "rgba(12,10,16,0.9)", n.level === "alert" ? C2.bad : n.level === "good" ? C2.ok : C2.edge);
      ui.ctx.fillStyle = n.level === "alert" ? C2.bad : n.level === "good" ? C2.ok : C2.accent; ui.ctx.fillRect(r.x + 1, r.y + 1, 2, r.h - 2);
      text2(ui.ctx, ellipsize(text, w - 12), r.x + 7, r.y + 4, C2.text);
      ui.ctx.globalAlpha = 1;
      ui.region(r);
      if (this.ptr.inside && this.ptr.x >= r.x && this.ptr.y >= r.y && this.ptr.x < r.x + r.w && this.ptr.y < r.y + r.h) {
        ui.tooltip(`${n.text}\nClick to dismiss.`);
        if (this.ptr.pressed.has(0)) this.feed.dismiss(n.id);
      }
      y += 17;
    }
  }

  // ---------------------------------------------------------------- the world under the mouse
  private worldInput() {
    const g = this.g, ui = this.ui, p = this.ptr;
    if (!p.inside || ui.overUi() || this.context) return;
    const at = this.toWorld(p.x, p.y), hov = this.actorAt(at.x, at.y);
    if (hov && !p.dragging) {
      const tier = tierOf(g.world, hov, g.pl);
      ui.tooltip(`${actorLabel(hov)}\n${cap(actorDoing(hov))} - ${tier}`);
      const s = this.toUi(hov.x, hov.y);
      this.bracket(s.x, s.y, C2.accent);
    }
    if (p.dragging && p.dragFrom) {
      const r = { x: Math.min(p.dragFrom.x, p.x), y: Math.min(p.dragFrom.y, p.y), w: Math.abs(p.x - p.dragFrom.x), h: Math.abs(p.y - p.dragFrom.y) };
      ui.ctx.fillStyle = "rgba(116,220,226,0.12)"; ui.ctx.fillRect(r.x, r.y, r.w, r.h);
      ui.ctx.fillStyle = C2.accent; ui.ctx.fillRect(r.x, r.y, r.w, 1); ui.ctx.fillRect(r.x, r.y + r.h, r.w + 1, 1); ui.ctx.fillRect(r.x, r.y, 1, r.h); ui.ctx.fillRect(r.x + r.w, r.y, 1, r.h);
      if (p.released.has(0)) {
        const a0 = this.toWorld(r.x, r.y), a1 = this.toWorld(r.x + r.w, r.y + r.h);
        this.selection = g.world.actors.filter((a) => a.area === g.pl.area && a.x >= a0.x && a.x <= a1.x && a.y - 8 >= a0.y && a.y - 8 <= a1.y && !(a.life?.state === "indoors")).map((a) => a.id);
        if (this.selection.length) g.sfx.tone(700, 0.04, "triangle", 0.03);
      }
    } else if (p.released.has(0) && !p.dragging) {
      this.selection = hov ? [hov.id] : [];
    }
    if (p.pressed.has(2)) this.context = { x: p.x, y: p.y, actor: hov?.id ?? null, wx: at.x, wy: at.y };
  }

  private bracket(x: number, y: number, col: string) {
    const c = this.ui.ctx, s = this.ui.w / 320, w = 10 * s, top = y - 26 * s, bot = y + 3 * s;
    c.fillStyle = col;
    for (const [bx, by, dx, dy] of [[x - w, top, 1, 1], [x + w, top, -1, 1], [x - w, bot, 1, -1], [x + w, bot, -1, -1]]) {
      c.fillRect(Math.round(bx), Math.round(by), 5 * dx, 1); c.fillRect(Math.round(bx), Math.round(by), 1, 5 * dy);
    }
  }

  private drawSelection() {
    const g = this.g, ui = this.ui;
    const sel = this.selection.map((id) => g.world.actors.find((a) => a.id === id)).filter((a): a is Actor => !!a && a.area === g.pl.area);
    if (!sel.length) return;
    for (const a of sel) { const s = this.toUi(a.x, a.y); this.bracket(s.x, s.y, C2.gold); }
    const h = Math.min(130, 30 + sel.length * 12 + 14), r = ui.panel({ x: 4, y: ui.h - h - 46, w: 210, h }, `Selected (${sel.length})`);
    ui.scrollList("sel.list", { x: r.x, y: r.y, w: r.w, h: r.h - 16 }, sel, 12, (a, _i, row) => {
      text2(ui.ctx, ellipsize(actorLabel(a), 120), row.x + 3, row.y + 2, C2.text);
      text2(ui.ctx, ellipsize(cap(actorDoing(a)), 70), row.x + row.w - 3, row.y + 2, C2.dim, 1, "right");
    });
    if (ui.button("sel.clear", { x: r.x + r.w - 50, y: r.y + r.h - 13, w: 50, h: 13 }, "Clear")) this.selection = [];
  }

  private contextMenu() {
    const g = this.g, c = this.context!, a = c.actor ? g.world.actors.find((x) => x.id === c.actor) : null;
    const items = a ? ["Inspect", "Select", "Add to selection"] : ["Mark this spot", "Clear selection", "Overview"];
    const pick = this.ui.menu("ctx", c.x, c.y, items);
    if (pick === -1) return;
    this.context = null;
    if (pick < 0) return;
    if (a) {
      if (pick === 0) { this.tables.residents.sel = g.world.actors.indexOf(a); this.tab.overview = 0; this.open("overview"); }
      if (pick === 1) this.selection = [a.id];
      if (pick === 2 && !this.selection.includes(a.id)) this.selection.push(a.id);
    } else {
      if (pick === 0) this.feed.push(`Marked ${g.pl.area} at tile ${Math.floor(c.wx / TS)}, ${Math.floor(c.wy / TS)}`, "info", { at: g.world.time });
      if (pick === 1) this.selection = [];
      if (pick === 2) this.open("overview");
    }
  }

  // ---------------------------------------------------------------- panels
  private panel(id: PanelId) {
    const ui = this.ui;
    if (this.rebinding === null && (ui.key("escape") || (id === "settings" && ui.key("o")) || (id === "saves" && ui.key("j")) || (id === "overview" && ui.key("g")))) { this.close(); return; }
    const title = { overview: "Overview", saves: "Saves", settings: "Settings" }[id];
    const r = ui.modal(Math.min(560, ui.w - 20), Math.min(300, ui.h - 30), title);
    if (ui.button("modal.close", { x: r.x + r.w - 14, y: r.y - 18, w: 16, h: 13 }, "x", { tip: "Close (Esc)" })) { this.close(); return; }
    if (id === "overview") this.overview(r);
    else if (id === "saves") this.savesPanel(r);
    else this.settingsPanel(r);
    if (this.status && this.g.t - this.status.t < 6) ui.label(this.status.text, r.x, r.y + r.h - 9, this.status.ok ? C2.ok : C2.bad);
  }

  private overview(r: Rect) {
    const g = this.g, ui = this.ui;
    this.tab.overview = ui.tabs("ov.tabs", r.x, r.y, ["Residents", "Areas", "Performance", "Notices"], this.tab.overview);
    const body = { x: r.x, y: r.y + 20, w: r.w, h: r.h - 34 };
    if (this.tab.overview === 0) {
      const rows = g.world.actors;
      const picked = ui.table("ov.res", body, [
        { label: "Name", w: 190, get: (a: Actor) => actorLabel(a) },
        { label: "Kind", w: 70, get: (a: Actor) => a.kind },
        { label: "Area", w: 100, get: (a: Actor) => a.area },
        { label: "Tier", w: 50, get: (a: Actor) => tierOf(g.world, a, g.pl), color: (a: Actor) => ({ active: C2.ok, near: C2.amber, far: C2.dim })[tierOf(g.world, a, g.pl)] },
        { label: "Doing", w: body.w - 412, get: (a: Actor) => cap(actorDoing(a)) },
      ], rows, this.tables.residents);
      if (picked >= 0) this.selection = [rows[picked].id];
    } else if (this.tab.overview === 1) {
      const areas = [...g.world.areas.values()];
      const spec = (id: string) => g.world.specs?.[id];
      const picked = ui.table("ov.areas", { ...body, h: body.h - 18 }, [
        { label: "Area", w: 150, get: (a: (typeof areas)[number]) => a.id + (a.id === g.pl.area ? " *" : "") },
        { label: "Kind", w: 70, get: (a) => spec(a.id)?.kind ?? "authored" },
        { label: "Size", w: 60, get: (a) => `${a.w}x${a.h}` },
        { label: "People", w: 50, get: (a) => String(g.world.actors.filter((x) => x.area === a.id).length), align: "right" },
        { label: "Last ticked", w: 90, get: (a) => (a.id === g.pl.area ? "now" : `${(g.world.time - a.lastTicked).toFixed(0)}s ago`) },
        { label: "Depth", w: body.w - 420, get: (a) => String(spec(a.id)?.depth ?? 0) },
      ], areas, this.tables.areas);
      void picked;
      const by = body.y + body.h - 15;
      let bx = body.x;
      for (const [k, label] of [["floor", "New floor below"], ["cave", "New cave"], ["yard", "New yard"]] as const) {
        if (ui.button(`ov.new.${k}`, { x: bx, y: by, w: 92, h: 15 }, label, { tip: `Generate a ${k} from the world seed and step into it` })) { this.close(); g.generateArea(k); return; }
        bx += 96;
      }
      if (ui.button("ov.leave", { x: bx, y: by, w: 80, h: 15 }, "Leave area", { disabled: !g.world.specs?.[g.pl.area], tip: "Walk out by the exit, back to where it was opened" })) { this.close(); g.leaveGenerated(); return; }
      bx += 84;
      const sel = areas[this.tables.areas.sel];
      if (ui.button("ov.forget", { x: bx, y: by, w: 80, h: 15 }, "Forget", { disabled: !sel || !spec(sel.id) || sel.id === g.pl.area, tip: "Delete the selected generated area (it must be empty)" }) && sel) {
        this.tell(forgetArea(g.world, sel.id) ? `Forgot ${sel.id}` : "Somebody is still there", !!spec(sel.id));
      }
      void generatedAreas;
    } else if (this.tab.overview === 2) {
      const half = (body.w - 6) / 2;
      ui.graph({ x: body.x, y: body.y, w: half, h: 70 }, this.perf.tick, { label: "Sim ms / tick", unit: "ms", color: C2.accent, budget: g.tickBudgetMs });
      ui.graph({ x: body.x + half + 6, y: body.y, w: half, h: 70 }, this.perf.frame, { label: "Frame ms", unit: "ms", color: C2.gold, budget: 16.7 });
      ui.graph({ x: body.x, y: body.y + 76, w: half, h: 50 }, this.perf.ticks, { label: "Ticks / frame", color: C2.ok, max: 10 });
      const n = tierCounts(g.world, g.pl);
      const lines = [
        `Actors: ${g.world.actors.length}  (active ${n.active}, near ${n.near}, far ${n.far})`,
        `Areas loaded: ${g.world.areas.size}   generated: ${Object.keys(g.world.specs ?? {}).length}`,
        `World tick: ${g.world.tick ?? 0}   sim time ${g.world.time.toFixed(1)}s`,
        `Speed: ${speedLabel(g.clock.speed)}   interpolation ${g.settings.interpolate ? "on" : "off"} (alpha ${g.clock.alpha.toFixed(2)})`,
      ];
      lines.forEach((l, i) => ui.label(l, body.x + half + 10, body.y + 80 + i * LINE_H, C2.text));
    } else {
      const items = this.feed.items;
      ui.scrollList("ov.notes", { ...body, h: body.h - 18 }, items, 12, (n, _i, row) => {
        text2(ui.ctx, n.level === "alert" ? "!" : n.level === "good" ? "+" : "-", row.x + 4, row.y + 2, n.level === "alert" ? C2.bad : n.level === "good" ? C2.ok : C2.dim);
        text2(ui.ctx, ellipsize(n.text + (n.count > 1 ? ` (x${n.count})` : ""), row.w - 20), row.x + 14, row.y + 2, n.read ? C2.dim : C2.text);
      });
      if (ui.button("ov.readall", { x: body.x, y: body.y + body.h - 15, w: 90, h: 15 }, "Mark all read")) this.feed.dismissAll();
    }
  }

  private savesPanel(r: Rect) {
    const g = this.g, ui = this.ui;
    const slots = [...MANUAL_SLOTS, AUTO_SLOT];
    const rows = slots.map((s, i) => ({ slot: s, meta: this.slots[i] ?? null }));
    ui.table("sv.slots", { x: r.x, y: r.y, w: r.w, h: 15 + 12 * 5 + 4 }, [
      { label: "Slot", w: 60, get: (x: (typeof rows)[number]) => (x.slot === AUTO_SLOT ? "Autosave" : `Slot ${x.slot.slice(4)}`) },
      { label: "Label", w: 150, get: (x) => x.meta?.label ?? (x.meta ? "-" : "Empty"), color: (x) => (x.meta ? C2.text : C2.faint) },
      { label: "Day", w: 40, get: (x) => (x.meta ? String(Math.floor(x.meta.day) + 1) : ""), align: "right" },
      { label: "Area", w: 110, get: (x) => x.meta?.area ?? "" },
      { label: "Size", w: 60, get: (x) => (x.meta ? `${(x.meta.bytes / 1024).toFixed(1)} KB` : ""), align: "right" },
      { label: "Saved", w: r.w - 422, get: (x) => (x.meta ? ago(x.meta.savedAt) : "") },
    ], rows, this.tables.saves);
    const sel = rows[this.tables.saves.sel] ?? rows[0];
    const by = r.y + 90;
    let bx = r.x;
    const btn = (id: string, label: string, tip: string, disabled = false) => { const hit = ui.button(id, { x: bx, y: by, w: 82, h: 16 }, label, { tip, disabled }); bx += 86; return hit; };
    if (btn("sv.save", "Save here", "Write the current game to this slot (the old one becomes its backup)", sel.slot === AUTO_SLOT || !g.world)) g.saveTo(sel.slot);
    if (btn("sv.load", "Load", "Load this slot (falls back to its backups if it is damaged)", !sel.meta)) { this.close(); g.loadFrom(sel.slot); return; }
    if (btn("sv.del", "Delete", "Delete this slot and its backups", !sel.meta)) { g.saves.remove(sel.slot).then(() => { this.refreshSlots(); this.tell(`Deleted ${sel.slot}`); }); }
    if (btn("sv.export", "Export file", "Download the current game as a file")) g.exportSave();
    if (btn("sv.import", "Import file", "Load a game from a file")) g.importSave();
    const help = [
      `Autosave: ${g.settings.autosave ? `every ${g.settings.autosaveMinutes} min and on entering an area` : "off"} (rolling backups: 3).`,
      "Saves live in this browser (IndexedDB). Export a file to keep one safe or move it.",
      `Quick save: K (slot 1).  Quick load: L (newest).`,
    ];
    help.forEach((l, i) => ui.label(l, r.x, by + 26 + i * LINE_H, C2.dim));
  }

  private settingsPanel(r: Rect) {
    const g = this.g, ui = this.ui, s = g.settings;
    const sections = [...new Set(OPTIONS.map((o) => o.section)), "Controls"];
    this.tab.settings = ui.tabs("st.tabs", r.x, r.y, sections, this.tab.settings);
    const sec = sections[this.tab.settings];
    let y = r.y + 22;
    const rowW = Math.min(360, r.w);
    let changed = false;
    if (sec === "Controls") {
      const colW = (r.w - 6) / 2;
      ACTIONS.forEach((a, i) => {
        const x = r.x + (i % 2) * (colW + 6), yy = y + Math.floor(i / 2) * 18;
        const waiting = this.rebinding === a.id;
        ui.label(a.label, x + 4, yy + 4, C2.text);
        if (ui.button(`st.key.${a.id}`, { x: x + colW - 80, y: yy, w: 80, h: 15 }, waiting ? "Press a key" : keyName(boundKey(s, a.id)), { on: waiting, tip: "Click, then press the new key (Esc cancels)" })) { this.rebinding = a.id; }
      });
      if (this.rebinding) {
        const k = [...ui.keys].find((x) => x !== "enter" && x !== "tab");
        if (k === "escape") this.rebinding = null;
        else if (k) {
          const def = ACTIONS.find((a) => a.id === this.rebinding)!;
          // a key moves to its new action: anything else bound to it is put back to its default
          for (const [id, key] of Object.entries(s.keymap)) if (key === k) delete s.keymap[id];
          if (k === def.key) delete s.keymap[def.id]; else s.keymap[def.id] = k;
          this.rebinding = null; changed = true;
        }
      }
      if (ui.button("st.keys.reset", { x: r.x, y: r.y + r.h - 16, w: 100, h: 15 }, "Reset controls")) { s.keymap = {}; changed = true; }
    } else {
      for (const o of OPTIONS.filter((x) => x.section === sec)) {
        const rr = { x: r.x, y, w: rowW, h: o.kind === "slider" ? 22 : 16 };
        const cur = s[o.id] as never;
        let v: unknown = cur;
        if (o.kind === "slider") v = ui.slider(`st.${o.id}`, rr, o.label, cur as number, o.min, o.max, o.step, o.format, o.hint);
        else if (o.kind === "toggle") v = ui.toggle(`st.${o.id}`, rr, o.label, cur as boolean, o.hint);
        else v = ui.choice(`st.${o.id}`, rr, o.label, cur as string, o.values, o.labels, o.hint);
        if (v !== cur) { (s as unknown as Record<string, unknown>)[o.id] = v; changed = true; }
        y += rr.h + 4;
      }
      if (sec === "Accessibility") ui.paragraph("Overlay colours change the scan mode's highlight categories to palettes that stay distinct for common colour-vision deficiencies.", { x: r.x + rowW + 12, y: r.y + 24, w: r.w - rowW - 12, h: 80 }, C2.dim);
    }
    if (changed) g.applySettings(s as Settings, true);
  }
}
