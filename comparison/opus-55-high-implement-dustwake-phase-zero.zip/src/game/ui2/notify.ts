// The notification feed (Phase 0.5). No DOM. Messages from the sim and the host (an order blocked, a full pack, an
// autosave, a new day) collect here; alerts can pause the game (settings: pauseOnAlert). The shell draws the newest
// few in the corner; the overview keeps the history.
export type NoticeLevel = "info" | "good" | "alert";
export interface Notice { id: number; text: string; level: NoticeLevel; at: number; age: number; read: boolean; area?: string; count: number }

export const NOTICE_LIFE = 8;
export const NOTICE_HISTORY = 120;

export class NotificationFeed {
  items: Notice[] = [];
  private seq = 0;
  /** Set when an alert arrived that should pause the game; the host consumes it. */
  pauseRequested = false;

  /** Add a notice. A repeat of the newest unread one bumps its count instead. */
  push(text: string, level: NoticeLevel = "info", o: { area?: string; at?: number; pause?: boolean } = {}): Notice {
    const top = this.items[0];
    if (top && top.text === text && !top.read && top.age < NOTICE_LIFE) { top.count++; top.age = 0; if (level === "alert" && o.pause !== false) this.pauseRequested = true; return top; }
    const n: Notice = { id: ++this.seq, text, level, at: o.at ?? 0, age: 0, read: false, area: o.area, count: 1 };
    this.items.unshift(n);
    if (this.items.length > NOTICE_HISTORY) this.items.length = NOTICE_HISTORY;
    if (level === "alert" && o.pause !== false) this.pauseRequested = true;
    return n;
  }
  /** Age notices by real seconds. */
  update(dt: number) { for (const n of this.items) n.age += dt; }
  /** The notices still showing in the corner (newest first). */
  visible(max = 5) { return this.items.filter((n) => !n.read && n.age < NOTICE_LIFE).slice(0, max); }
  dismiss(id: number) { const n = this.items.find((x) => x.id === id); if (n) n.read = true; }
  dismissAll() { for (const n of this.items) n.read = true; }
  get unread() { return this.items.filter((n) => !n.read).length; }
  consumePause() { const p = this.pauseRequested; this.pauseRequested = false; return p; }
  clear() { this.items = []; this.pauseRequested = false; }
}
