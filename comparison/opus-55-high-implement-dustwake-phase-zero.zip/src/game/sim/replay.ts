// Deterministic replays (Phase 0.1). No DOM.
//
// `simTick` is the canonical play-screen tick: the same three calls, in the same order, the host makes (and the
// tests' `frame` helper mirrors), always with dt = TICK. An `InputLog` binds player input to tick numbers, so a
// world replayed from the same save with the same log reaches the same state no matter how many ticks each
// rendered frame ran (1x or 8x), or whether it ran at all (a hidden tab).
import { addPlayTime, stepPlayer, stepWorld, type PlayerInput } from "./step";
import { TICK, SimClock } from "./clock";
import type { World } from "../world/world";

export const NO_INPUT: PlayerInput = { ix: 0, iy: 0, use: false };

/** One play tick: player step, then world step. */
export function simTick(w: World, input: PlayerInput = NO_INPUT) {
  addPlayTime(w, TICK);
  const r = stepPlayer(w, TICK, input);
  stepWorld(w, TICK);
  return r;
}

const neutral = (i: PlayerInput) => !i.ix && !i.iy && !i.use && !i.attack && !i.core && !i.toggleScan;

export interface InputFrame { tick: number; input: PlayerInput }

/** Player input keyed by world tick. Neutral ticks are not stored, so an idle hour costs nothing. */
export class InputLog {
  frames: InputFrame[] = [];
  private byTick = new Map<number, PlayerInput>();
  record(tick: number, input: PlayerInput) {
    if (neutral(input)) return;
    const copy = { ...input };
    this.frames.push({ tick, input: copy });
    this.byTick.set(tick, copy);
  }
  at(tick: number): PlayerInput { return this.byTick.get(tick) ?? NO_INPUT; }
  toJSON() { return this.frames; }
  static from(frames: InputFrame[]) { const l = new InputLog(); for (const f of frames) l.record(f.tick, f.input); return l; }
}

/** Run `ticks` ticks of `w` from its current tick, feeding the logged input. Events are drained each tick. */
export function replay(w: World, log: InputLog, ticks: number) {
  for (let i = 0; i < ticks; i++) {
    simTick(w, log.at(w.tick ?? 0));
    w.events.length = 0;
  }
}

/**
 * Drive `w` the way the host does, through a SimClock at `speed`, over a list of real frame times, until it has run
 * `ticks` ticks. Returns how many frames that took. Used by the determinism test: a world driven at 1x and at 8x
 * over different frame timings ends identical.
 */
export function driveAtSpeed(w: World, log: InputLog, ticks: number, speed: number, frameDts: number[]) {
  const clock = new SimClock();
  let run = 0, frames = 0;
  while (run < ticks) {
    const n = clock.advance(frameDts[frames++ % frameDts.length], speed);
    for (let k = 0; k < n && run < ticks; k++, run++) { simTick(w, log.at(w.tick ?? 0)); w.events.length = 0; }
  }
  return frames;
}
