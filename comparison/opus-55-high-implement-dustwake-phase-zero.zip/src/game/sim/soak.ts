// Soak test harness (Phase 0.8). No DOM. Runs a world headless for N in-game hours with M residents and checks
// invariants as it goes:
//   stuck        nobody in full detail wants to walk (a path) yet stays put for more than `stuckSeconds`
//   items        no item is created or destroyed: the totals over every pack, worn slot, prop and loose stack hold
//   places       no exclusive standing place is held by two people at once
//   ids          no actor id appears twice
//   round trip   serialize -> deserialize -> serialize is the identity, every `roundTripHours`
//   budget       mean (and p95) sim cost per tick under `budgetMs`
// Used by tests/soak.test.ts (small and 300-actor runs) and scripts/soak.mjs (long runs from the command line).
import { CENSUS, type CensusRow } from "../content/folk";
import { DAY_SECONDS } from "../content/daycycle";
import { createWorld, enterArea, getArea, player, actorById, type World } from "../world/world";
import { deserialize, serialize } from "../world/save";
import { isExclusive, isFolk, makeFolk, spotById } from "./folk";
import { simTick } from "./replay";
import { TICK } from "./clock";
import { tierOf } from "./lod";
import { advanceDayTo } from "./daytime";

export interface SoakOptions {
  /** In-game hours to run. */
  hours: number;
  /** Total actors wanted (the census is cloned until there are this many). */
  actors: number;
  seed?: number;
  /** Where the player stands (the area simulated in full). */
  area?: string;
  /** Hour of day to start at. */
  startHour?: number;
  stuckSeconds?: number;
  roundTripHours?: number;
  budgetMs?: number;
  now?: () => number;
}

export interface SoakReport {
  ticks: number; simSeconds: number; actors: number;
  msPerTick: number; p95Ms: number; maxMs: number; budgetMs: number; withinBudget: boolean;
  stuck: string[]; placeConflicts: string[]; duplicateIds: string[]; itemDrift: Record<string, number>; roundTrips: number; roundTripFailures: string[];
  ok: boolean;
}

/** Clone census rows (new ids, same homes and routines) until the world holds `n` actors. Deterministic. */
export function populateResidents(w: World, n: number, areas = ["town"]) {
  const rows = CENSUS.filter((r) => areas.includes(r.area));
  for (const id of new Set(rows.map((r) => r.area))) getArea(w, id);
  const taken = new Set(w.actors.filter(isFolk).map((a) => a.person!.name.split(" ")[0]));
  for (let k = 1; w.actors.length < n && rows.length; k++) {
    for (const r of rows) {
      if (w.actors.length >= n) break;
      const row: CensusRow = { ...r, id: `${r.id}.r${k}` };
      if (!actorById(w, row.id)) w.actors.push(makeFolk(w, row, taken));
    }
  }
}

/** Every item in the world, by id: packs, worn gear, prop inventories, props holding an item, loose stacks. */
export function itemTotals(w: World): Record<string, number> {
  const t: Record<string, number> = {};
  const add = (id: string | null | undefined, n = 1) => { if (id) t[id] = (t[id] ?? 0) + n; };
  for (const a of w.actors) {
    for (const s of a.inventory) if (s) add(s.item, s.n);
    for (const g of Object.values(a.gear)) add(g);
    add(a.powerCore);
  }
  for (const area of w.areas.values()) {
    for (const p of area.props) { add(p.item); for (const s of p.inventory ?? []) if (s) add(s.item, s.n); }
    for (const l of area.loose) if (!l.taken) add(l.item, l.n ?? 1);
  }
  return t;
}

/** Exclusive places held by more than one person: "area|spot" -> holders. */
export function placeConflicts(w: World): string[] {
  const held = new Map<string, string[]>();
  for (const a of w.actors) {
    if (!isFolk(a) || !a.life!.spot) continue;
    const id = a.life!.spot;
    if (!id.startsWith("lamp:")) { const s = spotById(getArea(w, a.area), id); if (!s || !isExclusive(s)) continue; }
    const k = `${a.area}|${id}`;
    held.set(k, [...(held.get(k) ?? []), a.id]);
  }
  return [...held].filter(([, ids]) => ids.length > 1).map(([k, ids]) => `${k}: ${ids.join(", ")}`);
}

export function makeSoakWorld(o: SoakOptions): World {
  const w = createWorld(o.seed ?? 1234);
  const area = getArea(w, o.area ?? "town");
  enterArea(w, player(w), area.id, area.start.x, area.start.y);
  populateResidents(w, o.actors);
  advanceDayTo(w, o.startHour ?? 9);
  w.events.length = 0;
  return w;
}

export function runSoak(o: SoakOptions, w: World = makeSoakWorld(o)): SoakReport {
  const now = o.now ?? (() => (typeof performance !== "undefined" ? performance.now() : Date.now()));
  const stuckLimit = o.stuckSeconds ?? 20, budget = o.budgetMs ?? 4, rtEvery = (o.roundTripHours ?? 4) * (DAY_SECONDS / 24);
  const ticks = Math.round((o.hours * DAY_SECONDS) / 24 / TICK);
  const before = itemTotals(w);
  const lastMove = new Map<string, { x: number; y: number; t: number }>();
  const stuck = new Set<string>(), conflicts = new Set<string>(), rtFail: string[] = [];
  const costs: number[] = [];
  let nextRt = w.time + rtEvery, roundTrips = 0;
  for (let i = 0; i < ticks; i++) {
    const t0 = now();
    simTick(w);
    costs.push(now() - t0);
    w.events.length = 0;
    // stuck: in full detail, wanting to walk, not moving
    if (i % 15 === 0) {
      const pl = player(w);
      for (const a of w.actors) {
        if (!isFolk(a) || a.area !== pl.area || tierOf(w, a, pl) !== "active") { lastMove.delete(a.id); continue; }
        const L = a.life!, m = lastMove.get(a.id);
        const wants = L.path.length > 0 && L.state !== "do" && L.state !== "indoors" && !L.chat;
        if (!m || !wants || Math.hypot(a.x - m.x, a.y - m.y) > 1) { lastMove.set(a.id, { x: a.x, y: a.y, t: w.time }); continue; }
        if (w.time - m.t > stuckLimit) stuck.add(`${a.id} at ${a.x.toFixed(0)},${a.y.toFixed(0)} (${L.act})`);
      }
      for (const c of placeConflicts(w)) conflicts.add(c);
    }
    if (w.time >= nextRt) {
      nextRt += rtEvery; roundTrips++;
      const a = JSON.stringify(serialize(w)), b = JSON.stringify(serialize(deserialize(JSON.parse(a))));
      if (a !== b) rtFail.push(`at t=${w.time.toFixed(1)}: ${a.length} vs ${b.length} bytes`);
    }
  }
  const after = itemTotals(w), drift: Record<string, number> = {};
  for (const k of new Set([...Object.keys(before), ...Object.keys(after)])) { const d = (after[k] ?? 0) - (before[k] ?? 0); if (d) drift[k] = d; }
  const ids = w.actors.map((a) => a.id), dup = ids.filter((id, i) => ids.indexOf(id) !== i);
  const sorted = [...costs].sort((a, b) => a - b), mean = costs.reduce((s, c) => s + c, 0) / Math.max(1, costs.length);
  const report: SoakReport = {
    ticks, simSeconds: ticks * TICK, actors: w.actors.length,
    msPerTick: mean, p95Ms: sorted[Math.floor(sorted.length * 0.95)] ?? 0, maxMs: sorted[sorted.length - 1] ?? 0, budgetMs: budget, withinBudget: mean <= budget,
    stuck: [...stuck], placeConflicts: [...conflicts], duplicateIds: dup, itemDrift: drift, roundTrips, roundTripFailures: rtFail, ok: false,
  };
  report.ok = report.withinBudget && !report.stuck.length && !report.placeConflicts.length && !dup.length && !Object.keys(drift).length && !rtFail.length;
  return report;
}
