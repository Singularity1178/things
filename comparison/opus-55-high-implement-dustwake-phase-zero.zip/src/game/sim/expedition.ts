// Opening and leaving areas made at runtime (Phase 0.3): a generated floor below where the golem stands, a cave,
// a yard to build in. Pure sim; the overview's Areas tab and the tests call these. No DOM.
import { createArea, enterArea, forgetArea, getArea, type Actor, type World } from "../world/world";
import { hash01 } from "../content/daycycle";
import { AREA_KINDS, nextSpecId, type AreaSpec } from "../world/areaSpec";
import { portalById, walkThrough } from "./portals";

const LABEL: Record<string, string> = { floor: "A FLOOR BELOW", cave: "A CAVE", yard: "AN OPEN YARD" };

/** Create a `kind` area under the actor's area (deterministic from the world seed and the new id) and step into it. */
export function openGeneratedArea(w: World, a: Actor, kind: string, size: { w: number; h: number } = { w: 56, h: 36 }): AreaSpec | null {
  if (!AREA_KINDS[kind]) return null;
  const parentSpec = w.specs?.[a.area];
  const id = nextSpecId(w.specs, a.area, kind);
  const spec: AreaSpec = {
    id, kind, w: size.w, h: size.h, parent: a.area, depth: (parentSpec?.depth ?? 0) + (kind === "yard" ? 0 : 1),
    // never from w.rng: opening a floor must not change what the rest of the sim rolls
    seed: Math.floor(hash01(`${w.seed}:${id}`, 7) * 4294967296) >>> 0,
    entry: { x: Math.round(a.x), y: Math.round(a.y) }, label: LABEL[kind],
  };
  const area = createArea(w, spec);
  enterArea(w, a, id, area.start.x, area.start.y);
  a.facing = "down";
  return w.specs![id];
}

/** Walk the actor out of a generated area by its exit (back to where it was opened). False if this is not one. */
export function leaveGeneratedArea(w: World, a: Actor): boolean {
  if (!w.specs?.[a.area]) return false;
  const area = getArea(w, a.area), exit = portalById(area, "exit");
  return !!exit && walkThrough(w, a, area, exit);
}

/** Generated areas, parents first. */
export const generatedAreas = (w: World) => Object.values(w.specs ?? {}).sort((x, y) => x.depth - y.depth || (x.id < y.id ? -1 : 1));

export { forgetArea };
