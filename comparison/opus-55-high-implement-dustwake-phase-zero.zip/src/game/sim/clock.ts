// Fixed-timestep simulation clock (Phase 0.1). No DOM.
//
// The sim always steps in ticks of exactly TICK seconds. The host feeds real frame time into `advance`, which
// returns how many ticks to run this frame (more at higher game speeds) and leaves `alpha`, the fraction of a
// tick left over, for the renderer to interpolate between the previous and the current tick. Because the World
// only ever sees TICK-sized steps, and input is bound to tick numbers (sim/replay.ts), the same save and input
// stream give an identical World at 1x and at 8x: 8x simply runs more ticks per frame.

export const SIM_HZ = 30;
export const TICK = 1 / SIM_HZ;

/** Game speeds offered by the HUD: 0 is pause. */
export const SPEEDS = [0, 1, 2, 4, 8] as const;
export type Speed = (typeof SPEEDS)[number];

export const speedLabel = (s: number) => (s === 0 ? "Paused" : `${s}x`);

export class SimClock {
  /** Current game speed (0 = paused). */
  speed: Speed = 1;
  /** The speed to return to when unpausing. */
  resumeSpeed: Exclude<Speed, 0> = 1;
  /** Real seconds of sim time owed but not yet stepped (always < TICK after `advance`). */
  acc = 0;
  /** Leftover fraction of a tick, 0..1: how far the renderer is between the last two ticks. */
  alpha = 1;
  /** Most real time one frame may contribute (a stalled tab must not trigger a spiral of catch-up ticks). */
  maxFrame = 0.25;
  /** Ticks run in the last `advance` (the perf panel reads it). */
  lastTicks = 0;
  /** Total ticks handed out since this clock started. */
  total = 0;

  /** Feed `realDt` seconds of wall time at `speed` (default: the clock's own). Returns the number of ticks to run. */
  advance(realDt: number, speed: number = this.speed): number {
    if (speed <= 0) { this.lastTicks = 0; return 0; }
    this.acc += Math.min(Math.max(0, realDt), this.maxFrame) * speed;
    // the epsilon keeps float drift from dropping a tick when acc lands a hair under a multiple of TICK
    const n = Math.floor(this.acc / TICK + 1e-7);
    this.acc = Math.max(0, this.acc - n * TICK);
    this.alpha = Math.min(1, this.acc / TICK);
    this.lastTicks = n;
    this.total += n;
    return n;
  }

  setSpeed(s: Speed) {
    if (s !== 0) this.resumeSpeed = s;
    this.speed = s;
  }
  togglePause() { this.setSpeed(this.speed === 0 ? this.resumeSpeed : 0); }
  /** Step to the next faster (+1) or slower (-1) speed, never below 1x (pause has its own key). */
  stepSpeed(dir: 1 | -1) {
    const i = SPEEDS.indexOf(this.speed === 0 ? this.resumeSpeed : this.speed);
    this.setSpeed(SPEEDS[Math.min(SPEEDS.length - 1, Math.max(1, i + dir))]);
  }
}
