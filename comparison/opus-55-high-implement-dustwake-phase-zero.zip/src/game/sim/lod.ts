// Simulation level of detail (Phase 0.2). No DOM.
//
// Three tiers, decided from sim state only (never from the camera), so they are deterministic and replays agree:
//   active  in the player's area and within ACTIVE_BOX of the player (a margin over the largest view): full step
//   near    in the player's area, beyond that box: stepped every NEAR_INTERVAL of sim time, the owed time in chunks
//   far     any other area: stepped every FAR_INTERVAL in chunks, or abstract (townsfolk: "set down where the hour
//           says" on entry, sim/folk.ts: settle)
// Owed time per actor lives in `World.lod` and is saved, so a loaded world steps exactly like the live one.
// Areas remember when they were last ticked (`Area.lastTicked`); entering one runs the registered catch-up hooks
// with `world.time - area.lastTicked`.
import type { Actor, World } from "../world/world";
import type { Area } from "../world/area";

export type Tier = "active" | "near" | "far";

/** Half-extents of the active box around the player (px): the 2x view is 640x360, plus a margin for walking in. */
export const ACTIVE_BOX = { x: 400, y: 260 };
/** Sim seconds between steps of a near / far actor, and the longest single step it is given (chunks). */
export const NEAR_INTERVAL = 0.1, NEAR_CHUNK = 0.1;
export const FAR_INTERVAL = 0.25, FAR_CHUNK = 0.25;

/** The tier of `a` relative to the player (`focus`). The player is always active. */
export function tierOf(_w: World, a: Actor, focus: Actor | undefined): Tier {
  if (!focus || a.id === focus.id) return "active";
  if (a.area !== focus.area) return "far";
  return Math.abs(a.x - focus.x) <= ACTIVE_BOX.x && Math.abs(a.y - focus.y) <= ACTIVE_BOX.y ? "active" : "near";
}

const debtOf = (w: World) => (w.lod ??= {});

/**
 * Step `a` by `dt` at its tier: `step(dt)` immediately when active; otherwise the time is owed until the tier's
 * interval has passed, then paid in chunks no longer than the tier's chunk. Returns the sim time actually stepped.
 */
export function stepAtTier(w: World, a: Actor, tier: Tier, dt: number, step: (dt: number) => void, key = a.id): number {
  const debt = debtOf(w);
  if (tier === "active") {
    const owed = debt[key] ?? 0;
    if (owed) delete debt[key];
    let left = owed + dt, done = 0;
    // an actor that just came into full detail first pays what it owed, in steps no longer than this tick's
    while (left > 1e-9) { const c = Math.min(left, dt > 0 ? dt : left); step(c); left -= c; done += c; }
    return done;
  }
  const interval = tier === "near" ? NEAR_INTERVAL : FAR_INTERVAL, chunk = tier === "near" ? NEAR_CHUNK : FAR_CHUNK;
  const owed = (debt[key] ?? 0) + dt;
  if (owed + 1e-9 < interval) { debt[key] = owed; return 0; }
  delete debt[key];
  let left = owed;
  while (left > 1e-9) { const c = Math.min(left, chunk); step(c); left -= c; }
  return owed;
}

/** Forget what an idle actor owed (nothing to catch up on; it must not burst when given work). */
export function clearDebt(w: World, id: string) { if (w.lod && id in w.lod) delete w.lod[id]; }

// ---------------------------------------------------------------- area catch-up
type CatchUp = (w: World, area: Area, elapsed: number) => void;
const CATCH_UPS: { id: string; fn: CatchUp }[] = [];

/** Register what an area does when the player enters it after `elapsed` sim seconds away (idempotent by id). */
export function registerCatchUp(id: string, fn: CatchUp) {
  const i = CATCH_UPS.findIndex((c) => c.id === id);
  if (i >= 0) CATCH_UPS[i].fn = fn; else CATCH_UPS.push({ id, fn });
}

/** Run every catch-up hook for `area` (stepWorld calls this when the player's area changes). */
export function catchUpArea(w: World, area: Area) {
  const elapsed = Math.max(0, w.time - area.lastTicked);
  if (elapsed > 0) for (const c of CATCH_UPS) c.fn(w, area, elapsed);
  area.lastTicked = w.time;
  return elapsed;
}

// The translocation circle's charge: areas off the player's path skip it, and it is credited on entry.
registerCatchUp("ritual", (_w, area, elapsed) => area.advanceRitual(elapsed));

/** Counts by tier, for the overview and the soak report. */
export function tierCounts(w: World, focus: Actor | undefined) {
  const n = { active: 0, near: 0, far: 0 };
  for (const a of w.actors) n[tierOf(w, a, focus)]++;
  return n;
}
