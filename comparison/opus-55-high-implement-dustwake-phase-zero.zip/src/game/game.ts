// Host + presentation. Owns the canvas, input, screens, camera, particles,
// audio and rendering. It never mutates the World directly except through sim
// entry points; it reacts to the World's events for sound and particles.
import { TS } from "./content/tiles";
import { ITEMS, type ItemId } from "./content/items";
import { hasItem } from "./sim/inventory";
import { golemGlow } from "./sim/gear";
import { toggleGearKit, grantStoryKit, grantBuildKit, teleportTo, type DebugPlace } from "./sim/debug";
import { foundationDemo } from "./sim/debugFoundations";

import { GOLEM_LIGHT } from "./content/gear";
import { BuildUi } from "./screens/buildMenu";
import { CraftingUi } from "./screens/crafting";


import { PackUi } from "./screens/pack";
import { StorageUi } from "./screens/storage";
import { DebugUi } from "./screens/debug";
import { ManageUi } from "./screens/manage";
import { TransferUi } from "./screens/transfer";
import { BookUi } from "./screens/book";
import { SchematicUi } from "./screens/schematic";
import { DialogueUi } from "./screens/dialogue";
import { IntroCutscene } from "./screens/intro";
import { CrossingCutscene } from "./screens/crossing";
import { ARRIVE } from "./content/cutscenes";
import { MonologueLog, drawMonologue } from "./ui/monologue";

import { renderTitle } from "./screens/cards";
import { propDef } from "./content/props";


import { FLAGS } from "./content/flags";




import { makeCanvas, Sprite, hash2, clamp, lerp, makeSprite } from "./util";
import { GolemPose, type Facing } from "./golem";

import { Light, makeLight, computeVis, applyGlow, Lighting } from "./light";
import { Sfx } from "./audio";
import { buildCircle, CircleArt } from "./circle";
import { SurfaceRuneArt } from "./surfaceRune";
import { carvingVisible, clumpCleared } from "./runeReveal";
import { RUNE_NODES } from "./content/runes";
import { runeState } from "./sim/runes";
import { RUNE_DUD, linkedGlow, runeDudGlow, severedGlow } from "./view/runeFx";
import { drawText, drawTextS } from "./font";
import { createWorld, player, currentArea, actorById, hasFlag, setFlag, clearFlag, type World, type SimEvent } from "./world/world";
import type { PropInst } from "./world/area";
import { stepPlayer, stepWorld, addPlayTime } from "./sim/step";
import { interactables, type Interactable } from "./sim/interact";
import { AreaView } from "./view/areaView";
import { ScreenStack, type Screen } from "./ui/screens";
import { BASE_W, BASE_H, ZOOM_STEPS, ZOOM_DEFAULT, viewSize, nextZoomStep } from "./view/zoom";




import { type WorkerAnim, type AnimCue } from "./workerAnim";

import { VisionView, type VisionCue, type VisionArt } from "./view/vision";
import type { Target } from "./content/tasks";

import type { Actor } from "./world/world";





import type { ChatIcon } from "./content/folk";

import { DAY_SECONDS, skyLight, litLevel, sunLevel, clockText, phaseAt, hearthSmoke, type DayPhase, type RGB } from "./content/daycycle";
import { worldHour, advanceDay, advanceDayTo } from "./sim/daytime";
import * as reactionsV from "./view/reactions";
import * as worldRendererV from "./view/worldRenderer";
import * as particlesV from "./view/particles";
import { SimClock, TICK } from "./sim/clock";
import { Camera } from "./view/camera";
import { Shell } from "./ui2/shell";
import { loadSettings, saveSettings, translateKey, OVERLAY_PALETTES, UI_RES, type Settings } from "./settings";
import { setOverlayPalette } from "./view/vision";
import { Autosaver, exportText as _exportText, importText, type SaveManager } from "./world/saveStore";
import { browserSaves, downloadSave, pickSaveFile } from "./view/persistence";
import { openGeneratedArea, leaveGeneratedArea } from "./sim/expedition";

/** Debug super-speed multiplier. 200% faster = base + 2x base = 3x. */
const DEBUG_SPEED_MULT = 3;

/** Base logical size. HUD and overlay screens are laid out for it (they draw on a base-size UI layer). */
export const W = BASE_W, H = BASE_H;
export { ZOOM_STEPS, ZOOM_DEFAULT, viewSize };
/** The crossing's arrival timings (content/cutscenes.ts), re-exported for the host's callers. */
export { ARRIVE };
/** An area with no `ambient` of its own: the dark of the buried halls. */
export const BURIED_AMBIENT: RGB = [0.05, 0.045, 0.065];

/** Presentation state of one NPC (eased pose, eye, flare). Not saved: derived from flags on load. */
export interface NpcLook {
  awake: number; eye: number; wakeT: number; sleepT: number; reach: number; flare: number;
  /** A worker body's animation sequencer (workerAnim.ts), the px a rune holds it off the ground, when it was last stepped, and whether it just arrived through a rune. */
  worker?: WorkerAnim; lift: number; seen: number; arrived: boolean;
}

export interface Particle {
  x: number; y: number; z: number; vx: number; vy: number; vz: number;
  life: number; max: number; kind: "spark" | "ember" | "dust" | "debris" | "drip" | "splash" | "rune" | "mote" | "glint" | "smoke";
  col: string; emit: boolean; g: number; size: number;
}

/** Presentation-only state of the golem's body: boot-up, flicker, hover. */
export interface GolemLook { eye: number; core: number; dormant: number; sparkT: number; sputter: number; z: number }

const newSeed = () => (Math.random() * 4294967296) >>> 0;

/** How near the golem must be to read townsfolk's own talk as words (px), and how many such lines show at once besides a talk already going. */
export const FOLK_EARSHOT = 170, FOLK_MAX_LINES = 3;

export class Game {
  /** Base-size (W x H) UI layer: HUD, overlays, title and chapter cards. */
  ctx: CanvasRenderingContext2D;
  /** World layer: the lit scene, sized to the current view (vw x vh). */
  wctx: CanvasRenderingContext2D;
  /** Current view size in world pixels (W x H at 1x). */
  vw = W; vh = H;
  /** Current (possibly easing) zoom and its animation. */
  zoom = 1;
  zoomAnim: { from: number; to: number; t: number; dur: number } | null = null;
  /** Called when the view size changes (App refits the world canvas). */
  onView: ((w: number, h: number) => void) | null = null;
  scene = makeCanvas(W, H);
  emit = makeCanvas(W, H);
  lighting = new Lighting(W, H);
  npcLooks = new Map<string, NpcLook>();
  /** Speech bubbles over townsfolk (presentation only): a line said to the golem, or a pictogram in their own talk. */
  bubbles = new Map<string, { text?: string; icon?: ChatIcon; t: number; dur: number; /** A line of their own talk (not said to the golem). */ talk?: boolean }>();
  /** The golem's vision mode overlay (presentation of the sim's scan mode). */
  vision = new VisionView();
  lastAnalyzed = { prop: "", t: -1 };
  sfx = new Sfx();
  circle: CircleArt = buildCircle();
  /** The sky through the throne room's broken roof: a shaft of moonlight, and the same shaft as a sunbeam. */
  shaft: Sprite;
  sunShaft: Sprite;

  world!: World;
  view!: AreaView;
  screens = new ScreenStack();
  /** Real (presentation) clock: animations run on it even while the world is paused. */
  t = 0;
  particles: Particle[] = [];
  toast: { icon: Sprite; name: string; t: number } | null = null;
  /** Debug/testing state (not saved, not part of the sim). */
  debugSpeed = false;
  /** The multiplier super speed applies while on (Ctrl+3 uses the default; the debug menu cycles it). */
  debugSpeedMult = DEBUG_SPEED_MULT;
  debugNoclip = false;
  /** Corner readout of the area, position and active debug modes. */
  debugHud = false;
  debugMsg: { text: string; t: number } | null = null;
  cam = new Camera();
  // ---------------------------------------------------------------- Phase 0: the management shell
  /** Fixed-timestep clock and game speed (sim/clock.ts). */
  clock = new SimClock();
  /** Player preferences (settings.ts). Not saved with the world. */
  settings: Settings = loadSettings(typeof localStorage !== "undefined" ? localStorage : null);
  /** Save slots v2 (IndexedDB in the browser, memory in tests). */
  saves: SaveManager = browserSaves();
  autosaver = new Autosaver();
  /** Whether any slot holds a save (known after the first listing). */
  hasSaves = false;
  /** The hi-res UI layer (null in tests that build the host with two canvases). */
  hctx: CanvasRenderingContext2D | null = null;
  hiCanvas: HTMLCanvasElement | null = null;
  /** The hi-res layer's resolution over the base (settings: UI scale). */
  uiRes = 2;
  shell!: Shell;
  /** True while the play screen runs paused (game speed 0): input and presentation, no sim. */
  paused = false;
  /** Frame budget for one sim tick (ms), drawn on the performance graph and held by the soak test. */
  tickBudgetMs = 4;
  /** Actor positions before the last tick of this frame, for interpolated drawing. */
  private interp: { area: string; pos: Map<string, [number, number]> } | null = null;
  shakeT = 0; shakeMag = 0;
  rumbleT = 50;
  eyeBoost = 0;
  crackFlash = 0;
  /** Cracked debris that took a slam and held shudders for a moment (presentation only). */
  shudder: { tx: number; ty: number; t: number } | null = null;
  fizzT = 0;
  look: GolemLook = { eye: 0, core: 0, dormant: 1, sparkT: 2, sputter: 0, z: 0 };
  glight!: Light;
  keys = new Set<string>();
  pressed = new Set<string>();
  dripT: number[] = [];
  target: Interactable | null = null;
  outImg: ImageData;
  uiTimers: { at: number; fn: () => void }[] = [];
  S!: Record<"title" | "intro" | "play" | "tele" | "crossing" | "inv" | "schem" | "book" | "build" | "crafting" | "storage" | "manage" | "dialogue" | "debug", Screen>;
  /** Feedback line (blocked actions, pack full, rune dark...). */
  note: { text: string; t: number } | null = null;
  /** Current rune jump: where the effect plays, how long, and whether it's the first (cinematic) one. */
  tele = { x: 0, y: 0, dur: 4.6, first: true, travelled: false };
  /** White fade after a short rune hop (1 -> 0). */
  arriveFade = 0;
  /** Stepping through a doorway or along a road into the next area: a short fade up from dark. */
  doorFade = 0;
  hideGolem = false;
  /**
   * Surface rune override during the arrival cutscene (null: follow its flag).
   * t: redraw progress 0..1, glow: emissive level (>1 = overdriven pulse), column: summon beam 0..1.
   */
  runeAnim: { t: number; glow: number; column: number } | null = null;
  /** A rune that refused to carry (E on one that is dark or severed): where it is, and how long its sputter has run (view/runeFx.ts). */
  runeDud: { x: number; y: number; t: number } | null = null;
  runeArtCache: SurfaceRuneArt | null = null;
  /** The surface rune's layered art (dormant / awakening / restored), built on first use. */
  get runeArt() { return (this.runeArtCache ??= new SurfaceRuneArt(this.circle.pixels)); }
  /** Build menu, placement and deconstruct tools (screens/buildMenu.ts). */
  buildUi!: BuildUi;
  /** Crafting bench screen (screens/crafting.ts). */
  craftUi!: CraftingUi;
  /** Pack / inventory overlay (screens/pack.ts). */
  packUi!: PackUi;
  storageUi!: StorageUi;
  manageUi!: ManageUi;
  transferUi!: TransferUi;
  /** The Ctrl+0 debug menu (screens/debug.ts). */
  debugUi!: DebugUi;
  /** Book reading screen (screens/book.ts). */
  bookUi!: BookUi;
  /** Schematic overlay (screens/schematic.ts). */
  schemUi!: SchematicUi;
  /** Dialogue box overlay (screens/dialogue.ts). */
  dialogueUi!: DialogueUi;
  /** The opening cutscene (screens/intro.ts, script in content/cutscenes.ts). */
  introUi!: IntroCutscene;
  /** The golem's inner monologue as shown (ui/monologue.ts); the sim emits `thought` events into it. */
  monologue = new MonologueLog();
  /** Cutscene letterbox: current amount 0..1 and where it is easing to. */
  bars = { v: 0, to: 0 };
  /** The first crossing to the surface (screens/crossing.ts, script in content/cutscenes.ts). */
  crossingUi!: CrossingCutscene;
  /** Which way a cutscene has the golem drawn facing (null: as the sim says). Presentation only. */
  gaze: Facing | null = null;
  /** Debug: the calendar clock runs this many times faster (1: normal). Not saved. */
  debugClock = 1;
  /** Under the open sky: seconds until the next bird or cricket. */
  skyT = 3;
  /** Printable characters typed this frame (raw case) and "\b" for Backspace: text fields read these. */
  typed: string[] = [];

  constructor(public canvas: HTMLCanvasElement, public uiCanvas: HTMLCanvasElement, hiCanvas?: HTMLCanvasElement) {
    this.hiCanvas = hiCanvas ?? null;
    this.hctx = hiCanvas?.getContext("2d") ?? null;
    this.shell = new Shell(this);
    this.wctx = canvas.getContext("2d")!;
    this.wctx.imageSmoothingEnabled = false;
    this.ctx = uiCanvas.getContext("2d")!;
    this.ctx.imageSmoothingEnabled = false;
    this.outImg = this.wctx.createImageData(W, H);
    this.shaft = this.buildShaft(["#1c2638", "#121a28", "#26324a"]);
    this.sunShaft = this.buildShaft(["#4a3a1c", "#33280f", "#5e4a22"]);
    this.makeScreens();
    this.reset();
    this.screens.set(this.S.title);
    this.applySettings(this.settings, false);
    this.initSaves();
  }

  // ---------------------------------------------------------------- session
  /** Start presenting a world (a fresh session by default, or a loaded one). */
  reset(world: World = createWorld(newSeed())) {
    this.world = world;
    this.view?.dispose();
    const area = currentArea(world);
    this.view = new AreaView(area);
    // The schematic is of the dungeon, wherever the golem is.
    this.schemUi.reset(world);
    const pl = player(world);
    this.glight = makeLight(pl.x, pl.y - 6, GOLEM_LIGHT.rad, GOLEM_LIGHT.col, 0, 0.05, "golem");
    this.dripT = area.drips.map(() => Math.random() * 4);
    this.look = { eye: 0, core: 0, dormant: 1, sparkT: 1.5, sputter: 0, z: 0 };
    // Zoom is not saved: a world with a mended eye starts at the default zoomed-out view.
    this.zoomAnim = null;
    this.setZoom(hasFlag(world, FLAGS.golemEye) ? ZOOM_DEFAULT : 1);
    this.cam.snap(pl.x - this.vw / 2, pl.y - this.vh / 2 - 10);
    this.npcLooks.clear(); this.bubbles.clear();
    this.vision.reset(pl.mode === "scan");
    this.dialogueUi.reset();
    this.packUi.reset();
    this.storageUi.reset();
    this.manageUi.reset();
    this.transferUi.reset();
    this.particles = [];
    this.toast = null;
    this.fizzT = 0;
    this.shudder = null;
    this.uiTimers = [];
    this.rumbleT = 45 + Math.random() * 30;
    this.note = null; this.arriveFade = 0; this.doorFade = 0; this.hideGolem = false; this.runeAnim = null; this.runeDud = null; this.gaze = null; this.skyT = 3;
    this.monologue.reset();
    this.bars = { v: 0, to: 0 };
  }

  /** Present a saved world, resuming straight into play. */
  resume(world: World) {
    this.reset(world);
    this.clock.acc = 0; this.interp = null; this.shell.selection = [];
    this.autosaver.reset(player(world).area);
    this.look.dormant = 0;
    this.screens.set(this.S.play);
  }

  /** Save the world to the single localStorage slot (K on the play screen). */
  /** Quick save (K): slot 1 (save system v2, world/saveStore.ts). */
  saveGame() { this.saveTo("slot1"); }
  /** Load the saved world and resume play (L on the play or title screen). False if there is none. */
  /** Quick load (L): the newest slot. False (and a note) if there is none; the load itself finishes asynchronously. */
  loadGame(): boolean {
    if (!this.hasSaves) { this.say("NO SAVED GAME"); this.sfx.tone(180, 0.1, "square", 0.04); return false; }
    this.saves.latest().then((m) => { if (m) this.loadFrom(m.slot); else { this.hasSaves = false; this.say("NO SAVED GAME"); } });
    return true;
  }

  /** Rebuild the area view when the player has travelled to another area. */
  syncView() {
    const area = currentArea(this.world);
    if (this.view.area === area) return;
    this.view.dispose();
    this.view = new AreaView(area);
    this.dripT = area.drips.map(() => Math.random() * 4);
    this.glight.vx = -999;
    // new area: snap the camera instead of panning across the map
    const pl = this.pl;
    this.cam.x = clamp(pl.x - this.vw / 2, 0, area.w * TS - this.vw); this.cam.y = clamp(pl.y - 12 - this.vh / 2, 0, area.h * TS - this.vh);
  }

  // ---------------------------------------------------------------- zoom
  /** Apply a zoom level now: resize the world canvas and the scene/emissive/lighting buffers if the view size changes. */
  setZoom(z: number) {
    this.zoom = z;
    const { w, h } = viewSize(z);
    if (w === this.vw && h === this.vh) return;
    // keep the view centred on the same point while it grows/shrinks
    this.cam.x -= (w - this.vw) / 2; this.cam.y -= (h - this.vh) / 2;
    this.vw = w; this.vh = h;
    this.scene = makeCanvas(w, h);
    this.emit = makeCanvas(w, h);
    this.lighting = new Lighting(w, h);
    this.canvas.width = w; this.canvas.height = h;
    this.wctx.imageSmoothingEnabled = false;
    this.outImg = this.wctx.createImageData(w, h);
    if (this.view) {
      const a = this.area;
      this.cam.x = clamp(this.cam.x, 0, a.w * TS - w); this.cam.y = clamp(this.cam.y, 0, a.h * TS - h);
    }
    this.onView?.(w, h);
  }
  /** Ease to a zoom level over `dur` seconds (presentation clock). */
  zoomTo(z: number, dur: number) {
    if (z === this.zoom && !this.zoomAnim) return;
    this.zoomAnim = { from: this.zoom, to: z, t: 0, dur };
  }
  stepZoom(dt: number) {
    const a = this.zoomAnim;
    if (!a) return;
    a.t += dt;
    const k = clamp(a.t / a.dur, 0, 1), e = k * k * (3 - 2 * k);
    this.setZoom(lerp(a.from, a.to, e));
    if (k >= 1) this.zoomAnim = null;
  }
  /** Mouse wheel (App.tsx): discrete zoom steps, on the play screen only, once the eye is mended. */
  wheel(deltaY: number) {
    if (!this.screens.is("play") || !hasFlag(this.world, FLAGS.golemEye) || deltaY === 0) return;
    const cur = this.zoomAnim?.to ?? this.zoom;
    const next = nextZoomStep(cur, deltaY);
    if (next === cur) return;
    this.zoomTo(next, 0.25);
    this.sfx.tone(next > cur ? 420 : 560, 0.05, "triangle", 0.03);
  }

  buildShaft(cols: [string, string, string]): Sprite {
    // The shaft has no top. The roof it falls through is out of sight above the view, so the beam must never
    // end on an edge: it keeps the same lean and taper as it climbs, and over its upper half it thins out
    // pixel by pixel until nothing is left of it (FOOT is where it meets the floor: the pool lies below that).
    const FOOT = 150, FADE = 0.55;
    return makeSprite(80, FOOT + 10, 40, FOOT, 1, (p) => {
      for (let y = 0; y < FOOT + 10; y++) {
        const t = y / FOOT;
        const cx = lerp(22, 40, t), hw = lerp(7, 24, t);
        // how much of the beam is there at this height: none at the top, all of it below the fade
        const k = clamp(t / FADE, 0, 1), dens = k * k * (3 - 2 * k);
        for (let x = 0; x < 80; x++) {
          const d = Math.abs(x - cx) / hw;
          if (y > FOOT) {
            const e = ((x - 40) / 26) ** 2 + ((y - FOOT - 2) / 7) ** 2;
            if (e < 1 && (x + y) % 2 === 0) p.g(x, y, 1, 1, cols[2]);
            continue;
          }
          if (d < 1 && (x + y) % 2 === 0 && hash2(x, y, 2) > d * 0.8 && hash2(x, y, 5) < dens) p.g(x, y, 1, 1, d < 0.5 ? cols[0] : cols[1]);
        }
      }
    });
  }

  // ---------------------------------------------------------------- input
  keyDown(k: string, shift = false) {
    const raw = k;
    this.shell.ui.shift = shift;
    this.shell.ui.keys.add(k.toLowerCase());
    // remapped controls (settings.ts): the game reads default keys, the player presses theirs
    const mapped = translateKey(this.settings, k);
    if (mapped === null) return;
    k = mapped;
    if (!this.keys.has(k)) this.pressed.add(k);
    this.keys.add(k);
    if (raw.length === 1) this.typed.push(raw);
    else if (k === "backspace") this.typed.push("\b");
  }
  keyUp(k: string) { const m = translateKey(this.settings, k); this.keys.delete(m ?? k.toLowerCase()); }
  pointer() { this.pressed.add("click"); }

  /** Debug keybinds (Ctrl+0..6), wired up in App.tsx. Ctrl+0 opens (or closes) the debug menu. */
  debugKey(n: number) {
    const w = this.world, pl = this.pl;
    const say = (text: string) => { this.debugMsg = { text, t: 0 }; };
    if (n === 0) {
      this.debugUi.toggle();
    } else if (n === 1) {
      // Toggle the iron arm.
      if (this.hasArm) { clearFlag(w, FLAGS.golemArm); say("DEBUG: IRON ARM OFF"); }
      else { setFlag(w, FLAGS.golemArm); say("DEBUG: IRON ARM ON"); }
    } else if (n === 2) {
      // Give every rune glyph, the aether core, the rune chisel and the schematic
      // (skipping any already held or already placed).
      const given = grantStoryKit(w, pl);
      this.sfx.tone(520, 0.1, "triangle", 0.05);
      say(given ? "DEBUG: RUNES + CORE + TOOLS GRANTED" : "DEBUG: ALREADY HAVE ALL RUNES + CORE + TOOLS");
    } else if (n === 3) {
      this.debugSpeed = !this.debugSpeed;
      say(this.debugSpeed ? "DEBUG: SUPER SPEED ON" : "DEBUG: SUPER SPEED OFF");
    } else if (n === 4) {
      // Building tests: every build knowledge flag (incl. masonry for the brazier),
      // the basket worn on the back (the one in the pack if there is one, else a
      // new one), and enough materials to build one of everything several times.
      grantBuildKit(w, pl);
      say("DEBUG: BUILD + MASONRY + PLANS + BASKET + MATERIALS");
    } else if (n === 6) {
      // Gear and crafting tests (sim/debug.ts): ON grants the crafted and raw materials, the chisel and both runes,
      // wears the basket and unlocks every locked gear slot; OFF locks them again (what they hold returns to the pack).
      const on = toggleGearKit(w, pl);
      this.sfx.tone(on ? 560 : 380, 0.1, "triangle", 0.05);
      say(on ? "DEBUG: GEAR KIT ON - ALL SLOTS UNLOCKED" : "DEBUG: GEAR KIT OFF - SLOTS LOCKED AGAIN");
    } else if (n === 5) {
      // Toggle the mended eye (golem.eye) and the zoom it unlocks.
      if (hasFlag(w, FLAGS.golemEye)) { w.flags.delete(FLAGS.golemEye); this.zoomTo(1, 0.4); say("DEBUG: EYE REPAIR OFF"); }
      else { setFlag(w, FLAGS.golemEye); this.zoomTo(ZOOM_DEFAULT, 1); this.eyeBoost = 1.5; say("DEBUG: EYE REPAIR ON (SCROLL TO ZOOM)"); }
    }
  }
  has(...k: string[]) { return k.some((x) => this.keys.has(x)); }
  hit(...k: string[]) { return k.some((x) => this.pressed.has(x)); }

  // ---------------------------------------------------------------- debug menu host (screens/debug.ts)
  /** Set or clear a flag from the debug menu. The mended eye also moves the zoom, as Ctrl+5 does. */
  debugSetFlag(flag: string, on: boolean) {
    const w = this.world;
    if (on) setFlag(w, flag); else clearFlag(w, flag);
    if (flag === FLAGS.golemEye) {
      if (on) { this.zoomTo(ZOOM_DEFAULT, 0.6); this.eyeBoost = 1.5; } else this.zoomTo(1, 0.4);
    }
  }
  /** Put the player at a debug place (any area): the view and camera follow at once. False if no free spot is near. */
  debugTeleport(p: DebugPlace): boolean {
    const pl = this.pl;
    if (!teleportTo(this.world, pl, p.area, p.x, p.y)) return false;
    this.syncView();
    const a = this.area;
    this.cam.x = clamp(pl.x - this.vw / 2, 0, Math.max(0, a.w * TS - this.vw));
    this.cam.y = clamp(pl.y - 12 - this.vh / 2, 0, Math.max(0, a.h * TS - this.vh));
    this.glight.vx = -999;
    this.particles = [];
    this.drainEvents();
    return true;
  }
  /** A fresh world straight in the dungeon, no intro. */
  debugNewGame() { this.resume(createWorld(newSeed())); this.say("NEW GAME (DEBUG)"); }
  /** The two-area worker fixture (what window.dustwake.foundations() does). */
  debugFoundations() { this.resume(foundationDemo()); this.say("FOUNDATION FIXTURE: A WORKER GATHERS THROUGH THE RUNES."); }
  /** Step the view zoom through ZOOM_STEPS (ascending order, wrapping). */
  debugZoom() {
    const cur = this.zoomAnim?.to ?? this.zoom;
    const steps = [...ZOOM_STEPS].sort((x, y) => x - y);
    const next = steps.find((z) => z > cur + 1e-6) ?? steps[0];
    this.zoomTo(next, 0.3);
  }

  // ---------------------------------------------------------------- helpers
  get pl() { return player(this.world); }
  get area() { return currentArea(this.world); }
  get hasArm() { return hasFlag(this.world, FLAGS.golemArm); }
  spawn(p: Partial<Particle> & { x: number; y: number }) { return particlesV.spawn(this, p); }
  shake(t: number, m: number) { if (!this.settings.shake) return; this.shakeT = Math.max(this.shakeT, t); this.shakeMag = Math.max(this.shakeMag, m); }
  dist2(x: number, y: number) { const pl = this.pl, dx = x - pl.x, dy = y - pl.y; return dx * dx + dy * dy; }
  volAt(x: number, y: number) { return clamp(1 - Math.sqrt(this.dist2(x, y)) / 220, 0, 1); }
  later(delay: number, fn: () => void) { this.uiTimers.push({ at: this.t + delay, fn }); }

  sparkBurst(n: number) { return particlesV.sparkBurst(this, n); }

  // ---------------------------------------------------------------- screens
  makeScreens() {
    const g = this;
    const scr = (id: string, opaque: boolean, update: (dt: number) => void, render: () => void): Screen => ({ id, opaque, t: 0, update, render });
    this.buildUi = new BuildUi(this);
    this.craftUi = new CraftingUi(this);
    this.packUi = new PackUi(this);
    this.storageUi = new StorageUi(this);
    this.manageUi = new ManageUi(this);
    this.transferUi = new TransferUi(this, (id) => this.manageUi.open(id));
    this.manageUi.openTransfer = (id) => this.transferUi.open(id);
    this.debugUi = new DebugUi(this);
    this.bookUi = new BookUi(this);
    this.schemUi = new SchematicUi(this);
    this.dialogueUi = new DialogueUi(this);
    this.introUi = new IntroCutscene(this);
    this.crossingUi = new CrossingCutscene(this);
    this.S = {
      title: scr("title", true, (dt) => {
        if (g.hit("l") && g.loadGame()) { g.sfx.init(); return; }
        if (g.pressed.size) { g.sfx.init(); g.introUi.start(); }
        if (Math.random() < 0.3) g.spawn({ x: Math.random() * W, y: H + 2, vy: -10 - Math.random() * 12, vx: (Math.random() - 0.5) * 4, life: 6, kind: "ember", col: Math.random() < 0.5 ? "#ff8a3a" : "#c84a10", emit: true });
        g.updateParticles(dt);
      }, () => renderTitle(g.ctx, g.t, g.particles)),
      intro: this.introUi.screen,
      play: scr("play", true, (dt) => g.updatePlay(dt), () => g.renderWorldScene()),
      tele: scr("tele", true, (dt) => {
        // the first jump is a cutscene (it runs on into the crossing): Esc skips the whole of it
        if (g.tele.first && g.S.tele.t > 0.2 && g.hit("escape")) { g.skipCrossing(); return; }
        if (g.updateTele(dt)) return;
        stepPlayer(g.world, dt, { ix: 0, iy: 0, use: false });
        g.drainEvents();
        g.worldFrame(dt);
      }, () => {
        g.renderWorldScene();
        const t = g.S.tele.t, w0 = g.tele.dur - 1.6;
        if (t > w0) { g.ctx.fillStyle = `rgba(${g.settings.flash ? "235,240,255" : "0,0,0"},${clamp((t - w0) / 1.4, 0, 1)})`; g.ctx.fillRect(0, 0, W, H); }
        if (g.tele.first) g.renderSkipHint(t);
      }),
      crossing: this.crossingUi.screen,
      book: this.bookUi.screen,
      build: this.buildUi.screen,
      crafting: this.craftUi.screen,
      storage: this.storageUi.screen,
      manage: this.manageUi.screen,
      debug: this.debugUi.screen,
      dialogue: this.dialogueUi.screen,
      inv: this.packUi.screen,
      schem: this.schemUi.screen,
    };
  }

  // ---------------------------------------------------------------- update
  /** The last update's dt (the folk bubbles age on it while drawing). */
  frameDt = 0;
  update(dt: number) {
    this.frameDt = dt;
    this.t += dt;
    if (this.uiTimers.length) {
      const due = this.uiTimers.filter((u) => u.at <= this.t);
      this.uiTimers = this.uiTimers.filter((u) => u.at > this.t);
      for (const u of due) u.fn();
    }
    this.stepZoom(dt);
    this.screens.update(dt);
    this.pressed.clear();
    this.typed.length = 0;
  }

  /** One frame of world simulation plus its presentation. */
  worldFrame(dt: number) {
    stepWorld(this.world, dt);
    if (this.debugClock > 1) advanceDay(this.world, ((this.debugClock - 1) * dt * 24) / DAY_SECONDS);
    this.drainEvents();
    this.syncView();
    if (this.view.flush()) this.glight.vx = -999;
    this.updateWorldFx(dt);
  }

  drainEvents() { return reactionsV.drainEvents(this); }

  onNearby(e: SimEvent) { return reactionsV.onNearby(this, e); }

  onEvent(e: SimEvent) { return reactionsV.onEvent(this, e); }

  updatePlay(dt: number) {
    const w = this.world, pl = this.pl, lk = this.look;
    if (this.paused) {
      // game speed 0: menus and saving still answer, the world holds still, the scene stays alive
      if (this.hit("k")) this.saveGame();
      if (this.hit("l") && this.loadGame()) return;
      if (!pl.task) {
        if (this.hit("i", "tab")) { this.packUi.open("view"); return; }
        if (this.hit("m") && hasItem(pl, "schematic")) { this.schemUi.open(); return; }
        if (this.hit("b")) { this.buildUi.open(); return; }
      }
      this.animate(dt);
      return;
    }
    addPlayTime(w, dt);
    // save / load (one slot in localStorage, the versioned format of world/save.ts)
    if (this.hit("k")) this.saveGame();
    if (this.hit("l") && this.loadGame()) return;
    // overlays
    if (!pl.task) {
      if (this.hit("i", "tab")) { this.packUi.open("view"); return this.worldFrame(dt); }
      if (this.hit("m") && hasItem(pl, "schematic")) { this.schemUi.open(); return this.worldFrame(dt); }
      if (this.hit("b")) { this.buildUi.open(); return this.worldFrame(dt); }
      if (this.hit("v")) { this.buildUi.quickPlace(); return this.worldFrame(dt); }
      // Repeat placement / deconstruction: reopen the tool once the ordered work is done.
      if (this.buildUi.pending) { this.buildUi.resumeAfterWork(); if (!this.screens.is("play")) return this.worldFrame(dt); }
      // After crafting at a bench, the bench's plans come back once the work is done.
      if (this.craftUi.pending) { this.craftUi.resume(); if (!this.screens.is("play")) return this.worldFrame(dt); }
      // After slotting a core in or out from the management screen, the worker's screen comes back once the reach is done.
      if (this.manageUi.pending) { this.manageUi.resume(); if (!this.screens.is("play")) return this.worldFrame(dt); }
    }
    let ix = 0, iy = 0;
    if (this.has("arrowleft", "a")) ix -= 1;
    if (this.has("arrowright", "d")) ix += 1;
    if (this.has("arrowup", "w")) iy -= 1;
    if (this.has("arrowdown", "s")) iy += 1;
    // E / Enter interact, Space attacks (the two-arm slam): separate actions, both usable next to anything.
    const res = stepPlayer(w, dt, { ix, iy, use: this.hit("e", "enter"), attack: this.hit(" "), core: this.hit("c"), toggleScan: this.hit("z"), speed: this.debugSpeed ? this.debugSpeedMult : 1, noclip: this.debugNoclip });
    this.drainEvents();
    // golem damage sparks
    lk.sparkT -= dt;
    if (lk.sparkT <= 0) {
      lk.sparkT = 1.5 + Math.random() * 4;
      if (!this.hasArm) { this.sparkBurst(3 + ((Math.random() * 4) | 0)); if (Math.random() < 0.6) this.sfx.spark(); }
      if (Math.random() < 0.12) lk.sputter = 0.25;
    }
    lk.sputter = Math.max(0, lk.sputter - dt);
    // The sputter is the damaged body's: the core keeps flickering (the golem is
    // still damaged), but once the guardian mends the eye it no longer gutters.
    lk.core = lk.sputter > 0 ? (Math.random() < 0.5 ? 0.3 : 0.8) : 1;
    lk.eye = lk.sputter > 0 && !hasFlag(w, FLAGS.golemEye) ? 0.3 : 1;
    lk.dormant = 0;
    this.eyeBoost = Math.max(0, this.eyeBoost - dt);
    this.target = res.target;
    if (res.ui) this.packUi.open("select", res.ui.socket);
    // rumble events
    // the buried halls groan; a lived-in room under a sound roof does not
    if (!this.area.base.outdoor && !this.area.base.interior) this.rumbleT -= dt;
    if (this.rumbleT <= 0) {
      this.rumbleT = 50 + Math.random() * 50;
      this.sfx.rumble();
      this.shake(2.2, 1.5);
      for (let i = 0; i < 30 * this.zoom * this.zoom; i++) this.spawn({ x: this.cam.x + Math.random() * this.vw, y: this.cam.y + Math.random() * this.vh, z: 60 + Math.random() * 40, vz: -10, life: 4, kind: "debris", col: Math.random() < 0.5 ? "#6a6372" : "#4b4552", g: 60 });
    }
    this.worldFrame(dt);
  }

  /** The rune-jump effect (first jump: long, and it runs on into the crossing cutscene; later hops: short). Returns true if it ended. */
  updateTele(_dt: number): boolean {
    const t = this.S.tele.t, lk = this.look, tl = this.tele, pl = this.pl;
    if (!pl.task && t > 0.2) {
      this.sfx.setHum(0);
      if (tl.first && tl.travelled) { this.particles = []; this.crossingUi.start(); }
      else {
        if (tl.first) { this.letterbox(false); this.monologue.release(); } // the jump failed: there is no crossing to run on into
        this.screens.set(this.S.play); this.arriveFade = tl.travelled ? 1 : 0; lk.z = tl.travelled ? 16 : 0;
      }
      return true;
    }
    const lift = tl.dur - 1.6;
    lk.z = Math.min(t, lift) * (tl.first ? 4 : 6) + Math.sin(t * 3) * 1;
    lk.eye = 1; lk.core = 1;
    this.shake(0.1, Math.min(4, t * 1.2));
    const c = tl;
    for (let i = 0; i < 6; i++) {
      const a = Math.random() * Math.PI * 2, r = 20 + Math.random() * 50;
      this.spawn({ x: c.x + Math.cos(a) * r, y: c.y + Math.sin(a) * r, z: 2, vx: -Math.cos(a) * r * 0.8, vy: -Math.sin(a) * r * 0.8, vz: 10 + Math.random() * 20, life: 1.2, kind: "rune", col: Math.random() < 0.5 ? "#c0a0ff" : "#80e0ff", emit: true, g: -5 });
    }
    this.glight.int = 0.9 + t * 0.4;
    return false;
  }

  /**
   * Esc during the first jump's lift-off: let the sim finish the channel at once (it travels), then end the
   * crossing as if it had played (screens/crossing.ts: the same hour, the same lines thought).
   */
  skipCrossing() {
    const pl = this.pl;
    for (let i = 0; i < 200 && pl.task; i++) stepPlayer(this.world, 0.1, { ix: 0, iy: 0, use: false });
    this.drainEvents();
    this.sfx.setHum(0);
    this.look.z = 0;
    if (!this.tele.travelled) { this.letterbox(false); this.monologue.release(); this.screens.set(this.S.play); return; }
    this.syncView();
    this.particles = [];
    this.crossingUi.start();
    this.crossingUi.skip();
  }

  // ---------------------------------------------------------------- the hour (content/daycycle.ts)
  /**
   * How lit (0..1) a prop is at this hour. Where people keep the lights (`tended` areas) a lamp follows its kind's
   * habit; anywhere else, and anything the golem built itself, simply stays as it is.
   */
  tendedLevel(p: PropInst, hour = worldHour(this.world)): number {
    if (!this.area.base.tended || p.dyn) return 1;
    const habit = propDef(p.kind).habit;
    return habit ? litLevel(habit, p.id, hour) : 1;
  }

  onDayPhase(phase: DayPhase) { return reactionsV.onDayPhase(this, phase); }

  /** Debug menu: move the clock on to the next mark of the day. Returns what it now reads. */
  debugAdvanceTime(): string {
    const marks = [0, 5, 6, 7, 12, 19, 20, 21], h = worldHour(this.world);
    advanceDayTo(this.world, marks.find((m) => m > h + 0.01) ?? marks[0]);
    this.drainEvents();
    const now = worldHour(this.world);
    return `${clockText(now)} ${phaseAt(now).toUpperCase()}`;
  }

  /**
   * The surface rune's presentation state: the arrival cutscene's, else what the sim says of it (sim/runes.ts:
   * runeState). Dormant: eroded and dark. Restored and linked: carved, its steady pulse. Restored but severed (the
   * circle below is broken, so nothing answers): carved, burning low as embers. While it is refusing someone
   * (`runeDud`), its sputter rides over whichever of those it rests at (view/runeFx.ts).
   */
  surfaceRuneState(): { t: number; glow: number; column: number } {
    if (this.runeAnim) return this.runeAnim;
    const state = runeState(this.world, RUNE_NODES.surface);
    const rest = state === "linked" ? linkedGlow(this.t) : state === "severed" ? severedGlow(this.t) : 0;
    const d = this.runeDud, p = d ? this.area.prop(RUNE_NODES.surface.prop) : undefined;
    const glow = d && p && Math.hypot(p.x - d.x, p.y - d.y) < 4 ? runeDudGlow(d.t, rest, state === "dormant" ? 0.5 : 1) : rest;
    return { t: state === "dormant" ? 0 : 1, glow, column: 0 };
  }

  /** The crossing's arrival act (screens/crossing.ts), `t` seconds in: the overgrown rune wakes and redraws itself, then summons the golem. */
  arriveStep(t: number, dt: number) {
    const A = ARRIVE, t0 = t - dt, lk = this.look;
    const rp = this.area.prop("rune.surface");
    const c = rp ?? this.pl;
    const crossed = (at: number) => t >= at && t0 < at;
    const ease = (x: number) => x * x * (3 - 2 * x);
    const prog = ease(clamp((t - A.SWEEP) / (A.SWEEP_END - A.SWEEP), 0, 1));
    let glow = 0;
    if (t >= A.GLOW && t < A.SWEEP) glow = 0.4 * ease(clamp((t - A.GLOW) / (A.SWEEP - A.GLOW), 0, 1)) * (0.85 + 0.15 * Math.sin(t * 7));
    else if (t >= A.SWEEP && t < A.SWEEP_END) glow = 0.4 + 0.25 * prog + 0.06 * Math.sin(t * 6);
    else if (t >= A.SWEEP_END && t < A.PULSE_END) glow = 0.65 + 0.95 * Math.sin((Math.PI * (t - A.SWEEP_END)) / (A.PULSE_END - A.SWEEP_END));
    else if (t >= A.PULSE_END) glow = 0.75 + 0.2 * Math.sin(t * 5);
    const column = t < A.PULSE_END ? 0 : t < A.FLASH ? ease((t - A.PULSE_END) / (A.FLASH - A.PULSE_END)) : Math.max(0, 1 - (t - A.FLASH) / 0.9);
    const prev = this.runeAnim?.t ?? 0;
    this.runeAnim = { t: prog, glow, column };
    this.hideGolem = t < A.FLASH;

    // sound follows the phases: a low hum, rising through the sweep; the pulse; the summon
    if (crossed(A.GLOW)) { this.sfx.setHum(0.25); this.sfx.tone(98, 2.2, "sine", 0.05, 110); }
    if (t >= A.SWEEP && t < A.SWEEP_END) this.sfx.setHum(0.25 + prog * 0.75);
    if (crossed(A.SWEEP)) this.sfx.tone(110, A.SWEEP_END - A.SWEEP, "sine", 0.05, 220);
    if (crossed(A.SWEEP_END)) { this.sfx.activate(); this.shake(0.6, 2); }
    if (crossed(A.PULSE_END)) this.sfx.tone(196, A.FLASH - A.PULSE_END, "triangle", 0.04, 392);
    if (crossed(A.FLASH)) { this.sfx.teleport(); this.shake(0.9, 3.5); this.sfx.setHum(0.2); }
    if (crossed(A.END - 0.5)) this.sfx.setHum(0);

    const px = this.circle.pixels;
    // motes rising from the lit carvings
    if (glow > 0 && t < A.FLASH && Math.random() < dt * 14 * Math.min(1, glow)) {
      const q = this.runeArt.model.pixels[(Math.random() * px.length) | 0];
      if (carvingVisible(q, prog)) this.spawn({ x: c.x + q.x, y: c.y + q.y, z: 0, vz: 6 + Math.random() * 10, life: 1.2, kind: "rune", col: Math.random() < 0.6 ? "#a070ff" : "#70d0ff", emit: true, g: -2 });
    }
    // the plants over each stretch the glow reaches wither and blow away
    if (prog > prev) {
      for (const cl of this.runeArt.model.clumps) if (clumpCleared(cl, prog) && !clumpCleared(cl, prev)) this.witherClump(c.x + cl.x, c.y + cl.y, cl.px.length);
      if (t < A.SWEEP_END) this.shake(0.1, 0.3 + prog * 0.8);
    }
    // summon: motes converge on the dais while the column of light builds
    if (t >= A.PULSE_END && t < A.FLASH) {
      this.shake(0.1, 0.4 + column * 2.6);
      for (let i = 0; i < 2 + column * 8; i++) {
        const a = Math.random() * Math.PI * 2, r = 50 + Math.random() * 40;
        this.spawn({ x: c.x + Math.cos(a) * r, y: c.y + Math.sin(a) * r, z: 2 + Math.random() * 6, vx: -Math.cos(a) * r * 1.1, vy: -Math.sin(a) * r * 1.1, vz: 4 + column * 30, life: 0.9, kind: "rune", col: Math.random() < 0.5 ? "#c0a0ff" : "#80e0ff", emit: true, g: -4 });
      }
    }
    if (crossed(A.FLASH)) for (let i = 0; i < 46; i++) {
      const a = Math.random() * Math.PI * 2, v = 30 + Math.random() * 70;
      this.spawn({ x: c.x, y: c.y + 4, z: 4 + Math.random() * 20, vx: Math.cos(a) * v, vy: Math.sin(a) * v * 0.5, vz: 20 + Math.random() * 40, life: 0.8 + Math.random() * 0.6, kind: "spark", col: Math.random() < 0.5 ? "#e8e0ff" : "#a070ff", emit: true, g: 90 });
    }
    const fall = clamp((t - A.FLASH) / A.FALL, 0, 1);
    lk.z = 30 * (1 - fall) ** 2;
    lk.eye = 1; lk.core = 1; lk.dormant = 0;
    this.cam.x = clamp(c.x - this.vw / 2, 0, this.area.w * TS - this.vw); this.cam.y = clamp(c.y - 12 - this.vh / 2, 0, this.area.h * TS - this.vh);
  }

  /** The arrival is over (played out or skipped): the rune follows its flag again and the golem stands on it, lit. */
  arriveEnd() {
    this.runeAnim = null; this.hideGolem = false;
    this.look.z = 0; this.look.eye = 1; this.look.core = 1; this.look.dormant = 0;
    this.sfx.setHum(0);
  }

  /** The golem comes down on the dais: the blow, a ring of dust, the ground answering. */
  landFx() {
    const pl = this.pl;
    this.sfx.slam(); this.shake(0.35, 2.2);
    for (let i = 0; i < 22; i++) {
      const ang = Math.random() * Math.PI * 2, v = 16 + Math.random() * 30;
      this.spawn({ x: pl.x + Math.cos(ang) * 4, y: pl.y + Math.sin(ang) * 2, z: 1, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v * 0.5, vz: 6 + Math.random() * 12, life: 0.7 + Math.random() * 0.6, kind: "dust", col: Math.random() < 0.5 ? "#8a8478" : "#a09a8c", g: 20 });
    }
    if (!this.hasArm) this.sparkBurst(6);
  }

  /** First light from the east during the crossing's dawn: a low gold light across the clearing (0 puts it out). */
  sunrise(level: number) {
    if (level <= 0 && !this.view.lights.has("sunrise")) return;
    const pl = this.pl;
    const lt = this.view.dynamicLight("sunrise", () => makeLight(pl.x + 190, pl.y - 30, 330, [1, 0.7, 0.4], 0, 0, "sunrise"));
    lt.int = 0.75 * clamp(level, 0, 1);
  }

  clearParticles() { this.particles = []; }
  anyKey() { return this.pressed.size > 0; }
  /** Wake again: a fresh world and the whole opening (R at the crossing's chapter card). */
  wakeAgain() { this.reset(); this.introUi.start(); }

  /** A clump of plants on the rune withers and blows off as the glow reaches it. */
  witherClump(x: number, y: number, size: number) {
    const cols = ["#3e5e2a", "#527636", "#6e8e34", "#7a6a3a", "#5a4630"];
    for (let i = 0; i < 1 + Math.min(4, size / 6); i++)
      this.spawn({ x: x + (Math.random() - 0.5) * 6, y: y + (Math.random() - 0.5) * 4, z: 1, vx: 10 + Math.random() * 22, vy: (Math.random() - 0.5) * 10, vz: 12 + Math.random() * 18, life: 0.7 + Math.random() * 0.7, kind: "debris", col: cols[(Math.random() * cols.length) | 0], g: 26 });
    if (Math.random() < 0.6) this.spawn({ x, y, z: 1, vz: 10 + Math.random() * 8, life: 0.8, kind: "rune", col: "#c0a0ff", emit: true, g: -3 });
  }

  /** Over the arrival's world scene: the cut in from black, and the white of the summoning flash. */
  arriveOverlay(t: number) {
    const A = ARRIVE, ctx = this.ctx;
    if (t < A.FADE) { ctx.fillStyle = `rgba(0,0,0,${1 - t / A.FADE})`; ctx.fillRect(0, 0, W, H); }
    if (t > A.FLASH && t < A.FLASH + 1) { ctx.fillStyle = `rgba(235,240,255,${1 - (t - A.FLASH)})`; ctx.fillRect(0, 0, W, H); }
  }

  /** The cinema dressing alone (letterbox, the golem's thoughts), over a picture a cutscene drew itself. */
  renderCinema() {
    this.renderBars();
    const bar = this.bars.v * this.bars.v * (3 - 2 * this.bars.v);
    drawMonologue(this.ctx, this.monologue, this.t, 7 + Math.round(12 * bar));
  }

  /** "ESC - SKIP", small in the lower bar of a cutscene that can be skipped (`t`: seconds it has run). */
  renderSkipHint(t: number) {
    const ctx = this.ctx;
    ctx.globalAlpha = clamp((t - 0.6) * 1.5, 0, 1) * 0.85;
    drawText(ctx, "ESC - SKIP", W - 5, H - 9, "#8a8392", 1, "right");
    ctx.globalAlpha = 1;
  }

  /** Presentation that follows the world each simulated frame. */
  updateWorldFx(dt: number) {
    const pl = this.pl, area = this.area;
    // camera
    const VW = this.vw, VH = this.vh;
    const tx = clamp(pl.x - VW / 2, 0, area.w * TS - VW), ty = clamp(pl.y - 12 - VH / 2, 0, area.h * TS - VH);
    this.cam.follow(tx, ty, dt);
    if (!this.settings.flash) { this.crackFlash = 0; this.arriveFade = 0; }
    this.shakeT = Math.max(0, this.shakeT - dt);
    if (this.shakeT <= 0) this.shakeMag = 0;
    this.crackFlash = Math.max(0, this.crackFlash - dt);
    if (this.shudder && (this.shudder.t -= dt) <= 0) this.shudder = null;
    // golem light
    const gl = this.glight;
    gl.x = pl.x; gl.y = pl.y - 6;
    // The glow is the sim's (sim/gear.ts: golemGlow: the standard glow, or what a worn rune of glow makes of it); the light system applies it.
    applyGlow(gl, golemGlow(this.world, pl));
    if (Math.abs(gl.x - gl.vx) > 2 || Math.abs(gl.y - gl.vy) > 2) computeVis(gl, area);
    const base = this.screens.is("tele") ? gl.int : 1.0;
    gl.cur = base * this.look.core * (0.95 + 0.05 * Math.sin(this.t * 13) * Math.sin(this.t * 3.1)) + this.eyeBoost * 0.3;
    // NPCs: eased pose and eye, eye light through the light registry
    this.updateNpcLooks(dt);
    // light flicker, and the hour: tended lamps are lit and put out with the day, sky light takes the sky's colour
    const hour = worldHour(this.world), sun = sunLevel(hour);
    for (const L of this.view.lights.values()) {
      const n = Math.sin(this.t * 9 + L.seed) * 0.5 + Math.sin(this.t * 23.7 + L.seed * 2) * 0.3 + Math.sin(this.t * 3.3 + L.seed) * 0.2;
      L.cur = L.int * (1 - L.flick * (0.5 + 0.5 * n));
      if (L.habit) L.day = litLevel(L.habit, L.owner!, hour);
      else if (L.sky) { const s = skyLight(L.sky, hour); L.r = s.col[0]; L.g = s.col[1]; L.b = s.col[2]; L.day = s.gain; }
    }
    // rune
    const r = area.ritual;
    const cl = this.view.byId("circle");
    if (r?.active) {
      this.sfx.setHum(Math.min(1, r.actT / 2));
      if (cl) {
        const target = 120;
        if (cl.rad < target) { cl.rad = Math.min(target, cl.rad + dt * 30); if (Math.abs(cl.rad - cl.vx) > 0) computeVis(cl, area); }
        cl.int = 0.6 + Math.min(1, r.actT / 3) * 0.6;
        cl.cur = cl.int * (0.85 + 0.15 * Math.sin(this.t * 3));
      }
      const c = area.ritualPos;
      if (Math.random() < dt * 30) {
        const p = this.circle.pixels[(Math.random() * this.circle.pixels.length) | 0];
        this.spawn({ x: c.x + p.x, y: c.y + p.y, z: 0, vz: 8 + Math.random() * 12, life: 1.5, kind: "rune", col: Math.random() < 0.6 ? "#a070ff" : "#70d0ff", emit: true, g: -2 });
      }
    } else if (cl) {
      cl.cur = cl.int * (0.8 + 0.2 * Math.sin(this.t * 1.3)) + (this.fizzT > 0 ? Math.random() * 0.6 : 0);
    }
    this.fizzT = Math.max(0, this.fizzT - dt);
    // a rune that refused: its sputter runs its course, spitting sparks off the carvings while it gutters
    if (this.runeDud) {
      const d = this.runeDud;
      if (d.t < RUNE_DUD.gutter && Math.random() < dt * 40) {
        const p = this.circle.pixels[(Math.random() * this.circle.pixels.length) | 0];
        this.spawn({ x: d.x + p.x, y: d.y + p.y, z: 1, vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.5) * 30, vz: 20 + Math.random() * 30, life: 0.45, kind: "spark", col: Math.random() < 0.5 ? "#ff6a8a" : "#a070ff", emit: true, g: 120 });
      }
      if ((d.t += dt) >= RUNE_DUD.dur) this.runeDud = null;
    }
    // surface rune glow: dark and dead while dormant (no baseline), driven by the cutscene, steady once restored
    const rg = this.view.byId("runeglow");
    if (rg) {
      const st = this.surfaceRuneState();
      rg.cur = rg.int * (st.glow * (0.92 + 0.08 * Math.sin(this.t * 2.3)) + st.column * 0.7);
      // motes rise from the carvings only while the rune has somewhere to carry them
      if (!this.runeAnim && runeState(this.world, RUNE_NODES.surface) === "linked" && Math.random() < dt * 8) {
        const p = this.circle.pixels[(Math.random() * this.circle.pixels.length) | 0];
        this.spawn({ x: rg.x + p.x, y: rg.y + p.y, z: 0, vz: 6 + Math.random() * 10, life: 1.4, kind: "rune", col: Math.random() < 0.6 ? "#a070ff" : "#70d0ff", emit: true, g: -2 });
      }
    }
    // short-hop arrival
    if (this.arriveFade > 0) { this.arriveFade = Math.max(0, this.arriveFade - dt * 1.4); this.look.z = Math.max(0, this.look.z - dt * 24); }
    if (this.doorFade > 0) this.doorFade = Math.max(0, this.doorFade - dt * 2.8);
    if (this.note) { this.note.t += dt; if (this.note.t > 3) this.note = null; }
    this.stepMonologue(dt);
    // drifting leaves on the wind
    if (area.base.outdoor && Math.random() < dt * 1.5)
      this.spawn({ x: this.cam.x - 20 + Math.random() * VW, y: this.cam.y + Math.random() * VH, z: 30 + Math.random() * 40, vx: 8 + Math.random() * 8, vy: (Math.random() - 0.3) * 3, vz: -4 - Math.random() * 3, life: 7, kind: "mote", col: ["#7a5630", "#946a34", "#5a7a34", "#a07c40"][(Math.random() * 4) | 0], emit: false, g: 0 });
    // fireflies under the open sky: the night's, thinning out as the sun comes up
    if (area.base.outdoor && Math.random() < dt * 3 * this.zoom * this.zoom * (1 - sun))
      this.spawn({ x: this.cam.x + Math.random() * VW, y: this.cam.y + Math.random() * VH, z: 6 + Math.random() * 20, vx: (Math.random() - 0.5) * 4, vy: (Math.random() - 0.5) * 3, life: 4, kind: "mote", col: "#d8f080", emit: true, g: 0 });
    // by day: pollen on the air and the odd butterfly instead
    if (area.base.outdoor && Math.random() < dt * 1.2 * this.zoom * this.zoom * sun)
      this.spawn({ x: this.cam.x + Math.random() * VW, y: this.cam.y + Math.random() * VH, z: 8 + Math.random() * 18, vx: (Math.random() - 0.5) * 10, vy: (Math.random() - 0.5) * 6, life: 5, kind: "mote", col: ["#f0e8c0", "#e8c860", "#d8d0e8", "#e89a5a"][(Math.random() * 4) | 0], emit: false, g: 0 });
    // and the open air sounds its hour: birds by day, crickets by night, a hush while one hands over to the other
    if (area.base.outdoor && (this.skyT -= dt) <= 0) {
      this.skyT = 2.5 + Math.random() * 6;
      if (sun > 0.6) this.sfx.bird(); else if (sun < 0.25) this.sfx.cricket();
    }
    // drips
    area.drips.forEach((d, i) => {
      this.dripT[i] -= dt;
      if (this.dripT[i] <= 0) {
        this.dripT[i] = 1.5 + Math.random() * 4;
        if (Math.abs(d.x - this.cam.x - VW / 2) < VW / 2 + 100 && Math.abs(d.y - this.cam.y - VH / 2) < VH / 2 + 90)
          this.spawn({ x: d.x, y: d.y, z: 70, vz: -20, life: 3, kind: "drip", col: "#6a8aa8", g: 140 });
      }
    });
    // torch embers
    for (const p of area.props) {
      if (!p.lit) continue;
      const fire = propDef(p.kind).fire;
      if (!fire || this.tendedLevel(p, hour) <= 0.05) continue;
      if (Math.abs(p.x - this.cam.x - VW / 2) > VW / 2 + 40 || Math.abs(p.y - this.cam.y - VH / 2) > VH / 2 + 50) continue;
      if (Math.random() < dt * fire.embers)
        this.spawn({ x: p.x + (Math.random() - 0.5) * 4, y: p.y + fire.emberDy, z: 14, vx: (Math.random() - 0.5) * 6, vz: 10 + Math.random() * 10, life: 1 + Math.random(), kind: "ember", col: Math.random() < 0.5 ? "#ffb040" : "#ff6a1a", emit: true, g: -4 });
    }
    // chimney smoke over the town's roofs (props with a `smoke` row), leaning on the same night wind as the leaves
    for (const p of area.props) {
      const sm = propDef(p.kind).smoke;
      if (!sm || Math.abs(p.x - this.cam.x - VW / 2) > VW / 2 + 40 || Math.abs(p.y - this.cam.y - VH / 2) > VH / 2 + 70) continue;
      if (Math.random() < dt * sm.rate * (area.base.tended ? hearthSmoke(hour) : 1)) // thick at breakfast and supper
        this.spawn({ x: p.x + sm.dx + (Math.random() - 0.5) * 3, y: p.y, z: sm.z, vx: 3 + Math.random() * 4, vy: (Math.random() - 0.5) * 1.5, vz: 7 + Math.random() * 5, life: 2.2 + Math.random() * 1.8, kind: "smoke", col: Math.random() < 0.5 ? "#6e6a70" : "#585460", g: -1, size: 2, emit: false });
    }
    // ambient dust motes
    if (Math.random() < dt * 8 * this.zoom * this.zoom)
      this.spawn({ x: this.cam.x + Math.random() * VW, y: this.cam.y + Math.random() * VH, z: 4 + Math.random() * 30, vx: (Math.random() - 0.5) * 3, vy: (Math.random() - 0.5) * 2, vz: (Math.random() - 0.5) * 2, life: 5, kind: "mote", col: "#b8b0a0", emit: false, g: 0 });
    // moonbeam motes
    const moon = this.view.byId("moon");
    if (moon && Math.random() < dt * 5)
      this.spawn({ x: moon.x - 14 + Math.random() * 30, y: moon.y + 2, z: 10 + Math.random() * 70, vx: (Math.random() - 0.5) * 2, vz: -3 - Math.random() * 3, life: 6, kind: "mote", col: sun > 0.5 ? "#ffe8b0" : "#a8c0ff", emit: true, g: 0 });
    // item glints
    if (Math.random() < dt * 2) {
      const cands: [number, number][] = [];
      for (const it of interactables(area)) if (it.kind === "item" || it.kind === "propItem" || (it.kind === "container" && it.hasItem)) cands.push([it.x, it.y - (it.itemZ ?? 6) - 2]);
      const near = cands.filter(([x, y]) => Math.abs(x - this.cam.x - VW / 2) < VW / 2 + 10 && Math.abs(y - this.cam.y - VH / 2) < VH / 2 + 10);
      if (near.length) {
        const [x, y] = near[(Math.random() * near.length) | 0];
        this.spawn({ x: x + (Math.random() - 0.5) * 8, y: y + 2, z: 2 + Math.random() * 4, life: 0.45, kind: "glint", col: "#fff4d0", emit: true });
      }
    }
    if (this.debugMsg) { this.debugMsg.t += dt; if (this.debugMsg.t > 2) this.debugMsg = null; }
    // toast
    if (this.toast) { this.toast.t += dt; if (this.toast.t > 3) this.toast = null; }
    // vision mode: follows the sim's mode; the lock-on reticle sits on whatever E would act on
    const focus = this.screens.is("play") && this.target ? visionId(this.target) : null;
    for (const c of this.vision.update(dt, this.world, pl, gl, focus, this.visionArt())) this.onVisionCue(c);
    this.updateParticles(dt);
  }

  visionArtCache: VisionArt | null = null;
  visionArt(): VisionArt { return worldRendererV.visionArt(this); }

  /** Where the golem's eye is (world px), for the scanner's glint and the data stream home. */
  eyeSpot(): { x: number; y: number; w: number; show: boolean } | null {
    if (this.hideGolem) return null;
    const pl = this.pl, lk = this.look, f = pl.facing;
    const y = Math.round(pl.y - lk.z) - 18 + Math.round(lk.dormant * 4) + Math.round(lk.dormant * 3);
    const x = Math.round(pl.x) + (f === "right" ? 2 : f === "left" ? -4 : -2);
    return { x, y, w: f === "down" ? 4 : 2, show: f !== "up" };
  }

  onVisionCue(c: VisionCue) { return reactionsV.onVisionCue(this, c); }

  updateParticles(dt: number) { return particlesV.updateParticles(this, dt); }

  // ---------------------------------------------------------------- UiHost
  say(text: string) { this.note = { text, t: 0 }; }

  // ---------------------------------------------------------------- CutsceneHost (screens/intro.ts)
  letterbox(on: boolean) { this.bars.to = on ? 1 : 0; if (on) this.bars.v = 1; }
  startPlay() { this.screens.set(this.S.play); }
  renderScene() { this.renderWorldScene(); }

  /** Type the monologue and ease the letterbox (presentation clock, scenes and animating overlays). */
  stepMonologue(dt: number) {
    const s = this.monologue.update(dt);
    if (s.started) this.sfx.thoughtStart();
    for (let i = 0; i < s.typed; i++) this.sfx.thoughtTick(s.tone === "void");
    const b = this.bars;
    if (b.v !== b.to) b.v = b.to > b.v ? Math.min(b.to, b.v + dt * 4) : Math.max(b.to, b.v - dt * 2.2);
  }

  /** Cutscene letterbox bars (they slide away when the player gets control). */
  renderBars() {
    const b = this.bars.v;
    if (b <= 0) return;
    const e = b * b * (3 - 2 * b), h = Math.round(14 * e);
    this.ctx.fillStyle = "#000";
    this.ctx.fillRect(0, 0, W, h); this.ctx.fillRect(0, H - h, W, h);
  }
  /** Open an item's reading screen (pack E, UiHost.read). */
  read(id: ItemId) {
    const opens = ITEMS[id].opens;
    if (opens === "schematic") this.schemUi.open();
    else if (opens === "book") this.bookUi.open(id);
  }
  boostEye(level: number) { this.eyeBoost = level; }
  /** World presentation without simulation (overlays that keep the scene alive, e.g. dialogue). */
  animate(dt: number) { this.updateWorldFx(dt); }

  renderNote(y = H - 40) {
    if (!this.note) return;
    const ctx = this.ctx;
    ctx.globalAlpha = clamp(3 - this.note.t, 0, 1);
    drawTextS(ctx, this.note.text, W / 2, y, "#e8d8b0", 1, "center", "#000");
    ctx.globalAlpha = 1;
  }

  // ---------------------------------------------------------------- render
  // ---------------------------------------------------------------- Phase 0: frame loop, interpolation
  /**
   * One browser frame (App.tsx): the shell takes the mouse, then the sim runs as many fixed ticks as the real time
   * and game speed owe (sim/clock.ts). Screens other than play always run at 1x; a paused play screen still gets
   * input and presentation, but no sim.
   */
  frame(realDt: number) {
    const now = () => (typeof performance !== "undefined" ? performance.now() : Date.now());
    this.shell.update(realDt);
    this.shell.sample("frame", realDt * 1000);
    const play = this.screens.is("play");
    if (play && this.clock.speed === 0) {
      this.paused = true;
      try { this.update(realDt); } finally { this.paused = false; }
      this.shell.sample("ticks", 0);
    } else {
      const n = this.clock.advance(realDt, play ? this.clock.speed : 1);
      const t0 = now();
      for (let i = 0; i < n; i++) { this.snapshot(); this.update(TICK); }
      if (n) this.shell.sample("tick", (now() - t0) / n);
      this.shell.sample("ticks", n);
    }
    if (this.screens.is("play") && this.clock.speed !== 0) {
      this.autosaver.enabled = this.settings.autosave;
      this.autosaver.interval = this.settings.autosaveMinutes * 60;
      const why = this.autosaver.tick(realDt, this.pl.area);
      if (why) this.saveTo("auto", true);
    }
  }

  /** Remember where everything in view stood before a tick (only the play screen interpolates). */
  private snapshot() {
    if (!this.screens.is("play")) { this.interp = null; return; }
    const area = this.pl.area, pos = new Map<string, [number, number]>();
    for (const a of this.world.actors) if (a.area === area) pos.set(a.id, [a.x, a.y]);
    this.interp = { area, pos };
    this.cam.mark();
  }

  /** Draw with actors and camera `alpha` of the way between the last two ticks, then put the sim state back. */
  private withInterpolation(draw: () => void) {
    const ip = this.interp, alpha = this.clock.alpha;
    if (!ip || !this.settings.interpolate || alpha >= 1 || !this.screens.has("play") || ip.area !== this.pl.area) return draw();
    const saved: [Actor, number, number][] = [];
    for (const a of this.world.actors) {
      const p = ip.pos.get(a.id);
      if (!p || a.area !== ip.area) continue;
      const dx = a.x - p[0], dy = a.y - p[1];
      if (dx * dx + dy * dy > 32 * 32 || (!dx && !dy)) continue; // teleports and doorways snap
      saved.push([a, a.x, a.y]);
      a.x = p[0] + dx * alpha; a.y = p[1] + dy * alpha;
    }
    const cx = this.cam.x, cy = this.cam.y, c = this.cam.at(alpha);
    if (Math.abs(cx - this.cam.px) < 64 && Math.abs(cy - this.cam.py) < 64) { this.cam.x = c.x; this.cam.y = c.y; }
    try { draw(); } finally {
      for (const [a, x, y] of saved) { a.x = x; a.y = y; }
      this.cam.x = cx; this.cam.y = cy;
    }
  }

  /** Apply preferences now (audio, overlay palette, UI scale); `persist` writes them to the browser. */
  applySettings(s: Settings, persist: boolean) {
    this.settings = s;
    this.sfx.setVolume(s.master, s.ambience);
    setOverlayPalette(OVERLAY_PALETTES[s.palette]);
    this.uiRes = UI_RES[s.uiScale];
    if (this.hiCanvas) {
      const w = Math.round(W * this.uiRes), h = Math.round(H * this.uiRes);
      if (this.hiCanvas.width !== w || this.hiCanvas.height !== h) { this.hiCanvas.width = w; this.hiCanvas.height = h; }
    }
    if (persist) saveSettings(s, typeof localStorage !== "undefined" ? localStorage : null);
  }

  // ---------------------------------------------------------------- Phase 0: saves v2
  private initSaves() {
    const legacy = typeof localStorage !== "undefined" ? this.saves.importLegacy(localStorage).catch(() => false) : Promise.resolve(false);
    legacy.then((imported) => {
      if (imported) this.shell.feed.push("Your old save was moved to slot 1", "good");
      return this.saves.latest();
    }).then((m) => { this.hasSaves = !!m; }, () => {});
  }
  /** Write the world to a slot (async); `quiet` for autosaves (a notice, no note). */
  saveTo(slot: string, quiet = false) {
    const w = this.world;
    this.saves.save(slot, w, quiet ? `Autosave (${w.areas.get(player(w).area)?.base.portals ? player(w).area : player(w).area})` : undefined).then((m) => {
      this.hasSaves = true;
      this.shell.refreshSlots();
      this.shell.feed.push(`${slot === "auto" ? "Autosaved" : `Saved to ${slot}`} (${(m.bytes / 1024).toFixed(1)} KB)`, "good", { at: w.time });
      if (!quiet) { this.say("GAME SAVED"); this.sfx.tone(520, 0.1, "triangle", 0.05); }
      this.shell.tell(`Saved to ${slot}`);
    }, (e) => {
      this.shell.feed.push(`Could not save: ${(e as Error).message}`, "alert", { pause: false });
      if (!quiet) { this.say("COULD NOT SAVE"); this.sfx.tone(180, 0.1, "square", 0.04); }
    });
  }
  /** Load a slot (async), recovering from its backups if it is damaged. */
  loadFrom(slot: string) {
    this.saves.load(slot).then((r) => {
      this.resume(r.world);
      this.say("GAME LOADED");
      if (r.recovered) this.shell.feed.push(`${slot} was damaged: loaded its backup (${r.from})`, "alert", { pause: false });
    }, (e) => {
      this.shell.feed.push(`Could not load ${slot}: ${(e as Error).message}`, "alert", { pause: false });
      this.say("NO SAVED GAME"); this.sfx.tone(180, 0.1, "square", 0.04);
    });
  }
  exportSave() { try { downloadSave(this.world); this.shell.tell("Exported the current game"); } catch (e) { this.shell.tell(`Export failed: ${(e as Error).message}`, false); } }
  exportText() { return _exportText(this.world); }
  importSave() {
    pickSaveFile().then((text) => {
      if (text === null) return;
      try { const w = importText(text); this.shell.close(); this.resume(w); this.shell.feed.push("Imported a save file", "good"); }
      catch (e) { this.shell.tell(`Import failed: ${(e as Error).message}`, false); }
    });
  }

  // ---------------------------------------------------------------- Phase 0: generated areas
  generateArea(kind: string) {
    const spec = openGeneratedArea(this.world, this.pl, kind);
    if (!spec) return;
    this.drainEvents(); this.syncView(); this.doorFade = 1;
    this.shell.feed.push(`Opened ${spec.id} (${spec.w}x${spec.h}, seed ${spec.seed})`, "info", { at: this.world.time });
  }
  leaveGenerated() {
    if (leaveGeneratedArea(this.world, this.pl)) { this.drainEvents(); this.syncView(); this.doorFade = 1; }
  }

  /** Sim events worth a notification (view/reactions.ts calls this for each event it drains). */
  noticeEvent(e: SimEvent) {
    const w = this.world, feed = this.shell.feed, me = w.playerId;
    if (e.t === "jobChanged" && (e.status === "blocked" || e.status === "failed")) feed.push(`${actorById(w, e.actor)?.name ?? e.actor}: order ${e.status}${e.reason ? ` (${e.reason})` : ""}`, "alert", { at: w.time });
    else if (e.t === "packFull" && e.actor === me) feed.push("The pack is full", "alert", { at: w.time, pause: false });
    else if (e.t === "dayPhase") feed.push(`Day ${e.day + 1}: ${e.phase}`, "info", { at: w.time });
    else if (e.t === "powerChanged" && e.actor !== me) feed.push(`${actorById(w, e.actor)?.name ?? e.actor} ${e.powered ? "powered up" : "lost power"}`, e.powered ? "good" : "alert", { at: w.time });
    else if (e.t === "travelled" && e.actor !== me) feed.push(`${actorById(w, e.actor)?.name ?? e.actor} travelled to ${e.to}`, "info", { at: w.time });
    else if (e.t === "learned") feed.push(`Learned: ${e.flag}`, "good", { at: w.time });
  }

  render() {
    this.ctx.clearRect(0, 0, W, H);
    this.withInterpolation(() => {
      this.screens.render();
      if (this.hctx && this.hiCanvas) this.shell.render(this.hctx, this.hiCanvas.width, this.hiCanvas.height);
    });
  }

  renderWorldScene() {
    this.view.flush();
    this.renderWorld();
    this.renderHud();
  }

  renderWorld() { return worldRendererV.renderWorld(this); }

  drawSurfaceRune(p: PropInst, camX: number, camY: number) { return worldRendererV.drawSurfaceRune(this, p, camX, camY); }

  /** The summoning beam: a shimmering column of light rising from the dais (emissive only). */
  drawSummonColumn(x: number, y: number, k: number) {
    const ec = this.emit.ctx;
    x = Math.round(x); y = Math.round(y);
    const w = Math.round(3 + 7 * k);
    ec.globalCompositeOperation = "lighter";
    for (let yy = y + 4; yy > -2; yy -= 2) {
      const f = 1 - ((y - yy) / Math.max(1, y + 2)) * 0.6;
      const wob = Math.round(Math.sin(yy * 0.21 + this.t * 9) * k);
      ec.globalAlpha = clamp(k * f * 0.5, 0, 1); ec.fillStyle = "#9a70ff"; ec.fillRect(x - w + wob, yy - 2, w * 2, 2);
      ec.globalAlpha = clamp(k * f, 0, 1); ec.fillStyle = "#e8e0ff"; ec.fillRect(x - 1 + wob, yy - 2, 2 + Math.round(k * 2), 2);
    }
    ec.globalAlpha = clamp(k * 0.6, 0, 1); ec.fillStyle = "#c0a0ff"; ec.fillRect(x - 14, y - 3, 28, 8);
    ec.globalAlpha = 1;
    ec.globalCompositeOperation = "source-over";
  }

  drawDimmed(s: Sprite, p: PropInst, lvl: number, whole: boolean, camX: number, camY: number) { return worldRendererV.drawDimmed(this, s, p, lvl, whole, camX, camY); }

  drawSwaying(s: Sprite, p: PropInst, camX: number, camY: number) { return worldRendererV.drawSwaying(this, s, p, camX, camY); }

  drawFlame(p: PropInst, big: boolean, camX: number, camY: number) { return worldRendererV.drawFlame(this, p, big, camX, camY); }

  drawPedestal(p: PropInst, i: number, spr: (s: Sprite, x: number, y: number) => void, camX: number, camY: number) { return worldRendererV.drawPedestal(this, p, i, spr, camX, camY); }

  drawPlayer(camX: number, camY: number) { return worldRendererV.drawPlayer(this, camX, camY); }
  /** The pose the golem was last drawn in (world px): vision mode outlines it so it never gets lost under highlights. */
  selfPose: { pose: GolemPose; x: number; y: number } | null = null;

  npcLook(a: Actor): NpcLook { return worldRendererV.npcLook(this, a); }

  updateNpcLooks(dt: number) { return worldRendererV.updateNpcLooks(this, dt); }

  updateWorkerLook(a: Actor, dt: number) { return worldRendererV.updateWorkerLook(this, a, dt); }

  updateFolkLook(a: Actor) { return worldRendererV.updateFolkLook(this, a); }

  renderFolkBubbles(dt: number) { return worldRendererV.renderFolkBubbles(this, dt); }

  workerCue(a: Actor, cue: AnimCue) { return reactionsV.workerCue(this, a, cue); }

  runeBlip(x: number, y: number, k = 1) { return reactionsV.runeBlip(this, x, y, k); }
  runeBurst(x: number, y: number) { return reactionsV.runeBurst(this, x, y); }
  runeRefused(x: number, y: number) { return reactionsV.runeRefused(this, x, y); }

  workerWalked(e: Extract<SimEvent, { t: "portal" }>) { return reactionsV.workerWalked(this, e); }

  workerTravelled(e: Extract<SimEvent, { t: "travelled" }>) { return reactionsV.workerTravelled(this, e); }

  coreSparks(a: Actor, n: number, bright: boolean) { return reactionsV.coreSparks(this, a, n, bright); }

  npcSparks(a: Actor, n: number) { return reactionsV.npcSparks(this, a, n); }
  npcDust(a: Actor) { return reactionsV.npcDust(this, a); }

  renderHud() { return worldRendererV.renderHud(this); }

  renderClock() { return worldRendererV.renderClock(this); }

  renderToast(y: number) { return worldRendererV.renderToast(this, y); }
}


/** The vision target id of an interaction target (sim/analysis.ts: visionTargets ids). */
function visionId(t: Target): string | null {
  return t.propId ?? t.looseId ?? t.actorId ?? (t.tx !== undefined && t.ty !== undefined ? `tile:${t.tx},${t.ty}` : null);
}
