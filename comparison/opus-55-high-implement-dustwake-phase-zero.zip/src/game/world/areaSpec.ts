// Dynamic areas (Phase 0.3). No DOM.
//
// Authored areas stay in the static AREAS table (world/areas.ts). Areas made at runtime (floors, caves, outposts,
// generated wilds) are described by a small saved `AreaSpec`; its `kind` picks a builder from AREA_KINDS, and the
// spec's parameters (seed, size, depth) make that builder deterministic, so the save can keep a *diff* against it
// exactly as for authored areas. Kinds marked `fullGrid` (player-built places, where nearly every tile is an edit)
// save a run-length-encoded full grid instead (world/save.ts).
import type { AreaData, Portal, PropDef } from "../map";
import { FS, T, TS } from "../content/tiles";
import { mulberry, type Rng } from "../core/rng";
import { AREAS } from "./areas";

export interface AreaSpec {
  id: string;
  kind: string;
  seed: number;
  w: number;
  h: number;
  /** The area this one was opened from; its exit leads back there. */
  parent: string;
  /** Floors below the parent (0 = same level). */
  depth: number;
  /** Where the exit comes out in the parent (px). */
  entry?: { x: number; y: number };
  /** A name to show on arrival. */
  label?: string;
}

export interface AreaKind {
  build(spec: AreaSpec): AreaData;
  /** Saves keep the whole grid (RLE) rather than a diff: nearly every tile is the player's. */
  fullGrid?: boolean;
  /** Size limits a spec is clamped to. */
  min: [number, number]; max: [number, number];
}

/** The portal id that sends someone to coordinates in an area (`@x,y`): used by exits back to a parent. */
export const coordPortalId = (x: number, y: number) => `@${Math.round(x)},${Math.round(y)}`;
export function coordPortal(id: string): Portal | undefined {
  const m = /^@(-?\d+),(-?\d+)$/.exec(id);
  if (!m) return undefined;
  const x = +m[1], y = +m[2];
  return { id, x: x - 8, y: y - 8, w: 16, h: 16, dir: "up", to: { area: "", portal: "" }, arrive: { x, y } };
}

// ---------------------------------------------------------------- shared helpers
interface Grid { w: number; h: number; grid: Uint8Array; style: Uint8Array }
const blank = (w: number, h: number, fill: number, style: number): Grid => ({ w, h, grid: new Uint8Array(w * h).fill(fill), style: new Uint8Array(w * h).fill(style) });
const carve = (g: Grid, x0: number, y0: number, x1: number, y1: number, t = T.FLOOR) => {
  for (let y = Math.max(1, y0); y <= Math.min(g.h - 2, y1); y++) for (let x = Math.max(1, x0); x <= Math.min(g.w - 2, x1); x++) g.grid[y * g.w + x] = t;
};
const ri = (r: Rng, a: number, b: number) => a + Math.floor(r() * (b - a + 1));

function finish(spec: AreaSpec, g: Grid, rooms: AreaData["rooms"], start: { tx: number; ty: number }, extra: Partial<AreaData>, props: PropDef[]): AreaData {
  // the way back: a notch in the wall above the start, a portal into it, coming out at the parent's entry
  const nx = start.tx, ny = Math.max(1, start.ty - 2);
  g.grid[ny * g.w + nx] = T.FLOOR; g.grid[(ny + 1) * g.w + nx] = T.FLOOR;
  const entry = spec.entry ?? { x: 0, y: 0 };
  const exit: Portal = {
    id: "exit", x: nx * TS, y: ny * TS, w: TS, h: TS, dir: "up",
    to: { area: spec.parent, portal: coordPortalId(entry.x, entry.y) },
    arrive: { x: nx * TS + 8, y: (ny + 2) * TS + 11 }, label: spec.label,
  };
  return {
    id: spec.id, w: g.w, h: g.h, grid: g.grid, plan: g.grid.slice(), style: g.style, tvar: new Uint8Array(g.w * g.h),
    rooms, props, decals: [], lights: [], loose: [], drips: [], exits: [], portals: [exit],
    start: { x: start.tx * TS + 8, y: start.ty * TS + 11 }, ...extra,
  };
}

// ---------------------------------------------------------------- kinds
/** A generated dungeon floor: rooms joined by corridors, candles in the larger rooms, clutter along the walls. */
function buildFloor(spec: AreaSpec): AreaData {
  const r = mulberry(spec.seed ^ 0x9e3779b9), g = blank(spec.w, spec.h, T.WALL, FS.FLAG);
  const rooms: AreaData["rooms"] = [], props: PropDef[] = [];
  const want = Math.max(3, Math.floor((spec.w * spec.h) / 140));
  for (let tries = 0; tries < want * 12 && rooms.length < want; tries++) {
    const w = ri(r, 4, 9), h = ri(r, 3, 6), x = ri(r, 2, spec.w - w - 3), y = ri(r, 3, spec.h - h - 2);
    if (rooms.some((o) => x <= o.x + o.w + 1 && x + w + 1 >= o.x && y <= o.y + o.h + 1 && y + h + 1 >= o.y)) continue;
    rooms.push({ num: rooms.length + 1, name: `Room ${rooms.length + 1}`, x, y, w, h });
    carve(g, x, y, x + w - 1, y + h - 1);
  }
  // corridors between consecutive rooms (sorted left to right so the floor reads as one path with side rooms)
  const order = [...rooms].sort((a, b) => a.x - b.x);
  for (let i = 1; i < order.length; i++) {
    const a = order[i - 1], b = order[i];
    const ax = a.x + (a.w >> 1), ay = a.y + (a.h >> 1), bx = b.x + (b.w >> 1), by = b.y + (b.h >> 1);
    if (r() < 0.5) { carve(g, Math.min(ax, bx), ay, Math.max(ax, bx), ay); carve(g, bx, Math.min(ay, by), bx, Math.max(ay, by)); }
    else { carve(g, ax, Math.min(ay, by), ax, Math.max(ay, by)); carve(g, Math.min(ax, bx), by, Math.max(ax, bx), by); }
  }
  for (const room of rooms) {
    if (room.w * room.h >= 20) props.push({ id: `candle.${room.num}`, kind: "candlestand", x: (room.x + 1) * TS + 8, y: (room.y + 1) * TS + 12, v: 0 });
    if (r() < 0.6) props.push({ id: `barrel.${room.num}`, kind: r() < 0.5 ? "barrel" : "crate", x: (room.x + room.w - 1) * TS + 8, y: (room.y + room.h - 1) * TS + 12, v: 0 });
  }
  const first = order[0] ?? { x: 2, y: 3, w: 3, h: 3 };
  return finish(spec, g, rooms, { tx: first.x + (first.w >> 1), ty: first.y + 1 }, { ambient: [0.06, 0.055, 0.075] }, props);
}

/** A natural cave: cellular automaton smoothing over seeded noise, the largest open pocket kept. */
function buildCave(spec: AreaSpec): AreaData {
  const r = mulberry(spec.seed ^ 0x51ed27), g = blank(spec.w, spec.h, T.WALL, FS.EARTH);
  let cells = new Uint8Array(spec.w * spec.h).map(() => (r() < 0.44 ? 1 : 0));
  for (let pass = 0; pass < 4; pass++) {
    const next = new Uint8Array(cells.length);
    for (let y = 0; y < spec.h; y++) for (let x = 0; x < spec.w; x++) {
      let n = 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const xx = x + dx, yy = y + dy; n += xx < 0 || yy < 0 || xx >= spec.w || yy >= spec.h ? 1 : cells[yy * spec.w + xx]; }
      next[y * spec.w + x] = n >= 5 ? 1 : 0;
    }
    cells = next;
  }
  // keep the biggest connected pocket (flood fill)
  const seen = new Int32Array(cells.length).fill(-1);
  let best = -1, bestN = 0;
  for (let i = 0; i < cells.length; i++) {
    if (cells[i] || seen[i] >= 0) continue;
    const stack = [i]; let n = 0; seen[i] = i;
    while (stack.length) {
      const j = stack.pop()!; n++;
      const x = j % spec.w, y = (j / spec.w) | 0;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const xx = x + dx, yy = y + dy, k = yy * spec.w + xx;
        if (xx > 0 && yy > 0 && xx < spec.w - 1 && yy < spec.h - 1 && !cells[k] && seen[k] < 0) { seen[k] = i; stack.push(k); }
      }
    }
    if (n > bestN) { bestN = n; best = i; }
  }
  let start = { tx: spec.w >> 1, ty: spec.h >> 1 };
  for (let i = 0; i < cells.length; i++) if (best >= 0 && seen[i] === best) {
    const x = i % spec.w, y = (i / spec.w) | 0;
    if (x > 0 && y > 2 && x < spec.w - 1 && y < spec.h - 1) { g.grid[i] = T.FLOOR; g.style[i] = r() < 0.2 ? FS.MOSS : FS.EARTH; }
  }
  // the start: the first open tile with open ground under it, scanning from the top
  outer: for (let y = 3; y < spec.h - 2; y++) for (let x = 2; x < spec.w - 2; x++) if (g.grid[y * spec.w + x] === T.FLOOR && g.grid[(y + 1) * spec.w + x] === T.FLOOR) { start = { tx: x, ty: y }; break outer; }
  carve(g, start.tx - 1, start.ty, start.tx + 1, start.ty + 1);
  const props: PropDef[] = [];
  for (let k = 0; k < 6; k++) {
    const x = ri(r, 2, spec.w - 3), y = ri(r, 3, spec.h - 3);
    if (g.grid[y * spec.w + x] === T.FLOOR && Math.abs(x - start.tx) + Math.abs(y - start.ty) > 4) props.push({ id: `rock.${k}`, kind: "rock", x: x * TS + 8, y: y * TS + 14, v: k % 3 });
  }
  return finish(spec, g, [{ num: 1, name: "Cave", x: 1, y: 1, w: spec.w - 2, h: spec.h - 2 }], start, { ambient: [0.05, 0.05, 0.06] }, props);
}

/** An empty walled yard for building on: open ground, every later tile is the player's (saved as a full grid). */
function buildYard(spec: AreaSpec): AreaData {
  const g = blank(spec.w, spec.h, T.WALL, FS.DIRT);
  carve(g, 1, 3, spec.w - 2, spec.h - 2);
  return finish(spec, g, [{ num: 1, name: "Yard", x: 1, y: 3, w: spec.w - 2, h: spec.h - 4 }], { tx: spec.w >> 1, ty: 4 }, { outdoor: true, ambient: [0.42, 0.4, 0.46] }, []);
}

export const AREA_KINDS: Record<string, AreaKind> = {
  floor: { build: buildFloor, min: [24, 16], max: [160, 120] },
  cave: { build: buildCave, min: [24, 16], max: [160, 120] },
  yard: { build: buildYard, fullGrid: true, min: [12, 10], max: [128, 96] },
};

/** Clamp a spec to its kind's limits; throws on an unknown kind. */
export function normalizeSpec(spec: AreaSpec): AreaSpec {
  const k = AREA_KINDS[spec.kind];
  if (!k) throw new Error(`unknown area kind "${spec.kind}"`);
  const clampI = (v: number, a: number, b: number) => Math.max(a, Math.min(b, Math.round(v)));
  return { ...spec, w: clampI(spec.w, k.min[0], k.max[0]), h: clampI(spec.h, k.min[1], k.max[1]), seed: spec.seed >>> 0, depth: Math.max(0, spec.depth | 0) };
}

/** The builder for area `id`: an authored one from AREAS, else one made from its saved spec. */
export function builderFor(id: string, specs: Record<string, AreaSpec> | undefined): (() => AreaData) | undefined {
  const authored = AREAS[id];
  if (authored) return authored;
  const spec = specs?.[id];
  if (!spec) return undefined;
  const kind = AREA_KINDS[spec.kind];
  return kind ? () => kind.build(spec) : undefined;
}

export const isFullGrid = (id: string, specs: Record<string, AreaSpec> | undefined) => !AREAS[id] && !!specs?.[id] && !!AREA_KINDS[specs[id].kind]?.fullGrid;

/** Next free id for a generated area under `parent` (`parent~floor1`, `parent~floor2`, ...). */
export function nextSpecId(specs: Record<string, AreaSpec> | undefined, parent: string, kind: string) {
  for (let i = 1; ; i++) { const id = `${parent}~${kind}${i}`; if (!specs?.[id] && !AREAS[id]) return id; }
}
