// Save system v2 (Phase 0.4). No DOM: storage is an injected async key-value store (IndexedDB in the browser,
// view/persistence.ts; memory in tests).
//
//   slots        three manual slots plus "auto"; each has a meta record (shown by the saves screen) and its data
//   checksums    data is stored as `<fnv1a>:<json>`; a mismatch, bad JSON or a failed migration is corruption
//   backups      every write first rolls the previous data down (`auto` keeps AUTO_BACKUPS generations, manual
//                slots one `.bak`), so a bad write or a corrupt record falls back to the generation before
//   recovery     load tries the slot, then its backups in order; the corrupt record is kept as `corrupt:<slot>`
//   export       a self-describing JSON file that import validates by loading it (migrations run as for slots)
//   legacy       the single localStorage slot of v1 (`dustwake.save`) is imported into slot 1 once
import { deserialize, serialize, settle, migrate, SAVE_VERSION, type SaveData, type SaveStorage } from "./save";
import { player, type World } from "./world";

export interface KvStore {
  get(key: string): Promise<string | undefined>;
  set(key: string, value: string): Promise<void>;
  del(key: string): Promise<void>;
  keys(): Promise<string[]>;
}

/** In-memory store (tests, and the browser's fallback when IndexedDB is unavailable). */
export class MemoryKv implements KvStore {
  map = new Map<string, string>();
  async get(k: string) { return this.map.get(k); }
  async set(k: string, v: string) { this.map.set(k, v); }
  async del(k: string) { this.map.delete(k); }
  async keys() { return [...this.map.keys()]; }
}

export const MANUAL_SLOTS = ["slot1", "slot2", "slot3"] as const;
export const AUTO_SLOT = "auto";
export const AUTO_BACKUPS = 3;
export const LEGACY_KEY = "dustwake.save";
/** Budgets the tests hold saves to (docs/world/saves.md). */
export const SAVE_BUDGET = { bytes: 512 * 1024, loadMs: 400 };

export interface SlotMeta {
  slot: string;
  /** Wall-clock ms of the write. */
  savedAt: number;
  version: number;
  day: number;
  area: string;
  playTime: number;
  bytes: number;
  label?: string;
}

export interface LoadResult { world: World; slot: string; from: string; recovered: boolean; error?: string }

export function fnv1a(s: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return (h >>> 0).toString(16).padStart(8, "0");
}
export const pack = (json: string) => `${fnv1a(json)}:${json}`;
export function unpack(raw: string): unknown {
  const i = raw.indexOf(":");
  if (i !== 8) throw new Error("save record has no checksum");
  const sum = raw.slice(0, 8), json = raw.slice(9);
  if (fnv1a(json) !== sum) throw new Error("save checksum mismatch (corrupted)");
  return JSON.parse(json);
}

const dataKey = (slot: string) => `save:${slot}`;
const metaKey = (slot: string) => `meta:${slot}`;
const backupsOf = (slot: string) => (slot === AUTO_SLOT ? Array.from({ length: AUTO_BACKUPS }, (_, i) => `${slot}.${i + 1}`) : [`${slot}.bak`]);

export function metaOf(slot: string, w: World, bytes: number, savedAt: number, label?: string): SlotMeta {
  return { slot, savedAt, version: SAVE_VERSION, day: w.day, area: player(w)?.area ?? "?", playTime: w.playTime, bytes, ...(label ? { label } : {}) };
}

export class SaveManager {
  constructor(public kv: KvStore, public now: () => number = () => Date.now()) {}

  /** Write `w` to `slot`, rolling the previous generations down first. */
  async save(slot: string, w: World, label?: string): Promise<SlotMeta> {
    const json = JSON.stringify(serialize(w));
    const backs = backupsOf(slot);
    for (let i = backs.length - 1; i >= 0; i--) {
      const from = i === 0 ? slot : backs[i - 1];
      const d = await this.kv.get(dataKey(from)), m = await this.kv.get(metaKey(from));
      if (d !== undefined) { await this.kv.set(dataKey(backs[i]), d); if (m) await this.kv.set(metaKey(backs[i]), m.replace(`"slot":"${from}"`, `"slot":"${backs[i]}"`)); }
    }
    const meta = metaOf(slot, w, json.length, this.now(), label);
    await this.kv.set(dataKey(slot), pack(json));
    await this.kv.set(metaKey(slot), JSON.stringify(meta));
    return meta;
  }

  /** Load `slot`; on corruption fall back through its backups. Throws only if nothing usable is left. */
  async load(slot: string): Promise<LoadResult> {
    let firstError: string | undefined;
    for (const from of [slot, ...backupsOf(slot)]) {
      const raw = await this.kv.get(dataKey(from));
      if (raw === undefined) continue;
      try {
        const world = settle(deserialize(unpack(raw)));
        if (from !== slot) {
          // keep the bad record for a bug report, and put the good generation back in the slot
          const bad = await this.kv.get(dataKey(slot));
          if (bad !== undefined) await this.kv.set(`corrupt:${slot}`, bad);
          await this.kv.set(dataKey(slot), raw);
          const m = await this.kv.get(metaKey(from));
          if (m) await this.kv.set(metaKey(slot), m.replace(`"slot":"${from}"`, `"slot":"${slot}"`));
        }
        return { world, slot, from, recovered: from !== slot, error: firstError };
      } catch (e) {
        firstError ??= `${from}: ${(e as Error).message}`;
      }
    }
    throw new Error(firstError ?? `no save in ${slot}`);
  }

  async has(slot: string) { return (await this.kv.get(dataKey(slot))) !== undefined; }
  async meta(slot: string): Promise<SlotMeta | null> { const m = await this.kv.get(metaKey(slot)); return m ? JSON.parse(m) : null; }
  /** Every primary slot's meta (manual slots, then auto), nulls for empty ones. */
  async list(): Promise<(SlotMeta | null)[]> { return Promise.all([...MANUAL_SLOTS, AUTO_SLOT].map((s) => this.meta(s))); }
  async remove(slot: string) {
    for (const s of [slot, ...backupsOf(slot)]) { await this.kv.del(dataKey(s)); await this.kv.del(metaKey(s)); }
  }

  /** The newest slot that holds a save (for "continue"). */
  async latest(): Promise<SlotMeta | null> {
    const all = (await this.list()).filter(Boolean) as SlotMeta[];
    return all.sort((a, b) => b.savedAt - a.savedAt)[0] ?? null;
  }

  /** Import the v1 single localStorage slot into slot 1, once (only if slot 1 is empty). True if it did. */
  async importLegacy(storage: SaveStorage): Promise<boolean> {
    const raw = storage.getItem(LEGACY_KEY);
    if (!raw || (await this.has("slot1"))) return false;
    const w = settle(deserialize(JSON.parse(raw)));
    await this.save("slot1", w, "Imported from v1");
    return true;
  }
}

// ---------------------------------------------------------------- export / import
export const EXPORT_FORMAT = "dustwake-save";
export function exportText(w: World, now = Date.now()): string {
  return JSON.stringify({ format: EXPORT_FORMAT, exportedAt: now, version: SAVE_VERSION, save: serialize(w) });
}
/** Parse an exported file (or a bare save) into a World. Throws with a readable message if it is not one. */
export function importText(text: string): World {
  let o: unknown;
  try { o = JSON.parse(text); } catch { throw new Error("not a save file (bad JSON)"); }
  const rec = o as { format?: string; save?: SaveData };
  const save = rec?.format === EXPORT_FORMAT ? rec.save : o;
  migrate(save); // throws "not a Dustwake save" / "newer than supported"
  return settle(deserialize(save));
}

// ---------------------------------------------------------------- autosave
/** When to autosave: every `interval` real seconds of play, and on entering another area (at most every `minGap`). */
export class Autosaver {
  timer = 0;
  sinceLast = 1e9;
  lastArea: string | null = null;
  enabled = true;
  constructor(public interval = 180, public minGap = 20) {}
  /** Advance by real seconds of play; returns the reason to save now, or null. */
  tick(realDt: number, area: string): "timer" | "area" | null {
    this.timer += realDt; this.sinceLast += realDt;
    const moved = this.lastArea !== null && area !== this.lastArea;
    this.lastArea = area;
    if (!this.enabled) return null;
    if (moved && this.sinceLast >= this.minGap) return this.mark("area");
    if (this.timer >= this.interval) return this.mark("timer");
    return null;
  }
  private mark(r: "timer" | "area") { this.timer = 0; this.sinceLast = 0; return r; }
  reset(area: string | null = null) { this.timer = 0; this.sinceLast = 1e9; this.lastArea = area; }
}
