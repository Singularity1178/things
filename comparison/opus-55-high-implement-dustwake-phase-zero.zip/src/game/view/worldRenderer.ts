// The world renderer (split from game.ts): draws the lit scene of the current area onto the world layer, the
// golem, NPC presentation state, folk speech, and the HUD of the base-size UI layer.
import { TS, T } from "../content/tiles";
import { ITEMS, isGlyph, glyphItem } from "../content/items";

import { runeMarks } from "../sim/gear";







import { propLook } from "../content/digging";











import { drawMonologue } from "../ui/monologue";


import { propDef } from "../content/props";

import { GLYPHS } from "../content/glyphs";
import { FLAGS } from "../content/flags";
import { propSprite } from "../art/props";

import { rubbleSprite, pillarSprite, doorSprite, barsSprite } from "../art/tiles";
import { itemIcon, glyphPattern } from "../art/items";
import { Pen, Sprite, hash2, clamp, lerp } from "../util";
import { drawGolem, GolemPose, slamPose } from "../golem";

import { Light, makeLight, computeVis } from "../light";

import { CR } from "../circle";





import { drawText, drawTextS } from "../font";
import { hasFlag } from "../world/world";
import type { PropInst } from "../world/area";





import { npcDef } from "../content/npcs";
import { actorDef } from "../content/actors";
import { drawActor, actorActive } from "./actors";
import { powered } from "../sim/actorStats";
import { initWorkerAnim, stepWorkerAnim, drainCues } from "../workerAnim";

import { type VisionArt } from "./vision";

import { isAwake } from "../sim/dialogue";

import type { Actor } from "../world/world";
import { archetypeOf, folkPresent } from "../sim/folk";
import { keeperPresent, shopOfArea, shopOpen } from "../sim/shops";
import { drawClosedSign } from "../keeperArt";
import { folkLantern } from "./actors";
import { drawChatIcon, drawSpeech } from "../folkArt";

import { hash01 } from "../content/daycycle";
import { ambientAt, lampGain, sunLevel, clockText, phaseAt } from "../content/daycycle";
import { worldHour, exposureOf } from "../sim/daytime";
import { Game, W, H, BURIED_AMBIENT, type NpcLook } from "../game";

export function renderWorld(g: Game) {
  const sc = g.scene.ctx, ec = g.emit.ctx, area = g.area;
  let sx = 0, sy = 0;
  if (g.shakeT > 0) { sx = (Math.random() - 0.5) * g.shakeMag * 2; sy = (Math.random() - 0.5) * g.shakeMag * 2; }
  const camX = Math.round(g.cam.x + sx), camY = Math.round(g.cam.y + sy);
  const W = g.vw, H = g.vh; // the world layer is view-sized (zoom)
  const hour = worldHour(g.world);
  sc.fillStyle = "#000"; sc.fillRect(0, 0, W, H);
  ec.fillStyle = "#000"; ec.fillRect(0, 0, W, H);
  g.view.prepare(camX, camY, W, H);
  g.view.idle();
  sc.drawImage(g.view.bg.c, camX, camY, W, H, 0, 0, W, H);
  const spr = (s: Sprite, x: number, y: number) => {
    const dx = Math.round(x - s.ax - camX), dy = Math.round(y - s.ay - camY);
    if (dx > W || dy > H || dx + s.w < 0 || dy + s.h < 0) return;
    sc.drawImage(s.a, dx, dy);
    ec.drawImage(s.e, dx, dy);
  };
  // ---- a room's doorway: the threshold is painted with the night beyond it; by day the daylight stands there instead
  const daylight = sunLevel(hour);
  if (area.base.interior && daylight > 0) for (const pt of area.base.portals ?? []) {
    if (!pt.door || pt.dir !== "down") continue;
    const x = pt.x - 1 - camX, y = pt.y + 4 - camY, ww = pt.w + 2;
    sc.globalAlpha = daylight; sc.fillStyle = "#cfc49c"; sc.fillRect(x, y, ww, 6); sc.fillStyle = "#f0e8c8"; sc.fillRect(x + 1, y + 2, ww - 2, 3); sc.globalAlpha = 1;
    ec.globalAlpha = daylight * 0.45; ec.fillStyle = "#a89868"; ec.fillRect(x, y, ww, 6); ec.globalAlpha = 1;
  }
  // ---- rune circle (floor layer)
  const r = area.ritual;
  if (r) {
    const c = area.ritualPos;
    const schemRead = hasFlag(g.world, FLAGS.knowSchematic);
    const ccx = c.x - CR - camX, ccy = c.y - CR - camY;
    if (ccx > -140 && ccx < W + 10 && ccy > -140 && ccy < H + 10) {
      sc.drawImage(g.circle.base, ccx, ccy);
      sc.drawImage(r.carved ? g.circle.gapCarved : g.circle.chalk, ccx, ccy);
      let lvl = r.active ? 0.55 + 0.35 * Math.sin(g.t * 3) + Math.min(0.3, r.actT * 0.1) : 0.16 + 0.06 * Math.sin(g.t * 1.3);
      if (g.fizzT > 0) lvl = Math.random() * 0.8;
      ec.globalAlpha = clamp(lvl, 0, 1);
      ec.drawImage(g.circle.glow, ccx, ccy);
      if (r.carved) ec.drawImage(g.circle.glowGap, ccx, ccy);
      if (!r.carved && schemRead) { ec.globalAlpha = 0.45 + 0.3 * Math.sin(g.t * 4); ec.drawImage(g.circle.ghost, ccx, ccy); }
      if (r.active) {
        ec.globalCompositeOperation = "lighter";
        ec.globalAlpha = 0.35 + 0.25 * Math.sin(g.t * 5);
        ec.drawImage(g.circle.glow, ccx, ccy);
        ec.drawImage(g.circle.glowGap, ccx, ccy);
        ec.globalCompositeOperation = "source-over";
      }
      ec.globalAlpha = 1;
    }
  }
  // ---- rune circles that are props (surface)
  for (const p of area.props) if (p.kind === "runecircle") g.drawSurfaceRune(p, camX, camY);
  // ---- sortables
  type D = { y: number; f: () => void };
  const list: D[] = [];
  const vx0 = camX - 48, vx1 = camX + W + 48, vy0 = camY - 16, vy1 = camY + H + 60;
  for (const p of area.props) {
    if (p.x < vx0 || p.x > vx1 || p.y < vy0 || p.y > vy1) continue;
    if (p.kind === "pedestal") {
      const i = Number(p.id.slice(3));
      list.push({ y: p.y, f: () => g.drawPedestal(p, i, spr, camX, camY) });
      continue;
    }
    const def = propDef(p.kind);
    // Where people keep the lights, a lamp is as lit as the hour says (content/daycycle.ts): a doused torch shows
    // its unlit art, a rune or a lantern stops glowing, and a dark window is just the painted window under it.
    const lvl = def.habit ? g.tendedLevel(p, hour) : 1;
    const alt = def.alt === "lit" ? !!p.lit && lvl > 0.05 : def.alt === "taken" ? p.taken : p.open;
    const s = propSprite(p.kind, propLook(p), alt);
    if (!s) continue;
    if (lvl <= 0.01 && def.habit === "window") continue;
    list.push({
      y: def.wallMounted ? p.y - 0.5 : def.flat ? p.y - 16 : p.y,
      f: () => {
        if (lvl < 1 && def.alt !== "lit") g.drawDimmed(s, p, lvl, def.habit === "window", camX, camY);
        else if (def.sway && !alt) g.drawSwaying(s, p, camX, camY); else spr(s, p.x, p.y);
        if (p.lit && def.fire && lvl > 0.05) g.drawFlame(p, def.fire.big, camX, camY);
        if (p.item && !p.container && !p.taken && ITEMS[p.item].showOnProp !== false) {
          const ic = itemIcon(p.item);
          const bob = isGlyph(p.item) ? Math.round(Math.sin(g.t * 2) * 0.6) : 0;
          spr(ic, p.x + (def.itemDx ?? 0), p.y - (p.itemZ ?? 8) + bob);
        }
      },
    });
  }
  for (const l of area.loose) {
    if (l.taken || l.x < vx0 || l.x > vx1 || l.y < vy0 || l.y > vy1) continue;
    list.push({ y: l.y, f: () => spr(itemIcon(l.item), l.x, l.y + 2) });
  }
  const AW = area.w;
  const tx0 = Math.max(0, Math.floor(camX / TS) - 1), tx1 = Math.min(AW - 1, Math.floor((camX + W) / TS) + 1);
  const ty0 = Math.max(0, Math.floor(camY / TS) - 1), ty1 = Math.min(area.h - 1, Math.floor((camY + H) / TS) + 3);
  for (let ty = ty0; ty <= ty1; ty++)
    for (let tx = tx0; tx <= tx1; tx++) {
      const t = area.grid[ty * AW + tx];
      const x = tx * TS + 8, y = ty * TS + 16;
      if (t === T.RUBBLE) { const s = rubbleSprite(Math.floor(hash2(tx, ty, 5) * 3), false); list.push({ y, f: () => spr(s, x, y) }); }
      else if (t === T.CRACKED) {
        const s = rubbleSprite(0, true);
        // a slam that didn't break it: the debris jolts side to side as the shudder dies away
        const sh = g.shudder, jx = sh && sh.tx === tx && ty >= sh.ty && ty <= sh.ty + 2 ? Math.round(Math.sin(g.t * 80) * 2 * Math.min(1, sh.t / 0.3)) : 0;
        list.push({ y, f: () => { spr(s, x + jx, y); if (g.crackFlash > 0) { ec.globalAlpha = g.crackFlash; ec.drawImage(s.e, Math.round(x + jx - s.ax - camX), Math.round(y - s.ay - camY)); ec.globalAlpha = 1; } } });
      }
      else if (t === T.PILLAR) { const s = pillarSprite(area.tvar[ty * AW + tx] === 1); list.push({ y, f: () => spr(s, x, y) }); }
      else if (t === T.LOCKED) { const s = doorSprite(); list.push({ y, f: () => spr(s, x, y) }); }
      else if (t === T.BARS) { const s = barsSprite(); list.push({ y, f: () => spr(s, x, y) }); }
    }
  // NPCs (one generic path: art looked up by NpcDef id)
  for (const a of g.world.actors) {
    if (a.id === g.world.playerId || a.area !== area.id || a.x < vx0 || a.x > vx1 || a.y < vy0 || a.y > vy1) continue;
    list.push({ y: a.y, f: () => drawActor(sc, ec, g.world, a, camX, camY, g.t, g.npcLook(a)) });
  }
  // player
  const pl = g.pl;
  if (!g.hideGolem) list.push({ y: pl.y, f: () => g.drawPlayer(camX, camY) });
  // world particles
  for (const p of g.particles) {
    if (p.kind === "debris" || p.kind === "dust" || p.kind === "smoke" || p.kind === "splash") {
      list.push({ y: p.y, f: () => { sc.fillStyle = p.col; const s = p.size; sc.fillRect(Math.round(p.x - camX), Math.round(p.y - p.z - camY), s, s); if (p.emit === false) { ec.fillStyle = "#000"; ec.fillRect(Math.round(p.x - camX), Math.round(p.y - p.z - camY), s, s); } } });
    }
  }
  list.sort((a, b) => a.y - b.y);
  for (const d of list) d.f();
  // moonbeam
  const moon = g.view.byId("moon");
  if (moon) {
    // moonlight through the broken roof by night, the same shaft as a sunbeam by day
    const sun = daylight, mx = Math.round(moon.x - g.shaft.ax - camX), my = Math.round(moon.y + 2 - g.shaft.ay - camY);
    ec.globalCompositeOperation = "lighter";
    if (sun < 1) { ec.globalAlpha = 1 - sun; ec.drawImage(g.shaft.e, mx, my); }
    if (sun > 0) { ec.globalAlpha = sun; ec.drawImage(g.sunShaft.e, mx, my); }
    ec.globalAlpha = 1; ec.globalCompositeOperation = "source-over";
  }
  // floating particles
  for (const p of g.particles) {
    if (p.kind === "debris" || p.kind === "dust" || p.kind === "smoke" || p.kind === "splash") continue;
    const x = Math.round(p.x - camX), y = Math.round(p.y - p.z - camY);
    if (x < -2 || y < -2 || x > W + 2 || y > H + 2) continue;
    if (p.kind === "glint") {
      const a = Math.sin(clamp(p.life, 0, 1) * Math.PI);
      ec.globalCompositeOperation = "lighter";
      ec.fillStyle = `rgba(255,240,200,${a})`;
      ec.fillRect(x, y, 1, 1);
      if (a > 0.5) { ec.fillStyle = `rgba(255,240,200,${a * 0.5})`; ec.fillRect(x - 1, y, 3, 1); ec.fillRect(x, y - 1, 1, 3); }
      ec.globalCompositeOperation = "source-over";
      continue;
    }
    if (p.emit) {
      ec.globalCompositeOperation = "lighter";
      ec.globalAlpha = clamp(p.life * 1.5, 0, 1);
      ec.fillStyle = p.col; ec.fillRect(x, y, p.size, p.size);
      ec.globalAlpha = 1;
      ec.globalCompositeOperation = "source-over";
    } else if (p.kind === "mote") {
      sc.fillStyle = p.col; sc.fillRect(x, y, 1, 1);
    } else { sc.fillStyle = p.col; sc.fillRect(x, y, p.size, p.size); }
  }
  // ---- lighting
  const sImg = sc.getImageData(0, 0, W, H);
  const eImg = ec.getImageData(0, 0, W, H);
  const active: Light[] = g.hideGolem ? [] : [g.glight];
  for (const L of g.view.lights.values()) if (L.on) active.push(L);
  g.lighting.accumulate(active, camX, camY);
  // the hour: the sky's share of the ambient by how much of it g area sees, and lamps counting for less in daylight
  const exposure = exposureOf(area);
  g.lighting.compose(sImg.data, eImg.data, g.outImg.data, ambientAt(area.base.ambient ?? BURIED_AMBIENT, hour, exposure), 6, lampGain(hour, exposure));
  g.wctx.putImageData(g.outImg, 0, 0);
  const eye = g.eyeSpot();
  g.vision.draw(g.wctx, g.pl, camX, camY, W, H, g.t, eye && { x: eye.x + eye.w / 2 - 1, y: eye.y, w: eye.w, show: eye.show });
}

/**
 * The surface rune: mostly eroded and overgrown while dormant, redrawn by the
 * awakening sweep, fully carved and glowing once active. Layers come cached
 * from SurfaceRuneArt (re-rasterised only while the sweep is in progress).
 */
export function drawSurfaceRune(g: Game, p: PropInst, camX: number, camY: number) {
  const st = g.surfaceRuneState();
  const ccx = Math.round(p.x - CR - camX), ccy = Math.round(p.y - CR - camY);
  if (ccx > -140 && ccx < g.vw + 10 && ccy > -140 && ccy < g.vh + 10) {
    const sc = g.scene.ctx, ec = g.emit.ctx;
    const L = g.runeArt.layers(st.t);
    sc.drawImage(L.scene, ccx, ccy);
    if (st.glow > 0) {
      ec.globalAlpha = clamp(st.glow, 0, 1);
      ec.drawImage(L.emit, ccx, ccy);
      if (st.glow > 1) {
        ec.globalCompositeOperation = "lighter";
        ec.globalAlpha = clamp(st.glow - 1, 0, 1);
        ec.drawImage(L.emit, ccx, ccy);
        ec.globalCompositeOperation = "source-over";
      }
      ec.globalAlpha = 1;
    }
  }
  if (st.column > 0) g.drawSummonColumn(p.x - camX, p.y - camY, st.column);
}

/** A tended lamp part-lit or out: its glow at `lvl`. A lit window (`whole`) is nothing but its glow, so all of it fades. */
export function drawDimmed(g: Game, s: Sprite, p: PropInst, lvl: number, whole: boolean, camX: number, camY: number) {
  const dx = Math.round(p.x - s.ax - camX), dy = Math.round(p.y - s.ay - camY);
  if (dx > g.vw || dy > g.vh || dx + s.w < 0 || dy + s.h < 0) return;
  const sc = g.scene.ctx, ec = g.emit.ctx;
  if (whole) sc.globalAlpha = lvl;
  sc.drawImage(s.a, dx, dy);
  sc.globalAlpha = 1;
  if (lvl > 0.01) { ec.globalAlpha = lvl; ec.drawImage(s.e, dx, dy); ec.globalAlpha = 1; }
}

/** Foliage in the wind: the upper part of the sprite shifts by a pixel now and then. */
export function drawSwaying(g: Game, s: Sprite, p: PropInst, camX: number, camY: number) {
  const dx = Math.round(p.x - s.ax - camX), dy = Math.round(p.y - s.ay - camY);
  if (dx > g.vw || dy > g.vh || dx + s.w < 0 || dy + s.h < 0) return;
  const sc = g.scene.ctx, ec = g.emit.ctx;
  const wv = Math.sin(g.t * 1.6 + p.x * 0.031 + p.y * 0.017) + 0.4 * Math.sin(g.t * 3.7 + p.x * 0.11);
  const o = Math.round(wv * 0.75);
  if (!o) { sc.drawImage(s.a, dx, dy); ec.drawImage(s.e, dx, dy); return; }
  const cut = Math.floor(s.h * 0.55);
  for (const [src, ctx] of [[s.a, sc], [s.e, ec]] as const) {
    ctx.drawImage(src, 0, 0, s.w, cut, dx + o, dy, s.w, cut);
    ctx.drawImage(src, 0, cut, s.w, s.h - cut, dx, dy + cut, s.w, s.h - cut);
  }
}

export function drawFlame(g: Game, p: PropInst, big: boolean, camX: number, camY: number) {
  const ec = g.emit.ctx;
  const bx = Math.round(p.x - camX), by = Math.round(p.y - camY - 15 + (propDef(p.kind).fire?.dy ?? 0));
  const t = g.t * 12 + p.x;
  const cols = ["#ff5a10", "#ff9a30", "#ffd060", "#fff0b0"];
  const w = big ? 8 : 3;
  for (let i = 0; i < w; i++) {
    const hgt = Math.max(1, Math.round((big ? 7 : 4) * (1 - Math.abs(i - (w - 1) / 2) / w) + Math.sin(t + i * 1.7) * 1.5 + Math.sin(t * 1.7 + i) * 0.8));
    for (let j = 0; j < hgt; j++) {
      const k = Math.min(3, Math.floor((j / hgt) * 4));
      ec.fillStyle = cols[3 - k];
      if (j === hgt - 1) ec.fillStyle = cols[0];
      ec.fillRect(bx - Math.floor(w / 2) + i, by - j + (big ? 2 : 0), 1, 1);
    }
  }
}

export function drawPedestal(g: Game, p: PropInst, i: number, spr: (s: Sprite, x: number, y: number) => void, camX: number, camY: number) {
  const s = propSprite("pedestal", 0, false)!;
  spr(s, p.x, p.y);
  const area = g.area, r = area.ritual!;
  const glyph = r.sockets[i];
  const ec = g.emit.ctx;
  const topY = p.y - 15;
  if (glyph >= 0) {
    spr(itemIcon(glyphItem(glyph)), p.x, topY + 4);
    if (r.active) {
      const pen = new Pen(ec, true);
      glyphPattern(pen, glyph, Math.round(p.x - camX) - 4, Math.round(topY - camY) - 7, GLYPHS[glyph].color, true);
    }
    if (r.wrong[i] && g.fizzT > 0 && Math.sin(g.t * 30) > 0) {
      ec.fillStyle = "#ff2040";
      ec.globalAlpha = 0.6;
      ec.fillRect(Math.round(p.x - camX) - 6, Math.round(topY - camY) - 8, 12, 12);
      ec.globalAlpha = 1;
    }
  }
  if (hasFlag(g.world, FLAGS.knowSchematic) && glyph !== r.solution[i] && !r.active) {
    const pen = new Pen(ec, true);
    ec.globalAlpha = 0.35 + 0.2 * Math.sin(g.t * 3 + i);
    const bob = Math.round(Math.sin(g.t * 2 + i) * 1.5);
    glyphPattern(pen, r.solution[i], Math.round(p.x - camX) - 3, Math.round(topY - camY) - 16 + bob - (glyph >= 0 ? 4 : 0), GLYPHS[r.solution[i]].color, true);
    ec.globalAlpha = 1;
  }
  if (i === 0 && r.core) {
    // core floating above center
    const c = area.ritualPos;
    const bob = Math.round(Math.sin(g.t * 2) * 1.5) + (r.active ? -3 : 0);
    spr(itemIcon("core"), c.x, c.y - 4 + bob);
  }
}

export function drawPlayer(g: Game, camX: number, camY: number) {
  const pl = g.pl, lk = g.look, sc = g.scene.ctx;
  // shadow
  sc.fillStyle = "rgba(0,0,0,0.45)";
  const sx = Math.round(pl.x - camX), sy = Math.round(pl.y - camY);
  const sw = Math.max(4, 8 - Math.round(lk.z / 3));
  sc.fillRect(sx - sw, sy - 1, sw * 2, 2);
  sc.fillRect(sx - sw + 2, sy - 2, sw * 2 - 4, 4);
  const a = pl.task;
  let raise = 0, reach = 0, slam: number | undefined, dip: number | undefined;
  if (a) {
    const k = a.t / a.dur;
    if (a.kind === "reach" || a.kind === "push" || a.kind === "dismantle") reach = Math.sin(Math.min(1, k) * Math.PI);
    if (a.kind === "smash") raise = a.t < 0.5 ? a.t / 0.5 : a.t < 0.62 ? lerp(1, -1, (a.t - 0.5) / 0.12) : lerp(-1, 0, clamp((a.t - 0.62) / 0.5, 0, 1));
    if (a.kind === "carve") reach = 0.4 + 0.6 * Math.abs(Math.sin(a.t * 14));
    if (a.kind === "craft") reach = 0.3 + 0.7 * Math.abs(Math.sin(a.t * 9));
    if (a.kind === "attach") reach = 0.3;
    if (a.kind === "punch") { const k2 = a.t / a.dur; raise = k2 < 0.35 ? k2 / 0.35 : k2 < 0.5 ? lerp(1, -1, (k2 - 0.35) / 0.15) : lerp(-1, 0, clamp((k2 - 0.5) / 0.4, 0, 1)); }
    if (a.kind === "channel") reach = 0.2;
    if (a.kind === "slam") ({ lift: slam, dip } = slamPose(k));
  }
  const pose: GolemPose = {
    facing: g.gaze ?? pl.facing, phase: pl.phase, moving: pl.moving && !a, hasArm: g.hasArm, dormant: lk.dormant,
    eye: clamp(lk.eye + g.eyeBoost + g.vision.k * 0.35, 0, 1.6), core: lk.core, raise, reach, t: g.t,
    eyeFixed: hasFlag(g.world, FLAGS.golemEye), back: pl.gear.back, runes: runeMarks(g.world, pl), slam, dip,
  };
  const ox = pl.x - camX + (a?.kind === "push" ? Math.round(Math.sin(a.t * 40)) : 0), oy = pl.y - camY - lk.z;
  drawGolem(new Pen(sc, false), ox, oy, pose);
  drawGolem(new Pen(g.emit.ctx, true), ox, oy, pose);
  g.selfPose = { pose, x: ox + camX, y: oy + camY };
}

// ---------------------------------------------------------------- NPCs
/** Presentation state for an NPC actor, created from its sim state (so a loaded world looks right at once). */
export function npcLook(g: Game, a: Actor): NpcLook {
  let L = g.npcLooks.get(a.id);
  if (!L) {
    const on = isAwake(g.world, a.id) ? 1 : 0;
    L = { awake: on, eye: on, wakeT: 99, sleepT: 99, reach: 0, flare: 0, lift: 0, seen: -99, arrived: false };
    g.npcLooks.set(a.id, L);
  }
  return L;
}

/** Ease every NPC in view toward its sim state: wake sputter, straighten, dim and slump. Drives its eye light. */
export function updateNpcLooks(g: Game, dt: number) {
  const area = g.area;
  for (const a of g.world.actors) {
    if (a.area !== area.id || a.id === g.world.playerId) continue;
    if (a.kind === "folk") { g.updateFolkLook(a); continue; }
    if (a.kind === "keeper") continue; // a keeper's look is all in keeperArt.ts
    // Bodies without a dialogue identity (workers): the sequencer decides how they stand, sit and shut down.
    if (!npcDef(a.npc)) { g.updateWorkerLook(a, dt); continue; }
    if (a.kind !== "npc") continue;
    const def = actorDef(a);
    const L = g.npcLook(a), on = isAwake(g.world, a.id);
    L.wakeT += dt; L.sleepT += dt;
    // awake: the eye sputters on first, then it straightens; dormant: the eye dims, then it slumps
    const target = on ? (L.wakeT > 0.6 ? 1 : 0) : (L.sleepT > 0.7 ? 0 : 1);
    L.awake += clamp(target - L.awake, -dt / 1.1, dt / 1.1);
    if (on) L.eye = L.wakeT < 0.9 ? (Math.random() < 0.45 + L.wakeT * 0.5 ? 1 : 0.12) : 1;
    else L.eye = Math.max(0, Math.min(L.eye, 1 - L.sleepT / 1.2));
    if (on && L.wakeT < 0.05) L.flare = 0.8;
    L.flare = Math.max(0, L.flare - dt * 1.5);
    L.reach = Math.max(0, L.reach - dt * 0.7);
    const el = def.eyeLight;
    if (el) {
      const lt = g.view.dynamicLight("npc:" + a.id, () => makeLight(a.x + el.dx, a.y + el.dy, el.rad, el.col, 0, 0.05, "npc:" + a.id));
      lt.int = L.eye * 0.42 + L.flare * 0.5 + (L.reach > 0.8 ? 0.25 : 0);
    }
  }
}

/**
 * A worker body, one frame: step its animation sequencer from what the sim says (powered, working, moving, has a core),
 * play the sounds and dust the sequence asks for, and, while it channels a rune, hold it up in the rune's own effect.
 * A worker that was out of the player's area (or the screen) starts at rest in whatever the sim says it is.
 */
export function updateWorkerLook(g: Game, a: Actor, dt: number) {
  const L = g.npcLook(a);
  const inp = { powered: powered(a), active: actorActive(a), moving: a.moving, hasCore: !!a.powerCore };
  if (!L.worker || g.t - L.seen > 0.5) { L.worker = initWorkerAnim(inp); if (!L.arrived) L.lift = 0; }
  L.seen = g.t; L.arrived = false;
  stepWorkerAnim(L.worker, dt, inp);
  for (const cue of drainCues(L.worker)) g.workerCue(a, cue);
  L.flare = Math.max(0, L.flare - dt * 0.8);
  const task = a.task;
  if (task?.kind === "channel" && task.target) {
    // Rune travel. The body does nothing of its own (it just stands at the rune); the rune does the effect:
    // the worker is lifted, motes spiral into the rune and a column of light builds, as the maintainer's jump does.
    const c = task.target, lift = task.dur - 1.0;
    L.lift = Math.min(task.t, lift) * 5.5 + Math.sin(task.t * 3);
    const n = Math.floor(dt * 150 + Math.random());
    for (let i = 0; i < n; i++) {
      const ang = Math.random() * Math.PI * 2, r = 12 + Math.random() * 26;
      g.spawn({ x: c.x + Math.cos(ang) * r, y: c.y + Math.sin(ang) * r, z: 1, vx: -Math.cos(ang) * r * 0.8, vy: -Math.sin(ang) * r * 0.8, vz: 8 + Math.random() * 16, life: 1.0, kind: "rune", col: Math.random() < 0.5 ? "#c0a0ff" : "#80e0ff", emit: true, g: -5 });
    }
    if (task.t - dt <= 0) g.runeBlip(c.x, c.y, 0.7);
  } else L.lift = Math.max(0, L.lift - dt * 26);
  // its core and lamp light the floor round it
  const lt = g.view.dynamicLight("npc:" + a.id, () => makeLight(a.x, a.y - 9, 38, [1, 0.38, 0.34], 0, 0.07, "npc:" + a.id));
  lt.x = a.x; lt.y = a.y - 9 - L.lift;
  if (Math.abs(lt.x - lt.vx) > 2 || Math.abs(lt.y - lt.vy) > 2) computeVis(lt, g.area);
  lt.int = L.worker.out.core * 0.2 + L.worker.out.eye * 0.1 + (task?.kind === "channel" ? 0.3 : 0);
}

/** A townsperson, one frame: the watch's lantern lights the street round them after dark. */
export function updateFolkLook(g: Game, a: Actor) {
  if (archetypeOf(a).garb !== "watch") return;
  const on = folkPresent(a) && folkLantern(g.world, a);
  const side = a.facing === "left" ? -1 : a.facing === "right" ? 1 : -4 / 3;
  const lx = a.x + side * 4, ly = a.y - 6;
  const lt = g.view.dynamicLight("folk:" + a.id, () => makeLight(lx, ly, 70, [1, 0.7, 0.38], 0, 0.14, "folk:" + a.id));
  lt.x = lx; lt.y = ly;
  if (on && (Math.abs(lt.x - lt.vx) > 2 || Math.abs(lt.y - lt.vy) > 2)) computeVis(lt, g.area);
  lt.int = on ? 0.62 : 0;
}

/** Speech bubbles and sleepers' Zs over townsfolk, on the world layer (they scale with the zoom like the marker). */
export function renderFolkBubbles(g: Game, dt: number) {
  const ctx = g.wctx, area = g.area, camX = g.cam.x, camY = g.cam.y;
  for (const [id, b] of g.bubbles) { b.t += dt; if (b.t > b.dur) g.bubbles.delete(id); }
  // a shop out of hours: a card on the counter where the keeper would stand
  const shop = shopOfArea(area.id), counter = shop && !shopOpen(g.world, shop.id) ? area.base.spots?.find((s) => s.id === "keeper") : undefined;
  if (counter) drawClosedSign(ctx, Math.round(counter.x - camX), Math.round(counter.y - camY) + 12);
  for (const a of g.world.actors) {
    if (a.area !== area.id || !(a.kind === "folk" ? folkPresent(a) && !!a.life : a.kind === "keeper" && keeperPresent(a))) continue;
    const x = Math.round(a.x - camX), y = Math.round(a.y - camY);
    if (x < -60 || y < -60 || x > g.vw + 60 || y > g.vh + 60) continue;
    if (a.life?.pose === "lie") {
      const k = (g.t * 0.5 + hash01(a.id, 4)) % 1;
      ctx.globalAlpha = Math.sin(k * Math.PI) * 0.8;
      drawTextS(ctx, k < 0.5 ? "z" : "Z", x + 4 + k * 6, y - 26 - k * 10, "#d8e0f0", 1, "left", "#1a1418");
      ctx.globalAlpha = 1;
    }
    const b = g.bubbles.get(a.id);
    if (!b) continue;
    const fade = clamp(Math.min(b.t / 0.12, (b.dur - b.t) / 0.25), 0, 1), top = y - (a.life?.pose === "sit" ? 27 : a.kind === "keeper" ? 26 : 30);
    ctx.globalAlpha = fade;
    if (b.text) drawSpeech(ctx, b.text, x, top, g.vw);
    else if (b.icon) drawChatIcon(ctx, b.icon, x + 3, top - Math.round((1 - fade) * 3));
    ctx.globalAlpha = 1;
  }
}

export function renderHud(g: Game) {
  const ctx = g.ctx;
  // interaction marker (world space: drawn on the world layer)
  if (g.screens.is("play") && g.target) {
    const ctx = g.wctx;
    const it = g.target;
    const x = Math.round(it.x - g.cam.x), y = Math.round(it.y - g.cam.y - (it.itemZ ?? 10) - 14 + Math.sin(g.t * 4) * 1.5);
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.fillRect(x - 3, y, 7, 1); ctx.fillRect(x - 2, y + 1, 5, 1); ctx.fillRect(x - 1, y + 2, 3, 1);
    ctx.fillStyle = "#d8cfa8";
    ctx.fillRect(x - 2, y - 1, 5, 1); ctx.fillRect(x - 1, y, 3, 1); ctx.fillRect(x, y + 1, 1, 1);
  }
  if (g.screens.is("play") || g.screens.is("dialogue")) g.renderFolkBubbles(g.frameDt);
  if (g.arriveFade > 0) { ctx.fillStyle = `rgba(235,240,255,${g.arriveFade})`; ctx.fillRect(0, 0, W, H); }
  if (g.doorFade > 0) { ctx.fillStyle = `rgba(6,5,9,${g.doorFade})`; ctx.fillRect(0, 0, W, H); }
  g.renderBars();
  // below the letterbox while it is up; it rises with the bars as control is handed over
  const bar = g.bars.v * g.bars.v * (3 - 2 * g.bars.v);
  drawMonologue(ctx, g.monologue, g.t, 7 + Math.round(12 * bar));
  if (g.screens.is("play")) { g.renderNote(); g.vision.drawHud(ctx, W); g.renderClock(); }
  // debug message
  if (g.debugMsg) {
    ctx.globalAlpha = clamp(2 - g.debugMsg.t, 0, 1);
    drawTextS(ctx, g.debugMsg.text, W / 2, 6, "#ff9a5a", 1, "center");
    ctx.globalAlpha = 1;
  }
  // debug readout: active modes, and (menu option) where the golem is
  if (g.debugHud || g.debugNoclip || g.debugSpeed) {
    const pl = g.pl, modes = [g.debugNoclip ? "NOCLIP" : "", g.debugSpeed ? `SPEED X${g.debugSpeedMult}` : ""].filter(Boolean).join("  ");
    const lines = [
      ...(g.debugHud ? [`${pl.area.toUpperCase()}  X ${Math.round(pl.x)}  Y ${Math.round(pl.y)}  TILE ${Math.floor(pl.x / TS)},${Math.floor((pl.y - 3) / TS)}`] : []),
      ...(modes ? [`DEBUG: ${modes}`] : []),
    ];
    lines.forEach((l, i) => drawTextS(ctx, l, 4, H - 8 - (lines.length - 1 - i) * 8, "#ff9a5a", 1, "left", "#000"));
  }
  // toast (the dialogue box draws it above itself)
  if (!g.screens.is("schem") && !g.screens.is("dialogue")) g.renderToast(H - 26);
}

/**
 * The hour, bottom right: the sun, the moon, or the sun on the horizon, and the clock. Shown under the open sky, and
 * anywhere once the golem has been up to see it (it keeps count from then on; before that it has no way to know).
 */
export function renderClock(g: Game) {
  if (!g.area.base.outdoor && !hasFlag(g.world, FLAGS.tutorialDone)) return;
  const ctx = g.ctx, hour = worldHour(g.world), ph = phaseAt(hour), x = W - 35, y = H - 11;
  ctx.fillStyle = "rgba(6,5,9,0.6)"; ctx.fillRect(x - 3, y - 2, 36, 11);
  const px = (c: string, cells: number[][]) => { ctx.fillStyle = c; for (const [cx, cy, w = 1, h = 1] of cells) ctx.fillRect(x + cx, y + cy, w, h); };
  if (ph === "day") {
    px("#ffb030", [[3, 0], [3, 6], [0, 3], [6, 3], [1, 1], [5, 1], [1, 5], [5, 5]]);
    px("#ffd860", [[2, 2, 3, 3]]);
  } else if (ph === "night") {
    px("#c8d4f0", [[2, 1, 3, 1], [1, 2, 2, 1], [1, 3, 2, 1], [1, 4, 3, 1], [2, 5, 3, 1]]);
    px("#7a88b0", [[5, 2], [6, 0]]);
  } else {
    px("#ff9a40", [[2, 3, 3, 2], [1, 4, 5, 1], [3, 1], [1, 2], [5, 2]]);
    px("#8a5a3a", [[0, 5, 7, 1]]);
  }
  drawText(ctx, clockText(hour), x + 10, y + 1, ph === "night" ? "#a8b4d8" : ph === "day" ? "#e8d8a0" : "#f0b078");
}

export function renderToast(g: Game, y: number) {
  const ctx = g.ctx;
  if (g.toast) {
    const t = g.toast.t;
    const a = t < 0.2 ? t / 0.2 : t > 2.5 ? 1 - (t - 2.5) / 0.5 : 1;
    ctx.globalAlpha = clamp(a, 0, 1);
    const name = g.toast.name;
    const w = name.length * 4 + 30;
    const x = Math.round(W / 2 - w / 2);
    ctx.fillStyle = "#0c0a0e"; ctx.fillRect(x, y, w, 20);
    ctx.fillStyle = "#3a3540"; ctx.fillRect(x, y, w, 1); ctx.fillRect(x, y + 19, w, 1); ctx.fillRect(x, y, 1, 20); ctx.fillRect(x + w - 1, y, 1, 20);
    ctx.drawImage(g.toast.icon.a, x + 3, y + 2);
    drawText(ctx, name, x + 23, y + 8, "#d8d0b8");
    ctx.globalAlpha = 1;
  }
}

export function visionArt(g: Game): VisionArt {
  const a = (g.visionArtCache ??= { t: 0, npcLook: (x) => g.npcLook(x), circle: { lines: [g.circle.glow, g.circle.glowGap], r: CR }, self: () => (g.hideGolem ? null : g.selfPose) });
  a.t = g.t;
  return a;
}
