// The event-reaction layer (split from game.ts): drains the World's events and turns them into sound, particles,
// notes, toasts and screens. Presentation only: it never changes the World except through sim entry points.

import { ITEMS, ITEM_NAMES } from "../content/items";




import { coreCheck } from "../sim/power";



import { isStation } from "../content/crafting";













import { reactToEvents, playerThinks } from "../sim/monologue";


import { VISION_CATEGORIES } from "../content/vision";

import { learnedText } from "../content/flags";

import { portalById } from "../sim/portals";

import { itemIcon } from "../art/items";


import { SLAM_HIT } from "../content/tasks";





import { RUNE_NODES } from "../content/runes";



import { actorById, type SimEvent } from "../world/world";





import { ZOOM_DEFAULT } from "./zoom";

import { actorDef } from "../content/actors";


import { type AnimCue } from "../workerAnim";
import { eventAudience } from "./audience";
import { type VisionCue } from "./vision";

import { npcActor } from "../sim/dialogue";

import type { Actor } from "../world/world";
import { folkLabel, sayTime } from "../sim/folk";
import { keeperLabel } from "../sim/shops";





import { type DayPhase } from "../content/daycycle";

import { Game, FOLK_EARSHOT, FOLK_MAX_LINES } from "../game";

export function drainEvents(g: Game) {
  // Monologue triggers must see events from paused-world commands (a book, the pack) before they are drained.
  reactToEvents(g.world);
  const evs = g.world.events;
  if (!evs.length) return;
  for (const e of evs) g.noticeEvent(e);
  g.world.events = [];
  for (const e of evs) {
    if (e.t === "travelled" && e.actor !== g.world.playerId) { g.workerTravelled(e); continue; }
    if (e.t === "portal" && actorById(g.world, e.actor)?.kind === "folk") continue; // townsfolk come and go quietly
    if (e.t === "portal" && e.actor !== g.world.playerId) { g.workerWalked(e); continue; }
    const aud = eventAudience(g.world, e);
    if (aud === "player") g.onEvent(e);
    else if (aud === "nearby") g.onNearby(e);
  }
}

/** Another actor in the player's area did something: world-space feedback only. */
export function onNearby(g: Game, e: SimEvent) {
  if (e.t === "step") {
    const a = actorById(g.world, e.actor);
    if (a) for (let i = 0; i < 2; i++)
      g.spawn({ x: a.x + (Math.random() - 0.5) * 8, y: a.y, z: 1, vx: (Math.random() - 0.5) * 12, vz: 6, life: 0.5, kind: "dust", col: "#8a8478", g: 20 });
  } else if (e.t === "harvestHit") {
    if (e.kind === "tree" || e.kind === "log") g.sfx.thud(); else g.sfx.clink();
    for (let i = 0; i < (e.depleted ? 14 : 6); i++)
      g.spawn({ x: e.x + (Math.random() - 0.5) * 10, y: e.y, z: 6 + Math.random() * 8, vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.5) * 14, vz: 10 + Math.random() * 20, life: 0.8, kind: "debris", col: e.kind === "rock" ? "#6a6372" : "#6a5034", g: 120 });
  } else if (e.t === "cue") {
    // Cues are local sound/particles for the worker that made them: no screen
    // shake, fizz timer or crack flash, because those belong to the player.
    if (e.cue === "clank") g.sfx.clank();
    else if (e.cue === "scrape") g.sfx.scrape();
    else if (e.cue === "dud" || e.cue === "runeDud") g.sfx.fizzle();
    else if (e.cue === "scrapeDust") {
      g.sfx.scrape();
      for (let i = 0; i < 4; i++) g.spawn({ x: e.x, y: e.y, z: 2, vx: (Math.random() - 0.5) * 20, vz: 8, life: 0.8, kind: "dust", col: "#9a96a0", g: 20 });
    } else if (e.cue === "push") {
      g.sfx.thud();
      for (let i = 0; i < 6; i++) g.spawn({ x: e.x + (Math.random() - 0.5) * 16, y: e.y + 2, z: 20 + Math.random() * 10, vx: (Math.random() - 0.5) * 10, life: 1.5, kind: "debris", col: "#6a6372", g: 80 });
    }
  }
}

/** Sound, particles and UI reactions to the player's (and world) simulation events. */
export function onEvent(g: Game, e: SimEvent) {
  const pl = g.pl;
  switch (e.t) {
    case "itemGained": {
      const n = e.n ?? 1;
      g.toast = { icon: itemIcon(e.item), name: ITEM_NAMES[e.item] + (n > 1 ? ` x${n}` : ""), t: 0 };
      g.sfx.pickup();
      if (e.stored) for (let i = 0; i < 10; i++) g.spawn({ x: pl.x, y: pl.y - 4, z: 14, vx: (Math.random() - 0.5) * 30, vy: (Math.random() - 0.5) * 20, vz: 20 + Math.random() * 20, life: 0.6, kind: "glint", col: "#fff0c0", emit: true, g: 40 });
      const def = ITEMS[e.item], id = e.item;
      if (def.opensOnPickup) g.later(0.5, () => { if (g.screens.is("play")) def.opens === "book" ? g.bookUi.open(id) : g.schemUi.open(); });
      break;
    }
    case "itemDropped":
      g.sfx.thud();
      for (let i = 0; i < 6; i++) g.spawn({ x: e.x + (Math.random() - 0.5) * 8, y: e.y, z: 2, vx: (Math.random() - 0.5) * 14, vz: 8, life: 0.6, kind: "dust", col: "#8a8478", g: 20 });
      if (e.reason !== "drop") g.say(e.reason === "full" ? "PACK FULL - LEFT ON THE GROUND" : "NO ROOM - DROPPED ON THE GROUND");
      break;
    case "packFull": g.say("YOUR PACK IS FULL"); g.sfx.tone(180, 0.1, "square", 0.04); break;
    case "message": g.say(e.text); break;
    case "folkSpoke": {
      const a = actorById(g.world, e.folk);
      const label = a?.person ? folkLabel(a) : a?.keeper ? keeperLabel(a) : null;
      if (a && label) { g.bubbles.set(a.id, { text: e.line, t: 0, dur: 2.4 + e.line.length * 0.055 }); g.say(label); g.sfx.tone(520, 0.05, "triangle", 0.03); }
      break;
    }
    case "folkSay": {
      // Their own talk (to each other, to a keeper, to themselves): the words in a bubble when it is near and the
      // street is not already full of words; otherwise the pictogram from `folkChat` stands. Never a dialogue screen.
      const a = actorById(g.world, e.folk);
      if (!a || a.area !== g.pl.area) break;
      const cur = g.bubbles.get(a.id);
      if (cur?.text && !cur.talk) break; // answering the golem: that line stays
      const near = Math.hypot(a.x - g.pl.x, a.y - g.pl.y) < FOLK_EARSHOT;
      const partner = e.to ? g.bubbles.get(e.to) : undefined;
      let others = 0;
      for (const [id, b] of g.bubbles) if (b.text && id !== a.id && id !== e.to && b.t < b.dur - 0.3) others++;
      if (!near || (others >= FOLK_MAX_LINES && !partner?.talk && !cur?.talk)) break;
      if (partner?.talk && e.to) g.bubbles.delete(e.to); // in turn: one side of a talk at a time
      g.bubbles.set(a.id, { text: e.line, t: 0, dur: sayTime(e.line), talk: true });
      break;
    }
    case "folkChat": {
      const a = actorById(g.world, e.folk);
      if (a && a.area === g.pl.area && !g.bubbles.get(a.id)?.text) g.bubbles.set(a.id, { icon: e.icon, t: 0, dur: 1.5 });
      break;
    }
    case "analyzed":
      // one chime per prop, however many plans it held
      if (g.lastAnalyzed.prop !== e.prop || g.t - g.lastAnalyzed.t > 0.2) g.sfx.analyzed();
      g.lastAnalyzed = { prop: e.prop, t: g.t };
      break;
    case "learned":
      g.sfx.insight(); g.eyeBoost = 1.5;
      g.say(learnedText(e.flag));
      break;
    case "thought":
      g.monologue.push(e.line);
      break;
    case "harvestHit": {
      const tree = e.kind === "tree" || e.kind === "log";
      if (tree) g.sfx.thud(); else g.sfx.clink();
      g.shake(e.depleted ? 0.35 : 0.12, e.depleted ? 2 : 1);
      if (e.depleted && !tree) g.sfx.smash();
      const cols = tree ? ["#5b3d24", "#7a5634", "#3e6a30", "#5a8a40"] : ["#8a8392", "#6a6372", "#4b4552"];
      for (let i = 0; i < (e.depleted ? 26 : 10); i++)
        g.spawn({ x: e.x + (Math.random() - 0.5) * 12, y: e.y, z: tree && i % 2 ? 20 + Math.random() * 14 : 6 + Math.random() * 6, vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.5) * 20, vz: 10 + Math.random() * 30, life: 1 + Math.random(), kind: "debris", col: cols[(Math.random() * cols.length) | 0], g: tree && i % 2 ? 30 : 120 });
      break;
    }
    case "deconstructed":
      g.sfx.clink(); g.sfx.noise(0.2, 0.1, "bandpass", 900, 2);
      for (let i = 0; i < 12; i++) g.spawn({ x: e.x + (Math.random() - 0.5) * 10, y: e.y, z: e.kind === "torch" || e.kind === "banner" ? 10 : 4, vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.5) * 16, vz: 10 + Math.random() * 20, life: 0.7, kind: "debris", col: Math.random() < 0.5 ? "#7a5634" : "#6a6372", g: 120 });
      break;
    case "openStation":
      // E on a station: the bench, the smelter or the anvil, each the same screen under its own name (content/crafting.ts).
      if (e.actor === g.world.playerId && g.screens.is("play") && isStation(e.station)) g.craftUi.open(e.station, e.prop);
      break;
    case "dug": {
      // A dig stroke: earth thuds and flies brown, stone rings and flies grey. A layer giving out, and the
      // stair coming open, are said in words (the sim only reports what happened).
      const stone = e.material === "stone";
      if (stone) g.sfx.clink(); else g.sfx.thud();
      g.shake(e.opened ? 0.6 : 0.12, e.opened ? 3 : 1);
      const cols = stone ? ["#8a8392", "#6a6372", "#4b4552"] : ["#4e3c2a", "#5a4630", "#3e2e20"];
      for (let i = 0; i < (e.opened ? 32 : 12); i++)
        g.spawn({ x: e.x + (Math.random() - 0.5) * 30, y: e.y + (Math.random() - 0.5) * 20, z: 2 + Math.random() * 6, vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.5) * 20, vz: 14 + Math.random() * 30, life: 0.8 + Math.random() * 0.6, kind: "debris", col: cols[(Math.random() * cols.length) | 0], g: 120 });
      if (e.actor !== g.world.playerId) break;
      if (e.opened) { g.sfx.smash(); g.say("THE VAULT GIVES WAY. THE OLD STAIR IS OPEN: WALK DOWN INTO IT FROM ITS SOUTH END"); }
      else if (e.next === "stone") g.say("THE EARTH IS OUT. FALLEN STONE LIES UNDER IT: THAT NEEDS A PICKAXE HEAD");
      break;
    }
    case "openStorage":
      // E on a storage prop: its screen (pack beside chest). Only the player's own use, from the play screen.
      if (e.actor === g.world.playerId && g.screens.is("play")) g.storageUi.open(e.prop);
      break;
    case "manageActor":
      // E on a worker: its management screen (state, core, orders). The golem's thought about a body with no
      // core (content/monologue.ts) still fires from g event.
      if (e.actor === g.world.playerId && g.screens.is("play") && actorById(g.world, e.target)) g.manageUi.open(e.target);
      break;
    case "coreSlotted": {
      // The core seam's feedback (sim/power.ts), both ways. In: the latch, a hum, embers, the core flaring as it
      // boots before it settles to its faint idle glow. Out: the latch, the hum falling, a puff of dust.
      const a = actorById(g.world, e.target);
      if (!a) break;
      const L = g.npcLook(a), name = ITEM_NAMES[e.item];
      if (e.inserted) {
        g.sfx.coreIn(e.powered);
        if (e.powered) L.flare = 1;
        g.coreSparks(a, e.powered ? 6 : 5, e.powered); // the latch; the boot animation sparks it again as it lights
        g.say(e.powered ? `${name} SLOTTED - IT POWERS ON` : `${name} SLOTTED`);
      } else {
        const ran = coreCheck(a, e.item).sufficient;
        g.sfx.coreOut(ran);
        L.flare = 0;
        for (let i = 0; i < 6; i++) g.spawn({ x: a.x + (Math.random() - 0.5) * 10, y: a.y, z: 6 + Math.random() * 6, vx: (Math.random() - 0.5) * 14, vz: 4 + Math.random() * 6, life: 0.8, kind: "dust", col: "#8a8478", g: 10 });
        g.say(ran ? `${name} TAKEN OUT - IT POWERS DOWN` : `${name} TAKEN OUT`);
      }
      break;
    }
    case "built":
      g.sfx.place(); g.sfx.tone(520, 0.2, "triangle", 0.05);
      for (let i = 0; i < 10; i++) g.spawn({ x: e.x, y: e.y - 14, z: 2, vx: (Math.random() - 0.5) * 30, vz: 10 + Math.random() * 20, life: 0.6, kind: "spark", col: "#ffb040", emit: true, g: 80 });
      break;
    case "runeAwakened": case "travelled":
      g.tele.travelled = true;
      break;
    case "step":
      g.sfx.step(e.heavy);
      for (let i = 0; i < (e.heavy ? 4 : 2); i++)
        g.spawn({ x: pl.x + (Math.random() - 0.5) * 10, y: pl.y, z: 1, vx: (Math.random() - 0.5) * 16, vy: (Math.random() - 0.5) * 6, vz: 8, life: 0.6, kind: "dust", col: "#8a8478", g: 20 });
      if (!e.heavy && !g.hasArm) g.sfx.scrape();
      break;
    case "taskTick": {
      const a = e.task;
      if (a.kind === "attach") { if (Math.random() < 0.5) g.sparkBurst(2); }
      else if (a.kind === "slam") {
        // both arms heave up (a low grind), then swing down (a whoosh) just before the blow lands
        const k0 = (a.t - e.dt) / a.dur, k1 = a.t / a.dur, down = SLAM_HIT * 0.88;
        if (k0 <= 0.02 && k1 > 0.02) g.sfx.slamWindup();
        if (k0 < down && k1 >= down) g.sfx.slamSwing();
        if (!g.hasArm && k1 < SLAM_HIT && Math.random() < 0.12) g.sparkBurst(1);
      }
      else if (a.kind === "dismantle" && a.target) {
        if (Math.floor(a.t / 0.3) !== Math.floor((a.t - e.dt) / 0.3)) g.sfx.clink();
        if (Math.random() < 0.3) g.spawn({ x: a.target.x + (Math.random() - 0.5) * 10, y: a.target.y, z: 4 + Math.random() * 8, vx: (Math.random() - 0.5) * 20, vz: 8, life: 0.5, kind: "dust", col: "#8a8478", g: 30 });
      }
      else if (a.kind === "scan" && e.actor === pl.id) {
        // the eye reads the pattern: a rising run of data chirps up to the fire point
        const fire = a.dur * 0.85, k0 = (a.t - e.dt) / fire, k1 = a.t / fire;
        if (k0 <= 0 && k1 > 0) g.sfx.scanStart();
        if (k1 < 1 && Math.floor(k1 * 9) !== Math.floor(k0 * 9)) g.sfx.scanTick(k1);
      }
      else if (a.kind === "craft") {
        if (Math.floor(a.t / 0.25) !== Math.floor((a.t - e.dt) / 0.25)) {
          g.sfx.clink();
          if (a.target) for (let i = 0; i < 2; i++) g.spawn({ x: a.target.x + (Math.random() - 0.5) * 14, y: a.target.y - 6, z: 8, vx: (Math.random() - 0.5) * 30, vz: 12 + Math.random() * 14, life: 0.4, kind: "spark", col: "#e8d8a0", emit: true, g: 120 });
        }
      }
      else if (a.kind === "carve") {
        const c = g.area.ritualPos;
        const k = Math.floor(a.t / 0.22), kp = Math.floor((a.t - e.dt) / 0.22);
        if (k !== kp && a.t < a.dur - 0.3) {
          g.sfx.clink();
          const ang = 0.26 + Math.random() * 1.05, r = 44 + Math.random() * 13;
          for (let i = 0; i < 4; i++) g.spawn({ x: c.x + Math.cos(ang) * r, y: c.y + Math.sin(ang) * r, z: 1, vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.5) * 30, vz: 20 + Math.random() * 20, life: 0.4, kind: "spark", col: "#d0c0ff", emit: true, g: 120 });
          g.spawn({ x: c.x + Math.cos(ang) * r, y: c.y + Math.sin(ang) * r, z: 1, vz: 6, life: 1, kind: "dust", col: "#8a8690", g: 4 });
        }
      }
      break;
    }
    case "cue":
      if (e.cue === "clank") { g.sfx.clank(); g.shake(0.1, 1); }
      else if (e.cue === "scrape") g.sfx.scrape();
      else if (e.cue === "dud") { g.sfx.fizzle(); g.fizzT = 0.5; }
      else if (e.cue === "runeDud") g.runeRefused(e.x, e.y);
      else if (e.cue === "scrapeDust") {
        g.sfx.scrape();
        for (let i = 0; i < 4; i++) g.spawn({ x: e.x, y: e.y, z: 2, vx: (Math.random() - 0.5) * 20, vz: 8, life: 0.8, kind: "dust", col: "#9a96a0", g: 20 });
      } else if (e.cue === "push") {
        g.sfx.thud();
        g.shake(0.2, 1);
        for (let i = 0; i < 6; i++) g.spawn({ x: e.x + (Math.random() - 0.5) * 16, y: e.y + 2, z: 20 + Math.random() * 10, vx: (Math.random() - 0.5) * 10, life: 1.5, kind: "debris", col: "#6a6372", g: 80 });
        g.crackFlash = 1;
      }
      break;
    case "equipped":
      g.sfx.clank();
      g.shake(0.15, 1);
      g.sparkBurst(14);
      break;
    case "gearOn": case "gearOff":
      // Gear is light: a soft wicker creak and a quiet line (nothing like the iron arm's clank, sparks and shake).
      if (e.actor !== g.world.playerId) break;
      if (ITEMS[e.item].worn) g.sfx.tone(e.t === "gearOn" ? 700 : 420, 0.14, "triangle", 0.05); // a rune: a soft chime
      else if (e.t === "gearOn") g.sfx.strap(); else g.sfx.unstrap();
      g.say(e.t === "gearOn" ? (e.slot === "back" ? `${ITEM_NAMES[e.item]} ON YOUR BACK` : `${ITEM_NAMES[e.item]} EQUIPPED`) : `${ITEM_NAMES[e.item]} TAKEN OFF`);
      break;
    case "crafted":
      if (e.actor === g.world.playerId) { g.sfx.place(); g.say(`MADE ${e.n} ${ITEM_NAMES[e.item]}`); }
      break;
    case "containerOpened":
      g.sfx.open();
      for (let i = 0; i < 8; i++) g.spawn({ x: e.x + (Math.random() - 0.5) * 12, y: e.y, z: 6, vx: (Math.random() - 0.5) * 20, vz: 10, life: 1, kind: "dust", col: "#7a7468", g: 10 });
      break;
    case "doorUnlocked": g.sfx.unlock(); break;
    case "wallBroken": {
      g.sfx.smash();
      g.shake(0.7, 3.5);
      const cx = e.x, cy = e.y;
      for (let i = 0; i < 40; i++)
        g.spawn({ x: cx + (Math.random() - 0.5) * 16, y: cy + (Math.random() - 0.5) * 20, z: 4 + Math.random() * 18, vx: (Math.random() - 0.5) * 120, vy: (Math.random() - 0.5) * 60, vz: 20 + Math.random() * 60, life: 1.6 + Math.random(), kind: "debris", col: ["#8a8392", "#6a6372", "#4b4552"][(Math.random() * 3) | 0], g: 160, size: Math.random() < 0.4 ? 2 : 1 });
      for (let i = 0; i < 40; i++)
        g.spawn({ x: cx + (Math.random() - 0.5) * 24, y: cy + (Math.random() - 0.5) * 24, z: Math.random() * 20, vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.5) * 30, vz: Math.random() * 10, life: 2 + Math.random() * 2, kind: "smoke", col: "#7a7470", g: -2, size: 2 });
      break;
    }
    case "slam": {
      // Both fists hit the ground: a deep thud, a ring of dust where they land, a small shake.
      // Whatever was hit adds its own feedback (wallBroken / withstood).
      g.sfx.slam();
      g.shake(0.18, 1.2);
      for (let i = 0; i < 16; i++) {
        const ang = Math.random() * Math.PI * 2, v = 14 + Math.random() * 24;
        g.spawn({ x: e.x + Math.cos(ang) * 3, y: e.y + Math.sin(ang) * 2, z: 1, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v * 0.5, vz: 6 + Math.random() * 10, life: 0.6 + Math.random() * 0.5, kind: "dust", col: Math.random() < 0.5 ? "#8a8478" : "#a09a8c", g: 20 });
      }
      if (!g.hasArm) g.sparkBurst(5); // the broken stub struck too
      break;
    }
    case "withstood": {
      // The debris takes the blow and holds: a heavy impact, a smaller shake than a break, chips and
      // dust off its face, and the debris itself jolts and flashes. Nothing in the world changes.
      g.sfx.impact();
      g.shake(0.3, 2);
      g.crackFlash = 1;
      if (e.tx !== undefined && e.ty !== undefined) g.shudder = { tx: e.tx, ty: e.ty, t: 0.45 };
      for (let i = 0; i < 14; i++)
        g.spawn({ x: e.x + (Math.random() - 0.5) * 16, y: e.y + 2, z: 4 + Math.random() * 20, vx: (Math.random() - 0.5) * 60, vy: Math.random() * 24, vz: 10 + Math.random() * 30, life: 0.9 + Math.random() * 0.6, kind: "debris", col: ["#8a8392", "#6a6372", "#4b4552"][(Math.random() * 3) | 0], g: 140 });
      for (let i = 0; i < 16; i++)
        g.spawn({ x: e.x + (Math.random() - 0.5) * 20, y: e.y + 3, z: Math.random() * 14, vx: (Math.random() - 0.5) * 24, vy: Math.random() * 10, vz: 2 + Math.random() * 6, life: 1 + Math.random(), kind: "dust", col: "#8a8478", g: 6, size: Math.random() < 0.4 ? 2 : 1 });
      break;
    }
    case "corePlaced": g.sfx.place(); g.sfx.tone(660, 1, "sine", 0.06); break;
    case "carved": g.sfx.tone(392, 1.2, "sine", 0.07); break;
    case "glyphPlaced": g.sfx.place(); break;
    case "runeActivated": g.sfx.activate(); g.shake(1.5, 1.5); break;
    case "runeFizzled": {
      g.fizzT = 1.2;
      g.sfx.fizzle();
      g.shake(0.4, 2);
      const c = g.area.ritualPos;
      for (let i = 0; i < 40; i++) {
        const a = Math.random() * Math.PI * 2, rr = 44 + Math.random() * 13;
        g.spawn({ x: c.x + Math.cos(a) * rr, y: c.y + Math.sin(a) * rr, z: 1, vx: (Math.random() - 0.5) * 60, vy: (Math.random() - 0.5) * 40, vz: 30 + Math.random() * 30, life: 0.5, kind: "spark", col: Math.random() < 0.5 ? "#ff6a8a" : "#a070ff", emit: true, g: 120 });
      }
      break;
    }
    case "runeDeactivated": g.sfx.setHum(0); break;
    case "teleport":
      g.tele = { x: e.x, y: e.y, dur: pl.task?.dur ?? 4.6, first: e.first, travelled: false };
      g.screens.set(g.S.tele); g.sfx.teleport();
      // The first jump opens the crossing (screens/crossing.ts): bars in, and the golem's own account of it begins.
      if (e.first) { g.letterbox(true); g.monologue.pinned = true; playerThinks(g.world, "cross.engage"); }
      break;
    case "areaEntered": break;
    case "dayPhase": g.onDayPhase(e.phase); break;
    case "portal": {
      // Walked through a doorway or out along a road (sim/portals.ts): a latch or a footfall, a short fade up from
      // dark, and the name of the place arrived in. The old area's particles stay behind.
      const dest = g.world.areas.get(e.toArea), out = dest && portalById(dest, e.to);
      g.doorFade = 1; g.particles = [];
      if (out?.door) g.sfx.open(); else g.sfx.step(true);
      if (out?.label) g.say(out.label);
      break;
    }
    case "dialogue":
      if (g.screens.is("play")) g.dialogueUi.open(e.npc, e.script, e.segment);
      break;
    case "npcState": {
      const a = npcActor(g.world, e.npc);
      if (!a) break;
      const L = g.npcLook(a);
      if (e.awake) {
        L.wakeT = 0;
        g.sfx.wakeSputter();
        g.npcSparks(a, 10);
        g.later(0.5, () => g.npcSparks(a, 6));
      } else {
        L.sleepT = 0;
        g.sfx.powerDown();
        g.later(1.1, () => { g.shake(0.2, 1); g.npcDust(a); });
      }
      break;
    }
    case "eyeRepaired": {
      const lk = g.look;
      lk.sputter = 0; lk.eye = 1;
      g.eyeBoost = 2.2;
      g.sfx.eyeRepair();
      g.shake(0.25, 1);
      g.sparkBurst(10);
      for (let i = 0; i < 24; i++)
        g.spawn({ x: pl.x + (Math.random() - 0.5) * 4, y: pl.y, z: 18, vx: (Math.random() - 0.5) * 60, vy: (Math.random() - 0.5) * 24, vz: 10 + Math.random() * 40, life: 0.4 + Math.random() * 0.5, kind: "spark", col: Math.random() < 0.5 ? "#bff4ff" : "#7fe8ff", emit: true, g: 110 });
      const by = e.by ? npcActor(g.world, e.by) : undefined;
      if (by) g.npcLook(by).reach = 1.8; // the guardian's hand holds still, then lowers
      // the camera pulls out as the eye clears; the wheel takes over from here
      g.later(0.5, () => g.zoomTo(ZOOM_DEFAULT, 1.1));
      g.dialogueUi.zoomHint = true;
      break;
    }
  }
}

/** The day turned (sim/daytime.ts). Under the open sky it is said; where people live, the town answers it. */
export function onDayPhase(g: Game, phase: DayPhase) {
  const a = g.area;
  if (!a.base.outdoor || !g.screens.is("play")) return;
  const town = !!a.base.tended;
  if (phase === "dawn") { g.say(town ? "DAWN. THE TOWN PUTS OUT ITS LAMPS." : "DAWN BREAKS."); if (town) g.sfx.bell(); }
  else if (phase === "dusk") { g.say(town ? "DUSK. THE TOWN LIGHTS ITS LAMPS." : "DUSK. THE LIGHT IS GOING."); if (town) g.sfx.bell(); }
  else if (phase === "night") g.say("NIGHT FALLS.");
}

/** The sounds and dust of a worker's animation cues (workerAnim.ts), quiet when it is far off. */
export function workerCue(g: Game, a: Actor, cue: AnimCue) {
  const near = g.volAt(a.x, a.y) > 0.15;
  const dust = (n: number) => { for (let i = 0; i < n; i++) g.spawn({ x: a.x + (Math.random() - 0.5) * 12, y: a.y + 1, z: 1, vx: (Math.random() - 0.5) * 22, vy: (Math.random() - 0.5) * 8, vz: 6 + Math.random() * 6, life: 0.6, kind: "dust", col: "#8a7a68", g: 20 }); };
  switch (cue) {
    case "spark": g.coreSparks(a, 9, true); if (near) g.sfx.spark(); break;
    case "creak": if (near) g.sfx.scrape(); break;
    case "lamp": g.coreSparks(a, 3, true); if (near) g.sfx.wakeSputter(); break;
    case "plant": dust(7); if (near) g.sfx.thud(); break;
    case "jolt": g.coreSparks(a, 8, false); dust(3); if (near) g.sfx.clank(); break;
    case "lampOut": if (near) g.sfx.tone(420, 0.25, "sine", 0.03, 110); break;
    case "settle": if (near) g.sfx.tone(190, 0.7, "sine", 0.035, 70); break;
  }
}

/** A soft rune chime and a burst of motes at (x, y): a worker leaving or arriving through a rune. */
export function runeBlip(g: Game, x: number, y: number, k = 1) {
  const v = g.volAt(x, y) * k;
  if (v > 0.05) { g.sfx.tone(520, 0.35, "sine", 0.06 * v, 1040); g.sfx.tone(780, 0.5, "triangle", 0.04 * v, undefined, 0.07); }
}

export function runeBurst(g: Game, x: number, y: number) {
  g.runeBlip(x, y);
  for (let i = 0; i < 26; i++) {
    const ang = Math.random() * Math.PI * 2, sp = 14 + Math.random() * 30;
    g.spawn({ x, y, z: 2 + Math.random() * 10, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp * 0.5, vz: 10 + Math.random() * 30, life: 0.7, kind: "rune", col: Math.random() < 0.4 ? "#ffffff" : Math.random() < 0.5 ? "#c0a0ff" : "#80e0ff", emit: true, g: 10 });
  }
}

/**
 * E on a rune that will not carry (dark, or lit with nothing answering it): the fizzle, a jolt, sparks thrown off
 * its ring, and the rune's own sputter (view/runeFx.ts), which updateWorldFx runs. The halls' circle flickers on
 * `fizzT`, as it always did for a dud; a rune that is a prop (the surface's) reads `runeDud` in surfaceRuneState.
 */
export function runeRefused(g: Game, x: number, y: number) {
  g.sfx.fizzle();
  g.fizzT = 0.5;
  g.runeDud = { x, y, t: 0 };
  g.shake(0.25, 1.2);
  for (let i = 0; i < 18; i++) {
    const a = Math.random() * Math.PI * 2, rr = 44 + Math.random() * 13;
    g.spawn({ x: x + Math.cos(a) * rr, y: y + Math.sin(a) * rr, z: 1, vx: (Math.random() - 0.5) * 60, vy: (Math.random() - 0.5) * 40, vz: 30 + Math.random() * 30, life: 0.5, kind: "spark", col: Math.random() < 0.5 ? "#ff6a8a" : "#a070ff", emit: true, g: 120 });
  }
}

/**
 * Another body walked through a door or off along a road (a worker under orders: sim/jobs.ts). It is only heard:
 * the latch or a footfall where it left, if that was here, else where it came out, if that is here. The view, the
 * fade and the place's name are the player's own (onEvent, "portal").
 */
export function workerWalked(g: Game, e: Extract<SimEvent, { t: "portal" }>) {
  const here = g.pl.area, a = actorById(g.world, e.actor);
  const from = e.fromArea === here ? portalById(g.area, e.from) : undefined;
  const out = !from && a && e.toArea === here ? portalById(g.area, e.to) : undefined;
  const at = from ? { x: from.x + from.w / 2, y: from.y + from.h / 2, door: !!from.door } : out && a ? { x: a.x, y: a.y, door: !!out.door } : null;
  if (!at || g.volAt(at.x, at.y) < 0.15) return;
  if (at.door) g.sfx.open(); else g.sfx.step(true);
}

/** Another body went through a rune: a flash where it left (if that was in the player's area) and where it landed. */
export function workerTravelled(g: Game, e: Extract<SimEvent, { t: "travelled" }>) {
  const a = actorById(g.world, e.actor), pa = g.pl.area;
  const from = RUNE_NODES[e.from], p = from && from.area === pa ? g.area.prop(from.prop) : null;
  if (p) g.runeBurst(p.x, p.y);
  if (a && a.area === pa) { const L = g.npcLook(a); L.lift = 13; L.arrived = true; g.runeBurst(a.x, a.y); }
}

/** Embers from a golem's core hatch as a core seats: bright when it powers the body, a few dull ones when too weak. */
export function coreSparks(g: Game, a: Actor, n: number, bright: boolean) {
  const z = actorDef(a).body.height * 0.55;
  for (let i = 0; i < n; i++)
    g.spawn({ x: a.x + (Math.random() - 0.5) * 4, y: a.y + 1, z: z + Math.random() * 3, vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.2) * 16, vz: 8 + Math.random() * 24, life: 0.3 + Math.random() * 0.4, kind: "spark", col: bright ? (Math.random() < 0.5 ? "#ff5a70" : "#ffc0c8") : "#8a3040", emit: true, g: 110 });
}

export function npcSparks(g: Game, a: Actor, n: number) {
  for (let i = 0; i < n; i++)
    g.spawn({ x: a.x + (Math.random() - 0.5) * 16, y: a.y - 2, z: 18 + Math.random() * 14, vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.5) * 20, vz: 10 + Math.random() * 30, life: 0.3 + Math.random() * 0.4, kind: "spark", col: Math.random() < 0.5 ? "#fff2a0" : "#7fe8ff", emit: true, g: 120 });
}

export function npcDust(g: Game, a: Actor) {
  for (let i = 0; i < 12; i++)
    g.spawn({ x: a.x + (Math.random() - 0.5) * 26, y: a.y, z: 2 + Math.random() * 6, vx: (Math.random() - 0.5) * 24, vz: 6 + Math.random() * 8, life: 1, kind: "dust", col: "#8a8478", g: 14 });
}

/** Sound and particles for the vision overlay's moments. */
export function onVisionCue(g: Game, c: VisionCue) {
  switch (c.t) {
    case "on": g.sfx.visionOn(); break;
    case "off": g.sfx.visionOff(); break;
    case "ping": if (c.n < 10) g.sfx.visionPing(c.category, c.pending, c.n); break;
    case "lock": {
      // the reading locks in: motes of the category's colour burst off the silhouette and drift up
      const col = VISION_CATEGORIES[c.target.category].color;
      for (let i = 0; i < 18; i++) {
        const edge = Math.random() < 0.5, px = c.x + (edge ? (Math.random() < 0.5 ? 0 : c.w) : Math.random() * c.w), py = c.y + (edge ? Math.random() * c.h : (Math.random() < 0.5 ? 0 : c.h));
        const zx = c.target.y - py;
        g.spawn({ x: px, y: c.target.y, z: zx, vx: (px - (c.x + c.w / 2)) * (1.5 + Math.random() * 2), vz: 6 + Math.random() * 16, life: 0.5 + Math.random() * 0.5, kind: "rune", col: Math.random() < 0.35 ? "#ffffff" : col, emit: true, g: -6 });
      }
      g.eyeBoost = Math.max(g.eyeBoost, 0.6);
      break;
    }
  }
}
