// Browser persistence: IndexedDB key-value store for save system v2 (world/saveStore.ts), with a localStorage
// fallback when IndexedDB is unavailable (private windows in some browsers), file export / import, and the v1
// single-slot helpers kept for the debug hook.
import { saveToStorage as save, loadFromStorage as load } from "../world/save";
import { MemoryKv, SaveManager, exportText, type KvStore } from "../world/saveStore";
import type { World } from "../world/world";

export const saveToStorage = (w: World) => save(w, localStorage);
export const loadFromStorage = () => load(localStorage);

const DB = "dustwake", STORE = "kv";

export class IdbKv implements KvStore {
  private db: Promise<IDBDatabase>;
  constructor() {
    this.db = new Promise((res, rej) => {
      const r = indexedDB.open(DB, 1);
      r.onupgradeneeded = () => r.result.createObjectStore(STORE);
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
  }
  private async tx<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
    const db = await this.db;
    return new Promise((res, rej) => {
      const req = fn(db.transaction(STORE, mode).objectStore(STORE));
      req.onsuccess = () => res(req.result);
      req.onerror = () => rej(req.error);
    });
  }
  get(k: string) { return this.tx<string | undefined>("readonly", (s) => s.get(k) as IDBRequest<string | undefined>); }
  async set(k: string, v: string) { await this.tx("readwrite", (s) => s.put(v, k)); }
  async del(k: string) { await this.tx("readwrite", (s) => s.delete(k)); }
  async keys() { return (await this.tx("readonly", (s) => s.getAllKeys())).map(String); }
}

/** localStorage-backed store (fallback). */
export class LocalKv implements KvStore {
  constructor(private prefix = "dustwake.v2.") {}
  async get(k: string) { return localStorage.getItem(this.prefix + k) ?? undefined; }
  async set(k: string, v: string) { localStorage.setItem(this.prefix + k, v); }
  async del(k: string) { localStorage.removeItem(this.prefix + k); }
  async keys() { return Object.keys(localStorage).filter((k) => k.startsWith(this.prefix)).map((k) => k.slice(this.prefix.length)); }
}

/** The browser's save manager: IndexedDB if it opens, else localStorage, else memory (nothing persists). */
export function browserSaves(): SaveManager {
  let kv: KvStore;
  try { kv = typeof indexedDB !== "undefined" ? new IdbKv() : typeof localStorage !== "undefined" ? new LocalKv() : new MemoryKv(); }
  catch { kv = new MemoryKv(); }
  return new SaveManager(kv);
}

/** Offer the world as a downloaded file. */
export function downloadSave(w: World) {
  const blob = new Blob([exportText(w)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `dustwake-day${Math.floor(w.day) + 1}-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-")}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

/** Ask the player for a save file; resolves with its text (or null if cancelled). */
export function pickSaveFile(): Promise<string | null> {
  return new Promise((res) => {
    const input = document.createElement("input");
    input.type = "file"; input.accept = ".json,application/json";
    input.onchange = () => { const f = input.files?.[0]; if (!f) return res(null); f.text().then(res, () => res(null)); };
    input.click();
  });
}
