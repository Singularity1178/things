// Content linter (Phase 0.8). No DOM. Runs a rule set over every content row and returns readable issues; the test
// suite fails on any (tests/contentLint.test.ts). It generalises the data-resolution checks that already existed
// per system (every shop step resolves, every line fits the font) to all tables: a new table adds a rule here.
import { ITEMS } from "./items";
import { PROPS } from "./props";
import { RECIPES } from "./build";
import { CRAFT_RECIPES, STATIONS } from "./crafting";
import { THOUGHTS } from "./monologue";
import { EXCHANGES, PEER_MAX } from "./talk";
import { CENSUS, ARCHETYPES } from "./folk";
import { FONT_GLYPHS, textWidth } from "../font";
import { measure, FONT2_GLYPHS } from "../ui2/font2";
import { OPTIONS, ACTIONS } from "../settings";
import { AREAS } from "../world/areas";
import { AREA_KINDS, type AreaSpec } from "../world/areaSpec";
import { T } from "./tiles";

export interface LintIssue { table: string; row: string; rule: string; detail: string }

/** Characters the world's bitmap font cannot draw (it uppercases first). */
export const undrawable = (s: string) => [...new Set([...s.toUpperCase()].filter((c) => !FONT_GLYPHS.has(c)))];
const undrawable2 = (s: string) => [...new Set([...s].filter((c) => !FONT2_GLYPHS.has(c)))];

export function lintContent(): LintIssue[] {
  const out: LintIssue[] = [];
  const bad = (table: string, row: string, rule: string, detail: string) => out.push({ table, row, rule, detail });
  const text = (table: string, row: string, s: string | undefined, maxW?: number) => {
    if (s === undefined) return;
    const u = undrawable(s);
    if (u.length) bad(table, row, "font", `cannot draw ${JSON.stringify(u.join(""))} in "${s.slice(0, 40)}"`);
    if (maxW && textWidth(s) > maxW) bad(table, row, "width", `"${s}" is ${textWidth(s)}px, over ${maxW}px`);
  };
  const item = (table: string, row: string, id: string | undefined | null) => { if (id && !(id in ITEMS)) bad(table, row, "ref", `unknown item "${id}"`); };

  for (const [id, it] of Object.entries(ITEMS)) {
    if (!it.name) bad("ITEMS", id, "required", "no name");
    text("ITEMS", id, it.name, 150);
    if ((it.stack ?? 1) < 1) bad("ITEMS", id, "range", `stack ${it.stack}`);
  }
  for (const [id, p] of Object.entries(PROPS)) {
    text("PROPS", id, (p as { examine?: string }).examine);
    if (p.box && (p.box[0] <= 0 || p.box[1] <= 0)) bad("PROPS", id, "range", `box ${p.box}`);
  }
  for (const [id, r] of Object.entries(RECIPES)) {
    text("RECIPES", id, r.name, 150);
    r.desc.forEach((l, i) => text("RECIPES", `${id}.desc${i}`, l, 34 * 4));
    if (!(r.prop in PROPS)) bad("RECIPES", id, "ref", `unknown prop "${r.prop}"`);
    for (const c of r.cost) { item("RECIPES", id, c.item); if (c.n <= 0) bad("RECIPES", id, "range", `cost ${c.n} x ${c.item}`); }
  }
  for (const r of CRAFT_RECIPES) {
    text("CRAFT_RECIPES", r.id, r.name, 150);
    r.desc.forEach((l, i) => text("CRAFT_RECIPES", `${r.id}.desc${i}`, l, 30 * 4));
    if (!(r.station in STATIONS)) bad("CRAFT_RECIPES", r.id, "ref", `unknown station "${r.station}"`);
    for (const c of r.inputs) item("CRAFT_RECIPES", r.id, c.item);
    for (const t of r.tools ?? []) item("CRAFT_RECIPES", r.id, t);
    for (const c of r.also ?? []) item("CRAFT_RECIPES", r.id, c.item);
    item("CRAFT_RECIPES", r.id, r.output.item);
    if (r.output.n <= 0) bad("CRAFT_RECIPES", r.id, "range", `output n ${r.output.n}`);
  }
  for (const [id, l] of Object.entries(THOUGHTS)) text("THOUGHTS", id, l.text);
  for (const e of EXCHANGES) for (const [i, l] of e.lines.entries()) {
    const s = typeof l === "string" ? l : (l as { text?: string; say?: string }).text ?? (l as { say?: string }).say;
    if (typeof s !== "string") continue;
    // placeholders ({name}) are filled at run time; lint the template's literal characters only
    text("EXCHANGES", `${e.id}.${i}`, s.replace(/\{[^}]*\}/g, "X"));
    if (s.length > PEER_MAX + 20) bad("EXCHANGES", `${e.id}.${i}`, "length", `${s.length} chars`);
  }
  const ids = new Set<string>();
  for (const r of CENSUS) {
    if (ids.has(r.id)) bad("CENSUS", r.id, "unique", "duplicate id"); ids.add(r.id);
    if (!(r.archetype in ARCHETYPES)) bad("CENSUS", r.id, "ref", `unknown archetype "${r.archetype}"`);
    if (!(r.area in AREAS)) bad("CENSUS", r.id, "ref", `unknown area "${r.area}"`);
  }
  // the settings registry and the UI font
  for (const o of OPTIONS) { const u = undrawable2(o.label + (o.hint ?? "")); if (u.length) bad("OPTIONS", o.id, "font2", `cannot draw ${u.join("")}`); if (measure(o.label) > 200) bad("OPTIONS", o.id, "width", o.label); }
  const keys = new Set<string>();
  for (const a of ACTIONS) { if (keys.has(a.key)) bad("ACTIONS", a.id, "unique", `default key "${a.key}" bound twice`); keys.add(a.key); }
  // every portal leads somewhere that exists (authored areas)
  for (const [id, build] of Object.entries(AREAS)) {
    if (id.startsWith("debug_")) continue;
    const a = build();
    for (const p of a.portals ?? []) {
      if (!(p.to.area in AREAS)) { bad("AREAS", `${id}.${p.id}`, "ref", `portal to unknown area "${p.to.area}"`); continue; }
      if (!p.to.portal.startsWith("@") && !(AREAS[p.to.area]().portals ?? []).some((q) => q.id === p.to.portal)) bad("AREAS", `${id}.${p.id}`, "ref", `no portal "${p.to.portal}" in ${p.to.area}`);
    }
  }
  // generated area kinds: deterministic, walkable start, an exit
  for (const [kind, k] of Object.entries(AREA_KINDS)) for (const seed of [1, 99, 123456]) {
    const spec: AreaSpec = { id: `lint~${kind}`, kind, seed, w: k.min[0] + 16, h: k.min[1] + 10, parent: "surface", depth: 1, entry: { x: 100, y: 100 } };
    const a = k.build(spec), b = k.build(spec);
    if (a.grid.join() !== b.grid.join() || JSON.stringify(a.props) !== JSON.stringify(b.props)) bad("AREA_KINDS", `${kind}#${seed}`, "deterministic", "two builds differ");
    const sx = Math.floor(a.start.x / 16), sy = Math.floor(a.start.y / 16);
    if (a.grid[sy * a.w + sx] !== T.FLOOR) bad("AREA_KINDS", `${kind}#${seed}`, "start", "start tile is not floor");
    if (!(a.portals ?? []).some((p) => p.id === "exit")) bad("AREA_KINDS", `${kind}#${seed}`, "exit", "no exit portal");
    for (const p of a.props) if (!(p.kind in PROPS)) bad("AREA_KINDS", `${kind}#${seed}`, "ref", `unknown prop "${p.kind}"`);
  }
  return out;
}
