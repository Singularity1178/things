"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The inner monologue (sim side) and the opening cutscene that uses it:
// line data lint, one-shot and cooldown rules, the three ways a line fires
// (event triggers, the `think` effect, the `think` command), the shipped
// power lines through real interactions, save/load and the v10 -> v11 migration, the
// Primer's note, and the intro script played through the real host.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const g0 = globalThis;
g0.localStorage ?? (g0.localStorage = { getItem: () => null, setItem: () => { }, removeItem: () => { } });
const monologue_1 = require("../src/game/content/monologue");
const cutscenes_1 = require("../src/game/content/cutscenes");
const flags_1 = require("../src/game/content/flags");
const font_1 = require("../src/game/font");
const zoom_1 = require("../src/game/view/zoom");
const monologue_2 = require("../src/game/ui/monologue");
const cutscene_1 = require("../src/game/ui/cutscene");
const intro_1 = require("../src/game/screens/intro");
const monologue_3 = require("../src/game/sim/monologue");
const tasks_1 = require("../src/game/sim/tasks");
const commands_1 = require("../src/game/sim/commands");
const inventory_1 = require("../src/game/sim/inventory");
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const debugFoundations_1 = require("../src/game/sim/debugFoundations");
const game_1 = require("../src/game/game");
const helpers_1 = require("./helpers");
(0, debugFoundations_1.registerFoundations)();
const thoughts = (evs) => evs.filter((e) => e.t === "thought").map((e) => e.line);
/** Add a line for one test only: adding a line is a data row. */
function withLine(id, line, fn) {
    monologue_1.THOUGHTS[id] = line;
    try {
        return fn();
    }
    finally {
        delete monologue_1.THOUGHTS[id];
    }
}
// ------------------------------------------------------------------ data
(0, node_test_1.test)("every line is font-safe, fits the HUD, and names only known conditions", () => {
    for (const [id, l] of Object.entries(monologue_1.THOUGHTS)) {
        for (const ch of l.text)
            strict_1.default.ok(font_1.FONT_GLYPHS.has(ch), `${id}: "${ch}" is not in the bitmap font`);
        strict_1.default.ok(monologue_2.MONO.x + 6 + (0, font_1.textWidth)(l.text) + 4 <= zoom_1.BASE_W - 6, `${id} is too wide for the screen`);
        for (const c of l.if ?? [])
            strict_1.default.ok(monologue_3.THOUGHT_CONDITIONS[c], `${id}: unknown condition ${c}`);
        if (l.cooldown)
            strict_1.default.equal(l.once, false, `${id}: only recurring lines have a cooldown`);
        strict_1.default.ok(!l.pace || (l.pace > 0.2 && l.pace <= 2), `${id}: sane pace`);
    }
});
(0, node_test_1.test)("the opening's lines exist, read as the brief asks, and the script names only known lines and cues", () => {
    const said = (0, cutscene_1.timeline)(cutscenes_1.INTRO).filter((b) => b.think).map((b) => monologue_1.THOUGHTS[b.think]?.text);
    strict_1.default.deepEqual(said, ["ASSESSING...", "MILD DAMAGE DETECTED.", "MISSING LEFT ARM.", "PRIME DIRECTIVE: NONE."]);
    for (const b of cutscenes_1.INTRO.beats)
        for (const c of b.cues ?? [])
            strict_1.default.ok(intro_1.CUTSCENE_CUES[c], `unknown cue ${c}`);
    const tl = (0, cutscene_1.timeline)(cutscenes_1.INTRO);
    strict_1.default.equal(tl.filter((b) => b.control).length, 1, "exactly one hand-over");
    strict_1.default.ok(tl[tl.length - 1].control, "control is the last beat");
    for (let i = 1; i < tl.length; i++)
        strict_1.default.ok(tl[i].at > tl[i - 1].at, "beats strictly ordered");
});
(0, node_test_1.test)("cutscene timeline: the awakening keeps its timing, diagnostics run 2-3 s, control comes after the last line", () => {
    const at = (label) => (0, cutscene_1.timeline)(cutscenes_1.INTRO).find((b) => b.label === label).at;
    const near = (a, b) => Math.abs(a - b) < 1e-9;
    strict_1.default.ok(near(at("spark"), 0.8) && near(at("boot"), 1.2) && near(at("eye lit"), 3.5) && near(at("rise"), 3.6) && near(at("foot down"), 4.2));
    const diag = at("diagnostics done") - at("assessing");
    strict_1.default.ok(diag >= 2 && diag <= 3, `diagnostics last ${diag}s`);
    strict_1.default.equal((0, cutscene_1.trackAt)(cutscenes_1.INTRO, "core", at("assessing") + 1).mode, "diagnose");
    strict_1.default.equal((0, cutscene_1.trackAt)(cutscenes_1.INTRO, "core", at("diagnostics done") + 0.01).mode, "on");
    strict_1.default.ok(near((0, cutscene_1.trackAt)(cutscenes_1.INTRO, "body", at("rise") + 0.7).k, 0.5), "the rise ramps over its `over`");
    strict_1.default.ok(at("assessing") >= at("rise") + 1.4, "it thinks only once it has risen");
    // the last line has finished typing (at the presentation's pace) before control
    const last = (0, cutscene_1.timeline)(cutscenes_1.INTRO).find((b) => b.think === "intro.directive");
    const typed = last.at + monologue_2.MONO.lead + monologue_1.THOUGHTS[last.think].text.length / (monologue_2.MONO.cps * (monologue_1.THOUGHTS[last.think].pace ?? 1));
    strict_1.default.ok((0, cutscene_1.controlAt)(cutscenes_1.INTRO) > typed + 0.3, "a held beat after the last line");
    strict_1.default.ok((0, cutscene_1.controlAt)(cutscenes_1.INTRO) < 13, "not slow");
    // a frame straddling a beat fires it exactly once
    strict_1.default.deepEqual((0, cutscene_1.beatsCrossed)(cutscenes_1.INTRO, 0.79, 0.81).map((b) => b.label), ["spark"]);
    strict_1.default.deepEqual((0, cutscene_1.beatsCrossed)(cutscenes_1.INTRO, 0.81, 0.83), []);
});
// ------------------------------------------------------------------ rules
(0, node_test_1.test)("think: emits a thought for the player, one-shot lines never repeat, other actors don't think", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    strict_1.default.equal((0, monologue_3.think)(w, pl, "intro.damage"), true);
    strict_1.default.deepEqual(thoughts((0, helpers_1.events)(w)), ["intro.damage"]);
    strict_1.default.equal((0, monologue_3.think)(w, pl, "intro.damage"), false);
    strict_1.default.equal((0, monologue_3.thoughtBlocked)(w, pl, "intro.damage"), "said");
    strict_1.default.deepEqual((0, helpers_1.events)(w), []);
    strict_1.default.equal((0, monologue_3.think)(w, pl, "no.such.line"), false);
    const guardian = (0, world_1.actorById)(w, helpers_1.GUARDIAN);
    strict_1.default.equal((0, monologue_3.think)(w, guardian, "intro.arm"), false, "only the player golem thinks");
    strict_1.default.ok((0, monologue_3.hasThought)(w, "intro.damage") && !(0, monologue_3.hasThought)(w, "intro.arm"));
});
(0, node_test_1.test)("recurring lines respect their cooldown on sim time; `when` and `if` gate a line", () => {
    withLine("t.recur", { text: "AGAIN.", once: false, cooldown: 2 }, () => withLine("t.gated", { text: "KNOWN.", when: { flags: [flags_1.FLAGS.knowBuild] } }, () => {
        const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
        strict_1.default.ok((0, monologue_3.think)(w, pl, "t.recur"));
        strict_1.default.ok(!(0, monologue_3.think)(w, pl, "t.recur"), "cooling down");
        (0, helpers_1.frames)(w, 61); // ~1 s
        strict_1.default.equal((0, monologue_3.thoughtBlocked)(w, pl, "t.recur"), "cooldown");
        (0, helpers_1.frames)(w, 70);
        strict_1.default.ok((0, monologue_3.think)(w, pl, "t.recur"), "fires again after 2 s of sim time");
        strict_1.default.equal((0, monologue_3.thoughtBlocked)(w, pl, "t.gated"), "when");
        (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
        strict_1.default.ok((0, monologue_3.think)(w, pl, "t.gated"));
    }));
});
(0, node_test_1.test)("event triggers: a data row with `on` fires from the matching player event, with field matching", () => {
    withLine("t.surface", { text: "OPEN SKY.", on: { event: "areaEntered", match: { area: "surface" } } }, () => {
        const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
        const other = (0, world_1.makeActor)("other", "worker_golem", "dungeon", pl.x + 40, pl.y);
        w.actors.push(other);
        (0, world_1.enterArea)(w, other, "surface", 100, 100);
        (0, helpers_1.frame)(w);
        strict_1.default.deepEqual(thoughts((0, helpers_1.events)(w)), [], "another actor's event is not the golem's thought");
        (0, world_1.enterArea)(w, pl, "dungeon", pl.x, pl.y);
        (0, helpers_1.frame)(w);
        strict_1.default.deepEqual(thoughts((0, helpers_1.events)(w)), [], "field match: the wrong area");
        (0, world_1.enterArea)(w, pl, "surface", 100, 100);
        (0, helpers_1.frame)(w);
        strict_1.default.deepEqual(thoughts((0, helpers_1.events)(w)), ["t.surface"]);
        (0, world_1.enterArea)(w, pl, "dungeon", 100, 100);
        (0, world_1.enterArea)(w, pl, "surface", 100, 100);
        (0, helpers_1.frame)(w);
        strict_1.default.deepEqual(thoughts((0, helpers_1.events)(w)), [], "one-shot");
    });
});
(0, node_test_1.test)("events from paused-world commands are seen when the host drains: reading the Primer", () => {
    withLine("t.learned", { text: "PATTERNS STORED.", on: { event: "learned", match: { flag: flags_1.FLAGS.knowBuild } } }, () => {
        const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
        (0, inventory_1.addItems)(w, pl, "book_build", 1);
        (0, commands_1.readItem)(w, pl, "book_build"); // the book screen, world paused
        (0, monologue_3.reactToEvents)(w); // what Game.drainEvents does first
        const evs = (0, helpers_1.events)(w);
        strict_1.default.deepEqual(evs.map((e) => e.t), ["learned", "thought"]);
        (0, commands_1.readItem)(w, pl, "book_build");
        (0, monologue_3.reactToEvents)(w);
        strict_1.default.deepEqual((0, helpers_1.events)(w), [], "learning is once; so is the thought");
    });
});
(0, node_test_1.test)("the `think` effect op: interaction rules, schedules and beats can fire lines as data", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    strict_1.default.equal((0, tasks_1.applyEffect)(w, pl, { op: "think", line: "intro.arm" }), true);
    strict_1.default.deepEqual(thoughts((0, helpers_1.events)(w)), ["intro.arm"]);
    strict_1.default.equal((0, tasks_1.applyEffect)(w, pl, { op: "think", line: "intro.arm" }), false);
});
(0, node_test_1.test)("golem vision: analyzing a buildable thinks OBJECT ANALYZED. once per analysis", () => {
    const w = (0, world_1.createWorld)(12), area = (0, world_1.getArea)(w, "debug_workshop"), pl = (0, world_1.player)(w), chest = area.prop("chest.fixture");
    (0, world_1.enterArea)(w, pl, area.id, chest.x, chest.y + 11);
    pl.facing = "up";
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    (0, helpers_1.events)(w);
    (0, helpers_1.frame)(w, { ix: 0, iy: 0, use: true, toggleScan: true });
    (0, helpers_1.frames)(w, 90);
    const evs = (0, helpers_1.events)(w);
    strict_1.default.ok(evs.some((e) => e.t === "analyzed"));
    strict_1.default.deepEqual(thoughts(evs), ["vision.analyzed"]);
    strict_1.default.equal(monologue_1.THOUGHTS["vision.analyzed"].text, "OBJECT ANALYZED.");
});
(0, node_test_1.test)("the power lines ship: E on the dormant worker golem, and the guardian holding the ruby core (C, then talk)", () => {
    const dormant = monologue_1.THOUGHTS["golem.dormant"], weak = monologue_1.THOUGHTS["golem.underpowered"];
    strict_1.default.equal(dormant.text, "INTEGRITY INTACT, MISSING POWER SOURCE.");
    strict_1.default.deepEqual((0, monologue_1.thoughtTriggers)(dormant).map((t) => t.event), ["dormantTouched"], "dormantTouched only: subjectNoPower also holds for the unpowered guardian");
    strict_1.default.deepEqual(dormant.if, ["subjectNoPower"]);
    strict_1.default.equal(weak.text, "INSUFFICIENT POWER SOURCE.");
    strict_1.default.deepEqual((0, monologue_1.thoughtTriggers)(weak).map((t) => t.event), ["manageActor", "talkedTo", "coreSlotted"]);
    strict_1.default.deepEqual(weak.if, ["subjectWeakPower"]);
    // the dormant golem in the artificery: walking up to it and pressing E
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), worker = (0, world_1.actorById)(w, "npc.worker.artificery");
    const at = () => (0, helpers_1.find)(w, (i) => i.actorId === worker.id);
    (0, helpers_1.events)(w);
    (0, helpers_1.useOn)(w, at());
    strict_1.default.deepEqual(thoughts((0, helpers_1.events)(w)), ["golem.dormant"]);
    // powered (C slots the core), it is just a worker: nothing to think
    (0, inventory_1.addItems)(w, pl, "ruby_core", 1);
    (0, helpers_1.frame)(w, { ix: 0, iy: 0, use: false, core: true });
    (0, helpers_1.frames)(w, 150);
    strict_1.default.equal(worker.powerCore, "ruby_core");
    (0, helpers_1.events)(w);
    (0, helpers_1.useOn)(w, at());
    strict_1.default.deepEqual(thoughts((0, helpers_1.events)(w)), []);
    // the guardian takes a ruby core (it fits) but its body needs more: thought as it goes in, and on talking
    const v = (0, helpers_1.newWorld)(), gp = (0, world_1.player)(v), it = (0, helpers_1.guardianIt)(v), guardian = (0, world_1.actorById)(v, helpers_1.GUARDIAN);
    (0, inventory_1.addItems)(v, gp, "ruby_core", 1);
    (0, helpers_1.standAt)(v, it);
    (0, helpers_1.events)(v);
    (0, helpers_1.frame)(v, { ix: 0, iy: 0, use: false, core: true });
    (0, helpers_1.frames)(v, 150);
    strict_1.default.equal(guardian.powerCore, "ruby_core");
    strict_1.default.deepEqual(thoughts((0, helpers_1.events)(v)), ["golem.underpowered"]);
    (0, helpers_1.useOn)(v, it);
    const evs = (0, helpers_1.events)(v);
    strict_1.default.ok(evs.some((e) => e.t === "dialogue"), "the dialogue still opens");
    strict_1.default.deepEqual(thoughts(evs), ["golem.underpowered"]);
});
// ------------------------------------------------------------------ saves
(0, node_test_1.test)("monologue state saves and loads: one-shot lines stay said, cooldowns carry over, worlds stay identical", () => {
    withLine("t.recur", { text: "AGAIN.", once: false, cooldown: 5 }, () => {
        const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
        (0, monologue_3.think)(w, pl, "intro.assessing");
        (0, monologue_3.think)(w, pl, "t.recur");
        (0, helpers_1.frames)(w, 30);
        const s = (0, save_1.serialize)(w);
        strict_1.default.deepEqual(s.monologue.said, ["intro.assessing"]);
        const w2 = (0, save_1.deserialize)(JSON.parse(JSON.stringify(s)));
        strict_1.default.deepEqual((0, save_1.serialize)(w2), s, "round trip");
        strict_1.default.equal((0, monologue_3.think)(w2, (0, world_1.player)(w2), "intro.assessing"), false, "a one-shot line doesn't repeat after load");
        strict_1.default.equal((0, monologue_3.thoughtBlocked)(w2, (0, world_1.player)(w2), "t.recur"), "cooldown", "the cooldown survives");
        // same inputs after the load give the same world
        (0, helpers_1.frames)(w, 400);
        (0, helpers_1.frames)(w2, 400);
        strict_1.default.equal((0, monologue_3.think)(w, (0, world_1.player)(w), "t.recur"), (0, monologue_3.think)(w2, (0, world_1.player)(w2), "t.recur"));
        strict_1.default.deepEqual((0, save_1.serialize)(w2), (0, save_1.serialize)(w));
    });
});
(0, node_test_1.test)("v10 -> v11: the migration adds an empty monologue; a migrated save plays on", () => {
    strict_1.default.equal(save_1.SAVE_VERSION, 20); // v18: townsfolk (tests/folk.test.ts); v19: shops (tests/shops.test.ts)
    const w = (0, helpers_1.newWorld)();
    const s = (0, save_1.serialize)(w);
    s.version = 10;
    delete s.monologue;
    const m = (0, save_1.migrate)(s);
    strict_1.default.equal(m.version, 20);
    strict_1.default.deepEqual(m.monologue, { said: [], ready: {} });
    const w2 = (0, save_1.deserialize)(s);
    strict_1.default.deepEqual((0, save_1.serialize)(w2), (0, save_1.serialize)(w));
    strict_1.default.ok((0, monologue_3.playerThinks)(w2, "intro.arm"));
});
// ------------------------------------------------------------------ the Primer
(0, node_test_1.test)("the Builder's Primer: the learned event brings YOU LEARNED TO BUILD., once", () => {
    strict_1.default.equal((0, flags_1.learnedText)(flags_1.FLAGS.knowBuild), "YOU LEARNED TO BUILD.");
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, inventory_1.addItems)(w, pl, "book_build", 1);
    (0, commands_1.readItem)(w, pl, "book_build");
    (0, commands_1.readItem)(w, pl, "book_build");
    strict_1.default.deepEqual((0, helpers_1.events)(w).filter((e) => e.t === "learned"), [{ t: "learned", flag: flags_1.FLAGS.knowBuild }]);
});
// ------------------------------------------------------------------ the opening, through the host
const canvas = () => globalThis.document.createElement("canvas");
const DT = 1 / 60;
function playIntro(g) {
    g.keyDown("x");
    g.update(DT);
    g.keyUp("x");
    strict_1.default.ok(g.screens.is("intro"));
    const start = g.pl.x;
    let t = 0, handed = -1;
    const order = [];
    g.keyDown("d"); // held the whole time: it must not move the golem before control
    while (t < 20) {
        g.update(DT);
        t += DT;
        for (const id of g.world.monologue.said)
            if (!order.includes(id))
                order.push(id);
        if (g.screens.is("play")) {
            handed = t;
            break;
        }
        strict_1.default.equal(g.pl.x, start, "no control during the cutscene");
    }
    g.keyUp("d");
    return { handed, order };
}
(0, node_test_1.test)("the opening plays its lines in order and hands control over at the control beat; R replays it, loading doesn't", () => {
    const g = new game_1.Game(canvas(), canvas());
    const { handed, order } = playIntro(g);
    strict_1.default.ok(Math.abs(handed - (0, cutscene_1.controlAt)(cutscenes_1.INTRO)) < 2 * DT, `control at ${handed}`);
    strict_1.default.deepEqual(order, ["intro.assessing", "intro.damage", "intro.arm", "intro.directive"]);
    strict_1.default.deepEqual(g.monologue.lines.map((l) => l.text), ["ASSESSING...", "MILD DAMAGE DETECTED.", "MISSING LEFT ARM.", "PRIME DIRECTIVE: NONE."], "the list is still up as control is handed over");
    strict_1.default.ok(g.monologue.lines.every((l) => l.done), "fully typed");
    strict_1.default.equal(g.monologue.pinned, false, "and now free to fade");
    for (let i = 0; i < 60 * 12; i++)
        g.update(DT);
    strict_1.default.equal(g.monologue.lines.length, 0, "the list fades in play");
    // control: the golem moves
    const x0 = g.pl.x;
    g.keyDown("d");
    for (let i = 0; i < 30; i++)
        g.update(DT);
    g.keyUp("d");
    strict_1.default.ok(g.pl.x > x0);
    // Wake again (R at the chapter card that ends the crossing): a fresh world, the whole opening again.
    // (The crossing itself, played through from a real first jump, is tests/daycycle.test.ts.)
    const s = g.S;
    g.crossingUi.start();
    while (g.crossingUi.screen.t < g.crossingUi.at.chapter + g.crossingUi.script.promptAfter + 0.1)
        g.update(DT);
    strict_1.default.ok(g.screens.is("crossing"), "the chapter card holds for a key");
    g.keyDown("r");
    g.update(DT);
    g.keyUp("r");
    strict_1.default.ok(g.screens.is("intro"));
    g.screens.set(s.title);
    const again = playIntro(g);
    strict_1.default.deepEqual(again.order, order);
    // a loaded save resumes straight into play: no cutscene, no opening thoughts
    const saved = (0, save_1.serialize)(g.world);
    const h = new game_1.Game(canvas(), canvas());
    h.resume((0, save_1.deserialize)(saved));
    strict_1.default.ok(h.screens.is("play"));
    for (let i = 0; i < 60 * 3; i++)
        h.update(DT);
    strict_1.default.ok(h.screens.is("play"));
    strict_1.default.equal(h.monologue.lines.length, 0);
});
(0, node_test_1.test)("presentation model: lines type one at a time, hold while pinned, and fade once released", () => {
    const log = new monologue_2.MonologueLog();
    log.pinned = true;
    log.push("intro.damage");
    log.push("intro.arm");
    for (let i = 0; i < 20; i++)
        log.update(DT);
    strict_1.default.equal(log.lines.length, 1, "the second waits for the first");
    for (let i = 0; i < 300; i++)
        log.update(DT);
    strict_1.default.equal(log.lines.length, 2);
    for (let i = 0; i < 1200; i++)
        log.update(DT);
    strict_1.default.equal(log.lines.length, 2, "pinned lines hold");
    log.release();
    for (let i = 0; i < 1200; i++)
        log.update(DT);
    strict_1.default.equal(log.lines.length, 0);
});
