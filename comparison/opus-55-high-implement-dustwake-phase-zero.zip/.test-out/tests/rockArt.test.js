"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The rock and stair retexture: the surface's rocks, iron veins, boulders and outcrops (art/rocks.ts), the one
// stair drawn in three places (art/stairs.ts: its head on the surface, the flight in the halls, its foot in the
// Vestibule) and the dig stages where the stair head's fall shows. Own file: node --test runs each file in a
// fresh process, so the sprite cache starts empty and the traces don't depend on other tests.
//
// It is art only: no prop moved, changed size, changed footprint or changed id, no tile changed, and nothing
// that is saved changed, so there is no save version bump and no migration (pinned below). What moved among the
// existing goldens is told in tests/art.test.ts (the dungeon bake) and tests/artRegistry.test.ts (the props).
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const props_1 = require("../src/game/art/props");
const tiles_1 = require("../src/game/art/tiles");
const rocks_1 = require("../src/game/art/rocks");
const stairs_1 = require("../src/game/art/stairs");
const uiSnapshot_1 = require("./support/uiSnapshot");
const util_1 = require("../src/game/util");
const tiles_2 = require("../src/game/content/tiles");
const props_2 = require("../src/game/content/props");
const harvest_1 = require("../src/game/content/harvest");
const digging_1 = require("../src/game/content/digging");
const surface_1 = require("../src/game/surface");
const map_1 = require("../src/game/map");
const geography_1 = require("../src/game/content/geography");
const save_1 = require("../src/game/world/save");
// stair: moved deliberately when the stair below was redrawn with depth (docs/ARCHITECTURE.md: "The stair below, with
// depth"): the list it hashes lost `stairfoot` (the three steps that stood out in the Vestibule are gone) and gained
// the two `stairpost`s. The stair head's six stages in it are pixel for pixel as they were (was "e6925303").
const GOLDEN = { rocks: "9fc9a08c", stair: "5bef3221" };
const KINDS = Object.keys(rocks_1.ROCK_SEEDS);
/** One pass of one prop sprite with real pixels (the seed is art/props.ts makeProp's). */
function raster(kind, v, alt = false, emit = false) {
    let out;
    props_1.PROP_ART[kind](v, alt, (w, h, fn) => {
        out = new uiSnapshot_1.RCanvas(w, h);
        fn(new util_1.Pen(out.getContext(), emit), (0, util_1.mulberry)(kind.length * 101 + v * 13 + (alt ? 7 : 0)));
        return { a: out, e: out, w, h, ax: w >> 1, ay: h };
    });
    return out;
}
const key = (c) => (0, util_1.hex)(c).join(",");
/** The colour of an opaque pixel ("" where the sprite is clear or only shadowed). */
const at = (c, x, y) => { const i = (y * c.width + x) * 4; return c.data[i + 3] === 255 ? `${c.data[i]},${c.data[i + 1]},${c.data[i + 2]}` : ""; };
const lum = (c, x0, y0, x1, y1) => {
    let s = 0, n = 0;
    for (let y = y0; y <= y1; y++)
        for (let x = x0; x <= x1; x++) {
            const i = (y * c.width + x) * 4;
            s += c.data[i] + c.data[i + 1] + c.data[i + 2];
            n += 3;
        }
    return s / n;
};
/** A rock sprite read back: per pixel its tone (0 outline .. 5 ridge glint), -2 for ore, -1 for anything else. */
function tones(kind, v) {
    const c = raster(kind, v), ramp = (kind === "ironore" ? rocks_1.IRONSTONE : rocks_1.STONE).map(key), ore = rocks_1.ORE.map(key), t = [];
    for (let y = 0; y < c.height; y++)
        for (let x = 0; x < c.width; x++) {
            const k = at(c, x, y);
            t.push(ramp.includes(k) ? ramp.indexOf(k) : ore.includes(k) ? -2 : -1);
        }
    return { t, w: c.width, h: c.height };
}
(0, node_test_1.test)("the retextured sprites are pixel-stable", () => {
    (0, fakeCanvas_1.resetTrace)();
    for (const k of KINDS)
        for (let v = 0; v < 4; v++)
            for (const alt of [false, true])
                (0, props_1.propSprite)(k, v, alt);
    strict_1.default.equal((0, fakeCanvas_1.traceHash)(), GOLDEN.rocks);
    (0, fakeCanvas_1.resetTrace)();
    (0, props_1.propSprite)("stairpost", 0, false);
    (0, props_1.propSprite)("stairpost", 1, false);
    for (let v = 0; v <= 5; v++)
        (0, props_1.propSprite)("buriedgate", v, false);
    strict_1.default.equal((0, fakeCanvas_1.traceHash)(), GOLDEN.stair);
});
(0, node_test_1.test)("art only: sizes, footprints and what is harvested are as they were, and nothing saved changed", () => {
    strict_1.default.equal(save_1.SAVE_VERSION, 20, "the retexture changed no saved field (v15 is the stair's cheek walls, v16 raises its newel posts: tests/entrance.test.ts; v17 is routes: tests/routes.test.ts; v18 is townsfolk: tests/folk.test.ts; v20 is Phase 0: tests/phase0.test.ts)");
    strict_1.default.deepEqual(rocks_1.ROCK_SIZE, { rock: [22, 18], ironore: [22, 18], boulder: [28, 22], outcrop: [48, 32] });
    for (const k of KINDS) {
        const s = (0, props_1.propSprite)(k, 0, false);
        strict_1.default.deepEqual([s.w, s.h, s.ax, s.ay], [rocks_1.ROCK_SIZE[k][0], rocks_1.ROCK_SIZE[k][1], rocks_1.ROCK_SIZE[k][0] >> 1, rocks_1.ROCK_SIZE[k][1]], `${k}: size and anchor`);
    }
    strict_1.default.deepEqual([(0, props_2.propDef)("rock").box, (0, props_2.propDef)("ironore").box, (0, props_2.propDef)("boulder").box, (0, props_2.propDef)("outcrop").box], [[16, 8], [16, 8], [22, 9], [40, 12]]);
    strict_1.default.deepEqual(Object.keys(harvest_1.HARVEST).sort(), ["ironore", "log", "rock", "tree"], "boulders and outcrops stay scenery");
    for (const [k, w, h] of [["stairpost", 12, 19], ["buriedgate", 72, 58]]) {
        const s = (0, props_1.propSprite)(k, 0, false);
        strict_1.default.deepEqual([s.w, s.h], [w, h], k);
    }
    // every variant a builder places has a shape of its own, and the builders place what they placed
    const placed = (0, surface_1.buildSurface)().props.filter((p) => KINDS.includes(p.kind));
    for (const k of KINDS)
        strict_1.default.ok(placed.some((p) => p.kind === k), `${k} stands on the surface`);
    for (const p of placed)
        strict_1.default.ok(p.v >= 0 && p.v < rocks_1.ROCK_SEEDS[p.kind].length, `${p.id}: variant ${p.v} has a shape`);
    strict_1.default.equal(placed.filter((p) => p.kind === "ironore").length, 12);
});
(0, node_test_1.test)("a rock is cut stone: every tone of the ramp, lit from above, an outline all round, and no glow", () => {
    for (const k of KINDS)
        rocks_1.ROCK_SEEDS[k].forEach((_seed, v) => {
            const { t, w, h } = tones(k, v), rows = t.map((_x, i) => Math.floor(i / w));
            const solid = t.filter((x) => x !== -1).length;
            strict_1.default.ok(solid > w * h * 0.35, `${k} ${v}: the rock fills its sprite (${solid} px)`);
            for (let tone = 0; tone <= 5; tone++)
                strict_1.default.ok(t.includes(tone), `${k} ${v}: tone ${tone} is used`);
            // lit from above: the upper half of the rock is lighter than the lower (a vein's ore takes the place of lit stone)
            const ys = rows.filter((_y, i) => t[i] !== -1), mid = (Math.min(...ys) + Math.max(...ys)) / 2;
            const mean = (f) => { const l = t.filter((x, i) => x > 0 && f(rows[i])); return l.reduce((a, b) => a + b, 0) / l.length; };
            if (k !== "ironore")
                strict_1.default.ok(mean((y) => y < mid) > mean((y) => y >= mid), `${k} ${v}: the top is lighter than the foot`);
            // the sprite holds all of it (no face is cut off at the sprite's edge), and the outline closes it: the body's
            // stone never touches the clear sprite, only its outline (or what grows on it) does
            const c = raster(k, v);
            let cut = 0, open = 0;
            t.forEach((x, i) => {
                if (x <= 0)
                    return;
                const px = i % w, py = Math.floor(i / w);
                if (px === 0 || px === w - 1 || py === 0 || py === h - 1) {
                    cut++;
                    return;
                }
                if ([[px - 1, py], [px + 1, py], [px, py - 1], [px, py + 1]].some(([qx, qy]) => at(c, qx, qy) === ""))
                    open++;
            });
            strict_1.default.equal(cut, 0, `${k} ${v}: the rock stands inside its sprite`);
            strict_1.default.equal(open, 0, `${k} ${v}: the outline is closed`);
            const e = raster(k, v, false, true);
            strict_1.default.ok(e.data.every((x, i) => i % 4 === 3 || x === 0), `${k} ${v}: nothing glows`);
        });
});
(0, node_test_1.test)("no two rocks are the same shape, and a shape is its seed", () => {
    for (const k of KINDS) {
        const masks = rocks_1.ROCK_SEEDS[k].map((_s, v) => tones(k, v).t.map((x) => x !== -1));
        for (let a = 0; a < masks.length; a++)
            for (let b = a + 1; b < masks.length; b++) {
                const d = masks[a].filter((x, i) => x !== masks[b][i]).length;
                strict_1.default.ok(d >= 40, `${k} ${a} and ${b}: silhouettes differ (${d} px)`);
            }
        strict_1.default.equal(new Set(rocks_1.ROCK_SEEDS[k]).size, rocks_1.ROCK_SEEDS[k].length, `${k}: one seed a variant`);
    }
    // the form draws on nothing but its seed: the same chunks every time, other chunks for another seed or kind
    strict_1.default.deepEqual((0, rocks_1.rockForm)("rock", 4), (0, rocks_1.rockForm)("rock", 4));
    strict_1.default.notDeepEqual((0, rocks_1.rockForm)("rock", 4), (0, rocks_1.rockForm)("rock", 5));
    strict_1.default.notDeepEqual((0, rocks_1.rockForm)("rock", 4), (0, rocks_1.rockForm)("boulder", 4));
    // kinds differ in build: a vein is three pieces (tooth, shelf, fallen piece), an outcrop four
    strict_1.default.equal((0, rocks_1.rockForm)("ironore", 1).length, 3);
    strict_1.default.equal((0, rocks_1.rockForm)("outcrop", 1).length, 4);
    // a chunk is planes with unit normals; the last is its top, facing the sky
    const c = (0, rocks_1.chunk)((0, util_1.mulberry)(1), 10, 10, 8, 4, 9, { sides: 6, shoulders: 3 });
    strict_1.default.equal(c.n.length, 10);
    for (const n of c.n)
        strict_1.default.ok(Math.abs(Math.hypot(n[0], n[1], n[2]) - 1) < 1e-9);
    strict_1.default.ok(c.n[9][2] > 0.9);
});
(0, node_test_1.test)("an iron vein is dark ironstone with the ore in it; no other rock has any", () => {
    rocks_1.STONE.forEach((c, i) => { if (i > 0)
        strict_1.default.ok((0, util_1.hex)(rocks_1.IRONSTONE[i]).reduce((a, b) => a + b) < (0, util_1.hex)(c).reduce((a, b) => a + b), `ironstone tone ${i} is darker than stone`); });
    rocks_1.ROCK_SEEDS.ironore.forEach((_s, v) => {
        const c = raster("ironore", v), { t } = tones("ironore", v), ore = t.filter((x) => x === -2).length, solid = t.filter((x) => x !== -1).length;
        strict_1.default.ok(ore / solid > 0.08 && ore / solid < 0.28, `vein ${v}: ore is ${Math.round((ore / solid) * 100)}% of the rock: seams in stone, not a lump of it`);
        // a seam cuts lit and shaded faces alike, so it shows in more than one of its colours; the stain is below ore
        const seen = new Set();
        for (let y = 0; y < c.height; y++)
            for (let x = 0; x < c.width; x++)
                seen.add(at(c, x, y));
        strict_1.default.ok([rocks_1.ORE[0], rocks_1.ORE[1], rocks_1.ORE[2]].filter((o) => seen.has(key(o))).length >= 2, `vein ${v}: the seam is shaded with the face it crosses`);
        for (let y = 1; y < c.height; y++)
            for (let x = 0; x < c.width; x++)
                if (at(c, x, y) === key(rocks_1.ORE[4]))
                    strict_1.default.ok(rocks_1.ORE.slice(0, 4).map(key).includes(at(c, x, y - 1)), `vein ${v}: rust at ${x},${y} runs down from ore`);
    });
    for (const k of ["rock", "boulder", "outcrop"])
        rocks_1.ROCK_SEEDS[k].forEach((_s, v) => strict_1.default.ok(!tones(k, v).t.includes(-2), `${k} ${v}: no ore`));
    // broken up, a vein leaves chips flecked with ore and a rock leaves plain ones
    const chips = (kind) => { const c = raster(kind, 0, true); let n = 0; for (let y = 0; y < c.height; y++)
        for (let x = 0; x < c.width; x++)
            if (rocks_1.ORE.map(key).includes(at(c, x, y)))
                n++; return n; };
    strict_1.default.ok(chips("ironore") > 0);
    strict_1.default.equal(chips("rock"), 0);
});
(0, node_test_1.test)("a step is a solid: a lit lip, then a steady fall into the shadow of the step above", () => {
    strict_1.default.equal(stairs_1.STEP, tiles_2.TS / 2, "two steps to a tile");
    for (let pitch = 3; pitch <= stairs_1.STEP; pitch++) {
        const rows = Array.from({ length: pitch }, (_x, s) => (0, stairs_1.stepShade)(s, pitch));
        strict_1.default.equal(rows[0], (0, stairs_1.stepShade)(0, stairs_1.STEP), `pitch ${pitch}: the same lip`);
        strict_1.default.equal(rows[pitch - 1], (0, stairs_1.stepShade)(stairs_1.STEP - 1, stairs_1.STEP), `pitch ${pitch}: the same deepest shadow`);
        for (let s = 1; s < pitch; s++)
            strict_1.default.ok(rows[s] <= rows[s - 1], `pitch ${pitch}: row ${s} is no lighter than the row before`);
        strict_1.default.ok(rows[0] > 0 && rows[pitch - 1] < -40);
        // the corner's wedge of shadow widens toward the foot of the step above
        for (let s = 1; s < pitch; s++)
            strict_1.default.ok((0, stairs_1.cornerShade)(s, pitch) >= (0, stairs_1.cornerShade)(s - 1, pitch));
        strict_1.default.equal((0, stairs_1.cornerShade)(0, pitch), 0);
        strict_1.default.ok((0, stairs_1.cornerShade)(pitch - 1, pitch) >= 2, `pitch ${pitch}: the wedge is there on the shallowest step`);
    }
    for (let l = 1; l < 20; l++)
        strict_1.default.ok((0, stairs_1.treadTone)(l) > (0, stairs_1.treadTone)(l - 1), "each step lighter than the one below");
});
(0, node_test_1.test)("the flight has depth: each step up is deeper, wider and lighter, between a coping and a wall face each side; toothed corners, wear down the middle, one stone to a step", () => {
    const W = 64, H = 64, L = (0, stairs_1.flightSteps)(H), px = (x, y) => (0, stairs_1.flightPix)(x, y, W, H)[0];
    const med = (v) => [...v].sort((p, q) => p - q)[v.length >> 1], mean = (v) => v.reduce((p, q) => p + q, 0) / v.length;
    const cols = (x0, x1, y) => Array.from({ length: x1 - x0 }, (_, i) => px(x0 + i, y));
    // the layout: nine steps in the halls' four tiles, end to end; the lowest five rows deep and narrowest, each one
    // up no shallower and a pixel wider each side, to the top one, which runs from coping to coping
    strict_1.default.equal(L.length, 9);
    strict_1.default.equal(L[0].y0, 0);
    strict_1.default.equal(L[8].y0 + L[8].pitch, H);
    L.forEach((st, i) => {
        if (i) {
            const lo = L[i - 1];
            strict_1.default.equal(st.y0, lo.y0 + lo.pitch);
            strict_1.default.ok(st.pitch >= lo.pitch, `step ${i} is no shallower`);
            strict_1.default.equal(st.inset, lo.inset - 1);
            strict_1.default.ok(st.level > lo.level);
        }
        strict_1.default.equal((0, stairs_1.flightStepAt)(st.y0, H), st);
        strict_1.default.equal((0, stairs_1.flightStepAt)(st.y0 + st.pitch - 1, H), st);
    });
    strict_1.default.deepEqual([L[0].pitch, L[0].inset, L[0].level], [5, stairs_1.KERB + 8, 1]);
    strict_1.default.ok(L[8].pitch >= L[0].pitch + 4, "the top step is nearly twice as deep as the lowest");
    strict_1.default.deepEqual([L[8].inset, L[8].level], [stairs_1.KERB, stairs_1.TOP_LEVEL], "the top step is the one the head on the surface starts from");
    // a run of any length is the whole stair, foot to top
    for (const h of [16, 32, 48, 64, 96]) {
        const l = (0, stairs_1.flightSteps)(h), last = l[l.length - 1];
        strict_1.default.equal(last.y0 + last.pitch, h);
        strict_1.default.equal(last.level, stairs_1.TOP_LEVEL);
        strict_1.default.equal(last.inset, stairs_1.KERB);
        strict_1.default.ok(l.every((st, i) => st.pitch >= 4 && (!i || st.pitch >= l[i - 1].pitch)), `${h} rows`);
    }
    const cracks = (st) => {
        const dark = (x, r) => px(x, r) < px(x - 2, r) - 7 && px(x, r) < px(x + 2, r) - 7, out = [];
        for (let x = st.inset + 7; x < W - st.inset - 7; x++)
            if (dark(x, st.y0 + 1) && dark(x + 1, st.y0 + st.pitch - 2))
                out.push(x);
        return out;
    };
    let cracked = 0;
    L.forEach((st, i) => {
        const y = st.y0, last = y + st.pitch - 1;
        // the lip is the lightest row of the tread and the row under the next lip the darkest
        strict_1.default.ok(px(24, y) > px(24, y + (st.pitch >> 1)) && px(24, y + (st.pitch >> 1)) > px(24, last), `step ${i}: lip, tread, shadow`);
        // the corner against each wall: lit at the lip, a wedge of shadow by the foot of the next step, and it ends
        for (const x of [st.inset + 3, W - 2 - st.inset])
            strict_1.default.ok(px(x, y) - px(x, last) > 60 && px(x, last) < px(24, last) + 8, `step ${i}: toothed at x ${x}`);
        strict_1.default.ok(px(st.inset + 8, last - 1) > px(st.inset + 1, last - 1) + 15, `step ${i}: the wedge ends`);
        // the walls beside it: the east face catches the light, the west is in its own shade, and both are darker than
        // the tread they stand on; a bed joint runs along the foot of each course
        if (st.inset > stairs_1.KERB + 1) {
            const face = (east) => { const v = []; for (let r = y; r < last; r++)
                for (let k = stairs_1.KERB; k < st.inset; k++)
                    v.push(px(east ? W - 1 - k : k, r)); return mean(v); };
            strict_1.default.ok(face(true) > face(false) + 15, `step ${i}: east face lit, west shaded (${face(true) | 0} / ${face(false) | 0})`);
            strict_1.default.ok(face(true) < px(24, y + 1) - 10 && face(false) > 20, `step ${i}: faces darker than the tread, and not black`);
        }
        if (st.inset > stairs_1.KERB)
            strict_1.default.ok(px(W - 1 - stairs_1.KERB, last) < px(W - 1 - stairs_1.KERB, last - 1) - 8, `step ${i}: a bed joint`);
        else
            strict_1.default.ok(Math.max(...cols(W - 8 - stairs_1.KERB, W - 1 - stairs_1.KERB, y)) > (0, stairs_1.treadTone)(st.level) + 20, `step ${i}: no face left, the tread's lip runs to the coping`);
        // a tread is one stone: at most one crack through it, and never over the crack of the step below
        const c = cracks(st);
        strict_1.default.ok(c.length <= 1, `step ${i}: ${c.length} joints`);
        if (i)
            strict_1.default.ok(!c.some((x) => cracks(L[i - 1]).includes(x)), `step ${i}: no joint over a joint`);
        cracked += c.length;
        // each step up is lighter (the lip's row, its median: a chip is not the stone's tone)
        if (i)
            strict_1.default.ok(med(cols(22, 42, y)) > med(cols(22, 42, L[i - 1].y0)) + 2, `step ${i} is lighter than step ${i - 1}`);
    });
    strict_1.default.ok(med(cols(22, 42, L[8].y0)) > med(cols(22, 42, 0)) + 30, "the top of the flight is well lighter than its foot");
    strict_1.default.ok(cracked >= 1 && cracked <= 6, `${cracked} cracked treads in nine`);
    // worn pale down the middle of the flight (not of each tile): the first tread row, averaged over the steps
    const worn = (x0, x1) => mean(L.map((st) => mean(cols(x0, x1, st.y0 + 1))));
    strict_1.default.ok(worn(26, 38) > worn(16, 21) + 2 && worn(26, 38) > worn(43, 48) + 2);
    // the coping does not step: its rows differ only at its own joints, which sit between the treads' lips; it is
    // lit along its inner edge the whole way, and climbs into the light with the flight
    strict_1.default.ok(Math.abs(px(stairs_1.KERB - 1, 1) - px(stairs_1.KERB - 1, 2)) < 8);
    strict_1.default.ok(px(stairs_1.KERB - 1, 4) < px(stairs_1.KERB - 1, 3) - 15, "the coping's joint is not on a lip");
    for (let y = 0; y < H; y++)
        for (const [edge, out] of [[stairs_1.KERB - 1, 0], [W - stairs_1.KERB, W - 1]])
            strict_1.default.ok(px(edge, y) > px(out, y) + 20, `coping lit at row ${y}`);
    strict_1.default.ok(px(stairs_1.KERB - 1, H - 2) > px(stairs_1.KERB - 1, 1) + 25);
});
(0, node_test_1.test)("one stair in the halls: a baked run is the flight's own pixels, nothing of it stands out in the Vestibule, and it ends in two newel posts", () => {
    // the flight in a bake: a run four tiles wide and four long in a wall, as in the halls. Its steps are laid over
    // the run's whole length and its walls lie at the run's edges and nowhere between.
    const w = 8, h = 6, grid = new Uint8Array(w * h).fill(tiles_2.T.WALL), style = new Uint8Array(w * h);
    for (let y = 1; y <= 4; y++)
        for (let x = 2; x <= 5; x++) {
            grid[y * w + x] = y === 3 ? tiles_2.T.RUBBLE : tiles_2.T.FLOOR;
            style[y * w + x] = tiles_2.FS.STAIR;
        }
    const c = (0, util_1.makeCanvas)(w * tiles_2.TS, h * tiles_2.TS);
    let img = null;
    c.ctx.putImageData = (i) => { img = i; };
    (0, tiles_1.bakeRegion)(c.ctx, { w, h, grid, style, decals: [] }, 0, 0, w - 1, h - 1);
    const baked = (x, y) => { const i = (y * img.width + x) * 4; return [img.data[i], img.data[i + 1], img.data[i + 2]]; };
    for (let ty = 2; ty <= 4; ty++)
        for (let tx = 2; tx <= 5; tx++)
            for (let ly = 0; ly < tiles_2.TS; ly++)
                for (let lx = 0; lx < tiles_2.TS; lx++) {
                    if ((tx === 2 && lx < 2) || (tx === 5 && lx > 13))
                        continue; // the wall's shade on the floor beside it
                    const f = ty === 3 ? 0.7 : 1; // a fall lying on a step darkens it and does not end the run
                    const e = (0, stairs_1.flightPix)((tx - 2) * tiles_2.TS + lx, (ty - 1) * tiles_2.TS + ly, 4 * tiles_2.TS, 4 * tiles_2.TS).map((v) => Math.max(0, Math.min(255, Math.round(v * f))));
                    strict_1.default.deepEqual(baked(tx * tiles_2.TS + lx, ty * tiles_2.TS + ly), e, `tile ${tx},${ty} pixel ${lx},${ly}`);
                }
    // and the halls' stair is such a run: stair tiles from wall to wall, choked (rubble) as built, at the end of a
    // flagged hall; no step is drawn anywhere else (the three that stood out in the Vestibule are gone)
    const d = (0, map_1.buildDungeon)();
    for (let y = geography_1.GATE_STAIR.y; y < geography_1.GATE_STAIR.y + geography_1.GATE_STAIR.h; y++)
        for (let x = geography_1.GATE_STAIR.x; x < geography_1.GATE_STAIR.x + geography_1.GATE_STAIR.w; x++)
            strict_1.default.equal(d.style[y * d.w + x], tiles_2.FS.STAIR);
    for (let y = geography_1.GATE_HALL.y; y < geography_1.GATE_HALL.y + geography_1.GATE_HALL.h; y++)
        for (let x = geography_1.GATE_HALL.x; x < geography_1.GATE_HALL.x + geography_1.GATE_HALL.w; x++)
            strict_1.default.equal(d.style[y * d.w + x], tiles_2.FS.FLAG);
    strict_1.default.equal(geography_1.GATE_STAIR.h * tiles_2.TS, 64, "the length the flight's nine steps are laid out for");
    strict_1.default.ok(!("stairfoot" in props_1.PROP_ART) && !d.props.some((p) => p.kind === "stairfoot"));
    // the newel posts: the stair's stone, standing (a lit top over a darker south face); the whole one fills its
    // sprite, the east one is broken off short; each is as wide as the wall face it ends, and emits nothing
    const whole = raster("stairpost", 0), broken = raster("stairpost", 1);
    const topRow = (s) => { for (let y = 0; y < s.height; y++)
        for (let x = 0; x < s.width; x++)
            if (at(s, x, y))
                return y; return -1; };
    strict_1.default.deepEqual([whole.width, whole.height, broken.width, broken.height], [geography_1.STAIR_CHEEK.post.w, 19, geography_1.STAIR_CHEEK.post.w, 19]);
    strict_1.default.equal(topRow(whole), 0);
    strict_1.default.ok(topRow(broken) >= 5, "broken off below the capstone");
    strict_1.default.ok(lum(whole, 1, 1, 10, 5) > lum(whole, 3, 9, 8, 16) + 30, "top lit, face in shade");
    for (const s of [whole, broken])
        for (let x = 2; x < 10; x++)
            strict_1.default.ok(at(s, x, 18), "it stands on the floor");
    for (const v of [0, 1]) {
        const e = raster("stairpost", v, false, true);
        strict_1.default.ok(e.data.every((x, i) => i % 4 === 3 || x === 0), "no glow");
    }
    strict_1.default.equal(geography_1.STAIR_CHEEK.post.w, (0, stairs_1.flightSteps)(geography_1.GATE_STAIR.h * tiles_2.TS)[0].inset + 1, "a post covers the face beside the lowest step, and its edge");
});
(0, node_test_1.test)("the head goes down into the dark, and the fall above is the fall below: boulders, never courses", () => {
    const site = digging_1.DIG_SITES.buriedgate, total = (0, digging_1.digTotal)(site);
    strict_1.default.deepEqual([0, 2, 6, 8, 13].map((dmg) => (0, digging_1.digStage)(site, dmg, false)).concat((0, digging_1.digStage)(site, total, true)), [0, 1, 2, 3, 4, 5], "the stages are as they were");
    // open: the top step in daylight, each lower one darker, lost under the lintel
    const open = raster("buriedgate", 5);
    const near = lum(open, 10, 50, 61, 57), mid = lum(open, 10, 34, 61, 42), far = lum(open, 10, 15, 61, 22);
    strict_1.default.ok(near > mid * 1.5 && mid > far * 2 && far < 25, `near ${near | 0}, mid ${mid | 0}, far ${far | 0}`);
    // its top step is a step of the flight below: the same lip over the same tread, a little lighter than the halls' last
    const topStep = (y) => lum(open, 16, y, 24, y);
    strict_1.default.ok(topStep(50) > topStep(53) && topStep(53) > topStep(57), "lip, tread, shadow");
    // the well narrows as it goes down: the lit tread of a lower step is shorter than the top one's
    const litW = (y) => { let n = 0; for (let x = 6; x < 66; x++)
        if (open.data[(y * open.width + x) * 4] > 60)
            n++; return n; };
    strict_1.default.ok(litW(51) > litW(37) + 4, `${litW(51)} px wide at the top step, ${litW(37)} three steps down`);
    // the glyph on the lintel wakes only when the stair is open
    const glow = (v) => { const e = raster("buriedgate", v, false, true); let n = 0; for (let i = 0; i < e.data.length; i += 4)
        if (e.data[i] + e.data[i + 1] + e.data[i + 2] > 0)
            n++; return n; };
    strict_1.default.deepEqual([0, 1, 2, 3, 4].map(glow), [0, 0, 0, 0, 0]);
    strict_1.default.ok(glow(5) > 0);
    // the fall: stone in the halls' ramp, heaped. A wall has courses, and a course is a joint running the width of
    // the pit (the old sprite's did, every seventh row); no row of a heap is all joint.
    const stone = rocks_1.STONE.slice(1, 5).map(key), line = key(rocks_1.STONE[0]);
    const read = (v) => {
        const c = raster("buriedgate", v);
        let n = 0, worst = 0;
        for (let y = 22; y < 58; y++) {
            let o = 0;
            for (let x = 7; x < 65; x++) {
                const k = at(c, x, y);
                if (stone.includes(k))
                    n++;
                if (k === line)
                    o++;
            }
            worst = Math.max(worst, o / 58);
        }
        return { stone: n, worst };
    };
    const laid = read(3), broken = read(4), clear = read(5);
    strict_1.default.ok(laid.stone > 800, `the fall fills the pit (${laid.stone} px of stone)`);
    strict_1.default.ok(laid.worst < 0.8 && broken.worst < 0.8, `no course: at most ${Math.round(Math.max(laid.worst, broken.worst) * 100)}% of a row is outline`);
    strict_1.default.ok(broken.stone < laid.stone - 80 && broken.stone > laid.stone * 0.6, "broken through: a breach, most of the fall still there");
    strict_1.default.equal(clear.stone, 0, "open: the fall is gone");
    // through the breach the stair shows: the breach's rows carry the open well's steps, dimmed
    const br = raster("buriedgate", 4);
    strict_1.default.ok(lum(br, 30, 40, 44, 46) > 20 && lum(br, 30, 40, 44, 46) < lum(open, 30, 40, 44, 46), "steps in the breach, darker than by day");
});
