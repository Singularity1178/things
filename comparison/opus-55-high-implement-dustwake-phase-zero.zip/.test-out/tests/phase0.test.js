"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Phase 0 groundwork: fixed-timestep determinism, simulation level of detail, runtime areas, save system v2, the
// UI kit and font, settings, notifications, the content linter and the 300-actor soak (docs/phase0.md).
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const clock_1 = require("../src/game/sim/clock");
const replay_1 = require("../src/game/sim/replay");
const lod_1 = require("../src/game/sim/lod");
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const saveStore_1 = require("../src/game/world/saveStore");
const expedition_1 = require("../src/game/sim/expedition");
const areaSpec_1 = require("../src/game/world/areaSpec");
const tiles_1 = require("../src/game/content/tiles");
const font2_1 = require("../src/game/ui2/font2");
const kit2_1 = require("../src/game/ui2/kit2");
const notify_1 = require("../src/game/ui2/notify");
const settings_1 = require("../src/game/settings");
const lint_1 = require("../src/game/content/lint");
const soak_1 = require("../src/game/sim/soak");
const game_1 = require("../src/game/game");
const json = (w) => JSON.stringify((0, save_1.serialize)(w));
const fresh = (seed = 42) => { const w = (0, world_1.createWorld)(seed); w.events.length = 0; return w; };
/** A stub 2D context: every method is a no-op, every property settable. */
const stubCtx = () => new Proxy({}, { get: (o, k) => (k in o ? o[k] : () => undefined), set: (o, k, v) => { o[k] = v; return true; } });
// ---------------------------------------------------------------- 0.1 fixed timestep
(0, node_test_1.test)("the clock hands out whole ticks: 8x runs eight times as many, pause runs none, a stall is capped", () => {
    const c = new clock_1.SimClock();
    let n = 0;
    for (let i = 0; i < 60; i++)
        n += c.advance(1 / 60, 1);
    strict_1.default.equal(n, clock_1.SIM_HZ);
    const c8 = new clock_1.SimClock();
    let n8 = 0;
    for (let i = 0; i < 60; i++)
        n8 += c8.advance(1 / 60, 8);
    strict_1.default.equal(n8, clock_1.SIM_HZ * 8);
    strict_1.default.equal(new clock_1.SimClock().advance(1, 0), 0);
    strict_1.default.equal(new clock_1.SimClock().advance(10, 1), Math.floor(0.25 / clock_1.TICK + 1e-7), "a long stall only owes maxFrame");
    const a = new clock_1.SimClock();
    a.advance(clock_1.TICK * 1.5, 1);
    strict_1.default.ok(Math.abs(a.alpha - 0.5) < 1e-6, "alpha is the leftover fraction");
    const s = new clock_1.SimClock();
    s.setSpeed(4);
    s.togglePause();
    strict_1.default.equal(s.speed, 0);
    s.togglePause();
    strict_1.default.equal(s.speed, 4);
    s.stepSpeed(1);
    strict_1.default.equal(s.speed, 8);
});
(0, node_test_1.test)("the same save and input stream give an identical world at 1x and at 8x, over any frame timing", () => {
    const base = fresh(7);
    for (let i = 0; i < 30; i++)
        (0, replay_1.simTick)(base);
    const save = (0, save_1.serialize)(base);
    const log = new replay_1.InputLog();
    const t0 = base.tick ?? 0;
    for (let i = 0; i < 240; i++) {
        const phase = Math.floor(i / 40) % 4;
        log.record(t0 + i, { ix: phase === 0 ? 1 : phase === 2 ? -1 : 0, iy: phase === 1 ? 1 : phase === 3 ? -1 : 0, use: i % 97 === 0 });
    }
    const a = (0, save_1.deserialize)(save), b = (0, save_1.deserialize)(save), c = (0, save_1.deserialize)(save);
    strict_1.default.equal(a.tick, t0, "the tick count comes back from the clock");
    const fa = (0, replay_1.driveAtSpeed)(a, log, 400, 1, [1 / 60, 1 / 144, 1 / 30, 0.05, 1 / 75]);
    const fb = (0, replay_1.driveAtSpeed)(b, log, 400, 8, [1 / 60]);
    (0, replay_1.replay)(c, log, 400);
    strict_1.default.ok(fb < fa / 4, `8x needs far fewer frames (${fb} vs ${fa})`);
    strict_1.default.equal(json(a), json(b));
    strict_1.default.equal(json(a), json(c));
    strict_1.default.notEqual((0, world_1.player)(a).x, (0, world_1.player)((0, save_1.deserialize)(save)).x, "the input stream really moved the golem");
});
(0, node_test_1.test)("the host steps fixed ticks: frame() at 8x runs eight times the sim time of 1x, and pause runs none", () => {
    const canvas = () => globalThis.document.createElement("canvas");
    const g = new game_1.Game(canvas(), canvas(), canvas());
    g.resume(fresh(3));
    const t0 = g.world.time;
    for (let i = 0; i < 30; i++) {
        g.frame(1 / 60);
        g.render();
    }
    const at1 = g.world.time - t0;
    strict_1.default.ok(Math.abs(at1 - 0.5) < clock_1.TICK + 1e-9, `1x: half a second of frames is half a second of sim (${at1})`);
    g.clock.setSpeed(8);
    const t1 = g.world.time;
    for (let i = 0; i < 30; i++)
        g.frame(1 / 60);
    strict_1.default.ok(Math.abs(g.world.time - t1 - 4) < clock_1.TICK * 8 + 1e-9, "8x: eight times as much");
    g.clock.setSpeed(0);
    const t2 = g.world.time;
    for (let i = 0; i < 30; i++) {
        g.frame(1 / 60);
        g.render();
    }
    strict_1.default.equal(g.world.time, t2, "paused: no sim time passes");
    // the shell's keyboard: P resumes, = speeds up
    g.keyDown("p");
    g.render();
    g.keyUp("p");
    strict_1.default.equal(g.clock.speed, 8);
});
// ---------------------------------------------------------------- 0.2 level of detail
(0, node_test_1.test)("tiers come from sim state: active near the golem, near across its area, far elsewhere", () => {
    const w = fresh(), pl = (0, world_1.player)(w);
    const near = (0, world_1.makeActor)("n", "worker_golem", pl.area, pl.x + lod_1.ACTIVE_BOX.x + 40, pl.y);
    const close = (0, world_1.makeActor)("c", "worker_golem", pl.area, pl.x + 20, pl.y);
    const far = (0, world_1.makeActor)("f", "worker_golem", "surface", 100, 100);
    strict_1.default.deepEqual([(0, lod_1.tierOf)(w, close, pl), (0, lod_1.tierOf)(w, near, pl), (0, lod_1.tierOf)(w, far, pl), (0, lod_1.tierOf)(w, pl, pl)], ["active", "near", "far", "active"]);
    // far: owed time is paid in chunks once the interval has passed
    const steps = [];
    for (let i = 0; i < 10; i++)
        (0, lod_1.stepAtTier)(w, far, "far", clock_1.TICK, (dt) => steps.push(dt));
    strict_1.default.ok(steps.length >= 1 && steps.length <= 2);
    strict_1.default.ok(Math.abs(steps.reduce((s, x) => s + x, 0) + (w.lod.f ?? 0) - 10 * clock_1.TICK) < 1e-9, "no time is lost or invented");
    strict_1.default.ok(steps.every((s) => s <= lod_1.FAR_INTERVAL + 1e-9));
});
(0, node_test_1.test)("entering an area runs its catch-up hooks with world.time - area.lastTicked", () => {
    const w = fresh(), pl = (0, world_1.player)(w);
    const seen = [];
    (0, lod_1.registerCatchUp)("test.phase0", (_w, area, elapsed) => seen.push([area.id, elapsed]));
    for (let i = 0; i < 10; i++)
        (0, replay_1.simTick)(w);
    const surface = (0, world_1.getArea)(w, "surface");
    const left = surface.lastTicked;
    for (let i = 0; i < 60; i++)
        (0, replay_1.simTick)(w);
    (0, world_1.enterArea)(w, pl, "surface", surface.start.x, surface.start.y);
    (0, replay_1.simTick)(w);
    const hit = seen.find(([id]) => id === "surface");
    strict_1.default.ok(hit && Math.abs(hit[1] - (w.time - clock_1.TICK - left)) < 1e-6, JSON.stringify(seen));
    strict_1.default.equal((0, lod_1.catchUpArea)(w, surface), 0, "caught up: nothing more owed");
    (0, lod_1.registerCatchUp)("test.phase0", () => { });
});
// ---------------------------------------------------------------- 0.3 dynamic areas
(0, node_test_1.test)("a generated floor can be created, edited, saved, loaded and left", () => {
    const w = fresh(11), pl = (0, world_1.player)(w);
    const surface = (0, world_1.getArea)(w, "surface");
    (0, world_1.enterArea)(w, pl, "surface", surface.start.x, surface.start.y);
    const spec = (0, expedition_1.openGeneratedArea)(w, pl, "floor");
    strict_1.default.ok(spec && pl.area === spec.id && spec.parent === "surface" && spec.depth === 1);
    const floor = (0, world_1.getArea)(w, spec.id);
    strict_1.default.equal(floor.tile(Math.floor(pl.x / tiles_1.TS), Math.floor(pl.y / tiles_1.TS)), tiles_1.T.FLOOR);
    // an edit is saved as a diff against the deterministic builder
    floor.setTile(2, 2, tiles_1.T.FLOOR);
    for (let i = 0; i < 20; i++)
        (0, replay_1.simTick)(w);
    const s = (0, save_1.serialize)(w);
    strict_1.default.deepEqual(s.specs?.[spec.id], spec);
    const back = (0, save_1.deserialize)(JSON.parse(JSON.stringify(s)));
    strict_1.default.equal(json(back), json(w));
    strict_1.default.equal((0, world_1.getArea)(back, spec.id).tile(2, 2), tiles_1.T.FLOOR);
    // leaving: out by the exit, back where it was opened
    const bp = (0, world_1.player)(back);
    strict_1.default.ok((0, expedition_1.leaveGeneratedArea)(back, bp));
    strict_1.default.equal(bp.area, "surface");
    strict_1.default.ok(Math.hypot(bp.x - spec.entry.x, bp.y - spec.entry.y) < 24);
    strict_1.default.ok((0, world_1.forgetArea)(back, spec.id) && !back.specs[spec.id] && !back.areas.has(spec.id));
    strict_1.default.ok((0, areaSpec_1.coordPortal)("@10,20")?.arrive?.x === 10 && !(0, areaSpec_1.coordPortal)("exit"));
});
(0, node_test_1.test)("every area kind builds deterministically; a yard saves a run-length full grid", () => {
    for (const kind of Object.keys(areaSpec_1.AREA_KINDS)) {
        const w = fresh(5), pl = (0, world_1.player)(w);
        const spec = (0, expedition_1.openGeneratedArea)(w, pl, kind);
        const s = (0, save_1.serialize)(w);
        if (areaSpec_1.AREA_KINDS[kind].fullGrid)
            strict_1.default.ok(s.areas[spec.id].rle && !s.areas[spec.id].tiles.length, kind);
        strict_1.default.equal(json((0, save_1.deserialize)(s)), json(w), kind);
    }
});
// ---------------------------------------------------------------- 0.4 saves v2
(0, node_test_1.test)("run-length grids round-trip, and big diffs are stored as one", () => {
    const g = new Uint8Array(500);
    g.fill(3, 10, 200);
    g[499] = 7;
    strict_1.default.deepEqual([...(0, save_1.rleDecode)((0, save_1.rleEncode)(g), g.length)], [...g]);
    strict_1.default.throws(() => (0, save_1.rleDecode)([5, 1], 6));
    const w = fresh(), a = (0, world_1.getArea)(w, "dungeon");
    // a scattered edit stays a diff when that is smaller
    for (let i = 0; i < 40; i++)
        a.setTile(1 + i, 1, tiles_1.T.RUBBLE);
    strict_1.default.ok(!(0, save_1.serialize)(w).areas.dungeon.rle);
    // the whole floor re-laid: the run-length grid is far smaller than the diff
    for (let y = 0; y < a.h; y++)
        for (let x = 0; x < a.w; x++)
            a.setTile(x, y, tiles_1.T.RUBBLE);
    const s = (0, save_1.serialize)(w);
    strict_1.default.ok(a.w * a.h > save_1.RLE_THRESHOLD);
    strict_1.default.ok(s.areas.dungeon.rle && s.areas.dungeon.tiles.length === 0);
    strict_1.default.equal(json((0, save_1.deserialize)(s)), json(w));
});
(0, node_test_1.test)("a v19 save still loads", () => {
    const w = fresh(9);
    for (let i = 0; i < 30; i++)
        (0, replay_1.simTick)(w);
    const v19 = JSON.parse(json(w));
    delete v19.specs;
    delete v19.lod;
    delete v19.areaTicks;
    v19.version = 19;
    strict_1.default.equal(save_1.SAVE_VERSION, 20);
    strict_1.default.equal((0, save_1.migrate)(v19).version, 20);
    const back = (0, save_1.deserialize)(v19);
    strict_1.default.equal((0, world_1.player)(back).x, (0, world_1.player)(w).x);
    strict_1.default.ok(back.specs && back.lod);
});
(0, node_test_1.test)("slots keep backups, a corrupt save recovers from the generation before, and the bad record is kept", async () => {
    const kv = new saveStore_1.MemoryKv(), m = new saveStore_1.SaveManager(kv, () => 1000);
    const w = fresh(2);
    await m.save("slot1", w, "first");
    for (let i = 0; i < 30; i++)
        (0, replay_1.simTick)(w);
    await m.save("slot1", w);
    strict_1.default.ok(await kv.get("save:slot1.bak"));
    kv.map.set("save:slot1", kv.map.get("save:slot1").replace(/"time":[0-9.]+/, '"time":999'));
    const r = await m.load("slot1");
    strict_1.default.ok(r.recovered && r.from === "slot1.bak" && /checksum/.test(r.error ?? ""));
    strict_1.default.ok(await kv.get("corrupt:slot1"));
    strict_1.default.equal(r.world.time, 0, "the older generation");
    // autosave keeps three rolling generations
    for (let i = 0; i < 5; i++) {
        (0, replay_1.simTick)(w);
        await m.save("auto", w);
    }
    strict_1.default.ok((await kv.get("save:auto.3")) && !(await kv.get("save:auto.4")));
    kv.map.set("save:auto", "garbage");
    kv.map.set("save:auto.1", (0, saveStore_1.pack)("{not json"));
    const r2 = await m.load("auto");
    strict_1.default.equal(r2.from, "auto.2");
    // nothing usable at all
    await strict_1.default.rejects(m.load("slot3"));
    strict_1.default.equal((await m.list()).length, 4);
});
(0, node_test_1.test)("export / import round-trips; junk is refused with a reason; the v1 slot is imported once", async () => {
    const w = fresh(4);
    for (let i = 0; i < 15; i++)
        (0, replay_1.simTick)(w);
    strict_1.default.equal(json((0, saveStore_1.importText)((0, saveStore_1.exportText)(w))), json(w));
    strict_1.default.throws(() => (0, saveStore_1.importText)("{oops"), /bad JSON/);
    strict_1.default.throws(() => (0, saveStore_1.importText)("{\"x\":1}"), /not a Dustwake save/);
    const legacy = new Map([[saveStore_1.LEGACY_KEY, JSON.stringify((0, save_1.serialize)(w))]]);
    const store = { getItem: (k) => legacy.get(k) ?? null, setItem: (k, v) => void legacy.set(k, v) };
    const m = new saveStore_1.SaveManager(new saveStore_1.MemoryKv());
    strict_1.default.equal(await m.importLegacy(store), true);
    strict_1.default.equal(await m.importLegacy(store), false);
    strict_1.default.equal((await m.load("slot1")).world.seed, w.seed);
});
(0, node_test_1.test)("saves stay within the size and load-time budgets with a lived-in town", async () => {
    const w = (0, soak_1.makeSoakWorld)({ hours: 0, actors: 120 });
    for (let i = 0; i < 60; i++)
        (0, replay_1.simTick)(w);
    const m = new saveStore_1.SaveManager(new saveStore_1.MemoryKv());
    const meta = await m.save("slot2", w);
    strict_1.default.ok(meta.bytes < saveStore_1.SAVE_BUDGET.bytes, `${meta.bytes} bytes`);
    const t0 = performance.now();
    await m.load("slot2");
    strict_1.default.ok(performance.now() - t0 < saveStore_1.SAVE_BUDGET.loadMs, "load time");
});
(0, node_test_1.test)("autosave fires on its timer and on entering another area, not more often than minGap", () => {
    const a = new saveStore_1.Autosaver(60, 20);
    strict_1.default.equal(a.tick(1, "dungeon"), null);
    strict_1.default.equal(a.tick(59.5, "dungeon"), "timer");
    strict_1.default.equal(a.tick(5, "surface"), null, "too soon after the last save");
    strict_1.default.equal(a.tick(20, "dungeon"), "area");
});
// ---------------------------------------------------------------- 0.5 UI
(0, node_test_1.test)("the UI font is mixed case and proportional, and wraps to a width", () => {
    strict_1.default.ok(font2_1.FONT2_GLYPHS.has("a") && font2_1.FONT2_GLYPHS.has("A") && font2_1.FONT2_GLYPHS.has("?"));
    strict_1.default.ok((0, font2_1.measure)("iiii") < (0, font2_1.measure)("mmmm"), "proportional");
    strict_1.default.equal((0, font2_1.measure)("Hello", 2), (0, font2_1.measure)("Hello") * 2);
    const lines = (0, font2_1.wrap2)("The quick brown fox jumps over the lazy golem, twice.", 80);
    strict_1.default.ok(lines.length > 1 && lines.every((l) => (0, font2_1.measure)(l) <= 80));
    strict_1.default.equal((0, font2_1.text2)(stubCtx(), "Ab", 0, 0, "#fff"), (0, font2_1.measure)("Ab"));
});
(0, node_test_1.test)("widgets answer the mouse and the keyboard alike", () => {
    const ptr = new kit2_1.Pointer(), ui = new kit2_1.Ui2(ptr), ctx = stubCtx();
    const frame = (f) => { ui.begin(ctx, 640, 360, 0); f(); ui.end(); ptr.endFrame(); };
    let clicks = 0;
    const btn = () => { if (ui.button("b", { x: 10, y: 10, w: 50, h: 16 }, "Go"))
        clicks++; };
    ptr.move(20, 15);
    ptr.press(0);
    frame(btn);
    ptr.release(0);
    frame(btn);
    strict_1.default.equal(clicks, 1, "press and release on it");
    strict_1.default.ok(ui.overUi());
    ui.keys.add("tab");
    frame(btn);
    strict_1.default.equal(ui.focus, "b");
    ui.keys.add("enter");
    frame(btn);
    strict_1.default.equal(clicks, 2, "Enter on the focused button");
    let v = 0.5;
    ui.focus = "s";
    ui.keys.add("arrowright");
    frame(() => { v = ui.slider("s", { x: 0, y: 40, w: 100, h: 20 }, "Vol", v, 0, 1, 0.1); });
    strict_1.default.equal(v, 0.6);
    let on = false;
    ptr.move(5, 75);
    ptr.press(0);
    frame(() => { on = ui.toggle("t", { x: 0, y: 70, w: 100, h: 16 }, "Shake", on); });
    ptr.release(0);
    frame(() => { on = ui.toggle("t", { x: 0, y: 70, w: 100, h: 16 }, "Shake", on); });
    strict_1.default.equal(on, true);
    const st = { sort: 0, desc: false, sel: -1 };
    ptr.move(20, 120);
    ptr.press(0);
    let picked = -1;
    frame(() => { picked = ui.table("tb", { x: 0, y: 100, w: 200, h: 80 }, [{ label: "N", w: 100, get: (r) => r.n }], [{ n: "b" }, { n: "a" }], st); });
    strict_1.default.equal(picked, 1, "sorted by name, the first row shown is a: the pick maps back to its index in rows");
    strict_1.default.equal(st.sel, 1);
});
(0, node_test_1.test)("the notification feed merges repeats and asks to pause on alerts", () => {
    const f = new notify_1.NotificationFeed();
    f.push("Hello");
    f.push("Hello");
    strict_1.default.equal(f.items.length, 1);
    strict_1.default.equal(f.items[0].count, 2);
    strict_1.default.equal(f.consumePause(), false);
    f.push("Blocked", "alert");
    strict_1.default.equal(f.consumePause(), true);
    strict_1.default.equal(f.consumePause(), false);
    f.push("Quiet alert", "alert", { pause: false });
    strict_1.default.equal(f.consumePause(), false);
    f.update(100);
    strict_1.default.equal(f.visible().length, 0);
});
// ---------------------------------------------------------------- 0.7 settings
(0, node_test_1.test)("remapped keys reach the game as the default key; the old key no longer does that action", () => {
    const s = { ...settings_1.DEFAULT_SETTINGS, keymap: { use: "f" } };
    strict_1.default.equal((0, settings_1.translateKey)(s, "F"), "e");
    strict_1.default.equal((0, settings_1.translateKey)(s, "e"), null);
    strict_1.default.equal((0, settings_1.translateKey)(s, "w"), "w");
    const mem = new Map(), store = { getItem: (k) => mem.get(k) ?? null, setItem: (k, v) => void mem.set(k, v) };
    (0, settings_1.saveSettings)({ ...s, master: 0.3 }, store);
    strict_1.default.equal((0, settings_1.loadSettings)(store).master, 0.3);
    strict_1.default.deepEqual((0, settings_1.loadSettings)({ getItem: () => "{bad", setItem: () => { } }).keymap, {});
    const n = settings_1.OPTIONS.length;
    (0, settings_1.registerOption)({ id: "shake", section: "Accessibility", label: "Screen shake", kind: "toggle" });
    strict_1.default.equal(settings_1.OPTIONS.length, n, "registering again replaces");
});
// ---------------------------------------------------------------- 0.8 lint and soak
(0, node_test_1.test)("content lint: every content row resolves and every line fits its font", () => {
    const issues = (0, lint_1.lintContent)();
    strict_1.default.deepEqual(issues.map((i) => `${i.table}/${i.row} [${i.rule}] ${i.detail}`), []);
});
(0, node_test_1.test)("soak: a small town for two hours keeps every invariant", () => {
    const r = (0, soak_1.runSoak)({ hours: 2, actors: 60, roundTripHours: 0.5, budgetMs: 50 });
    strict_1.default.ok(r.roundTrips >= 3);
    strict_1.default.deepEqual([r.stuck, r.placeConflicts, r.duplicateIds, r.itemDrift, r.roundTripFailures], [[], [], [], {}, []]);
});
/** The frame budget: mean sim cost of one tick with 300 actors. Two ticks (2x speed at 60 fps) must fit a 16.7 ms frame. */
const TICK_BUDGET_MS = 8;
(0, node_test_1.test)(`frame budget: a 300-actor soak holds ${TICK_BUDGET_MS} ms per tick`, () => {
    const w = (0, soak_1.makeSoakWorld)({ hours: 1, actors: 300 });
    const items = (0, soak_1.itemTotals)(w);
    const r = (0, soak_1.runSoak)({ hours: 1, actors: 300, budgetMs: TICK_BUDGET_MS, roundTripHours: 0.5 }, w);
    console.log(`# soak: ${r.actors} actors, ${r.ticks} ticks, ${r.msPerTick.toFixed(2)} ms/tick (p95 ${r.p95Ms.toFixed(2)})`);
    strict_1.default.ok(r.actors >= 300);
    strict_1.default.ok(r.withinBudget, `${r.msPerTick.toFixed(2)} ms/tick over ${TICK_BUDGET_MS}`);
    strict_1.default.ok(r.ok, JSON.stringify({ ...r, items }));
});
(0, node_test_1.test)("the shell: every panel and tab draws, the mouse hovers, drag-selects and opens a context menu", () => {
    const canvas = () => globalThis.document.createElement("canvas");
    const g = new game_1.Game(canvas(), canvas(), canvas());
    const w = (0, soak_1.makeSoakWorld)({ hours: 0, actors: 40 });
    g.resume(w);
    for (let i = 0; i < 10; i++) {
        g.frame(1 / 30);
        g.render();
    }
    const sh = g.shell, p = sh.ptr;
    // drag across the whole view: everyone in sight is selected
    p.move(2, 40);
    p.press(0);
    g.render();
    p.move(630, 350);
    g.render();
    p.release(0);
    g.render();
    strict_1.default.ok(sh.selection.length > 0, "drag-select picked people");
    // right-click opens the context menu; Escape dismisses it
    p.move(320, 200);
    p.press(2);
    g.render();
    p.release(2);
    g.render();
    g.keyDown("Escape");
    g.render();
    g.keyUp("Escape");
    for (const [key, id, tabs] of [["g", "overview", 4], ["j", "saves", 1], ["o", "settings", 5]]) {
        g.keyDown(key);
        g.render();
        g.keyUp(key);
        strict_1.default.ok(g.screens.is(id), id);
        for (let t = 0; t < tabs; t++) {
            g.frame(1 / 30);
            g.render();
            g.keyDown("e");
            g.render();
            g.keyUp("e");
        }
        g.keyDown("Escape");
        g.render();
        g.keyUp("Escape");
        strict_1.default.ok(g.screens.is("play"), `${id} closed`);
    }
    // a generated floor from the host, and back out
    g.generateArea("floor");
    strict_1.default.ok(g.world.specs && Object.keys(g.world.specs).length === 1 && g.pl.area.includes("~floor"));
    g.leaveGenerated();
    strict_1.default.equal(g.pl.area, "town");
});
