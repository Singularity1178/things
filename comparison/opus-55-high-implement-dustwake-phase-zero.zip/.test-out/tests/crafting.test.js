"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Crafting (planks, cut stone, rune carving) and the rebalanced build catalog:
// the craft task and effect, tools carried but not consumed, re-validation,
// overflow to the ground, any actor crafting, saves mid-work, the recipe data,
// and the v8 -> v9 migration of pending build work.
const debug_1 = require("../src/game/sim/debug");
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const inventory_1 = require("../src/game/sim/inventory");
const tasks_1 = require("../src/game/sim/tasks");
const commands_1 = require("../src/game/sim/commands");
const crafting_1 = require("../src/game/sim/crafting");
const catalog_1 = require("../src/game/sim/catalog");
const crafting_2 = require("../src/game/content/crafting");
const build_1 = require("../src/game/content/build");
const items_1 = require("../src/game/content/items");
const flags_1 = require("../src/game/content/flags");
const font_1 = require("../src/game/font");
const crafting_3 = require("../src/game/screens/crafting");
const screens_1 = require("../src/game/ui/screens");
const tiles_1 = require("../src/game/content/tiles");
const helpers_1 = require("./helpers");
const finish = (w) => { let g = 0; while ((0, world_1.player)(w).task && g++ < 600)
    (0, helpers_1.frame)(w); };
// Knows how to build and has read every plan: crafting needs only the first; the build-cost tests here need both.
const know = (w) => { (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild); (0, debug_1.learnAllPlans)(w); };
const BENCH = "workbench@13.5,37";
const loose = (w, item) => (0, world_1.currentArea)(w).loose.filter((l) => !l.taken && l.item === item).reduce((s, l) => s + (l.n ?? 1), 0);
/** The golem beside the dungeon's workbench with the chisel taken (it is a bench from then on). */
function atBench() {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, BENCH));
    know(w);
    const pl = (0, world_1.player)(w), bench = (0, world_1.currentArea)(w).prop(BENCH);
    pl.x = bench.x;
    pl.y = bench.y + 12;
    pl.facing = "up";
    return { w, pl, bench };
}
(0, node_test_1.test)("crafting data: planks and cut stone from raw materials, two runes carved from cut stone with the chisel as a tool", () => {
    const by = Object.fromEntries(crafting_2.CRAFT_RECIPES.map((r) => [r.id, r]));
    // (plus the ruby chain and the inverse rows promoted from the foundation fixture: tests/rollout.test.ts)
    // (and the hafted tools; the smelter's and the anvil's rows are tests/smithing.test.ts)
    strict_1.default.deepEqual(Object.keys(by).filter((id) => by[id].station === "crafting").sort(), ["axe", "axe_fine", "cut_stone", "pickaxe", "pickaxe_fine", "planks", "ruby_core", "rune_glow", "rune_swift", "shovel", "shovel_fine", "unmake_crown", "unmake_rune_glow", "unmake_rune_swift"]);
    strict_1.default.deepEqual(by.planks.inputs.map((c) => c.item), ["wood"]);
    strict_1.default.equal(by.planks.output.item, "planks");
    strict_1.default.deepEqual(by.cut_stone.inputs.map((c) => c.item), ["stone"]);
    strict_1.default.equal(by.cut_stone.output.item, "cut_stone");
    for (const id of ["rune_swift", "rune_glow"]) {
        strict_1.default.deepEqual(by[id].inputs.map((c) => c.item), ["cut_stone"], id);
        strict_1.default.deepEqual(by[id].tools, ["chisel"], id);
        strict_1.default.equal(by[id].output.item, id);
    }
    const ok = (s) => [...s].every((ch) => font_1.FONT_GLYPHS.has(ch));
    for (const r of crafting_2.CRAFT_RECIPES) {
        strict_1.default.ok(ok(r.name) && r.desc.length <= 3 && r.desc.every((l) => ok(l) && l.length <= 30), r.id);
        strict_1.default.ok(items_1.ITEMS[r.output.item] && r.inputs.every((c) => items_1.ITEMS[c.item]), r.id);
        // The existing building knowledge unlocks every craft: no new flag, no recipe-level gate.
        strict_1.default.equal(r.requires, undefined, r.id);
    }
    strict_1.default.deepEqual(crafting_2.STATION_REQUIRES.crafting, { flags: [flags_1.FLAGS.knowBuild] });
    // new items: stack sizes, art names, effects only on runes
    strict_1.default.ok(items_1.ITEMS.planks.stack > 1 && items_1.ITEMS.cut_stone.stack > 1 && items_1.ITEMS.rune_swift.stack === undefined);
    strict_1.default.ok(items_1.ITEM_NAMES.planks === "PLANKS" && items_1.ITEM_NAMES.cut_stone === "CUT STONE");
});
(0, node_test_1.test)("the craft task consumes the inputs when it fires and gives the output; the chisel is carried, never used up", () => {
    const { w, pl, bench } = atBench();
    (0, inventory_1.addItems)(w, pl, "wood", 5);
    (0, helpers_1.events)(w);
    strict_1.default.equal((0, crafting_1.orderCraft)(w, pl, "crafting", "planks", bench.id), true);
    strict_1.default.equal(pl.task.kind, "craft");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 5, "nothing happens until the task fires");
    finish(w);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 3);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "planks"), 3);
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "crafted" && e.item === "planks" && e.n === 3));
    // stone -> cut stone -> a rune, with the chisel along
    (0, inventory_1.addItems)(w, pl, "stone", 6);
    strict_1.default.equal((0, crafting_1.orderCraft)(w, pl, "crafting", "cut_stone", bench.id), true);
    finish(w);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "stone"), 3);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "cut_stone"), 2);
    strict_1.default.equal((0, crafting_1.orderCraft)(w, pl, "crafting", "rune_swift", bench.id), true);
    finish(w);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "cut_stone"), 0);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "rune_swift"), 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "chisel"), 1, "the tool is not consumed");
});
(0, node_test_1.test)("status and refusals: unknown craft, missing tool, missing materials; a refusal changes nothing and says why", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    const pl = (0, world_1.player)(w);
    strict_1.default.ok((0, crafting_1.craftLocked)(w, pl, "crafting"));
    (0, helpers_1.events)(w);
    strict_1.default.equal((0, crafting_1.orderCraft)(w, pl, "crafting", "planks"), false);
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "message" && e.text.includes("CRAFT")));
    know(w);
    (0, inventory_1.addItems)(w, pl, "cut_stone", 3);
    const swift = (0, crafting_1.craftEntries)(w, pl, "crafting").find((e) => e.recipe.id === "rune_swift");
    strict_1.default.equal(swift.status, "tools");
    strict_1.default.equal((0, crafting_1.craftReason)(swift), "NEED THE RUNE CHISEL");
    const before = JSON.stringify(pl.inventory);
    (0, helpers_1.events)(w);
    strict_1.default.equal((0, crafting_1.orderCraft)(w, pl, "crafting", "rune_swift"), false);
    strict_1.default.deepEqual((0, helpers_1.events)(w), [{ t: "message", text: "NEED THE RUNE CHISEL" }]);
    strict_1.default.equal(JSON.stringify(pl.inventory), before);
    strict_1.default.equal(pl.task, null);
    strict_1.default.equal((0, crafting_1.craftEntries)(w, pl, "crafting").find((e) => e.recipe.id === "planks").status, "cost");
    (0, inventory_1.addItems)(w, pl, "chisel", 1);
    strict_1.default.equal((0, crafting_1.craftEntries)(w, pl, "crafting").find((e) => e.recipe.id === "rune_swift").status, "ok");
});
(0, node_test_1.test)("the effect re-validates when it fires: spent materials, a dropped tool or a taken-apart bench change nothing", () => {
    const { w, pl, bench } = atBench();
    (0, inventory_1.addItems)(w, pl, "wood", 2);
    strict_1.default.equal((0, crafting_1.orderCraft)(w, pl, "crafting", "planks", bench.id), true);
    pl.inventory.forEach((s, i) => { if (s?.item === "wood")
        pl.inventory[i] = null; });
    (0, helpers_1.events)(w);
    finish(w);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "planks"), 0);
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "message" && e.text === "NOT ENOUGH MATERIALS"));
    // the bench goes before the work completes
    (0, inventory_1.addItems)(w, pl, "wood", 2);
    strict_1.default.equal((0, crafting_1.orderCraft)(w, pl, "crafting", "planks", bench.id), true);
    (0, world_1.currentArea)(w).removeProp(bench.id);
    (0, helpers_1.events)(w);
    finish(w);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 2, "the wood is still there");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "planks"), 0);
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "message" && e.text.includes("BENCH")));
    // the chisel is gone from the pack when a rune is about to be carved
    const w2 = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w2);
    know(w2);
    const p2 = (0, world_1.player)(w2);
    (0, inventory_1.addItems)(w2, p2, "cut_stone", 2);
    (0, inventory_1.addItems)(w2, p2, "chisel", 1);
    strict_1.default.equal((0, crafting_1.orderCraft)(w2, p2, "crafting", "rune_swift"), true);
    p2.inventory.forEach((s, i) => { if (s?.item === "chisel")
        p2.inventory[i] = null; });
    finish(w2);
    strict_1.default.equal((0, inventory_1.countItem)(p2, "rune_swift"), 0);
    strict_1.default.equal((0, inventory_1.countItem)(p2, "cut_stone"), 2);
});
(0, node_test_1.test)("overflow lands on the ground like any pickup; nothing is deleted", () => {
    const { w, pl, bench } = atBench();
    // the pack is full and the wood stack survives the crafting, so there is no room for the planks
    pl.inventory = pl.inventory.map(() => ({ item: "coin", n: 1 }));
    pl.inventory[0] = { item: "wood", n: 5 };
    (0, helpers_1.events)(w);
    strict_1.default.equal((0, crafting_1.orderCraft)(w, pl, "crafting", "planks", bench.id), true);
    finish(w);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 3);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "planks"), 0);
    strict_1.default.equal(loose(w, "planks"), 3, "the output is on the ground beside the golem");
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "itemDropped" && e.item === "planks" && e.reason === "full"));
    strict_1.default.equal(pl.inventory.length, (0, inventory_1.capacity)(w, pl));
});
(0, node_test_1.test)("any actor can craft through its task queue, and a craft saved mid-work finishes after loading", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    know(w);
    const helper = (0, world_1.makeActor)("helper", "fixture", "dungeon", 100, 100);
    w.actors.push(helper);
    helper.inventory = new Array(8).fill(null);
    (0, inventory_1.addItems)(w, helper, "wood", 4);
    (0, tasks_1.enqueueTask)(helper, { kind: "craft", dur: 1, effect: { op: "craft", recipe: "planks" } }, { kind: "craft", x: 100, y: 100 });
    (0, helpers_1.frames)(w, 90);
    strict_1.default.equal((0, inventory_1.countItem)(helper, "planks"), 3);
    strict_1.default.equal((0, inventory_1.countItem)(helper, "wood"), 2);
    // the player saves mid-craft
    const pl = (0, world_1.player)(w);
    (0, inventory_1.addItems)(w, pl, "wood", 2);
    strict_1.default.equal((0, crafting_1.orderCraft)(w, pl, "crafting", "planks"), true);
    (0, helpers_1.frames)(w, 20);
    strict_1.default.ok(pl.task && !pl.task.fired);
    const w2 = (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
    strict_1.default.deepEqual((0, save_1.serialize)(w2), (0, save_1.serialize)(w));
    finish(w2);
    strict_1.default.equal((0, inventory_1.countItem)((0, world_1.player)(w2), "planks"), 3);
});
(0, node_test_1.test)("the crafting screen: CRAFT closes it so the golem can work, and it comes back when the work is done", () => {
    const { w, pl, bench } = atBench();
    (0, inventory_1.addItems)(w, pl, "wood", 4);
    const ctx = globalThis.document.createElement("canvas").getContext("2d");
    const keys = [];
    const host = {
        ctx, wctx: ctx, world: w, get pl() { return (0, world_1.player)(w); }, get area() { return (0, world_1.currentArea)(w); },
        t: 0.1, cam: { x: 0, y: 0 }, vw: 320, vh: 180, screens: new screens_1.ScreenStack(), typed: [],
        sfx: new Proxy({}, { get: () => () => { } }), hit: (...k) => k.some((x) => keys.includes(x)),
        say: () => { }, renderNote: () => { }, drainEvents: () => { w.events = []; },
    };
    host.screens.set({ id: "play", opaque: true, t: 0, update() { }, render() { } });
    const ui = new crafting_3.CraftingUi(host);
    ui.open("crafting", bench.id);
    const tap = (...k) => { keys.splice(0, keys.length, ...k); host.screens.update(1 / 60); keys.length = 0; };
    tap("e");
    strict_1.default.equal(ui.focus, "button");
    tap("e");
    strict_1.default.ok(host.screens.is("play"), "the screen steps aside while the golem works");
    strict_1.default.ok(ui.pending && pl.task.kind === "craft");
    finish(w);
    ui.resume();
    strict_1.default.ok(host.screens.is("crafting") && !ui.pending);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "planks"), 3);
    ui.screen.render();
});
// ------------------------------------------------------------------ the rebalanced catalog
(0, node_test_1.test)("build costs: rough builds stay raw, finer ones use crafted materials, and the bench itself stays raw", () => {
    // Made at a bench by a forward recipe: an inverse row's output (a rune ground back to stone) doesn't make stone crafted.
    const crafted = new Set(crafting_2.CRAFT_RECIPES.filter((r) => r.mode !== "deconstruct").map((r) => r.output.item));
    const usesCrafted = (id) => build_1.RECIPES[id].cost.some((c) => crafted.has(c.item));
    for (const id of ["torch_post", "craftbench", "barricade"])
        strict_1.default.ok(!usesCrafted(id), `${id} is a rough build: raw only`);
    for (const id of ["table", "chair", "wall_banner", "wall_torch", "brazier"])
        strict_1.default.ok(usesCrafted(id), `${id} uses crafted materials`);
    // replaced outright (furniture) and mixed raw + crafted (the lights)
    strict_1.default.deepEqual(build_1.RECIPES.table.cost, [{ item: "planks", n: 4 }]);
    strict_1.default.deepEqual(build_1.RECIPES.chair.cost, [{ item: "planks", n: 2 }]);
    strict_1.default.deepEqual(build_1.RECIPES.wall_torch.cost, [{ item: "cut_stone", n: 1 }, { item: "wood", n: 1 }]);
    strict_1.default.deepEqual(build_1.RECIPES.brazier.cost, [{ item: "cut_stone", n: 4 }, { item: "wood", n: 2 }]);
    // Planks come from a bench, so a bench that needed them could never be built (and a taken-apart one could never be rebuilt).
    strict_1.default.ok(build_1.RECIPES.craftbench.cost.every((c) => !crafted.has(c.item)));
});
(0, node_test_1.test)("build menu: cost lines, the can-build filter and the cost sort handle crafted materials", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    know(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowMasonry);
    const pl = (0, world_1.player)(w);
    (0, inventory_1.addItems)(w, pl, "planks", 2);
    const list = (0, catalog_1.catalogEntries)(w, pl);
    const table = list.find((e) => e.id === "table"), chair = list.find((e) => e.id === "chair");
    strict_1.default.deepEqual(table.lines, [{ item: "planks", need: 4, have: 2 }]);
    strict_1.default.equal(table.status, "cost");
    strict_1.default.equal((0, catalog_1.entryReason)(table), "NEED 2 PLANKS MORE");
    strict_1.default.equal(chair.status, "ok");
    const q = { tab: "all", search: "", sort: "category", affordableOnly: true, favorites: new Set() };
    strict_1.default.deepEqual((0, catalog_1.queryCatalog)(list, q).map((e) => e.id), ["chair"]);
    (0, inventory_1.addItems)(w, pl, "wood", 3);
    strict_1.default.deepEqual((0, catalog_1.queryCatalog)((0, catalog_1.catalogEntries)(w, pl), q).map((e) => e.id).sort(), ["barricade", "chair"]);
    // search finds buildables by crafted material names
    const hits = (s) => list.filter((e) => (0, catalog_1.matchesSearch)(e, s)).map((e) => e.id).sort();
    strict_1.default.deepEqual(hits("planks"), ["chair", "storage_chest", "table", "wall_banner"]);
    strict_1.default.deepEqual(hits("cut stone"), ["brazier", "smelter", "wall_banner", "wall_torch"]);
    // the cost sort weighs a crafted unit by what it costs to make (planks 2/3 of a wood, cut stone 1.5 stone)
    strict_1.default.equal((0, crafting_2.rawValue)("planks"), 2 / 3);
    strict_1.default.equal((0, crafting_2.rawValue)("cut_stone"), 1.5);
    strict_1.default.equal((0, crafting_2.rawValue)("wood"), 1);
    strict_1.default.equal((0, build_1.costTotal)(build_1.RECIPES.chair), 1.33);
    strict_1.default.equal((0, build_1.costTotal)(build_1.RECIPES.table), 2.67);
    const byCost = (0, catalog_1.sortEntries)(list, "cost").map((e) => (0, build_1.costTotal)(e.recipe));
    strict_1.default.deepEqual(byCost, [...byCost].sort((a, b) => a - b));
    strict_1.default.equal((0, catalog_1.sortEntries)(list, "cost")[0].id, "chair");
});
(0, node_test_1.test)("building with crafted materials consumes them and records what the prop cost", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    know(w);
    const pl = (0, world_1.player)(w);
    pl.gear.back = "basket";
    (0, inventory_1.addItems)(w, pl, "planks", 6);
    (0, inventory_1.addItems)(w, pl, "wood", 1);
    (0, world_1.enterArea)(w, pl, "surface", 20 * tiles_1.TS + 8, 50 * tiles_1.TS + 14);
    const a = (0, world_1.currentArea)(w);
    for (let ty = 46; ty <= 54; ty++)
        for (let tx = 16; tx <= 24; tx++)
            a.setTile(tx, ty, tiles_1.T.FLOOR);
    for (const p of [...a.props])
        if (Math.abs(p.x - pl.x) < 96 && Math.abs(p.y - pl.y) < 96)
            a.removeProp(p.id);
    strict_1.default.ok((0, commands_1.orderBuild)(w, pl, "table", 20, 52));
    finish(w);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "planks"), 2);
    const t = a.props.find((p) => p.kind === "table");
    strict_1.default.deepEqual(t.refund, [{ item: "planks", n: 4 }]);
    strict_1.default.deepEqual((0, save_1.serialize)(w).areas.surface.propsAdded.find((p) => p.id === t.id).refund, [{ item: "planks", n: 4 }]);
});
// ------------------------------------------------------------------ save v9
(0, node_test_1.test)("v8 -> v9: pending build work for a rebalanced recipe is dropped (nothing was consumed); unchanged recipes keep theirs", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    const s = (0, save_1.serialize)(w);
    s.version = 8;
    const task = (recipe) => ({ kind: "reach", dur: 1, t: 0.1, fired: false, effect: { op: "build", recipe, tx: 3, ty: 4 }, area: "dungeon" });
    s.actors[0].task = task("table");
    s.actors[0].queue = [task("torch_post"), task("wall_banner"), task("craftbench")];
    const m = (0, save_1.migrate)(s);
    strict_1.default.equal(m.version, save_1.SAVE_VERSION);
    strict_1.default.equal(save_1.SAVE_VERSION, 20); // v18: townsfolk (tests/folk.test.ts); v19: shops (tests/shops.test.ts)
    strict_1.default.equal(m.actors[0].task, null);
    strict_1.default.deepEqual(m.actors[0].queue.map((t) => t.effect.recipe), ["torch_post", "craftbench"]);
    // the migrated save loads, and nothing the golem carries changed
    const w2 = (0, save_1.deserialize)(s);
    strict_1.default.deepEqual((0, world_1.player)(w2).inventory, (0, world_1.player)(w).inventory);
});
