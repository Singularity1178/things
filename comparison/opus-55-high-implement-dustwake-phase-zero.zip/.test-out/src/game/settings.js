"use strict";
// Settings and accessibility (Phase 0.7). Player preferences, not part of the World and never in a save.
//
// Every option is a row in OPTIONS (registerOption), so later features add theirs here and the settings screen
// (screens/settings.ts) lists them without changes. Values persist through an injected string store
// (localStorage in the browser). Key remapping translates physical keys to the default key of the action they are
// bound to, so the rest of the game keeps asking for its default keys (`hit("e")`) and never knows.
Object.defineProperty(exports, "__esModule", { value: true });
exports.UI_RES = exports.OPTIONS = exports.PALETTE_LABEL = exports.OVERLAY_PALETTES = exports.boundKey = exports.keyName = exports.ACTIONS = exports.DEFAULT_SETTINGS = void 0;
exports.translateKey = translateKey;
exports.registerOption = registerOption;
exports.loadSettings = loadSettings;
exports.saveSettings = saveSettings;
exports.DEFAULT_SETTINGS = {
    master: 0.8, ambience: 0.8, shake: true, flash: true, uiScale: "normal", palette: "default",
    pauseOnAlert: true, autosave: true, autosaveMinutes: 3, interpolate: true, keymap: {},
};
/** Remappable actions and their default keys (what the game's code asks for). */
exports.ACTIONS = [
    { id: "up", label: "Move up", key: "w" }, { id: "down", label: "Move down", key: "s" },
    { id: "left", label: "Move left", key: "a" }, { id: "right", label: "Move right", key: "d" },
    { id: "use", label: "Interact", key: "e" }, { id: "attack", label: "Slam", key: " " },
    { id: "core", label: "Core slot", key: "c" }, { id: "scan", label: "Scan mode", key: "z" },
    { id: "pack", label: "Pack", key: "i" }, { id: "map", label: "Schematic", key: "m" },
    { id: "build", label: "Build menu", key: "b" }, { id: "pause", label: "Pause", key: "p" },
    { id: "slower", label: "Slower", key: "-" }, { id: "faster", label: "Faster", key: "=" },
    { id: "overview", label: "Overview", key: "g" }, { id: "saves", label: "Saves", key: "j" },
    { id: "options", label: "Settings", key: "o" },
];
const keyName = (k) => (k === " " ? "Space" : k.length === 1 ? k.toUpperCase() : k[0].toUpperCase() + k.slice(1));
exports.keyName = keyName;
/** Physical key -> the default key the game reads, or null if the key is unbound (its action moved elsewhere). */
function translateKey(s, key) {
    const k = key.toLowerCase();
    if (!Object.keys(s.keymap).length)
        return k;
    for (const a of exports.ACTIONS)
        if (s.keymap[a.id] === k)
            return a.key;
    // a default key whose action was remapped to another key no longer does that action
    if (exports.ACTIONS.some((a) => a.key === k && s.keymap[a.id] && s.keymap[a.id] !== k))
        return null;
    return k;
}
const boundKey = (s, id) => s.keymap[id] ?? exports.ACTIONS.find((a) => a.id === id)?.key ?? "?";
exports.boundKey = boundKey;
// ---------------------------------------------------------------- overlay palettes
/** Colours for the scan overlay's categories (content/vision.ts), by palette. Okabe-Ito based for colour-blind safety. */
exports.OVERLAY_PALETTES = {
    default: { important: "#ffd27a", interactable: "#74dce2", npc: "#c5a0ff", buildable: "#97d38a" },
    deutan: { important: "#e69f00", interactable: "#56b4e9", npc: "#cc79a7", buildable: "#f0e442" },
    protan: { important: "#f0e442", interactable: "#56b4e9", npc: "#cc79a7", buildable: "#ffffff" },
    tritan: { important: "#d55e00", interactable: "#009e73", npc: "#cc79a7", buildable: "#ffffff" },
};
exports.PALETTE_LABEL = { default: "Default", deutan: "Deuteranopia", protan: "Protanopia", tritan: "Tritanopia" };
exports.OPTIONS = [];
function registerOption(o) {
    const i = exports.OPTIONS.findIndex((x) => x.id === o.id);
    if (i >= 0)
        exports.OPTIONS[i] = o;
    else
        exports.OPTIONS.push(o);
}
const pct = (v) => `${Math.round(v * 100)}%`;
registerOption({ id: "master", section: "Audio", label: "Master volume", kind: "slider", min: 0, max: 1, step: 0.05, format: pct });
registerOption({ id: "ambience", section: "Audio", label: "Ambience volume", kind: "slider", min: 0, max: 1, step: 0.05, format: pct, hint: "The hum of the halls and the wind" });
registerOption({ id: "shake", section: "Accessibility", label: "Screen shake", kind: "toggle" });
registerOption({ id: "flash", section: "Accessibility", label: "Flashes", kind: "toggle", hint: "White flashes on rune jumps and breaking stone" });
registerOption({ id: "palette", section: "Accessibility", label: "Overlay colours", kind: "choice", values: ["default", "deutan", "protan", "tritan"], labels: exports.PALETTE_LABEL });
registerOption({ id: "uiScale", section: "Display", label: "UI scale", kind: "choice", values: ["small", "normal", "large"], labels: { small: "Small", normal: "Normal", large: "Large" } });
registerOption({ id: "interpolate", section: "Display", label: "Smooth motion", kind: "toggle", hint: "Interpolate between simulation ticks" });
registerOption({ id: "pauseOnAlert", section: "Game", label: "Pause on alerts", kind: "toggle", hint: "Important notifications pause the game" });
registerOption({ id: "autosave", section: "Game", label: "Autosave", kind: "toggle" });
registerOption({ id: "autosaveMinutes", section: "Game", label: "Autosave every", kind: "slider", min: 1, max: 15, step: 1, format: (v) => `${v} min` });
const KEY = "dustwake.settings";
function loadSettings(store) {
    try {
        const raw = store?.getItem(KEY);
        if (!raw)
            return { ...exports.DEFAULT_SETTINGS, keymap: {} };
        const o = JSON.parse(raw);
        return { ...exports.DEFAULT_SETTINGS, ...o, keymap: { ...(o.keymap ?? {}) } };
    }
    catch {
        return { ...exports.DEFAULT_SETTINGS, keymap: {} };
    }
}
function saveSettings(s, store) { try {
    store?.setItem(KEY, JSON.stringify(s));
}
catch { /* quota: settings are a convenience */ } }
/** The hi-res UI layer's resolution multiplier over the 320x180 base for a UI scale (smaller canvas = larger UI). */
exports.UI_RES = { small: 3, normal: 2, large: 1.5 };
