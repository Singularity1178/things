"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.analysisFlag = exports.VISION_OFF_OPS = exports.SCAN_DURATION = exports.HIGHLIGHT_RULES = exports.VISION_CATEGORIES = void 0;
exports.VISION_CATEGORIES = {
    important: { color: "#ffd27a", effect: "radiant" }, interactable: { color: "#74dce2", effect: "wireframe" },
    npc: { color: "#c5a0ff", effect: "signal" }, buildable: { color: "#97d38a", effect: "blueprint" },
};
/** First matching row wins. A new category rule is data, not a host branch. */
exports.HIGHLIGHT_RULES = [
    { category: "important", tags: ["rune", "glyph", "part", "document", "relic", "power"] },
    { category: "important", trait: "rune" },
    { category: "npc", trait: "actor" },
    { category: "buildable", trait: "buildable" },
    { category: "interactable", trait: "interactable" },
];
exports.SCAN_DURATION = 0.9;
/**
 * Effects that take the golem's attention elsewhere (a conversation, a rune jump,
 * a work/storage/management screen). Starting a task with one of these ends vision
 * mode on its own, so the overlay plays its normal switch-off.
 */
exports.VISION_OFF_OPS = ["talk", "travel", "useStation", "useStorage", "manageActor"];
const analysisFlag = (key) => `analysis.${key}`;
exports.analysisFlag = analysisFlag;
