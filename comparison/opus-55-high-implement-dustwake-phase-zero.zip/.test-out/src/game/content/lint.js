"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.undrawable = void 0;
exports.lintContent = lintContent;
// Content linter (Phase 0.8). No DOM. Runs a rule set over every content row and returns readable issues; the test
// suite fails on any (tests/contentLint.test.ts). It generalises the data-resolution checks that already existed
// per system (every shop step resolves, every line fits the font) to all tables: a new table adds a rule here.
const items_1 = require("./items");
const props_1 = require("./props");
const build_1 = require("./build");
const crafting_1 = require("./crafting");
const monologue_1 = require("./monologue");
const talk_1 = require("./talk");
const folk_1 = require("./folk");
const font_1 = require("../font");
const font2_1 = require("../ui2/font2");
const settings_1 = require("../settings");
const areas_1 = require("../world/areas");
const areaSpec_1 = require("../world/areaSpec");
const tiles_1 = require("./tiles");
/** Characters the world's bitmap font cannot draw (it uppercases first). */
const undrawable = (s) => [...new Set([...s.toUpperCase()].filter((c) => !font_1.FONT_GLYPHS.has(c)))];
exports.undrawable = undrawable;
const undrawable2 = (s) => [...new Set([...s].filter((c) => !font2_1.FONT2_GLYPHS.has(c)))];
function lintContent() {
    const out = [];
    const bad = (table, row, rule, detail) => out.push({ table, row, rule, detail });
    const text = (table, row, s, maxW) => {
        if (s === undefined)
            return;
        const u = (0, exports.undrawable)(s);
        if (u.length)
            bad(table, row, "font", `cannot draw ${JSON.stringify(u.join(""))} in "${s.slice(0, 40)}"`);
        if (maxW && (0, font_1.textWidth)(s) > maxW)
            bad(table, row, "width", `"${s}" is ${(0, font_1.textWidth)(s)}px, over ${maxW}px`);
    };
    const item = (table, row, id) => { if (id && !(id in items_1.ITEMS))
        bad(table, row, "ref", `unknown item "${id}"`); };
    for (const [id, it] of Object.entries(items_1.ITEMS)) {
        if (!it.name)
            bad("ITEMS", id, "required", "no name");
        text("ITEMS", id, it.name, 150);
        if ((it.stack ?? 1) < 1)
            bad("ITEMS", id, "range", `stack ${it.stack}`);
    }
    for (const [id, p] of Object.entries(props_1.PROPS)) {
        text("PROPS", id, p.examine);
        if (p.box && (p.box[0] <= 0 || p.box[1] <= 0))
            bad("PROPS", id, "range", `box ${p.box}`);
    }
    for (const [id, r] of Object.entries(build_1.RECIPES)) {
        text("RECIPES", id, r.name, 150);
        r.desc.forEach((l, i) => text("RECIPES", `${id}.desc${i}`, l, 34 * 4));
        if (!(r.prop in props_1.PROPS))
            bad("RECIPES", id, "ref", `unknown prop "${r.prop}"`);
        for (const c of r.cost) {
            item("RECIPES", id, c.item);
            if (c.n <= 0)
                bad("RECIPES", id, "range", `cost ${c.n} x ${c.item}`);
        }
    }
    for (const r of crafting_1.CRAFT_RECIPES) {
        text("CRAFT_RECIPES", r.id, r.name, 150);
        r.desc.forEach((l, i) => text("CRAFT_RECIPES", `${r.id}.desc${i}`, l, 30 * 4));
        if (!(r.station in crafting_1.STATIONS))
            bad("CRAFT_RECIPES", r.id, "ref", `unknown station "${r.station}"`);
        for (const c of r.inputs)
            item("CRAFT_RECIPES", r.id, c.item);
        for (const t of r.tools ?? [])
            item("CRAFT_RECIPES", r.id, t);
        for (const c of r.also ?? [])
            item("CRAFT_RECIPES", r.id, c.item);
        item("CRAFT_RECIPES", r.id, r.output.item);
        if (r.output.n <= 0)
            bad("CRAFT_RECIPES", r.id, "range", `output n ${r.output.n}`);
    }
    for (const [id, l] of Object.entries(monologue_1.THOUGHTS))
        text("THOUGHTS", id, l.text);
    for (const e of talk_1.EXCHANGES)
        for (const [i, l] of e.lines.entries()) {
            const s = typeof l === "string" ? l : l.text ?? l.say;
            if (typeof s !== "string")
                continue;
            // placeholders ({name}) are filled at run time; lint the template's literal characters only
            text("EXCHANGES", `${e.id}.${i}`, s.replace(/\{[^}]*\}/g, "X"));
            if (s.length > talk_1.PEER_MAX + 20)
                bad("EXCHANGES", `${e.id}.${i}`, "length", `${s.length} chars`);
        }
    const ids = new Set();
    for (const r of folk_1.CENSUS) {
        if (ids.has(r.id))
            bad("CENSUS", r.id, "unique", "duplicate id");
        ids.add(r.id);
        if (!(r.archetype in folk_1.ARCHETYPES))
            bad("CENSUS", r.id, "ref", `unknown archetype "${r.archetype}"`);
        if (!(r.area in areas_1.AREAS))
            bad("CENSUS", r.id, "ref", `unknown area "${r.area}"`);
    }
    // the settings registry and the UI font
    for (const o of settings_1.OPTIONS) {
        const u = undrawable2(o.label + (o.hint ?? ""));
        if (u.length)
            bad("OPTIONS", o.id, "font2", `cannot draw ${u.join("")}`);
        if ((0, font2_1.measure)(o.label) > 200)
            bad("OPTIONS", o.id, "width", o.label);
    }
    const keys = new Set();
    for (const a of settings_1.ACTIONS) {
        if (keys.has(a.key))
            bad("ACTIONS", a.id, "unique", `default key "${a.key}" bound twice`);
        keys.add(a.key);
    }
    // every portal leads somewhere that exists (authored areas)
    for (const [id, build] of Object.entries(areas_1.AREAS)) {
        if (id.startsWith("debug_"))
            continue;
        const a = build();
        for (const p of a.portals ?? []) {
            if (!(p.to.area in areas_1.AREAS)) {
                bad("AREAS", `${id}.${p.id}`, "ref", `portal to unknown area "${p.to.area}"`);
                continue;
            }
            if (!p.to.portal.startsWith("@") && !(areas_1.AREAS[p.to.area]().portals ?? []).some((q) => q.id === p.to.portal))
                bad("AREAS", `${id}.${p.id}`, "ref", `no portal "${p.to.portal}" in ${p.to.area}`);
        }
    }
    // generated area kinds: deterministic, walkable start, an exit
    for (const [kind, k] of Object.entries(areaSpec_1.AREA_KINDS))
        for (const seed of [1, 99, 123456]) {
            const spec = { id: `lint~${kind}`, kind, seed, w: k.min[0] + 16, h: k.min[1] + 10, parent: "surface", depth: 1, entry: { x: 100, y: 100 } };
            const a = k.build(spec), b = k.build(spec);
            if (a.grid.join() !== b.grid.join() || JSON.stringify(a.props) !== JSON.stringify(b.props))
                bad("AREA_KINDS", `${kind}#${seed}`, "deterministic", "two builds differ");
            const sx = Math.floor(a.start.x / 16), sy = Math.floor(a.start.y / 16);
            if (a.grid[sy * a.w + sx] !== tiles_1.T.FLOOR)
                bad("AREA_KINDS", `${kind}#${seed}`, "start", "start tile is not floor");
            if (!(a.portals ?? []).some((p) => p.id === "exit"))
                bad("AREA_KINDS", `${kind}#${seed}`, "exit", "no exit portal");
            for (const p of a.props)
                if (!(p.kind in props_1.PROPS))
                    bad("AREA_KINDS", `${kind}#${seed}`, "ref", `unknown prop "${p.kind}"`);
        }
    return out;
}
