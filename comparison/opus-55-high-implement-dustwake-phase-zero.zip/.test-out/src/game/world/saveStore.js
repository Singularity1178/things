"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Autosaver = exports.EXPORT_FORMAT = exports.SaveManager = exports.pack = exports.SAVE_BUDGET = exports.LEGACY_KEY = exports.AUTO_BACKUPS = exports.AUTO_SLOT = exports.MANUAL_SLOTS = exports.MemoryKv = void 0;
exports.fnv1a = fnv1a;
exports.unpack = unpack;
exports.metaOf = metaOf;
exports.exportText = exportText;
exports.importText = importText;
// Save system v2 (Phase 0.4). No DOM: storage is an injected async key-value store (IndexedDB in the browser,
// view/persistence.ts; memory in tests).
//
//   slots        three manual slots plus "auto"; each has a meta record (shown by the saves screen) and its data
//   checksums    data is stored as `<fnv1a>:<json>`; a mismatch, bad JSON or a failed migration is corruption
//   backups      every write first rolls the previous data down (`auto` keeps AUTO_BACKUPS generations, manual
//                slots one `.bak`), so a bad write or a corrupt record falls back to the generation before
//   recovery     load tries the slot, then its backups in order; the corrupt record is kept as `corrupt:<slot>`
//   export       a self-describing JSON file that import validates by loading it (migrations run as for slots)
//   legacy       the single localStorage slot of v1 (`dustwake.save`) is imported into slot 1 once
const save_1 = require("./save");
const world_1 = require("./world");
/** In-memory store (tests, and the browser's fallback when IndexedDB is unavailable). */
class MemoryKv {
    constructor() {
        Object.defineProperty(this, "map", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
    }
    async get(k) { return this.map.get(k); }
    async set(k, v) { this.map.set(k, v); }
    async del(k) { this.map.delete(k); }
    async keys() { return [...this.map.keys()]; }
}
exports.MemoryKv = MemoryKv;
exports.MANUAL_SLOTS = ["slot1", "slot2", "slot3"];
exports.AUTO_SLOT = "auto";
exports.AUTO_BACKUPS = 3;
exports.LEGACY_KEY = "dustwake.save";
/** Budgets the tests hold saves to (docs/world/saves.md). */
exports.SAVE_BUDGET = { bytes: 512 * 1024, loadMs: 400 };
function fnv1a(s) {
    let h = 0x811c9dc5;
    for (let i = 0; i < s.length; i++) {
        h ^= s.charCodeAt(i);
        h = Math.imul(h, 0x01000193);
    }
    return (h >>> 0).toString(16).padStart(8, "0");
}
const pack = (json) => `${fnv1a(json)}:${json}`;
exports.pack = pack;
function unpack(raw) {
    const i = raw.indexOf(":");
    if (i !== 8)
        throw new Error("save record has no checksum");
    const sum = raw.slice(0, 8), json = raw.slice(9);
    if (fnv1a(json) !== sum)
        throw new Error("save checksum mismatch (corrupted)");
    return JSON.parse(json);
}
const dataKey = (slot) => `save:${slot}`;
const metaKey = (slot) => `meta:${slot}`;
const backupsOf = (slot) => (slot === exports.AUTO_SLOT ? Array.from({ length: exports.AUTO_BACKUPS }, (_, i) => `${slot}.${i + 1}`) : [`${slot}.bak`]);
function metaOf(slot, w, bytes, savedAt, label) {
    return { slot, savedAt, version: save_1.SAVE_VERSION, day: w.day, area: (0, world_1.player)(w)?.area ?? "?", playTime: w.playTime, bytes, ...(label ? { label } : {}) };
}
class SaveManager {
    constructor(kv, now = () => Date.now()) {
        Object.defineProperty(this, "kv", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: kv
        });
        Object.defineProperty(this, "now", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: now
        });
    }
    /** Write `w` to `slot`, rolling the previous generations down first. */
    async save(slot, w, label) {
        const json = JSON.stringify((0, save_1.serialize)(w));
        const backs = backupsOf(slot);
        for (let i = backs.length - 1; i >= 0; i--) {
            const from = i === 0 ? slot : backs[i - 1];
            const d = await this.kv.get(dataKey(from)), m = await this.kv.get(metaKey(from));
            if (d !== undefined) {
                await this.kv.set(dataKey(backs[i]), d);
                if (m)
                    await this.kv.set(metaKey(backs[i]), m.replace(`"slot":"${from}"`, `"slot":"${backs[i]}"`));
            }
        }
        const meta = metaOf(slot, w, json.length, this.now(), label);
        await this.kv.set(dataKey(slot), (0, exports.pack)(json));
        await this.kv.set(metaKey(slot), JSON.stringify(meta));
        return meta;
    }
    /** Load `slot`; on corruption fall back through its backups. Throws only if nothing usable is left. */
    async load(slot) {
        let firstError;
        for (const from of [slot, ...backupsOf(slot)]) {
            const raw = await this.kv.get(dataKey(from));
            if (raw === undefined)
                continue;
            try {
                const world = (0, save_1.settle)((0, save_1.deserialize)(unpack(raw)));
                if (from !== slot) {
                    // keep the bad record for a bug report, and put the good generation back in the slot
                    const bad = await this.kv.get(dataKey(slot));
                    if (bad !== undefined)
                        await this.kv.set(`corrupt:${slot}`, bad);
                    await this.kv.set(dataKey(slot), raw);
                    const m = await this.kv.get(metaKey(from));
                    if (m)
                        await this.kv.set(metaKey(slot), m.replace(`"slot":"${from}"`, `"slot":"${slot}"`));
                }
                return { world, slot, from, recovered: from !== slot, error: firstError };
            }
            catch (e) {
                firstError ?? (firstError = `${from}: ${e.message}`);
            }
        }
        throw new Error(firstError ?? `no save in ${slot}`);
    }
    async has(slot) { return (await this.kv.get(dataKey(slot))) !== undefined; }
    async meta(slot) { const m = await this.kv.get(metaKey(slot)); return m ? JSON.parse(m) : null; }
    /** Every primary slot's meta (manual slots, then auto), nulls for empty ones. */
    async list() { return Promise.all([...exports.MANUAL_SLOTS, exports.AUTO_SLOT].map((s) => this.meta(s))); }
    async remove(slot) {
        for (const s of [slot, ...backupsOf(slot)]) {
            await this.kv.del(dataKey(s));
            await this.kv.del(metaKey(s));
        }
    }
    /** The newest slot that holds a save (for "continue"). */
    async latest() {
        const all = (await this.list()).filter(Boolean);
        return all.sort((a, b) => b.savedAt - a.savedAt)[0] ?? null;
    }
    /** Import the v1 single localStorage slot into slot 1, once (only if slot 1 is empty). True if it did. */
    async importLegacy(storage) {
        const raw = storage.getItem(exports.LEGACY_KEY);
        if (!raw || (await this.has("slot1")))
            return false;
        const w = (0, save_1.settle)((0, save_1.deserialize)(JSON.parse(raw)));
        await this.save("slot1", w, "Imported from v1");
        return true;
    }
}
exports.SaveManager = SaveManager;
// ---------------------------------------------------------------- export / import
exports.EXPORT_FORMAT = "dustwake-save";
function exportText(w, now = Date.now()) {
    return JSON.stringify({ format: exports.EXPORT_FORMAT, exportedAt: now, version: save_1.SAVE_VERSION, save: (0, save_1.serialize)(w) });
}
/** Parse an exported file (or a bare save) into a World. Throws with a readable message if it is not one. */
function importText(text) {
    let o;
    try {
        o = JSON.parse(text);
    }
    catch {
        throw new Error("not a save file (bad JSON)");
    }
    const rec = o;
    const save = rec?.format === exports.EXPORT_FORMAT ? rec.save : o;
    (0, save_1.migrate)(save); // throws "not a Dustwake save" / "newer than supported"
    return (0, save_1.settle)((0, save_1.deserialize)(save));
}
// ---------------------------------------------------------------- autosave
/** When to autosave: every `interval` real seconds of play, and on entering another area (at most every `minGap`). */
class Autosaver {
    constructor(interval = 180, minGap = 20) {
        Object.defineProperty(this, "interval", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: interval
        });
        Object.defineProperty(this, "minGap", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: minGap
        });
        Object.defineProperty(this, "timer", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "sinceLast", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1e9
        });
        Object.defineProperty(this, "lastArea", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "enabled", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
    }
    /** Advance by real seconds of play; returns the reason to save now, or null. */
    tick(realDt, area) {
        this.timer += realDt;
        this.sinceLast += realDt;
        const moved = this.lastArea !== null && area !== this.lastArea;
        this.lastArea = area;
        if (!this.enabled)
            return null;
        if (moved && this.sinceLast >= this.minGap)
            return this.mark("area");
        if (this.timer >= this.interval)
            return this.mark("timer");
        return null;
    }
    mark(r) { this.timer = 0; this.sinceLast = 0; return r; }
    reset(area = null) { this.timer = 0; this.sinceLast = 1e9; this.lastArea = area; }
}
exports.Autosaver = Autosaver;
