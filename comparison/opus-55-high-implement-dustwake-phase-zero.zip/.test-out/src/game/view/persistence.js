"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalKv = exports.IdbKv = exports.loadFromStorage = exports.saveToStorage = void 0;
exports.browserSaves = browserSaves;
exports.downloadSave = downloadSave;
exports.pickSaveFile = pickSaveFile;
// Browser persistence: IndexedDB key-value store for save system v2 (world/saveStore.ts), with a localStorage
// fallback when IndexedDB is unavailable (private windows in some browsers), file export / import, and the v1
// single-slot helpers kept for the debug hook.
const save_1 = require("../world/save");
const saveStore_1 = require("../world/saveStore");
const saveToStorage = (w) => (0, save_1.saveToStorage)(w, localStorage);
exports.saveToStorage = saveToStorage;
const loadFromStorage = () => (0, save_1.loadFromStorage)(localStorage);
exports.loadFromStorage = loadFromStorage;
const DB = "dustwake", STORE = "kv";
class IdbKv {
    constructor() {
        Object.defineProperty(this, "db", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.db = new Promise((res, rej) => {
            const r = indexedDB.open(DB, 1);
            r.onupgradeneeded = () => r.result.createObjectStore(STORE);
            r.onsuccess = () => res(r.result);
            r.onerror = () => rej(r.error);
        });
    }
    async tx(mode, fn) {
        const db = await this.db;
        return new Promise((res, rej) => {
            const req = fn(db.transaction(STORE, mode).objectStore(STORE));
            req.onsuccess = () => res(req.result);
            req.onerror = () => rej(req.error);
        });
    }
    get(k) { return this.tx("readonly", (s) => s.get(k)); }
    async set(k, v) { await this.tx("readwrite", (s) => s.put(v, k)); }
    async del(k) { await this.tx("readwrite", (s) => s.delete(k)); }
    async keys() { return (await this.tx("readonly", (s) => s.getAllKeys())).map(String); }
}
exports.IdbKv = IdbKv;
/** localStorage-backed store (fallback). */
class LocalKv {
    constructor(prefix = "dustwake.v2.") {
        Object.defineProperty(this, "prefix", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: prefix
        });
    }
    async get(k) { return localStorage.getItem(this.prefix + k) ?? undefined; }
    async set(k, v) { localStorage.setItem(this.prefix + k, v); }
    async del(k) { localStorage.removeItem(this.prefix + k); }
    async keys() { return Object.keys(localStorage).filter((k) => k.startsWith(this.prefix)).map((k) => k.slice(this.prefix.length)); }
}
exports.LocalKv = LocalKv;
/** The browser's save manager: IndexedDB if it opens, else localStorage, else memory (nothing persists). */
function browserSaves() {
    let kv;
    try {
        kv = typeof indexedDB !== "undefined" ? new IdbKv() : typeof localStorage !== "undefined" ? new LocalKv() : new saveStore_1.MemoryKv();
    }
    catch {
        kv = new saveStore_1.MemoryKv();
    }
    return new saveStore_1.SaveManager(kv);
}
/** Offer the world as a downloaded file. */
function downloadSave(w) {
    const blob = new Blob([(0, saveStore_1.exportText)(w)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `dustwake-day${Math.floor(w.day) + 1}-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-")}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
/** Ask the player for a save file; resolves with its text (or null if cancelled). */
function pickSaveFile() {
    return new Promise((res) => {
        const input = document.createElement("input");
        input.type = "file";
        input.accept = ".json,application/json";
        input.onchange = () => { const f = input.files?.[0]; if (!f)
            return res(null); f.text().then(res, () => res(null)); };
        input.click();
    });
}
