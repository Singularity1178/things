"use strict";
// The particle system (split from game.ts): presentation-only motes, sparks, debris, drips and smoke.
// Randomness here is Math.random on purpose (docs/sim/determinism.md): particles never feed back into the World.
Object.defineProperty(exports, "__esModule", { value: true });
exports.spawn = spawn;
exports.sparkBurst = sparkBurst;
exports.updateParticles = updateParticles;
function spawn(g, p) {
    if (g.particles.length > 900)
        return;
    g.particles.push({ z: 0, vx: 0, vy: 0, vz: 0, life: 1, max: p.life ?? 1, kind: "dust", col: "#888", emit: false, g: 0, size: 1, ...p });
}
function sparkBurst(g, n) {
    const pl = g.pl;
    const right = pl.facing === "down" || pl.facing === "left";
    const sx = pl.x + (pl.facing === "up" ? -8 : pl.facing === "down" ? 8 : right ? -1 : 1), sy = pl.y - 9 + Math.round(g.look.dormant * 4);
    for (let i = 0; i < n; i++)
        g.spawn({ x: sx, y: sy + 9, z: 9, vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.3) * 20, vz: 10 + Math.random() * 30, life: 0.3 + Math.random() * 0.4, kind: "spark", col: Math.random() < 0.5 ? "#fff2a0" : "#ffb040", emit: true, g: 120 });
}
function updateParticles(g, dt) {
    const ps = g.particles;
    for (let i = ps.length - 1; i >= 0; i--) {
        const p = ps[i];
        p.life -= dt / p.max;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.vz -= p.g * dt;
        p.z += p.vz * dt;
        if (p.kind === "debris" || p.kind === "spark" || p.kind === "dust") {
            if (p.z < 0) {
                p.z = 0;
                p.vz = -p.vz * 0.35;
                p.vx *= 0.6;
                p.vy *= 0.6;
            }
        }
        if (p.kind === "drip" && p.z <= 0) {
            for (let k = 0; k < 5; k++)
                g.spawn({ x: p.x, y: p.y, z: 0, vx: (Math.random() - 0.5) * 20, vy: (Math.random() - 0.5) * 8, vz: 12 + Math.random() * 8, life: 0.35, kind: "splash", col: "#7a9ab8", g: 80 });
            g.sfx.drip(g.volAt(p.x, p.y));
            p.life = 0;
        }
        if (p.kind === "mote") {
            p.vx += (Math.random() - 0.5) * dt * 4;
            p.vz += (Math.random() - 0.5) * dt * 4;
        }
        if (p.kind === "smoke") {
            p.vx *= 0.97;
            p.vy *= 0.97;
        }
        if (p.life <= 0)
            ps.splice(i, 1);
    }
}
