"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderWorld = renderWorld;
exports.drawSurfaceRune = drawSurfaceRune;
exports.drawDimmed = drawDimmed;
exports.drawSwaying = drawSwaying;
exports.drawFlame = drawFlame;
exports.drawPedestal = drawPedestal;
exports.drawPlayer = drawPlayer;
exports.npcLook = npcLook;
exports.updateNpcLooks = updateNpcLooks;
exports.updateWorkerLook = updateWorkerLook;
exports.updateFolkLook = updateFolkLook;
exports.renderFolkBubbles = renderFolkBubbles;
exports.renderHud = renderHud;
exports.renderClock = renderClock;
exports.renderToast = renderToast;
exports.visionArt = visionArt;
// The world renderer (split from game.ts): draws the lit scene of the current area onto the world layer, the
// golem, NPC presentation state, folk speech, and the HUD of the base-size UI layer.
const tiles_1 = require("../content/tiles");
const items_1 = require("../content/items");
const gear_1 = require("../sim/gear");
const digging_1 = require("../content/digging");
const monologue_1 = require("../ui/monologue");
const props_1 = require("../content/props");
const glyphs_1 = require("../content/glyphs");
const flags_1 = require("../content/flags");
const props_2 = require("../art/props");
const tiles_2 = require("../art/tiles");
const items_2 = require("../art/items");
const util_1 = require("../util");
const golem_1 = require("../golem");
const light_1 = require("../light");
const circle_1 = require("../circle");
const font_1 = require("../font");
const world_1 = require("../world/world");
const npcs_1 = require("../content/npcs");
const actors_1 = require("../content/actors");
const actors_2 = require("./actors");
const actorStats_1 = require("../sim/actorStats");
const workerAnim_1 = require("../workerAnim");
const dialogue_1 = require("../sim/dialogue");
const folk_1 = require("../sim/folk");
const shops_1 = require("../sim/shops");
const keeperArt_1 = require("../keeperArt");
const actors_3 = require("./actors");
const folkArt_1 = require("../folkArt");
const daycycle_1 = require("../content/daycycle");
const daycycle_2 = require("../content/daycycle");
const daytime_1 = require("../sim/daytime");
const game_1 = require("../game");
function renderWorld(g) {
    const sc = g.scene.ctx, ec = g.emit.ctx, area = g.area;
    let sx = 0, sy = 0;
    if (g.shakeT > 0) {
        sx = (Math.random() - 0.5) * g.shakeMag * 2;
        sy = (Math.random() - 0.5) * g.shakeMag * 2;
    }
    const camX = Math.round(g.cam.x + sx), camY = Math.round(g.cam.y + sy);
    const W = g.vw, H = g.vh; // the world layer is view-sized (zoom)
    const hour = (0, daytime_1.worldHour)(g.world);
    sc.fillStyle = "#000";
    sc.fillRect(0, 0, W, H);
    ec.fillStyle = "#000";
    ec.fillRect(0, 0, W, H);
    g.view.prepare(camX, camY, W, H);
    g.view.idle();
    sc.drawImage(g.view.bg.c, camX, camY, W, H, 0, 0, W, H);
    const spr = (s, x, y) => {
        const dx = Math.round(x - s.ax - camX), dy = Math.round(y - s.ay - camY);
        if (dx > W || dy > H || dx + s.w < 0 || dy + s.h < 0)
            return;
        sc.drawImage(s.a, dx, dy);
        ec.drawImage(s.e, dx, dy);
    };
    // ---- a room's doorway: the threshold is painted with the night beyond it; by day the daylight stands there instead
    const daylight = (0, daycycle_2.sunLevel)(hour);
    if (area.base.interior && daylight > 0)
        for (const pt of area.base.portals ?? []) {
            if (!pt.door || pt.dir !== "down")
                continue;
            const x = pt.x - 1 - camX, y = pt.y + 4 - camY, ww = pt.w + 2;
            sc.globalAlpha = daylight;
            sc.fillStyle = "#cfc49c";
            sc.fillRect(x, y, ww, 6);
            sc.fillStyle = "#f0e8c8";
            sc.fillRect(x + 1, y + 2, ww - 2, 3);
            sc.globalAlpha = 1;
            ec.globalAlpha = daylight * 0.45;
            ec.fillStyle = "#a89868";
            ec.fillRect(x, y, ww, 6);
            ec.globalAlpha = 1;
        }
    // ---- rune circle (floor layer)
    const r = area.ritual;
    if (r) {
        const c = area.ritualPos;
        const schemRead = (0, world_1.hasFlag)(g.world, flags_1.FLAGS.knowSchematic);
        const ccx = c.x - circle_1.CR - camX, ccy = c.y - circle_1.CR - camY;
        if (ccx > -140 && ccx < W + 10 && ccy > -140 && ccy < H + 10) {
            sc.drawImage(g.circle.base, ccx, ccy);
            sc.drawImage(r.carved ? g.circle.gapCarved : g.circle.chalk, ccx, ccy);
            let lvl = r.active ? 0.55 + 0.35 * Math.sin(g.t * 3) + Math.min(0.3, r.actT * 0.1) : 0.16 + 0.06 * Math.sin(g.t * 1.3);
            if (g.fizzT > 0)
                lvl = Math.random() * 0.8;
            ec.globalAlpha = (0, util_1.clamp)(lvl, 0, 1);
            ec.drawImage(g.circle.glow, ccx, ccy);
            if (r.carved)
                ec.drawImage(g.circle.glowGap, ccx, ccy);
            if (!r.carved && schemRead) {
                ec.globalAlpha = 0.45 + 0.3 * Math.sin(g.t * 4);
                ec.drawImage(g.circle.ghost, ccx, ccy);
            }
            if (r.active) {
                ec.globalCompositeOperation = "lighter";
                ec.globalAlpha = 0.35 + 0.25 * Math.sin(g.t * 5);
                ec.drawImage(g.circle.glow, ccx, ccy);
                ec.drawImage(g.circle.glowGap, ccx, ccy);
                ec.globalCompositeOperation = "source-over";
            }
            ec.globalAlpha = 1;
        }
    }
    // ---- rune circles that are props (surface)
    for (const p of area.props)
        if (p.kind === "runecircle")
            g.drawSurfaceRune(p, camX, camY);
    const list = [];
    const vx0 = camX - 48, vx1 = camX + W + 48, vy0 = camY - 16, vy1 = camY + H + 60;
    for (const p of area.props) {
        if (p.x < vx0 || p.x > vx1 || p.y < vy0 || p.y > vy1)
            continue;
        if (p.kind === "pedestal") {
            const i = Number(p.id.slice(3));
            list.push({ y: p.y, f: () => g.drawPedestal(p, i, spr, camX, camY) });
            continue;
        }
        const def = (0, props_1.propDef)(p.kind);
        // Where people keep the lights, a lamp is as lit as the hour says (content/daycycle.ts): a doused torch shows
        // its unlit art, a rune or a lantern stops glowing, and a dark window is just the painted window under it.
        const lvl = def.habit ? g.tendedLevel(p, hour) : 1;
        const alt = def.alt === "lit" ? !!p.lit && lvl > 0.05 : def.alt === "taken" ? p.taken : p.open;
        const s = (0, props_2.propSprite)(p.kind, (0, digging_1.propLook)(p), alt);
        if (!s)
            continue;
        if (lvl <= 0.01 && def.habit === "window")
            continue;
        list.push({
            y: def.wallMounted ? p.y - 0.5 : def.flat ? p.y - 16 : p.y,
            f: () => {
                if (lvl < 1 && def.alt !== "lit")
                    g.drawDimmed(s, p, lvl, def.habit === "window", camX, camY);
                else if (def.sway && !alt)
                    g.drawSwaying(s, p, camX, camY);
                else
                    spr(s, p.x, p.y);
                if (p.lit && def.fire && lvl > 0.05)
                    g.drawFlame(p, def.fire.big, camX, camY);
                if (p.item && !p.container && !p.taken && items_1.ITEMS[p.item].showOnProp !== false) {
                    const ic = (0, items_2.itemIcon)(p.item);
                    const bob = (0, items_1.isGlyph)(p.item) ? Math.round(Math.sin(g.t * 2) * 0.6) : 0;
                    spr(ic, p.x + (def.itemDx ?? 0), p.y - (p.itemZ ?? 8) + bob);
                }
            },
        });
    }
    for (const l of area.loose) {
        if (l.taken || l.x < vx0 || l.x > vx1 || l.y < vy0 || l.y > vy1)
            continue;
        list.push({ y: l.y, f: () => spr((0, items_2.itemIcon)(l.item), l.x, l.y + 2) });
    }
    const AW = area.w;
    const tx0 = Math.max(0, Math.floor(camX / tiles_1.TS) - 1), tx1 = Math.min(AW - 1, Math.floor((camX + W) / tiles_1.TS) + 1);
    const ty0 = Math.max(0, Math.floor(camY / tiles_1.TS) - 1), ty1 = Math.min(area.h - 1, Math.floor((camY + H) / tiles_1.TS) + 3);
    for (let ty = ty0; ty <= ty1; ty++)
        for (let tx = tx0; tx <= tx1; tx++) {
            const t = area.grid[ty * AW + tx];
            const x = tx * tiles_1.TS + 8, y = ty * tiles_1.TS + 16;
            if (t === tiles_1.T.RUBBLE) {
                const s = (0, tiles_2.rubbleSprite)(Math.floor((0, util_1.hash2)(tx, ty, 5) * 3), false);
                list.push({ y, f: () => spr(s, x, y) });
            }
            else if (t === tiles_1.T.CRACKED) {
                const s = (0, tiles_2.rubbleSprite)(0, true);
                // a slam that didn't break it: the debris jolts side to side as the shudder dies away
                const sh = g.shudder, jx = sh && sh.tx === tx && ty >= sh.ty && ty <= sh.ty + 2 ? Math.round(Math.sin(g.t * 80) * 2 * Math.min(1, sh.t / 0.3)) : 0;
                list.push({ y, f: () => { spr(s, x + jx, y); if (g.crackFlash > 0) {
                        ec.globalAlpha = g.crackFlash;
                        ec.drawImage(s.e, Math.round(x + jx - s.ax - camX), Math.round(y - s.ay - camY));
                        ec.globalAlpha = 1;
                    } } });
            }
            else if (t === tiles_1.T.PILLAR) {
                const s = (0, tiles_2.pillarSprite)(area.tvar[ty * AW + tx] === 1);
                list.push({ y, f: () => spr(s, x, y) });
            }
            else if (t === tiles_1.T.LOCKED) {
                const s = (0, tiles_2.doorSprite)();
                list.push({ y, f: () => spr(s, x, y) });
            }
            else if (t === tiles_1.T.BARS) {
                const s = (0, tiles_2.barsSprite)();
                list.push({ y, f: () => spr(s, x, y) });
            }
        }
    // NPCs (one generic path: art looked up by NpcDef id)
    for (const a of g.world.actors) {
        if (a.id === g.world.playerId || a.area !== area.id || a.x < vx0 || a.x > vx1 || a.y < vy0 || a.y > vy1)
            continue;
        list.push({ y: a.y, f: () => (0, actors_2.drawActor)(sc, ec, g.world, a, camX, camY, g.t, g.npcLook(a)) });
    }
    // player
    const pl = g.pl;
    if (!g.hideGolem)
        list.push({ y: pl.y, f: () => g.drawPlayer(camX, camY) });
    // world particles
    for (const p of g.particles) {
        if (p.kind === "debris" || p.kind === "dust" || p.kind === "smoke" || p.kind === "splash") {
            list.push({ y: p.y, f: () => { sc.fillStyle = p.col; const s = p.size; sc.fillRect(Math.round(p.x - camX), Math.round(p.y - p.z - camY), s, s); if (p.emit === false) {
                    ec.fillStyle = "#000";
                    ec.fillRect(Math.round(p.x - camX), Math.round(p.y - p.z - camY), s, s);
                } } });
        }
    }
    list.sort((a, b) => a.y - b.y);
    for (const d of list)
        d.f();
    // moonbeam
    const moon = g.view.byId("moon");
    if (moon) {
        // moonlight through the broken roof by night, the same shaft as a sunbeam by day
        const sun = daylight, mx = Math.round(moon.x - g.shaft.ax - camX), my = Math.round(moon.y + 2 - g.shaft.ay - camY);
        ec.globalCompositeOperation = "lighter";
        if (sun < 1) {
            ec.globalAlpha = 1 - sun;
            ec.drawImage(g.shaft.e, mx, my);
        }
        if (sun > 0) {
            ec.globalAlpha = sun;
            ec.drawImage(g.sunShaft.e, mx, my);
        }
        ec.globalAlpha = 1;
        ec.globalCompositeOperation = "source-over";
    }
    // floating particles
    for (const p of g.particles) {
        if (p.kind === "debris" || p.kind === "dust" || p.kind === "smoke" || p.kind === "splash")
            continue;
        const x = Math.round(p.x - camX), y = Math.round(p.y - p.z - camY);
        if (x < -2 || y < -2 || x > W + 2 || y > H + 2)
            continue;
        if (p.kind === "glint") {
            const a = Math.sin((0, util_1.clamp)(p.life, 0, 1) * Math.PI);
            ec.globalCompositeOperation = "lighter";
            ec.fillStyle = `rgba(255,240,200,${a})`;
            ec.fillRect(x, y, 1, 1);
            if (a > 0.5) {
                ec.fillStyle = `rgba(255,240,200,${a * 0.5})`;
                ec.fillRect(x - 1, y, 3, 1);
                ec.fillRect(x, y - 1, 1, 3);
            }
            ec.globalCompositeOperation = "source-over";
            continue;
        }
        if (p.emit) {
            ec.globalCompositeOperation = "lighter";
            ec.globalAlpha = (0, util_1.clamp)(p.life * 1.5, 0, 1);
            ec.fillStyle = p.col;
            ec.fillRect(x, y, p.size, p.size);
            ec.globalAlpha = 1;
            ec.globalCompositeOperation = "source-over";
        }
        else if (p.kind === "mote") {
            sc.fillStyle = p.col;
            sc.fillRect(x, y, 1, 1);
        }
        else {
            sc.fillStyle = p.col;
            sc.fillRect(x, y, p.size, p.size);
        }
    }
    // ---- lighting
    const sImg = sc.getImageData(0, 0, W, H);
    const eImg = ec.getImageData(0, 0, W, H);
    const active = g.hideGolem ? [] : [g.glight];
    for (const L of g.view.lights.values())
        if (L.on)
            active.push(L);
    g.lighting.accumulate(active, camX, camY);
    // the hour: the sky's share of the ambient by how much of it g area sees, and lamps counting for less in daylight
    const exposure = (0, daytime_1.exposureOf)(area);
    g.lighting.compose(sImg.data, eImg.data, g.outImg.data, (0, daycycle_2.ambientAt)(area.base.ambient ?? game_1.BURIED_AMBIENT, hour, exposure), 6, (0, daycycle_2.lampGain)(hour, exposure));
    g.wctx.putImageData(g.outImg, 0, 0);
    const eye = g.eyeSpot();
    g.vision.draw(g.wctx, g.pl, camX, camY, W, H, g.t, eye && { x: eye.x + eye.w / 2 - 1, y: eye.y, w: eye.w, show: eye.show });
}
/**
 * The surface rune: mostly eroded and overgrown while dormant, redrawn by the
 * awakening sweep, fully carved and glowing once active. Layers come cached
 * from SurfaceRuneArt (re-rasterised only while the sweep is in progress).
 */
function drawSurfaceRune(g, p, camX, camY) {
    const st = g.surfaceRuneState();
    const ccx = Math.round(p.x - circle_1.CR - camX), ccy = Math.round(p.y - circle_1.CR - camY);
    if (ccx > -140 && ccx < g.vw + 10 && ccy > -140 && ccy < g.vh + 10) {
        const sc = g.scene.ctx, ec = g.emit.ctx;
        const L = g.runeArt.layers(st.t);
        sc.drawImage(L.scene, ccx, ccy);
        if (st.glow > 0) {
            ec.globalAlpha = (0, util_1.clamp)(st.glow, 0, 1);
            ec.drawImage(L.emit, ccx, ccy);
            if (st.glow > 1) {
                ec.globalCompositeOperation = "lighter";
                ec.globalAlpha = (0, util_1.clamp)(st.glow - 1, 0, 1);
                ec.drawImage(L.emit, ccx, ccy);
                ec.globalCompositeOperation = "source-over";
            }
            ec.globalAlpha = 1;
        }
    }
    if (st.column > 0)
        g.drawSummonColumn(p.x - camX, p.y - camY, st.column);
}
/** A tended lamp part-lit or out: its glow at `lvl`. A lit window (`whole`) is nothing but its glow, so all of it fades. */
function drawDimmed(g, s, p, lvl, whole, camX, camY) {
    const dx = Math.round(p.x - s.ax - camX), dy = Math.round(p.y - s.ay - camY);
    if (dx > g.vw || dy > g.vh || dx + s.w < 0 || dy + s.h < 0)
        return;
    const sc = g.scene.ctx, ec = g.emit.ctx;
    if (whole)
        sc.globalAlpha = lvl;
    sc.drawImage(s.a, dx, dy);
    sc.globalAlpha = 1;
    if (lvl > 0.01) {
        ec.globalAlpha = lvl;
        ec.drawImage(s.e, dx, dy);
        ec.globalAlpha = 1;
    }
}
/** Foliage in the wind: the upper part of the sprite shifts by a pixel now and then. */
function drawSwaying(g, s, p, camX, camY) {
    const dx = Math.round(p.x - s.ax - camX), dy = Math.round(p.y - s.ay - camY);
    if (dx > g.vw || dy > g.vh || dx + s.w < 0 || dy + s.h < 0)
        return;
    const sc = g.scene.ctx, ec = g.emit.ctx;
    const wv = Math.sin(g.t * 1.6 + p.x * 0.031 + p.y * 0.017) + 0.4 * Math.sin(g.t * 3.7 + p.x * 0.11);
    const o = Math.round(wv * 0.75);
    if (!o) {
        sc.drawImage(s.a, dx, dy);
        ec.drawImage(s.e, dx, dy);
        return;
    }
    const cut = Math.floor(s.h * 0.55);
    for (const [src, ctx] of [[s.a, sc], [s.e, ec]]) {
        ctx.drawImage(src, 0, 0, s.w, cut, dx + o, dy, s.w, cut);
        ctx.drawImage(src, 0, cut, s.w, s.h - cut, dx, dy + cut, s.w, s.h - cut);
    }
}
function drawFlame(g, p, big, camX, camY) {
    const ec = g.emit.ctx;
    const bx = Math.round(p.x - camX), by = Math.round(p.y - camY - 15 + ((0, props_1.propDef)(p.kind).fire?.dy ?? 0));
    const t = g.t * 12 + p.x;
    const cols = ["#ff5a10", "#ff9a30", "#ffd060", "#fff0b0"];
    const w = big ? 8 : 3;
    for (let i = 0; i < w; i++) {
        const hgt = Math.max(1, Math.round((big ? 7 : 4) * (1 - Math.abs(i - (w - 1) / 2) / w) + Math.sin(t + i * 1.7) * 1.5 + Math.sin(t * 1.7 + i) * 0.8));
        for (let j = 0; j < hgt; j++) {
            const k = Math.min(3, Math.floor((j / hgt) * 4));
            ec.fillStyle = cols[3 - k];
            if (j === hgt - 1)
                ec.fillStyle = cols[0];
            ec.fillRect(bx - Math.floor(w / 2) + i, by - j + (big ? 2 : 0), 1, 1);
        }
    }
}
function drawPedestal(g, p, i, spr, camX, camY) {
    const s = (0, props_2.propSprite)("pedestal", 0, false);
    spr(s, p.x, p.y);
    const area = g.area, r = area.ritual;
    const glyph = r.sockets[i];
    const ec = g.emit.ctx;
    const topY = p.y - 15;
    if (glyph >= 0) {
        spr((0, items_2.itemIcon)((0, items_1.glyphItem)(glyph)), p.x, topY + 4);
        if (r.active) {
            const pen = new util_1.Pen(ec, true);
            (0, items_2.glyphPattern)(pen, glyph, Math.round(p.x - camX) - 4, Math.round(topY - camY) - 7, glyphs_1.GLYPHS[glyph].color, true);
        }
        if (r.wrong[i] && g.fizzT > 0 && Math.sin(g.t * 30) > 0) {
            ec.fillStyle = "#ff2040";
            ec.globalAlpha = 0.6;
            ec.fillRect(Math.round(p.x - camX) - 6, Math.round(topY - camY) - 8, 12, 12);
            ec.globalAlpha = 1;
        }
    }
    if ((0, world_1.hasFlag)(g.world, flags_1.FLAGS.knowSchematic) && glyph !== r.solution[i] && !r.active) {
        const pen = new util_1.Pen(ec, true);
        ec.globalAlpha = 0.35 + 0.2 * Math.sin(g.t * 3 + i);
        const bob = Math.round(Math.sin(g.t * 2 + i) * 1.5);
        (0, items_2.glyphPattern)(pen, r.solution[i], Math.round(p.x - camX) - 3, Math.round(topY - camY) - 16 + bob - (glyph >= 0 ? 4 : 0), glyphs_1.GLYPHS[r.solution[i]].color, true);
        ec.globalAlpha = 1;
    }
    if (i === 0 && r.core) {
        // core floating above center
        const c = area.ritualPos;
        const bob = Math.round(Math.sin(g.t * 2) * 1.5) + (r.active ? -3 : 0);
        spr((0, items_2.itemIcon)("core"), c.x, c.y - 4 + bob);
    }
}
function drawPlayer(g, camX, camY) {
    const pl = g.pl, lk = g.look, sc = g.scene.ctx;
    // shadow
    sc.fillStyle = "rgba(0,0,0,0.45)";
    const sx = Math.round(pl.x - camX), sy = Math.round(pl.y - camY);
    const sw = Math.max(4, 8 - Math.round(lk.z / 3));
    sc.fillRect(sx - sw, sy - 1, sw * 2, 2);
    sc.fillRect(sx - sw + 2, sy - 2, sw * 2 - 4, 4);
    const a = pl.task;
    let raise = 0, reach = 0, slam, dip;
    if (a) {
        const k = a.t / a.dur;
        if (a.kind === "reach" || a.kind === "push" || a.kind === "dismantle")
            reach = Math.sin(Math.min(1, k) * Math.PI);
        if (a.kind === "smash")
            raise = a.t < 0.5 ? a.t / 0.5 : a.t < 0.62 ? (0, util_1.lerp)(1, -1, (a.t - 0.5) / 0.12) : (0, util_1.lerp)(-1, 0, (0, util_1.clamp)((a.t - 0.62) / 0.5, 0, 1));
        if (a.kind === "carve")
            reach = 0.4 + 0.6 * Math.abs(Math.sin(a.t * 14));
        if (a.kind === "craft")
            reach = 0.3 + 0.7 * Math.abs(Math.sin(a.t * 9));
        if (a.kind === "attach")
            reach = 0.3;
        if (a.kind === "punch") {
            const k2 = a.t / a.dur;
            raise = k2 < 0.35 ? k2 / 0.35 : k2 < 0.5 ? (0, util_1.lerp)(1, -1, (k2 - 0.35) / 0.15) : (0, util_1.lerp)(-1, 0, (0, util_1.clamp)((k2 - 0.5) / 0.4, 0, 1));
        }
        if (a.kind === "channel")
            reach = 0.2;
        if (a.kind === "slam")
            ({ lift: slam, dip } = (0, golem_1.slamPose)(k));
    }
    const pose = {
        facing: g.gaze ?? pl.facing, phase: pl.phase, moving: pl.moving && !a, hasArm: g.hasArm, dormant: lk.dormant,
        eye: (0, util_1.clamp)(lk.eye + g.eyeBoost + g.vision.k * 0.35, 0, 1.6), core: lk.core, raise, reach, t: g.t,
        eyeFixed: (0, world_1.hasFlag)(g.world, flags_1.FLAGS.golemEye), back: pl.gear.back, runes: (0, gear_1.runeMarks)(g.world, pl), slam, dip,
    };
    const ox = pl.x - camX + (a?.kind === "push" ? Math.round(Math.sin(a.t * 40)) : 0), oy = pl.y - camY - lk.z;
    (0, golem_1.drawGolem)(new util_1.Pen(sc, false), ox, oy, pose);
    (0, golem_1.drawGolem)(new util_1.Pen(g.emit.ctx, true), ox, oy, pose);
    g.selfPose = { pose, x: ox + camX, y: oy + camY };
}
// ---------------------------------------------------------------- NPCs
/** Presentation state for an NPC actor, created from its sim state (so a loaded world looks right at once). */
function npcLook(g, a) {
    let L = g.npcLooks.get(a.id);
    if (!L) {
        const on = (0, dialogue_1.isAwake)(g.world, a.id) ? 1 : 0;
        L = { awake: on, eye: on, wakeT: 99, sleepT: 99, reach: 0, flare: 0, lift: 0, seen: -99, arrived: false };
        g.npcLooks.set(a.id, L);
    }
    return L;
}
/** Ease every NPC in view toward its sim state: wake sputter, straighten, dim and slump. Drives its eye light. */
function updateNpcLooks(g, dt) {
    const area = g.area;
    for (const a of g.world.actors) {
        if (a.area !== area.id || a.id === g.world.playerId)
            continue;
        if (a.kind === "folk") {
            g.updateFolkLook(a);
            continue;
        }
        if (a.kind === "keeper")
            continue; // a keeper's look is all in keeperArt.ts
        // Bodies without a dialogue identity (workers): the sequencer decides how they stand, sit and shut down.
        if (!(0, npcs_1.npcDef)(a.npc)) {
            g.updateWorkerLook(a, dt);
            continue;
        }
        if (a.kind !== "npc")
            continue;
        const def = (0, actors_1.actorDef)(a);
        const L = g.npcLook(a), on = (0, dialogue_1.isAwake)(g.world, a.id);
        L.wakeT += dt;
        L.sleepT += dt;
        // awake: the eye sputters on first, then it straightens; dormant: the eye dims, then it slumps
        const target = on ? (L.wakeT > 0.6 ? 1 : 0) : (L.sleepT > 0.7 ? 0 : 1);
        L.awake += (0, util_1.clamp)(target - L.awake, -dt / 1.1, dt / 1.1);
        if (on)
            L.eye = L.wakeT < 0.9 ? (Math.random() < 0.45 + L.wakeT * 0.5 ? 1 : 0.12) : 1;
        else
            L.eye = Math.max(0, Math.min(L.eye, 1 - L.sleepT / 1.2));
        if (on && L.wakeT < 0.05)
            L.flare = 0.8;
        L.flare = Math.max(0, L.flare - dt * 1.5);
        L.reach = Math.max(0, L.reach - dt * 0.7);
        const el = def.eyeLight;
        if (el) {
            const lt = g.view.dynamicLight("npc:" + a.id, () => (0, light_1.makeLight)(a.x + el.dx, a.y + el.dy, el.rad, el.col, 0, 0.05, "npc:" + a.id));
            lt.int = L.eye * 0.42 + L.flare * 0.5 + (L.reach > 0.8 ? 0.25 : 0);
        }
    }
}
/**
 * A worker body, one frame: step its animation sequencer from what the sim says (powered, working, moving, has a core),
 * play the sounds and dust the sequence asks for, and, while it channels a rune, hold it up in the rune's own effect.
 * A worker that was out of the player's area (or the screen) starts at rest in whatever the sim says it is.
 */
function updateWorkerLook(g, a, dt) {
    const L = g.npcLook(a);
    const inp = { powered: (0, actorStats_1.powered)(a), active: (0, actors_2.actorActive)(a), moving: a.moving, hasCore: !!a.powerCore };
    if (!L.worker || g.t - L.seen > 0.5) {
        L.worker = (0, workerAnim_1.initWorkerAnim)(inp);
        if (!L.arrived)
            L.lift = 0;
    }
    L.seen = g.t;
    L.arrived = false;
    (0, workerAnim_1.stepWorkerAnim)(L.worker, dt, inp);
    for (const cue of (0, workerAnim_1.drainCues)(L.worker))
        g.workerCue(a, cue);
    L.flare = Math.max(0, L.flare - dt * 0.8);
    const task = a.task;
    if (task?.kind === "channel" && task.target) {
        // Rune travel. The body does nothing of its own (it just stands at the rune); the rune does the effect:
        // the worker is lifted, motes spiral into the rune and a column of light builds, as the maintainer's jump does.
        const c = task.target, lift = task.dur - 1.0;
        L.lift = Math.min(task.t, lift) * 5.5 + Math.sin(task.t * 3);
        const n = Math.floor(dt * 150 + Math.random());
        for (let i = 0; i < n; i++) {
            const ang = Math.random() * Math.PI * 2, r = 12 + Math.random() * 26;
            g.spawn({ x: c.x + Math.cos(ang) * r, y: c.y + Math.sin(ang) * r, z: 1, vx: -Math.cos(ang) * r * 0.8, vy: -Math.sin(ang) * r * 0.8, vz: 8 + Math.random() * 16, life: 1.0, kind: "rune", col: Math.random() < 0.5 ? "#c0a0ff" : "#80e0ff", emit: true, g: -5 });
        }
        if (task.t - dt <= 0)
            g.runeBlip(c.x, c.y, 0.7);
    }
    else
        L.lift = Math.max(0, L.lift - dt * 26);
    // its core and lamp light the floor round it
    const lt = g.view.dynamicLight("npc:" + a.id, () => (0, light_1.makeLight)(a.x, a.y - 9, 38, [1, 0.38, 0.34], 0, 0.07, "npc:" + a.id));
    lt.x = a.x;
    lt.y = a.y - 9 - L.lift;
    if (Math.abs(lt.x - lt.vx) > 2 || Math.abs(lt.y - lt.vy) > 2)
        (0, light_1.computeVis)(lt, g.area);
    lt.int = L.worker.out.core * 0.2 + L.worker.out.eye * 0.1 + (task?.kind === "channel" ? 0.3 : 0);
}
/** A townsperson, one frame: the watch's lantern lights the street round them after dark. */
function updateFolkLook(g, a) {
    if ((0, folk_1.archetypeOf)(a).garb !== "watch")
        return;
    const on = (0, folk_1.folkPresent)(a) && (0, actors_3.folkLantern)(g.world, a);
    const side = a.facing === "left" ? -1 : a.facing === "right" ? 1 : -4 / 3;
    const lx = a.x + side * 4, ly = a.y - 6;
    const lt = g.view.dynamicLight("folk:" + a.id, () => (0, light_1.makeLight)(lx, ly, 70, [1, 0.7, 0.38], 0, 0.14, "folk:" + a.id));
    lt.x = lx;
    lt.y = ly;
    if (on && (Math.abs(lt.x - lt.vx) > 2 || Math.abs(lt.y - lt.vy) > 2))
        (0, light_1.computeVis)(lt, g.area);
    lt.int = on ? 0.62 : 0;
}
/** Speech bubbles and sleepers' Zs over townsfolk, on the world layer (they scale with the zoom like the marker). */
function renderFolkBubbles(g, dt) {
    const ctx = g.wctx, area = g.area, camX = g.cam.x, camY = g.cam.y;
    for (const [id, b] of g.bubbles) {
        b.t += dt;
        if (b.t > b.dur)
            g.bubbles.delete(id);
    }
    // a shop out of hours: a card on the counter where the keeper would stand
    const shop = (0, shops_1.shopOfArea)(area.id), counter = shop && !(0, shops_1.shopOpen)(g.world, shop.id) ? area.base.spots?.find((s) => s.id === "keeper") : undefined;
    if (counter)
        (0, keeperArt_1.drawClosedSign)(ctx, Math.round(counter.x - camX), Math.round(counter.y - camY) + 12);
    for (const a of g.world.actors) {
        if (a.area !== area.id || !(a.kind === "folk" ? (0, folk_1.folkPresent)(a) && !!a.life : a.kind === "keeper" && (0, shops_1.keeperPresent)(a)))
            continue;
        const x = Math.round(a.x - camX), y = Math.round(a.y - camY);
        if (x < -60 || y < -60 || x > g.vw + 60 || y > g.vh + 60)
            continue;
        if (a.life?.pose === "lie") {
            const k = (g.t * 0.5 + (0, daycycle_1.hash01)(a.id, 4)) % 1;
            ctx.globalAlpha = Math.sin(k * Math.PI) * 0.8;
            (0, font_1.drawTextS)(ctx, k < 0.5 ? "z" : "Z", x + 4 + k * 6, y - 26 - k * 10, "#d8e0f0", 1, "left", "#1a1418");
            ctx.globalAlpha = 1;
        }
        const b = g.bubbles.get(a.id);
        if (!b)
            continue;
        const fade = (0, util_1.clamp)(Math.min(b.t / 0.12, (b.dur - b.t) / 0.25), 0, 1), top = y - (a.life?.pose === "sit" ? 27 : a.kind === "keeper" ? 26 : 30);
        ctx.globalAlpha = fade;
        if (b.text)
            (0, folkArt_1.drawSpeech)(ctx, b.text, x, top, g.vw);
        else if (b.icon)
            (0, folkArt_1.drawChatIcon)(ctx, b.icon, x + 3, top - Math.round((1 - fade) * 3));
        ctx.globalAlpha = 1;
    }
}
function renderHud(g) {
    const ctx = g.ctx;
    // interaction marker (world space: drawn on the world layer)
    if (g.screens.is("play") && g.target) {
        const ctx = g.wctx;
        const it = g.target;
        const x = Math.round(it.x - g.cam.x), y = Math.round(it.y - g.cam.y - (it.itemZ ?? 10) - 14 + Math.sin(g.t * 4) * 1.5);
        ctx.fillStyle = "rgba(0,0,0,0.6)";
        ctx.fillRect(x - 3, y, 7, 1);
        ctx.fillRect(x - 2, y + 1, 5, 1);
        ctx.fillRect(x - 1, y + 2, 3, 1);
        ctx.fillStyle = "#d8cfa8";
        ctx.fillRect(x - 2, y - 1, 5, 1);
        ctx.fillRect(x - 1, y, 3, 1);
        ctx.fillRect(x, y + 1, 1, 1);
    }
    if (g.screens.is("play") || g.screens.is("dialogue"))
        g.renderFolkBubbles(g.frameDt);
    if (g.arriveFade > 0) {
        ctx.fillStyle = `rgba(235,240,255,${g.arriveFade})`;
        ctx.fillRect(0, 0, game_1.W, game_1.H);
    }
    if (g.doorFade > 0) {
        ctx.fillStyle = `rgba(6,5,9,${g.doorFade})`;
        ctx.fillRect(0, 0, game_1.W, game_1.H);
    }
    g.renderBars();
    // below the letterbox while it is up; it rises with the bars as control is handed over
    const bar = g.bars.v * g.bars.v * (3 - 2 * g.bars.v);
    (0, monologue_1.drawMonologue)(ctx, g.monologue, g.t, 7 + Math.round(12 * bar));
    if (g.screens.is("play")) {
        g.renderNote();
        g.vision.drawHud(ctx, game_1.W);
        g.renderClock();
    }
    // debug message
    if (g.debugMsg) {
        ctx.globalAlpha = (0, util_1.clamp)(2 - g.debugMsg.t, 0, 1);
        (0, font_1.drawTextS)(ctx, g.debugMsg.text, game_1.W / 2, 6, "#ff9a5a", 1, "center");
        ctx.globalAlpha = 1;
    }
    // debug readout: active modes, and (menu option) where the golem is
    if (g.debugHud || g.debugNoclip || g.debugSpeed) {
        const pl = g.pl, modes = [g.debugNoclip ? "NOCLIP" : "", g.debugSpeed ? `SPEED X${g.debugSpeedMult}` : ""].filter(Boolean).join("  ");
        const lines = [
            ...(g.debugHud ? [`${pl.area.toUpperCase()}  X ${Math.round(pl.x)}  Y ${Math.round(pl.y)}  TILE ${Math.floor(pl.x / tiles_1.TS)},${Math.floor((pl.y - 3) / tiles_1.TS)}`] : []),
            ...(modes ? [`DEBUG: ${modes}`] : []),
        ];
        lines.forEach((l, i) => (0, font_1.drawTextS)(ctx, l, 4, game_1.H - 8 - (lines.length - 1 - i) * 8, "#ff9a5a", 1, "left", "#000"));
    }
    // toast (the dialogue box draws it above itself)
    if (!g.screens.is("schem") && !g.screens.is("dialogue"))
        g.renderToast(game_1.H - 26);
}
/**
 * The hour, bottom right: the sun, the moon, or the sun on the horizon, and the clock. Shown under the open sky, and
 * anywhere once the golem has been up to see it (it keeps count from then on; before that it has no way to know).
 */
function renderClock(g) {
    if (!g.area.base.outdoor && !(0, world_1.hasFlag)(g.world, flags_1.FLAGS.tutorialDone))
        return;
    const ctx = g.ctx, hour = (0, daytime_1.worldHour)(g.world), ph = (0, daycycle_2.phaseAt)(hour), x = game_1.W - 35, y = game_1.H - 11;
    ctx.fillStyle = "rgba(6,5,9,0.6)";
    ctx.fillRect(x - 3, y - 2, 36, 11);
    const px = (c, cells) => { ctx.fillStyle = c; for (const [cx, cy, w = 1, h = 1] of cells)
        ctx.fillRect(x + cx, y + cy, w, h); };
    if (ph === "day") {
        px("#ffb030", [[3, 0], [3, 6], [0, 3], [6, 3], [1, 1], [5, 1], [1, 5], [5, 5]]);
        px("#ffd860", [[2, 2, 3, 3]]);
    }
    else if (ph === "night") {
        px("#c8d4f0", [[2, 1, 3, 1], [1, 2, 2, 1], [1, 3, 2, 1], [1, 4, 3, 1], [2, 5, 3, 1]]);
        px("#7a88b0", [[5, 2], [6, 0]]);
    }
    else {
        px("#ff9a40", [[2, 3, 3, 2], [1, 4, 5, 1], [3, 1], [1, 2], [5, 2]]);
        px("#8a5a3a", [[0, 5, 7, 1]]);
    }
    (0, font_1.drawText)(ctx, (0, daycycle_2.clockText)(hour), x + 10, y + 1, ph === "night" ? "#a8b4d8" : ph === "day" ? "#e8d8a0" : "#f0b078");
}
function renderToast(g, y) {
    const ctx = g.ctx;
    if (g.toast) {
        const t = g.toast.t;
        const a = t < 0.2 ? t / 0.2 : t > 2.5 ? 1 - (t - 2.5) / 0.5 : 1;
        ctx.globalAlpha = (0, util_1.clamp)(a, 0, 1);
        const name = g.toast.name;
        const w = name.length * 4 + 30;
        const x = Math.round(game_1.W / 2 - w / 2);
        ctx.fillStyle = "#0c0a0e";
        ctx.fillRect(x, y, w, 20);
        ctx.fillStyle = "#3a3540";
        ctx.fillRect(x, y, w, 1);
        ctx.fillRect(x, y + 19, w, 1);
        ctx.fillRect(x, y, 1, 20);
        ctx.fillRect(x + w - 1, y, 1, 20);
        ctx.drawImage(g.toast.icon.a, x + 3, y + 2);
        (0, font_1.drawText)(ctx, name, x + 23, y + 8, "#d8d0b8");
        ctx.globalAlpha = 1;
    }
}
function visionArt(g) {
    const a = (g.visionArtCache ?? (g.visionArtCache = { t: 0, npcLook: (x) => g.npcLook(x), circle: { lines: [g.circle.glow, g.circle.glowGap], r: circle_1.CR }, self: () => (g.hideGolem ? null : g.selfPose) }));
    a.t = g.t;
    return a;
}
