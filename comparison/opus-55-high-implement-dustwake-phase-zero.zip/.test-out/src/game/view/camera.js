"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Camera = void 0;
// The camera (split from game.ts, Phase 0.6): where the view's top-left sits in world pixels, easing after its
// target, plus the previous tick's position so the renderer can interpolate between fixed sim ticks (sim/clock.ts).
class Camera {
    constructor() {
        Object.defineProperty(this, "x", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "y", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        /** Position at the previous tick (interpolation). */
        Object.defineProperty(this, "px", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "py", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
    }
    /** Ease toward a target top-left at `rate` per second (frame-rate independent enough at a fixed tick). */
    follow(tx, ty, dt, rate = 3.5) {
        const k = Math.min(1, dt * rate);
        this.x += (tx - this.x) * k;
        this.y += (ty - this.y) * k;
    }
    /** Jump straight to a position (area change, load), with no interpolation from the old one. */
    snap(x, y) { this.x = this.px = x; this.y = this.py = y; }
    /** Remember the current position as the previous tick's. */
    mark() { this.px = this.x; this.py = this.y; }
    /** The position drawn `alpha` of the way from the previous tick to this one. */
    at(alpha) { return { x: this.px + (this.x - this.px) * alpha, y: this.py + (this.y - this.py) * alpha }; }
}
exports.Camera = Camera;
