"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Shell = void 0;
exports.actorLabel = actorLabel;
exports.actorDoing = actorDoing;
const kit2_1 = require("./kit2");
const font2_1 = require("./font2");
const notify_1 = require("./notify");
const clock_1 = require("../sim/clock");
const lod_1 = require("../sim/lod");
const settings_1 = require("../settings");
const daycycle_1 = require("../content/daycycle");
const daytime_1 = require("../sim/daytime");
const tiles_1 = require("../content/tiles");
const folk_1 = require("../sim/folk");
const shops_1 = require("../sim/shops");
const npcs_1 = require("../content/npcs");
const actors_1 = require("../content/actors");
const expedition_1 = require("../sim/expedition");
const saveStore_1 = require("../world/saveStore");
const PANELS = ["overview", "saves", "settings"];
function actorLabel(a) {
    if ((0, folk_1.isFolk)(a))
        return (0, folk_1.folkLabel)(a);
    if (a.keeper)
        return (0, shops_1.keeperLabel)(a);
    if (a.name)
        return `${a.name} - ${(0, actors_1.actorDef)(a).name ?? a.kind}`;
    if (a.npc)
        return (0, npcs_1.npcDef)(a.npc)?.name ?? a.npc;
    return ((0, actors_1.actorDef)(a).name ?? a.kind).toString();
}
function actorDoing(a) {
    if (a.task)
        return a.task.kind;
    if (a.job && a.job.status !== "done")
        return `${a.job.status}${a.job.reason ? ` (${a.job.reason})` : ""}`;
    if (a.life)
        return a.life.state === "do" ? a.life.act : a.life.state;
    if (a.keeper)
        return "keeping shop";
    return a.moving ? "walking" : "idle";
}
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
const ago = (ms) => { const s = Math.max(0, (Date.now() - ms) / 1000); return s < 60 ? `${s | 0}s ago` : s < 3600 ? `${(s / 60) | 0}m ago` : s < 86400 ? `${(s / 3600) | 0}h ago` : `${(s / 86400) | 0}d ago`; };
class Shell {
    constructor(g) {
        Object.defineProperty(this, "g", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: g
        });
        Object.defineProperty(this, "ptr", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new kit2_1.Pointer()
        });
        Object.defineProperty(this, "ui", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new kit2_1.Ui2(this.ptr)
        });
        Object.defineProperty(this, "feed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new notify_1.NotificationFeed()
        });
        Object.defineProperty(this, "selection", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "context", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "tab", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { overview: 0, settings: 0 }
        });
        Object.defineProperty(this, "tables", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { residents: { sort: 0, desc: false, sel: -1 }, areas: { sort: 0, desc: false, sel: -1 }, saves: { sort: 0, desc: false, sel: 0 } }
        });
        Object.defineProperty(this, "rebinding", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "slots", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "status", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        /** Rolling performance samples for the overview (ms per sim tick, ms per frame, ticks per frame). */
        Object.defineProperty(this, "perf", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { tick: [], frame: [], ticks: [] }
        });
        Object.defineProperty(this, "screens", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        const mk = (id) => ({ id, opaque: false, t: 0, update: (dt) => g.animate(dt), render: () => { } });
        this.screens = { overview: mk("overview"), saves: mk("saves"), settings: mk("settings") };
    }
    open(p) {
        if (this.g.screens.is(p))
            return this.close();
        if (PANELS.includes(this.g.screens.top?.id))
            this.g.screens.pop();
        this.g.screens.push(this.screens[p]);
        this.ui.focus = null;
        this.rebinding = null;
        if (p === "saves")
            this.refreshSlots();
        this.g.sfx.tone(600, 0.04, "triangle", 0.03);
    }
    close() { if (PANELS.includes(this.g.screens.top?.id)) {
        this.g.screens.pop();
        this.g.sfx.tone(420, 0.04, "triangle", 0.03);
    } }
    refreshSlots() { this.g.saves.list().then((s) => { this.slots = s; }, () => { }); }
    tell(text, ok = true) { this.status = { text, ok, t: this.g.t }; }
    sample(key, v) { const s = this.perf[key]; s.push(v); if (s.length > 180)
        s.shift(); }
    /** Per frame, before the sim ticks: notices age, alerts pause, the wheel zooms when it is not over UI. */
    update(realDt) {
        const g = this.g;
        this.feed.update(realDt);
        if (this.feed.consumePause() && g.settings.pauseOnAlert && g.screens.is("play") && g.clock.speed !== 0) {
            g.clock.setSpeed(0);
        }
        if (this.ptr.wheel && g.screens.is("play") && !this.ui.overUi()) {
            g.wheel(this.ptr.wheel);
            this.ptr.wheel = 0;
        }
    }
    // ---------------------------------------------------------------- coordinates
    /** Hi-res UI px -> world px (the world canvas shows vw x vh over the same display rect). */
    toWorld(ux, uy) { const g = this.g; return { x: g.cam.x + (ux / this.ui.w) * g.vw, y: g.cam.y + (uy / this.ui.h) * g.vh }; }
    toUi(wx, wy) { const g = this.g; return { x: ((wx - g.cam.x) / g.vw) * this.ui.w, y: ((wy - g.cam.y) / g.vh) * this.ui.h }; }
    actorAt(wx, wy) {
        const g = this.g;
        let best = null, bd = 1e9;
        for (const a of g.world.actors) {
            if (a.area !== g.pl.area || (a.life && a.life.state === "indoors"))
                continue;
            const dx = Math.abs(wx - a.x), dy = a.y - wy;
            if (dx <= 9 && dy >= -3 && dy <= 26) {
                const d = dx + Math.abs(dy - 10);
                if (d < bd) {
                    bd = d;
                    best = a;
                }
            }
        }
        return best;
    }
    // ---------------------------------------------------------------- render
    render(ctx, w, h) {
        const g = this.g, ui = this.ui;
        ctx.clearRect(0, 0, w, h);
        ui.begin(ctx, w, h, g.t);
        const top = g.screens.top?.id ?? "";
        const base = top === "play" || PANELS.includes(top);
        if (base) {
            if (top === "play")
                this.worldInput();
            this.drawSelection();
            this.hud();
        }
        this.drawFeed(base);
        if (PANELS.includes(top))
            this.panel(top);
        if (top === "play")
            this.hotkeys();
        if (this.context && top === "play")
            this.contextMenu();
        ui.end();
        this.ptr.endFrame();
    }
    hotkeys() {
        const g = this.g, ui = this.ui;
        if (ui.key("p"))
            g.clock.togglePause();
        if (ui.key("-"))
            g.clock.stepSpeed(-1);
        if (ui.key("=") || ui.key("+"))
            g.clock.stepSpeed(1);
        if (ui.key("g"))
            this.open("overview");
        if (ui.key("j"))
            this.open("saves");
        if (ui.key("o"))
            this.open("settings");
    }
    hud() {
        const g = this.g, ui = this.ui, W = ui.w;
        const bw = 22, y = 4;
        let x = W - 4 - (clock_1.SPEEDS.length * (bw + 2)) - 3 * 58 - 8;
        ui.panel({ x: x - 4, y: y - 3, w: W - x + 1, h: 22 });
        for (const s of clock_1.SPEEDS) {
            const on = g.clock.speed === s;
            if (ui.button(`speed.${s}`, { x, y, w: bw, h: 16 }, s === 0 ? "||" : `${s}x`, { on, tip: s === 0 ? `Pause (${(0, settings_1.keyName)((0, settings_1.boundKey)(g.settings, "pause"))})` : `Game speed ${s}x (${(0, settings_1.keyName)((0, settings_1.boundKey)(g.settings, "slower"))} / ${(0, settings_1.keyName)((0, settings_1.boundKey)(g.settings, "faster"))})` }))
                g.clock.setSpeed(s);
            x += bw + 2;
        }
        x += 6;
        const labels = { overview: "Overview", saves: "Saves", settings: "Settings" };
        const keys = { overview: "overview", saves: "saves", settings: "options" };
        for (const p of PANELS) {
            const unread = p === "overview" && this.feed.unread ? ` ${this.feed.unread}` : "";
            if (ui.button(`panel.${p}`, { x, y, w: 56, h: 16 }, labels[p] + unread, { on: g.screens.is(p), tip: `${labels[p]} (${(0, settings_1.keyName)((0, settings_1.boundKey)(g.settings, keys[p]))})` }))
                this.open(p);
            x += 58;
        }
        // under the bar: the day, the hour and the speed, small
        const day = Math.floor(g.world.day) + 1, hour = (0, daycycle_1.clockText)((0, daytime_1.worldHour)(g.world));
        const info = `Day ${day}  ${hour}  ${(0, clock_1.speedLabel)(g.clock.speed)}`;
        ui.labelS(info, W - 6, 27, g.clock.speed === 0 ? kit2_1.C2.amber : kit2_1.C2.dim, "right");
        if (g.clock.speed === 0 && g.screens.is("play"))
            ui.labelS("PAUSED", W / 2, 8, kit2_1.C2.amber, "center", 2);
    }
    drawFeed(base) {
        const ui = this.ui, list = this.feed.visible(base ? 5 : 2);
        let y = 40;
        for (const n of list) {
            const text = n.count > 1 ? `${n.text} (x${n.count})` : n.text;
            const w = Math.min(230, (0, font2_1.measure)(text) + 14), r = { x: ui.w - w - 6, y, w, h: 15 };
            const fade = Math.min(1, (8 - n.age) / 1.5);
            ui.ctx.globalAlpha = Math.max(0.15, fade);
            ui.box(r, "rgba(12,10,16,0.9)", n.level === "alert" ? kit2_1.C2.bad : n.level === "good" ? kit2_1.C2.ok : kit2_1.C2.edge);
            ui.ctx.fillStyle = n.level === "alert" ? kit2_1.C2.bad : n.level === "good" ? kit2_1.C2.ok : kit2_1.C2.accent;
            ui.ctx.fillRect(r.x + 1, r.y + 1, 2, r.h - 2);
            (0, font2_1.text2)(ui.ctx, (0, font2_1.ellipsize)(text, w - 12), r.x + 7, r.y + 4, kit2_1.C2.text);
            ui.ctx.globalAlpha = 1;
            ui.region(r);
            if (this.ptr.inside && this.ptr.x >= r.x && this.ptr.y >= r.y && this.ptr.x < r.x + r.w && this.ptr.y < r.y + r.h) {
                ui.tooltip(`${n.text}\nClick to dismiss.`);
                if (this.ptr.pressed.has(0))
                    this.feed.dismiss(n.id);
            }
            y += 17;
        }
    }
    // ---------------------------------------------------------------- the world under the mouse
    worldInput() {
        const g = this.g, ui = this.ui, p = this.ptr;
        if (!p.inside || ui.overUi() || this.context)
            return;
        const at = this.toWorld(p.x, p.y), hov = this.actorAt(at.x, at.y);
        if (hov && !p.dragging) {
            const tier = (0, lod_1.tierOf)(g.world, hov, g.pl);
            ui.tooltip(`${actorLabel(hov)}\n${cap(actorDoing(hov))} - ${tier}`);
            const s = this.toUi(hov.x, hov.y);
            this.bracket(s.x, s.y, kit2_1.C2.accent);
        }
        if (p.dragging && p.dragFrom) {
            const r = { x: Math.min(p.dragFrom.x, p.x), y: Math.min(p.dragFrom.y, p.y), w: Math.abs(p.x - p.dragFrom.x), h: Math.abs(p.y - p.dragFrom.y) };
            ui.ctx.fillStyle = "rgba(116,220,226,0.12)";
            ui.ctx.fillRect(r.x, r.y, r.w, r.h);
            ui.ctx.fillStyle = kit2_1.C2.accent;
            ui.ctx.fillRect(r.x, r.y, r.w, 1);
            ui.ctx.fillRect(r.x, r.y + r.h, r.w + 1, 1);
            ui.ctx.fillRect(r.x, r.y, 1, r.h);
            ui.ctx.fillRect(r.x + r.w, r.y, 1, r.h);
            if (p.released.has(0)) {
                const a0 = this.toWorld(r.x, r.y), a1 = this.toWorld(r.x + r.w, r.y + r.h);
                this.selection = g.world.actors.filter((a) => a.area === g.pl.area && a.x >= a0.x && a.x <= a1.x && a.y - 8 >= a0.y && a.y - 8 <= a1.y && !(a.life?.state === "indoors")).map((a) => a.id);
                if (this.selection.length)
                    g.sfx.tone(700, 0.04, "triangle", 0.03);
            }
        }
        else if (p.released.has(0) && !p.dragging) {
            this.selection = hov ? [hov.id] : [];
        }
        if (p.pressed.has(2))
            this.context = { x: p.x, y: p.y, actor: hov?.id ?? null, wx: at.x, wy: at.y };
    }
    bracket(x, y, col) {
        const c = this.ui.ctx, s = this.ui.w / 320, w = 10 * s, top = y - 26 * s, bot = y + 3 * s;
        c.fillStyle = col;
        for (const [bx, by, dx, dy] of [[x - w, top, 1, 1], [x + w, top, -1, 1], [x - w, bot, 1, -1], [x + w, bot, -1, -1]]) {
            c.fillRect(Math.round(bx), Math.round(by), 5 * dx, 1);
            c.fillRect(Math.round(bx), Math.round(by), 1, 5 * dy);
        }
    }
    drawSelection() {
        const g = this.g, ui = this.ui;
        const sel = this.selection.map((id) => g.world.actors.find((a) => a.id === id)).filter((a) => !!a && a.area === g.pl.area);
        if (!sel.length)
            return;
        for (const a of sel) {
            const s = this.toUi(a.x, a.y);
            this.bracket(s.x, s.y, kit2_1.C2.gold);
        }
        const h = Math.min(130, 30 + sel.length * 12 + 14), r = ui.panel({ x: 4, y: ui.h - h - 46, w: 210, h }, `Selected (${sel.length})`);
        ui.scrollList("sel.list", { x: r.x, y: r.y, w: r.w, h: r.h - 16 }, sel, 12, (a, _i, row) => {
            (0, font2_1.text2)(ui.ctx, (0, font2_1.ellipsize)(actorLabel(a), 120), row.x + 3, row.y + 2, kit2_1.C2.text);
            (0, font2_1.text2)(ui.ctx, (0, font2_1.ellipsize)(cap(actorDoing(a)), 70), row.x + row.w - 3, row.y + 2, kit2_1.C2.dim, 1, "right");
        });
        if (ui.button("sel.clear", { x: r.x + r.w - 50, y: r.y + r.h - 13, w: 50, h: 13 }, "Clear"))
            this.selection = [];
    }
    contextMenu() {
        const g = this.g, c = this.context, a = c.actor ? g.world.actors.find((x) => x.id === c.actor) : null;
        const items = a ? ["Inspect", "Select", "Add to selection"] : ["Mark this spot", "Clear selection", "Overview"];
        const pick = this.ui.menu("ctx", c.x, c.y, items);
        if (pick === -1)
            return;
        this.context = null;
        if (pick < 0)
            return;
        if (a) {
            if (pick === 0) {
                this.tables.residents.sel = g.world.actors.indexOf(a);
                this.tab.overview = 0;
                this.open("overview");
            }
            if (pick === 1)
                this.selection = [a.id];
            if (pick === 2 && !this.selection.includes(a.id))
                this.selection.push(a.id);
        }
        else {
            if (pick === 0)
                this.feed.push(`Marked ${g.pl.area} at tile ${Math.floor(c.wx / tiles_1.TS)}, ${Math.floor(c.wy / tiles_1.TS)}`, "info", { at: g.world.time });
            if (pick === 1)
                this.selection = [];
            if (pick === 2)
                this.open("overview");
        }
    }
    // ---------------------------------------------------------------- panels
    panel(id) {
        const ui = this.ui;
        if (this.rebinding === null && (ui.key("escape") || (id === "settings" && ui.key("o")) || (id === "saves" && ui.key("j")) || (id === "overview" && ui.key("g")))) {
            this.close();
            return;
        }
        const title = { overview: "Overview", saves: "Saves", settings: "Settings" }[id];
        const r = ui.modal(Math.min(560, ui.w - 20), Math.min(300, ui.h - 30), title);
        if (ui.button("modal.close", { x: r.x + r.w - 14, y: r.y - 18, w: 16, h: 13 }, "x", { tip: "Close (Esc)" })) {
            this.close();
            return;
        }
        if (id === "overview")
            this.overview(r);
        else if (id === "saves")
            this.savesPanel(r);
        else
            this.settingsPanel(r);
        if (this.status && this.g.t - this.status.t < 6)
            ui.label(this.status.text, r.x, r.y + r.h - 9, this.status.ok ? kit2_1.C2.ok : kit2_1.C2.bad);
    }
    overview(r) {
        const g = this.g, ui = this.ui;
        this.tab.overview = ui.tabs("ov.tabs", r.x, r.y, ["Residents", "Areas", "Performance", "Notices"], this.tab.overview);
        const body = { x: r.x, y: r.y + 20, w: r.w, h: r.h - 34 };
        if (this.tab.overview === 0) {
            const rows = g.world.actors;
            const picked = ui.table("ov.res", body, [
                { label: "Name", w: 190, get: (a) => actorLabel(a) },
                { label: "Kind", w: 70, get: (a) => a.kind },
                { label: "Area", w: 100, get: (a) => a.area },
                { label: "Tier", w: 50, get: (a) => (0, lod_1.tierOf)(g.world, a, g.pl), color: (a) => ({ active: kit2_1.C2.ok, near: kit2_1.C2.amber, far: kit2_1.C2.dim })[(0, lod_1.tierOf)(g.world, a, g.pl)] },
                { label: "Doing", w: body.w - 412, get: (a) => cap(actorDoing(a)) },
            ], rows, this.tables.residents);
            if (picked >= 0)
                this.selection = [rows[picked].id];
        }
        else if (this.tab.overview === 1) {
            const areas = [...g.world.areas.values()];
            const spec = (id) => g.world.specs?.[id];
            const picked = ui.table("ov.areas", { ...body, h: body.h - 18 }, [
                { label: "Area", w: 150, get: (a) => a.id + (a.id === g.pl.area ? " *" : "") },
                { label: "Kind", w: 70, get: (a) => spec(a.id)?.kind ?? "authored" },
                { label: "Size", w: 60, get: (a) => `${a.w}x${a.h}` },
                { label: "People", w: 50, get: (a) => String(g.world.actors.filter((x) => x.area === a.id).length), align: "right" },
                { label: "Last ticked", w: 90, get: (a) => (a.id === g.pl.area ? "now" : `${(g.world.time - a.lastTicked).toFixed(0)}s ago`) },
                { label: "Depth", w: body.w - 420, get: (a) => String(spec(a.id)?.depth ?? 0) },
            ], areas, this.tables.areas);
            void picked;
            const by = body.y + body.h - 15;
            let bx = body.x;
            for (const [k, label] of [["floor", "New floor below"], ["cave", "New cave"], ["yard", "New yard"]]) {
                if (ui.button(`ov.new.${k}`, { x: bx, y: by, w: 92, h: 15 }, label, { tip: `Generate a ${k} from the world seed and step into it` })) {
                    this.close();
                    g.generateArea(k);
                    return;
                }
                bx += 96;
            }
            if (ui.button("ov.leave", { x: bx, y: by, w: 80, h: 15 }, "Leave area", { disabled: !g.world.specs?.[g.pl.area], tip: "Walk out by the exit, back to where it was opened" })) {
                this.close();
                g.leaveGenerated();
                return;
            }
            bx += 84;
            const sel = areas[this.tables.areas.sel];
            if (ui.button("ov.forget", { x: bx, y: by, w: 80, h: 15 }, "Forget", { disabled: !sel || !spec(sel.id) || sel.id === g.pl.area, tip: "Delete the selected generated area (it must be empty)" }) && sel) {
                this.tell((0, expedition_1.forgetArea)(g.world, sel.id) ? `Forgot ${sel.id}` : "Somebody is still there", !!spec(sel.id));
            }
            void expedition_1.generatedAreas;
        }
        else if (this.tab.overview === 2) {
            const half = (body.w - 6) / 2;
            ui.graph({ x: body.x, y: body.y, w: half, h: 70 }, this.perf.tick, { label: "Sim ms / tick", unit: "ms", color: kit2_1.C2.accent, budget: g.tickBudgetMs });
            ui.graph({ x: body.x + half + 6, y: body.y, w: half, h: 70 }, this.perf.frame, { label: "Frame ms", unit: "ms", color: kit2_1.C2.gold, budget: 16.7 });
            ui.graph({ x: body.x, y: body.y + 76, w: half, h: 50 }, this.perf.ticks, { label: "Ticks / frame", color: kit2_1.C2.ok, max: 10 });
            const n = (0, lod_1.tierCounts)(g.world, g.pl);
            const lines = [
                `Actors: ${g.world.actors.length}  (active ${n.active}, near ${n.near}, far ${n.far})`,
                `Areas loaded: ${g.world.areas.size}   generated: ${Object.keys(g.world.specs ?? {}).length}`,
                `World tick: ${g.world.tick ?? 0}   sim time ${g.world.time.toFixed(1)}s`,
                `Speed: ${(0, clock_1.speedLabel)(g.clock.speed)}   interpolation ${g.settings.interpolate ? "on" : "off"} (alpha ${g.clock.alpha.toFixed(2)})`,
            ];
            lines.forEach((l, i) => ui.label(l, body.x + half + 10, body.y + 80 + i * font2_1.LINE_H, kit2_1.C2.text));
        }
        else {
            const items = this.feed.items;
            ui.scrollList("ov.notes", { ...body, h: body.h - 18 }, items, 12, (n, _i, row) => {
                (0, font2_1.text2)(ui.ctx, n.level === "alert" ? "!" : n.level === "good" ? "+" : "-", row.x + 4, row.y + 2, n.level === "alert" ? kit2_1.C2.bad : n.level === "good" ? kit2_1.C2.ok : kit2_1.C2.dim);
                (0, font2_1.text2)(ui.ctx, (0, font2_1.ellipsize)(n.text + (n.count > 1 ? ` (x${n.count})` : ""), row.w - 20), row.x + 14, row.y + 2, n.read ? kit2_1.C2.dim : kit2_1.C2.text);
            });
            if (ui.button("ov.readall", { x: body.x, y: body.y + body.h - 15, w: 90, h: 15 }, "Mark all read"))
                this.feed.dismissAll();
        }
    }
    savesPanel(r) {
        const g = this.g, ui = this.ui;
        const slots = [...saveStore_1.MANUAL_SLOTS, saveStore_1.AUTO_SLOT];
        const rows = slots.map((s, i) => ({ slot: s, meta: this.slots[i] ?? null }));
        ui.table("sv.slots", { x: r.x, y: r.y, w: r.w, h: 15 + 12 * 5 + 4 }, [
            { label: "Slot", w: 60, get: (x) => (x.slot === saveStore_1.AUTO_SLOT ? "Autosave" : `Slot ${x.slot.slice(4)}`) },
            { label: "Label", w: 150, get: (x) => x.meta?.label ?? (x.meta ? "-" : "Empty"), color: (x) => (x.meta ? kit2_1.C2.text : kit2_1.C2.faint) },
            { label: "Day", w: 40, get: (x) => (x.meta ? String(Math.floor(x.meta.day) + 1) : ""), align: "right" },
            { label: "Area", w: 110, get: (x) => x.meta?.area ?? "" },
            { label: "Size", w: 60, get: (x) => (x.meta ? `${(x.meta.bytes / 1024).toFixed(1)} KB` : ""), align: "right" },
            { label: "Saved", w: r.w - 422, get: (x) => (x.meta ? ago(x.meta.savedAt) : "") },
        ], rows, this.tables.saves);
        const sel = rows[this.tables.saves.sel] ?? rows[0];
        const by = r.y + 90;
        let bx = r.x;
        const btn = (id, label, tip, disabled = false) => { const hit = ui.button(id, { x: bx, y: by, w: 82, h: 16 }, label, { tip, disabled }); bx += 86; return hit; };
        if (btn("sv.save", "Save here", "Write the current game to this slot (the old one becomes its backup)", sel.slot === saveStore_1.AUTO_SLOT || !g.world))
            g.saveTo(sel.slot);
        if (btn("sv.load", "Load", "Load this slot (falls back to its backups if it is damaged)", !sel.meta)) {
            this.close();
            g.loadFrom(sel.slot);
            return;
        }
        if (btn("sv.del", "Delete", "Delete this slot and its backups", !sel.meta)) {
            g.saves.remove(sel.slot).then(() => { this.refreshSlots(); this.tell(`Deleted ${sel.slot}`); });
        }
        if (btn("sv.export", "Export file", "Download the current game as a file"))
            g.exportSave();
        if (btn("sv.import", "Import file", "Load a game from a file"))
            g.importSave();
        const help = [
            `Autosave: ${g.settings.autosave ? `every ${g.settings.autosaveMinutes} min and on entering an area` : "off"} (rolling backups: 3).`,
            "Saves live in this browser (IndexedDB). Export a file to keep one safe or move it.",
            `Quick save: K (slot 1).  Quick load: L (newest).`,
        ];
        help.forEach((l, i) => ui.label(l, r.x, by + 26 + i * font2_1.LINE_H, kit2_1.C2.dim));
    }
    settingsPanel(r) {
        const g = this.g, ui = this.ui, s = g.settings;
        const sections = [...new Set(settings_1.OPTIONS.map((o) => o.section)), "Controls"];
        this.tab.settings = ui.tabs("st.tabs", r.x, r.y, sections, this.tab.settings);
        const sec = sections[this.tab.settings];
        let y = r.y + 22;
        const rowW = Math.min(360, r.w);
        let changed = false;
        if (sec === "Controls") {
            const colW = (r.w - 6) / 2;
            settings_1.ACTIONS.forEach((a, i) => {
                const x = r.x + (i % 2) * (colW + 6), yy = y + Math.floor(i / 2) * 18;
                const waiting = this.rebinding === a.id;
                ui.label(a.label, x + 4, yy + 4, kit2_1.C2.text);
                if (ui.button(`st.key.${a.id}`, { x: x + colW - 80, y: yy, w: 80, h: 15 }, waiting ? "Press a key" : (0, settings_1.keyName)((0, settings_1.boundKey)(s, a.id)), { on: waiting, tip: "Click, then press the new key (Esc cancels)" })) {
                    this.rebinding = a.id;
                }
            });
            if (this.rebinding) {
                const k = [...ui.keys].find((x) => x !== "enter" && x !== "tab");
                if (k === "escape")
                    this.rebinding = null;
                else if (k) {
                    const def = settings_1.ACTIONS.find((a) => a.id === this.rebinding);
                    // a key moves to its new action: anything else bound to it is put back to its default
                    for (const [id, key] of Object.entries(s.keymap))
                        if (key === k)
                            delete s.keymap[id];
                    if (k === def.key)
                        delete s.keymap[def.id];
                    else
                        s.keymap[def.id] = k;
                    this.rebinding = null;
                    changed = true;
                }
            }
            if (ui.button("st.keys.reset", { x: r.x, y: r.y + r.h - 16, w: 100, h: 15 }, "Reset controls")) {
                s.keymap = {};
                changed = true;
            }
        }
        else {
            for (const o of settings_1.OPTIONS.filter((x) => x.section === sec)) {
                const rr = { x: r.x, y, w: rowW, h: o.kind === "slider" ? 22 : 16 };
                const cur = s[o.id];
                let v = cur;
                if (o.kind === "slider")
                    v = ui.slider(`st.${o.id}`, rr, o.label, cur, o.min, o.max, o.step, o.format, o.hint);
                else if (o.kind === "toggle")
                    v = ui.toggle(`st.${o.id}`, rr, o.label, cur, o.hint);
                else
                    v = ui.choice(`st.${o.id}`, rr, o.label, cur, o.values, o.labels, o.hint);
                if (v !== cur) {
                    s[o.id] = v;
                    changed = true;
                }
                y += rr.h + 4;
            }
            if (sec === "Accessibility")
                ui.paragraph("Overlay colours change the scan mode's highlight categories to palettes that stay distinct for common colour-vision deficiencies.", { x: r.x + rowW + 12, y: r.y + 24, w: r.w - rowW - 12, h: 80 }, kit2_1.C2.dim);
        }
        if (changed)
            g.applySettings(s, true);
    }
}
exports.Shell = Shell;
