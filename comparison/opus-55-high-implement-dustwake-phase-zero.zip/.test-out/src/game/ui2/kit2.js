"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Ui2 = exports.Pointer = exports.C2 = void 0;
// UI framework v2 (Phase 0.5): an immediate-mode widget kit for the hi-res UI layer. No DOM.
//
// Widgets are called every frame while drawing; each returns what the player did to it this frame. Mouse: hover,
// press/release (left, right), drag, wheel. Keyboard and gamepad parity (the gamepad arrives as keys, App.tsx):
// every interactive widget joins a focus order; Tab / Shift+Tab or Up / Down move focus, Enter or Space activates,
// Left / Right adjust sliders, tabs and choices. The kit records the rectangles it drew, so the host can tell
// whether the pointer is over UI (then the world ignores it). Colours follow the world's palette (ui/kit.ts: UI).
const font2_1 = require("./font2");
exports.C2 = {
    bg: "rgba(14,12,18,0.94)", panel: "#16131c", edge: "#3a3540", hi: "#4e4856", text: "#e2dac4", dim: "#8a8392", faint: "#5a5462",
    gold: "#d9b25a", amber: "#f0b050", ok: "#7ae08a", bad: "#e08a7a", accent: "#74dce2", focus: "#f0d27a", row: "#201c27", rowHi: "#2c2636", sel: "#3a3248",
};
/** Pointer state in hi-res UI pixels, fed by the host from DOM events. */
class Pointer {
    constructor() {
        Object.defineProperty(this, "x", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: -1
        });
        Object.defineProperty(this, "y", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: -1
        });
        Object.defineProperty(this, "inside", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "down", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [false, false, false]
        });
        Object.defineProperty(this, "pressed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Set()
        });
        Object.defineProperty(this, "released", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Set()
        });
        Object.defineProperty(this, "wheel", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        /** Where the left button went down (UI px), while it is held. */
        Object.defineProperty(this, "dragFrom", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        /** Set once the held pointer has moved far enough to count as a drag. */
        Object.defineProperty(this, "dragging", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
    }
    move(x, y) {
        this.x = x;
        this.y = y;
        this.inside = true;
        if (this.dragFrom && !this.dragging && Math.hypot(x - this.dragFrom.x, y - this.dragFrom.y) > 6)
            this.dragging = true;
    }
    press(b) { this.down[b] = true; this.pressed.add(b); if (b === 0) {
        this.dragFrom = { x: this.x, y: this.y };
        this.dragging = false;
    } }
    release(b) { this.down[b] = false; this.released.add(b); }
    leave() { this.inside = false; this.x = -1; this.y = -1; }
    /** Clear one-frame state (after the frame has been drawn). */
    endFrame() {
        this.pressed.clear();
        this.wheel = 0;
        if (this.released.has(0)) {
            this.dragFrom = null;
            this.dragging = false;
        }
        this.released.clear();
    }
}
exports.Pointer = Pointer;
const inR = (r, x, y) => x >= r.x && y >= r.y && x < r.x + r.w && y < r.y + r.h;
class Ui2 {
    constructor(ptr) {
        Object.defineProperty(this, "ptr", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: ptr
        });
        Object.defineProperty(this, "ctx", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "w", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 640
        });
        Object.defineProperty(this, "h", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 360
        });
        Object.defineProperty(this, "t", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        /** Keys pressed this frame (lowercase), for keyboard parity. Filled by the host, cleared by `end`. */
        Object.defineProperty(this, "keys", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Set()
        });
        Object.defineProperty(this, "shift", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "regions", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "lastRegions", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "focusOrder", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "lastFocusOrder", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "focus", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        /** The widget the left button went down on (a click needs press and release on the same one). */
        Object.defineProperty(this, "active", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "tip", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "scroll", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        Object.defineProperty(this, "wheelUsed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        /** A modal open this frame: everything outside it ignores the pointer. */
        Object.defineProperty(this, "modalRect", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
    }
    begin(ctx, w, h, t) {
        this.ctx = ctx;
        this.w = w;
        this.h = h;
        this.t = t;
        this.regions = [];
        this.focusOrder = [];
        this.tip = null;
        this.wheelUsed = false;
        this.modalRect = null;
    }
    /** Finish the frame: tooltip on top, focus keys, input cleared. */
    end() {
        if (this.tip)
            this.drawTip(this.tip);
        // focus moves with Tab / Shift+Tab / Up / Down over the order of the frame just drawn
        const order = this.focusOrder;
        if (order.length) {
            const i = this.focus ? order.indexOf(this.focus) : -1;
            const fwd = this.key("tab") && !this.shift || this.key("arrowdown"), back = this.key("tab") && this.shift || this.key("arrowup");
            if (fwd)
                this.focus = order[(i + 1) % order.length];
            else if (back)
                this.focus = order[(i - 1 + order.length) % order.length];
            else if (i < 0 && this.focus)
                this.focus = null;
        }
        this.lastRegions = this.regions;
        this.lastFocusOrder = order;
        if (this.ptr.released.has(0))
            this.active = null;
        this.keys.clear();
    }
    /** Was the pointer over anything the kit drew last frame? (The host asks before letting the world have it.) */
    overUi() { return this.ptr.inside && this.lastRegions.some((r) => inR(r, this.ptr.x, this.ptr.y)); }
    get hasFocusables() { return this.lastFocusOrder.length > 0; }
    key(k) { return this.keys.has(k); }
    /** Claim a rectangle as UI (the world will not get the pointer there). */
    region(r) { this.regions.push(r); }
    hover(r) {
        if (!this.ptr.inside || !inR(r, this.ptr.x, this.ptr.y))
            return false;
        if (this.modalRect && !inR(this.modalRect, this.ptr.x, this.ptr.y))
            return false;
        return true;
    }
    focusable(id) { this.focusOrder.push(id); return this.focus === id; }
    tooltip(text) { this.tip = { text, x: this.ptr.x + 10, y: this.ptr.y + 12 }; }
    drawTip(t) {
        const lines = (0, font2_1.wrap2)(t.text, 180), w = Math.max(...lines.map((l) => (0, font2_1.measure)(l))) + 10, h = lines.length * font2_1.LINE_H + 6;
        const x = Math.min(t.x, this.w - w - 2), y = Math.min(t.y, this.h - h - 2);
        this.box({ x, y, w, h }, "rgba(8,7,10,0.96)", exports.C2.hi);
        lines.forEach((l, i) => (0, font2_1.text2)(this.ctx, l, x + 5, y + 4 + i * font2_1.LINE_H, exports.C2.text));
    }
    // ---------------------------------------------------------------- drawing
    box(r, fill = exports.C2.panel, edge = exports.C2.edge) {
        const c = this.ctx;
        c.fillStyle = edge;
        c.fillRect(r.x, r.y, r.w, r.h);
        c.fillStyle = fill;
        c.fillRect(r.x + 1, r.y + 1, r.w - 2, r.h - 2);
    }
    /** A framed panel with an optional title bar; claims its rectangle. Returns the content rect. */
    panel(r, title) {
        this.region(r);
        const c = this.ctx;
        c.fillStyle = "#08070a";
        c.fillRect(r.x - 1, r.y - 1, r.w + 2, r.h + 2);
        this.box(r, exports.C2.bg, exports.C2.edge);
        c.fillStyle = exports.C2.hi;
        c.fillRect(r.x + 1, r.y + 1, r.w - 2, 1);
        if (!title)
            return { x: r.x + 6, y: r.y + 6, w: r.w - 12, h: r.h - 12 };
        c.fillStyle = "#211c29";
        c.fillRect(r.x + 1, r.y + 2, r.w - 2, 14);
        (0, font2_1.text2)(c, title, r.x + 7, r.y + 5, exports.C2.gold);
        return { x: r.x + 6, y: r.y + 21, w: r.w - 12, h: r.h - 27 };
    }
    label(s, x, y, color = exports.C2.text, align = "left", scale = 1) { return (0, font2_1.text2)(this.ctx, s, x, y, color, scale, align); }
    labelS(s, x, y, color = exports.C2.text, align = "left", scale = 1) { return (0, font2_1.text2s)(this.ctx, s, x, y, color, scale, align); }
    paragraph(s, r, color = exports.C2.text) {
        const lines = (0, font2_1.wrap2)(s, r.w);
        lines.forEach((l, i) => { if ((i + 1) * font2_1.LINE_H <= r.h + 2)
            (0, font2_1.text2)(this.ctx, l, r.x, r.y + i * font2_1.LINE_H, color); });
        return lines.length * font2_1.LINE_H;
    }
    // ---------------------------------------------------------------- widgets
    /** A push button. True on click (press and release on it) or Enter/Space while focused. */
    button(id, r, label, o = {}) {
        this.region(r);
        const hov = !o.disabled && this.hover(r), foc = !o.disabled && this.focusable(id);
        if (hov && this.ptr.pressed.has(0))
            this.active = id;
        const held = this.active === id && this.ptr.down[0];
        this.box(r, o.on ? exports.C2.sel : held ? "#0e0c12" : hov ? exports.C2.rowHi : exports.C2.row, foc ? exports.C2.focus : o.on ? exports.C2.gold : hov ? exports.C2.hi : exports.C2.edge);
        (0, font2_1.text2)(this.ctx, (0, font2_1.ellipsize)(label, r.w - 6), r.x + r.w / 2, r.y + Math.round((r.h - 9) / 2) + 1 + (held ? 1 : 0), o.disabled ? exports.C2.faint : o.color ?? (o.on ? exports.C2.gold : exports.C2.text), 1, "center");
        if (hov && o.tip)
            this.tooltip(o.tip);
        if (o.disabled)
            return false;
        const clicked = hov && this.ptr.released.has(0) && this.active === id;
        return clicked || (foc && (this.key("enter") || this.key(" ")));
    }
    /** A labelled on/off switch. Returns the (possibly flipped) value. */
    toggle(id, r, label, value, tip) {
        this.region(r);
        const hov = this.hover(r), foc = this.focusable(id);
        if (hov)
            this.ctx.fillStyle = exports.C2.rowHi, this.ctx.fillRect(r.x, r.y, r.w, r.h);
        if (hov && this.ptr.pressed.has(0))
            this.active = id;
        (0, font2_1.text2)(this.ctx, label, r.x + 4, r.y + Math.round((r.h - 9) / 2) + 1, foc ? exports.C2.focus : exports.C2.text);
        const sw = { x: r.x + r.w - 26, y: r.y + Math.round((r.h - 10) / 2), w: 22, h: 10 };
        this.box(sw, value ? "#2f5a3a" : "#2a2530", foc ? exports.C2.focus : exports.C2.hi);
        this.ctx.fillStyle = value ? exports.C2.ok : exports.C2.dim;
        this.ctx.fillRect(value ? sw.x + sw.w - 9 : sw.x + 1, sw.y + 1, 8, 8);
        if (hov && tip)
            this.tooltip(tip);
        const flip = (hov && this.ptr.released.has(0) && this.active === id) || (foc && (this.key("enter") || this.key(" ") || this.key("arrowleft") || this.key("arrowright")));
        return flip ? !value : value;
    }
    /** A horizontal slider. Drag or click to set; Left/Right step it while focused. Returns the new value. */
    slider(id, r, label, value, min, max, step, fmt = (v) => v.toFixed(2), tip) {
        this.region(r);
        const hov = this.hover(r), foc = this.focusable(id);
        if (hov && this.ptr.pressed.has(0))
            this.active = id;
        (0, font2_1.text2)(this.ctx, label, r.x + 4, r.y + 2, foc ? exports.C2.focus : exports.C2.text);
        (0, font2_1.text2)(this.ctx, fmt(value), r.x + r.w - 4, r.y + 2, exports.C2.dim, 1, "right");
        const track = { x: r.x + 4, y: r.y + r.h - 7, w: r.w - 8, h: 4 };
        this.box(track, "#2a2530", exports.C2.edge);
        const k = (value - min) / (max - min || 1);
        this.ctx.fillStyle = exports.C2.gold;
        this.ctx.fillRect(track.x + 1, track.y + 1, Math.round((track.w - 2) * k), 2);
        this.ctx.fillStyle = foc || this.active === id ? exports.C2.focus : exports.C2.text;
        this.ctx.fillRect(track.x + Math.round((track.w - 4) * k), track.y - 3, 4, 10);
        if (hov && tip)
            this.tooltip(tip);
        let v = value;
        if (this.active === id && this.ptr.down[0])
            v = min + Math.max(0, Math.min(1, (this.ptr.x - track.x) / track.w)) * (max - min);
        if (foc && this.key("arrowleft"))
            v = value - step;
        if (foc && this.key("arrowright"))
            v = value + step;
        v = Math.round(v / step) * step;
        return Math.max(min, Math.min(max, +v.toFixed(6)));
    }
    /** A cycling choice (a slider over named values). */
    choice(id, r, label, value, values, labels, tip) {
        this.region(r);
        const hov = this.hover(r), foc = this.focusable(id);
        if (hov) {
            this.ctx.fillStyle = exports.C2.rowHi;
            this.ctx.fillRect(r.x, r.y, r.w, r.h);
        }
        if (hov && this.ptr.pressed.has(0))
            this.active = id;
        const ty = r.y + Math.round((r.h - 9) / 2) + 1;
        (0, font2_1.text2)(this.ctx, label, r.x + 4, ty, foc ? exports.C2.focus : exports.C2.text);
        const shown = labels?.[value] ?? value;
        (0, font2_1.text2)(this.ctx, `< ${shown} >`, r.x + r.w - 4, ty, exports.C2.gold, 1, "right");
        if (hov && tip)
            this.tooltip(tip);
        let i = values.indexOf(value);
        if ((hov && this.ptr.released.has(0) && this.active === id) || (foc && (this.key("arrowright") || this.key("enter"))))
            i++;
        if ((hov && this.ptr.released.has(2)) || (foc && this.key("arrowleft")))
            i--;
        return values[(i + values.length) % values.length];
    }
    /** A row of tabs. Returns the selected index. Left/Right switch while any tab is focused; Q/E always. */
    tabs(id, x, y, labels, current, w) {
        let cx = x, sel = current;
        const foc = this.focusable(id);
        labels.forEach((l, i) => {
            const tw = w ?? (0, font2_1.measure)(l) + 14, r = { x: cx, y, w: tw, h: 15 };
            this.region(r);
            const hov = this.hover(r), on = i === current;
            if (hov && this.ptr.pressed.has(0))
                sel = i;
            this.box(r, on ? exports.C2.sel : hov ? exports.C2.rowHi : exports.C2.row, on ? (foc ? exports.C2.focus : exports.C2.gold) : exports.C2.edge);
            (0, font2_1.text2)(this.ctx, l, cx + tw / 2, y + 4, on ? exports.C2.gold : exports.C2.text, 1, "center");
            cx += tw + 2;
        });
        if ((foc && this.key("arrowright")) || this.key("e"))
            sel = (current + 1) % labels.length;
        if ((foc && this.key("arrowleft")) || this.key("q"))
            sel = (current - 1 + labels.length) % labels.length;
        return sel;
    }
    /** A clipped, wheel-scrolled list. `draw` paints one row. Returns the clicked index (or Enter on the focused row), else -1. */
    scrollList(id, r, items, rowH, draw, selected = -1) {
        this.region(r);
        const c = this.ctx, hov = this.hover(r), foc = this.focusable(id);
        this.box(r, "#110f15", foc ? exports.C2.focus : exports.C2.edge);
        const total = items.length * rowH, maxS = Math.max(0, total - (r.h - 2));
        let s = this.scroll.get(id) ?? 0;
        if (hov && this.ptr.wheel && !this.wheelUsed) {
            s += Math.sign(this.ptr.wheel) * rowH * 3;
            this.wheelUsed = true;
        }
        let pick = -1;
        if (foc) {
            let sel = selected;
            if (this.key("pagedown"))
                sel = Math.min(items.length - 1, sel + 8);
            if (this.key("pageup"))
                sel = Math.max(0, sel - 8);
            if (sel !== selected)
                pick = sel;
            if (this.key("enter") && selected >= 0)
                pick = selected;
        }
        if (selected >= 0) {
            const top = selected * rowH;
            if (top < s)
                s = top;
            if (top + rowH > s + r.h - 2)
                s = top + rowH - (r.h - 2);
        }
        s = Math.max(0, Math.min(maxS, s));
        this.scroll.set(id, s);
        c.save();
        c.beginPath();
        c.rect(r.x + 1, r.y + 1, r.w - 2, r.h - 2);
        c.clip();
        const first = Math.floor(s / rowH), last = Math.min(items.length, Math.ceil((s + r.h) / rowH) + 1);
        for (let i = first; i < last; i++) {
            const row = { x: r.x + 1, y: r.y + 1 + i * rowH - s, w: r.w - 2 - (maxS ? 5 : 0), h: rowH };
            const rh = hov && inR(row, this.ptr.x, this.ptr.y);
            c.fillStyle = i === selected ? exports.C2.sel : rh ? exports.C2.rowHi : i % 2 ? "#15121a" : "#110f15";
            c.fillRect(row.x, row.y, row.w, row.h);
            draw(items[i], i, row, rh);
            if (rh && this.ptr.pressed.has(0))
                pick = i;
        }
        c.restore();
        if (maxS) {
            const th = Math.max(10, (r.h - 4) * ((r.h - 2) / total)), ty = r.y + 2 + (r.h - 4 - th) * (s / maxS);
            c.fillStyle = exports.C2.edge;
            c.fillRect(r.x + r.w - 5, r.y + 2, 3, r.h - 4);
            c.fillStyle = exports.C2.dim;
            c.fillRect(r.x + r.w - 5, Math.round(ty), 3, Math.round(th));
        }
        if (!items.length)
            (0, font2_1.text2)(c, "Nothing here.", r.x + r.w / 2, r.y + r.h / 2 - 4, exports.C2.faint, 1, "center");
        return pick;
    }
    /** A sortable table over a scrolling list. Click a header to sort by it (again to reverse). Returns the clicked row index in `rows`. */
    table(id, r, cols, rows, state) {
        const c = this.ctx;
        let cx = r.x + 1;
        cols.forEach((col, i) => {
            const hr = { x: cx, y: r.y, w: col.w, h: 14 };
            this.region(hr);
            const hov = this.hover(hr);
            if (hov && this.ptr.pressed.has(0)) {
                if (state.sort === i)
                    state.desc = !state.desc;
                else {
                    state.sort = i;
                    state.desc = false;
                }
            }
            c.fillStyle = hov ? exports.C2.rowHi : "#211c29";
            c.fillRect(hr.x, hr.y, hr.w - 1, hr.h);
            (0, font2_1.text2)(c, col.label + (state.sort === i ? (state.desc ? " v" : " ^") : ""), cx + 3, r.y + 3, state.sort === i ? exports.C2.gold : exports.C2.dim);
            cx += col.w;
        });
        const key = cols[state.sort]?.get;
        const order = rows.map((_, i) => i);
        if (key)
            order.sort((a, b) => { const x = key(rows[a]), y = key(rows[b]); const nx = parseFloat(x), ny = parseFloat(y); const d = !isNaN(nx) && !isNaN(ny) ? nx - ny : x < y ? -1 : x > y ? 1 : 0; return state.desc ? -d : d; });
        const selPos = order.indexOf(state.sel);
        const picked = this.scrollList(id, { x: r.x, y: r.y + 15, w: r.w, h: r.h - 15 }, order, 12, (ri, _i, row) => {
            let x = row.x;
            for (const col of cols) {
                const v = (0, font2_1.ellipsize)(col.get(rows[ri]), col.w - 6);
                (0, font2_1.text2)(c, v, col.align === "right" ? x + col.w - 4 : x + 3, row.y + 2, col.color?.(rows[ri]) ?? exports.C2.text, 1, col.align === "right" ? "right" : "left");
                x += col.w;
            }
        }, selPos);
        if (picked >= 0)
            state.sel = order[picked];
        if (this.focus === id) {
            if (this.key("arrowright"))
                state.sel = order[Math.min(order.length - 1, selPos + 1)] ?? state.sel;
            if (this.key("arrowleft"))
                state.sel = order[Math.max(0, selPos - 1)] ?? state.sel;
        }
        return picked >= 0 ? order[picked] : -1;
    }
    /** A line graph of `series` (newest last), scaled to `max` (default: the series' peak). */
    graph(r, series, o = {}) {
        this.region(r);
        const c = this.ctx;
        this.box(r, "#110f15", exports.C2.edge);
        const max = o.max ?? Math.max(1e-6, ...series, o.budget ?? 0);
        if (o.budget) {
            const by = r.y + r.h - 2 - (r.h - 4) * Math.min(1, o.budget / max);
            c.fillStyle = "rgba(224,138,122,0.5)";
            for (let x = r.x + 2; x < r.x + r.w - 2; x += 4)
                c.fillRect(x, Math.round(by), 2, 1);
        }
        c.fillStyle = o.color ?? exports.C2.accent;
        const n = series.length, w = r.w - 4;
        for (let i = 0; i < n; i++) {
            const x = r.x + 2 + Math.floor((i / Math.max(1, n - 1)) * (w - 1));
            const v = Math.min(1, series[i] / max), hgt = Math.max(1, Math.round(v * (r.h - 4)));
            c.fillRect(x, r.y + r.h - 2 - hgt, 1, 1);
            c.globalAlpha = 0.25;
            c.fillRect(x, r.y + r.h - 2 - hgt + 1, 1, hgt - 1);
            c.globalAlpha = 1;
        }
        if (o.label)
            (0, font2_1.text2)(c, o.label, r.x + 4, r.y + 3, exports.C2.dim);
        const last = series[n - 1];
        if (last !== undefined)
            (0, font2_1.text2)(c, `${last.toFixed(2)}${o.unit ?? ""}`, r.x + r.w - 4, r.y + 3, exports.C2.text, 1, "right");
    }
    /** Dim everything and draw a centred modal panel; claims the whole screen. Returns its content rect. */
    modal(w, h, title) {
        this.ctx.fillStyle = "rgba(0,0,0,0.55)";
        this.ctx.fillRect(0, 0, this.w, this.h);
        this.region({ x: 0, y: 0, w: this.w, h: this.h });
        const r = { x: Math.round((this.w - w) / 2), y: Math.round((this.h - h) / 2), w, h };
        const inner = this.panel(r, title);
        this.modalRect = r;
        return inner;
    }
    /** A small popup menu (right-click context). Returns the index picked, -1 for none, -2 if dismissed. */
    menu(id, x, y, items) {
        const w = Math.max(80, ...items.map((s) => (0, font2_1.measure)(s) + 16)), h = items.length * 13 + 4;
        const r = { x: Math.min(x, this.w - w - 2), y: Math.min(y, this.h - h - 2), w, h };
        this.region(r);
        this.box(r, "rgba(12,10,16,0.97)", exports.C2.hi);
        let pick = -1;
        items.forEach((s, i) => {
            const row = { x: r.x + 2, y: r.y + 2 + i * 13, w: r.w - 4, h: 13 };
            const hov = this.hover(row), foc = this.focusable(`${id}.${i}`);
            if (hov || foc) {
                this.ctx.fillStyle = exports.C2.sel;
                this.ctx.fillRect(row.x, row.y, row.w, row.h);
            }
            (0, font2_1.text2)(this.ctx, s, row.x + 6, row.y + 3, hov || foc ? exports.C2.gold : exports.C2.text);
            if ((hov && this.ptr.released.has(0)) || (foc && this.key("enter")))
                pick = i;
        });
        if (pick < 0 && ((this.ptr.pressed.size && !this.hover(r)) || this.key("escape")))
            return -2;
        return pick;
    }
}
exports.Ui2 = Ui2;
