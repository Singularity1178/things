"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationFeed = exports.NOTICE_HISTORY = exports.NOTICE_LIFE = void 0;
exports.NOTICE_LIFE = 8;
exports.NOTICE_HISTORY = 120;
class NotificationFeed {
    constructor() {
        Object.defineProperty(this, "items", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "seq", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        /** Set when an alert arrived that should pause the game; the host consumes it. */
        Object.defineProperty(this, "pauseRequested", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
    }
    /** Add a notice. A repeat of the newest unread one bumps its count instead. */
    push(text, level = "info", o = {}) {
        const top = this.items[0];
        if (top && top.text === text && !top.read && top.age < exports.NOTICE_LIFE) {
            top.count++;
            top.age = 0;
            if (level === "alert" && o.pause !== false)
                this.pauseRequested = true;
            return top;
        }
        const n = { id: ++this.seq, text, level, at: o.at ?? 0, age: 0, read: false, area: o.area, count: 1 };
        this.items.unshift(n);
        if (this.items.length > exports.NOTICE_HISTORY)
            this.items.length = exports.NOTICE_HISTORY;
        if (level === "alert" && o.pause !== false)
            this.pauseRequested = true;
        return n;
    }
    /** Age notices by real seconds. */
    update(dt) { for (const n of this.items)
        n.age += dt; }
    /** The notices still showing in the corner (newest first). */
    visible(max = 5) { return this.items.filter((n) => !n.read && n.age < exports.NOTICE_LIFE).slice(0, max); }
    dismiss(id) { const n = this.items.find((x) => x.id === id); if (n)
        n.read = true; }
    dismissAll() { for (const n of this.items)
        n.read = true; }
    get unread() { return this.items.filter((n) => !n.read).length; }
    consumePause() { const p = this.pauseRequested; this.pauseRequested = false; return p; }
    clear() { this.items = []; this.pauseRequested = false; }
}
exports.NotificationFeed = NotificationFeed;
