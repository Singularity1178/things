"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.Game = exports.FOLK_MAX_LINES = exports.FOLK_EARSHOT = exports.BURIED_AMBIENT = exports.ARRIVE = exports.viewSize = exports.ZOOM_DEFAULT = exports.ZOOM_STEPS = exports.H = exports.W = void 0;
// Host + presentation. Owns the canvas, input, screens, camera, particles,
// audio and rendering. It never mutates the World directly except through sim
// entry points; it reacts to the World's events for sound and particles.
const tiles_1 = require("./content/tiles");
const items_1 = require("./content/items");
const inventory_1 = require("./sim/inventory");
const gear_1 = require("./sim/gear");
const debug_1 = require("./sim/debug");
const debugFoundations_1 = require("./sim/debugFoundations");
const gear_2 = require("./content/gear");
const buildMenu_1 = require("./screens/buildMenu");
const crafting_1 = require("./screens/crafting");
const pack_1 = require("./screens/pack");
const storage_1 = require("./screens/storage");
const debug_2 = require("./screens/debug");
const manage_1 = require("./screens/manage");
const transfer_1 = require("./screens/transfer");
const book_1 = require("./screens/book");
const schematic_1 = require("./screens/schematic");
const dialogue_1 = require("./screens/dialogue");
const intro_1 = require("./screens/intro");
const crossing_1 = require("./screens/crossing");
const cutscenes_1 = require("./content/cutscenes");
Object.defineProperty(exports, "ARRIVE", { enumerable: true, get: function () { return cutscenes_1.ARRIVE; } });
const monologue_1 = require("./ui/monologue");
const cards_1 = require("./screens/cards");
const props_1 = require("./content/props");
const flags_1 = require("./content/flags");
const util_1 = require("./util");
const light_1 = require("./light");
const audio_1 = require("./audio");
const circle_1 = require("./circle");
const surfaceRune_1 = require("./surfaceRune");
const runeReveal_1 = require("./runeReveal");
const runes_1 = require("./content/runes");
const runes_2 = require("./sim/runes");
const runeFx_1 = require("./view/runeFx");
const font_1 = require("./font");
const world_1 = require("./world/world");
const step_1 = require("./sim/step");
const interact_1 = require("./sim/interact");
const areaView_1 = require("./view/areaView");
const screens_1 = require("./ui/screens");
const zoom_1 = require("./view/zoom");
Object.defineProperty(exports, "ZOOM_STEPS", { enumerable: true, get: function () { return zoom_1.ZOOM_STEPS; } });
Object.defineProperty(exports, "ZOOM_DEFAULT", { enumerable: true, get: function () { return zoom_1.ZOOM_DEFAULT; } });
Object.defineProperty(exports, "viewSize", { enumerable: true, get: function () { return zoom_1.viewSize; } });
const vision_1 = require("./view/vision");
const daycycle_1 = require("./content/daycycle");
const daytime_1 = require("./sim/daytime");
const reactionsV = __importStar(require("./view/reactions"));
const worldRendererV = __importStar(require("./view/worldRenderer"));
const particlesV = __importStar(require("./view/particles"));
const clock_1 = require("./sim/clock");
const camera_1 = require("./view/camera");
const shell_1 = require("./ui2/shell");
const settings_1 = require("./settings");
const vision_2 = require("./view/vision");
const saveStore_1 = require("./world/saveStore");
const persistence_1 = require("./view/persistence");
const expedition_1 = require("./sim/expedition");
/** Debug super-speed multiplier. 200% faster = base + 2x base = 3x. */
const DEBUG_SPEED_MULT = 3;
/** Base logical size. HUD and overlay screens are laid out for it (they draw on a base-size UI layer). */
exports.W = zoom_1.BASE_W, exports.H = zoom_1.BASE_H;
/** An area with no `ambient` of its own: the dark of the buried halls. */
exports.BURIED_AMBIENT = [0.05, 0.045, 0.065];
const newSeed = () => (Math.random() * 4294967296) >>> 0;
/** How near the golem must be to read townsfolk's own talk as words (px), and how many such lines show at once besides a talk already going. */
exports.FOLK_EARSHOT = 170, exports.FOLK_MAX_LINES = 3;
class Game {
    /** The surface rune's layered art (dormant / awakening / restored), built on first use. */
    get runeArt() { return (this.runeArtCache ?? (this.runeArtCache = new surfaceRune_1.SurfaceRuneArt(this.circle.pixels))); }
    constructor(canvas, uiCanvas, hiCanvas) {
        Object.defineProperty(this, "canvas", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: canvas
        });
        Object.defineProperty(this, "uiCanvas", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: uiCanvas
        });
        /** Base-size (W x H) UI layer: HUD, overlays, title and chapter cards. */
        Object.defineProperty(this, "ctx", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** World layer: the lit scene, sized to the current view (vw x vh). */
        Object.defineProperty(this, "wctx", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Current view size in world pixels (W x H at 1x). */
        Object.defineProperty(this, "vw", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: exports.W
        });
        Object.defineProperty(this, "vh", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: exports.H
        });
        /** Current (possibly easing) zoom and its animation. */
        Object.defineProperty(this, "zoom", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        Object.defineProperty(this, "zoomAnim", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        /** Called when the view size changes (App refits the world canvas). */
        Object.defineProperty(this, "onView", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "scene", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (0, util_1.makeCanvas)(exports.W, exports.H)
        });
        Object.defineProperty(this, "emit", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (0, util_1.makeCanvas)(exports.W, exports.H)
        });
        Object.defineProperty(this, "lighting", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new light_1.Lighting(exports.W, exports.H)
        });
        Object.defineProperty(this, "npcLooks", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        /** Speech bubbles over townsfolk (presentation only): a line said to the golem, or a pictogram in their own talk. */
        Object.defineProperty(this, "bubbles", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        /** The golem's vision mode overlay (presentation of the sim's scan mode). */
        Object.defineProperty(this, "vision", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new vision_1.VisionView()
        });
        Object.defineProperty(this, "lastAnalyzed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { prop: "", t: -1 }
        });
        Object.defineProperty(this, "sfx", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new audio_1.Sfx()
        });
        Object.defineProperty(this, "circle", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (0, circle_1.buildCircle)()
        });
        /** The sky through the throne room's broken roof: a shaft of moonlight, and the same shaft as a sunbeam. */
        Object.defineProperty(this, "shaft", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "sunShaft", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "world", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "view", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "screens", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new screens_1.ScreenStack()
        });
        /** Real (presentation) clock: animations run on it even while the world is paused. */
        Object.defineProperty(this, "t", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "particles", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "toast", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        /** Debug/testing state (not saved, not part of the sim). */
        Object.defineProperty(this, "debugSpeed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        /** The multiplier super speed applies while on (Ctrl+3 uses the default; the debug menu cycles it). */
        Object.defineProperty(this, "debugSpeedMult", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: DEBUG_SPEED_MULT
        });
        Object.defineProperty(this, "debugNoclip", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        /** Corner readout of the area, position and active debug modes. */
        Object.defineProperty(this, "debugHud", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "debugMsg", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "cam", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new camera_1.Camera()
        });
        // ---------------------------------------------------------------- Phase 0: the management shell
        /** Fixed-timestep clock and game speed (sim/clock.ts). */
        Object.defineProperty(this, "clock", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new clock_1.SimClock()
        });
        /** Player preferences (settings.ts). Not saved with the world. */
        Object.defineProperty(this, "settings", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (0, settings_1.loadSettings)(typeof localStorage !== "undefined" ? localStorage : null)
        });
        /** Save slots v2 (IndexedDB in the browser, memory in tests). */
        Object.defineProperty(this, "saves", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (0, persistence_1.browserSaves)()
        });
        Object.defineProperty(this, "autosaver", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new saveStore_1.Autosaver()
        });
        /** Whether any slot holds a save (known after the first listing). */
        Object.defineProperty(this, "hasSaves", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        /** The hi-res UI layer (null in tests that build the host with two canvases). */
        Object.defineProperty(this, "hctx", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "hiCanvas", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        /** The hi-res layer's resolution over the base (settings: UI scale). */
        Object.defineProperty(this, "uiRes", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 2
        });
        Object.defineProperty(this, "shell", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** True while the play screen runs paused (game speed 0): input and presentation, no sim. */
        Object.defineProperty(this, "paused", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        /** Frame budget for one sim tick (ms), drawn on the performance graph and held by the soak test. */
        Object.defineProperty(this, "tickBudgetMs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 4
        });
        /** Actor positions before the last tick of this frame, for interpolated drawing. */
        Object.defineProperty(this, "interp", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "shakeT", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "shakeMag", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "rumbleT", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 50
        });
        Object.defineProperty(this, "eyeBoost", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "crackFlash", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        /** Cracked debris that took a slam and held shudders for a moment (presentation only). */
        Object.defineProperty(this, "shudder", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "fizzT", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "look", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { eye: 0, core: 0, dormant: 1, sparkT: 2, sputter: 0, z: 0 }
        });
        Object.defineProperty(this, "glight", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "keys", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Set()
        });
        Object.defineProperty(this, "pressed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Set()
        });
        Object.defineProperty(this, "dripT", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "target", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "outImg", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "uiTimers", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "S", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Feedback line (blocked actions, pack full, rune dark...). */
        Object.defineProperty(this, "note", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        /** Current rune jump: where the effect plays, how long, and whether it's the first (cinematic) one. */
        Object.defineProperty(this, "tele", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { x: 0, y: 0, dur: 4.6, first: true, travelled: false }
        });
        /** White fade after a short rune hop (1 -> 0). */
        Object.defineProperty(this, "arriveFade", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        /** Stepping through a doorway or along a road into the next area: a short fade up from dark. */
        Object.defineProperty(this, "doorFade", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "hideGolem", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        /**
         * Surface rune override during the arrival cutscene (null: follow its flag).
         * t: redraw progress 0..1, glow: emissive level (>1 = overdriven pulse), column: summon beam 0..1.
         */
        Object.defineProperty(this, "runeAnim", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        /** A rune that refused to carry (E on one that is dark or severed): where it is, and how long its sputter has run (view/runeFx.ts). */
        Object.defineProperty(this, "runeDud", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "runeArtCache", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        /** Build menu, placement and deconstruct tools (screens/buildMenu.ts). */
        Object.defineProperty(this, "buildUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Crafting bench screen (screens/crafting.ts). */
        Object.defineProperty(this, "craftUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Pack / inventory overlay (screens/pack.ts). */
        Object.defineProperty(this, "packUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "storageUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "manageUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "transferUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** The Ctrl+0 debug menu (screens/debug.ts). */
        Object.defineProperty(this, "debugUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Book reading screen (screens/book.ts). */
        Object.defineProperty(this, "bookUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Schematic overlay (screens/schematic.ts). */
        Object.defineProperty(this, "schemUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Dialogue box overlay (screens/dialogue.ts). */
        Object.defineProperty(this, "dialogueUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** The opening cutscene (screens/intro.ts, script in content/cutscenes.ts). */
        Object.defineProperty(this, "introUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** The golem's inner monologue as shown (ui/monologue.ts); the sim emits `thought` events into it. */
        Object.defineProperty(this, "monologue", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new monologue_1.MonologueLog()
        });
        /** Cutscene letterbox: current amount 0..1 and where it is easing to. */
        Object.defineProperty(this, "bars", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { v: 0, to: 0 }
        });
        /** The first crossing to the surface (screens/crossing.ts, script in content/cutscenes.ts). */
        Object.defineProperty(this, "crossingUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Which way a cutscene has the golem drawn facing (null: as the sim says). Presentation only. */
        Object.defineProperty(this, "gaze", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        /** Debug: the calendar clock runs this many times faster (1: normal). Not saved. */
        Object.defineProperty(this, "debugClock", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        /** Under the open sky: seconds until the next bird or cricket. */
        Object.defineProperty(this, "skyT", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 3
        });
        /** Printable characters typed this frame (raw case) and "\b" for Backspace: text fields read these. */
        Object.defineProperty(this, "typed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        // ---------------------------------------------------------------- update
        /** The last update's dt (the folk bubbles age on it while drawing). */
        Object.defineProperty(this, "frameDt", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "visionArtCache", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        /** The pose the golem was last drawn in (world px): vision mode outlines it so it never gets lost under highlights. */
        Object.defineProperty(this, "selfPose", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        this.hiCanvas = hiCanvas ?? null;
        this.hctx = hiCanvas?.getContext("2d") ?? null;
        this.shell = new shell_1.Shell(this);
        this.wctx = canvas.getContext("2d");
        this.wctx.imageSmoothingEnabled = false;
        this.ctx = uiCanvas.getContext("2d");
        this.ctx.imageSmoothingEnabled = false;
        this.outImg = this.wctx.createImageData(exports.W, exports.H);
        this.shaft = this.buildShaft(["#1c2638", "#121a28", "#26324a"]);
        this.sunShaft = this.buildShaft(["#4a3a1c", "#33280f", "#5e4a22"]);
        this.makeScreens();
        this.reset();
        this.screens.set(this.S.title);
        this.applySettings(this.settings, false);
        this.initSaves();
    }
    // ---------------------------------------------------------------- session
    /** Start presenting a world (a fresh session by default, or a loaded one). */
    reset(world = (0, world_1.createWorld)(newSeed())) {
        this.world = world;
        this.view?.dispose();
        const area = (0, world_1.currentArea)(world);
        this.view = new areaView_1.AreaView(area);
        // The schematic is of the dungeon, wherever the golem is.
        this.schemUi.reset(world);
        const pl = (0, world_1.player)(world);
        this.glight = (0, light_1.makeLight)(pl.x, pl.y - 6, gear_2.GOLEM_LIGHT.rad, gear_2.GOLEM_LIGHT.col, 0, 0.05, "golem");
        this.dripT = area.drips.map(() => Math.random() * 4);
        this.look = { eye: 0, core: 0, dormant: 1, sparkT: 1.5, sputter: 0, z: 0 };
        // Zoom is not saved: a world with a mended eye starts at the default zoomed-out view.
        this.zoomAnim = null;
        this.setZoom((0, world_1.hasFlag)(world, flags_1.FLAGS.golemEye) ? zoom_1.ZOOM_DEFAULT : 1);
        this.cam.snap(pl.x - this.vw / 2, pl.y - this.vh / 2 - 10);
        this.npcLooks.clear();
        this.bubbles.clear();
        this.vision.reset(pl.mode === "scan");
        this.dialogueUi.reset();
        this.packUi.reset();
        this.storageUi.reset();
        this.manageUi.reset();
        this.transferUi.reset();
        this.particles = [];
        this.toast = null;
        this.fizzT = 0;
        this.shudder = null;
        this.uiTimers = [];
        this.rumbleT = 45 + Math.random() * 30;
        this.note = null;
        this.arriveFade = 0;
        this.doorFade = 0;
        this.hideGolem = false;
        this.runeAnim = null;
        this.runeDud = null;
        this.gaze = null;
        this.skyT = 3;
        this.monologue.reset();
        this.bars = { v: 0, to: 0 };
    }
    /** Present a saved world, resuming straight into play. */
    resume(world) {
        this.reset(world);
        this.clock.acc = 0;
        this.interp = null;
        this.shell.selection = [];
        this.autosaver.reset((0, world_1.player)(world).area);
        this.look.dormant = 0;
        this.screens.set(this.S.play);
    }
    /** Save the world to the single localStorage slot (K on the play screen). */
    /** Quick save (K): slot 1 (save system v2, world/saveStore.ts). */
    saveGame() { this.saveTo("slot1"); }
    /** Load the saved world and resume play (L on the play or title screen). False if there is none. */
    /** Quick load (L): the newest slot. False (and a note) if there is none; the load itself finishes asynchronously. */
    loadGame() {
        if (!this.hasSaves) {
            this.say("NO SAVED GAME");
            this.sfx.tone(180, 0.1, "square", 0.04);
            return false;
        }
        this.saves.latest().then((m) => { if (m)
            this.loadFrom(m.slot);
        else {
            this.hasSaves = false;
            this.say("NO SAVED GAME");
        } });
        return true;
    }
    /** Rebuild the area view when the player has travelled to another area. */
    syncView() {
        const area = (0, world_1.currentArea)(this.world);
        if (this.view.area === area)
            return;
        this.view.dispose();
        this.view = new areaView_1.AreaView(area);
        this.dripT = area.drips.map(() => Math.random() * 4);
        this.glight.vx = -999;
        // new area: snap the camera instead of panning across the map
        const pl = this.pl;
        this.cam.x = (0, util_1.clamp)(pl.x - this.vw / 2, 0, area.w * tiles_1.TS - this.vw);
        this.cam.y = (0, util_1.clamp)(pl.y - 12 - this.vh / 2, 0, area.h * tiles_1.TS - this.vh);
    }
    // ---------------------------------------------------------------- zoom
    /** Apply a zoom level now: resize the world canvas and the scene/emissive/lighting buffers if the view size changes. */
    setZoom(z) {
        this.zoom = z;
        const { w, h } = (0, zoom_1.viewSize)(z);
        if (w === this.vw && h === this.vh)
            return;
        // keep the view centred on the same point while it grows/shrinks
        this.cam.x -= (w - this.vw) / 2;
        this.cam.y -= (h - this.vh) / 2;
        this.vw = w;
        this.vh = h;
        this.scene = (0, util_1.makeCanvas)(w, h);
        this.emit = (0, util_1.makeCanvas)(w, h);
        this.lighting = new light_1.Lighting(w, h);
        this.canvas.width = w;
        this.canvas.height = h;
        this.wctx.imageSmoothingEnabled = false;
        this.outImg = this.wctx.createImageData(w, h);
        if (this.view) {
            const a = this.area;
            this.cam.x = (0, util_1.clamp)(this.cam.x, 0, a.w * tiles_1.TS - w);
            this.cam.y = (0, util_1.clamp)(this.cam.y, 0, a.h * tiles_1.TS - h);
        }
        this.onView?.(w, h);
    }
    /** Ease to a zoom level over `dur` seconds (presentation clock). */
    zoomTo(z, dur) {
        if (z === this.zoom && !this.zoomAnim)
            return;
        this.zoomAnim = { from: this.zoom, to: z, t: 0, dur };
    }
    stepZoom(dt) {
        const a = this.zoomAnim;
        if (!a)
            return;
        a.t += dt;
        const k = (0, util_1.clamp)(a.t / a.dur, 0, 1), e = k * k * (3 - 2 * k);
        this.setZoom((0, util_1.lerp)(a.from, a.to, e));
        if (k >= 1)
            this.zoomAnim = null;
    }
    /** Mouse wheel (App.tsx): discrete zoom steps, on the play screen only, once the eye is mended. */
    wheel(deltaY) {
        if (!this.screens.is("play") || !(0, world_1.hasFlag)(this.world, flags_1.FLAGS.golemEye) || deltaY === 0)
            return;
        const cur = this.zoomAnim?.to ?? this.zoom;
        const next = (0, zoom_1.nextZoomStep)(cur, deltaY);
        if (next === cur)
            return;
        this.zoomTo(next, 0.25);
        this.sfx.tone(next > cur ? 420 : 560, 0.05, "triangle", 0.03);
    }
    buildShaft(cols) {
        // The shaft has no top. The roof it falls through is out of sight above the view, so the beam must never
        // end on an edge: it keeps the same lean and taper as it climbs, and over its upper half it thins out
        // pixel by pixel until nothing is left of it (FOOT is where it meets the floor: the pool lies below that).
        const FOOT = 150, FADE = 0.55;
        return (0, util_1.makeSprite)(80, FOOT + 10, 40, FOOT, 1, (p) => {
            for (let y = 0; y < FOOT + 10; y++) {
                const t = y / FOOT;
                const cx = (0, util_1.lerp)(22, 40, t), hw = (0, util_1.lerp)(7, 24, t);
                // how much of the beam is there at this height: none at the top, all of it below the fade
                const k = (0, util_1.clamp)(t / FADE, 0, 1), dens = k * k * (3 - 2 * k);
                for (let x = 0; x < 80; x++) {
                    const d = Math.abs(x - cx) / hw;
                    if (y > FOOT) {
                        const e = ((x - 40) / 26) ** 2 + ((y - FOOT - 2) / 7) ** 2;
                        if (e < 1 && (x + y) % 2 === 0)
                            p.g(x, y, 1, 1, cols[2]);
                        continue;
                    }
                    if (d < 1 && (x + y) % 2 === 0 && (0, util_1.hash2)(x, y, 2) > d * 0.8 && (0, util_1.hash2)(x, y, 5) < dens)
                        p.g(x, y, 1, 1, d < 0.5 ? cols[0] : cols[1]);
                }
            }
        });
    }
    // ---------------------------------------------------------------- input
    keyDown(k, shift = false) {
        const raw = k;
        this.shell.ui.shift = shift;
        this.shell.ui.keys.add(k.toLowerCase());
        // remapped controls (settings.ts): the game reads default keys, the player presses theirs
        const mapped = (0, settings_1.translateKey)(this.settings, k);
        if (mapped === null)
            return;
        k = mapped;
        if (!this.keys.has(k))
            this.pressed.add(k);
        this.keys.add(k);
        if (raw.length === 1)
            this.typed.push(raw);
        else if (k === "backspace")
            this.typed.push("\b");
    }
    keyUp(k) { const m = (0, settings_1.translateKey)(this.settings, k); this.keys.delete(m ?? k.toLowerCase()); }
    pointer() { this.pressed.add("click"); }
    /** Debug keybinds (Ctrl+0..6), wired up in App.tsx. Ctrl+0 opens (or closes) the debug menu. */
    debugKey(n) {
        const w = this.world, pl = this.pl;
        const say = (text) => { this.debugMsg = { text, t: 0 }; };
        if (n === 0) {
            this.debugUi.toggle();
        }
        else if (n === 1) {
            // Toggle the iron arm.
            if (this.hasArm) {
                (0, world_1.clearFlag)(w, flags_1.FLAGS.golemArm);
                say("DEBUG: IRON ARM OFF");
            }
            else {
                (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
                say("DEBUG: IRON ARM ON");
            }
        }
        else if (n === 2) {
            // Give every rune glyph, the aether core, the rune chisel and the schematic
            // (skipping any already held or already placed).
            const given = (0, debug_1.grantStoryKit)(w, pl);
            this.sfx.tone(520, 0.1, "triangle", 0.05);
            say(given ? "DEBUG: RUNES + CORE + TOOLS GRANTED" : "DEBUG: ALREADY HAVE ALL RUNES + CORE + TOOLS");
        }
        else if (n === 3) {
            this.debugSpeed = !this.debugSpeed;
            say(this.debugSpeed ? "DEBUG: SUPER SPEED ON" : "DEBUG: SUPER SPEED OFF");
        }
        else if (n === 4) {
            // Building tests: every build knowledge flag (incl. masonry for the brazier),
            // the basket worn on the back (the one in the pack if there is one, else a
            // new one), and enough materials to build one of everything several times.
            (0, debug_1.grantBuildKit)(w, pl);
            say("DEBUG: BUILD + MASONRY + PLANS + BASKET + MATERIALS");
        }
        else if (n === 6) {
            // Gear and crafting tests (sim/debug.ts): ON grants the crafted and raw materials, the chisel and both runes,
            // wears the basket and unlocks every locked gear slot; OFF locks them again (what they hold returns to the pack).
            const on = (0, debug_1.toggleGearKit)(w, pl);
            this.sfx.tone(on ? 560 : 380, 0.1, "triangle", 0.05);
            say(on ? "DEBUG: GEAR KIT ON - ALL SLOTS UNLOCKED" : "DEBUG: GEAR KIT OFF - SLOTS LOCKED AGAIN");
        }
        else if (n === 5) {
            // Toggle the mended eye (golem.eye) and the zoom it unlocks.
            if ((0, world_1.hasFlag)(w, flags_1.FLAGS.golemEye)) {
                w.flags.delete(flags_1.FLAGS.golemEye);
                this.zoomTo(1, 0.4);
                say("DEBUG: EYE REPAIR OFF");
            }
            else {
                (0, world_1.setFlag)(w, flags_1.FLAGS.golemEye);
                this.zoomTo(zoom_1.ZOOM_DEFAULT, 1);
                this.eyeBoost = 1.5;
                say("DEBUG: EYE REPAIR ON (SCROLL TO ZOOM)");
            }
        }
    }
    has(...k) { return k.some((x) => this.keys.has(x)); }
    hit(...k) { return k.some((x) => this.pressed.has(x)); }
    // ---------------------------------------------------------------- debug menu host (screens/debug.ts)
    /** Set or clear a flag from the debug menu. The mended eye also moves the zoom, as Ctrl+5 does. */
    debugSetFlag(flag, on) {
        const w = this.world;
        if (on)
            (0, world_1.setFlag)(w, flag);
        else
            (0, world_1.clearFlag)(w, flag);
        if (flag === flags_1.FLAGS.golemEye) {
            if (on) {
                this.zoomTo(zoom_1.ZOOM_DEFAULT, 0.6);
                this.eyeBoost = 1.5;
            }
            else
                this.zoomTo(1, 0.4);
        }
    }
    /** Put the player at a debug place (any area): the view and camera follow at once. False if no free spot is near. */
    debugTeleport(p) {
        const pl = this.pl;
        if (!(0, debug_1.teleportTo)(this.world, pl, p.area, p.x, p.y))
            return false;
        this.syncView();
        const a = this.area;
        this.cam.x = (0, util_1.clamp)(pl.x - this.vw / 2, 0, Math.max(0, a.w * tiles_1.TS - this.vw));
        this.cam.y = (0, util_1.clamp)(pl.y - 12 - this.vh / 2, 0, Math.max(0, a.h * tiles_1.TS - this.vh));
        this.glight.vx = -999;
        this.particles = [];
        this.drainEvents();
        return true;
    }
    /** A fresh world straight in the dungeon, no intro. */
    debugNewGame() { this.resume((0, world_1.createWorld)(newSeed())); this.say("NEW GAME (DEBUG)"); }
    /** The two-area worker fixture (what window.dustwake.foundations() does). */
    debugFoundations() { this.resume((0, debugFoundations_1.foundationDemo)()); this.say("FOUNDATION FIXTURE: A WORKER GATHERS THROUGH THE RUNES."); }
    /** Step the view zoom through ZOOM_STEPS (ascending order, wrapping). */
    debugZoom() {
        const cur = this.zoomAnim?.to ?? this.zoom;
        const steps = [...zoom_1.ZOOM_STEPS].sort((x, y) => x - y);
        const next = steps.find((z) => z > cur + 1e-6) ?? steps[0];
        this.zoomTo(next, 0.3);
    }
    // ---------------------------------------------------------------- helpers
    get pl() { return (0, world_1.player)(this.world); }
    get area() { return (0, world_1.currentArea)(this.world); }
    get hasArm() { return (0, world_1.hasFlag)(this.world, flags_1.FLAGS.golemArm); }
    spawn(p) { return particlesV.spawn(this, p); }
    shake(t, m) { if (!this.settings.shake)
        return; this.shakeT = Math.max(this.shakeT, t); this.shakeMag = Math.max(this.shakeMag, m); }
    dist2(x, y) { const pl = this.pl, dx = x - pl.x, dy = y - pl.y; return dx * dx + dy * dy; }
    volAt(x, y) { return (0, util_1.clamp)(1 - Math.sqrt(this.dist2(x, y)) / 220, 0, 1); }
    later(delay, fn) { this.uiTimers.push({ at: this.t + delay, fn }); }
    sparkBurst(n) { return particlesV.sparkBurst(this, n); }
    // ---------------------------------------------------------------- screens
    makeScreens() {
        const g = this;
        const scr = (id, opaque, update, render) => ({ id, opaque, t: 0, update, render });
        this.buildUi = new buildMenu_1.BuildUi(this);
        this.craftUi = new crafting_1.CraftingUi(this);
        this.packUi = new pack_1.PackUi(this);
        this.storageUi = new storage_1.StorageUi(this);
        this.manageUi = new manage_1.ManageUi(this);
        this.transferUi = new transfer_1.TransferUi(this, (id) => this.manageUi.open(id));
        this.manageUi.openTransfer = (id) => this.transferUi.open(id);
        this.debugUi = new debug_2.DebugUi(this);
        this.bookUi = new book_1.BookUi(this);
        this.schemUi = new schematic_1.SchematicUi(this);
        this.dialogueUi = new dialogue_1.DialogueUi(this);
        this.introUi = new intro_1.IntroCutscene(this);
        this.crossingUi = new crossing_1.CrossingCutscene(this);
        this.S = {
            title: scr("title", true, (dt) => {
                if (g.hit("l") && g.loadGame()) {
                    g.sfx.init();
                    return;
                }
                if (g.pressed.size) {
                    g.sfx.init();
                    g.introUi.start();
                }
                if (Math.random() < 0.3)
                    g.spawn({ x: Math.random() * exports.W, y: exports.H + 2, vy: -10 - Math.random() * 12, vx: (Math.random() - 0.5) * 4, life: 6, kind: "ember", col: Math.random() < 0.5 ? "#ff8a3a" : "#c84a10", emit: true });
                g.updateParticles(dt);
            }, () => (0, cards_1.renderTitle)(g.ctx, g.t, g.particles)),
            intro: this.introUi.screen,
            play: scr("play", true, (dt) => g.updatePlay(dt), () => g.renderWorldScene()),
            tele: scr("tele", true, (dt) => {
                // the first jump is a cutscene (it runs on into the crossing): Esc skips the whole of it
                if (g.tele.first && g.S.tele.t > 0.2 && g.hit("escape")) {
                    g.skipCrossing();
                    return;
                }
                if (g.updateTele(dt))
                    return;
                (0, step_1.stepPlayer)(g.world, dt, { ix: 0, iy: 0, use: false });
                g.drainEvents();
                g.worldFrame(dt);
            }, () => {
                g.renderWorldScene();
                const t = g.S.tele.t, w0 = g.tele.dur - 1.6;
                if (t > w0) {
                    g.ctx.fillStyle = `rgba(${g.settings.flash ? "235,240,255" : "0,0,0"},${(0, util_1.clamp)((t - w0) / 1.4, 0, 1)})`;
                    g.ctx.fillRect(0, 0, exports.W, exports.H);
                }
                if (g.tele.first)
                    g.renderSkipHint(t);
            }),
            crossing: this.crossingUi.screen,
            book: this.bookUi.screen,
            build: this.buildUi.screen,
            crafting: this.craftUi.screen,
            storage: this.storageUi.screen,
            manage: this.manageUi.screen,
            debug: this.debugUi.screen,
            dialogue: this.dialogueUi.screen,
            inv: this.packUi.screen,
            schem: this.schemUi.screen,
        };
    }
    update(dt) {
        this.frameDt = dt;
        this.t += dt;
        if (this.uiTimers.length) {
            const due = this.uiTimers.filter((u) => u.at <= this.t);
            this.uiTimers = this.uiTimers.filter((u) => u.at > this.t);
            for (const u of due)
                u.fn();
        }
        this.stepZoom(dt);
        this.screens.update(dt);
        this.pressed.clear();
        this.typed.length = 0;
    }
    /** One frame of world simulation plus its presentation. */
    worldFrame(dt) {
        (0, step_1.stepWorld)(this.world, dt);
        if (this.debugClock > 1)
            (0, daytime_1.advanceDay)(this.world, ((this.debugClock - 1) * dt * 24) / daycycle_1.DAY_SECONDS);
        this.drainEvents();
        this.syncView();
        if (this.view.flush())
            this.glight.vx = -999;
        this.updateWorldFx(dt);
    }
    drainEvents() { return reactionsV.drainEvents(this); }
    onNearby(e) { return reactionsV.onNearby(this, e); }
    onEvent(e) { return reactionsV.onEvent(this, e); }
    updatePlay(dt) {
        const w = this.world, pl = this.pl, lk = this.look;
        if (this.paused) {
            // game speed 0: menus and saving still answer, the world holds still, the scene stays alive
            if (this.hit("k"))
                this.saveGame();
            if (this.hit("l") && this.loadGame())
                return;
            if (!pl.task) {
                if (this.hit("i", "tab")) {
                    this.packUi.open("view");
                    return;
                }
                if (this.hit("m") && (0, inventory_1.hasItem)(pl, "schematic")) {
                    this.schemUi.open();
                    return;
                }
                if (this.hit("b")) {
                    this.buildUi.open();
                    return;
                }
            }
            this.animate(dt);
            return;
        }
        (0, step_1.addPlayTime)(w, dt);
        // save / load (one slot in localStorage, the versioned format of world/save.ts)
        if (this.hit("k"))
            this.saveGame();
        if (this.hit("l") && this.loadGame())
            return;
        // overlays
        if (!pl.task) {
            if (this.hit("i", "tab")) {
                this.packUi.open("view");
                return this.worldFrame(dt);
            }
            if (this.hit("m") && (0, inventory_1.hasItem)(pl, "schematic")) {
                this.schemUi.open();
                return this.worldFrame(dt);
            }
            if (this.hit("b")) {
                this.buildUi.open();
                return this.worldFrame(dt);
            }
            if (this.hit("v")) {
                this.buildUi.quickPlace();
                return this.worldFrame(dt);
            }
            // Repeat placement / deconstruction: reopen the tool once the ordered work is done.
            if (this.buildUi.pending) {
                this.buildUi.resumeAfterWork();
                if (!this.screens.is("play"))
                    return this.worldFrame(dt);
            }
            // After crafting at a bench, the bench's plans come back once the work is done.
            if (this.craftUi.pending) {
                this.craftUi.resume();
                if (!this.screens.is("play"))
                    return this.worldFrame(dt);
            }
            // After slotting a core in or out from the management screen, the worker's screen comes back once the reach is done.
            if (this.manageUi.pending) {
                this.manageUi.resume();
                if (!this.screens.is("play"))
                    return this.worldFrame(dt);
            }
        }
        let ix = 0, iy = 0;
        if (this.has("arrowleft", "a"))
            ix -= 1;
        if (this.has("arrowright", "d"))
            ix += 1;
        if (this.has("arrowup", "w"))
            iy -= 1;
        if (this.has("arrowdown", "s"))
            iy += 1;
        // E / Enter interact, Space attacks (the two-arm slam): separate actions, both usable next to anything.
        const res = (0, step_1.stepPlayer)(w, dt, { ix, iy, use: this.hit("e", "enter"), attack: this.hit(" "), core: this.hit("c"), toggleScan: this.hit("z"), speed: this.debugSpeed ? this.debugSpeedMult : 1, noclip: this.debugNoclip });
        this.drainEvents();
        // golem damage sparks
        lk.sparkT -= dt;
        if (lk.sparkT <= 0) {
            lk.sparkT = 1.5 + Math.random() * 4;
            if (!this.hasArm) {
                this.sparkBurst(3 + ((Math.random() * 4) | 0));
                if (Math.random() < 0.6)
                    this.sfx.spark();
            }
            if (Math.random() < 0.12)
                lk.sputter = 0.25;
        }
        lk.sputter = Math.max(0, lk.sputter - dt);
        // The sputter is the damaged body's: the core keeps flickering (the golem is
        // still damaged), but once the guardian mends the eye it no longer gutters.
        lk.core = lk.sputter > 0 ? (Math.random() < 0.5 ? 0.3 : 0.8) : 1;
        lk.eye = lk.sputter > 0 && !(0, world_1.hasFlag)(w, flags_1.FLAGS.golemEye) ? 0.3 : 1;
        lk.dormant = 0;
        this.eyeBoost = Math.max(0, this.eyeBoost - dt);
        this.target = res.target;
        if (res.ui)
            this.packUi.open("select", res.ui.socket);
        // rumble events
        // the buried halls groan; a lived-in room under a sound roof does not
        if (!this.area.base.outdoor && !this.area.base.interior)
            this.rumbleT -= dt;
        if (this.rumbleT <= 0) {
            this.rumbleT = 50 + Math.random() * 50;
            this.sfx.rumble();
            this.shake(2.2, 1.5);
            for (let i = 0; i < 30 * this.zoom * this.zoom; i++)
                this.spawn({ x: this.cam.x + Math.random() * this.vw, y: this.cam.y + Math.random() * this.vh, z: 60 + Math.random() * 40, vz: -10, life: 4, kind: "debris", col: Math.random() < 0.5 ? "#6a6372" : "#4b4552", g: 60 });
        }
        this.worldFrame(dt);
    }
    /** The rune-jump effect (first jump: long, and it runs on into the crossing cutscene; later hops: short). Returns true if it ended. */
    updateTele(_dt) {
        const t = this.S.tele.t, lk = this.look, tl = this.tele, pl = this.pl;
        if (!pl.task && t > 0.2) {
            this.sfx.setHum(0);
            if (tl.first && tl.travelled) {
                this.particles = [];
                this.crossingUi.start();
            }
            else {
                if (tl.first) {
                    this.letterbox(false);
                    this.monologue.release();
                } // the jump failed: there is no crossing to run on into
                this.screens.set(this.S.play);
                this.arriveFade = tl.travelled ? 1 : 0;
                lk.z = tl.travelled ? 16 : 0;
            }
            return true;
        }
        const lift = tl.dur - 1.6;
        lk.z = Math.min(t, lift) * (tl.first ? 4 : 6) + Math.sin(t * 3) * 1;
        lk.eye = 1;
        lk.core = 1;
        this.shake(0.1, Math.min(4, t * 1.2));
        const c = tl;
        for (let i = 0; i < 6; i++) {
            const a = Math.random() * Math.PI * 2, r = 20 + Math.random() * 50;
            this.spawn({ x: c.x + Math.cos(a) * r, y: c.y + Math.sin(a) * r, z: 2, vx: -Math.cos(a) * r * 0.8, vy: -Math.sin(a) * r * 0.8, vz: 10 + Math.random() * 20, life: 1.2, kind: "rune", col: Math.random() < 0.5 ? "#c0a0ff" : "#80e0ff", emit: true, g: -5 });
        }
        this.glight.int = 0.9 + t * 0.4;
        return false;
    }
    /**
     * Esc during the first jump's lift-off: let the sim finish the channel at once (it travels), then end the
     * crossing as if it had played (screens/crossing.ts: the same hour, the same lines thought).
     */
    skipCrossing() {
        const pl = this.pl;
        for (let i = 0; i < 200 && pl.task; i++)
            (0, step_1.stepPlayer)(this.world, 0.1, { ix: 0, iy: 0, use: false });
        this.drainEvents();
        this.sfx.setHum(0);
        this.look.z = 0;
        if (!this.tele.travelled) {
            this.letterbox(false);
            this.monologue.release();
            this.screens.set(this.S.play);
            return;
        }
        this.syncView();
        this.particles = [];
        this.crossingUi.start();
        this.crossingUi.skip();
    }
    // ---------------------------------------------------------------- the hour (content/daycycle.ts)
    /**
     * How lit (0..1) a prop is at this hour. Where people keep the lights (`tended` areas) a lamp follows its kind's
     * habit; anywhere else, and anything the golem built itself, simply stays as it is.
     */
    tendedLevel(p, hour = (0, daytime_1.worldHour)(this.world)) {
        if (!this.area.base.tended || p.dyn)
            return 1;
        const habit = (0, props_1.propDef)(p.kind).habit;
        return habit ? (0, daycycle_1.litLevel)(habit, p.id, hour) : 1;
    }
    onDayPhase(phase) { return reactionsV.onDayPhase(this, phase); }
    /** Debug menu: move the clock on to the next mark of the day. Returns what it now reads. */
    debugAdvanceTime() {
        const marks = [0, 5, 6, 7, 12, 19, 20, 21], h = (0, daytime_1.worldHour)(this.world);
        (0, daytime_1.advanceDayTo)(this.world, marks.find((m) => m > h + 0.01) ?? marks[0]);
        this.drainEvents();
        const now = (0, daytime_1.worldHour)(this.world);
        return `${(0, daycycle_1.clockText)(now)} ${(0, daycycle_1.phaseAt)(now).toUpperCase()}`;
    }
    /**
     * The surface rune's presentation state: the arrival cutscene's, else what the sim says of it (sim/runes.ts:
     * runeState). Dormant: eroded and dark. Restored and linked: carved, its steady pulse. Restored but severed (the
     * circle below is broken, so nothing answers): carved, burning low as embers. While it is refusing someone
     * (`runeDud`), its sputter rides over whichever of those it rests at (view/runeFx.ts).
     */
    surfaceRuneState() {
        if (this.runeAnim)
            return this.runeAnim;
        const state = (0, runes_2.runeState)(this.world, runes_1.RUNE_NODES.surface);
        const rest = state === "linked" ? (0, runeFx_1.linkedGlow)(this.t) : state === "severed" ? (0, runeFx_1.severedGlow)(this.t) : 0;
        const d = this.runeDud, p = d ? this.area.prop(runes_1.RUNE_NODES.surface.prop) : undefined;
        const glow = d && p && Math.hypot(p.x - d.x, p.y - d.y) < 4 ? (0, runeFx_1.runeDudGlow)(d.t, rest, state === "dormant" ? 0.5 : 1) : rest;
        return { t: state === "dormant" ? 0 : 1, glow, column: 0 };
    }
    /** The crossing's arrival act (screens/crossing.ts), `t` seconds in: the overgrown rune wakes and redraws itself, then summons the golem. */
    arriveStep(t, dt) {
        const A = cutscenes_1.ARRIVE, t0 = t - dt, lk = this.look;
        const rp = this.area.prop("rune.surface");
        const c = rp ?? this.pl;
        const crossed = (at) => t >= at && t0 < at;
        const ease = (x) => x * x * (3 - 2 * x);
        const prog = ease((0, util_1.clamp)((t - A.SWEEP) / (A.SWEEP_END - A.SWEEP), 0, 1));
        let glow = 0;
        if (t >= A.GLOW && t < A.SWEEP)
            glow = 0.4 * ease((0, util_1.clamp)((t - A.GLOW) / (A.SWEEP - A.GLOW), 0, 1)) * (0.85 + 0.15 * Math.sin(t * 7));
        else if (t >= A.SWEEP && t < A.SWEEP_END)
            glow = 0.4 + 0.25 * prog + 0.06 * Math.sin(t * 6);
        else if (t >= A.SWEEP_END && t < A.PULSE_END)
            glow = 0.65 + 0.95 * Math.sin((Math.PI * (t - A.SWEEP_END)) / (A.PULSE_END - A.SWEEP_END));
        else if (t >= A.PULSE_END)
            glow = 0.75 + 0.2 * Math.sin(t * 5);
        const column = t < A.PULSE_END ? 0 : t < A.FLASH ? ease((t - A.PULSE_END) / (A.FLASH - A.PULSE_END)) : Math.max(0, 1 - (t - A.FLASH) / 0.9);
        const prev = this.runeAnim?.t ?? 0;
        this.runeAnim = { t: prog, glow, column };
        this.hideGolem = t < A.FLASH;
        // sound follows the phases: a low hum, rising through the sweep; the pulse; the summon
        if (crossed(A.GLOW)) {
            this.sfx.setHum(0.25);
            this.sfx.tone(98, 2.2, "sine", 0.05, 110);
        }
        if (t >= A.SWEEP && t < A.SWEEP_END)
            this.sfx.setHum(0.25 + prog * 0.75);
        if (crossed(A.SWEEP))
            this.sfx.tone(110, A.SWEEP_END - A.SWEEP, "sine", 0.05, 220);
        if (crossed(A.SWEEP_END)) {
            this.sfx.activate();
            this.shake(0.6, 2);
        }
        if (crossed(A.PULSE_END))
            this.sfx.tone(196, A.FLASH - A.PULSE_END, "triangle", 0.04, 392);
        if (crossed(A.FLASH)) {
            this.sfx.teleport();
            this.shake(0.9, 3.5);
            this.sfx.setHum(0.2);
        }
        if (crossed(A.END - 0.5))
            this.sfx.setHum(0);
        const px = this.circle.pixels;
        // motes rising from the lit carvings
        if (glow > 0 && t < A.FLASH && Math.random() < dt * 14 * Math.min(1, glow)) {
            const q = this.runeArt.model.pixels[(Math.random() * px.length) | 0];
            if ((0, runeReveal_1.carvingVisible)(q, prog))
                this.spawn({ x: c.x + q.x, y: c.y + q.y, z: 0, vz: 6 + Math.random() * 10, life: 1.2, kind: "rune", col: Math.random() < 0.6 ? "#a070ff" : "#70d0ff", emit: true, g: -2 });
        }
        // the plants over each stretch the glow reaches wither and blow away
        if (prog > prev) {
            for (const cl of this.runeArt.model.clumps)
                if ((0, runeReveal_1.clumpCleared)(cl, prog) && !(0, runeReveal_1.clumpCleared)(cl, prev))
                    this.witherClump(c.x + cl.x, c.y + cl.y, cl.px.length);
            if (t < A.SWEEP_END)
                this.shake(0.1, 0.3 + prog * 0.8);
        }
        // summon: motes converge on the dais while the column of light builds
        if (t >= A.PULSE_END && t < A.FLASH) {
            this.shake(0.1, 0.4 + column * 2.6);
            for (let i = 0; i < 2 + column * 8; i++) {
                const a = Math.random() * Math.PI * 2, r = 50 + Math.random() * 40;
                this.spawn({ x: c.x + Math.cos(a) * r, y: c.y + Math.sin(a) * r, z: 2 + Math.random() * 6, vx: -Math.cos(a) * r * 1.1, vy: -Math.sin(a) * r * 1.1, vz: 4 + column * 30, life: 0.9, kind: "rune", col: Math.random() < 0.5 ? "#c0a0ff" : "#80e0ff", emit: true, g: -4 });
            }
        }
        if (crossed(A.FLASH))
            for (let i = 0; i < 46; i++) {
                const a = Math.random() * Math.PI * 2, v = 30 + Math.random() * 70;
                this.spawn({ x: c.x, y: c.y + 4, z: 4 + Math.random() * 20, vx: Math.cos(a) * v, vy: Math.sin(a) * v * 0.5, vz: 20 + Math.random() * 40, life: 0.8 + Math.random() * 0.6, kind: "spark", col: Math.random() < 0.5 ? "#e8e0ff" : "#a070ff", emit: true, g: 90 });
            }
        const fall = (0, util_1.clamp)((t - A.FLASH) / A.FALL, 0, 1);
        lk.z = 30 * (1 - fall) ** 2;
        lk.eye = 1;
        lk.core = 1;
        lk.dormant = 0;
        this.cam.x = (0, util_1.clamp)(c.x - this.vw / 2, 0, this.area.w * tiles_1.TS - this.vw);
        this.cam.y = (0, util_1.clamp)(c.y - 12 - this.vh / 2, 0, this.area.h * tiles_1.TS - this.vh);
    }
    /** The arrival is over (played out or skipped): the rune follows its flag again and the golem stands on it, lit. */
    arriveEnd() {
        this.runeAnim = null;
        this.hideGolem = false;
        this.look.z = 0;
        this.look.eye = 1;
        this.look.core = 1;
        this.look.dormant = 0;
        this.sfx.setHum(0);
    }
    /** The golem comes down on the dais: the blow, a ring of dust, the ground answering. */
    landFx() {
        const pl = this.pl;
        this.sfx.slam();
        this.shake(0.35, 2.2);
        for (let i = 0; i < 22; i++) {
            const ang = Math.random() * Math.PI * 2, v = 16 + Math.random() * 30;
            this.spawn({ x: pl.x + Math.cos(ang) * 4, y: pl.y + Math.sin(ang) * 2, z: 1, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v * 0.5, vz: 6 + Math.random() * 12, life: 0.7 + Math.random() * 0.6, kind: "dust", col: Math.random() < 0.5 ? "#8a8478" : "#a09a8c", g: 20 });
        }
        if (!this.hasArm)
            this.sparkBurst(6);
    }
    /** First light from the east during the crossing's dawn: a low gold light across the clearing (0 puts it out). */
    sunrise(level) {
        if (level <= 0 && !this.view.lights.has("sunrise"))
            return;
        const pl = this.pl;
        const lt = this.view.dynamicLight("sunrise", () => (0, light_1.makeLight)(pl.x + 190, pl.y - 30, 330, [1, 0.7, 0.4], 0, 0, "sunrise"));
        lt.int = 0.75 * (0, util_1.clamp)(level, 0, 1);
    }
    clearParticles() { this.particles = []; }
    anyKey() { return this.pressed.size > 0; }
    /** Wake again: a fresh world and the whole opening (R at the crossing's chapter card). */
    wakeAgain() { this.reset(); this.introUi.start(); }
    /** A clump of plants on the rune withers and blows off as the glow reaches it. */
    witherClump(x, y, size) {
        const cols = ["#3e5e2a", "#527636", "#6e8e34", "#7a6a3a", "#5a4630"];
        for (let i = 0; i < 1 + Math.min(4, size / 6); i++)
            this.spawn({ x: x + (Math.random() - 0.5) * 6, y: y + (Math.random() - 0.5) * 4, z: 1, vx: 10 + Math.random() * 22, vy: (Math.random() - 0.5) * 10, vz: 12 + Math.random() * 18, life: 0.7 + Math.random() * 0.7, kind: "debris", col: cols[(Math.random() * cols.length) | 0], g: 26 });
        if (Math.random() < 0.6)
            this.spawn({ x, y, z: 1, vz: 10 + Math.random() * 8, life: 0.8, kind: "rune", col: "#c0a0ff", emit: true, g: -3 });
    }
    /** Over the arrival's world scene: the cut in from black, and the white of the summoning flash. */
    arriveOverlay(t) {
        const A = cutscenes_1.ARRIVE, ctx = this.ctx;
        if (t < A.FADE) {
            ctx.fillStyle = `rgba(0,0,0,${1 - t / A.FADE})`;
            ctx.fillRect(0, 0, exports.W, exports.H);
        }
        if (t > A.FLASH && t < A.FLASH + 1) {
            ctx.fillStyle = `rgba(235,240,255,${1 - (t - A.FLASH)})`;
            ctx.fillRect(0, 0, exports.W, exports.H);
        }
    }
    /** The cinema dressing alone (letterbox, the golem's thoughts), over a picture a cutscene drew itself. */
    renderCinema() {
        this.renderBars();
        const bar = this.bars.v * this.bars.v * (3 - 2 * this.bars.v);
        (0, monologue_1.drawMonologue)(this.ctx, this.monologue, this.t, 7 + Math.round(12 * bar));
    }
    /** "ESC - SKIP", small in the lower bar of a cutscene that can be skipped (`t`: seconds it has run). */
    renderSkipHint(t) {
        const ctx = this.ctx;
        ctx.globalAlpha = (0, util_1.clamp)((t - 0.6) * 1.5, 0, 1) * 0.85;
        (0, font_1.drawText)(ctx, "ESC - SKIP", exports.W - 5, exports.H - 9, "#8a8392", 1, "right");
        ctx.globalAlpha = 1;
    }
    /** Presentation that follows the world each simulated frame. */
    updateWorldFx(dt) {
        const pl = this.pl, area = this.area;
        // camera
        const VW = this.vw, VH = this.vh;
        const tx = (0, util_1.clamp)(pl.x - VW / 2, 0, area.w * tiles_1.TS - VW), ty = (0, util_1.clamp)(pl.y - 12 - VH / 2, 0, area.h * tiles_1.TS - VH);
        this.cam.follow(tx, ty, dt);
        if (!this.settings.flash) {
            this.crackFlash = 0;
            this.arriveFade = 0;
        }
        this.shakeT = Math.max(0, this.shakeT - dt);
        if (this.shakeT <= 0)
            this.shakeMag = 0;
        this.crackFlash = Math.max(0, this.crackFlash - dt);
        if (this.shudder && (this.shudder.t -= dt) <= 0)
            this.shudder = null;
        // golem light
        const gl = this.glight;
        gl.x = pl.x;
        gl.y = pl.y - 6;
        // The glow is the sim's (sim/gear.ts: golemGlow: the standard glow, or what a worn rune of glow makes of it); the light system applies it.
        (0, light_1.applyGlow)(gl, (0, gear_1.golemGlow)(this.world, pl));
        if (Math.abs(gl.x - gl.vx) > 2 || Math.abs(gl.y - gl.vy) > 2)
            (0, light_1.computeVis)(gl, area);
        const base = this.screens.is("tele") ? gl.int : 1.0;
        gl.cur = base * this.look.core * (0.95 + 0.05 * Math.sin(this.t * 13) * Math.sin(this.t * 3.1)) + this.eyeBoost * 0.3;
        // NPCs: eased pose and eye, eye light through the light registry
        this.updateNpcLooks(dt);
        // light flicker, and the hour: tended lamps are lit and put out with the day, sky light takes the sky's colour
        const hour = (0, daytime_1.worldHour)(this.world), sun = (0, daycycle_1.sunLevel)(hour);
        for (const L of this.view.lights.values()) {
            const n = Math.sin(this.t * 9 + L.seed) * 0.5 + Math.sin(this.t * 23.7 + L.seed * 2) * 0.3 + Math.sin(this.t * 3.3 + L.seed) * 0.2;
            L.cur = L.int * (1 - L.flick * (0.5 + 0.5 * n));
            if (L.habit)
                L.day = (0, daycycle_1.litLevel)(L.habit, L.owner, hour);
            else if (L.sky) {
                const s = (0, daycycle_1.skyLight)(L.sky, hour);
                L.r = s.col[0];
                L.g = s.col[1];
                L.b = s.col[2];
                L.day = s.gain;
            }
        }
        // rune
        const r = area.ritual;
        const cl = this.view.byId("circle");
        if (r?.active) {
            this.sfx.setHum(Math.min(1, r.actT / 2));
            if (cl) {
                const target = 120;
                if (cl.rad < target) {
                    cl.rad = Math.min(target, cl.rad + dt * 30);
                    if (Math.abs(cl.rad - cl.vx) > 0)
                        (0, light_1.computeVis)(cl, area);
                }
                cl.int = 0.6 + Math.min(1, r.actT / 3) * 0.6;
                cl.cur = cl.int * (0.85 + 0.15 * Math.sin(this.t * 3));
            }
            const c = area.ritualPos;
            if (Math.random() < dt * 30) {
                const p = this.circle.pixels[(Math.random() * this.circle.pixels.length) | 0];
                this.spawn({ x: c.x + p.x, y: c.y + p.y, z: 0, vz: 8 + Math.random() * 12, life: 1.5, kind: "rune", col: Math.random() < 0.6 ? "#a070ff" : "#70d0ff", emit: true, g: -2 });
            }
        }
        else if (cl) {
            cl.cur = cl.int * (0.8 + 0.2 * Math.sin(this.t * 1.3)) + (this.fizzT > 0 ? Math.random() * 0.6 : 0);
        }
        this.fizzT = Math.max(0, this.fizzT - dt);
        // a rune that refused: its sputter runs its course, spitting sparks off the carvings while it gutters
        if (this.runeDud) {
            const d = this.runeDud;
            if (d.t < runeFx_1.RUNE_DUD.gutter && Math.random() < dt * 40) {
                const p = this.circle.pixels[(Math.random() * this.circle.pixels.length) | 0];
                this.spawn({ x: d.x + p.x, y: d.y + p.y, z: 1, vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.5) * 30, vz: 20 + Math.random() * 30, life: 0.45, kind: "spark", col: Math.random() < 0.5 ? "#ff6a8a" : "#a070ff", emit: true, g: 120 });
            }
            if ((d.t += dt) >= runeFx_1.RUNE_DUD.dur)
                this.runeDud = null;
        }
        // surface rune glow: dark and dead while dormant (no baseline), driven by the cutscene, steady once restored
        const rg = this.view.byId("runeglow");
        if (rg) {
            const st = this.surfaceRuneState();
            rg.cur = rg.int * (st.glow * (0.92 + 0.08 * Math.sin(this.t * 2.3)) + st.column * 0.7);
            // motes rise from the carvings only while the rune has somewhere to carry them
            if (!this.runeAnim && (0, runes_2.runeState)(this.world, runes_1.RUNE_NODES.surface) === "linked" && Math.random() < dt * 8) {
                const p = this.circle.pixels[(Math.random() * this.circle.pixels.length) | 0];
                this.spawn({ x: rg.x + p.x, y: rg.y + p.y, z: 0, vz: 6 + Math.random() * 10, life: 1.4, kind: "rune", col: Math.random() < 0.6 ? "#a070ff" : "#70d0ff", emit: true, g: -2 });
            }
        }
        // short-hop arrival
        if (this.arriveFade > 0) {
            this.arriveFade = Math.max(0, this.arriveFade - dt * 1.4);
            this.look.z = Math.max(0, this.look.z - dt * 24);
        }
        if (this.doorFade > 0)
            this.doorFade = Math.max(0, this.doorFade - dt * 2.8);
        if (this.note) {
            this.note.t += dt;
            if (this.note.t > 3)
                this.note = null;
        }
        this.stepMonologue(dt);
        // drifting leaves on the wind
        if (area.base.outdoor && Math.random() < dt * 1.5)
            this.spawn({ x: this.cam.x - 20 + Math.random() * VW, y: this.cam.y + Math.random() * VH, z: 30 + Math.random() * 40, vx: 8 + Math.random() * 8, vy: (Math.random() - 0.3) * 3, vz: -4 - Math.random() * 3, life: 7, kind: "mote", col: ["#7a5630", "#946a34", "#5a7a34", "#a07c40"][(Math.random() * 4) | 0], emit: false, g: 0 });
        // fireflies under the open sky: the night's, thinning out as the sun comes up
        if (area.base.outdoor && Math.random() < dt * 3 * this.zoom * this.zoom * (1 - sun))
            this.spawn({ x: this.cam.x + Math.random() * VW, y: this.cam.y + Math.random() * VH, z: 6 + Math.random() * 20, vx: (Math.random() - 0.5) * 4, vy: (Math.random() - 0.5) * 3, life: 4, kind: "mote", col: "#d8f080", emit: true, g: 0 });
        // by day: pollen on the air and the odd butterfly instead
        if (area.base.outdoor && Math.random() < dt * 1.2 * this.zoom * this.zoom * sun)
            this.spawn({ x: this.cam.x + Math.random() * VW, y: this.cam.y + Math.random() * VH, z: 8 + Math.random() * 18, vx: (Math.random() - 0.5) * 10, vy: (Math.random() - 0.5) * 6, life: 5, kind: "mote", col: ["#f0e8c0", "#e8c860", "#d8d0e8", "#e89a5a"][(Math.random() * 4) | 0], emit: false, g: 0 });
        // and the open air sounds its hour: birds by day, crickets by night, a hush while one hands over to the other
        if (area.base.outdoor && (this.skyT -= dt) <= 0) {
            this.skyT = 2.5 + Math.random() * 6;
            if (sun > 0.6)
                this.sfx.bird();
            else if (sun < 0.25)
                this.sfx.cricket();
        }
        // drips
        area.drips.forEach((d, i) => {
            this.dripT[i] -= dt;
            if (this.dripT[i] <= 0) {
                this.dripT[i] = 1.5 + Math.random() * 4;
                if (Math.abs(d.x - this.cam.x - VW / 2) < VW / 2 + 100 && Math.abs(d.y - this.cam.y - VH / 2) < VH / 2 + 90)
                    this.spawn({ x: d.x, y: d.y, z: 70, vz: -20, life: 3, kind: "drip", col: "#6a8aa8", g: 140 });
            }
        });
        // torch embers
        for (const p of area.props) {
            if (!p.lit)
                continue;
            const fire = (0, props_1.propDef)(p.kind).fire;
            if (!fire || this.tendedLevel(p, hour) <= 0.05)
                continue;
            if (Math.abs(p.x - this.cam.x - VW / 2) > VW / 2 + 40 || Math.abs(p.y - this.cam.y - VH / 2) > VH / 2 + 50)
                continue;
            if (Math.random() < dt * fire.embers)
                this.spawn({ x: p.x + (Math.random() - 0.5) * 4, y: p.y + fire.emberDy, z: 14, vx: (Math.random() - 0.5) * 6, vz: 10 + Math.random() * 10, life: 1 + Math.random(), kind: "ember", col: Math.random() < 0.5 ? "#ffb040" : "#ff6a1a", emit: true, g: -4 });
        }
        // chimney smoke over the town's roofs (props with a `smoke` row), leaning on the same night wind as the leaves
        for (const p of area.props) {
            const sm = (0, props_1.propDef)(p.kind).smoke;
            if (!sm || Math.abs(p.x - this.cam.x - VW / 2) > VW / 2 + 40 || Math.abs(p.y - this.cam.y - VH / 2) > VH / 2 + 70)
                continue;
            if (Math.random() < dt * sm.rate * (area.base.tended ? (0, daycycle_1.hearthSmoke)(hour) : 1)) // thick at breakfast and supper
                this.spawn({ x: p.x + sm.dx + (Math.random() - 0.5) * 3, y: p.y, z: sm.z, vx: 3 + Math.random() * 4, vy: (Math.random() - 0.5) * 1.5, vz: 7 + Math.random() * 5, life: 2.2 + Math.random() * 1.8, kind: "smoke", col: Math.random() < 0.5 ? "#6e6a70" : "#585460", g: -1, size: 2, emit: false });
        }
        // ambient dust motes
        if (Math.random() < dt * 8 * this.zoom * this.zoom)
            this.spawn({ x: this.cam.x + Math.random() * VW, y: this.cam.y + Math.random() * VH, z: 4 + Math.random() * 30, vx: (Math.random() - 0.5) * 3, vy: (Math.random() - 0.5) * 2, vz: (Math.random() - 0.5) * 2, life: 5, kind: "mote", col: "#b8b0a0", emit: false, g: 0 });
        // moonbeam motes
        const moon = this.view.byId("moon");
        if (moon && Math.random() < dt * 5)
            this.spawn({ x: moon.x - 14 + Math.random() * 30, y: moon.y + 2, z: 10 + Math.random() * 70, vx: (Math.random() - 0.5) * 2, vz: -3 - Math.random() * 3, life: 6, kind: "mote", col: sun > 0.5 ? "#ffe8b0" : "#a8c0ff", emit: true, g: 0 });
        // item glints
        if (Math.random() < dt * 2) {
            const cands = [];
            for (const it of (0, interact_1.interactables)(area))
                if (it.kind === "item" || it.kind === "propItem" || (it.kind === "container" && it.hasItem))
                    cands.push([it.x, it.y - (it.itemZ ?? 6) - 2]);
            const near = cands.filter(([x, y]) => Math.abs(x - this.cam.x - VW / 2) < VW / 2 + 10 && Math.abs(y - this.cam.y - VH / 2) < VH / 2 + 10);
            if (near.length) {
                const [x, y] = near[(Math.random() * near.length) | 0];
                this.spawn({ x: x + (Math.random() - 0.5) * 8, y: y + 2, z: 2 + Math.random() * 4, life: 0.45, kind: "glint", col: "#fff4d0", emit: true });
            }
        }
        if (this.debugMsg) {
            this.debugMsg.t += dt;
            if (this.debugMsg.t > 2)
                this.debugMsg = null;
        }
        // toast
        if (this.toast) {
            this.toast.t += dt;
            if (this.toast.t > 3)
                this.toast = null;
        }
        // vision mode: follows the sim's mode; the lock-on reticle sits on whatever E would act on
        const focus = this.screens.is("play") && this.target ? visionId(this.target) : null;
        for (const c of this.vision.update(dt, this.world, pl, gl, focus, this.visionArt()))
            this.onVisionCue(c);
        this.updateParticles(dt);
    }
    visionArt() { return worldRendererV.visionArt(this); }
    /** Where the golem's eye is (world px), for the scanner's glint and the data stream home. */
    eyeSpot() {
        if (this.hideGolem)
            return null;
        const pl = this.pl, lk = this.look, f = pl.facing;
        const y = Math.round(pl.y - lk.z) - 18 + Math.round(lk.dormant * 4) + Math.round(lk.dormant * 3);
        const x = Math.round(pl.x) + (f === "right" ? 2 : f === "left" ? -4 : -2);
        return { x, y, w: f === "down" ? 4 : 2, show: f !== "up" };
    }
    onVisionCue(c) { return reactionsV.onVisionCue(this, c); }
    updateParticles(dt) { return particlesV.updateParticles(this, dt); }
    // ---------------------------------------------------------------- UiHost
    say(text) { this.note = { text, t: 0 }; }
    // ---------------------------------------------------------------- CutsceneHost (screens/intro.ts)
    letterbox(on) { this.bars.to = on ? 1 : 0; if (on)
        this.bars.v = 1; }
    startPlay() { this.screens.set(this.S.play); }
    renderScene() { this.renderWorldScene(); }
    /** Type the monologue and ease the letterbox (presentation clock, scenes and animating overlays). */
    stepMonologue(dt) {
        const s = this.monologue.update(dt);
        if (s.started)
            this.sfx.thoughtStart();
        for (let i = 0; i < s.typed; i++)
            this.sfx.thoughtTick(s.tone === "void");
        const b = this.bars;
        if (b.v !== b.to)
            b.v = b.to > b.v ? Math.min(b.to, b.v + dt * 4) : Math.max(b.to, b.v - dt * 2.2);
    }
    /** Cutscene letterbox bars (they slide away when the player gets control). */
    renderBars() {
        const b = this.bars.v;
        if (b <= 0)
            return;
        const e = b * b * (3 - 2 * b), h = Math.round(14 * e);
        this.ctx.fillStyle = "#000";
        this.ctx.fillRect(0, 0, exports.W, h);
        this.ctx.fillRect(0, exports.H - h, exports.W, h);
    }
    /** Open an item's reading screen (pack E, UiHost.read). */
    read(id) {
        const opens = items_1.ITEMS[id].opens;
        if (opens === "schematic")
            this.schemUi.open();
        else if (opens === "book")
            this.bookUi.open(id);
    }
    boostEye(level) { this.eyeBoost = level; }
    /** World presentation without simulation (overlays that keep the scene alive, e.g. dialogue). */
    animate(dt) { this.updateWorldFx(dt); }
    renderNote(y = exports.H - 40) {
        if (!this.note)
            return;
        const ctx = this.ctx;
        ctx.globalAlpha = (0, util_1.clamp)(3 - this.note.t, 0, 1);
        (0, font_1.drawTextS)(ctx, this.note.text, exports.W / 2, y, "#e8d8b0", 1, "center", "#000");
        ctx.globalAlpha = 1;
    }
    // ---------------------------------------------------------------- render
    // ---------------------------------------------------------------- Phase 0: frame loop, interpolation
    /**
     * One browser frame (App.tsx): the shell takes the mouse, then the sim runs as many fixed ticks as the real time
     * and game speed owe (sim/clock.ts). Screens other than play always run at 1x; a paused play screen still gets
     * input and presentation, but no sim.
     */
    frame(realDt) {
        const now = () => (typeof performance !== "undefined" ? performance.now() : Date.now());
        this.shell.update(realDt);
        this.shell.sample("frame", realDt * 1000);
        const play = this.screens.is("play");
        if (play && this.clock.speed === 0) {
            this.paused = true;
            try {
                this.update(realDt);
            }
            finally {
                this.paused = false;
            }
            this.shell.sample("ticks", 0);
        }
        else {
            const n = this.clock.advance(realDt, play ? this.clock.speed : 1);
            const t0 = now();
            for (let i = 0; i < n; i++) {
                this.snapshot();
                this.update(clock_1.TICK);
            }
            if (n)
                this.shell.sample("tick", (now() - t0) / n);
            this.shell.sample("ticks", n);
        }
        if (this.screens.is("play") && this.clock.speed !== 0) {
            this.autosaver.enabled = this.settings.autosave;
            this.autosaver.interval = this.settings.autosaveMinutes * 60;
            const why = this.autosaver.tick(realDt, this.pl.area);
            if (why)
                this.saveTo("auto", true);
        }
    }
    /** Remember where everything in view stood before a tick (only the play screen interpolates). */
    snapshot() {
        if (!this.screens.is("play")) {
            this.interp = null;
            return;
        }
        const area = this.pl.area, pos = new Map();
        for (const a of this.world.actors)
            if (a.area === area)
                pos.set(a.id, [a.x, a.y]);
        this.interp = { area, pos };
        this.cam.mark();
    }
    /** Draw with actors and camera `alpha` of the way between the last two ticks, then put the sim state back. */
    withInterpolation(draw) {
        const ip = this.interp, alpha = this.clock.alpha;
        if (!ip || !this.settings.interpolate || alpha >= 1 || !this.screens.has("play") || ip.area !== this.pl.area)
            return draw();
        const saved = [];
        for (const a of this.world.actors) {
            const p = ip.pos.get(a.id);
            if (!p || a.area !== ip.area)
                continue;
            const dx = a.x - p[0], dy = a.y - p[1];
            if (dx * dx + dy * dy > 32 * 32 || (!dx && !dy))
                continue; // teleports and doorways snap
            saved.push([a, a.x, a.y]);
            a.x = p[0] + dx * alpha;
            a.y = p[1] + dy * alpha;
        }
        const cx = this.cam.x, cy = this.cam.y, c = this.cam.at(alpha);
        if (Math.abs(cx - this.cam.px) < 64 && Math.abs(cy - this.cam.py) < 64) {
            this.cam.x = c.x;
            this.cam.y = c.y;
        }
        try {
            draw();
        }
        finally {
            for (const [a, x, y] of saved) {
                a.x = x;
                a.y = y;
            }
            this.cam.x = cx;
            this.cam.y = cy;
        }
    }
    /** Apply preferences now (audio, overlay palette, UI scale); `persist` writes them to the browser. */
    applySettings(s, persist) {
        this.settings = s;
        this.sfx.setVolume(s.master, s.ambience);
        (0, vision_2.setOverlayPalette)(settings_1.OVERLAY_PALETTES[s.palette]);
        this.uiRes = settings_1.UI_RES[s.uiScale];
        if (this.hiCanvas) {
            const w = Math.round(exports.W * this.uiRes), h = Math.round(exports.H * this.uiRes);
            if (this.hiCanvas.width !== w || this.hiCanvas.height !== h) {
                this.hiCanvas.width = w;
                this.hiCanvas.height = h;
            }
        }
        if (persist)
            (0, settings_1.saveSettings)(s, typeof localStorage !== "undefined" ? localStorage : null);
    }
    // ---------------------------------------------------------------- Phase 0: saves v2
    initSaves() {
        const legacy = typeof localStorage !== "undefined" ? this.saves.importLegacy(localStorage).catch(() => false) : Promise.resolve(false);
        legacy.then((imported) => {
            if (imported)
                this.shell.feed.push("Your old save was moved to slot 1", "good");
            return this.saves.latest();
        }).then((m) => { this.hasSaves = !!m; }, () => { });
    }
    /** Write the world to a slot (async); `quiet` for autosaves (a notice, no note). */
    saveTo(slot, quiet = false) {
        const w = this.world;
        this.saves.save(slot, w, quiet ? `Autosave (${w.areas.get((0, world_1.player)(w).area)?.base.portals ? (0, world_1.player)(w).area : (0, world_1.player)(w).area})` : undefined).then((m) => {
            this.hasSaves = true;
            this.shell.refreshSlots();
            this.shell.feed.push(`${slot === "auto" ? "Autosaved" : `Saved to ${slot}`} (${(m.bytes / 1024).toFixed(1)} KB)`, "good", { at: w.time });
            if (!quiet) {
                this.say("GAME SAVED");
                this.sfx.tone(520, 0.1, "triangle", 0.05);
            }
            this.shell.tell(`Saved to ${slot}`);
        }, (e) => {
            this.shell.feed.push(`Could not save: ${e.message}`, "alert", { pause: false });
            if (!quiet) {
                this.say("COULD NOT SAVE");
                this.sfx.tone(180, 0.1, "square", 0.04);
            }
        });
    }
    /** Load a slot (async), recovering from its backups if it is damaged. */
    loadFrom(slot) {
        this.saves.load(slot).then((r) => {
            this.resume(r.world);
            this.say("GAME LOADED");
            if (r.recovered)
                this.shell.feed.push(`${slot} was damaged: loaded its backup (${r.from})`, "alert", { pause: false });
        }, (e) => {
            this.shell.feed.push(`Could not load ${slot}: ${e.message}`, "alert", { pause: false });
            this.say("NO SAVED GAME");
            this.sfx.tone(180, 0.1, "square", 0.04);
        });
    }
    exportSave() { try {
        (0, persistence_1.downloadSave)(this.world);
        this.shell.tell("Exported the current game");
    }
    catch (e) {
        this.shell.tell(`Export failed: ${e.message}`, false);
    } }
    exportText() { return (0, saveStore_1.exportText)(this.world); }
    importSave() {
        (0, persistence_1.pickSaveFile)().then((text) => {
            if (text === null)
                return;
            try {
                const w = (0, saveStore_1.importText)(text);
                this.shell.close();
                this.resume(w);
                this.shell.feed.push("Imported a save file", "good");
            }
            catch (e) {
                this.shell.tell(`Import failed: ${e.message}`, false);
            }
        });
    }
    // ---------------------------------------------------------------- Phase 0: generated areas
    generateArea(kind) {
        const spec = (0, expedition_1.openGeneratedArea)(this.world, this.pl, kind);
        if (!spec)
            return;
        this.drainEvents();
        this.syncView();
        this.doorFade = 1;
        this.shell.feed.push(`Opened ${spec.id} (${spec.w}x${spec.h}, seed ${spec.seed})`, "info", { at: this.world.time });
    }
    leaveGenerated() {
        if ((0, expedition_1.leaveGeneratedArea)(this.world, this.pl)) {
            this.drainEvents();
            this.syncView();
            this.doorFade = 1;
        }
    }
    /** Sim events worth a notification (view/reactions.ts calls this for each event it drains). */
    noticeEvent(e) {
        const w = this.world, feed = this.shell.feed, me = w.playerId;
        if (e.t === "jobChanged" && (e.status === "blocked" || e.status === "failed"))
            feed.push(`${(0, world_1.actorById)(w, e.actor)?.name ?? e.actor}: order ${e.status}${e.reason ? ` (${e.reason})` : ""}`, "alert", { at: w.time });
        else if (e.t === "packFull" && e.actor === me)
            feed.push("The pack is full", "alert", { at: w.time, pause: false });
        else if (e.t === "dayPhase")
            feed.push(`Day ${e.day + 1}: ${e.phase}`, "info", { at: w.time });
        else if (e.t === "powerChanged" && e.actor !== me)
            feed.push(`${(0, world_1.actorById)(w, e.actor)?.name ?? e.actor} ${e.powered ? "powered up" : "lost power"}`, e.powered ? "good" : "alert", { at: w.time });
        else if (e.t === "travelled" && e.actor !== me)
            feed.push(`${(0, world_1.actorById)(w, e.actor)?.name ?? e.actor} travelled to ${e.to}`, "info", { at: w.time });
        else if (e.t === "learned")
            feed.push(`Learned: ${e.flag}`, "good", { at: w.time });
    }
    render() {
        this.ctx.clearRect(0, 0, exports.W, exports.H);
        this.withInterpolation(() => {
            this.screens.render();
            if (this.hctx && this.hiCanvas)
                this.shell.render(this.hctx, this.hiCanvas.width, this.hiCanvas.height);
        });
    }
    renderWorldScene() {
        this.view.flush();
        this.renderWorld();
        this.renderHud();
    }
    renderWorld() { return worldRendererV.renderWorld(this); }
    drawSurfaceRune(p, camX, camY) { return worldRendererV.drawSurfaceRune(this, p, camX, camY); }
    /** The summoning beam: a shimmering column of light rising from the dais (emissive only). */
    drawSummonColumn(x, y, k) {
        const ec = this.emit.ctx;
        x = Math.round(x);
        y = Math.round(y);
        const w = Math.round(3 + 7 * k);
        ec.globalCompositeOperation = "lighter";
        for (let yy = y + 4; yy > -2; yy -= 2) {
            const f = 1 - ((y - yy) / Math.max(1, y + 2)) * 0.6;
            const wob = Math.round(Math.sin(yy * 0.21 + this.t * 9) * k);
            ec.globalAlpha = (0, util_1.clamp)(k * f * 0.5, 0, 1);
            ec.fillStyle = "#9a70ff";
            ec.fillRect(x - w + wob, yy - 2, w * 2, 2);
            ec.globalAlpha = (0, util_1.clamp)(k * f, 0, 1);
            ec.fillStyle = "#e8e0ff";
            ec.fillRect(x - 1 + wob, yy - 2, 2 + Math.round(k * 2), 2);
        }
        ec.globalAlpha = (0, util_1.clamp)(k * 0.6, 0, 1);
        ec.fillStyle = "#c0a0ff";
        ec.fillRect(x - 14, y - 3, 28, 8);
        ec.globalAlpha = 1;
        ec.globalCompositeOperation = "source-over";
    }
    drawDimmed(s, p, lvl, whole, camX, camY) { return worldRendererV.drawDimmed(this, s, p, lvl, whole, camX, camY); }
    drawSwaying(s, p, camX, camY) { return worldRendererV.drawSwaying(this, s, p, camX, camY); }
    drawFlame(p, big, camX, camY) { return worldRendererV.drawFlame(this, p, big, camX, camY); }
    drawPedestal(p, i, spr, camX, camY) { return worldRendererV.drawPedestal(this, p, i, spr, camX, camY); }
    drawPlayer(camX, camY) { return worldRendererV.drawPlayer(this, camX, camY); }
    npcLook(a) { return worldRendererV.npcLook(this, a); }
    updateNpcLooks(dt) { return worldRendererV.updateNpcLooks(this, dt); }
    updateWorkerLook(a, dt) { return worldRendererV.updateWorkerLook(this, a, dt); }
    updateFolkLook(a) { return worldRendererV.updateFolkLook(this, a); }
    renderFolkBubbles(dt) { return worldRendererV.renderFolkBubbles(this, dt); }
    workerCue(a, cue) { return reactionsV.workerCue(this, a, cue); }
    runeBlip(x, y, k = 1) { return reactionsV.runeBlip(this, x, y, k); }
    runeBurst(x, y) { return reactionsV.runeBurst(this, x, y); }
    runeRefused(x, y) { return reactionsV.runeRefused(this, x, y); }
    workerWalked(e) { return reactionsV.workerWalked(this, e); }
    workerTravelled(e) { return reactionsV.workerTravelled(this, e); }
    coreSparks(a, n, bright) { return reactionsV.coreSparks(this, a, n, bright); }
    npcSparks(a, n) { return reactionsV.npcSparks(this, a, n); }
    npcDust(a) { return reactionsV.npcDust(this, a); }
    renderHud() { return worldRendererV.renderHud(this); }
    renderClock() { return worldRendererV.renderClock(this); }
    renderToast(y) { return worldRendererV.renderToast(this, y); }
}
exports.Game = Game;
/** The vision target id of an interaction target (sim/analysis.ts: visionTargets ids). */
function visionId(t) {
    return t.propId ?? t.looseId ?? t.actorId ?? (t.tx !== undefined && t.ty !== undefined ? `tile:${t.tx},${t.ty}` : null);
}
