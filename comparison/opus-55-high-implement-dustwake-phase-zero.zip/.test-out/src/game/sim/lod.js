"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FAR_CHUNK = exports.FAR_INTERVAL = exports.NEAR_CHUNK = exports.NEAR_INTERVAL = exports.ACTIVE_BOX = void 0;
exports.tierOf = tierOf;
exports.stepAtTier = stepAtTier;
exports.clearDebt = clearDebt;
exports.registerCatchUp = registerCatchUp;
exports.catchUpArea = catchUpArea;
exports.tierCounts = tierCounts;
/** Half-extents of the active box around the player (px): the 2x view is 640x360, plus a margin for walking in. */
exports.ACTIVE_BOX = { x: 400, y: 260 };
/** Sim seconds between steps of a near / far actor, and the longest single step it is given (chunks). */
exports.NEAR_INTERVAL = 0.1, exports.NEAR_CHUNK = 0.1;
exports.FAR_INTERVAL = 0.25, exports.FAR_CHUNK = 0.25;
/** The tier of `a` relative to the player (`focus`). The player is always active. */
function tierOf(_w, a, focus) {
    if (!focus || a.id === focus.id)
        return "active";
    if (a.area !== focus.area)
        return "far";
    return Math.abs(a.x - focus.x) <= exports.ACTIVE_BOX.x && Math.abs(a.y - focus.y) <= exports.ACTIVE_BOX.y ? "active" : "near";
}
const debtOf = (w) => (w.lod ?? (w.lod = {}));
/**
 * Step `a` by `dt` at its tier: `step(dt)` immediately when active; otherwise the time is owed until the tier's
 * interval has passed, then paid in chunks no longer than the tier's chunk. Returns the sim time actually stepped.
 */
function stepAtTier(w, a, tier, dt, step, key = a.id) {
    const debt = debtOf(w);
    if (tier === "active") {
        const owed = debt[key] ?? 0;
        if (owed)
            delete debt[key];
        let left = owed + dt, done = 0;
        // an actor that just came into full detail first pays what it owed, in steps no longer than this tick's
        while (left > 1e-9) {
            const c = Math.min(left, dt > 0 ? dt : left);
            step(c);
            left -= c;
            done += c;
        }
        return done;
    }
    const interval = tier === "near" ? exports.NEAR_INTERVAL : exports.FAR_INTERVAL, chunk = tier === "near" ? exports.NEAR_CHUNK : exports.FAR_CHUNK;
    const owed = (debt[key] ?? 0) + dt;
    if (owed + 1e-9 < interval) {
        debt[key] = owed;
        return 0;
    }
    delete debt[key];
    let left = owed;
    while (left > 1e-9) {
        const c = Math.min(left, chunk);
        step(c);
        left -= c;
    }
    return owed;
}
/** Forget what an idle actor owed (nothing to catch up on; it must not burst when given work). */
function clearDebt(w, id) { if (w.lod && id in w.lod)
    delete w.lod[id]; }
const CATCH_UPS = [];
/** Register what an area does when the player enters it after `elapsed` sim seconds away (idempotent by id). */
function registerCatchUp(id, fn) {
    const i = CATCH_UPS.findIndex((c) => c.id === id);
    if (i >= 0)
        CATCH_UPS[i].fn = fn;
    else
        CATCH_UPS.push({ id, fn });
}
/** Run every catch-up hook for `area` (stepWorld calls this when the player's area changes). */
function catchUpArea(w, area) {
    const elapsed = Math.max(0, w.time - area.lastTicked);
    if (elapsed > 0)
        for (const c of CATCH_UPS)
            c.fn(w, area, elapsed);
    area.lastTicked = w.time;
    return elapsed;
}
// The translocation circle's charge: areas off the player's path skip it, and it is credited on entry.
registerCatchUp("ritual", (_w, area, elapsed) => area.advanceRitual(elapsed));
/** Counts by tier, for the overview and the soak report. */
function tierCounts(w, focus) {
    const n = { active: 0, near: 0, far: 0 };
    for (const a of w.actors)
        n[tierOf(w, a, focus)]++;
    return n;
}
