"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.populateResidents = populateResidents;
exports.itemTotals = itemTotals;
exports.placeConflicts = placeConflicts;
exports.makeSoakWorld = makeSoakWorld;
exports.runSoak = runSoak;
// Soak test harness (Phase 0.8). No DOM. Runs a world headless for N in-game hours with M residents and checks
// invariants as it goes:
//   stuck        nobody in full detail wants to walk (a path) yet stays put for more than `stuckSeconds`
//   items        no item is created or destroyed: the totals over every pack, worn slot, prop and loose stack hold
//   places       no exclusive standing place is held by two people at once
//   ids          no actor id appears twice
//   round trip   serialize -> deserialize -> serialize is the identity, every `roundTripHours`
//   budget       mean (and p95) sim cost per tick under `budgetMs`
// Used by tests/soak.test.ts (small and 300-actor runs) and scripts/soak.mjs (long runs from the command line).
const folk_1 = require("../content/folk");
const daycycle_1 = require("../content/daycycle");
const world_1 = require("../world/world");
const save_1 = require("../world/save");
const folk_2 = require("./folk");
const replay_1 = require("./replay");
const clock_1 = require("./clock");
const lod_1 = require("./lod");
const daytime_1 = require("./daytime");
/** Clone census rows (new ids, same homes and routines) until the world holds `n` actors. Deterministic. */
function populateResidents(w, n, areas = ["town"]) {
    const rows = folk_1.CENSUS.filter((r) => areas.includes(r.area));
    for (const id of new Set(rows.map((r) => r.area)))
        (0, world_1.getArea)(w, id);
    const taken = new Set(w.actors.filter(folk_2.isFolk).map((a) => a.person.name.split(" ")[0]));
    for (let k = 1; w.actors.length < n && rows.length; k++) {
        for (const r of rows) {
            if (w.actors.length >= n)
                break;
            const row = { ...r, id: `${r.id}.r${k}` };
            if (!(0, world_1.actorById)(w, row.id))
                w.actors.push((0, folk_2.makeFolk)(w, row, taken));
        }
    }
}
/** Every item in the world, by id: packs, worn gear, prop inventories, props holding an item, loose stacks. */
function itemTotals(w) {
    const t = {};
    const add = (id, n = 1) => { if (id)
        t[id] = (t[id] ?? 0) + n; };
    for (const a of w.actors) {
        for (const s of a.inventory)
            if (s)
                add(s.item, s.n);
        for (const g of Object.values(a.gear))
            add(g);
        add(a.powerCore);
    }
    for (const area of w.areas.values()) {
        for (const p of area.props) {
            add(p.item);
            for (const s of p.inventory ?? [])
                if (s)
                    add(s.item, s.n);
        }
        for (const l of area.loose)
            if (!l.taken)
                add(l.item, l.n ?? 1);
    }
    return t;
}
/** Exclusive places held by more than one person: "area|spot" -> holders. */
function placeConflicts(w) {
    const held = new Map();
    for (const a of w.actors) {
        if (!(0, folk_2.isFolk)(a) || !a.life.spot)
            continue;
        const id = a.life.spot;
        if (!id.startsWith("lamp:")) {
            const s = (0, folk_2.spotById)((0, world_1.getArea)(w, a.area), id);
            if (!s || !(0, folk_2.isExclusive)(s))
                continue;
        }
        const k = `${a.area}|${id}`;
        held.set(k, [...(held.get(k) ?? []), a.id]);
    }
    return [...held].filter(([, ids]) => ids.length > 1).map(([k, ids]) => `${k}: ${ids.join(", ")}`);
}
function makeSoakWorld(o) {
    const w = (0, world_1.createWorld)(o.seed ?? 1234);
    const area = (0, world_1.getArea)(w, o.area ?? "town");
    (0, world_1.enterArea)(w, (0, world_1.player)(w), area.id, area.start.x, area.start.y);
    populateResidents(w, o.actors);
    (0, daytime_1.advanceDayTo)(w, o.startHour ?? 9);
    w.events.length = 0;
    return w;
}
function runSoak(o, w = makeSoakWorld(o)) {
    const now = o.now ?? (() => (typeof performance !== "undefined" ? performance.now() : Date.now()));
    const stuckLimit = o.stuckSeconds ?? 20, budget = o.budgetMs ?? 4, rtEvery = (o.roundTripHours ?? 4) * (daycycle_1.DAY_SECONDS / 24);
    const ticks = Math.round((o.hours * daycycle_1.DAY_SECONDS) / 24 / clock_1.TICK);
    const before = itemTotals(w);
    const lastMove = new Map();
    const stuck = new Set(), conflicts = new Set(), rtFail = [];
    const costs = [];
    let nextRt = w.time + rtEvery, roundTrips = 0;
    for (let i = 0; i < ticks; i++) {
        const t0 = now();
        (0, replay_1.simTick)(w);
        costs.push(now() - t0);
        w.events.length = 0;
        // stuck: in full detail, wanting to walk, not moving
        if (i % 15 === 0) {
            const pl = (0, world_1.player)(w);
            for (const a of w.actors) {
                if (!(0, folk_2.isFolk)(a) || a.area !== pl.area || (0, lod_1.tierOf)(w, a, pl) !== "active") {
                    lastMove.delete(a.id);
                    continue;
                }
                const L = a.life, m = lastMove.get(a.id);
                const wants = L.path.length > 0 && L.state !== "do" && L.state !== "indoors" && !L.chat;
                if (!m || !wants || Math.hypot(a.x - m.x, a.y - m.y) > 1) {
                    lastMove.set(a.id, { x: a.x, y: a.y, t: w.time });
                    continue;
                }
                if (w.time - m.t > stuckLimit)
                    stuck.add(`${a.id} at ${a.x.toFixed(0)},${a.y.toFixed(0)} (${L.act})`);
            }
            for (const c of placeConflicts(w))
                conflicts.add(c);
        }
        if (w.time >= nextRt) {
            nextRt += rtEvery;
            roundTrips++;
            const a = JSON.stringify((0, save_1.serialize)(w)), b = JSON.stringify((0, save_1.serialize)((0, save_1.deserialize)(JSON.parse(a))));
            if (a !== b)
                rtFail.push(`at t=${w.time.toFixed(1)}: ${a.length} vs ${b.length} bytes`);
        }
    }
    const after = itemTotals(w), drift = {};
    for (const k of new Set([...Object.keys(before), ...Object.keys(after)])) {
        const d = (after[k] ?? 0) - (before[k] ?? 0);
        if (d)
            drift[k] = d;
    }
    const ids = w.actors.map((a) => a.id), dup = ids.filter((id, i) => ids.indexOf(id) !== i);
    const sorted = [...costs].sort((a, b) => a - b), mean = costs.reduce((s, c) => s + c, 0) / Math.max(1, costs.length);
    const report = {
        ticks, simSeconds: ticks * clock_1.TICK, actors: w.actors.length,
        msPerTick: mean, p95Ms: sorted[Math.floor(sorted.length * 0.95)] ?? 0, maxMs: sorted[sorted.length - 1] ?? 0, budgetMs: budget, withinBudget: mean <= budget,
        stuck: [...stuck], placeConflicts: [...conflicts], duplicateIds: dup, itemDrift: drift, roundTrips, roundTripFailures: rtFail, ok: false,
    };
    report.ok = report.withinBudget && !report.stuck.length && !report.placeConflicts.length && !dup.length && !Object.keys(drift).length && !rtFail.length;
    return report;
}
