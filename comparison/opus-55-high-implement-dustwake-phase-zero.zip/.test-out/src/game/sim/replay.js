"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InputLog = exports.NO_INPUT = void 0;
exports.simTick = simTick;
exports.replay = replay;
exports.driveAtSpeed = driveAtSpeed;
// Deterministic replays (Phase 0.1). No DOM.
//
// `simTick` is the canonical play-screen tick: the same three calls, in the same order, the host makes (and the
// tests' `frame` helper mirrors), always with dt = TICK. An `InputLog` binds player input to tick numbers, so a
// world replayed from the same save with the same log reaches the same state no matter how many ticks each
// rendered frame ran (1x or 8x), or whether it ran at all (a hidden tab).
const step_1 = require("./step");
const clock_1 = require("./clock");
exports.NO_INPUT = { ix: 0, iy: 0, use: false };
/** One play tick: player step, then world step. */
function simTick(w, input = exports.NO_INPUT) {
    (0, step_1.addPlayTime)(w, clock_1.TICK);
    const r = (0, step_1.stepPlayer)(w, clock_1.TICK, input);
    (0, step_1.stepWorld)(w, clock_1.TICK);
    return r;
}
const neutral = (i) => !i.ix && !i.iy && !i.use && !i.attack && !i.core && !i.toggleScan;
/** Player input keyed by world tick. Neutral ticks are not stored, so an idle hour costs nothing. */
class InputLog {
    constructor() {
        Object.defineProperty(this, "frames", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "byTick", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
    }
    record(tick, input) {
        if (neutral(input))
            return;
        const copy = { ...input };
        this.frames.push({ tick, input: copy });
        this.byTick.set(tick, copy);
    }
    at(tick) { return this.byTick.get(tick) ?? exports.NO_INPUT; }
    toJSON() { return this.frames; }
    static from(frames) { const l = new InputLog(); for (const f of frames)
        l.record(f.tick, f.input); return l; }
}
exports.InputLog = InputLog;
/** Run `ticks` ticks of `w` from its current tick, feeding the logged input. Events are drained each tick. */
function replay(w, log, ticks) {
    for (let i = 0; i < ticks; i++) {
        simTick(w, log.at(w.tick ?? 0));
        w.events.length = 0;
    }
}
/**
 * Drive `w` the way the host does, through a SimClock at `speed`, over a list of real frame times, until it has run
 * `ticks` ticks. Returns how many frames that took. Used by the determinism test: a world driven at 1x and at 8x
 * over different frame timings ends identical.
 */
function driveAtSpeed(w, log, ticks, speed, frameDts) {
    const clock = new clock_1.SimClock();
    let run = 0, frames = 0;
    while (run < ticks) {
        const n = clock.advance(frameDts[frames++ % frameDts.length], speed);
        for (let k = 0; k < n && run < ticks; k++, run++) {
            simTick(w, log.at(w.tick ?? 0));
            w.events.length = 0;
        }
    }
    return frames;
}
