"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.forgetArea = exports.generatedAreas = void 0;
exports.openGeneratedArea = openGeneratedArea;
exports.leaveGeneratedArea = leaveGeneratedArea;
// Opening and leaving areas made at runtime (Phase 0.3): a generated floor below where the golem stands, a cave,
// a yard to build in. Pure sim; the overview's Areas tab and the tests call these. No DOM.
const world_1 = require("../world/world");
Object.defineProperty(exports, "forgetArea", { enumerable: true, get: function () { return world_1.forgetArea; } });
const daycycle_1 = require("../content/daycycle");
const areaSpec_1 = require("../world/areaSpec");
const portals_1 = require("./portals");
const LABEL = { floor: "A FLOOR BELOW", cave: "A CAVE", yard: "AN OPEN YARD" };
/** Create a `kind` area under the actor's area (deterministic from the world seed and the new id) and step into it. */
function openGeneratedArea(w, a, kind, size = { w: 56, h: 36 }) {
    if (!areaSpec_1.AREA_KINDS[kind])
        return null;
    const parentSpec = w.specs?.[a.area];
    const id = (0, areaSpec_1.nextSpecId)(w.specs, a.area, kind);
    const spec = {
        id, kind, w: size.w, h: size.h, parent: a.area, depth: (parentSpec?.depth ?? 0) + (kind === "yard" ? 0 : 1),
        // never from w.rng: opening a floor must not change what the rest of the sim rolls
        seed: Math.floor((0, daycycle_1.hash01)(`${w.seed}:${id}`, 7) * 4294967296) >>> 0,
        entry: { x: Math.round(a.x), y: Math.round(a.y) }, label: LABEL[kind],
    };
    const area = (0, world_1.createArea)(w, spec);
    (0, world_1.enterArea)(w, a, id, area.start.x, area.start.y);
    a.facing = "down";
    return w.specs[id];
}
/** Walk the actor out of a generated area by its exit (back to where it was opened). False if this is not one. */
function leaveGeneratedArea(w, a) {
    if (!w.specs?.[a.area])
        return false;
    const area = (0, world_1.getArea)(w, a.area), exit = (0, portals_1.portalById)(area, "exit");
    return !!exit && (0, portals_1.walkThrough)(w, a, area, exit);
}
/** Generated areas, parents first. */
const generatedAreas = (w) => Object.values(w.specs ?? {}).sort((x, y) => x.depth - y.depth || (x.id < y.id ? -1 : 1));
exports.generatedAreas = generatedAreas;
