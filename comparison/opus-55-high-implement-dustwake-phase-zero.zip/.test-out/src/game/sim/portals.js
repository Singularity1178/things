"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inPortal = exports.portalOpen = exports.portalById = exports.portalsOf = void 0;
exports.portalAt = portalAt;
exports.portalStand = portalStand;
exports.portalArrival = portalArrival;
exports.walkThrough = walkThrough;
const actors_1 = require("../content/actors");
const world_1 = require("../world/world");
const collision_1 = require("./collision");
const areaSpec_1 = require("../world/areaSpec");
const PUSH = { up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0] };
const AWAY = { up: "down", down: "up", left: "right", right: "left" };
const portalsOf = (area) => area.base.portals ?? [];
exports.portalsOf = portalsOf;
const portalById = (area, id) => (0, exports.portalsOf)(area).find((p) => p.id === id);
exports.portalById = portalById;
/** Is a portal passable? One with a `flag` (a stair that has to be dug out first) only once that world flag is set. */
const portalOpen = (w, p) => !p.flag || (0, world_1.hasFlag)(w, p.flag);
exports.portalOpen = portalOpen;
/** Are feet at (x, y) inside a portal's box? */
const inPortal = (p, x, y) => x >= p.x && x <= p.x + p.w && y >= p.y && y <= p.y + p.h;
exports.inPortal = inPortal;
/**
 * The portal someone standing at (x, y) and pushing (ix, iy) walks through, if any: feet in its box, pushing
 * mostly its way. `open` leaves out the ones that are shut (pass `(p) => portalOpen(w, p)`).
 */
function portalAt(area, x, y, ix, iy, open = () => true) {
    const mag = Math.hypot(ix, iy);
    if (!mag)
        return null;
    for (const p of (0, exports.portalsOf)(area)) {
        if (!open(p))
            continue;
        const [dx, dy] = PUSH[p.dir];
        if ((ix * dx + iy * dy) / mag < 0.7)
            continue;
        if ((0, exports.inPortal)(p, x, y))
            return p;
    }
    return null;
}
/** Places in a portal's box, as fractions of its half-extents from its middle: the middle first, then toward the edges. */
const STAND = [[0, 0], [-0.5, 0], [0.5, 0], [0, 0.5], [0, -0.5], [-0.5, 0.5], [0.5, 0.5], [-0.5, -0.5], [0.5, -0.5]];
/**
 * Where a body that means to go through a portal walks to: a place inside its box where it can stand (`free`: that
 * body's own collision test), the middle first. Every candidate lies well inside the box, so a walker that stops a
 * pixel short still has its feet in it. Null if the whole box is blocked.
 */
function portalStand(p, free) {
    const cx = p.x + p.w / 2, cy = p.y + p.h / 2;
    for (const [fx, fy] of STAND) {
        const x = cx + fx * Math.max(0, p.w / 2 - 2), y = cy + fy * Math.max(0, p.h / 2 - 2);
        if (free(x, y))
            return { x, y };
    }
    return null;
}
/** Where someone coming out of a portal stands, and which way they face (away from the way in). */
function portalArrival(p) {
    const at = p.arrive ?? { x: p.x + p.w / 2, y: p.y + p.h / 2 };
    return { x: at.x, y: at.y, facing: AWAY[p.dir] };
}
/**
 * Walk `a` through portal `p` of `area`: it comes out of the paired portal,
 * nudged to the nearest free spot if something stands there. False (and
 * nothing moves) if the other side is missing or blocked solid.
 */
function walkThrough(w, a, area, p) {
    if (a.area !== area.id || !(0, actors_1.capable)(a, "move") || !(0, exports.portalOpen)(w, p))
        return false;
    const dest = (0, world_1.getArea)(w, p.to.area), out = (0, exports.portalById)(dest, p.to.portal) ?? (0, areaSpec_1.coordPortal)(p.to.portal);
    if (!out)
        return false;
    const at = portalArrival(out);
    const spot = (0, collision_1.nearestFree)(dest, at.x, at.y, (0, collision_1.actorBoxes)(w, dest.id, a.id), (0, actors_1.actorDef)(a).body.box);
    if (!spot)
        return false;
    (0, world_1.enterArea)(w, a, dest.id, spot.x, spot.y);
    a.facing = at.facing;
    (0, world_1.emit)(w, { t: "portal", actor: a.id, fromArea: area.id, from: p.id, toArea: dest.id, to: out.id });
    return true;
}
