"use strict";
// Fixed-timestep simulation clock (Phase 0.1). No DOM.
//
// The sim always steps in ticks of exactly TICK seconds. The host feeds real frame time into `advance`, which
// returns how many ticks to run this frame (more at higher game speeds) and leaves `alpha`, the fraction of a
// tick left over, for the renderer to interpolate between the previous and the current tick. Because the World
// only ever sees TICK-sized steps, and input is bound to tick numbers (sim/replay.ts), the same save and input
// stream give an identical World at 1x and at 8x: 8x simply runs more ticks per frame.
Object.defineProperty(exports, "__esModule", { value: true });
exports.SimClock = exports.speedLabel = exports.SPEEDS = exports.TICK = exports.SIM_HZ = void 0;
exports.SIM_HZ = 30;
exports.TICK = 1 / exports.SIM_HZ;
/** Game speeds offered by the HUD: 0 is pause. */
exports.SPEEDS = [0, 1, 2, 4, 8];
const speedLabel = (s) => (s === 0 ? "Paused" : `${s}x`);
exports.speedLabel = speedLabel;
class SimClock {
    constructor() {
        /** Current game speed (0 = paused). */
        Object.defineProperty(this, "speed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        /** The speed to return to when unpausing. */
        Object.defineProperty(this, "resumeSpeed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        /** Real seconds of sim time owed but not yet stepped (always < TICK after `advance`). */
        Object.defineProperty(this, "acc", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        /** Leftover fraction of a tick, 0..1: how far the renderer is between the last two ticks. */
        Object.defineProperty(this, "alpha", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        /** Most real time one frame may contribute (a stalled tab must not trigger a spiral of catch-up ticks). */
        Object.defineProperty(this, "maxFrame", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0.25
        });
        /** Ticks run in the last `advance` (the perf panel reads it). */
        Object.defineProperty(this, "lastTicks", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        /** Total ticks handed out since this clock started. */
        Object.defineProperty(this, "total", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
    }
    /** Feed `realDt` seconds of wall time at `speed` (default: the clock's own). Returns the number of ticks to run. */
    advance(realDt, speed = this.speed) {
        if (speed <= 0) {
            this.lastTicks = 0;
            return 0;
        }
        this.acc += Math.min(Math.max(0, realDt), this.maxFrame) * speed;
        // the epsilon keeps float drift from dropping a tick when acc lands a hair under a multiple of TICK
        const n = Math.floor(this.acc / exports.TICK + 1e-7);
        this.acc = Math.max(0, this.acc - n * exports.TICK);
        this.alpha = Math.min(1, this.acc / exports.TICK);
        this.lastTicks = n;
        this.total += n;
        return n;
    }
    setSpeed(s) {
        if (s !== 0)
            this.resumeSpeed = s;
        this.speed = s;
    }
    togglePause() { this.setSpeed(this.speed === 0 ? this.resumeSpeed : 0); }
    /** Step to the next faster (+1) or slower (-1) speed, never below 1x (pause has its own key). */
    stepSpeed(dir) {
        const i = exports.SPEEDS.indexOf(this.speed === 0 ? this.resumeSpeed : this.speed);
        this.setSpeed(exports.SPEEDS[Math.min(exports.SPEEDS.length - 1, Math.max(1, i + dir))]);
    }
}
exports.SimClock = SimClock;
