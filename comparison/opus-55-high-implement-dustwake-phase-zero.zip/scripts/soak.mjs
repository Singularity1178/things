// Soak test and content lint from the command line (Phase 0.8): runs the world headless and checks invariants
// (nobody stuck, no item made or lost, no place held by two, save round trip, frame budget). Exit code 1 on failure.
//
//   node scripts/soak.mjs                          2 in-game hours, 300 actors, in Westwake
//   node scripts/soak.mjs days=3 actors=300        three days
//   node scripts/soak.mjs hours=6 budget=2 seed=7  a tighter budget, another world
import { execFileSync } from "node:child_process";
import { createRequire } from "node:module";
execFileSync("node_modules/.bin/esbuild", ["tests/support/soakRun.ts", "--bundle", "--platform=node", "--format=cjs", "--outfile=.preview/soakRun.cjs", "--log-level=warning"], { stdio: "inherit" });
const run = createRequire(import.meta.url)("../.preview/soakRun.cjs");
process.exitCode = run.main(process.argv.slice(2));
