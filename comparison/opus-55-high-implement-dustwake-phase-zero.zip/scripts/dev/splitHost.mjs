// One-off refactoring tool (Phase 0.6): moves groups of Game methods out of src/game/game.ts into view/ modules as
// plain functions taking the host (`fn(g: Game, ...)`), and leaves a one-line delegator on Game for each, so every
// caller (screens through UiHost, tests, the other modules) keeps working unchanged. Kept for reference; re-running
// it on an already-split game.ts is a no-op (the methods are delegators by then and are skipped).
import { readFileSync, writeFileSync } from "node:fs";
import { execFileSync } from "node:child_process";

const GAME = "src/game/game.ts";
const GROUPS = {
  "src/game/view/reactions.ts": { head: "// The event-reaction layer (split from game.ts): drains the World's events and turns them into sound, particles,\n// notes, toasts and screens. Presentation only: it never changes the World except through sim entry points.\n", names: ["drainEvents", "onNearby", "onEvent", "onDayPhase", "workerCue", "runeBlip", "runeBurst", "runeRefused", "workerWalked", "workerTravelled", "coreSparks", "npcSparks", "npcDust", "onVisionCue"] },
  "src/game/view/worldRenderer.ts": { head: "// The world renderer (split from game.ts): draws the lit scene of the current area onto the world layer, the\n// golem, NPC presentation state, folk speech, and the HUD of the base-size UI layer.\n", names: ["renderWorld", "drawSurfaceRune", "drawDimmed", "drawSwaying", "drawFlame", "drawPedestal", "drawPlayer", "npcLook", "updateNpcLooks", "updateWorkerLook", "updateFolkLook", "renderFolkBubbles", "renderHud", "renderClock", "renderToast", "visionArt", "eyeSpot"] },
  "src/game/view/particles.ts": { head: "// The particle system (split from game.ts): presentation-only motes, sparks, debris, drips and smoke.\n// Randomness here is Math.random on purpose (docs/sim/determinism.md): particles never feed back into the World.\n", names: ["spawn", "sparkBurst", "updateParticles"] },
};

let src = readFileSync(GAME, "utf8").split("\n");
const importEnd = src.findIndex((l, i) => i > 0 && !/^(import|\s|\}|\/\/)/.test(l) && l.trim() !== "" && !src[i - 1].trim().endsWith(","));
const imports = src.slice(0, importEnd).filter((l) => l.startsWith("import")).map((l) => l.replace(/from "\.\/(.*)"/, 'from "../$1"').replace('from "../view/', 'from "./'));

const sigRe = (n) => new RegExp(`^  (private )?${n}\\((.*)\\)(: [^{]+)? \\{(.*)$`);
function splitArgs(s) {
  const out = []; let d = 0, cur = "";
  for (const ch of s) { if ("([{<".includes(ch)) d++; if (")]}>".includes(ch)) d--; if (ch === "," && d === 0) { out.push(cur); cur = ""; } else cur += ch; }
  if (cur.trim()) out.push(cur);
  return out.map((a) => a.trim());
}
const used = new Set();
for (const [file, { head, names }] of Object.entries(GROUPS)) {
  const fns = [];
  for (const n of names) {
    const i = src.findIndex((l) => sigRe(n).test(l));
    if (i < 0) { console.log("skip", n); continue; }
    const m = src[i].match(sigRe(n));
    if (/^\s*return \w+\.\w+\(this/.test(m[4])) { console.log("already split", n); continue; }
    let s = i; while (s > 0 && /^\s*(\/\*\*|\*|\/\/)/.test(src[s - 1])) s--;
    let e = i;
    const oneLine = m[4].trim().endsWith("}") && (m[4].match(/\{/g) ?? []).length + 1 === (m[4].match(/\}/g) ?? []).length;
    if (!oneLine) { e = i + 1; while (src[e] !== "  }") e++; }
    const args = splitArgs(m[2]);
    const argNames = args.map((a) => a.split(/[:=?]/)[0].trim());
    const body = src.slice(s, e + 1).map((l) => l.replace(/^  /, ""));
    const sigIdx = i - s;
    body[sigIdx] = `export function ${n}(g: Game${args.length ? ", " + args.join(", ") : ""})${m[3] ?? ""} {${m[4]}`;
    const text = body.join("\n").replace(/\bthis\./g, "g.").replace(/\bthis\b/g, "g");
    fns.push(text);
    const alias = file.split("/").pop().replace(".ts", "") + "V";
    used.add(`import * as ${alias} from "./${file.replace("src/game/", "").replace(".ts", "")}";`);
    const deleg = `  ${n}(${args.join(", ")})${m[3] ?? ""} { return ${alias}.${n}(this${argNames.length ? ", " + argNames.join(", ") : ""}); }`;
    src.splice(s, e - s + 1, deleg);
  }
  if (fns.length) writeFileSync(file, head + imports.join("\n") + `\nimport { Game, W, H, BURIED_AMBIENT, FOLK_EARSHOT, FOLK_MAX_LINES, type NpcLook, type Particle } from "../game";\n\n` + fns.join("\n\n") + "\n");
}
let out = src.join("\n").replace(/^  private /gm, "  ");
const lastImport = out.lastIndexOf("\nimport ");
const eol = out.indexOf("\n", lastImport + 1);
out = out.slice(0, eol + 1) + [...used].join("\n") + "\n" + out.slice(eol + 1);
for (const k of ["const BURIED_AMBIENT", "const FOLK_EARSHOT", "interface NpcLook", "interface Particle", "interface GolemLook"]) out = out.replace(new RegExp(`^${k}`, "m"), `export ${k}`);
writeFileSync(GAME, out);

// prune unused imports reported by tsc (TS6133 / TS6192), a few passes
for (let pass = 0; pass < 4; pass++) {
  let diag = "";
  try { execFileSync("node_modules/.bin/tsc", ["--noEmit", "-p", "tsconfig.json"], { encoding: "utf8" }); } catch (e) { diag = e.stdout; }
  const errs = [...diag.matchAll(/^(src\/[^()]+)\((\d+),(\d+)\): error TS(6133|6192|6196): (.*)$/gm)];
  if (!errs.length) break;
  const byFile = new Map();
  for (const [, f, l, , code, msg] of errs) { if (!byFile.has(f)) byFile.set(f, []); byFile.get(f).push({ l: +l, code, name: msg.match(/'([^']+)'/)?.[1] }); }
  for (const [f, list] of byFile) {
    const lines = readFileSync(f, "utf8").split("\n");
    for (const { l, code, name } of list) {
      const line = lines[l - 1];
      if (!line?.startsWith("import")) continue;
      if (code === "6192") { lines[l - 1] = ""; continue; }
      const mm = line.match(/^import (type )?\{([^}]*)\} from (.*)$/);
      if (!mm) { if (line.includes(`* as ${name} `) || line.startsWith(`import ${name} `)) lines[l - 1] = ""; continue; }
      const keep = mm[2].split(",").map((x) => x.trim()).filter((x) => x && x.replace(/^type /, "").split(" as ").pop() !== name);
      lines[l - 1] = keep.length ? `import ${mm[1] ?? ""}{ ${keep.join(", ")} } from ${mm[3]}` : "";
    }
    writeFileSync(f, lines.filter((x, i) => x !== "" || !lines[i - 1]?.startsWith("import") || true).join("\n"));
  }
}
console.log("done");
