// One-off tool (Phase 0.9): splits docs/ARCHITECTURE.md into per-system docs by heading and rewrites it as an index.
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { dirname } from "node:path";
const SRC = existsSync("docs/ARCHITECTURE.full.md") ? "docs/ARCHITECTURE.full.md" : "docs/ARCHITECTURE.md";
const text = readFileSync(SRC, "utf8");
writeFileSync("docs/ARCHITECTURE.full.md", text);
const MAP = [
  ["Layers", "overview/layers.md"], ["Actor foundations", "sim/actors.md"], ["Body power", "sim/actors.md"],
  ["Orders and navigation", "sim/orders.md"], ["Storage and shared crafting", "sim/storage.md"], ["Worker management", "sim/storage.md"],
  ["Vision and analysis", "sim/vision.md"], ["Production rollout", "sim/rollout.md"], ["Area: dimensions", "world/areas.md"],
  ["Work: tasks", "sim/tasks.md"], ["Attack", "sim/tasks.md"], ["Inner monologue", "sim/monologue.md"], ["Time", "sim/time.md"],
  ["Determinism", "sim/time.md"], ["Progression", "content/data.md"], ["Content as data", "content/data.md"], ["Screens", "ui/screens.md"],
  ["Two render layers", "ui/screens.md"], ["Save format", "world/saves.md"], ["Save size", "world/saves.md"], ["Inventory", "sim/inventory.md"],
  ["Gear", "sim/inventory.md"], ["Rune network", "sim/runes.md"], ["Harvesting and building", "sim/building.md"],
  ["Off-screen simulation", "sim/offscreen.md"], ["Large areas", "sim/offscreen.md"], ["NPCs and dialogue", "sim/dialogue.md"],
  ["Testing", "testing.md"], ["Deliberately deferred", "roadmap.md"], ["Next up", "roadmap.md"], ["Dormant worker lock", "sim/actors.md"],
  ["The market town", "world/town.md"], ["The dungeon audit", "world/dungeon-audit.md"], ["The entrance update", "world/entrance.md"],
  ["Rocks and the stair", "art/rocks-and-stairs.md"], ["The stair below", "world/stair-below.md"], ["Routes, the severed rune", "sim/routes.md"],
  ["Townsfolk", "sim/townsfolk.md"], ["Shops in use", "sim/shops.md"],
];
const fileFor = (h) => MAP.find(([k]) => h.startsWith(k))?.[1];
const out = new Map();
let h2 = "", target = "overview/intro.md";
const intro = [];
for (const line of text.split("\n")) {
  const m2 = /^## (.*)/.exec(line), m3 = /^### (.*)/.exec(line);
  if (m2) { h2 = m2[1]; target = fileFor(h2) ?? target; if (h2 === "Key decisions") { target = "overview/decisions.md"; } }
  else if (m3) { const f = fileFor(m3[1]); target = f ?? fileFor(h2) ?? target; }
  if (line.startsWith("# Dustwake architecture")) continue;
  if (!h2) { intro.push(line); continue; }
  if (!out.has(target)) out.set(target, []);
  out.get(target).push(line.replace(/^### /, "## ").replace(/^## (?=.)/, (s) => (m2 ? "# " : s)));
}
const titles = {};
for (const [f, lines] of out) {
  mkdirSync(dirname(`docs/${f}`), { recursive: true });
  const body = lines.join("\n").trim();
  if (!body || body === "# Key decisions") continue;
  titles[f] = (/^#{1,2} (.*)$/m.exec(body)?.[1] ?? f).trim();
  writeFileSync(`docs/${f}`, `<!-- Split from ARCHITECTURE.md (Phase 0.9). Index: docs/ARCHITECTURE.md -->\n${body}\n`);
}
writeFileSync("docs/overview/intro.md", "# Dustwake architecture: introduction\n" + intro.join("\n"));
console.log(JSON.stringify(titles, null, 1));
