// Phase 0 Groundwork verification suite (0.1 through 0.8 + exit criteria).
import { test } from "node:test";
import assert from "node:assert/strict";
import { installFakeCanvas } from "./support/fakeCanvas";
installFakeCanvas();
const g0 = globalThis as unknown as Record<string, unknown>;
g0.localStorage ??= { getItem: () => null, setItem: () => {}, removeItem: () => {} };

import { Game, UI2_H, UI2_W } from "../src/game/game";
import { SimClock, InterpBuffer, SIM_DT } from "../src/game/sim/clock";
import { classifyActorLod, catchUpArea, createLodConfig } from "../src/game/sim/lod";
import { stepPlayer, stepWorld, type PlayerInput } from "../src/game/sim/step";
import { createDynamicArea, createWorld, currentArea, enterArea, getArea, player } from "../src/game/world/world";
import { T } from "../src/game/content/tiles";
import {
  decodeRle,
  deserialize,
  encodeRle,
  exportSaveJson,
  importSaveJson,
  migrate,
  SAVE_VERSION,
  serialize,
  validateSave,
} from "../src/game/world/save";
import { MemorySaveBackend, SaveStore } from "../src/game/view/saveStore";
import { lintAllContent } from "../src/game/sim/contentLint";
import { runSoak } from "../src/game/sim/soak";
import { drawPropText, propTextWidth, wrapPropText } from "../src/game/ui/propFont";
import { InputManager } from "../src/game/ui/input";
import { NotificationFeed } from "../src/game/ui/notifications";
import {
  ContextMenu,
  hiButton,
  hiGraph,
  hiModal,
  hiScrollList,
  hiSlider,
  hiTable,
  hiTabs,
  hiToggle,
  TooltipHost,
} from "../src/game/ui/components";
import { DEFAULT_SETTINGS, registerSetting, registeredSettings, SettingsStore } from "../src/game/settings";
import { OVERLAY_PALETTES, visionColor } from "../src/game/content/vision";

const makeCanvasEl = () => (globalThis as unknown as { document: { createElement(t: string): HTMLCanvasElement } }).document.createElement("canvas");

// ========================================================================= 0.1
test("0.1 fixed-timestep determinism: same save + input stream yields identical world state at 1x and 8x", () => {
  const base = createWorld(1337);
  const saved = serialize(base);
  const w1 = deserialize(saved);
  const w8 = deserialize(saved);

  // Deterministic tick-indexed input stream over 240 fixed ticks (4 sim seconds)
  const inputAtTick = (tick: number): PlayerInput => ({
    ix: tick < 80 ? 1 : tick < 140 ? 0 : -1,
    iy: tick >= 40 && tick < 160 ? 1 : 0,
    use: tick === 50 || tick === 150,
    attack: tick === 90,
    toggleScan: tick === 110,
  });

  const c1 = new SimClock(SIM_DT);
  c1.setSpeed(1);
  const c8 = new SimClock(SIM_DT);
  c8.setSpeed(8);

  const stepBoth = (w: ReturnType<typeof createWorld>, clock: SimClock, frameDt: number) => {
    clock.advance(frameDt, (dt, tickIdx) => {
      stepPlayer(w, dt, inputAtTick(tickIdx));
      stepWorld(w, dt);
      w.events.length = 0;
    });
  };

  // Run 240 frames at 1x (1 tick per 1/60s frame = 240 ticks)
  for (let f = 0; f < 240; f++) stepBoth(w1, c1, SIM_DT);
  // Run 30 frames at 8x (8 ticks per 1/60s frame = 240 ticks)
  for (let f = 0; f < 30; f++) stepBoth(w8, c8, SIM_DT);

  assert.equal(c1.tick, 240);
  assert.equal(c8.tick, 240);
  assert.deepEqual(serialize(w1), serialize(w8), "1x and 8x must produce byte-identical world state");

  // Pause runs 0 ticks
  c8.setSpeed(0);
  const pausedRes = c8.advance(0.05, () => { throw new Error("should not step while paused"); });
  assert.equal(pausedRes.ticks, 0);

  // InterpBuffer smoothly interpolates actor movement and snaps across teleports
  const interp = new InterpBuffer();
  const pl = player(w1);
  interp.capture(w1);
  const x0 = pl.x, y0 = pl.y;
  pl.x += 10; pl.y += 4;
  const mid = interp.position(pl, 0.5);
  assert.equal(mid.x, x0 + 5);
  assert.equal(mid.y, y0 + 2);
  pl.x += 120; // teleport jump > 32px snaps cleanly
  assert.equal(interp.position(pl, 0.5).x, pl.x);
});

// ========================================================================= 0.2
test("0.2 simulation LOD: classifies Active / Near / Far and catches up Far areas via world.time - area.lastTicked", () => {
  const w = createWorld(2026);
  const town = getArea(w, "town");
  const dungeon = getArea(w, "dungeon");
  enterArea(w, player(w), town.id, town.start.x, town.start.y);
  w.lod = createLodConfig();
  w.lod.view = { x: town.start.x - 100, y: town.start.y - 60, w: 200, h: 120 };

  const tiers = { active: 0, near: 0, far: 0 };
  for (const a of w.actors) {
    tiers[classifyActorLod(w, a, w.lod.view, 0)]++;
  }
  assert.ok(tiers.active >= 1, "player (and nearby town actors) are Active");
  assert.ok(tiers.near >= 1, "off-camera town residents are Near");
  assert.ok(tiers.far >= 1, "dungeon actors are Far");

  // Advance world time while dungeon is Far; dungeon.lastTicked stays behind w.time
  dungeon.ritual!.active = true;
  const beforeActT = dungeon.ritual!.actT;
  const beforeLast = dungeon.lastTicked;
  for (let i = 0; i < 60; i++) stepWorld(w, SIM_DT);
  assert.equal(dungeon.lastTicked, beforeLast, "Far area does not advance per tick");
  assert.ok(w.time - dungeon.lastTicked >= 0.99);

  // Entering dungeon triggers catch-up using world.time - area.lastTicked
  const elapsed = catchUpArea(w, dungeon);
  assert.ok(elapsed >= 0.99, "catch-up delta equals world.time - area.lastTicked");
  assert.ok(dungeon.ritual!.actT > beforeActT + 0.9, "Far area ritual caught up accurately");
  assert.equal(dungeon.lastTicked, w.time);
});

// ========================================================================= 0.3
test("0.3 dynamic areas (AreaSpec): create, enter, edit, save, load and leave a generated test floor", () => {
  const w = createWorld(777);
  const pl = player(w);

  // Create generated areas of every kind
  const floor = createDynamicArea(w, { id: "test_floor_1", kind: "dungeon_floor", seed: 9001, w: 34, h: 26, parent: "dungeon", depth: 2, label: "Test Floor 2" });
  const cavern = createDynamicArea(w, { kind: "cavern", seed: 9002, w: 30, h: 24, parent: "test_floor_1", depth: 3 });
  const outpost = createDynamicArea(w, { kind: "outpost", seed: 9003, w: 30, h: 24, parent: "surface", depth: 0 });
  const wilds = createDynamicArea(w, { kind: "wilds", seed: 9004, w: 30, h: 24, parent: "surface", depth: 0 });
  assert.ok(floor.rooms.length >= 2 && cavern.w === 30 && outpost.base.outdoor && wilds.base.outdoor);

  // Enter the generated floor, edit a tile and add a prop
  enterArea(w, pl, floor.id, floor.start.x, floor.start.y);
  assert.equal(currentArea(w).id, "test_floor_1");
  const editTx = Math.floor(floor.start.x / 16) + 1;
  const editTy = Math.floor(floor.start.y / 16);
  floor.setTile(editTx, editTy, T.RUBBLE);
  floor.addProp("chest", floor.start.x + 16, floor.start.y + 8, { container: true }, "built_floor_chest");

  // Save & load round-trip
  const raw = serialize(w);
  assert.ok(raw.specs?.test_floor_1, "AreaSpec persisted in save");
  const loaded = deserialize(raw);
  assert.equal(currentArea(loaded).id, "test_floor_1");
  const loadedFloor = getArea(loaded, "test_floor_1");
  assert.equal(loadedFloor.tile(editTx, editTy), T.RUBBLE, "edited tile persisted on generated floor");
  assert.ok(loadedFloor.prop("built_floor_chest"), "built prop persisted on generated floor");
  assert.deepEqual(serialize(loaded), raw, "exact round-trip on generated areas");

  // Leave generated floor back to parent dungeon
  const parentId = loadedFloor.spec!.parent!;
  const parent = getArea(loaded, parentId);
  enterArea(loaded, player(loaded), parent.id, parent.start.x, parent.start.y);
  assert.equal(currentArea(loaded).id, "dungeon");
});

// ========================================================================= 0.4
test("0.4 save system v2: v19 migration, RLE compression, multi-slot store, rolling backups, export/import, corruption recovery, size & load budgets", async () => {
  const w = createWorld(5150);
  // 1. v19 save still loads through MIGRATIONS[19]
  const v20 = serialize(w);
  assert.equal(v20.version, SAVE_VERSION);
  const v19 = { ...JSON.parse(JSON.stringify(v20)), version: 19 };
  delete v19.specs;
  const migrated = migrate(v19) as { version: number };
  assert.equal(migrated.version, SAVE_VERSION);
  const fromV19 = deserialize(v19);
  assert.equal(player(fromV19).area, "dungeon");

  // 2. RLE compression round-trip & threshold engagement on player-built / heavily edited area
  const pb = createDynamicArea(w, { id: "player_hall", kind: "dungeon_floor", seed: 123, w: 32, h: 24, depth: 1, playerBuilt: true });
  const encoded = encodeRle(pb.grid);
  assert.deepEqual(decodeRle(encoded, pb.grid.length), pb.grid);
  const savedWithPb = serialize(w);
  assert.ok(Array.isArray(savedWithPb.areas.player_hall.tilesRle), "player-built area uses RLE full grid");
  assert.equal(savedWithPb.areas.player_hall.tiles.length, 0);
  const reloadedPb = deserialize(savedWithPb);
  assert.deepEqual(getArea(reloadedPb, "player_hall").grid, pb.grid);

  // 3. Size & load-time budgets
  const t0 = performance.now();
  const json = exportSaveJson(w);
  const imported = importSaveJson(json);
  const loadMs = performance.now() - t0;
  assert.ok(json.length < 250_000, `Save size within budget (${json.length} bytes)`);
  assert.ok(loadMs < 150, `Save/load round-trip within budget (${loadMs.toFixed(1)}ms)`);
  assert.equal(imported.seed, w.seed);
  assert.equal(validateSave({ bad: true }).ok, false);

  // 4. Multi-slot SaveStore + rolling backups + corrupted-save recovery
  const store = new SaveStore(new MemorySaveBackend());
  await store.saveSlot("slot-1", w, "First Save");
  w.playTime = 42;
  await store.saveSlot("slot-1", w, "Second Save");
  const slots = await store.listSlots();
  assert.equal(slots.length, 1);
  assert.equal(slots[0].backupCount, 1, "rolling backup created on overwrite");

  // Corrupt primary slot and verify automatic recovery from rolling backup #1
  await store.corruptSlotForTest("slot-1");
  const recovered = await store.loadSlot("slot-1");
  assert.ok(recovered, "recovered from rolling backup");
  assert.equal(recovered.recoveredFrom, "backup #1");
  assert.equal(recovered.world.seed, 5150);

  // Export & import through store
  const exported = await store.exportSlotJson("slot-1");
  assert.ok(exported);
  const impRes = await store.importSlotJson("slot-2", exported!, "Imported Slot");
  assert.equal(impRes.world.seed, 5150);
  assert.equal((await store.listSlots()).length, 2);
});

// ========================================================================= 0.5
test("0.5 input & UI v2: mixed-case proportional font, mouse/drag/wheel/context, reusable components, notification feed & pause-on-alert", () => {
  // Mixed-case proportional font: narrower 'i'/'l' than 'M'/'W', supports lowercase + descenders
  assert.ok(propTextWidth("iii") < propTextWidth("MMM"), "proportional widths differ");
  assert.ok(propTextWidth("Dustwake Phase 0") > 40);
  const wrapped = wrapPropText("The quick brown golem leaps over the lazy rubble", 70);
  assert.ok(wrapped.length >= 2);

  // Reusable components render cleanly on 640x360 2x UI canvas with mouse input
  const hiCanvas = makeCanvasEl();
  hiCanvas.width = UI2_W; hiCanvas.height = UI2_H;
  const ctx = hiCanvas.getContext("2d")!;
  const input = new InputManager();
  const tips = new TooltipHost();

  drawPropText(ctx, "Mixed Case 123 (gjpqy)", 10, 10, "#fff");

  // Click a button
  input.onPointerDown(0, 30, 30, 0, 0, 320, 180);
  input.onPointerUp(0, 30, 30, 0, 0, 320, 180);
  assert.equal(hiButton(ctx, { x: 10, y: 20, w: 80, h: 20 }, "Click Me", input.pointer, {}, tips), true);
  input.endFrame();

  // Drag-select in world coordinates
  input.onPointerDown(0, 100, 100, 10, 20, 320, 180);
  input.onPointerMove(200, 200, 10, 20, 320, 180);
  assert.ok(input.pointer.drag?.active, "drag-select becomes active past threshold");
  input.onPointerUp(0, 200, 200, 10, 20, 320, 180);
  assert.ok(input.pointer.dragFinished, "dragFinished emitted on release");
  assert.equal(input.pointer.dragFinished!.wx0, 10 + (100 / UI2_W) * 320);
  input.endFrame();

  // Slider, Toggle, Tabs, ScrollList, Table, Graph, Modal, ContextMenu
  input.onPointerDown(0, 150, 50, 0, 0, 320, 180);
  const sl = hiSlider(ctx, { x: 100, y: 40, w: 100, h: 20 }, 0, 0, 1, 0.1, input.pointer);
  assert.ok(sl !== null && sl >= 0.4 && sl <= 0.6);
  input.endFrame();

  hiToggle(ctx, { x: 10, y: 10, w: 60, h: 16 }, true, input.pointer);
  hiTabs(ctx, { x: 10, y: 30, w: 200, h: 18 }, [{ id: "a", label: "Tab A" }, { id: "b", label: "Tab B" }], "a", input.pointer);
  hiScrollList(ctx, { x: 10, y: 60, w: 120, h: 80 }, ["Row 1", "Row 2", "Row 3"], 16, { scroll: 0, selected: 0 }, input, () => {});
  hiTable(ctx, { x: 140, y: 60, w: 200, h: 80 }, [{ id: "n", label: "Name", w: 100, value: (x: string) => x }], ["Alpha", "Beta"], { scroll: 0, selected: 0, sortCol: "n", sortAsc: true }, input);
  hiGraph(ctx, { x: 350, y: 60, w: 120, h: 50 }, [1.2, 2.4, 3.1, 2.0], { label: "Sim", unit: "ms" });
  hiModal(ctx, { x: 60, y: 40, w: 500, h: 260 }, "Test Modal", "sub", input.pointer);

  const cm = new ContextMenu();
  let ran = false;
  cm.show(200, 150, [{ id: "act", label: "Inspect", action: () => { ran = true; } }], "Menu");
  cm.updateAndRender(ctx, input.pointer, (...k) => k.includes("enter"));
  assert.equal(ran, true, "ContextMenu supports keyboard Enter parity");

  // Notification feed + pause-on-alert
  const feed = new NotificationFeed();
  const s = { ...DEFAULT_SETTINGS, pauseOnAlert: true, pauseOnJobBlocked: true };
  const r1 = feed.push({ title: "Info note", severity: "info", category: "world" }, s);
  assert.equal(r1.pause, false);
  const r2 = feed.push({ title: "Critical Alert", severity: "alert", category: "world" }, s);
  assert.equal(r2.pause, true, "pauseOnAlert triggers pause on alert severity");
  const r3 = feed.push({ title: "Worker blocked", severity: "warn", category: "worker" }, s);
  assert.equal(r3.pause, true, "pauseOnJobBlocked triggers pause on worker warn");
  assert.equal(feed.unreadCount(), 3);
});

// ========================================================================= 0.6 & 0.7
test("0.6 split host & 0.7 settings/accessibility: volume, palettes, key remapping, registry, Game integration", () => {
  const settings = new SettingsStore();
  // Extensible settings registry
  registerSetting({
    id: "phase0_test_opt",
    category: "gameplay",
    kind: "toggle",
    label: "Test Option",
    get: (st) => Boolean(st.extra.testOpt),
    set: (st, v) => { st.extra.testOpt = v; },
  });
  assert.ok(registeredSettings("gameplay").some((d) => d.id === "phase0_test_opt"));

  // Color-blind palettes distinct & valid hex
  for (const pal of Object.keys(OVERLAY_PALETTES) as (keyof typeof OVERLAY_PALETTES)[]) {
    assert.match(visionColor("important", pal), /^#[0-9a-f]{6}$/i);
    assert.match(visionColor("buildable", pal), /^#[0-9a-f]{6}$/i);
  }
  assert.notEqual(visionColor("buildable", "default"), visionColor("buildable", "deuteranopia"));

  // Key remapping
  settings.rebind("pause", "f8");
  assert.ok(settings.keysFor("pause").includes("f8"));
  settings.resetKeybinds();
  assert.ok(settings.keysFor("pause").includes("p"));

  // Split host smoke check (Game uses Camera, ParticleSystem, WorldRenderer, SimClock)
  const g = new Game(makeCanvasEl(), makeCanvasEl(), makeCanvasEl());
  g.resume(createWorld(99));
  g.setSpeed(4);
  assert.equal(g.clock.speed, 4);
  const beforeTime = g.world.time;
  g.update(SIM_DT);
  assert.ok(g.world.time - beforeTime >= SIM_DT * 3.9, "4x speed advances 4 fixed ticks per frame");
  g.render();
  g.dispose();
});

// ========================================================================= 0.8 + 0.2 frame budget
test("0.8 content linter: every content row resolves and fits bitmap font", () => {
  const res = lintAllContent();
  assert.ok(res.checked > 200, `checked ${res.checked} content rows`);
  assert.deepEqual(res.errors, [], `Content lint errors:\n${res.errors.map((e) => `${e.table}:${e.row}: ${e.message}`).join("\n")}`);
});

test("0.2 & 0.8 300-actor headless soak test: invariants and frame budget hold", () => {
  const report = runSoak({
    actors: 300,
    days: 0.15,          // 108 in-game seconds (~3240 ticks at 1/30s) across Active/Near/Far
    tickDt: 1 / 30,
    seed: 2026,
    maxStuckSeconds: 15,
    frameBudgetMs: 12,
    checkRoundTrip: true,
  });
  assert.equal(report.actors, 300);
  assert.ok(report.lodCounts.active > 0 && report.lodCounts.far > 0, "LOD tiers engaged during soak");
  assert.ok(report.avgTickMs <= 12, `300-actor avg tick ${report.avgTickMs.toFixed(2)}ms exceeded 12ms budget`);
  assert.deepEqual(report.violations, [], `Soak violations:\n${report.violations.join("\n")}`);
});
