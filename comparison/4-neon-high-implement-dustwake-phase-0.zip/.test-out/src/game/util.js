"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Pen = exports.lerp = exports.clamp = exports.hash2 = exports.mulberry = void 0;
exports.hex = hex;
exports.rgb = rgb;
exports.shade = shade;
exports.makeCanvas = makeCanvas;
exports.makeSprite = makeSprite;
const rng_1 = require("./core/rng");
var rng_2 = require("./core/rng");
Object.defineProperty(exports, "mulberry", { enumerable: true, get: function () { return rng_2.mulberry; } });
Object.defineProperty(exports, "hash2", { enumerable: true, get: function () { return rng_2.hash2; } });
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
exports.clamp = clamp;
const lerp = (a, b, t) => a + (b - a) * t;
exports.lerp = lerp;
function hex(c) {
    const n = parseInt(c.slice(1), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
function rgb(r, g, b) {
    return `rgb(${r | 0},${g | 0},${b | 0})`;
}
function shade(c, f) {
    const [r, g, b] = hex(c);
    return rgb((0, exports.clamp)(r * f, 0, 255), (0, exports.clamp)(g * f, 0, 255), (0, exports.clamp)(b * f, 0, 255));
}
function makeCanvas(w, h) {
    const c = document.createElement("canvas");
    c.width = w;
    c.height = h;
    const ctx = c.getContext("2d", { willReadFrequently: true });
    ctx.imageSmoothingEnabled = false;
    return { c, ctx };
}
/** Pixel painter writing either albedo or emissive layer. In emissive mode,
 * non-glowing pixels are written black so they occlude glow behind them. */
class Pen {
    constructor(ctx, emit) {
        Object.defineProperty(this, "ctx", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: ctx
        });
        Object.defineProperty(this, "emit", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: emit
        });
        Object.defineProperty(this, "ox", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "oy", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "flip", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
    }
    X(x, w) {
        return this.flip ? this.ox - x - w : this.ox + x;
    }
    r(x, y, w, h, c) {
        if (w <= 0 || h <= 0)
            return;
        this.ctx.fillStyle = this.emit ? "#000" : c;
        this.ctx.fillRect(Math.round(this.X(x, w)), Math.round(this.oy + y), w, h);
    }
    /** glowing pixels */
    g(x, y, w, h, c) {
        if (w <= 0 || h <= 0)
            return;
        this.ctx.fillStyle = c;
        this.ctx.fillRect(Math.round(this.X(x, w)), Math.round(this.oy + y), w, h);
    }
    p(x, y, c) {
        this.r(x, y, 1, 1, c);
    }
    gp(x, y, c) {
        this.g(x, y, 1, 1, c);
    }
    /** outlined box */
    o(x, y, w, h, fill, line = "#141016") {
        this.r(x, y, w, h, line);
        this.r(x + 1, y + 1, w - 2, h - 2, fill);
    }
    line(x0, y0, x1, y1, c, glow = false) {
        x0 = Math.round(x0);
        y0 = Math.round(y0);
        x1 = Math.round(x1);
        y1 = Math.round(y1);
        const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0);
        const sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
        let err = dx + dy;
        for (let i = 0; i < 400; i++) {
            if (glow)
                this.gp(x0, y0, c);
            else
                this.p(x0, y0, c);
            if (x0 === x1 && y0 === y1)
                break;
            const e2 = 2 * err;
            if (e2 >= dy) {
                err += dy;
                x0 += sx;
            }
            if (e2 <= dx) {
                err += dx;
                y0 += sy;
            }
        }
    }
}
exports.Pen = Pen;
function makeSprite(w, h, ax, ay, seed, fn) {
    const A = makeCanvas(w, h);
    const E = makeCanvas(w, h);
    fn(new Pen(A.ctx, false), (0, rng_1.mulberry)(seed));
    fn(new Pen(E.ctx, true), (0, rng_1.mulberry)(seed));
    return { a: A.c, e: E.c, w, h, ax, ay };
}
