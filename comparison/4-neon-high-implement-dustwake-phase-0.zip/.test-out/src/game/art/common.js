"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.spriteCache = void 0;
exports.cached = cached;
exports.stoneBlob = stoneBlob;
const palette_1 = require("./palette");
/** One cache for every sprite family (keys are namespaced by family: `kind|v|alt`, `rub..`, `item..`). */
exports.spriteCache = new Map();
function cached(key, make) {
    let s = exports.spriteCache.get(key);
    if (!s) {
        s = make();
        exports.spriteCache.set(key, s);
    }
    return s;
}
/** A shaded, roughly elliptical stone (rubble, broken pillars, boulders, rock piles). */
function stoneBlob(p, x, y, w, h, r) {
    for (let j = 0; j < h; j++)
        for (let i = 0; i < w; i++) {
            const dx = (i + 0.5 - w / 2) / (w / 2), dy = (j + 0.5 - h / 2) / (h / 2);
            const v = dx * dx + dy * dy;
            if (v > 1.05)
                continue;
            let c = v > 0.62 ? palette_1.S.o : dx + dy < -0.5 ? palette_1.S.h : dx + dy < 0.1 ? palette_1.S.l : dx + dy < 0.6 ? palette_1.S.m : palette_1.S.d;
            if (c !== palette_1.S.o && r() < 0.06)
                c = palette_1.S.d;
            p.p(x + i, y + j, c);
        }
}
