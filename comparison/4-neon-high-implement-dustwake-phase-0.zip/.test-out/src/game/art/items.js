"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ITEM_ART = void 0;
exports.glyphPattern = glyphPattern;
exports.itemIcon = itemIcon;
const glyphs_1 = require("../content/glyphs");
const util_1 = require("../util");
const palette_1 = require("./palette");
const tools_1 = require("../content/tools");
const common_1 = require("./common");
function glyphPattern(p, gi, x, y, color, glow) {
    const pat = glyphs_1.GLYPHS[gi].pat;
    for (let j = 0; j < 7; j++)
        for (let i = 0; i < 7; i++)
            if (pat[j][i] === "#")
                glow ? p.g(x + i, y + j, 1, 1, color) : p.p(x + i, y + j, color);
}
/**
 * The ruby ramp, shared by the High-Grade Ruby, the crown's main stone (the same
 * gem, still set) and the Ruby Golem Core carved from it.
 */
const RB = { o: "#2a0610", d: "#5c0d1f", m: "#8e1530", l: "#c0233f", h: "#e5566b", s: "#ffb0ba" };
/** An outlined box with its corners clipped (round-ish at icon size). */
function rbox(p, x, y, w, h, fill, line) {
    p.r(x + 1, y, w - 2, h, line);
    p.r(x, y + 1, w, h - 2, line);
    p.r(x + 1, y + 1, w - 2, h - 2, fill);
}
const glyphIcon = (gi) => (p) => {
    const g = glyphs_1.GLYPHS[gi];
    p.o(2, 3, 12, 12, "#4a4552", palette_1.S.o);
    p.r(3, 4, 10, 2, "#6a6372");
    p.r(3, 12, 10, 2, "#2e2a33");
    glyphPattern(p, gi, 4, 5, g.color, true);
};
const IRON = { o: "#14161a", d: palette_1.IR.d, m: palette_1.IR.m, l: palette_1.IR.l, h: palette_1.IR.h };
const RUSTY = { o: "#1a1210", d: "#4a2a1c", m: "#6e4028", l: "#8e5a38", h: "#a87048" };
const FINE = { o: "#14161a", d: "#3c4650", m: "#66737f", l: "#96a6b4", h: "#d6e2ec" };
/** Head shapes as pixel rows (o outline, d/m/l/h the ramp, . nothing) and where they sit in the 16x16 icon. */
const HEAD_SHAPES = {
    shovel: { at: [3, 1], rune: [4, 7], rows: [
            "...oooo...", "...ohlo...", "...omlo...", "..oomloo..", ".ohlmmmdo.", ".ohmmmmdo.", ".olmmmmdo.",
            ".olmmmmdo.", ".olmmmddo.", "..olmmdo..", "..olmddo..", "...omdo...", "....oo....",
        ] },
    pickaxe: { at: [1, 4], rune: [6, 2], rows: [
            "....oooooo....", "..oohhhllmoo..", ".ohllommoommo.", "ohlo.olmo.omdo", "oo...olmo...oo", ".....oddo.....", "......oo......",
        ] },
    axe: { at: [2, 3], rune: [4, 4], rows: [
            "..oo.......", ".ohlo......", "ohllmoooooo", "ohlmmmmmmdo", "ohlmmmmoodo", "ohlmmmmoodo", "ohlmmmmmmdo", "ohllmoooooo", ".ohlo......", "..oo.......",
        ] },
};
function drawHead(p, t, c, rune) {
    const { at, rows, rune: rp } = HEAD_SHAPES[t];
    rows.forEach((row, j) => { for (let i = 0; i < row.length; i++) {
        const ch = row[i];
        if (ch !== ".")
            p.p(at[0] + i, at[1] + j, c[ch]);
    } });
    if (c === RUSTY) {
        p.p(at[0] + rp[0], at[1] + rp[1], c.o);
        p.p(at[0] + rp[0] + 1, at[1] + rp[1] - 1, c.d);
    }
    if (c === FINE)
        p.p(at[0] + rp[0] + 2, at[1] + rp[1] + 1, palette_1.GD.l);
    if (rune) {
        p.gp(at[0] + rp[0], at[1] + rp[1], rune);
        p.gp(at[0] + rp[0] + 1, at[1] + rp[1] - 1, rune);
    }
}
function drawTool(p, t, c) {
    p.r(6, 2, 4, 13, palette_1.WD.o);
    p.r(7, 2, 2, 12, palette_1.WD.l);
    p.r(8, 3, 1, 11, palette_1.WD.m);
    p.p(7, 14, palette_1.WD.d);
    if (t === "axe") {
        p.o(1, 2, 7, 7, c.m, c.o);
        p.r(2, 3, 1, 5, c.h);
        p.r(3, 3, 2, 1, c.l);
        p.r(6, 3, 1, 5, c.d);
        p.r(8, 3, 2, 4, c.d);
        p.p(9, 2, c.o);
    }
    else if (t === "pickaxe") {
        p.r(3, 1, 10, 1, c.o);
        p.r(1, 2, 14, 3, c.o);
        p.r(2, 3, 12, 1, c.l);
        p.r(4, 2, 8, 1, c.h);
        p.r(6, 4, 4, 1, c.d);
        p.p(0, 4, c.o);
        p.p(15, 4, c.o);
        p.p(1, 5, c.o);
        p.p(14, 5, c.o);
    }
    else {
        p.r(4, 1, 8, 3, palette_1.WD.o);
        p.r(5, 2, 6, 1, palette_1.WD.l);
        p.o(4, 9, 8, 6, c.m, c.o);
        p.r(5, 10, 1, 4, c.h);
        p.r(6, 10, 4, 1, c.l);
        p.r(10, 10, 1, 4, c.d);
    }
    if (c === FINE)
        p.p(t === "shovel" ? 9 : 4, t === "shovel" ? 12 : 3, palette_1.GD.l);
}
const TOOL_ART = (() => {
    const out = {};
    for (const t of tools_1.TOOL_TYPE_IDS) {
        out[`head_${t}`] = (p) => drawHead(p, t, IRON);
        out[`head_${t}_rusted`] = (p) => drawHead(p, t, RUSTY);
        out[`head_${t}_fine`] = (p) => drawHead(p, t, FINE);
        out[`head_${t}_swift`] = (p) => drawHead(p, t, FINE, "#5cf0c8");
        out[`head_${t}_glow`] = (p) => drawHead(p, t, FINE, "#ffffff");
        out[t] = (p) => drawTool(p, t, IRON);
        out[`${t}_fine`] = (p) => drawTool(p, t, FINE);
    }
    return out;
})();
/** Item icon registry: item id -> draw function. Adding an item = adding an entry. */
exports.ITEM_ART = {
    ...TOOL_ART,
    // Three lumps of ore: dark stone, rust-red where the iron is.
    iron_ore: (p) => {
        p.o(2, 7, 7, 6, "#5a4a44", palette_1.S.o);
        p.r(3, 8, 3, 1, "#7a6a60");
        p.r(4, 10, 3, 2, "#a8623a");
        p.p(5, 10, "#d8905a");
        p.o(8, 4, 6, 6, "#4e4440", palette_1.S.o);
        p.r(9, 5, 2, 1, "#6e625a");
        p.r(10, 7, 3, 2, "#8e4a2a");
        p.p(11, 7, "#c8783e");
        p.o(7, 10, 7, 5, "#5a4a44", palette_1.S.o);
        p.r(8, 11, 2, 1, "#7a6a60");
        p.r(9, 12, 4, 2, "#a8623a");
        p.p(10, 12, "#e0a060");
    },
    // Two cast bars, the upper one catching the light.
    iron_ingot: (p) => {
        p.o(2, 9, 12, 5, palette_1.IR.m, "#14161a");
        p.r(3, 10, 10, 1, palette_1.IR.l);
        p.r(3, 12, 10, 1, palette_1.IR.d);
        p.p(2, 9, "#14161a");
        p.o(4, 4, 9, 5, palette_1.IR.l, "#14161a");
        p.r(5, 5, 7, 1, palette_1.IR.h);
        p.r(5, 7, 7, 1, palette_1.IR.m);
        p.p(6, 5, "#e6eef4");
    },
    // A heap of loose earth with a pebble in it.
    dirt: (p) => {
        p.r(3, 14, 10, 1, "rgba(0,0,0,0.35)");
        p.o(2, 8, 12, 6, "#4e3c2a", "#1a110b");
        p.o(4, 5, 8, 5, "#5a4630", "#1a110b");
        p.r(5, 6, 4, 1, "#6e583c");
        p.r(4, 9, 7, 1, "#5a4630");
        p.p(6, 11, "#3a2c1e");
        p.p(10, 10, "#3a2c1e");
        p.p(8, 7, "#7a6a50");
        p.p(11, 12, "#6a6372");
        p.p(4, 12, "#3a2c1e");
    },
    // A big brilliant-cut stone: a bright table, crown facets lit from the top left, a dark girdle,
    // and a pavilion narrowing to the culet. One glint glows, so it catches the eye on the ground.
    large_ruby: (p) => {
        p.r(5, 3, 6, 1, RB.o);
        p.r(4, 4, 8, 1, RB.o);
        p.r(5, 4, 6, 1, RB.h);
        p.r(5, 4, 2, 1, RB.s);
        p.r(3, 5, 10, 1, RB.o);
        p.r(4, 5, 1, 1, RB.l);
        p.r(5, 5, 6, 1, RB.h);
        p.r(11, 5, 1, 1, RB.m);
        p.p(6, 5, RB.s);
        p.r(2, 6, 12, 1, RB.o);
        p.r(3, 6, 4, 1, RB.l);
        p.r(7, 6, 3, 1, RB.m);
        p.r(10, 6, 3, 1, RB.d);
        p.r(2, 7, 12, 1, RB.o);
        p.r(3, 7, 10, 1, RB.d);
        for (let j = 0; j < 5; j++) {
            const y = 8 + j, x0 = 3 + j, w = 10 - 2 * j;
            p.r(x0, y, w, 1, RB.o);
            if (w > 2) {
                p.r(x0 + 1, y, w - 2, 1, RB.m);
                p.r(x0 + 1, y, Math.max(1, (w - 2) >> 1), 1, RB.l);
                p.p(x0 + w - 2, y, RB.d);
            }
        }
        p.p(8, 9, RB.d);
        p.p(8, 10, RB.d);
        p.gp(6, 4, "#fff0f2");
    },
    // The same stone carved down to a rune-cut dome, set in a plain iron collar with a bayonet lug each side and
    // a socket pin: a mass-made part, one tier notch, a modest glow. (The aether core is a free crystal, all light.)
    ruby_core: (p) => {
        p.o(1, 7, 3, 3, palette_1.IR.d, "#14161a");
        p.o(12, 7, 3, 3, palette_1.IR.d, "#14161a");
        p.r(7, 13, 2, 2, "#14161a");
        p.p(7, 13, palette_1.IR.m);
        rbox(p, 3, 3, 10, 11, palette_1.IR.m, "#14161a");
        p.r(4, 4, 8, 1, palette_1.IR.l);
        p.r(4, 12, 8, 1, palette_1.IR.d);
        p.r(11, 5, 1, 7, palette_1.IR.d);
        p.p(5, 4, palette_1.IR.h);
        rbox(p, 5, 5, 6, 7, RB.m, RB.o);
        p.r(6, 6, 2, 1, RB.h);
        p.p(6, 7, RB.l);
        p.r(9, 7, 1, 4, RB.d);
        p.p(7, 8, RB.o);
        p.p(8, 9, RB.o);
        p.p(7, 10, RB.o); // the carved rune
        p.g(7, 7, 2, 1, "#d8344e");
        p.g(8, 8, 1, 1, "#ff8090");
        p.g(6, 9, 1, 2, "#b02040");
    },
    chisel: (p) => {
        p.r(3, 11, 6, 3, "#14100c");
        p.r(4, 12, 4, 1, palette_1.WD.l);
        p.line(4, 12, 10, 6, palette_1.WD.m);
        p.line(5, 12, 11, 6, palette_1.WD.l);
        p.line(10, 6, 13, 3, palette_1.IR.l);
        p.line(11, 6, 14, 3, palette_1.IR.h);
        p.p(14, 2, "#e0e8f0");
        p.r(9, 6, 2, 2, palette_1.IR.d);
    },
    arm: (p) => {
        p.o(5, 0, 6, 5, palette_1.IR.m, "#14161a");
        p.p(6, 1, palette_1.IR.h);
        p.p(9, 1, palette_1.IR.h);
        p.o(6, 4, 4, 6, palette_1.IR.l, "#14161a");
        p.p(7, 6, palette_1.IR.h);
        p.o(5, 9, 6, 3, palette_1.IR.d, "#14161a");
        p.o(4, 11, 8, 5, palette_1.IR.m, "#14161a");
        p.r(5, 12, 2, 2, palette_1.IR.h);
        p.r(9, 14, 2, 1, palette_1.IR.d);
        p.p(8, 2, "#c06020");
        p.p(7, 7, "#c06020");
    },
    key: (p) => {
        p.o(2, 3, 6, 6, "#7a5a34", "#2a1a0c");
        p.r(4, 5, 2, 2, "#2a1a0c");
        p.r(7, 5, 7, 2, "#8a6a3a");
        p.r(7, 5, 7, 1, "#a8844a");
        p.r(11, 7, 1, 3, "#7a5a34");
        p.r(13, 7, 1, 2, "#7a5a34");
        p.p(9, 6, "#4a3418");
    },
    // The aether core: a free crystal, all light. A tall faceted diamond, tip to tip, lit from the top left: four
    // quadrant facets (a bright upper left, a deep lower right), a luminous rim, a girdle through the middle and a
    // glint near the top. No base or stand; every pixel glows.
    core: (p) => {
        const HALF = [1, 2, 3, 3, 4, 5, 6, 6, 5, 4, 3, 3, 2, 1]; // half-width per row, rows 1..14
        const FACET = {
            ul: { fill: "#8aeeff", mid: "#6adcfa", rim: "#e4ffff" },
            ur: { fill: "#3cb4f0", mid: "#4cc4f6", rim: "#8ae4ff" },
            ll: { fill: "#2a8ee0", mid: "#36a2ea", rim: "#5cc0f4" },
            lr: { fill: "#1a62b4", mid: "#2276c8", rim: "#3a94dc" },
        };
        HALF.forEach((n, i) => {
            const y = 1 + i, upper = i < 7;
            for (let d = 0; d < n; d++) {
                for (const left of [true, false]) {
                    const x = left ? 7 - d : 8 + d;
                    const f = FACET[`${upper ? "u" : "l"}${left ? "l" : "r"}`];
                    const rim = d === n - 1, centre = d === 0, girdle = i === 6 || i === 7;
                    // the rim is the brightest ring; one step in is the body of the facet; the centre line and a diagonal catch light
                    let c = rim ? f.rim : f.fill;
                    if (!rim && (centre || d === n - 2 || (upper ? (n - 1 - d) === 2 : false)))
                        c = f.mid;
                    if (girdle && !rim)
                        c = upper ? f.rim : f.mid;
                    p.g(x, y, 1, 1, c);
                }
            }
        });
        p.g(7, 8, 2, 1, "#ffffff"); // the heart where the facets meet
        p.g(6, 3, 1, 2, "#ffffff");
        p.gp(5, 5, "#e8ffff");
        p.gp(9, 11, "#a8e8ff");
    },
    schematic: (p) => {
        p.o(1, 4, 14, 8, "#2a4a7a", "#0e1a2e");
        p.r(2, 5, 12, 2, "#3a5a9a");
        p.r(0, 4, 2, 8, "#d0d8e8");
        p.r(14, 4, 2, 8, "#d0d8e8");
        p.r(0, 4, 1, 8, "#8a98b0");
        p.r(4, 8, 7, 1, "#8aa8d8");
        p.r(4, 10, 5, 1, "#8aa8d8");
        p.r(7, 7, 1, 4, "#8aa8d8");
        p.r(6, 3, 4, 10, "#6a2020");
        p.r(6, 3, 4, 1, "#8a3030");
    },
    // The broken crown: its main stone is the High-Grade Ruby (same ramp, still set), a small sapphire beside it,
    // an empty setting, one point snapped short and a crack through the band.
    crown: (p) => {
        const O = "#3a2a08";
        for (const [x, top] of [[2, 6], [7, 4], [12, 8]]) {
            p.r(x - 1, top - 1, 4, 11 - top + 1, O);
            p.r(x, top, 2, 11 - top, palette_1.GD.m);
            p.p(x, top, palette_1.GD.l);
        }
        p.p(13, 7, O);
        p.p(12, 8, palette_1.GD.d); // the snapped point
        p.r(1, 9, 14, 6, O);
        p.r(2, 10, 12, 4, palette_1.GD.m);
        p.r(2, 10, 12, 1, palette_1.GD.l);
        p.r(2, 13, 12, 1, palette_1.GD.d);
        p.r(6, 9, 4, 5, RB.o);
        p.r(7, 10, 2, 3, RB.m);
        p.p(7, 10, RB.h);
        p.p(8, 12, RB.d);
        p.p(7, 11, RB.l);
        p.r(3, 11, 2, 2, "#1a2a70");
        p.p(3, 11, "#4a70e0");
        p.r(11, 11, 2, 2, "#2a1e06");
        p.line(10, 10, 12, 13, O);
        p.gp(7, 10, "#ffd8de");
    },
    goblet: (p) => {
        p.o(4, 2, 8, 6, palette_1.IR.l, "#2a2e34");
        p.r(5, 3, 2, 3, palette_1.IR.h);
        p.r(7, 8, 2, 4, palette_1.IR.m);
        p.o(4, 12, 8, 3, palette_1.IR.l, "#2a2e34");
    },
    coin: (p) => {
        p.o(5, 7, 7, 7, palette_1.GD.m, "#3a2a08");
        p.r(6, 8, 2, 2, palette_1.GD.l);
        p.r(8, 10, 2, 2, palette_1.GD.d);
    },
    glyph0: glyphIcon(0), glyph1: glyphIcon(1), glyph2: glyphIcon(2), glyph3: glyphIcon(3),
    wood: (p) => {
        // two stacked logs
        for (const [x, y] of [[2, 9], [5, 5]]) {
            p.o(x, y, 10, 5, palette_1.WD.m, palette_1.WD.o);
            p.r(x + 1, y + 1, 8, 1, palette_1.WD.l);
            p.o(x + 8, y, 4, 5, "#b08a5a", palette_1.WD.o);
            p.p(x + 9, y + 2, palette_1.WD.d);
        }
    },
    stone: (p) => {
        p.o(2, 8, 7, 6, palette_1.S.m, palette_1.S.o);
        p.r(3, 9, 3, 1, palette_1.S.h);
        p.r(3, 12, 5, 1, palette_1.S.d);
        p.o(7, 5, 7, 8, palette_1.S.l, palette_1.S.o);
        p.r(8, 6, 3, 1, palette_1.S.h);
        p.r(12, 7, 1, 5, palette_1.S.d);
    },
    book_build: (p) => {
        p.o(2, 4, 12, 10, "#6a4a24", "#1a1008");
        p.r(3, 5, 10, 1, "#8a6a34");
        p.r(2, 12, 12, 2, "#d8ccb0");
        p.r(3, 12, 10, 1, "#b8ac90");
        p.r(6, 7, 4, 1, palette_1.GD.m);
        p.r(7, 8, 2, 3, palette_1.GD.m); // hammer sigil
    },
    book_repair: (p) => {
        p.o(2, 4, 12, 10, "#2a4a5a", "#08141a");
        p.r(3, 5, 10, 1, "#3a6a7a");
        p.r(2, 12, 12, 2, "#d8ccb0");
        p.r(3, 12, 10, 1, "#b8ac90");
        p.r(7, 6, 2, 5, "#a8c8d0");
        p.r(5, 8, 6, 1, "#a8c8d0"); // mending cross
    },
    // Processed materials.
    planks: (p) => {
        // three sawn boards, stacked and offset
        for (const [x, y, w] of [[1, 9, 13], [3, 6, 12], [2, 3, 12]]) {
            p.o(x, y, w, 4, "#b08a5a", palette_1.WD.o);
            p.r(x + 1, y + 1, w - 2, 1, "#c8a470");
            p.p(x + 3, y + 2, palette_1.WD.m);
            p.p(x + 8, y + 2, palette_1.WD.m);
            p.r(x + w - 3, y + 1, 1, 2, "#8a6a40");
        }
    },
    cut_stone: (p) => {
        // two squared blocks with chisel marks
        p.o(1, 8, 8, 6, palette_1.S.l, palette_1.S.o);
        p.r(2, 9, 6, 1, palette_1.S.h);
        p.r(2, 12, 6, 1, palette_1.S.d);
        p.r(8, 9, 1, 4, palette_1.S.d);
        p.o(7, 4, 8, 7, palette_1.S.m, palette_1.S.o);
        p.r(8, 5, 6, 1, palette_1.S.h);
        p.r(8, 9, 6, 1, palette_1.S.d);
        p.p(10, 7, palette_1.S.d);
        p.p(12, 7, palette_1.S.d);
        p.p(3, 10, palette_1.S.m);
        p.p(5, 11, palette_1.S.m);
    },
    // Runes: a squared tablet with a glowing sigil (the same 3x3 sigil the golem wears: ItemDef.worn.mark).
    rune_swift: (p) => {
        p.o(3, 1, 10, 14, "#4a4552", palette_1.S.o);
        p.r(4, 2, 8, 2, "#6a6372");
        p.r(4, 12, 8, 2, "#2e2a33");
        // two chevrons, ">>"
        for (const x of [5, 9]) {
            p.g(x, 5, 2, 1, "#5cf0c8");
            p.g(x + 1, 6, 2, 1, "#5cf0c8");
            p.g(x + 1, 7, 2, 1, "#5cf0c8");
            p.g(x, 8, 2, 1, "#5cf0c8");
            p.g(x + 1, 9, 1, 1, "#5cf0c8");
        }
        p.g(4, 10, 8, 1, "#2a9a80");
    },
    rune_glow: (p) => {
        p.o(3, 1, 10, 14, "#4a4552", palette_1.S.o);
        p.r(4, 2, 8, 2, "#6a6372");
        p.r(4, 12, 8, 2, "#2e2a33");
        // a sun: a bright core with four rays
        p.g(7, 5, 2, 6, "#ffffff");
        p.g(5, 7, 6, 2, "#ffffff");
        p.g(6, 6, 4, 4, "#fff8d8");
        p.g(7, 4, 2, 1, "#c8d8ff");
        p.g(7, 11, 2, 1, "#c8d8ff");
        p.g(4, 7, 1, 2, "#c8d8ff");
        p.g(11, 7, 1, 2, "#c8d8ff");
    },
    basket: (p) => {
        p.r(4, 2, 8, 1, palette_1.WD.d);
        p.r(3, 3, 1, 4, palette_1.WD.d);
        p.r(12, 3, 1, 4, palette_1.WD.d);
        p.o(2, 6, 12, 9, "#a8844a", palette_1.WD.o);
        for (let y = 7; y < 14; y++)
            for (let x = 3; x < 13; x++)
                if ((x + y * 2) % 4 === 0)
                    p.p(x, y, "#7a5a30");
        p.r(3, 7, 10, 1, "#c8a466");
    },
};
function itemIcon(id) {
    return (0, common_1.cached)("item" + id, () => (0, util_1.makeSprite)(16, 16, 8, 15, 3, (p) => exports.ITEM_ART[id](p)));
}
