"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PROP_ART = void 0;
exports.propSprite = propSprite;
// Prop sprites: the PROP_ART registry (kind -> draw function) and the cached
// lookup the renderer and the build menu use. The draw functions live with the
// rest of their family: art/propsSurface.ts (the wilds above) and
// art/propsDungeon.ts (the halls below). Presentation only.
const util_1 = require("../util");
const common_1 = require("./common");
const propsSurface_1 = require("./propsSurface");
const propsDungeon_1 = require("./propsDungeon");
const propsTown_1 = require("./propsTown");
const propsFolk_1 = require("./propsFolk");
const props_1 = require("../content/props");
function propSprite(kind, v, alt) {
    kind = (0, props_1.propDef)(kind).art ?? kind;
    const key = `${kind}|${v}|${alt}`;
    const c = common_1.spriteCache.get(key);
    if (c)
        return c;
    const s = makeProp(kind, v, alt);
    if (s)
        common_1.spriteCache.set(key, s);
    return s;
}
/** Prop sprite registry: kind -> draw function. Adding a prop kind = adding an entry (surface kinds first, then dungeon, then the town). */
exports.PROP_ART = { ...propsSurface_1.SURFACE_PROP_ART, ...propsDungeon_1.DUNGEON_PROP_ART, ...propsTown_1.TOWN_PROP_ART, ...propsFolk_1.FOLK_PROP_ART };
function makeProp(kind, v, alt) {
    const seed = kind.length * 101 + v * 13 + (alt ? 7 : 0);
    const M = (w, h, fn, ay = h) => (0, util_1.makeSprite)(w, h, Math.floor(w / 2), ay, seed, fn);
    const art = exports.PROP_ART[kind];
    return art ? art(v, alt, M) : null;
}
