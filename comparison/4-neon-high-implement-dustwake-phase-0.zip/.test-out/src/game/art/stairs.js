"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WALL_SHADE = exports.WALL_LIT = exports.stairRGB = exports.treadTone = exports.cornerShade = exports.TOP_LEVEL = exports.KERB = exports.STEP = void 0;
exports.stepShade = stepShade;
exports.flightSteps = flightSteps;
exports.flightStepAt = flightStepAt;
exports.flightPix = flightPix;
// The stair between the surface and the halls. It is one flight, drawn in two
// places: its head on the surface (propsSurface: the open `buriedgate`, looked
// down into) and the flight in the halls (tiles: FS.STAIR, climbed). Both take
// their steps from here, so a step is the same thing wherever it is met.
// Presentation only.
//
// The flight climbs south and is seen from the south and above, so no riser
// ever shows: only treads, each lower than the one in front of it. What makes
// that read as a stair and not as boards:
//   - a step is shaded as a solid, not ruled off with a line: a lit lip at its
//     north edge (the nosing), then the tread falling steadily into the shadow
//     of the step above until it is lost under that step's lip;
//   - it has depth, and the same depth at both ends. A step that is higher is
//     nearer the eye: deeper, wider and lighter. So on the surface the flight
//     shrinks and darkens as it goes down under the lintel, and in the halls
//     it grows and lightens as it climbs out of the hall toward the daylight;
//   - it runs between two walls, and they are seen: a coping along the top of
//     each that does not step, and under it the wall's face, tall beside the
//     lowest step and gone by the highest, the east one catching the light and
//     the west one in its own shade. Where each step meets the wall is a wedge
//     of shadow, so the flight's two edges are toothed;
//   - the treads are stone, and one stone each (a course of short stones is a
//     wall): chipped at the lip, pitted, the odd one cracked through, and worn
//     pale and round-edged down the middle of the flight.
const util_1 = require("../util");
/** Rows in a full step: the length of the shading ramp below. In the halls a step is this deep about half-way up. */
exports.STEP = 8;
/** Width of the coping (the kerb) along the top of each side wall. */
exports.KERB = 3;
/** The level of the stair's top step, counted in steps from the halls' floor: where the head starts counting down. */
exports.TOP_LEVEL = 14;
/** A step's rows, north to south, against its tread: the lit nosing, the tread, the shadow of the step above. */
const SHADE = [34, 14, 5, 0, -6, -16, -34, -60];
/**
 * Brightness of row `s` of a step `pitch` rows deep (0 is its north edge). Shallower steps (the head's, as they
 * recede) keep the lip and the deepest shadow and take the rows between from the same ramp.
 */
function stepShade(s, pitch) {
    if (s <= 0)
        return SHADE[0];
    if (s >= pitch - 1)
        return SHADE[exports.STEP - 1];
    return SHADE[Math.round((s * (exports.STEP - 1)) / (pitch - 1))];
}
/**
 * How far the wedge of shadow in a step's corner (against the kerb or the well's wall) reaches along row `s`:
 * nothing at the lip, widening a pixel a row over the step's last rows (four of them on a full step).
 */
const cornerShade = (s, pitch) => Math.max(0, s - Math.max(0, pitch - 5));
exports.cornerShade = cornerShade;
/** The grey of the tread `level` steps above the Vestibule's floor: a shade lighter with every step up. */
const treadTone = (level) => 80 + level * 3;
exports.treadTone = treadTone;
/** A grey as the stair's stone (the halls' faint violet). */
const stairRGB = (v) => [v, v * 0.96, v * 1.06];
exports.stairRGB = stairRGB;
/** What the east wall's face keeps of its step's tone (it catches the light), and the west (in its own shade). */
exports.WALL_LIT = 0.74, exports.WALL_SHADE = 0.44;
const layouts = new Map();
/**
 * The steps of a flight `H` rows long, north (its foot) to south (its top). There is a step to about seven
 * rows; the lowest is five deep and each one up is deeper, as the head's are shallower each one down. The wall
 * faces come in a pixel more beside each step down, from nothing beside the top one (the flight is the passage's
 * whole width there, less the coping). Levels run from 1, one step above the floor, to TOP_LEVEL, the step the
 * head on the surface starts from: however long the run, it is the whole stair.
 */
function flightSteps(H) {
    let L = layouts.get(H);
    if (!L) {
        const n = Math.max(1, Math.round(H / 7)), edge = (k) => Math.round((H * (5 * k + 0.3 * k * k)) / (5 * n + 0.3 * n * n));
        const steps = [];
        for (let i = 0; i < n; i++)
            steps.push({ y0: edge(i), pitch: edge(i + 1) - edge(i), inset: exports.KERB + (n - 1 - i), level: n === 1 ? exports.TOP_LEVEL : 1 + (i * (exports.TOP_LEVEL - 1)) / (n - 1) });
        layouts.set(H, (L = steps));
    }
    return L;
}
/** The step that row `fy` of a flight `H` long falls on. */
function flightStepAt(fy, H) {
    const L = flightSteps(H);
    let i = 0;
    while (i < L.length - 1 && fy >= L[i + 1].y0)
        i++;
    return L[i];
}
/**
 * One pixel of the flight in the halls, `W` wide and `H` long: `fx` across it, `fy` rows down from its north
 * (lower) end. From each side inward: the coping, the wall's face, the wedge of shadow in the step's corner,
 * the tread. `seed` tells one flight's chips and joints from another's.
 */
function flightPix(fx, fy, W, H, seed = 0) {
    const st = flightStepAt(fy, H), s = fy - st.y0, base = (0, exports.treadTone)(st.level);
    const n = ((0, util_1.hash2)(fx, fy, 61 + seed) - 0.5) * 7;
    const k = Math.min(fx, W - 1 - fx), east = fx >= W / 2;
    if (k < exports.KERB) {
        // the coping: a course of blocks lying up the slope, lit along its inner edge, jointed out of step with the
        // treads. It does not step, so its tone climbs with the row, not with the step.
        let v = (0, exports.treadTone)(1 + ((exports.TOP_LEVEL - 1) * fy) / Math.max(1, H - 1)) - 8 + (k === exports.KERB - 1 ? 16 : k === 1 ? 0 : -18);
        if ((fy + 4) % exports.STEP === 0)
            v -= 26;
        return (0, exports.stairRGB)(v + n * 0.5);
    }
    if (k < st.inset) {
        // the wall's face, from the coping down to the tread: a course of blocks to each step, the bed joint along
        // the step's last row, a head joint in every other course, and (east) its foot catching the light
        let v = base * (east ? exports.WALL_LIT : exports.WALL_SHADE);
        if (s === st.pitch - 1)
            v -= east ? 30 : 14;
        else if (k === exports.KERB)
            v -= east ? 12 : 6; // the coping's shadow down the top of the face
        else if (east && k === st.inset - 1)
            v += 22;
        else if (s > 0 && k === exports.KERB + ((st.inset - exports.KERB) >> 1) && (Math.round(st.level) & 1) === 1 && st.inset - exports.KERB > 3)
            v -= east ? 22 : 10;
        return (0, exports.stairRGB)(Math.max(6, v) + n * 0.4);
    }
    // the corner against the wall: a wedge of shadow, widening to the foot of the step above; the west wall also
    // throws its own shade along the tread ends
    const d = k - st.inset, wedge = (0, exports.cornerShade)(s, st.pitch);
    if (d < wedge + (east || !wedge ? 0 : 2))
        return (0, exports.stairRGB)(base - 60 + n * 0.4);
    let t = stepShade(s, st.pitch);
    if (d < 2 && !east)
        t -= 34;
    else if (d === 0)
        t -= 16;
    // worn down the middle of the flight: paler, and the lip rounded off (its light spread over two rows)
    if (Math.abs(fx - (W - 1) / 2) < W * 0.17)
        t += s === 0 ? -9 : s === 1 && st.pitch >= 6 ? 11 : s < st.pitch - 3 ? 5 : 0;
    // one stone to a step; a few have cracked through, each somewhere of its own
    const step = Math.round(st.level * 8), run = W - st.inset * 2 - 14;
    if (s > 0 && s < st.pitch - 1 && run > 0 && (0, util_1.hash2)(step, seed, 62) < 0.4 && fx === st.inset + 7 + Math.floor((0, util_1.hash2)(step, seed, 65) * run) + (s > st.pitch >> 1 ? 1 : 0))
        t -= 15;
    // a chip out of the lip, a pit in the tread
    if (s === 0 && (0, util_1.hash2)(fx >> 1, step, 64 + seed) < 0.07)
        t -= 24;
    else if (s > 1 && s < st.pitch - 3 && (0, util_1.hash2)(fx >> 1, fy, 63 + seed) < 0.035)
        t -= 10;
    return (0, exports.stairRGB)(base + t + n);
}
