"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AreaView = exports.CH = void 0;
// Presentation of one Area: baked background + light registry. Subscribes to
// the area's dirty-rect notifications and catches up once per frame (flush),
// so a burst of world changes costs one local re-bake, not one per change.
//
// Large areas: the background is baked in CH x CH tile chunks. Chunks under
// the camera are baked on demand (prepare), the rest one per frame in the
// background (idle). Light visibility is traced lazily the first time a light
// reaches the view window. Dirty-rect re-bakes and re-traces work exactly as
// before (bakeRegion is tile-local and decals are clipped per region, so a
// chunked bake is pixel-identical to a full one).
const tiles_1 = require("../content/tiles");
const glyphs_1 = require("../content/glyphs");
const items_1 = require("../content/items");
const props_1 = require("../content/props");
const ritual_1 = require("../content/ritual");
const glyphs_2 = require("../content/glyphs");
const tiles_2 = require("../art/tiles");
const util_1 = require("../util");
const light_1 = require("../light");
const area_1 = require("../world/area");
exports.CH = 8;
class AreaView {
    constructor(area) {
        Object.defineProperty(this, "area", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: area
        });
        Object.defineProperty(this, "bg", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Insertion-ordered: lights are appended as they come into existence, as before. */
        Object.defineProperty(this, "lights", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        /** Instrumentation for perf checks. */
        Object.defineProperty(this, "stats", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { chunksBaked: 0, visTraced: 0 }
        });
        Object.defineProperty(this, "pending", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "syncedRev", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: -1
        });
        Object.defineProperty(this, "dynamic", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Set()
        });
        Object.defineProperty(this, "unsub", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "cw", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "chh", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "baked", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "nextIdle", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        this.bg = (0, util_1.makeCanvas)(area.w * tiles_1.TS, area.h * tiles_1.TS);
        this.cw = Math.ceil(area.w / exports.CH);
        this.chh = Math.ceil(area.h / exports.CH);
        this.baked = new Uint8Array(this.cw * this.chh);
        this.unsub = area.onChange((r) => { this.pending = (0, area_1.unionRect)(this.pending, r); });
        this.syncLights();
    }
    dispose() { this.unsub(); }
    get fullyBaked() { return this.baked.every((b) => b === 1); }
    bakeChunk(i) {
        if (this.baked[i])
            return;
        this.baked[i] = 1;
        const cx = i % this.cw, cy = Math.floor(i / this.cw);
        (0, tiles_2.bakeRegion)(this.bg.ctx, this.area, cx * exports.CH, cy * exports.CH, Math.min(this.area.w, (cx + 1) * exports.CH) - 1, Math.min(this.area.h, (cy + 1) * exports.CH) - 1);
        this.stats.chunksBaked++;
    }
    /** Make everything the camera (px rect) can see ready: background chunks and light visibility. */
    prepare(camX, camY, w, h) {
        const x0 = Math.max(0, Math.floor(camX / tiles_1.TS / exports.CH)), x1 = Math.min(this.cw - 1, Math.floor((camX + w) / tiles_1.TS / exports.CH));
        const y0 = Math.max(0, Math.floor(camY / tiles_1.TS / exports.CH)), y1 = Math.min(this.chh - 1, Math.floor((camY + h) / tiles_1.TS / exports.CH));
        for (let cy = y0; cy <= y1; cy++)
            for (let cx = x0; cx <= x1; cx++)
                this.bakeChunk(cy * this.cw + cx);
        for (const L of this.lights.values()) {
            if (L.n > 0)
                continue;
            if (L.x + L.rad < camX - 32 || L.x - L.rad > camX + w + 32 || L.y + L.rad < camY - 32 || L.y - L.rad > camY + h + 32)
                continue;
            (0, light_1.computeVis)(L, this.area);
            this.stats.visTraced++;
        }
    }
    /** Background work: bake one more chunk. Returns false when done. */
    idle() {
        while (this.nextIdle < this.baked.length && this.baked[this.nextIdle])
            this.nextIdle++;
        if (this.nextIdle >= this.baked.length)
            return false;
        this.bakeChunk(this.nextIdle);
        return true;
    }
    /** Apply pending world changes. Returns true if tiles changed (callers refresh moving lights). */
    flush() {
        if (this.area.interactionRevision !== this.syncedRev)
            this.syncLights();
        const r = this.pending;
        if (!r)
            return false;
        this.pending = null;
        (0, tiles_2.bakeRegion)(this.bg.ctx, this.area, r.x0, r.y0, r.x1, r.y1);
        for (const L of this.lights.values()) {
            if (L.n === 0)
                continue; // not traced yet; it will be when it comes into view
            if (L.ox + L.n - 1 < r.x0 || L.ox > r.x1 || L.oy + L.n - 1 < r.y0 || L.oy > r.y1)
                continue;
            (0, light_1.computeVis)(L, this.area);
            this.stats.visTraced++;
        }
        return true;
    }
    byId(id) {
        for (const L of this.lights.values())
            if (L.id === id)
                return L;
        return undefined;
    }
    /** Reconcile lights with what the world state says should exist. */
    /**
     * A light owned by presentation rather than area state (e.g. an NPC's eye:
     * actors live on the World, not the Area). Created on first request, kept in
     * the same registry (so it is traced, culled and accumulated like any other
     * light); the caller drives its `int` each frame.
     */
    dynamicLight(key, make) {
        this.dynamic.add(key);
        let L = this.lights.get(key);
        if (!L) {
            L = make();
            this.lights.set(key, L);
        }
        return L;
    }
    syncLights() {
        this.syncedRev = this.area.interactionRevision;
        const want = this.wantedLights();
        const keys = new Set([...want.map((w) => w.key), ...this.dynamic]);
        for (const k of [...this.lights.keys()])
            if (!keys.has(k))
                this.lights.delete(k);
        for (const w of want)
            if (!this.lights.has(w.key))
                this.lights.set(w.key, w.make());
    }
    wantedLights() {
        const a = this.area, out = [];
        a.lights.forEach((l, i) => {
            // Where people keep the lights (`tended`), a prop's light carries its kind's habit: the host dims it by the hour.
            let habit;
            if (l.owner) {
                const p = a.prop(l.owner);
                if (!p || ((0, props_1.propDef)(p.kind).light?.when === "lit" && !p.lit))
                    return;
                if (a.base.tended)
                    habit = (0, props_1.propDef)(p.kind).habit;
            }
            out.push({
                key: "area" + i,
                make: () => {
                    const L = (0, light_1.makeLight)(l.x, l.y, l.rad, l.col, l.int, l.flick, l.id);
                    if (habit) {
                        L.owner = l.owner;
                        L.habit = habit;
                    }
                    if (l.sky)
                        L.sky = [l.col[0], l.col[1], l.col[2]];
                    return L;
                },
            });
        });
        for (const p of a.props) {
            const g = p.item && !p.container && !p.taken ? items_1.ITEMS[p.item].glow : undefined;
            if (g)
                out.push({ key: "item:" + p.id, make: () => (0, light_1.makeLight)(p.x, p.y - 8, g.rad, (0, glyphs_1.hexToCol)(g.color), g.int, g.flick) });
        }
        const r = a.ritual;
        if (r) {
            const c = a.ritualPos;
            if (r.core)
                out.push({ key: "core", make: () => (0, light_1.makeLight)(c.x, c.y - 6, 54, [0.4, 0.85, 1], 0.8, 0.08) });
            const sp = (0, ritual_1.socketPositions)(c);
            r.sockets.forEach((g, i) => {
                if (g >= 0)
                    out.push({ key: `socket${i}:${g}`, make: () => (0, light_1.makeLight)(sp[i].x, sp[i].y - 4, 30, (0, glyphs_1.hexToCol)(glyphs_2.GLYPHS[g].color), 0.5, 0.05) });
            });
        }
        // Props built during play emit their kind's light (torches), reconciled like everything else.
        for (const p of a.props) {
            if (!p.dyn)
                continue;
            const L = (0, props_1.propDef)(p.kind).light;
            if (L && (L.when === "always" || p.lit))
                out.push({ key: "prop:" + p.id, make: () => (0, light_1.makeLight)(p.x + L.dx, p.y + L.dy, L.rad, L.col, L.int, L.flick) });
        }
        return out;
    }
}
exports.AreaView = AreaView;
