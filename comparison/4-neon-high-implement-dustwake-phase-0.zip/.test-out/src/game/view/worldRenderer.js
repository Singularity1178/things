"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WorldRenderer = void 0;
// World renderer (extracted from game.ts in Phase 0.6).
// Owns the offscreen scene/emissive/lighting buffers, light shafts, rune art,
// and interpolated actor/prop/tile rendering, leaving room for Phase 2's
// overview renderer.
const tiles_1 = require("../content/tiles");
const items_1 = require("../content/items");
const props_1 = require("../content/props");
const digging_1 = require("../content/digging");
const glyphs_1 = require("../content/glyphs");
const flags_1 = require("../content/flags");
const props_2 = require("../art/props");
const tiles_2 = require("../art/tiles");
const items_2 = require("../art/items");
const util_1 = require("../util");
const golem_1 = require("../golem");
const light_1 = require("../light");
const circle_1 = require("../circle");
const surfaceRune_1 = require("../surfaceRune");
const world_1 = require("../world/world");
const actors_1 = require("./actors");
const gear_1 = require("../sim/gear");
const daycycle_1 = require("../content/daycycle");
const daytime_1 = require("../sim/daytime");
const zoom_1 = require("./zoom");
const BURIED_AMBIENT = [0.05, 0.045, 0.065];
class WorldRenderer {
    constructor(wctx) {
        Object.defineProperty(this, "scene", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (0, util_1.makeCanvas)(zoom_1.BASE_W, zoom_1.BASE_H)
        });
        Object.defineProperty(this, "emit", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (0, util_1.makeCanvas)(zoom_1.BASE_W, zoom_1.BASE_H)
        });
        Object.defineProperty(this, "lighting", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new light_1.Lighting(zoom_1.BASE_W, zoom_1.BASE_H)
        });
        Object.defineProperty(this, "outImg", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "circle", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (0, circle_1.buildCircle)()
        });
        Object.defineProperty(this, "shaft", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "sunShaft", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "selfPose", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "runeArtCache", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        this.outImg = wctx.createImageData(zoom_1.BASE_W, zoom_1.BASE_H);
        this.shaft = buildShaft(["#1c2638", "#121a28", "#26324a"]);
        this.sunShaft = buildShaft(["#4a3a1c", "#33280f", "#5e4a22"]);
    }
    get runeArt() {
        return (this.runeArtCache ?? (this.runeArtCache = new surfaceRune_1.SurfaceRuneArt(this.circle.pixels)));
    }
    resize(wctx, vw, vh) {
        this.scene = (0, util_1.makeCanvas)(vw, vh);
        this.emit = (0, util_1.makeCanvas)(vw, vh);
        this.lighting = new light_1.Lighting(vw, vh);
        this.outImg = wctx.createImageData(vw, vh);
    }
    render(p) {
        const sc = this.scene.ctx, ec = this.emit.ctx, area = p.area;
        const { camX, camY, vw: W, vh: H, t } = p;
        const hour = (0, daytime_1.worldHour)(p.world);
        const alpha = p.alpha ?? 1;
        sc.fillStyle = "#000";
        sc.fillRect(0, 0, W, H);
        ec.fillStyle = "#000";
        ec.fillRect(0, 0, W, H);
        p.view.prepare(camX, camY, W, H);
        p.view.idle();
        sc.drawImage(p.view.bg.c, camX, camY, W, H, 0, 0, W, H);
        const spr = (s, x, y) => {
            const dx = Math.round(x - s.ax - camX), dy = Math.round(y - s.ay - camY);
            if (dx > W || dy > H || dx + s.w < 0 || dy + s.h < 0)
                return;
            sc.drawImage(s.a, dx, dy);
            ec.drawImage(s.e, dx, dy);
        };
        // ---- interior doorway daylight
        const daylight = (0, daycycle_1.sunLevel)(hour);
        if (area.base.interior && daylight > 0)
            for (const pt of area.base.portals ?? []) {
                if (!pt.door || pt.dir !== "down")
                    continue;
                const x = pt.x - 1 - camX, y = pt.y + 4 - camY, ww = pt.w + 2;
                sc.globalAlpha = daylight;
                sc.fillStyle = "#cfc49c";
                sc.fillRect(x, y, ww, 6);
                sc.fillStyle = "#f0e8c8";
                sc.fillRect(x + 1, y + 2, ww - 2, 3);
                sc.globalAlpha = 1;
                ec.globalAlpha = daylight * 0.45;
                ec.fillStyle = "#a89868";
                ec.fillRect(x, y, ww, 6);
                ec.globalAlpha = 1;
            }
        // ---- rune circle (floor layer)
        const r = area.ritual;
        if (r) {
            const c = area.ritualPos;
            const schemRead = (0, world_1.hasFlag)(p.world, flags_1.FLAGS.knowSchematic);
            const ccx = c.x - circle_1.CR - camX, ccy = c.y - circle_1.CR - camY;
            if (ccx > -140 && ccx < W + 10 && ccy > -140 && ccy < H + 10) {
                sc.drawImage(this.circle.base, ccx, ccy);
                sc.drawImage(r.carved ? this.circle.gapCarved : this.circle.chalk, ccx, ccy);
                let lvl = r.active ? 0.55 + 0.35 * Math.sin(t * 3) + Math.min(0.3, r.actT * 0.1) : 0.16 + 0.06 * Math.sin(t * 1.3);
                if (p.fizzT > 0)
                    lvl = Math.random() * 0.8;
                ec.globalAlpha = (0, util_1.clamp)(lvl, 0, 1);
                ec.drawImage(this.circle.glow, ccx, ccy);
                if (r.carved)
                    ec.drawImage(this.circle.glowGap, ccx, ccy);
                if (!r.carved && schemRead) {
                    ec.globalAlpha = 0.45 + 0.3 * Math.sin(t * 4);
                    ec.drawImage(this.circle.ghost, ccx, ccy);
                }
                if (r.active) {
                    ec.globalCompositeOperation = "lighter";
                    ec.globalAlpha = 0.35 + 0.25 * Math.sin(t * 5);
                    ec.drawImage(this.circle.glow, ccx, ccy);
                    ec.drawImage(this.circle.glowGap, ccx, ccy);
                    ec.globalCompositeOperation = "source-over";
                }
                ec.globalAlpha = 1;
            }
        }
        // ---- rune circles that are props (surface)
        for (const pr of area.props)
            if (pr.kind === "runecircle")
                this.drawSurfaceRune(pr, p.surfaceRuneState(), camX, camY, W, H, t);
        const list = [];
        const vx0 = camX - 48, vx1 = camX + W + 48, vy0 = camY - 16, vy1 = camY + H + 60;
        for (const pr of area.props) {
            if (pr.x < vx0 || pr.x > vx1 || pr.y < vy0 || pr.y > vy1)
                continue;
            if (pr.kind === "pedestal") {
                const i = Number(pr.id.slice(3));
                list.push({ y: pr.y, f: () => this.drawPedestal(p, pr, i, spr, camX, camY) });
                continue;
            }
            const def = (0, props_1.propDef)(pr.kind);
            const lvl = def.habit ? p.tendedLevel(pr, hour) : 1;
            const alt = def.alt === "lit" ? !!pr.lit && lvl > 0.05 : def.alt === "taken" ? pr.taken : pr.open;
            const s = (0, props_2.propSprite)(pr.kind, (0, digging_1.propLook)(pr), alt);
            if (!s)
                continue;
            if (lvl <= 0.01 && def.habit === "window")
                continue;
            list.push({
                y: def.wallMounted ? pr.y - 0.5 : def.flat ? pr.y - 16 : pr.y,
                f: () => {
                    if (lvl < 1 && def.alt !== "lit")
                        this.drawDimmed(s, pr, lvl, def.habit === "window", camX, camY, W, H);
                    else if (def.sway && !alt)
                        this.drawSwaying(s, pr, camX, camY, W, H, t);
                    else
                        spr(s, pr.x, pr.y);
                    if (pr.lit && def.fire && lvl > 0.05)
                        this.drawFlame(pr, def.fire.big, camX, camY, t);
                    if (pr.item && !pr.container && !pr.taken && items_1.ITEMS[pr.item].showOnProp !== false) {
                        const ic = (0, items_2.itemIcon)(pr.item);
                        const bob = (0, items_1.isGlyph)(pr.item) ? Math.round(Math.sin(t * 2) * 0.6) : 0;
                        spr(ic, pr.x + (def.itemDx ?? 0), pr.y - (pr.itemZ ?? 8) + bob);
                    }
                },
            });
        }
        for (const l of area.loose) {
            if (l.taken || l.x < vx0 || l.x > vx1 || l.y < vy0 || l.y > vy1)
                continue;
            list.push({ y: l.y, f: () => spr((0, items_2.itemIcon)(l.item), l.x, l.y + 2) });
        }
        const AW = area.w;
        const tx0 = Math.max(0, Math.floor(camX / tiles_1.TS) - 1), tx1 = Math.min(AW - 1, Math.floor((camX + W) / tiles_1.TS) + 1);
        const ty0 = Math.max(0, Math.floor(camY / tiles_1.TS) - 1), ty1 = Math.min(area.h - 1, Math.floor((camY + H) / tiles_1.TS) + 3);
        for (let ty = ty0; ty <= ty1; ty++) {
            for (let tx = tx0; tx <= tx1; tx++) {
                const tile = area.grid[ty * AW + tx];
                const x = tx * tiles_1.TS + 8, y = ty * tiles_1.TS + 16;
                if (tile === tiles_1.T.RUBBLE) {
                    const s = (0, tiles_2.rubbleSprite)(Math.floor((0, util_1.hash2)(tx, ty, 5) * 3), false);
                    list.push({ y, f: () => spr(s, x, y) });
                }
                else if (tile === tiles_1.T.CRACKED) {
                    const s = (0, tiles_2.rubbleSprite)(0, true);
                    const sh = p.shudder;
                    const jx = sh && sh.tx === tx && ty >= sh.ty && ty <= sh.ty + 2 ? Math.round(Math.sin(t * 80) * 2 * Math.min(1, sh.t / 0.3)) : 0;
                    list.push({
                        y,
                        f: () => {
                            spr(s, x + jx, y);
                            if (p.crackFlash > 0) {
                                ec.globalAlpha = p.crackFlash;
                                ec.drawImage(s.e, Math.round(x + jx - s.ax - camX), Math.round(y - s.ay - camY));
                                ec.globalAlpha = 1;
                            }
                        },
                    });
                }
                else if (tile === tiles_1.T.PILLAR) {
                    const s = (0, tiles_2.pillarSprite)(area.tvar[ty * AW + tx] === 1);
                    list.push({ y, f: () => spr(s, x, y) });
                }
                else if (tile === tiles_1.T.LOCKED) {
                    const s = (0, tiles_2.doorSprite)();
                    list.push({ y, f: () => spr(s, x, y) });
                }
                else if (tile === tiles_1.T.BARS) {
                    const s = (0, tiles_2.barsSprite)();
                    list.push({ y, f: () => spr(s, x, y) });
                }
            }
        }
        // ---- Non-player actors (interpolated between fixed ticks)
        for (const a of p.world.actors) {
            if (a.id === p.world.playerId || a.area !== area.id)
                continue;
            const pos = p.interp ? p.interp.position(a, alpha) : { x: a.x, y: a.y };
            if (pos.x < vx0 || pos.x > vx1 || pos.y < vy0 || pos.y > vy1)
                continue;
            const dx = pos.x - a.x, dy = pos.y - a.y;
            list.push({
                y: pos.y,
                f: () => {
                    (0, actors_1.drawActor)(sc, ec, p.world, a, camX - dx, camY - dy, t, p.npcLook(a));
                    if (p.selectedActors?.has(a.id)) {
                        const sx = Math.round(pos.x - camX), sy = Math.round(pos.y - camY);
                        ec.fillStyle = "#f2d878";
                        ec.fillRect(sx - 7, sy - 2, 14, 1);
                        ec.fillRect(sx - 7, sy + 1, 14, 1);
                        ec.fillRect(sx - 7, sy - 2, 1, 4);
                        ec.fillRect(sx + 6, sy - 2, 1, 4);
                    }
                },
            });
        }
        // ---- Player actor (interpolated)
        const pl = (0, world_1.player)(p.world);
        if (!p.hideGolem) {
            const pos = p.interp ? p.interp.position(pl, alpha) : { x: pl.x, y: pl.y };
            list.push({ y: pos.y, f: () => this.drawPlayer(p, pos.x, pos.y, camX, camY) });
        }
        // ---- Ground-sorted particles
        for (const pt of p.particles.list) {
            if (pt.kind === "debris" || pt.kind === "dust" || pt.kind === "smoke" || pt.kind === "splash") {
                list.push({
                    y: pt.y,
                    f: () => {
                        sc.fillStyle = pt.col;
                        const s = pt.size;
                        sc.fillRect(Math.round(pt.x - camX), Math.round(pt.y - pt.z - camY), s, s);
                        if (pt.emit === false) {
                            ec.fillStyle = "#000";
                            ec.fillRect(Math.round(pt.x - camX), Math.round(pt.y - pt.z - camY), s, s);
                        }
                    },
                });
            }
        }
        list.sort((a, b) => a.y - b.y);
        for (const d of list)
            d.f();
        // ---- Moonbeam / sunbeam shaft
        const moon = p.view.byId("moon");
        if (moon) {
            const mx = Math.round(moon.x - this.shaft.ax - camX), my = Math.round(moon.y + 2 - this.shaft.ay - camY);
            ec.globalCompositeOperation = "lighter";
            if (daylight < 1) {
                ec.globalAlpha = 1 - daylight;
                ec.drawImage(this.shaft.e, mx, my);
            }
            if (daylight > 0) {
                ec.globalAlpha = daylight;
                ec.drawImage(this.sunShaft.e, mx, my);
            }
            ec.globalAlpha = 1;
            ec.globalCompositeOperation = "source-over";
        }
        // ---- Floating / emissive particles
        p.particles.renderFloating(sc, ec, camX, camY, W, H);
        // ---- Lighting compose
        const sImg = sc.getImageData(0, 0, W, H);
        const eImg = ec.getImageData(0, 0, W, H);
        const active = p.hideGolem ? [] : [p.glight];
        for (const L of p.view.lights.values())
            if (L.on)
                active.push(L);
        this.lighting.accumulate(active, camX, camY);
        const exposure = (0, daytime_1.exposureOf)(area);
        this.lighting.compose(sImg.data, eImg.data, this.outImg.data, (0, daycycle_1.ambientAt)(area.base.ambient ?? BURIED_AMBIENT, hour, exposure), 6, (0, daycycle_1.lampGain)(hour, exposure));
        p.wctx.putImageData(this.outImg, 0, 0);
        const eye = p.eyeSpot();
        p.vision.draw(p.wctx, pl, camX, camY, W, H, t, eye && { x: eye.x + eye.w / 2 - 1, y: eye.y, w: eye.w, show: eye.show });
    }
    drawSurfaceRune(pr, st, camX, camY, vw, vh, t) {
        const ccx = Math.round(pr.x - circle_1.CR - camX), ccy = Math.round(pr.y - circle_1.CR - camY);
        if (ccx > -140 && ccx < vw + 10 && ccy > -140 && ccy < vh + 10) {
            const sc = this.scene.ctx, ec = this.emit.ctx;
            const L = this.runeArt.layers(st.t);
            sc.drawImage(L.scene, ccx, ccy);
            if (st.glow > 0) {
                ec.globalAlpha = (0, util_1.clamp)(st.glow, 0, 1);
                ec.drawImage(L.emit, ccx, ccy);
                if (st.glow > 1) {
                    ec.globalCompositeOperation = "lighter";
                    ec.globalAlpha = (0, util_1.clamp)(st.glow - 1, 0, 1);
                    ec.drawImage(L.emit, ccx, ccy);
                    ec.globalCompositeOperation = "source-over";
                }
                ec.globalAlpha = 1;
            }
        }
        if (st.column > 0)
            this.drawSummonColumn(pr.x - camX, pr.y - camY, st.column, t);
    }
    drawSummonColumn(x, y, k, t) {
        const ec = this.emit.ctx;
        x = Math.round(x);
        y = Math.round(y);
        const w = Math.round(3 + 7 * k);
        ec.globalCompositeOperation = "lighter";
        for (let yy = y + 4; yy > -2; yy -= 2) {
            const f = 1 - ((y - yy) / Math.max(1, y + 2)) * 0.6;
            const wob = Math.round(Math.sin(yy * 0.21 + t * 9) * k);
            ec.globalAlpha = (0, util_1.clamp)(k * f * 0.5, 0, 1);
            ec.fillStyle = "#9a70ff";
            ec.fillRect(x - w + wob, yy - 2, w * 2, 2);
            ec.globalAlpha = (0, util_1.clamp)(k * f, 0, 1);
            ec.fillStyle = "#e8e0ff";
            ec.fillRect(x - 1 + wob, yy - 2, 2 + Math.round(k * 2), 2);
        }
        ec.globalAlpha = (0, util_1.clamp)(k * 0.6, 0, 1);
        ec.fillStyle = "#c0a0ff";
        ec.fillRect(x - 14, y - 3, 28, 8);
        ec.globalAlpha = 1;
        ec.globalCompositeOperation = "source-over";
    }
    drawDimmed(s, pr, lvl, whole, camX, camY, vw, vh) {
        const dx = Math.round(pr.x - s.ax - camX), dy = Math.round(pr.y - s.ay - camY);
        if (dx > vw || dy > vh || dx + s.w < 0 || dy + s.h < 0)
            return;
        const sc = this.scene.ctx, ec = this.emit.ctx;
        if (whole)
            sc.globalAlpha = lvl;
        sc.drawImage(s.a, dx, dy);
        sc.globalAlpha = 1;
        if (lvl > 0.01) {
            ec.globalAlpha = lvl;
            ec.drawImage(s.e, dx, dy);
            ec.globalAlpha = 1;
        }
    }
    drawSwaying(s, pr, camX, camY, vw, vh, t) {
        const dx = Math.round(pr.x - s.ax - camX), dy = Math.round(pr.y - s.ay - camY);
        if (dx > vw || dy > vh || dx + s.w < 0 || dy + s.h < 0)
            return;
        const sc = this.scene.ctx, ec = this.emit.ctx;
        const wv = Math.sin(t * 1.6 + pr.x * 0.031 + pr.y * 0.017) + 0.4 * Math.sin(t * 3.7 + pr.x * 0.11);
        const o = Math.round(wv * 0.75);
        if (!o) {
            sc.drawImage(s.a, dx, dy);
            ec.drawImage(s.e, dx, dy);
            return;
        }
        const cut = Math.floor(s.h * 0.55);
        for (const [src, ctx] of [[s.a, sc], [s.e, ec]]) {
            ctx.drawImage(src, 0, 0, s.w, cut, dx + o, dy, s.w, cut);
            ctx.drawImage(src, 0, cut, s.w, s.h - cut, dx, dy + cut, s.w, s.h - cut);
        }
    }
    drawFlame(pr, big, camX, camY, time) {
        const ec = this.emit.ctx;
        const bx = Math.round(pr.x - camX), by = Math.round(pr.y - camY - 15 + ((0, props_1.propDef)(pr.kind).fire?.dy ?? 0));
        const t = time * 12 + pr.x;
        const cols = ["#ff5a10", "#ff9a30", "#ffd060", "#fff0b0"];
        const w = big ? 8 : 3;
        for (let i = 0; i < w; i++) {
            const hgt = Math.max(1, Math.round((big ? 7 : 4) * (1 - Math.abs(i - (w - 1) / 2) / w) + Math.sin(t + i * 1.7) * 1.5 + Math.sin(t * 1.7 + i) * 0.8));
            for (let j = 0; j < hgt; j++) {
                const k = Math.min(3, Math.floor((j / hgt) * 4));
                ec.fillStyle = cols[3 - k];
                if (j === hgt - 1)
                    ec.fillStyle = cols[0];
                ec.fillRect(bx - Math.floor(w / 2) + i, by - j + (big ? 2 : 0), 1, 1);
            }
        }
    }
    drawPedestal(p, pr, i, spr, camX, camY) {
        const s = (0, props_2.propSprite)("pedestal", 0, false);
        spr(s, pr.x, pr.y);
        const area = p.area, r = area.ritual, t = p.t;
        const g = r.sockets[i];
        const ec = this.emit.ctx;
        const topY = pr.y - 15;
        if (g >= 0) {
            spr((0, items_2.itemIcon)((0, items_1.glyphItem)(g)), pr.x, topY + 4);
            if (r.active) {
                const pen = new util_1.Pen(ec, true);
                (0, items_2.glyphPattern)(pen, g, Math.round(pr.x - camX) - 4, Math.round(topY - camY) - 7, glyphs_1.GLYPHS[g].color, true);
            }
            if (r.wrong[i] && p.fizzT > 0 && Math.sin(t * 30) > 0) {
                ec.fillStyle = "#ff2040";
                ec.globalAlpha = 0.6;
                ec.fillRect(Math.round(pr.x - camX) - 6, Math.round(topY - camY) - 8, 12, 12);
                ec.globalAlpha = 1;
            }
        }
        if ((0, world_1.hasFlag)(p.world, flags_1.FLAGS.knowSchematic) && g !== r.solution[i] && !r.active) {
            const pen = new util_1.Pen(ec, true);
            ec.globalAlpha = 0.35 + 0.2 * Math.sin(t * 3 + i);
            const bob = Math.round(Math.sin(t * 2 + i) * 1.5);
            (0, items_2.glyphPattern)(pen, r.solution[i], Math.round(pr.x - camX) - 3, Math.round(topY - camY) - 16 + bob - (g >= 0 ? 4 : 0), glyphs_1.GLYPHS[r.solution[i]].color, true);
            ec.globalAlpha = 1;
        }
        if (i === 0 && r.core) {
            const c = area.ritualPos;
            const bob = Math.round(Math.sin(t * 2) * 1.5) + (r.active ? -3 : 0);
            spr((0, items_2.itemIcon)("core"), c.x, c.y - 4 + bob);
        }
    }
    drawPlayer(p, px, py, camX, camY) {
        const pl = (0, world_1.player)(p.world), lk = p.look, sc = this.scene.ctx;
        sc.fillStyle = "rgba(0,0,0,0.45)";
        const sx = Math.round(px - camX), sy = Math.round(py - camY);
        const sw = Math.max(4, 8 - Math.round(lk.z / 3));
        sc.fillRect(sx - sw, sy - 1, sw * 2, 2);
        sc.fillRect(sx - sw + 2, sy - 2, sw * 2 - 4, 4);
        const a = pl.task;
        let raise = 0, reach = 0, slam, dip;
        if (a) {
            const k = a.t / a.dur;
            if (a.kind === "reach" || a.kind === "push" || a.kind === "dismantle")
                reach = Math.sin(Math.min(1, k) * Math.PI);
            if (a.kind === "smash")
                raise = a.t < 0.5 ? a.t / 0.5 : a.t < 0.62 ? (0, util_1.lerp)(1, -1, (a.t - 0.5) / 0.12) : (0, util_1.lerp)(-1, 0, (0, util_1.clamp)((a.t - 0.62) / 0.5, 0, 1));
            if (a.kind === "carve")
                reach = 0.4 + 0.6 * Math.abs(Math.sin(a.t * 14));
            if (a.kind === "craft")
                reach = 0.3 + 0.7 * Math.abs(Math.sin(a.t * 9));
            if (a.kind === "attach")
                reach = 0.3;
            if (a.kind === "punch") {
                const k2 = a.t / a.dur;
                raise = k2 < 0.35 ? k2 / 0.35 : k2 < 0.5 ? (0, util_1.lerp)(1, -1, (k2 - 0.35) / 0.15) : (0, util_1.lerp)(-1, 0, (0, util_1.clamp)((k2 - 0.5) / 0.4, 0, 1));
            }
            if (a.kind === "channel")
                reach = 0.2;
            if (a.kind === "slam")
                ({ lift: slam, dip } = (0, golem_1.slamPose)(k));
        }
        const pose = {
            facing: p.gaze ?? pl.facing, phase: pl.phase, moving: pl.moving && !a, hasArm: p.hasArm, dormant: lk.dormant,
            eye: (0, util_1.clamp)(lk.eye + p.eyeBoost + p.vision.k * 0.35, 0, 1.6), core: lk.core, raise, reach, t: p.t,
            eyeFixed: (0, world_1.hasFlag)(p.world, flags_1.FLAGS.golemEye), back: pl.gear.back, runes: (0, gear_1.runeMarks)(p.world, pl), slam, dip,
        };
        const ox = px - camX + (a?.kind === "push" ? Math.round(Math.sin(a.t * 40)) : 0), oy = py - camY - lk.z;
        (0, golem_1.drawGolem)(new util_1.Pen(sc, false), ox, oy, pose);
        (0, golem_1.drawGolem)(new util_1.Pen(this.emit.ctx, true), ox, oy, pose);
        this.selfPose = { pose, x: ox + camX, y: oy + camY };
    }
}
exports.WorldRenderer = WorldRenderer;
function buildShaft(cols) {
    const FOOT = 150, FADE = 0.55;
    return (0, util_1.makeSprite)(80, FOOT + 10, 40, FOOT, 1, (p) => {
        for (let y = 0; y < FOOT + 10; y++) {
            const t = y / FOOT;
            const cx = (0, util_1.lerp)(22, 40, t), hw = (0, util_1.lerp)(7, 24, t);
            const k = (0, util_1.clamp)(t / FADE, 0, 1), dens = k * k * (3 - 2 * k);
            for (let x = 0; x < 80; x++) {
                const d = Math.abs(x - cx) / hw;
                if (y > FOOT) {
                    const e = ((x - 40) / 26) ** 2 + ((y - FOOT - 2) / 7) ** 2;
                    if (e < 1 && (x + y) % 2 === 0)
                        p.g(x, y, 1, 1, cols[2]);
                    continue;
                }
                if (d < 1 && (x + y) % 2 === 0 && (0, util_1.hash2)(x, y, 2) > d * 0.8 && (0, util_1.hash2)(x, y, 5) < dens)
                    p.g(x, y, 1, 1, d < 0.5 ? cols[0] : cols[1]);
            }
        }
    });
}
