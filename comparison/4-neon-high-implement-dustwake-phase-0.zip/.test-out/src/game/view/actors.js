"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.actorActive = void 0;
exports.drawActor = drawActor;
exports.folkLantern = folkLantern;
exports.folkArtPose = folkArtPose;
// Shared actor drawing, by the ActorDef's art key: NPC_ART (guardian-shaped
// poses, npcArt.ts), BODY_ART (bodies with power and work, workerArt.ts: the
// worker golem), the golem painter, and the test-only human fixture. Every
// path draws an albedo and an emissive pass, here and when golem vision
// retraces actors each frame into its scratch canvas (view/vision.ts).
const actors_1 = require("../content/actors");
const golem_1 = require("../golem");
const npcArt_1 = require("../npcArt");
const workerArt_1 = require("../workerArt");
const workerAnim_1 = require("../workerAnim");
const util_1 = require("../util");
const actorStats_1 = require("../sim/actorStats");
const gear_1 = require("../sim/gear");
const folkArt_1 = require("../folkArt");
const folk_1 = require("../sim/folk");
const daycycle_1 = require("../content/daycycle");
const keeperArt_1 = require("../keeperArt");
const shops_1 = require("../sim/shops");
const QUARTER = { up: ["left", "right"], down: ["right", "left"], left: ["down", "up"], right: ["up", "down"] };
/** Working: powered, with a task in hand or an order running. Powered with neither is idle, and looks dormant. */
const actorActive = (a) => (0, actorStats_1.powered)(a) && (!!a.task || a.job?.status === "running");
exports.actorActive = actorActive;
function drawActor(sc, ec, w, a, camX, camY, t, look) {
    const d = (0, actors_1.actorDef)(a), x = Math.round(a.x - camX), y = Math.round(a.y - camY), hw = Math.round(d.body.box[0] / 2) + 2;
    if (d.art.key === "folk") {
        drawFolk(sc, ec, w, a, x, y, t);
        return;
    }
    if (d.art.key === "keeper") {
        drawKeeper(sc, ec, a, x, y, t);
        return;
    }
    sc.fillStyle = "rgba(0,0,0,0.45)";
    sc.fillRect(x - hw, y - 1, hw * 2, 2);
    sc.fillRect(x - hw + 3, y - 3, hw * 2 - 6, 4);
    const npcArt = npcArt_1.NPC_ART[d.art.key];
    if (npcArt) {
        const v = (0, util_1.clamp)(look.awake, 0, 1);
        const pose = { facing: a.facing, awake: v * v * (3 - 2 * v), eye: look.eye + look.flare, reach: (0, util_1.clamp)(look.reach, 0, 1), t };
        npcArt(new util_1.Pen(sc, false), x, y, pose);
        npcArt(new util_1.Pen(ec, true), x, y, pose);
        return;
    }
    const active = (0, exports.actorActive)(a);
    const task = a.task;
    const bodyArt = workerArt_1.BODY_ART[d.art.key];
    if (bodyArt) {
        // The sim says powered / working / has a core; the sequencer (stepped by the host) turns that into a posture.
        // Walking and task motion layer on top. A rune channel adds nothing: it stands, and the rune plays its own effect.
        const anim = (look.worker ?? (look.worker = (0, workerAnim_1.initWorkerAnim)({ powered: (0, actorStats_1.powered)(a), active, moving: a.moving, hasCore: !!a.powerCore })));
        const pose = (0, workerAnim_1.animPose)(anim, {
            facing: a.facing, phase: a.phase, moving: a.moving, t, hasCore: !!a.powerCore,
            task: task ? (0, workerAnim_1.taskMotion)(task.kind, task.t, task.dur) : undefined,
        });
        const lift = Math.round(look.lift ?? 0);
        bodyArt(new util_1.Pen(sc, false), x, y - lift, pose);
        bodyArt(new util_1.Pen(ec, true), x, y - lift, pose);
        return;
    }
    if (d.art.key === "golem") {
        const pose = {
            facing: a.facing, phase: a.phase, moving: a.moving, hasArm: a.upgrades.includes("golem.arm"),
            dormant: active ? 0 : 1, eye: active ? 1 : 0.1, core: (0, actorStats_1.powered)(a) ? 0.8 : 0,
            raise: task?.kind === "punch" ? Math.sin(task.t / task.dur * Math.PI * 2) : 0,
            reach: task ? Math.abs(Math.sin(task.t * 8)) : 0, t, back: a.gear.back, runes: (0, gear_1.runeMarks)(w, a),
        };
        (0, golem_1.drawGolem)(new util_1.Pen(sc, false), x, y, pose);
        (0, golem_1.drawGolem)(new util_1.Pen(ec, true), x, y, pose);
        return;
    }
    for (const emit of [false, true])
        drawFixtureHuman(new util_1.Pen(emit ? ec : sc, emit), x, y, a);
}
/**
 * Test fixture only (the `npc_worker` row, art key "human"): intentionally
 * plain. No builder spawns one, no NPCS row names it and no migration creates
 * one (tests/rollout.test.ts), so no production path can show it.
 */
function drawFixtureHuman(p, x, y, a) {
    const stride = a.moving ? Math.round(Math.sin(a.phase) * 2) : 0;
    p.ox = x;
    p.oy = y;
    p.o(-4, -20, 8, 7, "#b79b7d");
    p.o(-5, -13, 10, 9, "#63796a");
    p.r(-4 + stride, -4, 3, 4, "#594a41");
    p.r(1 - stride, -4, 3, 4, "#594a41");
}
/** The watch carries a lit lantern on its rounds after dark. */
function folkLantern(w, a) {
    if (!a.person || !a.life || (0, folk_1.archetypeOf)(a).garb !== "watch")
        return false;
    const h = (0, daycycle_1.hourOf)(w.day), dark = h < 5.6 || h > 19.8;
    return dark && (a.life.act === "patrol" || a.life.act === "post" || a.life.act === "lamps") && a.area === a.person.origin;
}
/** The pose a townsperson is drawn in this frame: the sim's posture plus presentation timing (step, motion, blink). */
function folkArtPose(w, a, t) {
    const L = a.life, off = (0, daycycle_1.hash01)(a.id, 3) * 10;
    const rate = folkArt_1.POSE_RATE[L.pose] ?? 0;
    let frame = L.pose === "walk" ? Math.floor(L.phase) % 4 : rate ? Math.floor(t * rate + off) % 2 : 0;
    if (L.pose === "drink")
        frame = (t + off) % 5 < 1.3 ? 1 : 0;
    return {
        // a shake of the head is the head turning a quarter turn each way in turn
        facing: a.facing, head: L.pose === "shake" ? QUARTER[a.facing][frame & 1] : (0, folk_1.naturalHead)(a.facing, L.head), pose: L.pose, frame, carry: L.carry,
        lantern: folkLantern(w, a), pole: L.act === "lamps", blink: L.pose !== "lie" && (t + off) % 3.9 < 0.13,
    };
}
/** A shopkeeper (keeperArt.ts: a placeholder box until textured): a soft shadow, then the shop's painter into both passes. Out of hours, nothing. */
function drawKeeper(sc, ec, a, x, y, t) {
    if (!a.keeper || !(0, shops_1.keeperPresent)(a))
        return;
    sc.fillStyle = "rgba(0,0,0,0.32)";
    sc.fillRect(x - 6, y - 1, 12, 2);
    sc.fillRect(x - 4, y - 2, 8, 4);
    const paint = (0, keeperArt_1.keeperPainter)(a.keeper.shop), pose = { facing: a.facing, state: a.keeper.state, moving: a.moving, phase: a.phase, t };
    paint(new util_1.Pen(sc, false), x, y, pose);
    paint(new util_1.Pen(ec, true), x, y, pose);
}
/** A townsperson (folkArt.ts): a soft shadow, then the cached sprite into both passes. Indoors, nothing. */
function drawFolk(sc, ec, w, a, x, y, t) {
    if (!a.person || !a.life || !(0, folk_1.folkPresent)(a))
        return;
    const pose = folkArtPose(w, a, t), arch = (0, folk_1.archetypeOf)(a);
    if (pose.pose !== "lie") {
        sc.fillStyle = "rgba(0,0,0,0.32)";
        sc.fillRect(x - 5, y - 1, 11, 2);
        sc.fillRect(x - 3, y - 2, 7, 4);
    }
    const s = (0, folkArt_1.folkSprite)(arch.garb, arch.age, a.person.look, pose);
    sc.drawImage(s.a, x - s.ax, y - s.ay);
    ec.drawImage(s.e, x - s.ax, y - s.ay);
}
