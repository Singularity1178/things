"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleNearbyEvent = handleNearbyEvent;
exports.handlePlayerEvent = handlePlayerEvent;
// Event-reaction layer (extracted from game.ts in Phase 0.6).
// Translates World SimEvents into audio, particles, shakes, bubbles, UI
// transitions, and NotificationFeed alerts (including pause-on-alert).
const items_1 = require("../content/items");
const flags_1 = require("../content/flags");
const tasks_1 = require("../content/tasks");
const crafting_1 = require("../content/crafting");
const items_2 = require("../art/items");
const power_1 = require("../sim/power");
const portals_1 = require("../sim/portals");
const dialogue_1 = require("../sim/dialogue");
const folk_1 = require("../sim/folk");
const shops_1 = require("../sim/shops");
const monologue_1 = require("../sim/monologue");
const world_1 = require("../world/world");
const zoom_1 = require("./zoom");
const FOLK_EARSHOT = 170;
const FOLK_MAX_LINES = 3;
/** Another actor in the player's area did something: world-space feedback only. */
function handleNearbyEvent(h, e) {
    const ps = h.particles;
    if (e.t === "step") {
        const a = (0, world_1.actorById)(h.world, e.actor);
        if (a)
            for (let i = 0; i < 2; i++)
                ps.spawn({ x: a.x + (Math.random() - 0.5) * 8, y: a.y, z: 1, vx: (Math.random() - 0.5) * 12, vz: 6, life: 0.5, kind: "dust", col: "#8a8478", g: 20 });
    }
    else if (e.t === "harvestHit") {
        if (e.kind === "tree" || e.kind === "log")
            h.sfx.thud();
        else
            h.sfx.clink();
        for (let i = 0; i < (e.depleted ? 14 : 6); i++)
            ps.spawn({ x: e.x + (Math.random() - 0.5) * 10, y: e.y, z: 6 + Math.random() * 8, vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.5) * 14, vz: 10 + Math.random() * 20, life: 0.8, kind: "debris", col: e.kind === "rock" ? "#6a6372" : "#6a5034", g: 120 });
    }
    else if (e.t === "cue") {
        if (e.cue === "clank")
            h.sfx.clank();
        else if (e.cue === "scrape")
            h.sfx.scrape();
        else if (e.cue === "dud" || e.cue === "runeDud")
            h.sfx.fizzle();
        else if (e.cue === "scrapeDust") {
            h.sfx.scrape();
            for (let i = 0; i < 4; i++)
                ps.spawn({ x: e.x, y: e.y, z: 2, vx: (Math.random() - 0.5) * 20, vz: 8, life: 0.8, kind: "dust", col: "#9a96a0", g: 20 });
        }
        else if (e.cue === "push") {
            h.sfx.thud();
            for (let i = 0; i < 6; i++)
                ps.spawn({ x: e.x + (Math.random() - 0.5) * 16, y: e.y + 2, z: 20 + Math.random() * 10, vx: (Math.random() - 0.5) * 10, life: 1.5, kind: "debris", col: "#6a6372", g: 80 });
        }
    }
    else if (e.t === "jobChanged" && (e.status === "paused" || e.status === "blocked")) {
        const a = (0, world_1.actorById)(h.world, e.actor);
        const label = a?.name ?? e.actor;
        h.notify({
            title: `Worker paused: ${label}`,
            detail: e.reason ? `Reason: ${e.reason}` : "A worker cannot continue its order.",
            severity: "warn",
            category: "worker",
            worldTime: h.world.time,
            area: a?.area,
            x: a?.x,
            y: a?.y,
        });
    }
}
/** Sound, particles, UI reactions, and notifications to the player's (and world) events. */
function handlePlayerEvent(h, e) {
    const pl = h.pl;
    const ps = h.particles;
    switch (e.t) {
        case "itemGained": {
            const n = e.n ?? 1;
            h.toast = { icon: (0, items_2.itemIcon)(e.item), name: items_1.ITEM_NAMES[e.item] + (n > 1 ? ` x${n}` : ""), t: 0 };
            h.sfx.pickup();
            if (e.stored)
                for (let i = 0; i < 10; i++)
                    ps.spawn({ x: pl.x, y: pl.y - 4, z: 14, vx: (Math.random() - 0.5) * 30, vy: (Math.random() - 0.5) * 20, vz: 20 + Math.random() * 20, life: 0.6, kind: "glint", col: "#fff0c0", emit: true, g: 40 });
            const def = items_1.ITEMS[e.item], id = e.item;
            if (def.opensOnPickup)
                h.later(0.5, () => { if (h.isPlayScreen())
                    def.opens === "book" ? h.openBook(id) : h.openSchematic(); });
            break;
        }
        case "itemDropped":
            h.sfx.thud();
            for (let i = 0; i < 6; i++)
                ps.spawn({ x: e.x + (Math.random() - 0.5) * 8, y: e.y, z: 2, vx: (Math.random() - 0.5) * 14, vz: 8, life: 0.6, kind: "dust", col: "#8a8478", g: 20 });
            if (e.reason !== "drop")
                h.say(e.reason === "full" ? "PACK FULL - LEFT ON THE GROUND" : "NO ROOM - DROPPED ON THE GROUND");
            break;
        case "packFull":
            h.say("YOUR PACK IS FULL");
            h.sfx.tone(180, 0.1, "square", 0.04);
            h.notify({ title: "Pack Full", detail: `Could not pick up ${items_1.ITEM_NAMES[e.item]}.`, severity: "warn", category: "world", worldTime: h.world.time, area: pl.area, x: pl.x, y: pl.y });
            break;
        case "message":
            h.say(e.text);
            break;
        case "folkSpoke": {
            const a = (0, world_1.actorById)(h.world, e.folk);
            const label = a?.person ? (0, folk_1.folkLabel)(a) : a?.keeper ? (0, shops_1.keeperLabel)(a) : null;
            if (a && label) {
                h.bubbles.set(a.id, { text: e.line, t: 0, dur: 2.4 + e.line.length * 0.055 });
                h.say(label);
                h.sfx.tone(520, 0.05, "triangle", 0.03);
            }
            break;
        }
        case "folkSay": {
            const a = (0, world_1.actorById)(h.world, e.folk);
            if (!a || a.area !== h.pl.area)
                break;
            const cur = h.bubbles.get(a.id);
            if (cur?.text && !cur.talk)
                break;
            const near = Math.hypot(a.x - h.pl.x, a.y - h.pl.y) < FOLK_EARSHOT;
            const partner = e.to ? h.bubbles.get(e.to) : undefined;
            let others = 0;
            for (const [id, b] of h.bubbles)
                if (b.text && id !== a.id && id !== e.to && b.t < b.dur - 0.3)
                    others++;
            if (!near || (others >= FOLK_MAX_LINES && !partner?.talk && !cur?.talk))
                break;
            if (partner?.talk && e.to)
                h.bubbles.delete(e.to);
            h.bubbles.set(a.id, { text: e.line, t: 0, dur: (0, folk_1.sayTime)(e.line), talk: true });
            break;
        }
        case "folkChat": {
            const a = (0, world_1.actorById)(h.world, e.folk);
            if (a && a.area === h.pl.area && !h.bubbles.get(a.id)?.text)
                h.bubbles.set(a.id, { icon: e.icon, t: 0, dur: 1.5 });
            break;
        }
        case "analyzed":
            if (h.lastAnalyzed.prop !== e.prop || h.t - h.lastAnalyzed.t > 0.2)
                h.sfx.analyzed();
            h.lastAnalyzed = { prop: e.prop, t: h.t };
            break;
        case "learned": {
            h.sfx.insight();
            h.eyeBoost = 1.5;
            const txt = (0, flags_1.learnedText)(e.flag);
            h.say(txt);
            h.notify({ title: "Discovery", detail: txt, severity: "success", category: "world", worldTime: h.world.time, area: pl.area, x: pl.x, y: pl.y });
            break;
        }
        case "thought":
            h.pushThought(e.line);
            break;
        case "harvestHit": {
            const tree = e.kind === "tree" || e.kind === "log";
            if (tree)
                h.sfx.thud();
            else
                h.sfx.clink();
            h.shake(e.depleted ? 0.35 : 0.12, e.depleted ? 2 : 1);
            if (e.depleted && !tree)
                h.sfx.smash();
            const cols = tree ? ["#5b3d24", "#7a5634", "#3e6a30", "#5a8a40"] : ["#8a8392", "#6a6372", "#4b4552"];
            for (let i = 0; i < (e.depleted ? 26 : 10); i++)
                ps.spawn({ x: e.x + (Math.random() - 0.5) * 12, y: e.y, z: tree && i % 2 ? 20 + Math.random() * 14 : 6 + Math.random() * 6, vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.5) * 20, vz: 10 + Math.random() * 30, life: 1 + Math.random(), kind: "debris", col: cols[(Math.random() * cols.length) | 0], g: tree && i % 2 ? 30 : 120 });
            break;
        }
        case "deconstructed":
            h.sfx.clink();
            h.sfx.noise(0.2, 0.1, "bandpass", 900, 2);
            for (let i = 0; i < 12; i++)
                ps.spawn({ x: e.x + (Math.random() - 0.5) * 10, y: e.y, z: e.kind === "torch" || e.kind === "banner" ? 10 : 4, vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.5) * 16, vz: 10 + Math.random() * 20, life: 0.7, kind: "debris", col: Math.random() < 0.5 ? "#7a5634" : "#6a6372", g: 120 });
            break;
        case "openStation":
            if (e.actor === h.world.playerId && h.isPlayScreen() && (0, crafting_1.isStation)(e.station))
                h.openStation(e.station, e.prop);
            break;
        case "dug": {
            const stone = e.material === "stone";
            if (stone)
                h.sfx.clink();
            else
                h.sfx.thud();
            h.shake(e.opened ? 0.6 : 0.12, e.opened ? 3 : 1);
            const cols = stone ? ["#8a8392", "#6a6372", "#4b4552"] : ["#4e3c2a", "#5a4630", "#3e2e20"];
            for (let i = 0; i < (e.opened ? 32 : 12); i++)
                ps.spawn({ x: e.x + (Math.random() - 0.5) * 30, y: e.y + (Math.random() - 0.5) * 20, z: 2 + Math.random() * 6, vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.5) * 20, vz: 14 + Math.random() * 30, life: 0.8 + Math.random() * 0.6, kind: "debris", col: cols[(Math.random() * cols.length) | 0], g: 120 });
            if (e.actor !== h.world.playerId)
                break;
            if (e.opened) {
                h.sfx.smash();
                h.say("THE VAULT GIVES WAY. THE OLD STAIR IS OPEN: WALK DOWN INTO IT FROM ITS SOUTH END");
                h.notify({ title: "Entrance Opened", detail: "The stair between surface and halls is clear.", severity: "success", category: "world", worldTime: h.world.time, area: pl.area, x: e.x, y: e.y });
            }
            else if (e.next === "stone")
                h.say("THE EARTH IS OUT. FALLEN STONE LIES UNDER IT: THAT NEEDS A PICKAXE HEAD");
            break;
        }
        case "openStorage":
            if (e.actor === h.world.playerId && h.isPlayScreen())
                h.openStorage(e.prop);
            break;
        case "manageActor":
            if (e.actor === h.world.playerId && h.isPlayScreen() && (0, world_1.actorById)(h.world, e.target))
                h.openManage(e.target);
            break;
        case "coreSlotted": {
            const a = (0, world_1.actorById)(h.world, e.target);
            if (!a)
                break;
            const L = h.npcLook(a), name = items_1.ITEM_NAMES[e.item];
            if (e.inserted) {
                h.sfx.coreIn(e.powered);
                if (e.powered)
                    L.flare = 1;
                ps.coreSparks(a, e.powered ? 6 : 5, e.powered);
                h.say(e.powered ? `${name} SLOTTED - IT POWERS ON` : `${name} SLOTTED`);
            }
            else {
                const ran = (0, power_1.coreCheck)(a, e.item).sufficient;
                h.sfx.coreOut(ran);
                L.flare = 0;
                for (let i = 0; i < 6; i++)
                    ps.spawn({ x: a.x + (Math.random() - 0.5) * 10, y: a.y, z: 6 + Math.random() * 6, vx: (Math.random() - 0.5) * 14, vz: 4 + Math.random() * 6, life: 0.8, kind: "dust", col: "#8a8478", g: 10 });
                h.say(ran ? `${name} TAKEN OUT - IT POWERS DOWN` : `${name} TAKEN OUT`);
            }
            break;
        }
        case "built":
            h.sfx.place();
            h.sfx.tone(520, 0.2, "triangle", 0.05);
            for (let i = 0; i < 10; i++)
                ps.spawn({ x: e.x, y: e.y - 14, z: 2, vx: (Math.random() - 0.5) * 30, vz: 10 + Math.random() * 20, life: 0.6, kind: "spark", col: "#ffb040", emit: true, g: 80 });
            break;
        case "runeAwakened":
        case "travelled":
            h.tele.travelled = true;
            break;
        case "step":
            h.sfx.step(e.heavy);
            for (let i = 0; i < (e.heavy ? 4 : 2); i++)
                ps.spawn({ x: pl.x + (Math.random() - 0.5) * 10, y: pl.y, z: 1, vx: (Math.random() - 0.5) * 16, vy: (Math.random() - 0.5) * 6, vz: 8, life: 0.6, kind: "dust", col: "#8a8478", g: 20 });
            if (!e.heavy && !h.hasArm)
                h.sfx.scrape();
            break;
        case "taskTick": {
            const a = e.task;
            if (a.kind === "attach") {
                if (Math.random() < 0.5)
                    ps.sparkBurst(pl, h.look.dormant, 2);
            }
            else if (a.kind === "slam") {
                const k0 = (a.t - e.dt) / a.dur, k1 = a.t / a.dur, down = tasks_1.SLAM_HIT * 0.88;
                if (k0 <= 0.02 && k1 > 0.02)
                    h.sfx.slamWindup();
                if (k0 < down && k1 >= down)
                    h.sfx.slamSwing();
                if (!h.hasArm && k1 < tasks_1.SLAM_HIT && Math.random() < 0.12)
                    ps.sparkBurst(pl, h.look.dormant, 1);
            }
            else if (a.kind === "dismantle" && a.target) {
                if (Math.floor(a.t / 0.3) !== Math.floor((a.t - e.dt) / 0.3))
                    h.sfx.clink();
                if (Math.random() < 0.3)
                    ps.spawn({ x: a.target.x + (Math.random() - 0.5) * 10, y: a.target.y, z: 4 + Math.random() * 8, vx: (Math.random() - 0.5) * 20, vz: 8, life: 0.5, kind: "dust", col: "#8a8478", g: 30 });
            }
            else if (a.kind === "scan" && e.actor === pl.id) {
                const fire = a.dur * 0.85, k0 = (a.t - e.dt) / fire, k1 = a.t / fire;
                if (k0 <= 0 && k1 > 0)
                    h.sfx.scanStart();
                if (k1 < 1 && Math.floor(k1 * 9) !== Math.floor(k0 * 9))
                    h.sfx.scanTick(k1);
            }
            else if (a.kind === "craft") {
                if (Math.floor(a.t / 0.25) !== Math.floor((a.t - e.dt) / 0.25)) {
                    h.sfx.clink();
                    if (a.target)
                        for (let i = 0; i < 2; i++)
                            ps.spawn({ x: a.target.x + (Math.random() - 0.5) * 14, y: a.target.y - 6, z: 8, vx: (Math.random() - 0.5) * 30, vz: 12 + Math.random() * 14, life: 0.4, kind: "spark", col: "#e8d8a0", emit: true, g: 120 });
                }
            }
            else if (a.kind === "carve") {
                const c = h.area.ritualPos;
                const k = Math.floor(a.t / 0.22), kp = Math.floor((a.t - e.dt) / 0.22);
                if (k !== kp && a.t < a.dur - 0.3) {
                    h.sfx.clink();
                    const ang = 0.26 + Math.random() * 1.05, r = 44 + Math.random() * 13;
                    for (let i = 0; i < 4; i++)
                        ps.spawn({ x: c.x + Math.cos(ang) * r, y: c.y + Math.sin(ang) * r, z: 1, vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.5) * 30, vz: 20 + Math.random() * 20, life: 0.4, kind: "spark", col: "#d0c0ff", emit: true, g: 120 });
                    ps.spawn({ x: c.x + Math.cos(ang) * r, y: c.y + Math.sin(ang) * r, z: 1, vz: 6, life: 1, kind: "dust", col: "#8a8690", g: 4 });
                }
            }
            break;
        }
        case "cue":
            if (e.cue === "clank") {
                h.sfx.clank();
                h.shake(0.1, 1);
            }
            else if (e.cue === "scrape")
                h.sfx.scrape();
            else if (e.cue === "dud") {
                h.sfx.fizzle();
                h.fizzT = 0.5;
            }
            else if (e.cue === "runeDud")
                h.runeRefused(e.x, e.y);
            else if (e.cue === "scrapeDust") {
                h.sfx.scrape();
                for (let i = 0; i < 4; i++)
                    ps.spawn({ x: e.x, y: e.y, z: 2, vx: (Math.random() - 0.5) * 20, vz: 8, life: 0.8, kind: "dust", col: "#9a96a0", g: 20 });
            }
            else if (e.cue === "push") {
                h.sfx.thud();
                h.shake(0.2, 1);
                for (let i = 0; i < 6; i++)
                    ps.spawn({ x: e.x + (Math.random() - 0.5) * 16, y: e.y + 2, z: 20 + Math.random() * 10, vx: (Math.random() - 0.5) * 10, life: 1.5, kind: "debris", col: "#6a6372", g: 80 });
                h.crackFlash = 1;
            }
            break;
        case "equipped":
            h.sfx.clank();
            h.shake(0.15, 1);
            ps.sparkBurst(pl, h.look.dormant, 14);
            break;
        case "gearOn":
        case "gearOff":
            if (e.actor !== h.world.playerId)
                break;
            if (items_1.ITEMS[e.item].worn)
                h.sfx.tone(e.t === "gearOn" ? 700 : 420, 0.14, "triangle", 0.05);
            else if (e.t === "gearOn")
                h.sfx.strap();
            else
                h.sfx.unstrap();
            h.say(e.t === "gearOn" ? (e.slot === "back" ? `${items_1.ITEM_NAMES[e.item]} ON YOUR BACK` : `${items_1.ITEM_NAMES[e.item]} EQUIPPED`) : `${items_1.ITEM_NAMES[e.item]} TAKEN OFF`);
            break;
        case "crafted":
            if (e.actor === h.world.playerId) {
                h.sfx.place();
                h.say(`MADE ${e.n} ${items_1.ITEM_NAMES[e.item]}`);
            }
            break;
        case "containerOpened":
            h.sfx.open();
            for (let i = 0; i < 8; i++)
                ps.spawn({ x: e.x + (Math.random() - 0.5) * 12, y: e.y, z: 6, vx: (Math.random() - 0.5) * 20, vz: 10, life: 1, kind: "dust", col: "#7a7468", g: 10 });
            break;
        case "doorUnlocked":
            h.sfx.unlock();
            break;
        case "wallBroken": {
            h.sfx.smash();
            h.shake(0.7, 3.5);
            const cx = e.x, cy = e.y;
            for (let i = 0; i < 40; i++)
                ps.spawn({ x: cx + (Math.random() - 0.5) * 16, y: cy + (Math.random() - 0.5) * 20, z: 4 + Math.random() * 18, vx: (Math.random() - 0.5) * 120, vy: (Math.random() - 0.5) * 60, vz: 20 + Math.random() * 60, life: 1.6 + Math.random(), kind: "debris", col: ["#8a8392", "#6a6372", "#4b4552"][(Math.random() * 3) | 0], g: 160, size: Math.random() < 0.4 ? 2 : 1 });
            for (let i = 0; i < 40; i++)
                ps.spawn({ x: cx + (Math.random() - 0.5) * 24, y: cy + (Math.random() - 0.5) * 24, z: Math.random() * 20, vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.5) * 30, vz: Math.random() * 10, life: 2 + Math.random() * 2, kind: "smoke", col: "#7a7470", g: -2, size: 2 });
            break;
        }
        case "slam": {
            h.sfx.slam();
            h.shake(0.18, 1.2);
            for (let i = 0; i < 16; i++) {
                const ang = Math.random() * Math.PI * 2, v = 14 + Math.random() * 24;
                ps.spawn({ x: e.x + Math.cos(ang) * 3, y: e.y + Math.sin(ang) * 2, z: 1, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v * 0.5, vz: 6 + Math.random() * 10, life: 0.6 + Math.random() * 0.5, kind: "dust", col: Math.random() < 0.5 ? "#8a8478" : "#a09a8c", g: 20 });
            }
            if (!h.hasArm)
                ps.sparkBurst(pl, h.look.dormant, 5);
            break;
        }
        case "withstood": {
            h.sfx.impact();
            h.shake(0.3, 2);
            h.crackFlash = 1;
            if (e.tx !== undefined && e.ty !== undefined)
                h.shudder = { tx: e.tx, ty: e.ty, t: 0.45 };
            for (let i = 0; i < 14; i++)
                ps.spawn({ x: e.x + (Math.random() - 0.5) * 16, y: e.y + 2, z: 4 + Math.random() * 20, vx: (Math.random() - 0.5) * 60, vy: Math.random() * 24, vz: 10 + Math.random() * 30, life: 0.9 + Math.random() * 0.6, kind: "debris", col: ["#8a8392", "#6a6372", "#4b4552"][(Math.random() * 3) | 0], g: 140 });
            for (let i = 0; i < 16; i++)
                ps.spawn({ x: e.x + (Math.random() - 0.5) * 20, y: e.y + 3, z: Math.random() * 14, vx: (Math.random() - 0.5) * 24, vy: Math.random() * 10, vz: 2 + Math.random() * 6, life: 1 + Math.random(), kind: "dust", col: "#8a8478", g: 6, size: Math.random() < 0.4 ? 2 : 1 });
            break;
        }
        case "corePlaced":
            h.sfx.place();
            h.sfx.tone(660, 1, "sine", 0.06);
            break;
        case "carved":
            h.sfx.tone(392, 1.2, "sine", 0.07);
            break;
        case "glyphPlaced":
            h.sfx.place();
            break;
        case "runeActivated":
            h.sfx.activate();
            h.shake(1.5, 1.5);
            break;
        case "runeFizzled": {
            h.fizzT = 1.2;
            h.sfx.fizzle();
            h.shake(0.4, 2);
            const c = h.area.ritualPos;
            for (let i = 0; i < 40; i++) {
                const a = Math.random() * Math.PI * 2, rr = 44 + Math.random() * 13;
                ps.spawn({ x: c.x + Math.cos(a) * rr, y: c.y + Math.sin(a) * rr, z: 1, vx: (Math.random() - 0.5) * 60, vy: (Math.random() - 0.5) * 40, vz: 30 + Math.random() * 30, life: 0.5, kind: "spark", col: Math.random() < 0.5 ? "#ff6a8a" : "#a070ff", emit: true, g: 120 });
            }
            break;
        }
        case "runeDeactivated":
            h.sfx.setHum(0);
            break;
        case "teleport":
            h.tele.x = e.x;
            h.tele.y = e.y;
            h.tele.dur = pl.task?.dur ?? 4.6;
            h.tele.first = e.first;
            h.tele.travelled = false;
            h.beginTeleport(e.first);
            h.sfx.teleport();
            if (e.first)
                (0, monologue_1.playerThinks)(h.world, "cross.engage");
            break;
        case "areaEntered": break;
        case "dayPhase":
            h.onDayPhase(e.phase);
            break;
        case "portal": {
            const dest = h.world.areas.get(e.toArea), out = dest && (0, portals_1.portalById)(dest, e.to);
            h.doorFade = 1;
            ps.clear();
            if (out?.door)
                h.sfx.open();
            else
                h.sfx.step(true);
            if (out?.label)
                h.say(out.label);
            break;
        }
        case "dialogue":
            if (h.isPlayScreen())
                h.openDialogue(e.npc, e.script, e.segment);
            break;
        case "npcState": {
            const a = (0, dialogue_1.npcActor)(h.world, e.npc);
            if (!a)
                break;
            const L = h.npcLook(a);
            if (e.awake) {
                L.wakeT = 0;
                h.sfx.wakeSputter();
                ps.npcSparks(a, 10);
                h.later(0.5, () => ps.npcSparks(a, 6));
            }
            else {
                L.sleepT = 0;
                h.sfx.powerDown();
                h.later(1.1, () => { h.shake(0.2, 1); ps.npcDust(a); });
            }
            break;
        }
        case "eyeRepaired": {
            const lk = h.look;
            lk.sputter = 0;
            lk.eye = 1;
            h.eyeBoost = 2.2;
            h.sfx.eyeRepair();
            h.shake(0.25, 1);
            ps.sparkBurst(pl, lk.dormant, 10);
            for (let i = 0; i < 24; i++)
                ps.spawn({ x: pl.x + (Math.random() - 0.5) * 4, y: pl.y, z: 18, vx: (Math.random() - 0.5) * 60, vy: (Math.random() - 0.5) * 24, vz: 10 + Math.random() * 40, life: 0.4 + Math.random() * 0.5, kind: "spark", col: Math.random() < 0.5 ? "#bff4ff" : "#7fe8ff", emit: true, g: 110 });
            const by = e.by ? (0, dialogue_1.npcActor)(h.world, e.by) : undefined;
            if (by)
                h.npcLook(by).reach = 1.8;
            h.later(0.5, () => h.zoomTo(zoom_1.ZOOM_DEFAULT, 1.1));
            h.markDialogueZoomHint();
            break;
        }
    }
}
