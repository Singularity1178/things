"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveStore = exports.SaveStore = exports.IndexedDbBackend = exports.MemorySaveBackend = exports.MAX_BACKUPS = exports.DEFAULT_SLOTS = void 0;
exports.checksumStr = checksumStr;
exports.downloadSaveFile = downloadSaveFile;
// Save System v2 (Phase 0.4): IndexedDB multi-slot persistence, rolling
// backups, autosave, file export/import, integrity checksums, and automatic
// corrupted-save recovery.
//
// In the browser, uses IndexedDB (`dustwake-saves-v2`) with graceful fallback
// to an in-memory / injected backend for headless tests.
const save_1 = require("../world/save");
const world_1 = require("../world/world");
exports.DEFAULT_SLOTS = ["autosave", "slot-1", "slot-2", "slot-3"];
exports.MAX_BACKUPS = 3;
/** Fast deterministic FNV-1a 32-bit checksum for save integrity verification. */
function checksumStr(s) {
    let h = 2166136261;
    for (let i = 0; i < s.length; i++) {
        h ^= s.charCodeAt(i);
        h = Math.imul(h, 16777619);
    }
    return h >>> 0;
}
/** In-memory backend (used by headless tests and as a fallback when IndexedDB is unavailable). */
class MemorySaveBackend {
    constructor() {
        Object.defineProperty(this, "data", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
    }
    async get(key) { return this.data.get(key) ?? null; }
    async set(key, value) { this.data.set(key, value); }
    async del(key) { this.data.delete(key); }
    async keys() { return [...this.data.keys()]; }
}
exports.MemorySaveBackend = MemorySaveBackend;
/** IndexedDB backend for browser persistence (`dustwake-saves-v2`). */
class IndexedDbBackend {
    constructor(dbName = "dustwake-saves-v2", storeName = "saves") {
        Object.defineProperty(this, "dbName", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: dbName
        });
        Object.defineProperty(this, "storeName", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: storeName
        });
        Object.defineProperty(this, "dbPromise", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
    }
    open() {
        if (this.dbPromise)
            return this.dbPromise;
        this.dbPromise = new Promise((resolve, reject) => {
            if (typeof indexedDB === "undefined") {
                reject(new Error("IndexedDB not available"));
                return;
            }
            const req = indexedDB.open(this.dbName, 1);
            req.onupgradeneeded = () => {
                const db = req.result;
                if (!db.objectStoreNames.contains(this.storeName)) {
                    db.createObjectStore(this.storeName);
                }
            };
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error ?? new Error("IndexedDB open failed"));
        });
        return this.dbPromise;
    }
    async get(key) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readonly");
            const req = tx.objectStore(this.storeName).get(key);
            req.onsuccess = () => resolve(typeof req.result === "string" ? req.result : null);
            req.onerror = () => reject(req.error);
        });
    }
    async set(key, value) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readwrite");
            tx.objectStore(this.storeName).put(value, key);
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error);
        });
    }
    async del(key) {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readwrite");
            tx.objectStore(this.storeName).delete(key);
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error);
        });
    }
    async keys() {
        const db = await this.open();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(this.storeName, "readonly");
            const req = tx.objectStore(this.storeName).getAllKeys();
            req.onsuccess = () => resolve(req.result.map(String));
            req.onerror = () => reject(req.error);
        });
    }
}
exports.IndexedDbBackend = IndexedDbBackend;
const slotKey = (id) => `slot:${id}`;
const backupKey = (id, n) => `bak:${id}:${n}`;
class SaveStore {
    constructor(backend) {
        Object.defineProperty(this, "backend", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "fallback", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new MemorySaveBackend()
        });
        Object.defineProperty(this, "useFallback", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        this.backend = backend ?? (typeof indexedDB !== "undefined" ? new IndexedDbBackend() : this.fallback);
    }
    async run(fn) {
        if (this.useFallback)
            return fn(this.fallback);
        try {
            return await fn(this.backend);
        }
        catch {
            this.useFallback = true;
            return fn(this.fallback);
        }
    }
    /** Save `world` into slot `id`, rotating up to `MAX_BACKUPS` rolling backups of the previous save. */
    async saveSlot(id, world, name) {
        const saveData = (0, save_1.serialize)(world);
        const payload = JSON.stringify(saveData);
        const pl = (0, world_1.player)(world);
        const savedAt = Date.now();
        const label = name ?? (id === "autosave" ? "Autosave" : id.replace(/^slot-/, "Slot "));
        const meta = {
            id,
            name: label,
            savedAt,
            day: Math.floor(world.day) + 1,
            playTime: world.playTime,
            area: pl?.area ?? "dungeon",
            actors: world.actors.length,
            version: saveData.version,
            sizeBytes: payload.length,
        };
        const env = {
            id,
            name: label,
            savedAt,
            checksum: checksumStr(payload),
            payload,
            meta,
        };
        // Rotate existing backups: bak(N-1) -> bak(N), current -> bak(1)
        const existing = await this.run((b) => b.get(slotKey(id)));
        if (existing) {
            for (let i = exports.MAX_BACKUPS; i >= 2; i--) {
                const prev = await this.run((b) => b.get(backupKey(id, i - 1)));
                if (prev)
                    await this.run((b) => b.set(backupKey(id, i), prev));
            }
            await this.run((b) => b.set(backupKey(id, 1), existing));
        }
        await this.run((b) => b.set(slotKey(id), JSON.stringify(env)));
        const backups = await this.countBackups(id);
        return { ...meta, backupCount: backups };
    }
    /** Parse and verify a raw stored envelope string, returning the settled World + meta or null on corruption. */
    parseEnvelope(raw) {
        try {
            const env = JSON.parse(raw);
            if (!env || typeof env.payload !== "string" || typeof env.checksum !== "number")
                return null;
            if (checksumStr(env.payload) !== env.checksum)
                return null;
            const parsed = JSON.parse(env.payload);
            const valid = (0, save_1.validateSave)(parsed);
            if (!valid.ok)
                return null;
            const world = (0, save_1.settle)((0, save_1.deserialize)(parsed));
            const meta = {
                ...(env.meta ?? {
                    id: env.id ?? "unknown",
                    name: env.name ?? "Save",
                    savedAt: env.savedAt ?? 0,
                    day: Math.floor(world.day) + 1,
                    playTime: world.playTime,
                    area: (0, world_1.player)(world)?.area ?? "dungeon",
                    actors: world.actors.length,
                    version: valid.data.version,
                    sizeBytes: env.payload.length,
                }),
            };
            return { world, meta, save: valid.data };
        }
        catch {
            return null;
        }
    }
    /**
     * Load slot `id`. If the primary entry is corrupted (bad JSON, checksum mismatch,
     * or invalid save schema), automatically recovers from the newest valid rolling backup.
     */
    async loadSlot(id) {
        const primary = await this.run((b) => b.get(slotKey(id)));
        if (primary) {
            const ok = this.parseEnvelope(primary);
            if (ok) {
                ok.meta.backupCount = await this.countBackups(id);
                return { world: ok.world, meta: ok.meta };
            }
        }
        // Primary missing or corrupted -> try rolling backups newest to oldest
        for (let i = 1; i <= exports.MAX_BACKUPS; i++) {
            const bak = await this.run((b) => b.get(backupKey(id, i)));
            if (!bak)
                continue;
            const ok = this.parseEnvelope(bak);
            if (ok) {
                // Restore primary from healthy backup so subsequent loads succeed cleanly
                await this.run((b) => b.set(slotKey(id), bak));
                ok.meta.backupCount = await this.countBackups(id);
                return {
                    world: ok.world,
                    meta: ok.meta,
                    recoveredFrom: `backup #${i}`,
                    warning: `Slot "${id}" was corrupted and recovered from rolling backup #${i}.`,
                };
            }
        }
        if (primary) {
            throw new Error(`Save slot "${id}" is corrupted and no valid backup could be recovered.`);
        }
        return null;
    }
    /** Intentionally corrupt a slot's primary entry (for testing recovery paths). */
    async corruptSlotForTest(id, garbage = "{corrupted_save_data!!!") {
        await this.run((b) => b.set(slotKey(id), garbage));
    }
    async deleteSlot(id) {
        await this.run((b) => b.del(slotKey(id)));
        for (let i = 1; i <= exports.MAX_BACKUPS; i++) {
            await this.run((b) => b.del(backupKey(id, i)));
        }
    }
    async countBackups(id) {
        let n = 0;
        for (let i = 1; i <= exports.MAX_BACKUPS; i++) {
            if (await this.run((b) => b.get(backupKey(id, i))))
                n++;
        }
        return n;
    }
    /** List metadata for all stored slots (newest first). */
    async listSlots() {
        const allKeys = await this.run((b) => b.keys());
        const slotIds = new Set();
        for (const k of allKeys) {
            if (k.startsWith("slot:"))
                slotIds.add(k.slice(5));
        }
        const list = [];
        for (const id of slotIds) {
            const raw = await this.run((b) => b.get(slotKey(id)));
            const backups = await this.countBackups(id);
            if (!raw)
                continue;
            try {
                const env = JSON.parse(raw);
                const validChecksum = typeof env.payload === "string" && typeof env.checksum === "number" && checksumStr(env.payload) === env.checksum;
                if (env.meta && validChecksum) {
                    list.push({ ...env.meta, corrupted: false, backupCount: backups });
                }
                else {
                    list.push({
                        id, name: env.name ?? id, savedAt: env.savedAt ?? 0, day: 0, playTime: 0,
                        area: "unknown", actors: 0, version: 0, sizeBytes: raw.length, corrupted: true, backupCount: backups,
                    });
                }
            }
            catch {
                list.push({
                    id, name: id, savedAt: 0, day: 0, playTime: 0,
                    area: "unknown", actors: 0, version: 0, sizeBytes: raw.length, corrupted: true, backupCount: backups,
                });
            }
        }
        return list.sort((a, b) => b.savedAt - a.savedAt);
    }
    /** Export a slot (or live world) as a portable JSON string. */
    async exportSlotJson(id) {
        const res = await this.loadSlot(id);
        if (!res)
            return null;
        return JSON.stringify((0, save_1.serialize)(res.world), null, 2);
    }
    /** Import a JSON string into slot `id`, validating and migrating through SAVE_VERSION. */
    async importSlotJson(id, jsonText, name) {
        const parsed = JSON.parse(jsonText);
        const valid = (0, save_1.validateSave)(parsed);
        if (!valid.ok)
            throw new Error(`Invalid save file: ${valid.error}`);
        const world = (0, save_1.settle)((0, save_1.deserialize)(parsed));
        const meta = await this.saveSlot(id, world, name ?? `Imported (${id})`);
        return { world, meta };
    }
    /** Migrate legacy localStorage `"dustwake.save"` into `slot-1` if not already present. */
    async migrateLegacyLocalStorage() {
        if (typeof localStorage === "undefined")
            return false;
        const legacy = localStorage.getItem("dustwake.save");
        if (!legacy)
            return false;
        const existing = await this.run((b) => b.get(slotKey("slot-1")));
        if (existing)
            return false;
        try {
            await this.importSlotJson("slot-1", legacy, "Migrated Legacy Save");
            return true;
        }
        catch {
            return false;
        }
    }
}
exports.SaveStore = SaveStore;
/** Shared browser save store singleton. */
exports.saveStore = new SaveStore();
/** Trigger a browser file download for an exported save JSON. */
function downloadSaveFile(filename, jsonText) {
    if (typeof document === "undefined" || typeof Blob === "undefined" || typeof URL === "undefined")
        return;
    const blob = new Blob([jsonText], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
}
