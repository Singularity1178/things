"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.eventActor = eventActor;
exports.eventAudience = eventAudience;
// Who a sim event concerns, for presentation. Many actors work at once
// (workers in other areas, an NPC beside the player), but host reactions such
// as notes, toasts, screen changes and shakes belong to the player. Nearby
// actors get world-space feedback only. Pure (no DOM), so tests can check it.
const world_1 = require("../world/world");
/** The actor an event is attributed to (message and cue events carry one). */
function eventActor(e) {
    return "actor" in e && typeof e.actor === "string" ? e.actor : undefined;
}
/** "player": the player's own (or world) event; "nearby": another actor in the player's area; "elsewhere": skip it. */
function eventAudience(w, e) {
    const id = eventActor(e);
    if (!id || id === w.playerId)
        return "player";
    const a = (0, world_1.actorById)(w, id);
    return a && a.area === (0, world_1.player)(w).area ? "nearby" : "elsewhere";
}
