"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Camera = void 0;
// Camera, zoom easing and screen shake (extracted from game.ts in Phase 0.6).
const tiles_1 = require("../content/tiles");
const util_1 = require("../util");
const zoom_1 = require("./zoom");
class Camera {
    constructor() {
        Object.defineProperty(this, "x", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "y", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "vw", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: zoom_1.BASE_W
        });
        Object.defineProperty(this, "vh", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: zoom_1.BASE_H
        });
        Object.defineProperty(this, "zoom", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        Object.defineProperty(this, "zoomAnim", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "shakeT", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "shakeMag", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "onResize", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
    }
    /** Snap camera to centre on (px, py) clamped inside area pixel bounds. */
    snap(px, py, areaW, areaH) {
        this.x = (0, util_1.clamp)(px - this.vw / 2, 0, Math.max(0, areaW * tiles_1.TS - this.vw));
        this.y = (0, util_1.clamp)(py - 12 - this.vh / 2, 0, Math.max(0, areaH * tiles_1.TS - this.vh));
    }
    /** Smoothly follow target (px, py) inside area pixel bounds. */
    follow(px, py, areaW, areaH, dt) {
        const tx = (0, util_1.clamp)(px - this.vw / 2, 0, Math.max(0, areaW * tiles_1.TS - this.vw));
        const ty = (0, util_1.clamp)(py - 12 - this.vh / 2, 0, Math.max(0, areaH * tiles_1.TS - this.vh));
        const k = Math.min(1, dt * 3.5);
        this.x += (tx - this.x) * k;
        this.y += (ty - this.y) * k;
    }
    shake(dur, mag) {
        this.shakeT = Math.max(this.shakeT, dur);
        this.shakeMag = Math.max(this.shakeMag, mag);
    }
    stepShake(dt) {
        this.shakeT = Math.max(0, this.shakeT - dt);
        if (this.shakeT <= 0)
            this.shakeMag = 0;
    }
    /** Current camera pixel origin with optional screen-shake offset (respects accessibility toggle). */
    renderOrigin(shakeEnabled) {
        let sx = 0, sy = 0;
        if (shakeEnabled && this.shakeT > 0) {
            sx = (Math.random() - 0.5) * this.shakeMag * 2;
            sy = (Math.random() - 0.5) * this.shakeMag * 2;
        }
        return { camX: Math.round(this.x + sx), camY: Math.round(this.y + sy) };
    }
    /** Apply a zoom level immediately; notifies `onResize` if view dimensions changed. */
    setZoom(z, areaW, areaH) {
        this.zoom = z;
        const { w, h } = (0, zoom_1.viewSize)(z);
        if (w === this.vw && h === this.vh)
            return false;
        this.x -= (w - this.vw) / 2;
        this.y -= (h - this.vh) / 2;
        this.vw = w;
        this.vh = h;
        if (areaW !== undefined && areaH !== undefined) {
            this.x = (0, util_1.clamp)(this.x, 0, Math.max(0, areaW * tiles_1.TS - w));
            this.y = (0, util_1.clamp)(this.y, 0, Math.max(0, areaH * tiles_1.TS - h));
        }
        this.onResize?.(w, h);
        return true;
    }
    zoomTo(z, dur) {
        if (z === this.zoom && !this.zoomAnim)
            return;
        this.zoomAnim = { from: this.zoom, to: z, t: 0, dur };
    }
    stepZoom(dt, areaW, areaH) {
        const a = this.zoomAnim;
        if (!a)
            return;
        a.t += dt;
        const k = (0, util_1.clamp)(a.t / a.dur, 0, 1);
        const e = k * k * (3 - 2 * k);
        this.setZoom((0, util_1.lerp)(a.from, a.to, e), areaW, areaH);
        if (k >= 1)
            this.zoomAnim = null;
    }
    /** Step zoom from mouse wheel; returns `{ changed, zoomIn }`. */
    applyWheel(deltaY) {
        if (deltaY === 0)
            return { changed: false, zoomIn: false };
        const cur = this.zoomAnim?.to ?? this.zoom;
        const next = (0, zoom_1.nextZoomStep)(cur, deltaY);
        if (next === cur)
            return { changed: false, zoomIn: false };
        this.zoomTo(next, 0.25);
        return { changed: true, zoomIn: next < cur };
    }
    /** Current camera viewport in world coordinates (fed to sim/lod.ts). */
    viewRect() {
        return { x: this.x, y: this.y, w: this.vw, h: this.vh };
    }
}
exports.Camera = Camera;
