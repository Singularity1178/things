"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadFromStorage = exports.saveToStorage = void 0;
const save_1 = require("../world/save");
const saveToStorage = (w) => (0, save_1.saveToStorage)(w, localStorage);
exports.saveToStorage = saveToStorage;
const loadFromStorage = () => (0, save_1.loadFromStorage)(localStorage);
exports.loadFromStorage = loadFromStorage;
