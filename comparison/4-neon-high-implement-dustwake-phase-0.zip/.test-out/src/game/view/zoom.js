"use strict";
// Zoom model (presentation only; never enters the sim or the save). A zoom
// level z shows z times more world: the world canvas is (W*z) x (H*z) with
// 1 world pixel = 1 canvas pixel, and the page scales it into the same display
// rect as the base-size UI layer, so it stays pixel-crisp. Sizes snap to
// multiples of 16x9 so the view is always integer-sized and exactly 16:9.
// Pure: tested headless.
Object.defineProperty(exports, "__esModule", { value: true });
exports.viewSize = exports.ZOOM_DEFAULT = exports.ZOOM_STEPS = exports.BASE_H = exports.BASE_W = void 0;
exports.nextZoomStep = nextZoomStep;
/** Base logical size. HUD and overlay screens are laid out for it. */
exports.BASE_W = 320, exports.BASE_H = 180;
/** Wheel steps once the eye is mended (1x = the original view). */
exports.ZOOM_STEPS = [1, 1.5, 2];
/** Default once the golem's eye is mended (golem.eye). Before that the view is fixed at 1x. */
exports.ZOOM_DEFAULT = 1.5;
const viewSize = (z) => { const k = Math.round((exports.BASE_W / 16) * z); return { w: 16 * k, h: 9 * k }; };
exports.viewSize = viewSize;
/** The wheel's next step from the current (or target) zoom; dir > 0 zooms out. */
function nextZoomStep(cur, dir) {
    let i = 0;
    exports.ZOOM_STEPS.forEach((z, j) => { if (Math.abs(z - cur) < Math.abs(exports.ZOOM_STEPS[i] - cur))
        i = j; });
    const n = Math.max(0, Math.min(exports.ZOOM_STEPS.length - 1, i + (dir > 0 ? 1 : -1)));
    return exports.ZOOM_STEPS[n];
}
