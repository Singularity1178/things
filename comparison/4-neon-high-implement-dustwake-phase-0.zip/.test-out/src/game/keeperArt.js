"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.keeperPainter = exports.KEEPER_ART = exports.KEEPER_BOX = void 0;
exports.drawClosedSign = drawClosedSign;
const font_1 = require("./font");
/** The placeholder's size (px): about a townsperson's. */
exports.KEEPER_BOX = { w: 10, h: 22 };
/** The placeholder: a plain black box standing on (x, y). */
const box = (p, x, y) => {
    p.ox = x;
    p.oy = y;
    p.r(-exports.KEEPER_BOX.w / 2, -exports.KEEPER_BOX.h, exports.KEEPER_BOX.w, exports.KEEPER_BOX.h, "#000000");
};
/** Painters by shop id; `default` is the placeholder every shop falls back on. Real art goes here. */
exports.KEEPER_ART = { default: box };
const keeperPainter = (shop) => exports.KEEPER_ART[shop] ?? exports.KEEPER_ART.default;
exports.keeperPainter = keeperPainter;
/** The card stood on a counter out of hours (drawn by the host on the world layer; `x`: its middle, `y`: its foot). */
function drawClosedSign(ctx, x, y) {
    const w = (0, font_1.textWidth)("CLOSED") + 6, bx = Math.round(x - w / 2), by = y - 10;
    ctx.fillStyle = "#1a1418";
    ctx.fillRect(bx, by, w, 10);
    ctx.fillStyle = "#b8ad92";
    ctx.fillRect(bx + 1, by + 1, w - 2, 8);
    ctx.fillStyle = "#8f856c";
    ctx.fillRect(bx + 1, by + 8, w - 2, 1);
    (0, font_1.drawText)(ctx, "CLOSED", bx + 3, by + 2, "#3a2a28");
}
