"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SchematicUi = void 0;
const flags_1 = require("../content/flags");
const tiles_1 = require("../content/tiles");
const world_1 = require("../world/world");
const schematic_1 = require("../schematic");
const zoom_1 = require("../view/zoom");
const util_1 = require("../util");
class SchematicUi {
    constructor(g) {
        Object.defineProperty(this, "g", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: g
        });
        Object.defineProperty(this, "screen", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** The rendered plan (of the dungeon, wherever the golem is). */
        Object.defineProperty(this, "canvas", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        this.screen = { id: "schem", opaque: false, t: 0, update: () => this.update(), render: () => this.render() };
    }
    /** New session: draw the plan of this world's dungeon. */
    reset(world) {
        const dg = (0, world_1.getArea)(world, "dungeon");
        this.canvas = dg.ritual ? (0, schematic_1.buildSchematic)(dg.base, dg.ritual.solution) : null;
    }
    open() {
        const g = this.g;
        g.screens.popToBase();
        g.screens.push(this.screen);
        (0, world_1.setFlag)(g.world, flags_1.FLAGS.knowSchematic);
        g.sfx.noise(0.4, 0.12, "bandpass", 2500, 1, 0, 800);
    }
    update() {
        const g = this.g;
        if (this.screen.t > 0.4 && g.hit("e", "escape", "enter", " ", "m", "i", "tab", "click")) {
            g.screens.popToBase();
            if (!(0, world_1.hasFlag)(g.world, flags_1.FLAGS.tutorialInsight)) {
                (0, world_1.setFlag)(g.world, flags_1.FLAGS.tutorialInsight);
                g.sfx.insight();
                g.boostEye(1.5);
            }
        }
    }
    render() {
        const g = this.g, ctx = g.ctx;
        if (!this.canvas)
            return;
        const k = (0, util_1.clamp)(this.screen.t / 0.45, 0, 1);
        const e = 1 - (1 - k) * (1 - k);
        ctx.fillStyle = "rgba(0,0,0,0.7)";
        ctx.fillRect(0, 0, zoom_1.BASE_W, zoom_1.BASE_H);
        const w = Math.round(zoom_1.BASE_W * e);
        const x = Math.round((zoom_1.BASE_W - w) / 2);
        ctx.drawImage(this.canvas, x, 0, w, zoom_1.BASE_H, x, 0, w, zoom_1.BASE_H);
        if (w < zoom_1.BASE_W) {
            ctx.fillStyle = "#d0d8e8";
            ctx.fillRect(x - 3, 0, 3, zoom_1.BASE_H);
            ctx.fillRect(x + w, 0, 3, zoom_1.BASE_H);
        }
        if (k >= 1 && g.area.id === "dungeon" && Math.sin(g.t * 6) > 0) {
            const pl = g.pl;
            const mx = Math.round(schematic_1.PLAN_X + (pl.x / tiles_1.TS) * schematic_1.PLAN_S), my = Math.round(schematic_1.PLAN_Y + (pl.y / tiles_1.TS) * schematic_1.PLAN_S);
            ctx.fillStyle = "#ffcc55";
            ctx.fillRect(mx - 1, my - 1, 3, 3);
            ctx.fillStyle = "#000";
            ctx.fillRect(mx, my, 1, 1);
        }
    }
}
exports.SchematicUi = SchematicUi;
