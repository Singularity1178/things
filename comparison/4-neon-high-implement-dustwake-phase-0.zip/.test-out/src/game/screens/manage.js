"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ManageUi = void 0;
const kit_1 = require("../ui/kit");
const actors_1 = require("../content/actors");
const items_1 = require("../content/items");
const gear_1 = require("../content/gear");
const world_1 = require("../world/world");
const inventory_1 = require("../sim/inventory");
const actorStats_1 = require("../sim/actorStats");
const gear_2 = require("../sim/gear");
const power_1 = require("../sim/power");
const crafting_1 = require("../sim/crafting");
const jobs_1 = require("../sim/jobs");
const commands_1 = require("../sim/commands");
const orders_1 = require("../sim/orders");
const items_2 = require("../art/items");
const slots_1 = require("../art/slots");
const workerArt_1 = require("../workerArt");
const font_1 = require("../font");
const zoom_1 = require("../view/zoom");
const util_1 = require("../util");
const PX = 5, PY = 2, PW = 310, PH = 172;
/** Left column (the worker), right column (the rows). */
const LX = 13, RX = 166, RW = 141, ROW = 11, RY = 27;
const TONE = { ok: kit_1.UI.ok, warn: kit_1.UI.amber, bad: kit_1.UI.bad, dim: kit_1.UI.mid };
const wrap = (i, d, n) => (n ? (((i + d) % n) + n) % n : 0);
class ManageUi {
    constructor(g) {
        Object.defineProperty(this, "g", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: g
        });
        Object.defineProperty(this, "screen", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** The worker being managed. */
        Object.defineProperty(this, "targetId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        /** A core swap was ordered: the host reopens the screen once the reach is done (see resume). */
        Object.defineProperty(this, "pending", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "view", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "main"
        });
        /** Chosen row, per view (cursor memory). */
        Object.defineProperty(this, "rows", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { main: 0, gather: 0, craft: 0, walk: 0 }
        });
        /** Form choices: indexes into the lists derived from the world, clamped on every refresh. */
        Object.defineProperty(this, "gather", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { res: 0, from: 0, to: 0, amt: 4 }
        });
        Object.defineProperty(this, "craft", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { station: 0, recipe: 0, amt: 0 }
        });
        Object.defineProperty(this, "walk", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { where: 0 }
        });
        /** The rename field: active while the worker's name is being typed. */
        Object.defineProperty(this, "nameField", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new kit_1.TextField(actorStats_1.ACTOR_NAME_MAX)
        });
        /** Opens the transfer screen for a worker (wired by the host; this screen steps aside for it). */
        Object.defineProperty(this, "openTransfer", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "list", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "fresh", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "fig", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        this.screen = { id: "manage", opaque: false, t: 0, update: () => this.update(), render: () => this.render() };
    }
    /** New session (a world was loaded or restarted): nothing remembered, no swap pending. */
    reset() { this.targetId = null; this.pending = false; this.nameField.active = false; this.nameField.clear(); this.view = "main"; this.rows = { main: 0, gather: 0, craft: 0, walk: 0 }; }
    get target() { return this.targetId ? (0, world_1.actorById)(this.g.world, this.targetId) : undefined; }
    get row() { return this.rows[this.view]; }
    get current() { return this.list[this.row]; }
    /** The rows of the current view, for tests. */
    get menu() { this.refresh(); return this.list; }
    open(targetId) {
        if (targetId !== this.targetId) {
            this.rows = { main: 0, gather: 0, craft: 0, walk: 0 };
        }
        this.targetId = targetId;
        this.view = "main";
        this.pending = false;
        this.nameField.active = false;
        this.nameField.clear();
        this.refresh();
        this.g.screens.push(this.screen);
        this.g.sfx.open();
    }
    /** The ordered core swap is done: back to the worker, if it is still within reach. */
    resume() {
        this.pending = false;
        if (!this.targetId || (0, jobs_1.workerRefusal)(this.g.world, this.g.pl, this.targetId))
            return;
        this.view = "main";
        this.refresh();
        this.g.screens.push(this.screen);
    }
    // ---------------------------------------------------------------- rows
    refresh() {
        const a = this.target;
        this.fresh = true;
        if (!a) {
            this.list = [];
            return;
        }
        this.list = this.view === "main" ? this.mainRows(a) : this.view === "gather" ? this.gatherRows(a) : this.view === "craft" ? this.craftRows(a) : this.walkRows(a);
        this.rows[this.view] = (0, util_1.clamp)(this.rows[this.view], 0, Math.max(0, this.list.length - 1));
    }
    mainRows(a) {
        const g = this.g, pl = g.pl, job = a.job;
        const core = (0, power_1.coreActionFor)(pl, a), needs = !!(0, actors_1.actorDef)(a).power;
        const coreRow = !needs
            ? { label: "NEEDS NO CORE", ok: false, note: ["THIS BODY RUNS WITHOUT A POWER CORE."] }
            : core.op === "remove"
                ? { label: `TAKE OUT ${items_1.ITEM_NAMES[core.item]}`, ok: true, note: ["TAKE ITS CORE OUT. IT POWERS DOWN AND ITS ORDER", "WAITS UNTIL A CORE GOES BACK IN."], act: () => this.swapCore() }
                : core.op === "insert"
                    ? { label: `SLOT IN ${items_1.ITEM_NAMES[core.item]}`, ok: true, note: ["SLOT A CORE FROM YOUR PACK INTO ITS CHEST.", "IT POWERS ON AND GETS BACK TO ITS ORDER."], act: () => this.swapCore() }
                    : { label: "NO CORE TO SLOT IN", ok: false, note: [power_1.CORE_TEXT.noCore + "."], act: () => this.swapCore() };
        const kindRow = (label, kind, view, note) => (0, orders_1.canTake)(a, kind) ? { label, ok: true, note, act: () => this.go(view) } : { label, ok: false, note: ["IT CANNOT DO THAT WORK."] };
        const live = !!job && job.status !== "done";
        const resume = !!job && (job.status === "blocked" || (job.status === "paused" && job.reason === "manual"));
        return [
            coreRow,
            kindRow("GATHER...", "gatherDeposit", "gather", ["SEND IT TO HARVEST A RESOURCE, INTO A STORAGE CHEST", "OR ITS OWN PACK, ONCE OR UNTIL TOLD TO STOP."]),
            kindRow("CRAFT...", "craftAt", "craft", ["HAVE IT CRAFT AT A BENCH FROM ITS PACK AND THE", "STORAGE BESIDE THE BENCH, ONCE OR ON REPEAT."]),
            kindRow("GO TO...", "walk", "walk", ["SEND IT SOMEWHERE AND LEAVE IT STANDING THERE."]),
            { label: "TRANSFER...", ok: true, note: ["SEE YOUR PACK BESIDE ITS PACK: GIVE IT ITEMS, TAKE", "THEM BACK, OR PUT A RUNE ON IT."], act: () => this.openTransfer?.(a.id) },
            { label: "RENAME...", ok: true, note: [a.name ? `IT IS CALLED ${(0, actorStats_1.actorLabel)(a)}. GIVE IT A NEW NAME,` : "GIVE IT A NAME OF YOUR OWN. IT GOES BEFORE ITS KIND:", a.name ? "OR LEAVE IT EMPTY TO CLEAR IT." : `${(0, actors_1.actorDef)(a).name} BECOMES BOB - ${(0, actors_1.actorDef)(a).name}.`], act: () => this.startRename() },
            resume
                ? { label: job.status === "blocked" ? "RETRY ORDER" : "RESUME ORDER", ok: true, note: ["LET IT TRY AGAIN, FROM WHERE IT STANDS."], act: () => this.control("resume") }
                : { label: "PAUSE ORDER", ok: live, note: [live ? "HOLD ITS ORDER WHERE IT IS. NOTHING IS LOST." : "IT HAS NO ORDER TO PAUSE."], act: () => this.control("pause") },
            { label: "CANCEL ORDER", ok: !!job, note: [job ? "DROP ITS ORDER. WHAT IT CARRIES STAYS WITH IT." : "IT HAS NO ORDER TO CANCEL."], act: () => this.control("cancel") },
        ];
    }
    amountRow(st) {
        const v = orders_1.AMOUNTS[st.amt];
        return {
            label: "AMOUNT", value: String(v), ok: true, step: (d) => { st.amt = wrap(st.amt, d, orders_1.AMOUNTS.length); },
            note: v === "REPEAT" ? ["IT KEEPS AT IT UNTIL YOU CANCEL THE ORDER."] : [`IT STOPS AFTER ${v}.`],
        };
    }
    gatherRows(a) {
        const w = this.g.world, st = this.gather;
        const resources = (0, orders_1.gatherResources)();
        st.res = (0, util_1.clamp)(st.res, 0, resources.length - 1);
        const item = resources[st.res];
        // TO: every chest it can get to, then INVENTORY (its own pack), which is always offered (sim/orders.ts: gatherTargets).
        const sources = (0, orders_1.gatherSources)(w, a, item), targets = (0, orders_1.gatherTargets)(w, a);
        st.from = (0, util_1.clamp)(st.from, 0, Math.max(0, sources.length - 1));
        st.to = (0, util_1.clamp)(st.to, 0, targets.length - 1);
        const from = sources[st.from], to = targets[st.to];
        const why = (0, orders_1.gatherRefusal)(w, a, item, from?.area, to.ref);
        const amount = orders_1.AMOUNTS[st.amt], repeat = amount === "REPEAT";
        return [
            { label: "RESOURCE", value: items_1.ITEM_NAMES[item], ok: true, step: (d) => { st.res = wrap(st.res, d, resources.length); st.from = 0; }, note: [`WHAT TO GATHER: ${resources.map((i) => items_1.ITEM_NAMES[i]).join(", ")}.`] },
            { label: "FROM", value: from ? from.label : "NONE", ok: !!from, step: (d) => { st.from = wrap(st.from, d, sources.length); }, note: from ? [`${from.count} SOURCES OF ${items_1.ITEM_NAMES[item]} LEFT IN ${from.label}.`] : [`NO ${items_1.ITEM_NAMES[item]} LEFT IN ANY AREA IT CAN REACH.`] },
            {
                label: "TO", value: to.label, ok: true, step: (d) => { st.to = wrap(st.to, d, targets.length); },
                note: to.ref ? [`IT STORES WHAT IT GATHERS IN ${to.label}.`] : ["IT KEEPS WHAT IT GATHERS IN ITS OWN PACK.", "TAKE IT FROM THERE WITH TRANSFER."],
            },
            this.amountRow(st),
            {
                label: "ISSUE ORDER", ok: !why, note: [why ? `${why}.` : `GATHER ${repeat ? "WITHOUT END" : String(amount)} ${items_1.ITEM_NAMES[item]} FROM ${from.label}, TO ${to.label}.`],
                act: () => this.issue((0, jobs_1.gatherOrder)(item, from.area, to.ref ? { ...to.ref } : null, repeat ? 1 : amount, repeat)),
            },
        ];
    }
    craftRows(a) {
        const w = this.g.world, st = this.craft;
        const stations = (0, orders_1.stationOptions)(w, a);
        st.station = (0, util_1.clamp)(st.station, 0, Math.max(0, stations.length - 1));
        const station = stations[st.station], entries = (0, orders_1.craftChoices)(w, a, station);
        st.recipe = (0, util_1.clamp)(st.recipe, 0, Math.max(0, entries.length - 1));
        const e = entries[st.recipe], amount = orders_1.AMOUNTS[st.amt], repeat = amount === "REPEAT";
        const why = !station ? "BUILD A CRAFTING BENCH FIRST" : !e ? "IT KNOWS NO RECIPE HERE" : null;
        const r = e?.recipe;
        const recipeNote = r ? [
            `MAKES ${r.output.n} ${items_1.ITEM_NAMES[r.output.item]}. NEEDS ${r.inputs.map((c) => `${c.n} ${items_1.ITEM_NAMES[c.item]}`).join(", ")}.`,
            e.status === "ok" ? "IT HAS WHAT IT NEEDS RIGHT NOW." : `NOW: ${(0, crafting_1.craftReason)(e)}. THE ORDER WAITS.`,
        ] : ["NOTHING TO CRAFT."];
        return [
            { label: "STATION", value: station ? station.label : "NONE", ok: !!station, step: (d) => { st.station = wrap(st.station, d, stations.length); st.recipe = 0; }, note: station ? [`IT CRAFTS AT ${station.label}, FROM ITS PACK AND THE STORAGE BESIDE IT.`] : ["NO STATION YET. BUILD A CRAFTING BENCH."] },
            { label: "RECIPE", value: r ? r.name : "NONE", ok: !!e, step: (d) => { st.recipe = wrap(st.recipe, d, entries.length); }, note: recipeNote },
            this.amountRow(st),
            {
                label: "ISSUE ORDER", ok: !why, note: [why ? `${why}.` : `CRAFT ${repeat ? "WITHOUT END" : String(amount)} ${r.name} AT ${station.label}.`],
                act: () => this.issue((0, jobs_1.craftOrder)({ ...station.ref }, r.id, repeat ? 1 : amount, repeat)),
            },
        ];
    }
    walkRows(a) {
        const st = this.walk, spots = (0, orders_1.walkOptions)(this.g.world, a);
        st.where = (0, util_1.clamp)(st.where, 0, Math.max(0, spots.length - 1));
        const s = spots[st.where];
        return [
            { label: "WHERE", value: s ? s.label : "NONE", ok: !!s, step: (d) => { st.where = wrap(st.where, d, spots.length); }, note: s ? [`IT WALKS THERE, BY ROAD, STAIR OR RUNE, AND STANDS.`, `${(0, orders_1.areaName)(s.area)} AT ${Math.round(s.x)},${Math.round(s.y)}.`] : ["THERE IS NOWHERE FOR IT TO GO."] },
            { label: "ISSUE ORDER", ok: !!s, note: [s ? `SEND IT TO ${s.label}.` : "THERE IS NOWHERE FOR IT TO GO."], act: () => this.issue((0, jobs_1.walkOrder)(s.area, s.x, s.y)) },
        ];
    }
    // ---------------------------------------------------------------- doing
    go(view) { this.view = view; this.refresh(); }
    issue(order) {
        const g = this.g;
        if (!this.targetId)
            return;
        const r = (0, commands_1.giveWorkerOrder)(g.world, g.pl, this.targetId, order);
        if (r.ok) {
            g.sfx.tone(520, 0.06, "triangle", 0.04);
            this.view = "main";
            this.rows.main = 0;
        }
        else
            g.sfx.thud();
        g.drainEvents();
        this.refresh();
    }
    control(what) {
        const g = this.g;
        if (!this.targetId)
            return;
        const r = (0, commands_1.controlWorker)(g.world, g.pl, this.targetId, what);
        if (r.ok)
            g.sfx.tone(440, 0.05, "triangle", 0.04);
        else
            g.sfx.thud();
        g.drainEvents();
        this.refresh();
    }
    /** Start typing a new name, the current one as the starting text. */
    startRename() {
        const a = this.target;
        if (!a)
            return;
        this.nameField.value = (a.name ?? "").slice(0, actorStats_1.ACTOR_NAME_MAX);
        this.nameField.active = true;
        this.g.sfx.tone(520, 0.05, "triangle", 0.04);
    }
    /** Keep what was typed (empty clears the name). Returns whether the worker took it. */
    commitRename() {
        const g = this.g, f = this.nameField;
        f.active = false;
        const r = this.targetId ? (0, commands_1.renameActor)(g.world, g.pl, this.targetId, f.value) : { ok: false, text: "" };
        f.clear();
        if (r.ok)
            g.sfx.tone(420, 0.05, "triangle", 0.04);
        else
            g.sfx.thud();
        g.drainEvents();
        this.refresh();
        return r.ok;
    }
    cancelRename() { this.nameField.active = false; this.nameField.clear(); }
    /** Slot a core in or take it out: the same order the C key gives. The golem does it with the world running, then this screen comes back. */
    swapCore() {
        const g = this.g, a = this.target;
        if (!a)
            return;
        const act = (0, power_1.coreActionFor)(g.pl, a);
        if (act.op === "none") {
            g.say(power_1.CORE_TEXT.noCore);
            g.sfx.thud();
            return;
        }
        if ((0, commands_1.orderCoreSwap)(g.world, g.pl, a.id, act.op === "insert" ? act.item : null)) {
            this.pending = true;
            g.screens.popToBase();
        }
        else
            g.sfx.thud();
        g.drainEvents();
    }
    update() {
        const g = this.g;
        const a = this.target;
        if (this.nameField.active) {
            // Typing mode: letters go to the field, never to the rows or the core key.
            if (!a) {
                this.cancelRename();
                g.screens.popToBase();
                return;
            }
            if (this.nameField.feed(g.typed))
                g.sfx.tone(620, 0.02, "square", 0.015);
            if (g.hit("enter"))
                this.commitRename();
            else if (g.hit("escape"))
                this.cancelRename();
            return;
        }
        if (g.hit("i", "tab")) {
            g.screens.popToBase();
            return;
        }
        if (!a) {
            g.screens.popToBase();
            return;
        }
        if (g.hit("escape")) {
            if (this.view === "main")
                g.screens.popToBase();
            else {
                this.go("main");
                g.sfx.tone(400, 0.04, "square", 0.02);
            }
            return;
        }
        this.refresh();
        const before = `${this.view}:${this.row}`;
        if (g.hit("arrowup", "w"))
            this.rows[this.view] = Math.max(0, this.row - 1);
        if (g.hit("arrowdown", "s"))
            this.rows[this.view] = Math.min(this.list.length - 1, this.row + 1);
        if (`${this.view}:${this.row}` !== before)
            g.sfx.tone(500, 0.04, "square", 0.02);
        const r = this.current;
        if (g.hit("c")) {
            this.swapCore();
            return;
        }
        if (this.view === "main" && g.hit("r")) {
            this.startRename();
            return;
        }
        if (!r)
            return;
        const d = g.hit("arrowleft", "a") ? -1 : g.hit("arrowright", "d") ? 1 : 0;
        if (d && r.step) {
            r.step(d);
            g.sfx.tone(480, 0.04, "square", 0.02);
            this.refresh();
            return;
        }
        if (g.hit("e", "enter", " ")) {
            if (r.act && r.ok)
                r.act();
            else if (r.step) {
                r.step(1);
                g.sfx.tone(480, 0.04, "square", 0.02);
                this.refresh();
            }
            else {
                g.say(r.note[0].replace(/\.$/, ""));
                g.sfx.thud();
            }
        }
    }
    // ---------------------------------------------------------------- drawing
    render() {
        const g = this.g, ctx = g.ctx, a = this.target;
        if (!this.fresh || this.view !== "walk")
            this.refresh();
        ctx.fillStyle = "rgba(0,0,0,0.55)";
        ctx.fillRect(0, 0, zoom_1.BASE_W, zoom_1.BASE_H);
        (0, kit_1.panel)(ctx, PX, PY, PW, PH);
        if (!a)
            return;
        const st = (0, orders_1.workerStatus)(g.world, a);
        if (this.nameField.active)
            this.nameField.draw(ctx, LX - 1, PY + 3, 150, g.t, "NAME");
        else {
            (0, font_1.drawText)(ctx, (0, kit_1.clipText)((0, actorStats_1.actorLabel)(a), 150), LX, PY + 6, kit_1.UI.title);
            (0, font_1.drawText)(ctx, (0, kit_1.clipText)(st.text, 120), PX + PW - 8, PY + 6, TONE[st.tone], 1, "right");
        }
        this.renderWorker(a);
        this.renderRows();
        this.renderNotes();
        g.renderNote(PY + PH + 1);
    }
    renderWorker(a) {
        const g = this.g, ctx = g.ctx, w = g.world;
        // portrait
        (0, kit_1.frame)(ctx, LX, 17, 46, 48, "#0e0c10", "#26222c", "#34303c");
        const art = workerArt_1.BODY_ART[(0, actors_1.actorDef)(a).art.key];
        if (art) {
            this.fig ?? (this.fig = (0, util_1.makeCanvas)(21, 22));
            this.fig.ctx.clearRect(0, 0, 21, 22);
            const on = (0, actorStats_1.powered)(a), busy = on && (!!a.task || a.job?.status === "running");
            art(new util_1.Pen(this.fig.ctx, false), 10, 20, (0, workerArt_1.workerPose)((0, workerArt_1.workerState)(on, busy), { facing: "down", phase: 0, moving: false, t: g.t, hasCore: !!a.powerCore }));
            ctx.drawImage(this.fig.c, LX + 2, 19, 42, 44);
        }
        // state, beside it
        const x = LX + 52, tw = 100, pw = (0, orders_1.powerState)(a), v = (0, orders_1.jobView)(w, a);
        (0, font_1.drawText)(ctx, (0, kit_1.clipText)(`POWER: ${pw.text}`, tw), x, 20, TONE[pw.tone]);
        (0, font_1.drawText)(ctx, (0, kit_1.clipText)(`AT: ${(0, orders_1.areaName)(a.area)}`, tw), x, 29, kit_1.UI.mid);
        if (v) {
            (0, font_1.drawText)(ctx, (0, kit_1.clipText)(`${v.title}${v.progress ? ` ${v.progress}` : ""}`, tw), x, 38, kit_1.UI.text);
            (0, font_1.drawText)(ctx, (0, kit_1.clipText)(`PHASE: ${v.phase}`, tw), x, 47, kit_1.UI.mid);
            (0, font_1.drawText)(ctx, (0, kit_1.clipText)(v.status, tw), x, 56, TONE[v.tone]);
            v.lines.slice(0, 2).forEach((l, i) => (0, font_1.drawText)(ctx, (0, kit_1.clipText)(l, 148), LX, 69 + i * 8, kit_1.UI.dim));
        }
        else {
            (0, font_1.drawText)(ctx, "NO ORDER", x, 38, kit_1.UI.mid);
            (0, font_1.drawText)(ctx, (0, actorStats_1.powered)(a) ? "IT STANDS AND WAITS" : "IT IS SWITCHED OFF", x, 47, kit_1.UI.dim);
            (0, font_1.drawText)(ctx, (0, kit_1.clipText)((0, orders_1.workerStatus)(w, a).text, tw), x, 56, TONE[(0, orders_1.workerStatus)(w, a).tone]);
        }
        // what it carries
        const cap = (0, inventory_1.capacity)(w, a), used = a.inventory.slice(0, cap).filter(Boolean).length;
        (0, font_1.drawText)(ctx, `CARRIES ${used}/${cap}`, LX, 87, kit_1.UI.mid);
        for (let i = 0; i < cap; i++) {
            const cx = LX + (i % 4) * 19, cy = 95 + Math.floor(i / 4) * 19, s = a.inventory[i] ?? null;
            (0, kit_1.frame)(ctx, cx, cy, 18, 18, s ? "#17141b" : "#100e12", s ? "#3a3540" : "#2a2630", "#4a4552");
            if (!s)
                continue;
            ctx.drawImage((0, items_2.itemIcon)(s.item).a, cx + 1, cy + 1);
            if (s.n > 1)
                (0, font_1.drawText)(ctx, String(s.n), cx + 17 - (String(s.n).length * 4 - 1), cy + 11, "#f0e8d0");
        }
        // what it wears
        (0, font_1.drawText)(ctx, "WORN", LX + 84, 87, kit_1.UI.mid);
        const slots = (0, actors_1.actorDef)(a).gearSlots.slice(0, 3);
        slots.forEach((id, i) => {
            const sx = LX + 84 + i * 24, item = (0, gear_2.wornIn)(a, id);
            (0, kit_1.frame)(ctx, sx, 95, 20, 20, item ? "#1c1722" : "#100e12", item ? "#6a5634" : "#2a2630", item ? "#a88a4c" : "#3a3540");
            if (item)
                ctx.drawImage((0, items_2.itemIcon)(item).a, sx + 2, 97);
            else {
                ctx.globalAlpha = 0.28;
                ctx.drawImage((0, slots_1.slotIcon)((0, gear_1.slotDef)(id).kind).a, sx + 2, 97);
                ctx.globalAlpha = 1;
            }
            (0, font_1.drawText)(ctx, (0, gear_1.slotDef)(id).name, sx + 10, 118, item ? kit_1.UI.dim : kit_1.UI.lock, 1, "center");
        });
        if (!slots.length)
            (0, font_1.drawText)(ctx, "NOTHING", LX + 84, 99, kit_1.UI.dim);
    }
    renderRows() {
        const g = this.g, ctx = g.ctx, t = g.t;
        const title = this.view === "main" ? "ORDERS" : this.view === "gather" ? "GATHER ORDER" : this.view === "craft" ? "CRAFT ORDER" : "GO TO ORDER";
        (0, font_1.drawText)(ctx, title, RX + 2, 18, kit_1.UI.mid);
        ctx.fillStyle = "#26222c";
        ctx.fillRect(RX - 4, 16, 1, 114);
        this.list.forEach((r, i) => {
            const y = RY + i * ROW, sel = i === this.row;
            if (sel)
                (0, kit_1.frame)(ctx, RX, y - 2, RW, ROW, "#221d26", (0, kit_1.selEdge)(t), "#3a3540");
            const col = sel ? kit_1.UI.title : r.ok ? kit_1.UI.text : kit_1.UI.lock;
            (0, font_1.drawText)(ctx, (0, kit_1.clipText)(r.label, r.value !== undefined ? 36 : RW - 10), RX + 5, y + 1, col);
            if (r.value !== undefined) {
                const arrows = sel && r.step ? ["<", ">"] : [" ", " "];
                (0, font_1.drawText)(ctx, `${arrows[0]} ${(0, kit_1.clipText)(r.value, 88)} ${arrows[1]}`.replace(/^ {1,2}/, ""), RX + RW - 5, y + 1, r.ok ? (sel ? kit_1.UI.title : kit_1.UI.amber) : kit_1.UI.lock, 1, "right");
            }
        });
    }
    renderNotes() {
        const g = this.g, ctx = g.ctx;
        const bx = PX + 4, by = PY + PH - 38, bw = PW - 8, bh = 34;
        (0, kit_1.frame)(ctx, bx, by, bw, bh, "#0e0c10", "#2a2630", "#3a3540");
        const r = this.current;
        (r?.note ?? []).slice(0, 3).forEach((l, i) => (0, font_1.drawText)(ctx, (0, kit_1.clipText)(l, bw - 12), bx + 6, by + 5 + i * 7, r.ok ? "#a89c80" : kit_1.UI.mid));
        const keys = this.nameField.active ? "TYPE A NAME   ENTER KEEP   ESC CANCEL   EMPTY: NO NAME" : this.view === "main" ? "W/S CHOOSE   E SELECT   R RENAME   C CORE   ESC CLOSE" : "W/S CHOOSE   A/D CHANGE   E CONFIRM   C CORE   ESC BACK";
        (0, font_1.drawText)(ctx, (0, kit_1.clipText)(keys, bw - 12), bx + 6, by + bh - 9, kit_1.UI.dim);
    }
}
exports.ManageUi = ManageUi;
