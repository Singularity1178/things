"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SettingsModal = void 0;
// Settings & Accessibility Modal (Phase 0.7) rendered on the 2x hi-res UI layer.
// Reads dynamically from `registeredSettings()` so future phases register their
// options in one central place. Supports mouse, keyboard, and gamepad navigation.
const settings_1 = require("../settings");
const components_1 = require("../ui/components");
const input_1 = require("../ui/input");
const propFont_1 = require("../ui/propFont");
const TABS = [
    { id: "audio", label: "Audio" },
    { id: "display", label: "Display & Accessibility" },
    { id: "alerts", label: "Alerts & Autosave" },
    { id: "controls", label: "Keybinds" },
];
class SettingsModal {
    constructor() {
        Object.defineProperty(this, "open", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "tab", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "audio"
        });
        Object.defineProperty(this, "focus", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "rebinding", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "controlsList", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { scroll: 0, selected: 0 }
        });
    }
    toggle() {
        this.open = !this.open;
        this.rebinding = null;
        this.focus = 0;
    }
    close() {
        this.open = false;
        this.rebinding = null;
    }
    /** Capture a key press while waiting to rebind an action. Returns true if consumed. */
    captureKey(rawKey, settings) {
        if (!this.open || !this.rebinding)
            return false;
        const k = rawKey.toLowerCase();
        if (k === "escape") {
            this.rebinding = null;
            return true;
        }
        settings.rebind(this.rebinding, k);
        this.rebinding = null;
        return true;
    }
    updateAndRender(ctx, input, settings, hitKey, tips) {
        if (!this.open)
            return false;
        const ptr = input.pointer;
        const s = settings.data;
        const pal = s.colorBlindPalette;
        if (!this.rebinding) {
            if (hitKey("escape")) {
                this.close();
                return true;
            }
            if (hitKey("q")) {
                const i = TABS.findIndex((t) => t.id === this.tab);
                this.tab = TABS[(i - 1 + TABS.length) % TABS.length].id;
                this.focus = 0;
            }
            else if (hitKey("e") && this.tab === "controls" && !ptr.inside) {
                const actions = Object.keys(settings_1.ACTION_LABELS);
                const act = actions[this.controlsList.selected];
                if (act)
                    this.rebinding = act;
            }
        }
        const r = { x: 80, y: 34, w: input_1.UI2_W - 160, h: input_1.UI2_H - 68 };
        const { closeClicked } = (0, components_1.hiModal)(ctx, r, "Settings & Accessibility", "Esc to close", ptr);
        if (closeClicked) {
            this.close();
            return true;
        }
        // Tabs
        const tabR = { x: r.x + 10, y: r.y + 30, w: r.w - 20, h: 18 };
        const nextTab = (0, components_1.hiTabs)(ctx, tabR, TABS, this.tab, ptr, tips);
        if (nextTab) {
            this.tab = nextTab;
            this.focus = 0;
            this.rebinding = null;
        }
        const bodyR = { x: r.x + 10, y: r.y + 54, w: r.w - 20, h: r.h - 92 };
        if (this.tab === "controls") {
            const actions = Object.keys(settings_1.ACTION_LABELS);
            if (!this.rebinding) {
                if (hitKey("arrowdown"))
                    this.controlsList.selected = Math.min(actions.length - 1, this.controlsList.selected + 1);
                if (hitKey("arrowup"))
                    this.controlsList.selected = Math.max(0, this.controlsList.selected - 1);
            }
            const res = (0, components_1.hiScrollList)(ctx, bodyR, actions, 18, this.controlsList, input, (c, act, _i, rr) => {
                (0, propFont_1.drawPropText)(c, settings_1.ACTION_LABELS[act], rr.x + 6, rr.y + 5, components_1.UI2.text);
                const waiting = this.rebinding === act;
                const bindLabel = waiting ? "Press a key..." : settings.formatBinding(act);
                const col = waiting ? (0, components_1.semanticColor)("warn", pal) : components_1.UI2.title;
                (0, propFont_1.drawPropText)(c, bindLabel, rr.x + rr.w - 8, rr.y + 5, col, 1, "right");
            });
            if (res.clickedIndex >= 0) {
                this.rebinding = actions[res.clickedIndex];
            }
            // Footer button: Reset Keybinds
            const resetR = { x: r.x + 10, y: r.y + r.h - 28, w: 110, h: 18 };
            if ((0, components_1.hiButton)(ctx, resetR, "Reset Keybinds", ptr, { tooltip: { title: "Reset Controls", body: "Restore all keybindings to defaults." } }, tips)) {
                settings.resetKeybinds();
            }
        }
        else {
            const defs = (0, settings_1.registeredSettings)(this.tab);
            if (hitKey("arrowdown", "s"))
                this.focus = (this.focus + 1) % Math.max(1, defs.length);
            if (hitKey("arrowup", "w"))
                this.focus = (this.focus - 1 + Math.max(1, defs.length)) % Math.max(1, defs.length);
            (0, components_1.hiFrame)(ctx, bodyR.x, bodyR.y, bodyR.w, bodyR.h, components_1.UI2.bgDeep);
            const rowH = 28;
            defs.forEach((def, idx) => {
                const ry = bodyR.y + 6 + idx * rowH;
                if (ry + rowH > bodyR.y + bodyR.h)
                    return;
                const focused = this.focus === idx;
                if (focused) {
                    ctx.fillStyle = "#1c1826";
                    ctx.fillRect(bodyR.x + 3, ry - 2, bodyR.w - 6, rowH - 2);
                }
                (0, propFont_1.drawPropTextS)(ctx, def.label, bodyR.x + 10, ry + 2, focused ? components_1.UI2.title : components_1.UI2.text);
                if (def.hint)
                    (0, propFont_1.drawPropText)(ctx, (0, propFont_1.clipPropText)(def.hint, 210), bodyR.x + 10, ry + 13, components_1.UI2.dim);
                const ctrlR = { x: bodyR.x + bodyR.w - 178, y: ry + 3, w: 168, h: 18 };
                if (def.kind === "slider") {
                    const cur = def.get(s);
                    const sliderR = { x: ctrlR.x, y: ctrlR.y, w: ctrlR.w - 36, h: ctrlR.h };
                    const nv = (0, components_1.hiSlider)(ctx, sliderR, cur, def.min, def.max, def.step, ptr, (0, components_1.semanticColor)("info", pal), focused);
                    if (nv !== null) {
                        def.set(s, nv);
                        settings.save();
                    }
                    if (focused && hitKey("arrowleft", "a")) {
                        def.set(s, Math.max(def.min, Number((cur - def.step).toFixed(4))));
                        settings.save();
                    }
                    if (focused && hitKey("arrowright", "d")) {
                        def.set(s, Math.min(def.max, Number((cur + def.step).toFixed(4))));
                        settings.save();
                    }
                    const label = def.format ? def.format(def.get(s)) : String(def.get(s));
                    (0, propFont_1.drawPropText)(ctx, label, ctrlR.x + ctrlR.w - 2, ry + 7, components_1.UI2.title, 1, "right");
                }
                else if (def.kind === "toggle") {
                    const cur = def.get(s);
                    const toggled = (0, components_1.hiToggle)(ctx, ctrlR, cur, ptr, (0, components_1.semanticColor)("ok", pal), focused) || (focused && hitKey("enter", " "));
                    if (toggled) {
                        def.set(s, !cur);
                        settings.save();
                    }
                    (0, propFont_1.drawPropText)(ctx, cur ? "On" : "Off", ctrlR.x + ctrlR.w - 36, ry + 7, cur ? (0, components_1.semanticColor)("ok", pal) : components_1.UI2.dim, 1, "right");
                }
                else if (def.kind === "choice") {
                    const cur = def.get(s);
                    const ci = Math.max(0, def.choices.findIndex((c) => c.value === cur));
                    const choice = def.choices[ci] ?? def.choices[0];
                    const clicked = (0, components_1.hiButton)(ctx, ctrlR, choice.label, ptr, { active: focused });
                    if (clicked || (focused && hitKey("arrowright", "d", "enter"))) {
                        const next = def.choices[(ci + 1) % def.choices.length];
                        def.set(s, next.value);
                        settings.save();
                    }
                    else if (focused && hitKey("arrowleft", "a")) {
                        const prev = def.choices[(ci - 1 + def.choices.length) % def.choices.length];
                        def.set(s, prev.value);
                        settings.save();
                    }
                }
            });
        }
        // Footer buttons
        const resetAllR = { x: r.x + r.w - 196, y: r.y + r.h - 28, w: 96, h: 18 };
        if ((0, components_1.hiButton)(ctx, resetAllR, "Reset All", ptr)) {
            settings.resetAll();
        }
        const doneR = { x: r.x + r.w - 92, y: r.y + r.h - 28, w: 82, h: 18 };
        if ((0, components_1.hiButton)(ctx, doneR, "Done", ptr, { active: true })) {
            this.close();
        }
        ptr.consumed = true;
        return true;
    }
}
exports.SettingsModal = SettingsModal;
