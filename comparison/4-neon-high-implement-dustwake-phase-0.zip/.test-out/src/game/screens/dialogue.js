"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DialogueUi = void 0;
const dialogue_1 = require("../content/dialogue");
const npcs_1 = require("../content/npcs");
const dialogue_2 = require("../sim/dialogue");
const font_1 = require("../font");
const dialogueLayout_1 = require("../ui/dialogueLayout");
/** Seconds a beat holds the page before its text starts typing (presentation timing only). */
const BEAT_HOLD = { wake: 1.4, pause: 1.2, repairEye: 1.6, giveCore: 0.5 };
class DialogueUi {
    constructor(g) {
        Object.defineProperty(this, "g", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: g
        });
        Object.defineProperty(this, "screen", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** The open dialogue (presentation cursor only; progress lives in flags). */
        Object.defineProperty(this, "dlg", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        /** Show the zoom hint when the dialogue closes (set by the host after the eye repair). */
        Object.defineProperty(this, "zoomHint", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        this.screen = { id: "dialogue", opaque: false, t: 0, update: (dt) => this.update(dt), render: () => this.render() };
    }
    /** New session: nothing open. */
    reset() { this.dlg = null; this.zoomHint = false; }
    open(npc, script, segment) {
        const seg = dialogue_1.DIALOGUE[script]?.segments.find((s) => s.id === segment);
        if (!seg)
            return;
        this.dlg = { npc, seg, pages: [], page: 0, chars: 0, hold: 0 };
        this.g.screens.push(this.screen);
        this.startSegment(seg);
    }
    startSegment(seg) {
        const d = this.dlg;
        d.seg = seg;
        d.pages = (0, dialogueLayout_1.layoutDialogue)((0, dialogue_2.segmentPages)(this.g.world, this.g.pl, seg));
        if (!d.pages.length) {
            this.advanceSegment();
            return;
        }
        this.startPage(0);
    }
    startPage(i) {
        const g = this.g, d = this.dlg, p = d.pages[i];
        d.page = i;
        d.chars = 0;
        d.hold = 0;
        if (p.beat) {
            (0, dialogue_2.dialogueBeat)(g.world, g.pl, d.npc, d.seg.id, p.beat);
            g.drainEvents();
            d.hold = BEAT_HOLD[p.beat] ?? 0;
        }
    }
    advanceSegment() {
        const g = this.g, d = this.dlg;
        const next = (0, dialogue_2.finishSegment)(g.world, g.pl, d.npc, d.seg.id);
        g.drainEvents();
        if (next && this.dlg)
            this.startSegment(next);
        else
            this.close();
    }
    close() {
        this.dlg = null;
        if (this.g.screens.is("dialogue"))
            this.g.screens.popToBase();
        if (this.zoomHint) {
            this.zoomHint = false;
            this.g.say("(SCROLL TO ZOOM)");
        }
    }
    update(dt) {
        const g = this.g;
        g.animate(dt);
        const d = this.dlg;
        if (!d) {
            g.screens.popToBase();
            return;
        }
        // Esc leaves; progress is in flags, so the next talk resumes at the first unfinished segment.
        if (g.hit("escape")) {
            this.close();
            return;
        }
        if (d.hold > 0) {
            d.hold -= dt;
            return;
        }
        const p = d.pages[d.page];
        const total = p.lines.reduce((n, l) => n + l.length, 0);
        if (d.chars < total) {
            const before = Math.floor(d.chars);
            d.chars = Math.min(total, d.chars + dt * 42);
            const flat = p.lines.join("");
            for (let i = before; i < Math.floor(d.chars); i++)
                if (flat[i] !== " " && i % 2 === 0) {
                    g.sfx.blip();
                    break;
                }
        }
        if (this.screen.t > 0.15 && g.hit("e", "enter", " ")) {
            if (d.chars < total) {
                d.chars = total;
                return;
            }
            if (p.then) {
                (0, dialogue_2.dialogueBeat)(g.world, g.pl, d.npc, d.seg.id, p.then);
                g.drainEvents();
            }
            if (!this.dlg)
                return;
            if (d.page + 1 < d.pages.length) {
                this.startPage(d.page + 1);
                g.sfx.tone(240, 0.04, "triangle", 0.02);
            }
            else
                this.advanceSegment();
        }
    }
    render() {
        const g = this.g, d = this.dlg;
        if (!d)
            return;
        const ctx = g.ctx, p = d.pages[d.page];
        const npc = (0, dialogue_2.npcActor)(g.world, d.npc);
        const name = p.speaker ?? (0, npcs_1.npcDef)(npc?.npc)?.name ?? "";
        const bx = dialogueLayout_1.DIALOGUE_BOX.x, bw = dialogueLayout_1.DIALOGUE_BOX.w, bh = dialogueLayout_1.DIALOGUE_BOX.h, by = dialogueLayout_1.DIALOGUE_BOX.y;
        g.renderToast(by - 24);
        // box
        ctx.fillStyle = "#08070a";
        ctx.fillRect(bx - 1, by - 1, bw + 2, bh + 2);
        ctx.fillStyle = "#3a3540";
        ctx.fillRect(bx, by, bw, bh);
        ctx.fillStyle = "#4e4856";
        ctx.fillRect(bx, by, bw, 1);
        ctx.fillRect(bx, by, 1, bh);
        ctx.fillStyle = "rgba(14,12,18,0.94)";
        ctx.fillRect(bx + 2, by + 2, bw - 4, bh - 4);
        for (const [cx, cy] of [[bx + 3, by + 3], [bx + bw - 5, by + 3], [bx + 3, by + bh - 5], [bx + bw - 5, by + bh - 5]]) {
            ctx.fillStyle = "#6a6372";
            ctx.fillRect(cx, cy, 2, 2);
        }
        // speaker tag, trimmed in the guardian's rank gold
        const tw = (0, font_1.textWidth)(name) + 10;
        ctx.fillStyle = "#08070a";
        ctx.fillRect(bx + 7, by - 9, tw + 2, 10);
        ctx.fillStyle = "#2a2430";
        ctx.fillRect(bx + 8, by - 8, tw, 8);
        ctx.fillStyle = "#7a5a1c";
        ctx.fillRect(bx + 8, by - 8, tw, 1);
        (0, font_1.drawText)(ctx, name, bx + 13, by - 6, "#e0c060");
        // typewriter text
        let left = Math.floor(d.chars);
        p.lines.forEach((line, i) => {
            const n = Math.max(0, Math.min(line.length, left));
            left -= line.length;
            if (n > 0)
                (0, font_1.drawTextS)(ctx, line.slice(0, n), bx + dialogueLayout_1.DIALOGUE_BOX.padX, by + dialogueLayout_1.DIALOGUE_BOX.textY + i * dialogueLayout_1.DIALOGUE_BOX.lineH, "#e8dcc0", 1, "left", "#000");
        });
        const total = p.lines.reduce((n, l) => n + l.length, 0);
        if (d.hold <= 0 && d.chars >= total && Math.sin(g.t * 6) > -0.3) {
            const last = d.page === d.pages.length - 1;
            (0, font_1.drawText)(ctx, last ? "E" : "E >", bx + bw - 8, by + dialogueLayout_1.DIALOGUE_BOX.footerY, "#8a8392", 1, "right");
        }
        (0, font_1.drawText)(ctx, "ESC LEAVE", bx + dialogueLayout_1.DIALOGUE_BOX.padX, by + dialogueLayout_1.DIALOGUE_BOX.footerY, "#4e4856");
        g.renderNote(by - 36);
    }
}
exports.DialogueUi = DialogueUi;
