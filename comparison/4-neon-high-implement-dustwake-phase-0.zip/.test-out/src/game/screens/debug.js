"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DebugUi = exports.DEBUG_PANEL = exports.DEBUG_TABS = exports.DEBUG_SPEEDS = void 0;
const kit_1 = require("../ui/kit");
const items_1 = require("../content/items");
const flags_1 = require("../content/flags");
const textWrap_1 = require("../ui/textWrap");
const items_2 = require("../art/items");
const font_1 = require("../font");
const zoom_1 = require("../view/zoom");
const util_1 = require("../util");
const debug_1 = require("../sim/debug");
const inventory_1 = require("../sim/inventory");
const gear_1 = require("../sim/gear");
const world_1 = require("../world/world");
const daycycle_1 = require("../content/daycycle");
/** The speeds the PLAYER tab cycles through (multipliers; 1 is off). */
exports.DEBUG_SPEEDS = [1, 3, 6, 12];
exports.DEBUG_TABS = [
    { name: "ITEMS", search: true, hint: "E PACK  G GROUND  X DELETE  F WEAR  A/D QTY (SHIFT X10)  M MAX" },
    { name: "PLAYER", search: false, hint: "W/S CHOOSE  E OR D APPLY  A BACK (SPEED)" },
    { name: "FLAGS", search: true, hint: "W/S CHOOSE  E TOGGLE  / SEARCH  PGUP/PGDN SCROLL" },
    { name: "TELEPORT", search: true, hint: "W/S CHOOSE  E GO  / SEARCH  PGUP/PGDN SCROLL" },
    { name: "WORLD", search: false, hint: "W/S CHOOSE  E APPLY" },
];
const TABS = exports.DEBUG_TABS;
/** Panel, list and detail geometry (the 320x180 screen is laid out by hand). */
exports.DEBUG_PANEL = { x: 4, y: 2, w: 312, h: 174 };
const PX = exports.DEBUG_PANEL.x, PY = exports.DEBUG_PANEL.y, PW = exports.DEBUG_PANEL.w, PH = exports.DEBUG_PANEL.h;
const LX = 9, LW = 150, DX = 164, DW = 145, TOP = 31, BOTTOM = 153, ROW = 12;
const COLS = Math.floor((DW - 8 + 1) / 4);
const ON = kit_1.UI.ok, OFF = kit_1.UI.dim;
const onOff = (b) => ({ value: b ? "ON" : "OFF", vcol: b ? ON : OFF });
class DebugUi {
    constructor(g) {
        Object.defineProperty(this, "g", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: g
        });
        Object.defineProperty(this, "screen", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "tab", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "cursor", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [0, 0, 0, 0, 0]
        });
        Object.defineProperty(this, "scroll", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [0, 0, 0, 0, 0]
        });
        Object.defineProperty(this, "search", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new kit_1.TextField(16)
        });
        Object.defineProperty(this, "qty", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        /** The rows shown now (built and filtered every frame). */
        Object.defineProperty(this, "rows", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "status", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        this.screen = { id: "debug", opaque: false, t: 0, update: (dt) => this.update(dt), render: () => this.render() };
    }
    /** Open from the play screen (or close, if it is already open). */
    toggle() {
        const g = this.g;
        if (g.screens.is("debug")) {
            g.screens.popToBase();
            return;
        }
        if (!g.screens.is("play"))
            return;
        this.search.active = false;
        this.status = null;
        g.screens.push(this.screen);
        g.sfx.tone(440, 0.06, "triangle", 0.03);
        this.refresh();
    }
    tell(text, ok = true) { this.status = { text: text.toUpperCase(), ok }; }
    // ---------------------------------------------------------------- rows
    build(tab) {
        const g = this.g, w = g.world, pl = g.pl;
        if (tab === 0) {
            return items_1.ITEM_IDS.map((id) => {
                const def = items_1.ITEMS[id], n = (0, inventory_1.countItem)(pl, id), worn = (0, gear_1.wears)(pl, id);
                return {
                    key: "item", item: id, label: def.name, icon: (0, items_2.itemIcon)(id),
                    value: worn ? (n ? `WORN +${n}` : "WORN") : n ? `X${n}` : undefined, vcol: kit_1.UI.amber,
                    desc: (def.desc ?? []).join(" "),
                };
            });
        }
        if (tab === 1) {
            const speed = g.debugSpeed ? g.debugSpeedMult : 1;
            return [
                { key: "arm", label: "IRON ARM", ...onOff(g.hasArm), desc: "THE GOLEM'S SECOND ARM. LETS IT BREAK CRACKED WALLS AND WALK FASTER." },
                { key: "eye", label: "MENDED EYE", ...onOff((0, debug_1.flagOn)(w, flags_1.FLAGS.golemEye)), desc: "THE REPAIRED EYE. UNLOCKS THE MOUSE WHEEL ZOOM." },
                { key: "speed", label: "SUPER SPEED", value: speed === 1 ? "OFF" : `X${speed}`, vcol: speed === 1 ? OFF : ON, desc: "WALK FASTER. E OR D STEPS UP, A STEPS DOWN: OFF, X3, X6, X12." },
                { key: "noclip", label: "NOCLIP", ...onOff(g.debugNoclip), desc: "WALK THROUGH WALLS, PROPS AND BODIES. THE EDGE OF THE AREA STILL HOLDS." },
                { key: "slots", label: "ALL GEAR SLOTS", ...onOff((0, debug_1.allSlotsUnlocked)(w, pl)), desc: "UNLOCK THE LEFT ARM AND THE OTHER RUNE SLOTS. TURNING OFF SENDS WORN GEAR BACK TO THE PACK." },
                { key: "gearkit", label: "GEAR KIT", desc: "BUILD AND MASONRY KNOWLEDGE, THE BASKET WORN, MATERIALS TO 40, THE CHISEL, BOTH RUNES, ALL SLOTS (CTRL+6). AGAIN LOCKS THE SLOTS." },
                { key: "buildkit", label: "BUILD KIT", desc: "BUILD AND MASONRY KNOWLEDGE, EVERY PLAN, THE BASKET WORN, AND 40 EACH OF WOOD, STONE, PLANKS AND CUT STONE (CTRL+4)." },
                { key: "storykit", label: "STORY KIT", desc: "EVERY RUNE GLYPH, THE AETHER CORE, THE CHISEL AND THE SCHEMATIC, SKIPPING WHAT IS HELD OR PLACED (CTRL+2)." },
                { key: "plans", label: "LEARN ALL PLANS", desc: "READ EVERY ANALYSIS GATED PLAN, SO EVERYTHING SHOWS IN THE BUILD MENU." },
                { key: "mats", label: "FILL MATERIALS", desc: "TOP UP EVERY MATERIAL (WOOD, STONE, PLANKS, CUT STONE, RUBY) TO 40. WHAT DOES NOT FIT LANDS ON THE GROUND." },
                { key: "basket", label: "WEAR BASKET", value: (0, gear_1.wears)(pl, "basket") ? "WORN" : undefined, vcol: ON, desc: "STRAP A BASKET TO THE BACK (ONE FROM THE PACK, ELSE A NEW ONE). THE PACK GROWS." },
                { key: "clear", label: "CLEAR PACK", value: `${pl.inventory.reduce((n, s) => n + (s ? s.n : 0), 0)} HELD`, vcol: kit_1.UI.amber, desc: "DELETE EVERYTHING IN THE PACK. WORN GEAR STAYS ON." },
            ];
        }
        if (tab === 2) {
            return (0, debug_1.debugFlags)(w).map((f) => ({
                key: "flag", flag: f.flag, label: `${f.group}: ${f.label}`, ...onOff((0, debug_1.flagOn)(w, f.flag)),
                desc: `GROUP: ${f.group}\nFLAG: ${f.flag.toUpperCase().replace(/_/g, "-")}`,
            }));
        }
        if (tab === 3) {
            const here = pl.area;
            return (0, debug_1.debugPlaces)(w).map((p) => ({
                key: "go", place: p, label: p.label, value: p.area === here ? undefined : "TRAVEL", vcol: kit_1.UI.amber,
                desc: `AREA: ${p.group}\nPOSITION: ${Math.round(p.x)}, ${Math.round(p.y)}\nTHE GOLEM IS PUT ON THE NEAREST FREE SPOT.`,
            }));
        }
        return [
            { key: "hud", label: "COORDINATE HUD", ...onOff(g.debugHud), desc: "SHOW THE AREA, THE GOLEM'S POSITION AND TILE, AND THE ACTIVE DEBUG MODES IN THE CORNER." },
            { key: "zoom", label: "ZOOM", value: `X${g.zoom.toFixed(2)}`, vcol: kit_1.UI.amber, desc: "CYCLE THE VIEW ZOOM THROUGH ITS STEPS (WORKS WITHOUT THE MENDED EYE)." },
            { key: "time", label: "TIME OF DAY", value: `${(0, daycycle_1.clockText)((0, daycycle_1.hourOf)(w.day))} ${(0, daycycle_1.phaseAt)((0, daycycle_1.hourOf)(w.day)).toUpperCase()}`, vcol: kit_1.UI.amber, desc: "MOVE THE CLOCK ON TO THE NEXT MARK OF THE DAY: MIDNIGHT, DAWN, SIX, SUNRISE, NOON, DUSK, EIGHT, NIGHTFALL. THE CLOCK ONLY RUNS FORWARD." },
            { key: "clock", label: "CLOCK SPEED", value: `X${g.debugClock ?? 1}`, vcol: kit_1.UI.amber, desc: "HOW FAST THE DAY RUNS: X1 (A DAY IN TWELVE MINUTES), X20 OR X60. FOR WATCHING THE TOWN LIGHT ITS LAMPS AND PUT THEM OUT." },
            { key: "unlock", label: "UNLOCK EVERYTHING", desc: "ARM, EYE, ALL SLOTS, ALL KNOWLEDGE AND PLANS, AND THE GEAR, BUILD AND STORY KITS. STORY, RUNE AND NPC FLAGS ARE LEFT ALONE." },
            { key: "save", label: "SAVE GAME", desc: "WRITE THE ONE LOCALSTORAGE SLOT (K ON THE PLAY SCREEN)." },
            { key: "load", label: "LOAD GAME", desc: "LOAD THE SAVED GAME AND RESUME (L ON THE PLAY SCREEN)." },
            { key: "new", label: "NEW GAME", desc: "START A FRESH WORLD STRAIGHT IN THE DUNGEON, SKIPPING THE INTRO. THE CURRENT RUN IS DROPPED UNSAVED." },
            { key: "fixture", label: "FOUNDATION FIXTURE", desc: "LOAD THE TWO AREA FIXTURE: A WORKER GOLEM GATHERS WOOD THROUGH THE RUNES AND DEPOSITS IT IN A CHEST. THE CURRENT RUN IS DROPPED UNSAVED." },
        ];
    }
    /** Rebuild the rows for the current tab and keep the cursor in range and in view. */
    refresh() {
        const t = this.tab;
        let rows = this.build(t);
        const q = this.search.value.trim();
        if (TABS[t].search && q) {
            const words = q.split(" ");
            rows = rows.filter((r) => {
                const hay = `${r.label} ${r.item ?? ""} ${r.item ? items_1.ITEMS[r.item].tags.join(" ") : ""}`.toUpperCase().replace(/_/g, " ");
                return words.every((x) => hay.includes(x));
            });
        }
        this.rows = rows;
        const vis = this.visible();
        this.cursor[t] = (0, util_1.clamp)(this.cursor[t], 0, Math.max(0, rows.length - 1));
        this.scroll[t] = (0, util_1.clamp)(this.scroll[t], 0, Math.max(0, rows.length - vis));
        if (this.cursor[t] < this.scroll[t])
            this.scroll[t] = this.cursor[t];
        if (this.cursor[t] >= this.scroll[t] + vis)
            this.scroll[t] = this.cursor[t] - vis + 1;
    }
    top() { return TABS[this.tab].search ? TOP + 13 : TOP; }
    rowH() { return this.tab === 0 ? 16 : ROW; }
    visible() { return Math.floor((BOTTOM - this.top()) / this.rowH()); }
    cur() { return this.rows[this.cursor[this.tab]]; }
    /** Test hook: put the cursor on the first row matching a key (and item id / flag / label for the lists). */
    select(key, pick) {
        this.refresh();
        const i = this.rows.findIndex((r) => r.key === key && (pick === undefined || r.item === pick || r.flag === pick || r.label === pick));
        if (i < 0)
            return false;
        this.cursor[this.tab] = i;
        this.refresh();
        return true;
    }
    // ---------------------------------------------------------------- input
    setTab(n) {
        const was = this.tab;
        this.tab = (n + TABS.length) % TABS.length;
        if (this.tab !== was) {
            this.search.active = false;
            this.status = null;
            this.g.sfx.tone(560, 0.04, "square", 0.02);
        }
        this.refresh();
    }
    move(d) {
        const t = this.tab, n = this.rows.length;
        if (!n)
            return;
        this.cursor[t] = (0, util_1.clamp)(this.cursor[t] + d, 0, n - 1);
        this.g.sfx.tone(500, 0.03, "square", 0.015);
        this.refresh();
    }
    update(dt) {
        const g = this.g;
        g.animate(dt);
        if (this.search.active) {
            if (this.search.feed(g.typed)) {
                this.cursor[this.tab] = 0;
                this.scroll[this.tab] = 0;
            }
            if (g.hit("escape")) {
                this.search.clear();
                this.search.active = false;
            }
            else if (g.hit("enter", "arrowdown", "arrowup"))
                this.search.active = false;
            this.refresh();
            return;
        }
        if (g.hit("tab")) {
            g.screens.popToBase();
            return;
        }
        if (g.hit("escape")) {
            if (this.search.value) {
                this.search.clear();
                this.refresh();
            }
            else
                g.screens.popToBase();
            return;
        }
        // Tabs: Q / R step, 1-5 jump.
        if (g.hit("q"))
            return this.setTab(this.tab - 1);
        if (g.hit("r"))
            return this.setTab(this.tab + 1);
        for (let i = 0; i < TABS.length; i++)
            if (g.hit(String(i + 1)))
                return this.setTab(i);
        if (TABS[this.tab].search && g.hit("/")) {
            this.search.active = true;
            return;
        }
        this.refresh();
        if (g.hit("arrowup", "w"))
            this.move(-1);
        if (g.hit("arrowdown", "s"))
            this.move(1);
        if (g.hit("pageup"))
            this.move(-this.visible());
        if (g.hit("pagedown"))
            this.move(this.visible());
        if (g.hit("home"))
            this.move(-9999);
        if (g.hit("end"))
            this.move(9999);
        const row = this.cur();
        if (!row)
            return;
        const step = g.has("shift") ? 10 : 1;
        if (row.key === "item") {
            if (g.hit("arrowleft", "a"))
                this.qty = (0, util_1.clamp)(this.qty - step, 1, 99);
            if (g.hit("arrowright", "d"))
                this.qty = (0, util_1.clamp)(this.qty + step, 1, 99);
            if (g.hit("m"))
                this.qty = Math.min(99, (0, items_1.maxStack)(row.item));
            if (g.hit("e", "enter"))
                this.act(row, 0);
            if (g.hit("g"))
                this.act(row, 2);
            if (g.hit("x"))
                this.act(row, 3);
            if (g.hit("f"))
                this.act(row, 4);
        }
        else if (g.hit("e", "enter", "arrowright", "d"))
            this.act(row, 1);
        else if (g.hit("arrowleft", "a"))
            this.act(row, -1);
        this.refresh();
    }
    // ---------------------------------------------------------------- actions
    /** `how`: items: 0 pack, 2 ground, 3 delete, 4 wear. Others: 1 forward / apply, -1 back. */
    act(row, how) {
        const g = this.g, w = g.world, pl = g.pl, sfx = g.sfx;
        const chime = (up = true) => sfx.tone(up ? 560 : 380, 0.08, "triangle", 0.04);
        const buzz = () => sfx.tone(180, 0.1, "square", 0.04);
        switch (row.key) {
            case "item": {
                const id = row.item, def = items_1.ITEMS[id];
                if (how === 0) {
                    const r = (0, debug_1.summonItem)(w, pl, id, this.qty);
                    this.tell(r.text, r.ok);
                    chime();
                    g.drainEvents();
                }
                else if (how === 2) {
                    const r = (0, debug_1.summonLoose)(w, pl, id, this.qty);
                    this.tell(r.text, r.ok);
                    if (r.ok)
                        chime();
                    else
                        buzz();
                }
                else if (how === 3) {
                    const n = (0, debug_1.deleteItem)(pl, id, this.qty);
                    this.tell(n ? `-${n} ${def.name}` : `NO ${def.name} IN THE PACK`, n > 0);
                    if (n)
                        chime(false);
                    else
                        buzz();
                }
                else if (how === 4) {
                    if (!def.wear) {
                        this.tell(`${def.name} IS NOT WEARABLE`, false);
                        buzz();
                    }
                    else if ((0, gear_1.ensureWorn)(w, pl, id)) {
                        this.tell(`${def.name} WORN`);
                        chime();
                        g.drainEvents();
                    }
                    else {
                        this.tell(`NO FREE SLOT FOR ${def.name}`, false);
                        buzz();
                    }
                }
                return;
            }
            case "arm":
            case "eye": {
                const flag = row.key === "arm" ? flags_1.FLAGS.golemArm : flags_1.FLAGS.golemEye, on = !(0, debug_1.flagOn)(w, flag);
                g.debugSetFlag(flag, on);
                this.tell(`${row.label} ${on ? "ON" : "OFF"}`);
                chime(on);
                return;
            }
            case "speed": {
                const cur = g.debugSpeed ? exports.DEBUG_SPEEDS.indexOf(g.debugSpeedMult) : 0;
                const next = exports.DEBUG_SPEEDS[(Math.max(0, cur) + (how < 0 ? exports.DEBUG_SPEEDS.length - 1 : 1)) % exports.DEBUG_SPEEDS.length];
                g.debugSpeed = next > 1;
                if (next > 1)
                    g.debugSpeedMult = next;
                this.tell(next > 1 ? `SPEED X${next}` : "SPEED NORMAL");
                chime(next > 1);
                return;
            }
            case "noclip":
                g.debugNoclip = !g.debugNoclip;
                this.tell(`NOCLIP ${g.debugNoclip ? "ON" : "OFF"}`);
                chime(g.debugNoclip);
                return;
            case "slots": {
                const on = !(0, debug_1.allSlotsUnlocked)(w, pl);
                (0, debug_1.setAllSlots)(w, pl, on);
                this.tell(on ? "ALL GEAR SLOTS UNLOCKED" : "GEAR SLOTS LOCKED AGAIN");
                chime(on);
                return;
            }
            case "gearkit": {
                const on = (0, debug_1.toggleGearKit)(w, pl);
                this.tell(on ? "GEAR KIT ON: ALL SLOTS UNLOCKED" : "GEAR KIT OFF: SLOTS LOCKED AGAIN");
                chime(on);
                g.drainEvents();
                return;
            }
            case "buildkit":
                (0, debug_1.grantBuildKit)(w, pl);
                this.tell("BUILD KIT: PLANS, BASKET, MATERIALS");
                chime();
                g.drainEvents();
                return;
            case "storykit": {
                const n = (0, debug_1.grantStoryKit)(w, pl);
                this.tell(n ? `STORY KIT: ${n} ITEMS GIVEN` : "ALREADY HAVE THE WHOLE STORY KIT");
                chime();
                g.drainEvents();
                return;
            }
            case "plans":
                (0, debug_1.learnAllPlans)(w);
                this.tell("EVERY PLAN READ");
                chime();
                return;
            case "mats":
                (0, debug_1.fillMaterials)(w, pl, 40);
                this.tell("MATERIALS TOPPED UP TO 40");
                chime();
                g.drainEvents();
                return;
            case "basket": {
                const ok = (0, gear_1.ensureWorn)(w, pl, "basket");
                this.tell(ok ? "BASKET WORN" : "COULD NOT WEAR A BASKET", ok);
                chime();
                g.drainEvents();
                return;
            }
            case "clear": {
                const n = (0, debug_1.clearPack)(pl);
                this.tell(`PACK CLEARED: ${n} DELETED`);
                chime(false);
                return;
            }
            case "flag": {
                const on = !(0, debug_1.flagOn)(w, row.flag);
                g.debugSetFlag(row.flag, on);
                this.tell(`${row.label.split(": ").slice(1).join(": ")} ${on ? "ON" : "OFF"}`);
                chime(on);
                return;
            }
            case "go": {
                if (g.debugTeleport(row.place)) {
                    g.screens.popToBase();
                    g.say(`TELEPORTED: ${row.place.label}`);
                }
                else {
                    this.tell("NO FREE SPOT THERE", false);
                    buzz();
                }
                return;
            }
            case "hud":
                g.debugHud = !g.debugHud;
                this.tell(`COORDINATE HUD ${g.debugHud ? "ON" : "OFF"}`);
                chime(g.debugHud);
                return;
            case "zoom":
                g.debugZoom();
                this.tell("ZOOM CHANGED");
                chime();
                return;
            case "time":
                this.tell(`TIME: ${g.debugAdvanceTime()}`);
                chime();
                return;
            case "clock":
                g.debugClock = g.debugClock === 20 ? 60 : g.debugClock === 60 ? 1 : 20;
                this.tell(`CLOCK SPEED X${g.debugClock}`);
                chime(g.debugClock > 1);
                return;
            case "unlock": {
                for (const f of [flags_1.FLAGS.golemArm, flags_1.FLAGS.golemEye, flags_1.FLAGS.knowBuild, flags_1.FLAGS.knowRepair, flags_1.FLAGS.knowMasonry, flags_1.FLAGS.knowSchematic])
                    if (!(0, debug_1.flagOn)(w, f))
                        g.debugSetFlag(f, true);
                (0, world_1.setFlag)(w, flags_1.FLAGS.tutorialInsight);
                if (!(0, debug_1.allSlotsUnlocked)(w, pl))
                    (0, debug_1.toggleGearKit)(w, pl);
                (0, debug_1.grantBuildKit)(w, pl);
                (0, debug_1.grantStoryKit)(w, pl);
                (0, debug_1.learnAllPlans)(w);
                this.tell("EVERYTHING UNLOCKED");
                chime();
                g.drainEvents();
                return;
            }
            case "save":
                g.saveGame();
                return;
            case "load":
                if (!g.loadGame()) {
                    this.tell("NO SAVED GAME", false);
                    buzz();
                }
                return;
            case "new":
                g.debugNewGame();
                return;
            case "fixture":
                g.debugFoundations();
                return;
        }
    }
    // ---------------------------------------------------------------- render
    render() {
        const g = this.g, ctx = g.ctx, t = g.t;
        this.refresh();
        ctx.fillStyle = "rgba(0,0,0,0.72)";
        ctx.fillRect(0, 0, zoom_1.BASE_W, zoom_1.BASE_H);
        (0, kit_1.panel)(ctx, PX, PY, PW, PH);
        (0, font_1.drawText)(ctx, "DEBUG MENU", PX + 8, PY + 6, kit_1.UI.gold);
        (0, font_1.drawText)(ctx, "CTRL+0 / TAB / ESC CLOSE", PX + PW - 8, PY + 6, kit_1.UI.dim, 1, "right");
        // tabs
        const tw = Math.floor((PW - 16) / TABS.length);
        TABS.forEach((tb, i) => {
            const x = PX + 8 + i * tw, on = i === this.tab;
            (0, kit_1.frame)(ctx, x, 16, tw - 3, 11, on ? "#2a2430" : "#141117", on ? (0, kit_1.selEdge)(t) : "#2a2630", on ? "#e8d8a8" : "#3a3540");
            (0, font_1.drawText)(ctx, `${i + 1} ${tb.name}`, x + (tw - 3) / 2, 19, on ? kit_1.UI.title : kit_1.UI.mid, 1, "center");
        });
        // list
        const tab = TABS[this.tab], top = this.top(), vis = this.visible();
        if (tab.search)
            this.search.draw(ctx, LX, TOP, LW, t, "/ SEARCH");
        const cur = this.cursor[this.tab], sc = this.scroll[this.tab];
        (0, kit_1.frame)(ctx, LX, top - 1, LW, BOTTOM - top + 2, "#0e0c10", "#2a2630", "#3a3540");
        if (!this.rows.length)
            (0, font_1.drawText)(ctx, "NOTHING MATCHES", LX + LW / 2, top + 10, kit_1.UI.dim, 1, "center");
        for (let i = 0; i < vis; i++) {
            const idx = sc + i, r = this.rows[idx];
            if (!r)
                break;
            const rh = this.rowH(), y = top + i * rh, sel = idx === cur, ty = y + Math.floor((rh - 5) / 2);
            if (sel)
                (0, kit_1.frame)(ctx, LX + 2, y, LW - 8, rh - 1, "#262030", (0, kit_1.selEdge)(t), "#e8d8a8");
            let tx = LX + 6;
            if (r.icon) {
                ctx.drawImage(r.icon.a, LX + 4, y - 1, 16, 16);
                tx = LX + 22;
            }
            const vw = r.value ? (0, font_1.textWidth)(r.value) + 6 : 0;
            (0, font_1.drawText)(ctx, (0, kit_1.clipText)(r.label, LW - 17 - (tx - LX) - vw), tx, ty, sel ? kit_1.UI.title : kit_1.UI.text);
            if (r.value)
                (0, font_1.drawText)(ctx, r.value, LX + LW - 11, ty, r.vcol ?? kit_1.UI.amber, 1, "right");
        }
        if (this.rows.length > vis) {
            const h = BOTTOM - top, bh = Math.max(6, Math.round(h * vis / this.rows.length));
            ctx.fillStyle = "#2a2630";
            ctx.fillRect(LX + LW - 4, top, 2, h);
            ctx.fillStyle = "#8a8392";
            ctx.fillRect(LX + LW - 4, top + Math.round((h - bh) * sc / (this.rows.length - vis)), 2, bh);
        }
        // detail
        (0, kit_1.frame)(ctx, DX, TOP, DW, BOTTOM - TOP, "#0e0c10", "#2a2630", "#3a3540");
        const row = this.cur();
        if (row)
            this.detail(row);
        (0, font_1.drawText)(ctx, `${this.rows.length ? cur + 1 : 0}/${this.rows.length}`, DX + DW - 5, TOP + 4, kit_1.UI.dim, 1, "right");
        // key line and status
        (0, font_1.drawText)(ctx, (0, kit_1.clipText)(tab.hint, PW - 16), PX + 8, 158, kit_1.UI.mid);
        (0, font_1.drawText)(ctx, "Q/R OR 1-5 TABS", PX + 8, 166, kit_1.UI.dim);
        if (this.status)
            (0, font_1.drawText)(ctx, (0, kit_1.clipText)(this.status.text, PW - 110), PX + PW - 8, 166, this.status.ok ? kit_1.UI.ok : kit_1.UI.bad, 1, "right");
    }
    detail(row) {
        const g = this.g, ctx = g.ctx, x = DX + 5;
        if (row.key === "item") {
            const id = row.item, def = items_1.ITEMS[id], pl = g.pl;
            (0, kit_1.frame)(ctx, x, TOP + 12, 36, 36, "#141117", "#2a2630", "#3a3540");
            ctx.drawImage(row.icon.a, x + 2, TOP + 14, 32, 32);
            (0, font_1.drawText)(ctx, (0, kit_1.clipText)(def.name, DW - 56), x + 42, TOP + 15, kit_1.UI.title);
            (0, font_1.drawText)(ctx, (0, kit_1.clipText)(def.tags.join(" / ").toUpperCase(), DW - 56), x + 42, TOP + 24, kit_1.UI.mid);
            (0, font_1.drawText)(ctx, (0, kit_1.clipText)(`ID: ${id.toUpperCase().replace(/_/g, " ")}`, DW - 56), x + 42, TOP + 33, kit_1.UI.dim);
            (0, font_1.drawText)(ctx, `STACK ${(0, items_1.maxStack)(id)}`, x + 42, TOP + 41, kit_1.UI.dim);
            let y = TOP + 54;
            for (const l of [...(def.desc ?? []), ...(0, items_1.effectLines)(id)]) {
                (0, font_1.drawText)(ctx, l, x, y, kit_1.UI.text);
                y += 8;
            }
            y = Math.max(y + 3, TOP + 86);
            (0, font_1.drawText)(ctx, `IN PACK: ${(0, inventory_1.countItem)(pl, id)}`, x, y, kit_1.UI.text);
            (0, font_1.drawText)(ctx, def.wear ? `WORN: ${(0, gear_1.wears)(pl, id) ? "YES" : "NO"}` : def.equip ? `INSTALLED: ${(0, debug_1.flagOn)(g.world, def.equip.flag) ? "YES" : "NO"}` : "", x + 62, y, kit_1.UI.text);
            (0, font_1.drawText)(ctx, `HELD IN TOTAL: ${(0, debug_1.heldCount)(pl, id)}`, x, y + 8, kit_1.UI.dim);
            const qy = BOTTOM - 19;
            (0, kit_1.frame)(ctx, x, qy, DW - 10, 13, "#1c1820", "#3a3540", "#4e4856");
            (0, font_1.drawText)(ctx, "QTY", x + 5, qy + 4, kit_1.UI.mid);
            (0, font_1.drawText)(ctx, `< ${this.qty} >`, x + 50, qy + 4, kit_1.UI.amber, 1, "center");
            (0, font_1.drawText)(ctx, def.equip ? "E INSTALL" : "E GIVE", x + DW - 15, qy + 4, kit_1.UI.ok, 1, "right");
            return;
        }
        let y = TOP + 12;
        for (const l of (0, textWrap_1.wrapText)(row.label, COLS).slice(0, 2)) {
            (0, font_1.drawText)(ctx, l, x, y, kit_1.UI.title);
            y += 8;
        }
        y += 5;
        for (const l of (0, textWrap_1.wrapText)(row.desc, COLS)) {
            if (y > BOTTOM - 16)
                break;
            (0, font_1.drawText)(ctx, l, x, y, kit_1.UI.text);
            y += 8;
        }
        if (row.value)
            (0, font_1.drawText)(ctx, `NOW: ${row.value}`, x, BOTTOM - 12, row.vcol ?? kit_1.UI.amber);
    }
}
exports.DebugUi = DebugUi;
