"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IntroCutscene = exports.CUTSCENE_CUES = exports.SKIP_AFTER = void 0;
const cutscenes_1 = require("../content/cutscenes");
const cutscene_1 = require("../ui/cutscene");
const monologue_1 = require("../sim/monologue");
const zoom_1 = require("../view/zoom");
/** A cutscene can be skipped once it has run this long (the key that started it is long up by then). */
exports.SKIP_AFTER = 0.25;
/** Cue table: what each `cues` name in a script does. Adding a cue is a row here. */
exports.CUTSCENE_CUES = {
    sparks: (g) => { g.sparkBurst(8); g.sfx.spark(); },
    sparksSmall: (g) => { g.sparkBurst(6); g.sfx.spark(); },
    boot: (g) => g.sfx.boot(),
    thud: (g) => g.sfx.thud(),
    diagDone: (g) => g.sfx.diagDone(),
    /** The torn shoulder spits as the golem notices the arm is gone. */
    armSparks: (g) => { g.sparkBurst(5); g.sfx.spark(); },
    hollow: (g) => g.sfx.hollow(),
};
/** Step-wise hash for the diagnostics flicker (presentation only). */
const stepNoise = (n) => { const s = Math.sin(n * 12.9898 + 4.1) * 43758.5453; return s - Math.floor(s); };
/** The golem's look for each track mode at time t. */
function lookFor(c, t) {
    const core = (0, cutscene_1.trackAt)(c, "core", t), eye = (0, cutscene_1.trackAt)(c, "eye", t), body = (0, cutscene_1.trackAt)(c, "body", t);
    const coreV = {
        off: () => 0,
        // the original boot flicker: lit more and more often, brighter, until steady
        boot: () => (Math.random() < core.k ? core.k : 0.1),
        on: () => 1,
        // running diagnostics: stepped, irregular pulses, like a drive light
        diagnose: () => { const r = stepNoise(Math.floor(core.since / 0.06)); return r < 0.3 ? 0.2 : r < 0.75 ? 0.95 : 0.55; },
    };
    const eyeV = {
        off: () => 0, flicker: () => (Math.sin(t * 40) > 0 ? 1 : 0.2), on: () => 1,
    };
    const dormant = { slumped: 1, rise: 1 - body.k, up: 0 };
    return { core: coreV[core.mode](), eye: eyeV[eye.mode](), dormant: dormant[body.mode], diagnosing: core.mode === "diagnose" ? core.since : -1 };
}
class IntroCutscene {
    constructor(g, script = cutscenes_1.INTRO) {
        Object.defineProperty(this, "g", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: g
        });
        Object.defineProperty(this, "script", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: script
        });
        Object.defineProperty(this, "screen", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.screen = { id: "intro", opaque: true, t: 0, update: (dt) => this.update(dt), render: () => this.render() };
    }
    /** Begin (title -> intro, or R at the crossing's chapter card, on a fresh world). */
    start() {
        const g = this.g;
        g.screens.set(this.screen);
        g.monologue.pinned = true; // the list stays up until control
        g.letterbox(true);
    }
    update(dt) {
        const g = this.g, c = this.script, t = this.screen.t, t0 = t - dt;
        if (t > exports.SKIP_AFTER && g.hit("escape")) {
            this.skip(dt);
            return;
        }
        for (const b of (0, cutscene_1.beatsCrossed)(c, t0, t)) {
            for (const cue of b.cues ?? [])
                exports.CUTSCENE_CUES[cue]?.(g);
            if (b.think)
                (0, monologue_1.playerThinks)(g.world, b.think);
            if (b.control) {
                this.handOver(dt);
                return;
            }
        }
        const lk = lookFor(c, t);
        g.look.core = lk.core;
        g.look.eye = lk.eye;
        g.look.dormant = lk.dormant;
        // diagnostics: quiet data chirps on some of the flicker's steps
        if (lk.diagnosing >= 0 && Math.floor(lk.diagnosing / 0.06) !== Math.floor((lk.diagnosing - dt) / 0.06) && stepNoise(Math.floor(lk.diagnosing / 0.06)) > 0.72)
            g.sfx.chirp();
        g.worldFrame(dt);
    }
    /** Control: the letterbox opens, the list starts to fade, the play screen takes input from the next frame. */
    handOver(dt) {
        const g = this.g;
        g.worldFrame(dt);
        g.letterbox(false);
        g.monologue.release();
        g.sfx.online();
        g.startPlay();
    }
    /**
     * Esc: straight to control. The world ends up exactly as if the opening had
     * played: the golem is up and lit, and every line it would have thought is
     * thought (recorded as said, so nothing repeats later), only never shown.
     */
    skip(dt = 0) {
        const g = this.g, t = this.screen.t;
        for (const b of (0, cutscene_1.timeline)(this.script))
            if (b.at > t && b.think)
                (0, monologue_1.playerThinks)(g.world, b.think);
        g.drainEvents();
        g.monologue.reset();
        g.look.core = 1;
        g.look.eye = 1;
        g.look.dormant = 0;
        this.handOver(dt);
    }
    /** Drawn after the host's world scene and HUD: the fade from black. */
    renderFade() {
        const t = this.screen.t, f = this.script.fadeIn;
        if (t < f) {
            this.g.ctx.fillStyle = `rgba(0,0,0,${1 - t / f})`;
            this.g.ctx.fillRect(0, 0, zoom_1.BASE_W, zoom_1.BASE_H);
        }
    }
    render() { this.g.renderScene(); this.renderFade(); this.g.renderSkipHint(this.screen.t); }
}
exports.IntroCutscene = IntroCutscene;
