"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FloorsModal = void 0;
// Dynamic Areas & Floors Modal (Phase 0.3) rendered on the 2x hi-res UI layer.
// Lists all authored and runtime-generated areas (`AreaSpec`), lets the player
// create new procedural floors/caverns/outposts/wilds, travel to any area, or
// return to an area's parent.
const world_1 = require("../world/world");
const areas_1 = require("../world/areas");
const components_1 = require("../ui/components");
const input_1 = require("../ui/input");
const propFont_1 = require("../ui/propFont");
const KINDS = [
    { kind: "dungeon_floor", label: "Dungeon Floor" },
    { kind: "cavern", label: "Cavern" },
    { kind: "outpost", label: "Outpost" },
    { kind: "wilds", label: "Wilds" },
];
class FloorsModal {
    constructor() {
        Object.defineProperty(this, "open", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "kindIdx", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "depth", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        Object.defineProperty(this, "table", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { scroll: 0, selected: 0, sortCol: null, sortAsc: true }
        });
    }
    toggle() { this.open = !this.open; }
    close() { this.open = false; }
    rows(w) {
        const curId = (0, world_1.currentArea)(w).id;
        const ids = new Set([...Object.keys(areas_1.AREAS), ...w.areas.keys(), ...w.specs.keys()]);
        const list = [];
        for (const id of ids) {
            const spec = w.specs.get(id);
            const area = w.areas.get(id);
            const actors = w.actors.filter((a) => a.area === id).length;
            list.push({
                id,
                label: spec?.label ?? id.replace(/_/g, " "),
                kind: spec ? spec.kind : "authored",
                depth: spec?.depth ?? (id === "dungeon" ? 1 : 0),
                size: area ? `${area.w}x${area.h}` : spec ? `${spec.w}x${spec.h}` : "lazy",
                actors,
                current: id === curId,
                dynamic: !!spec,
                parent: spec?.parent,
            });
        }
        return list;
    }
    updateAndRender(ctx, input, w, pal, hitKey, tips, onTravel) {
        if (!this.open)
            return false;
        const ptr = input.pointer;
        if (hitKey("escape")) {
            this.close();
            return true;
        }
        const r = { x: 56, y: 30, w: input_1.UI2_W - 112, h: input_1.UI2_H - 60 };
        const { closeClicked } = (0, components_1.hiModal)(ctx, r, "Areas & Dynamic Floors (AreaSpec)", `${w.specs.size} generated`, ptr);
        if (closeClicked) {
            this.close();
            return true;
        }
        const rows = this.rows(w);
        if (hitKey("arrowdown", "s"))
            this.table.selected = Math.min(rows.length - 1, this.table.selected + 1);
        if (hitKey("arrowup", "w"))
            this.table.selected = Math.max(0, this.table.selected - 1);
        const cols = [
            { id: "id", label: "Area ID", w: 128, value: (x) => (x.current ? "* " : "") + x.label, color: (x) => x.current ? (0, components_1.semanticColor)("ok", pal) : x.dynamic ? (0, components_1.semanticColor)("info", pal) : components_1.UI2.text },
            { id: "kind", label: "Kind", w: 96, value: (x) => x.kind },
            { id: "depth", label: "Depth", w: 50, align: "right", value: (x) => `D${x.depth}`, sortKey: (x) => x.depth },
            { id: "size", label: "Size", w: 66, align: "right", value: (x) => x.size },
            { id: "actors", label: "Actors", w: 56, align: "right", value: (x) => String(x.actors), sortKey: (x) => x.actors },
            { id: "parent", label: "Parent", w: 96, value: (x) => x.parent ?? "-" },
        ];
        const tableR = { x: r.x + 10, y: r.y + 30, w: r.w - 20, h: r.h - 108 };
        const res = (0, components_1.hiTable)(ctx, tableR, cols, rows, this.table, input, 16);
        const sel = res.sorted[this.table.selected] ?? rows[0];
        // Generator bar
        const genY = r.y + r.h - 70;
        (0, components_1.hiFrame)(ctx, r.x + 10, genY, r.w - 20, 34, components_1.UI2.bgDeep);
        (0, propFont_1.drawPropText)(ctx, "Create Runtime Area:", r.x + 18, genY + 13, components_1.UI2.mid);
        const kind = KINDS[this.kindIdx];
        if ((0, components_1.hiButton)(ctx, { x: r.x + 128, y: genY + 8, w: 108, h: 18 }, `Kind: ${kind.label}`, ptr, { tooltip: { title: "Area Builder Kind", body: "Click to cycle dungeon_floor, cavern, outpost, wilds." } }, tips)) {
            this.kindIdx = (this.kindIdx + 1) % KINDS.length;
        }
        if ((0, components_1.hiButton)(ctx, { x: r.x + 242, y: genY + 8, w: 66, h: 18 }, `Depth ${this.depth}`, ptr, { tooltip: { title: "Floor Depth", body: "Click to increment depth (1..8)." } }, tips)) {
            this.depth = (this.depth % 8) + 1;
        }
        if ((0, components_1.hiButton)(ctx, { x: r.x + 314, y: genY + 8, w: 118, h: 18 }, "Generate & Enter", ptr, { active: true, accent: (0, components_1.semanticColor)("info", pal) }, tips)) {
            const parent = (0, world_1.currentArea)(w).id;
            const area = (0, world_1.createDynamicArea)(w, {
                kind: kind.kind,
                depth: this.depth,
                parent,
                w: 36,
                h: 28,
                label: `${kind.label} D${this.depth}`,
            });
            (0, world_1.enterArea)(w, (0, world_1.player)(w), area.id, area.start.x, area.start.y);
            onTravel(area.id);
            this.close();
            return true;
        }
        if ((0, components_1.hiButton)(ctx, { x: r.x + 438, y: genY + 8, w: 72, h: 18 }, "Gen Only", ptr, { tooltip: { title: "Generate Area", body: "Creates an AreaSpec without travelling yet." } }, tips)) {
            (0, world_1.createDynamicArea)(w, {
                kind: kind.kind,
                depth: this.depth,
                parent: (0, world_1.currentArea)(w).id,
                w: 36,
                h: 28,
                label: `${kind.label} D${this.depth}`,
            });
        }
        // Footer actions: Travel to Selected / Leave to Parent / Close
        const fy = r.y + r.h - 28;
        const travel = (targetId) => {
            const a = (0, world_1.getArea)(w, targetId);
            (0, world_1.enterArea)(w, (0, world_1.player)(w), a.id, a.start.x, a.start.y);
            onTravel(a.id);
            this.close();
        };
        if (res.doubleClickedRow && !res.doubleClickedRow.current) {
            travel(res.doubleClickedRow.id);
            return true;
        }
        if ((0, components_1.hiButton)(ctx, { x: r.x + 10, y: fy, w: 120, h: 18 }, "Travel to Selected", ptr, { active: true, disabled: !sel || sel.current }, tips)) {
            travel(sel.id);
            return true;
        }
        const curSpec = (0, world_1.currentArea)(w).spec;
        if ((0, components_1.hiButton)(ctx, { x: r.x + 136, y: fy, w: 126, h: 18 }, curSpec?.parent ? `Leave -> ${curSpec.parent}` : "Return to Dungeon", ptr, { disabled: !curSpec?.parent && (0, world_1.currentArea)(w).id === "dungeon" }, tips)) {
            travel(curSpec?.parent ?? "dungeon");
            return true;
        }
        if ((0, components_1.hiButton)(ctx, { x: r.x + r.w - 80, y: fy, w: 70, h: 18 }, "Close", ptr)) {
            this.close();
        }
        ptr.consumed = true;
        return true;
    }
}
exports.FloorsModal = FloorsModal;
