"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrossingCutscene = exports.CROSSING_CUES = void 0;
const cutscenes_1 = require("../content/cutscenes");
const daycycle_1 = require("../content/daycycle");
const flags_1 = require("../content/flags");
const cutscene_1 = require("../ui/cutscene");
const monologue_1 = require("../sim/monologue");
const daytime_1 = require("../sim/daytime");
const world_1 = require("../world/world");
const cards_1 = require("./cards");
const smooth = (x) => { x = x < 0 ? 0 : x > 1 ? 1 : x; return x * x * (3 - 2 * x); };
/** Cue table: what each `cues` name in the script does. */
exports.CROSSING_CUES = {
    /** The rush upward out of the halls. */
    ascend: (g) => { g.sfx.tone(64, 2.9, "sine", 0.07, 230); g.sfx.noise(2.7, 0.05, "bandpass", 300, 1.5, 0, 1400); },
    /** The far anchor does not answer: the climb stalls under the grass. */
    stall: (g) => g.sfx.stall(),
    /** The golem begins to write the missing carvings back. */
    rewrite: (g) => { g.sfx.tone(110, 1.8, "sine", 0.05, 196); g.sfx.chirp(); },
    land: (g) => g.landFx(),
    faceLeft: (g) => { g.gaze = "left"; },
    faceRight: (g) => { g.gaze = "right"; },
    faceDown: (g) => { g.gaze = "down"; },
    faceUp: (g) => { g.gaze = "up"; },
    dawn: (g) => g.sfx.dawn(),
    chapter: (g) => g.sfx.insight(),
};
class CrossingCutscene {
    constructor(g, script = cutscenes_1.CROSSING) {
        Object.defineProperty(this, "g", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: g
        });
        Object.defineProperty(this, "script", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: script
        });
        Object.defineProperty(this, "screen", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Beat start times by label. */
        Object.defineProperty(this, "at", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** The hour the time-lapse set out from (-1: not begun). */
        Object.defineProperty(this, "lapseFrom", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: -1
        });
        this.screen = { id: "crossing", opaque: true, t: 0, update: (dt) => this.update(dt), render: () => this.render() };
        this.at = Object.fromEntries((0, cutscene_1.timeline)(script).map((b) => [b.label, b.at]));
        for (const need of ["stall", "rewrite", "surface", "landed", "first light", "chapter"])
            if (!(need in this.at))
                throw new Error(`crossing script: no "${need}" beat`);
    }
    /** Which act is playing at screen time `t`. */
    actAt(t) {
        return t < this.at.surface ? "transit" : t < this.at["first light"] ? "arrival" : "firstLight";
    }
    /** Begin (the host's rune effect has finished and the sim has travelled: the golem is on the surface, unseen). */
    start() {
        const g = this.g;
        g.screens.set(this.screen);
        g.monologue.pinned = true; // the golem's account stays up until control
        g.letterbox(true);
        g.gaze = null;
        this.lapseFrom = -1;
        // the world waits in its before state under the card: the rune still dormant, nobody on it
        g.arriveStep(0, 0);
    }
    update(dt) {
        const g = this.g, c = this.script, A = this.at, t = this.screen.t, t0 = t - dt;
        if (t > 0.2 && g.hit("escape")) {
            this.finish(true);
            return;
        }
        if (t >= A.chapter + c.promptAfter) {
            if (g.hit("r")) {
                g.wakeAgain();
                return;
            }
            if (g.anyKey()) {
                this.finish(false);
                return;
            }
        }
        for (const b of (0, cutscene_1.beatsCrossed)(c, t0, t)) {
            for (const cue of b.cues ?? [])
                exports.CROSSING_CUES[cue]?.(g);
            if (b.think)
                (0, monologue_1.playerThinks)(g.world, b.think);
            if (b.label === "surface")
                g.clearParticles();
            if (b.control) {
                this.finish(false);
                return;
            }
        }
        if (t < A.surface) {
            // transit: a card. The world holds still behind it; only the golem's thoughts run.
            g.drainEvents();
            g.animate(dt);
            return;
        }
        const lt = t - A.surface;
        if (lt <= cutscenes_1.ARRIVE.END)
            g.arriveStep(lt, dt);
        else if (lt - dt <= cutscenes_1.ARRIVE.END)
            g.arriveEnd();
        if (t >= A["first light"]) {
            // the calendar clock runs on to morning while the golem watches (never back: sim/daytime.ts)
            if (this.lapseFrom < 0)
                this.lapseFrom = (0, daytime_1.worldHour)(g.world);
            const k = smooth((t - A["first light"]) / c.lapse);
            (0, daytime_1.advanceDayUpTo)(g.world, this.lapseFrom + (daycycle_1.FIRST_MORNING_HOUR - this.lapseFrom) * k);
            g.sunrise(Math.sin(Math.PI * Math.min(1, (t - A["first light"]) / (c.lapse + 3))));
        }
        g.worldFrame(dt);
    }
    /** Esc: end the crossing now, as if it had played. */
    skip() { this.finish(true); }
    /**
     * Hand over control. Played out or skipped, the world is left the same: the
     * rune restored with the golem standing on it, the clock at the first
     * morning, every line of the crossing thought (a skipped line is recorded
     * as said, only never shown).
     */
    finish(skipped) {
        const g = this.g, t = this.screen.t;
        if (skipped) {
            for (const b of (0, cutscene_1.timeline)(this.script))
                if (b.at > t && b.think)
                    (0, monologue_1.playerThinks)(g.world, b.think);
            g.drainEvents();
            g.monologue.reset();
            g.clearParticles();
        }
        g.arriveEnd();
        g.sunrise(0);
        g.gaze = null;
        (0, daytime_1.advanceDayUpTo)(g.world, daycycle_1.FIRST_MORNING_HOUR);
        g.worldFrame(0);
        g.letterbox(false);
        g.monologue.release();
        g.sfx.online();
        g.startPlay();
        g.say("THE SURFACE. THE WILD HAS SWALLOWED ALL TRACE OF THE HALLS.");
    }
    render() {
        const g = this.g, c = this.script, A = this.at, t = this.screen.t;
        if (t < A.surface) {
            (0, cards_1.renderTransit)(g.ctx, g.t, {
                et: t, stallAt: A.stall, rewriteAt: A.rewrite, endAt: A.surface, whiteOut: c.whiteOut,
                hasArm: (0, world_1.hasFlag)(g.world, flags_1.FLAGS.golemArm), eyeFixed: (0, world_1.hasFlag)(g.world, flags_1.FLAGS.golemEye),
            });
            g.renderCinema();
        }
        else {
            g.renderScene();
            g.arriveOverlay(t - A.surface);
            if (t >= A.chapter)
                (0, cards_1.renderChapter)(g.ctx, g.t, t - A.chapter, c.promptAfter, g.world, g.pl);
        }
        if (t < A.chapter)
            g.renderSkipHint(t);
    }
}
exports.CrossingCutscene = CrossingCutscene;
