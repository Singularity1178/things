"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ARTIFICERY_WORKER = exports.DUNGEON_SEED = exports.MH = exports.MW = exports.isOpaqueT = exports.isSolidT = exports.FS = exports.T = exports.TS = void 0;
exports.buildDungeon = buildDungeon;
exports.buildMap = buildMap;
// The tutorial dungeon, as an area definition. Pure data builder (no DOM): the
// same seed always yields the same layout. Runtime state lives in world/area.ts.
const rng_1 = require("./core/rng");
const tiles_1 = require("./content/tiles");
const props_1 = require("./content/props");
const ritual_1 = require("./content/ritual");
const geography_1 = require("./content/geography");
var tiles_2 = require("./content/tiles");
Object.defineProperty(exports, "TS", { enumerable: true, get: function () { return tiles_2.TS; } });
Object.defineProperty(exports, "T", { enumerable: true, get: function () { return tiles_2.T; } });
Object.defineProperty(exports, "FS", { enumerable: true, get: function () { return tiles_2.FS; } });
Object.defineProperty(exports, "isSolidT", { enumerable: true, get: function () { return tiles_2.isSolidT; } });
Object.defineProperty(exports, "isOpaqueT", { enumerable: true, get: function () { return tiles_2.isOpaqueT; } });
/** Dungeon dimensions. Only this builder uses them; everything else reads area.w / area.h. */
exports.MW = 72;
exports.MH = 56;
exports.DUNGEON_SEED = 1337;
/** The dormant worker golem's spawn row (stable id; a save migration places the same one). */
exports.ARTIFICERY_WORKER = { id: "npc.worker.artificery", npc: "worker_golem", x: 7 * tiles_1.TS + 13, y: 37 * tiles_1.TS + 14 };
function buildDungeon() {
    return buildMap(exports.DUNGEON_SEED);
}
function buildMap(seed) {
    const rng = (0, rng_1.mulberry)(seed);
    const grid = new Uint8Array(exports.MW * exports.MH);
    const style = new Uint8Array(exports.MW * exports.MH);
    const tvar = new Uint8Array(exports.MW * exports.MH);
    const inb = (x, y) => x >= 0 && y >= 0 && x < exports.MW && y < exports.MH;
    const set = (x, y, t, s) => {
        if (!inb(x, y))
            return;
        grid[y * exports.MW + x] = t;
        if (s !== undefined)
            style[y * exports.MW + x] = s;
    };
    const rect = (x, y, w, h, t, s) => {
        for (let j = y; j < y + h; j++)
            for (let i = x; i < x + w; i++)
                set(i, j, t, s);
    };
    const rooms = [];
    const room = (num, name, x, y, w, h, s) => {
        rect(x, y, w, h, tiles_1.T.FLOOR, s);
        rooms.push({ num, name, x, y, w, h });
    };
    // ---- Rooms ----
    room(1, "THRONE HALL", 26, 2, 20, 14, tiles_1.FS.MARBLE);
    room(2, "GREAT HALL", 29, 20, 14, 21, tiles_1.FS.MARBLE);
    room(3, "TRANSLOC. RM", 3, 3, 17, 13, tiles_1.FS.FLAG);
    room(4, "LIBRARY", 3, 20, 15, 11, tiles_1.FS.WOOD);
    room(5, "ARTIFICERY", 4, 36, 13, 10, tiles_1.FS.FLAG);
    room(6, "CHAPEL", 19, 47, 10, 7, tiles_1.FS.FLAG);
    room(7, "VESTIBULE", 31, 44, 10, 6, tiles_1.FS.MARBLE);
    room(8, "TREASURY", 52, 3, 8, 6, tiles_1.FS.MARBLE);
    room(9, "ARMORY", 62, 3, 7, 8, tiles_1.FS.FLAG);
    room(10, "BARRACKS", 53, 13, 16, 11, tiles_1.FS.WOOD);
    room(11, "GAOL", 53, 28, 16, 12, tiles_1.FS.COBBLE);
    room(12, "KITCHEN", 53, 43, 16, 8, tiles_1.FS.FLAG);
    // ---- Corridors ----
    const B = tiles_1.FS.BRICK;
    rect(21, 1, 2, 46, tiles_1.T.FLOOR, B);
    rect(20, 9, 1, 2, tiles_1.T.FLOOR, B);
    rect(18, 25, 3, 1, tiles_1.T.FLOOR, B);
    rect(17, 40, 4, 1, tiles_1.T.FLOOR, B);
    rect(23, 24, 6, 2, tiles_1.T.FLOOR, B);
    rect(23, 36, 6, 2, tiles_1.T.FLOOR, B);
    rect(49, 1, 2, 48, tiles_1.T.FLOOR, B);
    rect(43, 24, 6, 2, tiles_1.T.FLOOR, B);
    rect(43, 36, 6, 2, tiles_1.T.FLOOR, B);
    rect(46, 10, 3, 2, tiles_1.T.FLOOR, B);
    rect(51, 17, 2, 2, tiles_1.T.FLOOR, B);
    rect(65, 11, 2, 2, tiles_1.T.FLOOR, tiles_1.FS.FLAG);
    rect(51, 33, 2, 2, tiles_1.T.FLOOR, B);
    rect(51, 46, 2, 2, tiles_1.T.FLOOR, B);
    rect(35, 41, 2, 3, tiles_1.T.FLOOR, tiles_1.FS.MARBLE);
    // The way up to the surface (content/geography.ts): the halls are the first cellar floor. A short flagged hall
    // leaves the Vestibule to the south, and from its end the stair climbs south to the buried stair head above.
    // As built it is open: hall, then steps all the way.
    rect(geography_1.GATE_HALL.x, geography_1.GATE_HALL.y, geography_1.GATE_HALL.w, geography_1.GATE_HALL.h, tiles_1.T.FLOOR, tiles_1.FS.FLAG);
    rect(geography_1.GATE_STAIR.x, geography_1.GATE_STAIR.y, geography_1.GATE_STAIR.w, geography_1.GATE_STAIR.h, tiles_1.T.FLOOR, tiles_1.FS.STAIR);
    rect(29, 48, 2, 1, tiles_1.T.FLOOR, tiles_1.FS.FLAG);
    rect(34, 16, 4, 4, tiles_1.T.FLOOR, tiles_1.FS.MARBLE);
    rect(69, 46, 2, 2, tiles_1.T.FLOOR, tiles_1.FS.FLAG);
    set(51, 5, tiles_1.T.LOCKED, tiles_1.FS.MARBLE);
    // ---- Pillars ----
    for (const y of [22, 26, 30, 34, 38])
        for (const x of [31, 40])
            set(x, y, tiles_1.T.PILLAR);
    // The throne hall's colonnade stands a pillar every fourth row, like the great hall's. A pillar is drawn
    // three tiles tall, so any closer (they used to stand every third) and each base sits on the capital of
    // the pillar in front of it: one unbroken stack instead of a row of columns.
    for (const y of [5, 9, 13])
        for (const x of [29, 42])
            set(x, y, tiles_1.T.PILLAR);
    for (const [x, y] of [[40, 30], [31, 34], [42, 9], [29, 13]])
        tvar[y * exports.MW + x] = 1;
    // ---- Gaol cells ----
    for (let y = 28; y <= 39; y++)
        set(62, y, tiles_1.T.WALL);
    for (let x = 63; x <= 68; x++) {
        set(x, 31, tiles_1.T.WALL);
        set(x, 35, tiles_1.T.WALL);
    }
    set(62, 29, tiles_1.T.BARS);
    set(62, 37, tiles_1.T.BARS);
    set(62, 33, tiles_1.T.FLOOR, tiles_1.FS.COBBLE);
    const plan = grid.slice();
    // ---- Damage: collapses ----
    const R = tiles_1.T.RUBBLE;
    rect(21, 1, 2, 5, R);
    rect(49, 1, 2, 3, R);
    rect(34, 16, 4, 4, R);
    rect(44, 36, 3, 2, R);
    // the way up to the surface: the vault came down into it, and hall and stair are choked with rock and earth
    // from the Vestibule's wall to the top (the flags and the steps are still there under the fall: digging it out
    // from above clears them)
    rect(geography_1.GATE_PASSAGE.x, geography_1.GATE_PASSAGE.y, geography_1.GATE_PASSAGE.w, geography_1.GATE_PASSAGE.h, R);
    rect(69, 46, 2, 2, R);
    for (const [x, y] of [
        [43, 2], [44, 2], [45, 2], [44, 3], [45, 3], [45, 4], [43, 3],
        [26, 13], [26, 14], [27, 14], [26, 15], [27, 15], [28, 15],
        [3, 20], [4, 20], [3, 21],
        [68, 9], [68, 10], [67, 10],
        [68, 22], [68, 23], [67, 23],
        [34, 20], [37, 20],
        [49, 30], [22, 30],
        [33, 49], [38, 49],
        [27, 53], [28, 53],
    ])
        set(x, y, R);
    set(47, 10, tiles_1.T.CRACKED);
    set(47, 11, tiles_1.T.CRACKED);
    // ---- Props ----
    const props = [];
    const lights = [];
    const decals = [];
    const loose = [];
    const drips = [];
    const px = (tx) => tx * tiles_1.TS + 8;
    const py = (ty) => ty * tiles_1.TS + 16;
    const ids = new Set();
    const P = (kind, tx, ty, o = {}) => {
        let id = o.id ?? `${kind}@${tx},${ty}`;
        for (let n = 2; ids.has(id); n++)
            id = `${kind}@${tx},${ty}#${n}`;
        ids.add(id);
        const p = { kind, x: px(tx), y: py(ty), v: 0, ...o, id };
        props.push(p);
        const L = (0, props_1.propDef)(kind).light;
        if (L && (L.when === "always" || p.lit))
            lights.push({ x: p.x + L.dx, y: p.y + L.dy, rad: L.rad, col: L.col, int: L.int, flick: L.flick, owner: id });
        return p;
    };
    const D = (kind, x, y, v = 0, w, h) => decals.push({ kind, x, y, v, w, h });
    // Throne hall
    D("dais", 33 * tiles_1.TS, 2 * tiles_1.TS, 0, 6 * tiles_1.TS, 3 * tiles_1.TS);
    D("carpet", 35 * tiles_1.TS, 5 * tiles_1.TS, 0, 2 * tiles_1.TS, 11 * tiles_1.TS);
    D("carpet", 35 * tiles_1.TS, 20 * tiles_1.TS, 1, 2 * tiles_1.TS, 21 * tiles_1.TS);
    P("throne", 35.5, 3);
    P("maptable", 39.5, 5, { item: "schematic", itemZ: 12 });
    P("statue", 32, 3);
    P("statue", 39, 3, { v: 1 });
    P("statue_fallen", 27.5, 8);
    for (const x of [27, 31, 40])
        P("banner", x, 1, { v: x % 3 });
    P("brazier", 33, 12);
    P("brazier", 38, 12, { v: 1 });
    loose.push({ id: "crown", item: "crown", x: 33 * tiles_1.TS + 2, y: 6 * tiles_1.TS + 4 });
    // the sky through the broken roof: moonlight as authored, a sunbeam by day (`sky`)
    lights.push({ x: 31 * tiles_1.TS, y: 10 * tiles_1.TS, rad: 84, col: [0.55, 0.68, 1], int: 1.0, flick: 0.02, id: "moon", sky: true });
    lights.push({ x: 46 * tiles_1.TS + 8, y: 10 * tiles_1.TS + 16, rad: 30, col: [0.55, 0.68, 1], int: 0.35, flick: 0.02, sky: true });
    for (let i = 0; i < 14; i++)
        D("debris", 31 * tiles_1.TS + (rng() - 0.5) * 48, 10 * tiles_1.TS + (rng() - 0.5) * 40, (rng() * 4) | 0);
    D("bones", 41 * tiles_1.TS, 12 * tiles_1.TS, 0);
    // Great hall
    // (the four statues stand two pixels clear of the side walls: at the tile's centre their plinths were in the
    // masonry. Their ids are the ones they have always had.)
    P("statue", 29.125, 28, { id: "statue@29,28" });
    P("statue", 29.125, 32, { id: "statue@29,32", v: 1 });
    P("statue", 41.875, 28, { id: "statue@42,28" });
    P("statue", 41.875, 32, { id: "statue@42,32" });
    P("brazier", 33, 23, { lit: true });
    P("brazier", 38, 23);
    P("brazier", 33, 39);
    P("brazier", 38, 39, { lit: true });
    P("banner", 30, 19, { v: 1 });
    P("banner", 41, 19, { v: 2 });
    P("statue_fallen", 36, 31);
    for (let i = 0; i < 10; i++)
        D("debris", 35.5 * tiles_1.TS + (rng() - 0.5) * 64, 21 * tiles_1.TS + rng() * 20, (rng() * 4) | 0);
    // Vestibule
    P("fountain", 35.5, 46);
    P("statue", 32, 45);
    P("statue_fallen", 38.5, 45, { v: 1 });
    P("torch", 33, 43, { lit: true });
    P("torch", 38, 43);
    for (let i = 0; i < 12; i++)
        D("debris", 35.5 * tiles_1.TS + (rng() - 0.5) * 90, 49 * tiles_1.TS + rng() * 14, (rng() * 4) | 0);
    // Chapel
    // One axis: the banner on the wall, the altar under it, the pews facing them. (The altar used to stand a
    // tile and a half to the east of its pews, against the side door, and the banner a tile and a half to the
    // west. Both keep the ids they had, which saves and the tests know them by.)
    P("altar", 24.5, 48, { id: "altar@26,48", item: "glyph3", itemZ: 13 });
    lights.push({ x: 24.5 * tiles_1.TS + 8, y: 48 * tiles_1.TS + 8, rad: 58, col: [1, 0.7, 0.4], int: 0.6, flick: 0.15 });
    P("pew", 24.5, 50);
    P("pew", 24.5, 52);
    P("statue", 19.5, 52, { v: 1 });
    P("banner", 24.5, 46, { id: "banner@23,46", v: 0 });
    P("candles", 20, 49);
    // Artificery (start)
    P("cradle", 9, 37);
    P("forge", 5.5, 37);
    lights.push({ x: 5.5 * tiles_1.TS + 8, y: 37 * tiles_1.TS + 8, rad: 46, col: [1, 0.42, 0.18], int: 0.6, flick: 0.3 });
    P("workbench", 13.5, 37, { item: "chisel", itemZ: 12 });
    P("anvil", 6, 40);
    P("slab", 12.5, 43);
    P("parts", 15, 41);
    P("barrel", 15, 45);
    P("crate", 16, 44);
    P("crate", 16, 45, { v: 1 });
    P("bookshelf", 16, 36, { v: 1 });
    for (let i = 0; i < 6; i++)
        D("paper", 11 * tiles_1.TS + rng() * 64, 38 * tiles_1.TS + rng() * 40, (rng() * 3) | 0);
    D("scorch", 5.5 * tiles_1.TS, 38 * tiles_1.TS + 4, 0);
    // Library
    for (const x of [5, 6, 7, 9, 10, 11, 13, 14, 15, 16, 17])
        P("bookshelf", x, 20, { v: x % 2 ? 0 : 2 });
    for (const x of [5, 6, 7, 8, 11, 12, 13, 14])
        P("shelfrow", x, 23, { v: x % 3 });
    for (const x of [5, 6, 11, 12, 14])
        P("shelfrow", x, 26, { v: (x + 1) % 3 });
    P("shelf_fallen", 8, 27);
    P("table", 11, 29, { v: 1, item: "book_build", itemZ: 11 });
    P("chair_fallen", 12.5, 29.2);
    P("lectern", 5, 29, { item: "glyph1", itemZ: 12 });
    loose.push({ id: "book_repair", item: "book_repair", x: 9 * tiles_1.TS + 4, y: 28 * tiles_1.TS + 12 });
    P("mushrooms", 3, 30);
    D("puddle", 4 * tiles_1.TS, 27 * tiles_1.TS + 6, 0, 40, 18);
    D("puddle", 6 * tiles_1.TS + 6, 29 * tiles_1.TS + 4, 1, 30, 12);
    drips.push({ x: 5 * tiles_1.TS, y: 28 * tiles_1.TS }, { x: 7 * tiles_1.TS, y: 29 * tiles_1.TS + 8 });
    for (let i = 0; i < 18; i++)
        D("books", 4 * tiles_1.TS + rng() * 13 * tiles_1.TS, 21 * tiles_1.TS + rng() * 9 * tiles_1.TS, (rng() * 4) | 0);
    // Translocation room
    const ritual = { x: 11 * tiles_1.TS + 8, y: 9 * tiles_1.TS + 8 };
    P("torch", 7, 2, { lit: true });
    P("torch", 15, 2);
    P("candles", 6, 6);
    P("candles", 16, 13, { v: 1 });
    P("candles", 6, 13);
    P("ladder", 17, 6);
    P("bucket", 16, 4);
    P("skeleton", 18, 14, { v: 1 });
    lights.push({ x: ritual.x, y: ritual.y, rad: 70, col: [0.6, 0.38, 1], int: 0.28, flick: 0.06, id: "circle" });
    for (let i = 0; i < 10; i++)
        D("chalk", 5 * tiles_1.TS + rng() * 12 * tiles_1.TS, 4 * tiles_1.TS + rng() * 10 * tiles_1.TS, (rng() * 3) | 0);
    // Treasury: looted long ago. The aether core, the last thing it held, is
    // with its guardian (an NPC actor, spawned from `npcs` below).
    P("chest", 57, 4, { open: true });
    P("chest", 54, 4, { v: 2 });
    P("pot", 59, 8);
    P("pot", 52, 8, { v: 1 });
    loose.push({ id: "coin", item: "coin", x: 55 * tiles_1.TS + 8, y: 7 * tiles_1.TS + 8 });
    for (let i = 0; i < 12; i++)
        D("coins", 52 * tiles_1.TS + rng() * 8 * tiles_1.TS, 3 * tiles_1.TS + rng() * 6 * tiles_1.TS, (rng() * 3) | 0);
    // Armory
    P("limbrack", 65.5, 3, { item: "arm", itemZ: 10 });
    P("weaponrack", 63, 3);
    P("armorstand", 63, 7);
    P("armorstand", 67.5, 6, { v: 1 });
    lights.push({ x: 63 * tiles_1.TS, y: 9 * tiles_1.TS, rad: 40, col: [0.55, 0.65, 0.95], int: 0.4, flick: 0.02 });
    for (let i = 0; i < 6; i++)
        D("weapon", 62 * tiles_1.TS + rng() * 7 * tiles_1.TS, 4 * tiles_1.TS + rng() * 6 * tiles_1.TS, (rng() * 3) | 0);
    // Barracks
    for (const x of [54, 57, 60, 63, 68])
        P("bed", x, 14, { v: x % 2 });
    // the south row lies head to the south wall (bed v bit 1), so its footlockers stand at the foot like the north row's
    for (const x of [54, 57, 60, 63])
        P("bed", x, 23, { v: 2 + ((x + 1) % 2) });
    P("footlocker", 54, 15, { container: true });
    P("footlocker", 60, 15, { container: true });
    P("footlocker", 57, 21, { container: true });
    P("footlocker", 63, 21, { container: true, item: "glyph2" });
    P("table", 60.5, 18);
    P("chair", 58.6, 18);
    P("chair_fallen", 62.5, 19);
    P("torch", 57, 12, { lit: true });
    // Gaol
    P("skeleton", 65, 28, { v: 2 });
    P("skeleton", 66, 32, { container: true, item: "key" });
    P("skeleton", 64, 36, { v: 2 });
    P("mushrooms", 67, 39);
    P("table", 56, 30);
    P("chair", 57.6, 30.6);
    P("chains", 55, 27);
    P("chains", 59, 27);
    P("torch", 57, 27, { lit: true });
    P("barrel", 53, 39);
    P("bucket", 60, 38);
    P("brazier", 58, 35);
    D("bars_broken", 62 * tiles_1.TS, 33 * tiles_1.TS, 0);
    D("puddle", 55 * tiles_1.TS, 36 * tiles_1.TS, 0, 34, 14);
    drips.push({ x: 56 * tiles_1.TS, y: 36 * tiles_1.TS + 6 });
    for (let i = 0; i < 6; i++)
        D("bones", 53 * tiles_1.TS + rng() * 15 * tiles_1.TS, 28 * tiles_1.TS + rng() * 11 * tiles_1.TS, (rng() * 3) | 0);
    // Kitchen
    P("hearth", 60.5, 43, { container: true, item: "glyph0" });
    lights.push({ x: 60.5 * tiles_1.TS + 8, y: 43 * tiles_1.TS + 10, rad: 52, col: [1, 0.48, 0.22], int: 0.5, flick: 0.25 });
    P("longtable", 59.5, 47, { item: "goblet", itemZ: 9 });
    P("bench", 59.5, 45);
    P("bench", 59.5, 48);
    P("barrel", 53, 43);
    P("barrel", 54, 43, { v: 1 });
    P("crate", 67, 49);
    P("crate", 68, 50, { v: 1 });
    P("sack", 66, 50);
    P("sack", 53, 50);
    P("pot", 56, 43);
    P("bookshelf", 65, 43, { v: 3 });
    // Corridors
    for (const [x, y] of [[21, 15], [22, 33], [50, 9], [49, 27], [50, 42], [22, 44]])
        P("mushrooms", x, y);
    P("torch", 26, 23, { lit: true });
    P("torch", 46, 23);
    P("torch", 25, 35);
    D("puddle", 21 * tiles_1.TS, 20 * tiles_1.TS, 1, 28, 12);
    drips.push({ x: 21 * tiles_1.TS + 10, y: 20 * tiles_1.TS + 6 });
    D("puddle", 49 * tiles_1.TS + 4, 38 * tiles_1.TS, 0, 26, 16);
    drips.push({ x: 49 * tiles_1.TS + 16, y: 38 * tiles_1.TS + 8 });
    // ---- Procedural decals ----
    const G = (x, y) => (inb(x, y) ? grid[y * exports.MW + x] : tiles_1.T.WALL);
    // The scatter draws from one rng in reading order, so a tile that starts or stops being floor would re-roll
    // every crack, bone and cobweb after it. The throne hall's pillars were re-spaced after the scatter was
    // settled: the pass still walks those ten tiles as they lay before (the rows the pillars left get nothing,
    // the rows they moved to keep what they had, under the pillar), and the rest of the dungeon stays as it was.
    const key = (x, y) => y * exports.MW + x;
    const wasPillar = new Set([5, 8, 11, 14].flatMap((y) => [key(29, y), key(42, y)]));
    const nowPillar = new Set([5, 9, 13].flatMap((y) => [key(29, y), key(42, y)]));
    for (let y = 1; y < exports.MH - 1; y++)
        for (let x = 1; x < exports.MW - 1; x++) {
            const t = G(x, y);
            const k = key(x, y);
            if (wasPillar.has(k) || (t !== tiles_1.T.FLOOR && !(nowPillar.has(k) && !wasPillar.has(k))))
                continue;
            const bx = x * tiles_1.TS, by = y * tiles_1.TS;
            const r = rng();
            const nearRubble = [G(x - 1, y), G(x + 1, y), G(x, y - 1), G(x, y + 1)].some((n) => n === tiles_1.T.RUBBLE || n === tiles_1.T.CRACKED);
            if (nearRubble)
                for (let k = 0; k < 3; k++)
                    D("debris", bx + rng() * 16, by + rng() * 16, (rng() * 4) | 0);
            if (r < 0.07)
                D("crack", bx + rng() * 8, by + rng() * 8, (rng() * 4) | 0);
            else if (r < 0.12)
                D("debris", bx + rng() * 14, by + rng() * 14, (rng() * 4) | 0);
            else if (r < 0.13)
                D("bones", bx + 4, by + 6, (rng() * 3) | 0);
            if (G(x, y - 1) === tiles_1.T.WALL && G(x - 1, y) === tiles_1.T.WALL && rng() < 0.6)
                D("cobweb", bx, by, 0);
            if (G(x, y - 1) === tiles_1.T.WALL && G(x + 1, y) === tiles_1.T.WALL && rng() < 0.6)
                D("cobweb", bx, by, 1);
            const wallN = G(x - 1, y) === tiles_1.T.WALL || G(x + 1, y) === tiles_1.T.WALL || G(x, y - 1) === tiles_1.T.WALL;
            if (wallN && rng() < 0.12)
                D("moss", bx + rng() * 8, by + rng() * 8, (rng() * 3) | 0);
        }
    // ---- Ritual pedestals (one per socket; appended last so draw order is unchanged) ----
    (0, ritual_1.socketPositions)(ritual).forEach((s, i) => {
        const id = "ped" + i;
        ids.add(id);
        props.push({ id, kind: "pedestal", x: s.x, y: s.y + 4, v: 0 });
    });
    // The circle as a node of the rune network (content/runes.ts). No sprite, no collision.
    props.push({ id: "rune.dungeon", kind: "runesite", x: ritual.x, y: ritual.y, v: 0 });
    // ---- The choked SURFACE STAIR (added after the procedural pass, with its
    // own rng, so nothing else in the dungeon changes). Hall and flight are
    // heaped with boulders and fallen vault; rubble and spilled earth reach a
    // few tiles into the Vestibule; roots force their way through the broken
    // roof. No step shows from the Vestibule: where the hall opens into it there
    // is only the earth that poured in, and the toe of the fall lying on it
    // (`stairfall`, which says what lies behind). The earth stays when the
    // stair is dug out, trodden along the hall to the foot of the flight, so
    // the Vestibule's floor, the dirt and the first step are met in that order.
    // The flight stands between two cheek walls that end in a newel post each
    // (`stairpost`, `staircheek`: content/geography.ts STAIR_CHEEK). No night
    // air comes through: the daylight down the stair (`stairlight`) only burns
    // once it is dug out.
    {
        const gr = (0, rng_1.mulberry)(seed ^ 0x6a7e);
        const C = geography_1.GATE_CORRIDOR;
        for (const x of [C.x, C.x + C.w - 1])
            set(x, C.y - 1, R, tiles_1.FS.EARTH);
        const cx = (C.x + C.w / 2) * tiles_1.TS, top = C.y * tiles_1.TS;
        D("earthspill", cx, top - 10, 0, 76, 44);
        D("earthspill", cx - 20, top - 30, 1, 34, 20);
        D("earthspill", cx + 18, top - 26, 2, 30, 18);
        for (let i = 0; i < 16; i++)
            D("stones", cx + (gr() - 0.5) * 120, top - 6 - gr() * 52, (gr() * 4) | 0);
        for (let i = 0; i < 10; i++)
            D("debris", cx + (gr() - 0.5) * 100, top - 4 - gr() * 44, (gr() * 4) | 0);
        // (roots trail up to 22 px down from where they are placed: every one starts high enough to stay on the
        // Vestibule's floor or the gate's rubble, and none runs out across the top of the south wall)
        for (const [x, y, v] of [[C.x - 1.6, C.y - 1.5, 0], [C.x - 0.4, C.y - 1.45, 1], [C.x + C.w + 0.3, C.y - 1.5, 1], [C.x + C.w - 0.8, C.y - 1.2, 0], [C.x + 1.4, C.y - 2.2, 1]])
            D("rootfall", x * tiles_1.TS, y * tiles_1.TS, v);
        for (let i = 0; i < 5; i++)
            D("roots", cx + (gr() - 0.5) * 70, top - 18 - gr() * 20, 0);
        const piles = [
            [C.x + 0.3, C.y, 0], [C.x + 2.6, C.y + 0.2, 1], [C.x + 1.5, C.y + 1, 2], [C.x + 0.2, C.y + 2, 1], [C.x + 3, C.y + 2.4, 0],
            [C.x + 1.6, C.y + 3.2, 2], [C.x + 0.5, C.y + 4, 0], [C.x + 2.8, C.y + 4.2, 1], [C.x - 0.5, C.y - 1.9, 1], [C.x + C.w - 0.1, C.y - 1.8, 2],
        ];
        for (const [x, y, v] of piles)
            P("rockpile", x, y, { v });
        for (const [id, kind, y] of [["stairfall", "stairfall", top + 2], ["stairlight", "stairlight", top + 3 * tiles_1.TS]]) {
            ids.add(id);
            props.push({ id, kind, x: cx, y, v: 0 });
        }
        // earth where the hall opens (the stair's foot used to be drawn out here; it is dirt now) and along the hall,
        // thinning toward the flight, with the last crumbs of it on the first step
        D("earthspill", cx - 4, top - 13, 3, 50, 30);
        D("earthspill", cx + 2, top + 7, 4, 58, 24);
        D("earthspill", cx - 11, top + 22, 5, 24, 12);
        D("earthspill", cx + 14, top + geography_1.GATE_HALL.h * tiles_1.TS - 2, 6, 14, 8);
        for (const [x, y, v] of [[cx - 17, top + 9, 1], [cx + 15, top + 21, 2], [cx + 4, top + 5, 0], [cx - 12, top + geography_1.GATE_HALL.h * tiles_1.TS - 9, 3]])
            D("stones", x, y, v);
        // the stair's stonework: a newel post at the foot of each cheek wall (the east one broken off short), standing
        // in the hall with its feet on the flight's north edge, not down on the first step, and the cheek walls'
        // footprints up both sides of the flight from there
        const S = geography_1.GATE_STAIR, K = geography_1.STAIR_CHEEK, sy = S.y * tiles_1.TS;
        for (const [side, x0, dir, v] of [["w", S.x * tiles_1.TS, 1, 0], ["e", (S.x + S.w) * tiles_1.TS, -1, 1]]) {
            ids.add("stairpost." + side);
            ids.add("staircheek." + side);
            props.push({ id: "stairpost." + side, kind: "stairpost", x: x0 + (dir * K.post.w) / 2, y: sy + geography_1.STAIR_CHEEK_TOP, v });
            props.push({ id: "staircheek." + side, kind: "staircheek", x: x0 + (dir * K.wall.w) / 2, y: (S.y + S.h) * tiles_1.TS, v });
        }
        // the sky down the open stair (moonlight, or the sun by day): owned by `stairlight`, so dark until that is lit
        lights.push({ x: cx, y: top + 4 * tiles_1.TS, rad: 120, col: [0.55, 0.68, 1], int: 0.9, flick: 0.02, id: "gateleak", owner: "stairlight", sky: true });
    }
    // ---- The artificery and the armory, redone (fixed places, no rng, appended: no id, light or scatter above moves).
    // Artificery: the workshop where tools, runes and golems were made. Round the smelter its coal bin (and the coal
    // shovel's head, rusted through, on the floor beside it) and by the anvil a quench trough; a tool board on the
    // north wall with little left on it; in the south a rune-cutter's table whose last stone still glows, the slip
    // vat the worker bodies were cast from, and by it one unfinished body still on its casting stand.
    P("coalbin", 4, 37);
    P("quench", 4.5, 40);
    P("toolboard", 11.5, 35);
    P("runetable", 7.5, 45);
    P("clayvat", 4.25, 45);
    P("husk", 4.5, 42);
    loose.push({ id: "rusted_shovel", item: "head_shovel_rusted", x: 4 * tiles_1.TS + 14, y: 38 * tiles_1.TS + 12 });
    D("chalk", 6 * tiles_1.TS + 4, 44 * tiles_1.TS + 2, 1);
    D("chalk", 9 * tiles_1.TS + 6, 44 * tiles_1.TS + 8, 2);
    D("scorch", 6 * tiles_1.TS - 2, 41 * tiles_1.TS, 0);
    D("paper", 8 * tiles_1.TS + 4, 44 * tiles_1.TS + 6, 1);
    // Armory: it held racks of blades, rows of harness and the wardens' staves. Time took most of it: a second
    // rack stands all but empty, the pegs on the wall hold one sword, the staff rack one dead staff, a bare stand
    // waits in the corner, and what fell has rusted into a heap. One old axe head is still worth mending.
    P("wallhooks", 67.75, 2, { v: 1 });
    P("weaponrack", 67.25, 4.25, { v: 1 });
    P("staffrack", 62.75, 5.5);
    P("armorstand", 62.5, 9.5, { v: 2 });
    P("armorpile", 66.75, 8);
    loose.push({ id: "rusted_axe", item: "head_axe_rusted", x: 64 * tiles_1.TS + 10, y: 6 * tiles_1.TS + 8 });
    D("weapon", 65 * tiles_1.TS + 2, 8 * tiles_1.TS + 6, 1);
    D("weapon", 63 * tiles_1.TS + 9, 9 * tiles_1.TS + 2, 2);
    // ---- NPCs (no rng, no props: nothing above changes). The Treasury Guardian
    // slumps against the treasury's north wall between the two looted chests,
    // facing the door; its body box (content/npcs.ts) keeps rows 5-8 and the
    // doorway at 51,5 clear. A dormant worker golem (no NPCS row, so no dialogue:
    // its `npc` names its actor definition) is parked in the artificery's alcove
    // between the forge and the cradle, against the north wall, facing the room.
    // Its 8x4 box leaves row 38 (start, cradle, forge, workbench) and the exit
    // corridor at 17,40 open (tests/rollout.test.ts checks the routes).
    const npcs = [
        { id: "npc.guardian", npc: "guardian", x: 55.5 * tiles_1.TS + 8, y: 4 * tiles_1.TS + 10, facing: "down" },
        { id: exports.ARTIFICERY_WORKER.id, npc: exports.ARTIFICERY_WORKER.npc, x: exports.ARTIFICERY_WORKER.x, y: exports.ARTIFICERY_WORKER.y, facing: "down" },
    ];
    return {
        id: "dungeon", w: exports.MW, h: exports.MH,
        grid, plan, style, tvar, rooms, props, decals, lights, loose, ritual, drips, npcs,
        // The stair's upper end: walk south off the top of the flight and you come out of the stair head on the surface
        // (and back). Shut until the stair is dug out. The spot (in the Vestibule, where the hall to the stair opens)
        // is for whoever finds the way in later.
        portals: [{
                id: geography_1.ENTRANCES.surface_stair.below.portal, x: geography_1.GATE_STAIR.x * tiles_1.TS + 2, y: (geography_1.GATE_STAIR.y + geography_1.GATE_STAIR.h) * tiles_1.TS - 10, w: geography_1.GATE_STAIR.w * tiles_1.TS - 4, h: 10, dir: "down",
                to: { area: geography_1.ENTRANCES.surface_stair.above.area, portal: geography_1.ENTRANCES.surface_stair.above.portal },
                arrive: { x: (geography_1.GATE_STAIR.x + geography_1.GATE_STAIR.w / 2) * tiles_1.TS, y: (geography_1.GATE_STAIR.y + geography_1.GATE_STAIR.h) * tiles_1.TS - 14 },
                flag: geography_1.ENTRANCES.surface_stair.flag, label: "THE HALLS: FIRST CELLAR",
            }],
        spots: [{ id: "stairfoot", kind: "door", x: (geography_1.GATE_PASSAGE.x + geography_1.GATE_PASSAGE.w / 2) * tiles_1.TS, y: geography_1.GATE_PASSAGE.y * tiles_1.TS - 4, facing: "up" }],
        start: { x: 9 * tiles_1.TS + 8, y: 38 * tiles_1.TS + 14 },
        exits: [
            { x: 22, y: 1, label: "UPPER WARD", dir: "n" },
            { x: 50, y: 1, label: "TOWER", dir: "n" },
            { x: geography_1.GATE_EXIT.x, y: geography_1.GATE_EXIT.y, label: "SURFACE STAIR", dir: "s" },
            { x: 71, y: 47, label: "CELLARS", dir: "e" },
        ],
    };
}
