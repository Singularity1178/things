"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AREAS = void 0;
// Area registry: area id -> deterministic builder. Saves store only per-area
// diffs against these builders, so builders must be deterministic.
const map_1 = require("../map");
const surface_1 = require("../surface");
const town_1 = require("../town");
const townInteriors_1 = require("../townInteriors");
exports.AREAS = {
    dungeon: map_1.buildDungeon,
    surface: surface_1.buildSurface,
    // Westwake, the market town west of the surface, and the six rooms behind its shop doors.
    town: town_1.buildTown,
    ...townInteriors_1.INTERIOR_BUILDERS,
};
