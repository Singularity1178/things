"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildFoundationArea = buildFoundationArea;
const tiles_1 = require("../content/tiles");
function buildFoundationArea(id) {
    const w = 16, h = 10, grid = new Uint8Array(w * h).fill(tiles_1.T.FLOOR);
    for (let y = 0; y < h; y++)
        for (let x = 0; x < w; x++)
            if (!x || !y || x === w - 1 || y === h - 1)
                grid[y * w + x] = tiles_1.T.WALL;
    const yard = id === "debug_yard";
    return {
        id, w, h, grid, plan: grid.slice(), style: new Uint8Array(w * h).fill(yard ? tiles_1.FS.GRASS : tiles_1.FS.FLAG), tvar: new Uint8Array(w * h),
        rooms: [], lights: [], decals: [], loose: [], drips: [], exits: [], outdoor: yard, ambient: [0.48, 0.45, 0.5],
        start: { x: 7 * tiles_1.TS + 8, y: 7 * tiles_1.TS + 11 },
        props: [
            { id: `rune.${id}`, kind: "runesite", x: 3 * tiles_1.TS + 8, y: 5 * tiles_1.TS + 11, v: 0 },
            ...(yard ? [
                { id: "tree.fixture", kind: "tree", x: 9 * tiles_1.TS + 8, y: 5 * tiles_1.TS + 14, v: 0 },
                { id: "rock.fixture", kind: "rock", x: 11 * tiles_1.TS + 8, y: 7 * tiles_1.TS + 14, v: 0 },
            ] : [
                { id: "bench.fixture", kind: "workbench", x: 10 * tiles_1.TS + 8, y: 4 * tiles_1.TS + 14, v: 0 },
                { id: "chest.fixture", kind: "storage_chest", x: 11 * tiles_1.TS + 8, y: 5 * tiles_1.TS + 14, v: 0, recipe: "storage_chest" },
            ]),
        ],
    };
}
