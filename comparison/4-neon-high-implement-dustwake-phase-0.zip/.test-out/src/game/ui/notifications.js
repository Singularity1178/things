"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationFeed = exports.TOAST_DURATION = void 0;
const MAX_HISTORY = 64;
exports.TOAST_DURATION = 5.5;
class NotificationFeed {
    constructor() {
        Object.defineProperty(this, "items", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "drawerOpen", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "seq", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        Object.defineProperty(this, "now", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
    }
    /** Returns whether `settings` dictates pausing the simulation for this alert. */
    shouldPause(item, settings) {
        if (item.severity === "alert" && settings.pauseOnAlert)
            return true;
        if (item.category === "worker" && item.severity === "warn" && settings.pauseOnJobBlocked)
            return true;
        if (item.category === "day" && settings.pauseOnDayPhase)
            return true;
        return false;
    }
    /**
     * Push a new notification into the feed.
     * Returns `{ item, pause }` where `pause` is true if pause-on-alert triggered.
     */
    push(opts, settings) {
        const item = {
            id: this.seq++,
            title: opts.title,
            detail: opts.detail,
            severity: opts.severity ?? "info",
            category: opts.category ?? "world",
            worldTime: opts.worldTime ?? 0,
            createdAt: this.now,
            area: opts.area,
            x: opts.x,
            y: opts.y,
            read: false,
            dismissed: false,
        };
        const pause = settings ? this.shouldPause(item, settings) : false;
        item.causedPause = pause;
        this.items.unshift(item);
        if (this.items.length > MAX_HISTORY)
            this.items.length = MAX_HISTORY;
        return { item, pause };
    }
    tick(dt) {
        this.now += dt;
    }
    /** Active live toast notifications (recent & not dismissed). */
    liveToasts(limit = 4) {
        return this.items
            .filter((it) => !it.dismissed && this.now - it.createdAt < exports.TOAST_DURATION)
            .slice(0, limit);
    }
    toastAlpha(it) {
        const age = this.now - it.createdAt;
        if (age < 0.15)
            return Math.max(0, age / 0.15);
        if (age > exports.TOAST_DURATION - 0.6)
            return Math.max(0, (exports.TOAST_DURATION - age) / 0.6);
        return 1;
    }
    unreadCount() {
        return this.items.reduce((n, it) => n + (it.read ? 0 : 1), 0);
    }
    markRead(id) {
        const it = this.items.find((x) => x.id === id);
        if (it)
            it.read = true;
    }
    dismiss(id) {
        const it = this.items.find((x) => x.id === id);
        if (it) {
            it.dismissed = true;
            it.read = true;
        }
    }
    markAllRead() {
        for (const it of this.items)
            it.read = true;
    }
    clear() {
        this.items = [];
    }
}
exports.NotificationFeed = NotificationFeed;
