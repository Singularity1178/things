"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DIALOGUE_LINES = exports.DIALOGUE_COLS = exports.DIALOGUE_BOX = void 0;
exports.layoutDialogue = layoutDialogue;
const zoom_1 = require("../view/zoom");
const textWrap_1 = require("./textWrap");
/** Font metrics: 3 px glyphs on a 4 px advance, 5 px tall; drawTextS adds a 1 px shadow right and down. */
const ADVANCE = 4, GLYPH_H = 5, SHADOW = 1;
/** The box, in UI-layer pixels (relative offsets are from the box's top-left). */
exports.DIALOGUE_BOX = {
    x: 14, w: zoom_1.BASE_W - 28, h: 54, y: zoom_1.BASE_H - 54 - 6,
    /** Text inset from the left edge; the same margin is kept on the right. */
    padX: 10,
    /** First text line's top, and the line pitch. */
    textY: 8, lineH: 10,
    /** Top of the footer row ("ESC LEAVE" / "E >"). */
    footerY: 54 - 9,
};
/** Characters per line: n characters with their shadow take n * 4 px of the inset text width. */
exports.DIALOGUE_COLS = Math.floor((exports.DIALOGUE_BOX.w - 2 * exports.DIALOGUE_BOX.padX) / ADVANCE);
/** Lines per screen: the last line (glyph + shadow) must end at least 1 px above the footer row. */
exports.DIALOGUE_LINES = Math.floor((exports.DIALOGUE_BOX.footerY - 2 - (GLYPH_H + SHADOW - 1) - exports.DIALOGUE_BOX.textY) / exports.DIALOGUE_BOX.lineH) + 1;
/** Wrap and paginate authored pages into screens. Beats stay with the first / last screen of their page. */
function layoutDialogue(pages, cols = exports.DIALOGUE_COLS, perPage = exports.DIALOGUE_LINES) {
    const out = [];
    pages.forEach((p, source) => {
        const chunks = (0, textWrap_1.paginate)((0, textWrap_1.wrapText)(p.text, cols), perPage);
        chunks.forEach((lines, i) => {
            const s = { lines, source };
            if (p.speaker)
                s.speaker = p.speaker;
            if (i === 0 && p.beat)
                s.beat = p.beat;
            if (i === chunks.length - 1 && p.then)
                s.then = p.then;
            out.push(s);
        });
    });
    return out;
}
