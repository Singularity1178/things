"use strict";
// Screen stack. The top screen receives update (and therefore input); rendering
// starts at the highest opaque screen and draws upward, so overlays (pack,
// schematic, later management screens) sit on top of whatever is beneath.
// Screens that simulate (play, cutscenes) step the world themselves; overlays
// pause the world simply by being on top.
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScreenStack = void 0;
class ScreenStack {
    constructor() {
        Object.defineProperty(this, "stack", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
    }
    get top() { return this.stack[this.stack.length - 1]; }
    get size() { return this.stack.length; }
    is(id) { return this.top?.id === id; }
    has(id) { return this.stack.some((s) => s.id === id); }
    /** Replace the whole stack (scene change). */
    set(s) { this.stack = [s]; s.t = 0; }
    push(s) { this.stack.push(s); s.t = 0; }
    pop() { if (this.stack.length > 1)
        this.stack.pop(); }
    /** Drop every overlay above the base scene. */
    popToBase() { this.stack.length = Math.min(this.stack.length, 1); }
    update(dt) {
        const top = this.top;
        if (!top)
            return;
        top.t += dt;
        top.update(dt);
    }
    render() {
        let i = this.stack.length - 1;
        while (i > 0 && !this.stack[i].opaque)
            i--;
        for (; i < this.stack.length; i++)
            this.stack[i].render();
    }
}
exports.ScreenStack = ScreenStack;
