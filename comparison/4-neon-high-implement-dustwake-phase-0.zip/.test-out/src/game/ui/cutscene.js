"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.timeline = timeline;
exports.controlAt = controlAt;
exports.beatsCrossed = beatsCrossed;
exports.trackAt = trackAt;
const cache = new WeakMap();
/** The beats with their absolute start times. */
function timeline(c) {
    let tl = cache.get(c);
    if (!tl) {
        let at = 0;
        tl = c.beats.map((b, index) => ({ ...b, at: (at += b.wait), index }));
        cache.set(c, tl);
    }
    return tl;
}
/** When control is handed over (the `control` beat, else the last beat). */
function controlAt(c) {
    const tl = timeline(c);
    return (tl.find((b) => b.control) ?? tl[tl.length - 1])?.at ?? 0;
}
/** Beats starting in (t0, t]: what a frame from t0 to t must fire, in order. */
function beatsCrossed(c, t0, t) {
    return timeline(c).filter((b) => b.at > t0 && b.at <= t);
}
/** A track's mode at time t, how long it has held, and its ramp progress 0..1 (1 for modes without `over`). */
function trackAt(c, key, t) {
    let mode = c.start[key], from = 0, over = 0;
    for (const b of timeline(c)) {
        if (b.at > t)
            break;
        const m = b[key];
        if (m !== undefined) {
            mode = m;
            from = b.at;
            over = b.over ?? 0;
        }
    }
    const since = t - from;
    return { mode, since, k: over > 0 ? Math.max(0, Math.min(1, since / over)) : 1 };
}
