"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InputManager = exports.UI2_H = exports.UI2_W = void 0;
const settings_1 = require("../settings");
exports.UI2_W = 640;
exports.UI2_H = 360;
const DRAG_THRESHOLD = 6; // in 2x UI px
const DBL_CLICK_MS = 350;
class InputManager {
    constructor(settings = settings_1.settingsStore) {
        Object.defineProperty(this, "pointer", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: {
                x: -1, y: -1, x1: -1, y1: -1, wx: 0, wy: 0,
                inside: false, down: false, rightDown: false,
                pressed: false, released: false, clicked: false, doubleClicked: false, rightClicked: false,
                wheel: 0, consumed: false, wheelConsumed: false,
                drag: null, dragFinished: null,
            }
        });
        Object.defineProperty(this, "downOrigin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "lastClick", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { x: -999, y: -999, t: 0 }
        });
        Object.defineProperty(this, "padPrev", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Set()
        });
        Object.defineProperty(this, "settings", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.settings = settings;
    }
    /** Update world coordinates from the current camera + view size. */
    syncWorld(camX, camY, vw, vh) {
        const p = this.pointer;
        p.wx = camX + (p.x / exports.UI2_W) * vw;
        p.wy = camY + (p.y / exports.UI2_H) * vh;
        if (p.drag) {
            p.drag.curX = p.x;
            p.drag.curY = p.y;
            p.drag.curWx = p.wx;
            p.drag.curWy = p.wy;
        }
    }
    onPointerMove(nx, ny, camX, camY, vw, vh) {
        const p = this.pointer;
        p.inside = true;
        p.x = nx;
        p.y = ny;
        p.x1 = nx / 2;
        p.y1 = ny / 2;
        this.syncWorld(camX, camY, vw, vh);
        if (p.down && this.downOrigin && !p.drag) {
            const dist = Math.hypot(p.x - this.downOrigin.x, p.y - this.downOrigin.y);
            if (dist >= DRAG_THRESHOLD) {
                p.drag = {
                    active: true,
                    startX: this.downOrigin.x, startY: this.downOrigin.y,
                    curX: p.x, curY: p.y,
                    startWx: this.downOrigin.wx, startWy: this.downOrigin.wy,
                    curWx: p.wx, curWy: p.wy,
                };
            }
        }
    }
    onPointerDown(button, nx, ny, camX, camY, vw, vh, now = Date.now()) {
        this.onPointerMove(nx, ny, camX, camY, vw, vh);
        const p = this.pointer;
        if (button === 0) {
            p.down = true;
            p.pressed = true;
            this.downOrigin = { x: p.x, y: p.y, wx: p.wx, wy: p.wy, t: now };
        }
        else if (button === 2) {
            p.rightDown = true;
            p.rightClicked = true;
        }
    }
    onPointerUp(button, nx, ny, camX, camY, vw, vh, now = Date.now()) {
        this.onPointerMove(nx, ny, camX, camY, vw, vh);
        const p = this.pointer;
        if (button === 0) {
            p.down = false;
            p.released = true;
            if (p.drag) {
                const d = p.drag;
                p.dragFinished = {
                    x0: Math.min(d.startX, d.curX), y0: Math.min(d.startY, d.curY),
                    x1: Math.max(d.startX, d.curX), y1: Math.max(d.startY, d.curY),
                    wx0: Math.min(d.startWx, d.curWx), wy0: Math.min(d.startWy, d.curWy),
                    wx1: Math.max(d.startWx, d.curWx), wy1: Math.max(d.startWy, d.curWy),
                };
                p.drag = null;
            }
            else if (this.downOrigin) {
                p.clicked = true;
                if (now - this.lastClick.t <= DBL_CLICK_MS && Math.hypot(p.x - this.lastClick.x, p.y - this.lastClick.y) <= 10) {
                    p.doubleClicked = true;
                }
                this.lastClick = { x: p.x, y: p.y, t: now };
            }
            this.downOrigin = null;
        }
        else if (button === 2) {
            p.rightDown = false;
        }
    }
    onPointerLeave() {
        this.pointer.inside = false;
    }
    onWheel(deltaY) {
        this.pointer.wheel += deltaY;
    }
    /** Clear per-frame edge triggers after all screens/HUD have processed the frame. */
    endFrame() {
        const p = this.pointer;
        p.pressed = false;
        p.released = false;
        p.clicked = false;
        p.doubleClicked = false;
        p.rightClicked = false;
        p.wheel = 0;
        p.consumed = false;
        p.wheelConsumed = false;
        p.dragFinished = null;
    }
    /** Consume mouse click/hover for the rest of the frame (used by modals/bars). */
    consumePointer() {
        this.pointer.consumed = true;
    }
    /** Consume mouse wheel (used by scrollable lists so the world doesn't zoom behind them). */
    consumeWheel() {
        if (this.pointer.wheelConsumed)
            return 0;
        const w = this.pointer.wheel;
        if (w !== 0)
            this.pointer.wheelConsumed = true;
        return w;
    }
    // ---- Remappable action checks
    actionDown(action, keys) {
        for (const k of this.settings.keysFor(action)) {
            if (keys.has(k))
                return true;
        }
        return false;
    }
    actionHit(action, pressed) {
        for (const k of this.settings.keysFor(action)) {
            if (pressed.has(k))
                return true;
        }
        return false;
    }
    /**
     * Poll connected HTML5 Gamepad and inject equivalent keys into `keys` / `pressed`
     * so every screen in the ScreenStack automatically supports gamepad parity.
     */
    pollGamepad(keys, pressed) {
        if (typeof navigator === "undefined" || typeof navigator.getGamepads !== "function")
            return;
        const pads = navigator.getGamepads();
        const gp = pads?.find((p) => p && p.connected);
        const active = new Set();
        if (gp) {
            const dead = 0.35;
            const ax = gp.axes[0] ?? 0, ay = gp.axes[1] ?? 0;
            const btn = (i) => !!gp.buttons[i]?.pressed;
            if (ax < -dead || btn(14))
                active.add("arrowleft");
            if (ax > dead || btn(15))
                active.add("arrowright");
            if (ay < -dead || btn(12))
                active.add("arrowup");
            if (ay > dead || btn(13))
                active.add("arrowdown");
            if (btn(0))
                active.add("e"); // A -> interact / confirm
            if (btn(1))
                active.add("escape"); // B -> cancel / back
            if (btn(2))
                active.add(" "); // X -> slam / attack
            if (btn(3))
                active.add("i"); // Y -> pack
            if (btn(4))
                active.add("-"); // LB -> speed down
            if (btn(5))
                active.add("="); // RB -> speed up
            if (btn(9))
                active.add("o"); // Start -> settings
            if (btn(8))
                active.add("f"); // Select -> floors
        }
        for (const k of active) {
            if (!this.padPrev.has(k))
                pressed.add(k);
            keys.add(k);
        }
        for (const k of this.padPrev) {
            if (!active.has(k))
                keys.delete(k);
        }
        this.padPrev = active;
    }
}
exports.InputManager = InputManager;
