"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FOREST_GROUNDS = exports.CAMP = exports.IRON_VEINS = exports.Zone = exports.CART_T = exports.RUNE_CLEAR_PROPS = exports.RUNE_ART_R = exports.RUNE_T = exports.SH = exports.SW = void 0;
exports.vnoise = vnoise;
exports.buildSurface = buildSurface;
// The surface above the buried dungeon, as an area definition. Pure,
// deterministic builder (no DOM): fixed seed, stable prop ids (kind@tx,ty).
//
// Layout story: the keep that once stood here is gone, sunk and buried. Soil
// heaped over its halls and walls, then the wild took it: meadow, dense woods,
// rocky ground and damp hollows, all on uneven, noise-shaped land. The buried
// footprint only shows if you look for it. Low earth humps sit over the halls
// and grassy banks run along the old wall courses (both warped, so they never
// match the plan exactly). A handful of moss-eaten remains break the turf. To
// the south the old SURFACE GATE lies under plain-looking ground. Nothing glows
// except the rune circle, which sits in a small clearing of bare earth.
const rng_1 = require("./core/rng");
const tiles_1 = require("./content/tiles");
const props_1 = require("./content/props");
const geography_1 = require("./content/geography");
const reach_1 = require("./sim/reach");
const map_1 = require("./map");
exports.SW = 96, exports.SH = 72;
const SURFACE_SEED = 7331;
/** Rune circle centre tile. */
exports.RUNE_T = { x: 48, y: 26 };
/** Radius (px) of the rune circle's own art; the builder keeps decals clear of it (plus a margin). */
exports.RUNE_ART_R = 64;
/** No builder prop is placed within this many tiles of the rune centre (sprites never overlap the circle). */
exports.RUNE_CLEAR_PROPS = 7;
exports.CART_T = { x: 72, y: 36 };
var Zone;
(function (Zone) {
    Zone[Zone["MEADOW"] = 0] = "MEADOW";
    Zone[Zone["WOODS"] = 1] = "WOODS";
    Zone[Zone["ROCKY"] = 2] = "ROCKY";
    Zone[Zone["HOLLOW"] = 3] = "HOLLOW";
    Zone[Zone["CLEARING"] = 4] = "CLEARING";
    Zone[Zone["GATE"] = 5] = "GATE";
})(Zone || (exports.Zone = Zone = {}));
/** Smoothstepped value noise in [0, 1] at cell size k. */
function vnoise(x, y, k, s) {
    const fx = x / k, fy = y / k, x0 = Math.floor(fx), y0 = Math.floor(fy);
    let tx = fx - x0, ty = fy - y0;
    tx = tx * tx * (3 - 2 * tx);
    ty = ty * ty * (3 - 2 * ty);
    const a = (0, rng_1.hash2)(x0, y0, s), b = (0, rng_1.hash2)(x0 + 1, y0, s), c = (0, rng_1.hash2)(x0, y0 + 1, s), d = (0, rng_1.hash2)(x0 + 1, y0 + 1, s);
    return (a + (b - a) * tx) * (1 - ty) + (c + (d - c) * tx) * ty;
}
/** Three octaves, roughly [0.1, 0.9], mean 0.5. */
const fbm = (x, y, s) => 0.5 * vnoise(x, y, 13, s) + 0.3 * vnoise(x, y, 6, s + 1) + 0.2 * vnoise(x, y, 3, s + 2);
/**
 * `westRoad: false` leaves out the old road to Westwake (the wild exactly as it
 * was before the town existed; the art regression test bakes that one).
 */
/** How many iron veins the surface holds (three pieces of ore each; they do not grow back). */
exports.IRON_VEINS = 12;
/** The hunters' camp: the fire's place (px), in the clearing in the north-west wood. */
exports.CAMP = { x: 360, y: 176 };
/** Hunting blinds and foraging grounds (tiles), in the west woods, never in sight of the rune or the stair. */
exports.FOREST_GROUNDS = {
    hunt: [[8, 7], [15, 11], [11, 16], [7, 21], [10, 43], [12, 46], [29, 56], [20, 4]],
    forage: [[9, 6], [14, 13], [10, 18], [6, 22], [26, 12], [9, 45], [11, 47], [28, 58], [16, 9]],
};
function buildSurface(opts = {}) {
    const rng = (0, rng_1.mulberry)(SURFACE_SEED);
    const n = exports.SW * exports.SH;
    const grid = new Uint8Array(n).fill(tiles_1.T.FLOOR);
    const style = new Uint8Array(n).fill(tiles_1.FS.GRASS);
    const tvar = new Uint8Array(n);
    const zone = new Uint8Array(n);
    const inb = (x, y) => x >= 0 && y >= 0 && x < exports.SW && y < exports.SH;
    const G = (x, y) => (inb(x, y) ? grid[y * exports.SW + x] : tiles_1.T.THICKET);
    const dRune = (x, y) => Math.hypot(x - exports.RUNE_T.x, y - exports.RUNE_T.y);
    const inGate = (x, y, m = 0) => x >= geography_1.SURFACE_GATE_ZONE.x0 - m && x <= geography_1.SURFACE_GATE_ZONE.x1 + m && y >= geography_1.SURFACE_GATE_ZONE.y0 - m && y <= geography_1.SURFACE_GATE_ZONE.y1 + m;
    // ---- what lies beneath: the dungeon's undamaged plan, sampled through a
    // gentle warp so the land follows the footprint without copying it.
    const dg = (0, map_1.buildDungeon)();
    const under = new Int8Array(n).fill(-1); // -1 outside the footprint, 0 buried wall mass, 1 buried hall/corridor
    for (let y = 0; y < exports.SH; y++)
        for (let x = 0; x < exports.SW; x++) {
            const ux = x - geography_1.DUNGEON_TO_SURFACE.dx + Math.round((vnoise(x, y, 7, 210) - 0.5) * 3.2);
            const uy = y - geography_1.DUNGEON_TO_SURFACE.dy + Math.round((vnoise(x, y, 7, 211) - 0.5) * 3.2);
            if (ux < 0 || uy < 0 || ux >= dg.w || uy >= dg.h)
                continue;
            under[y * exports.SW + x] = dg.plan[uy * dg.w + ux] === tiles_1.T.WALL ? 0 : 1;
        }
    const U = (x, y) => (inb(x, y) ? under[y * exports.SW + x] : -1);
    /** A buried wall course: wall mass right next to a buried hall. */
    const wallLine = (x, y) => U(x, y) === 0 && (U(x - 1, y) === 1 || U(x + 1, y) === 1 || U(x, y - 1) === 1 || U(x, y + 1) === 1);
    // ---- land: zones from layered noise, the world's edge closed by thicket
    for (let y = 0; y < exports.SH; y++)
        for (let x = 0; x < exports.SW; x++) {
            const i = y * exports.SW + x;
            const edge = Math.min(x, y, exports.SW - 1 - x, exports.SH - 1 - y);
            if (edge < 2 + Math.floor(fbm(x, y, 220) * 7 - 0.6)) {
                grid[i] = tiles_1.T.THICKET;
                continue;
            }
            const wood = fbm(x, y, 201), wet = fbm(x, y, 202), rock = fbm(x, y, 203), dr = dRune(x, y);
            let z;
            if (inGate(x, y))
                z = Zone.GATE;
            else if (dr < 6.2 + (vnoise(x, y, 3, 205) - 0.5) * 1.6)
                z = Zone.CLEARING;
            else if (Math.hypot(x - exports.CART_T.x - 1, y - exports.CART_T.y) < 3.2)
                z = Zone.MEADOW;
            else if (wet > 0.6 && !wallLine(x, y))
                z = Zone.HOLLOW;
            else if (wood > 0.55)
                z = Zone.WOODS;
            else if (rock > 0.58)
                z = Zone.ROCKY;
            else
                z = Zone.MEADOW;
            zone[i] = z;
            let s = tiles_1.FS.GRASS;
            const pn = vnoise(x, y, 4, 206);
            switch (z) {
                case Zone.CLEARING:
                    s = dr < 4.6 ? tiles_1.FS.EARTH : pn > 0.62 ? tiles_1.FS.MOSS : tiles_1.FS.GRASS;
                    break;
                case Zone.GATE:
                    s = x === geography_1.SURFACE_GATE_ZONE.x0 || x === geography_1.SURFACE_GATE_ZONE.x1 ? tiles_1.FS.MOSS : tiles_1.FS.GRASS;
                    break;
                case Zone.HOLLOW:
                    s = wet > 0.67 ? tiles_1.FS.MUD : pn > 0.3 ? tiles_1.FS.MOSS : tiles_1.FS.GRASS;
                    break;
                case Zone.WOODS:
                    s = wet > 0.5 && pn > 0.58 ? tiles_1.FS.MOSS : pn < 0.12 ? tiles_1.FS.GRASS : tiles_1.FS.LEAF;
                    break;
                case Zone.ROCKY:
                    s = pn > 0.58 ? tiles_1.FS.EARTH : pn > 0.36 ? tiles_1.FS.DIRT : tiles_1.FS.GRASS;
                    break;
                default: s = vnoise(x, y, 5, 62) > 0.78 ? tiles_1.FS.DIRT : pn > 0.84 ? tiles_1.FS.MOSS : tiles_1.FS.GRASS;
            }
            // soil banked over the buried wall courses: bare earth in places, moss where stone lies shallow
            if (wallLine(x, y) && z !== Zone.CLEARING && z !== Zone.GATE) {
                const b = vnoise(x, y, 4, 215);
                if (b > 0.6)
                    s = tiles_1.FS.EARTH;
                else if (b < 0.24)
                    s = tiles_1.FS.MOSS;
            }
            style[i] = s;
        }
    // seal nothing: any floor not connected to the rune becomes part of the thicket
    {
        const seen = new Uint8Array(n), q = [exports.RUNE_T.y * exports.SW + exports.RUNE_T.x];
        seen[q[0]] = 1;
        while (q.length) {
            const k = q.pop(), x = k % exports.SW, y = (k / exports.SW) | 0;
            for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
                const nx = x + dx, ny = y + dy, nk = ny * exports.SW + nx;
                if (inb(nx, ny) && !seen[nk] && grid[nk] === tiles_1.T.FLOOR) {
                    seen[nk] = 1;
                    q.push(nk);
                }
            }
        }
        for (let k = 0; k < n; k++)
            if (grid[k] === tiles_1.T.FLOOR && !seen[k])
                grid[k] = tiles_1.T.THICKET;
    }
    // the entrance zone is always open ground
    for (let y = geography_1.SURFACE_GATE_ZONE.y0; y <= geography_1.SURFACE_GATE_ZONE.y1; y++)
        for (let x = geography_1.SURFACE_GATE_ZONE.x0; x <= geography_1.SURFACE_GATE_ZONE.x1; x++)
            grid[y * exports.SW + x] = tiles_1.T.FLOOR;
    const plan = grid.slice();
    const props = [], lights = [], decals = [], loose = [];
    const ids = new Set();
    /** Blocking footprints (tiles touched by a collision box). Every blocking prop keeps a one-tile free ring, so no pockets can form. */
    const occ = new Uint8Array(n);
    /** Tiles holding a non-blocking sprite (ferns, grass), so they don't stack. */
    const deco = new Uint8Array(n);
    /** Tiles where nothing blocking may stand: the entrance, the cart's clearing, trails. */
    const noBlock = new Uint8Array(n);
    const mark = (arr, cx, cy, r) => {
        for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++)
            for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++)
                if (inb(x, y) && Math.hypot(x - cx, y - cy) <= r)
                    arr[y * exports.SW + x] = 1;
    };
    for (let y = geography_1.SURFACE_GATE_ZONE.y0 - 1; y <= geography_1.SURFACE_GATE_ZONE.y1 + 1; y++)
        for (let x = geography_1.SURFACE_GATE_ZONE.x0 - 1; x <= geography_1.SURFACE_GATE_ZONE.x1 + 1; x++)
            if (inb(x, y))
                noBlock[y * exports.SW + x] = 1;
    mark(noBlock, exports.CART_T.x + 1.5, exports.CART_T.y + 0.5, 3.2);
    // game trails (never drawn): keep the woods open between the rune, the cart and the old gate
    const trail = (ax, ay, bx, by, s) => {
        const len = Math.hypot(bx - ax, by - ay), nx = -(by - ay) / len, ny = (bx - ax) / len;
        for (let t = 0; t <= len; t += 0.5) {
            const f = t / len, wob = (vnoise(t, s, 6, 250) - 0.5) * 6 * Math.sin(f * Math.PI);
            mark(noBlock, ax + (bx - ax) * f + nx * wob, ay + (by - ay) * f + ny * wob, 1.1);
        }
    };
    trail(exports.RUNE_T.x, exports.RUNE_T.y + 5, geography_1.SURFACE_GATE.x, geography_1.SURFACE_GATE_ZONE.y0 - 1, 1);
    trail(exports.RUNE_T.x + 5, exports.RUNE_T.y + 1, exports.CART_T.x - 1, exports.CART_T.y, 2);
    trail(exports.RUNE_T.x - 5, exports.RUNE_T.y + 2, 30, 34, 3);
    const footprint = (kind, px, py) => {
        const b = (0, props_1.propDef)(kind).box;
        if (!b)
            return null;
        return { x0: Math.floor((px - b[0] / 2) / tiles_1.TS), x1: Math.floor((px + b[0] / 2 - 0.01) / tiles_1.TS), y0: Math.floor((py - b[1]) / tiles_1.TS), y1: Math.floor((py - 0.01) / tiles_1.TS) };
    };
    const tooNearRune = (px, py) => Math.hypot(px - (exports.RUNE_T.x * tiles_1.TS + 8), py - (exports.RUNE_T.y * tiles_1.TS + 8)) < exports.RUNE_CLEAR_PROPS * tiles_1.TS;
    /** Can a prop stand at (px, py)? Blocking ones need floor under the box and a free floor ring around it. */
    const canPlace = (kind, px, py, strict = true) => {
        if (tooNearRune(px, py))
            return false;
        const tx = Math.floor(px / tiles_1.TS), ty = Math.floor((py - 1) / tiles_1.TS);
        if (!inb(tx, ty) || G(tx, ty) !== tiles_1.T.FLOOR)
            return false;
        const f = footprint(kind, px, py);
        if (!f)
            return !deco[ty * exports.SW + tx] && !occ[ty * exports.SW + tx];
        for (let y = f.y0 - 1; y <= f.y1 + 1; y++)
            for (let x = f.x0 - 1; x <= f.x1 + 1; x++) {
                if (!inb(x, y) || G(x, y) !== tiles_1.T.FLOOR || occ[y * exports.SW + x])
                    return false;
                const inside = x >= f.x0 && x <= f.x1 && y >= f.y0 && y <= f.y1;
                if (inside && (noBlock[y * exports.SW + x] && strict))
                    return false;
                if (inside && (deco[y * exports.SW + x] || inGate(x, y)))
                    return false;
            }
        return true;
    };
    const P = (kind, px, py, o = {}) => {
        const tx = Math.floor(px / tiles_1.TS), ty = Math.floor((py - 1) / tiles_1.TS);
        let id = o.id ?? `${kind}@${tx},${ty}`;
        for (let k = 2; ids.has(id); k++)
            id = `${kind}@${tx},${ty}#${k}`;
        ids.add(id);
        const p = { kind, x: Math.round(px), y: Math.round(py), v: 0, ...o, id };
        props.push(p);
        const f = footprint(kind, p.x, p.y);
        if (f) {
            for (let y = f.y0; y <= f.y1; y++)
                for (let x = f.x0; x <= f.x1; x++)
                    if (inb(x, y))
                        occ[y * exports.SW + x] = 1;
        }
        else if (inb(tx, ty))
            deco[ty * exports.SW + tx] = 1;
        const L = (0, props_1.propDef)(kind).light;
        if (L && (L.when === "always" || p.lit))
            lights.push({ x: p.x + L.dx, y: p.y + L.dy, rad: L.rad, col: L.col, int: L.int, flick: L.flick, owner: id });
        return p;
    };
    /** Tile anchor -> px, with an optional sub-tile jitter so nothing lines up on the grid. */
    const at = (tx, ty, jitter = 0) => ({
        x: tx * tiles_1.TS + 8 + (jitter ? Math.round(((0, rng_1.hash2)(tx, ty, 260) - 0.5) * 2 * jitter) : 0),
        y: ty * tiles_1.TS + 16 - (jitter ? Math.round((0, rng_1.hash2)(tx, ty, 261) * jitter * 0.6) : 0),
    });
    // ---- the rune circle (dormant, dark and overgrown until the dungeon rune wakes it)
    const rc = { x: exports.RUNE_T.x * tiles_1.TS + 8, y: exports.RUNE_T.y * tiles_1.TS + 8 };
    props.push({ id: "rune.surface", kind: "runecircle", x: rc.x, y: rc.y, v: 0 });
    // No baseline glow: presentation drives this light from 0 (dormant) to full.
    lights.push({ x: rc.x, y: rc.y, rad: 78, col: [0.6, 0.38, 1], int: 0.75, flick: 0.06, id: "runeglow" });
    // ---- the buried stair head: walkable, flat markers only. The halls below are the first cellar floor; the floor
    // that stood here is gone under the grass, and of it only what was warded survives: the rune circle, and the
    // glyph on this stair's lintel. The prop is centred on the stair (between its two middle tiles) and is the dig
    // site (content/digging.ts): dug out, it is the open stairwell, entered from its south lip (the portal below).
    const gate = { x: (geography_1.SURFACE_GATE_CORRIDOR.x + geography_1.SURFACE_GATE_CORRIDOR.w / 2) * tiles_1.TS, y: (geography_1.SURFACE_GATE.y + 1) * tiles_1.TS };
    const stairHead = P("buriedgate", gate.x, gate.y);
    // the ward glyph's glow: owned by the stair head, so it is dark until that is lit (when the stair is dug out)
    lights.push({ x: gate.x, y: gate.y - 47, rad: 40, col: [0.62, 0.5, 1], int: 0.45, flick: 0.05, id: "wardglow", owner: stairHead.id });
    const cor = geography_1.SURFACE_GATE_CORRIDOR, wL = geography_1.SURFACE_GATE_ZONE.x0, wR = geography_1.SURFACE_GATE_ZONE.x1;
    P("capstone", wL * tiles_1.TS + 9, (cor.y + 1) * tiles_1.TS + 15);
    P("capstone", wR * tiles_1.TS + 7, (cor.y + 3) * tiles_1.TS + 14, { v: 1 });
    // ---- the few remains that still break the surface (on buried walls and halls)
    const remains = [
        ["wallstub", 41, 22, 0], ["wallstub", 70, 18, 1], ["masonry", 58, 15, 0], ["masonry", 25, 37, 1],
        ["stoneslab", 50, 39, 0], ["statue_toppled", 22, 15, 0], ["statue_toppled", 77, 41, 1],
        ["standingstone", 44, 12, 0], ["standingstone", 53, 10, 1], ["cairn", 30, 47, 1],
    ];
    const placedRemains = [];
    for (const [kind, tx, ty, v] of remains) {
        const a = at(tx, ty);
        if (canPlace(kind, a.x, a.y, false))
            placedRemains.push(P(kind, a.x, a.y, { v }));
    }
    // ---- the cart and the basket it spilled
    P("cart", exports.CART_T.x * tiles_1.TS + 8, exports.CART_T.y * tiles_1.TS + 16);
    loose.push({ id: "basket", item: "basket", x: 75 * tiles_1.TS + 4, y: 37 * tiles_1.TS + 10 });
    // ---- vegetation: visit tiles in a shuffled order so nothing grows on a lattice
    const order = Array.from({ length: n }, (_, i) => i);
    for (let i = n - 1; i > 0; i--) {
        const j = (rng() * (i + 1)) | 0;
        const t = order[i];
        order[i] = order[j];
        order[j] = t;
    }
    const tryPlace = (kind, tx, ty, v, jitter = 4) => {
        const a = at(tx, ty, jitter);
        if (!canPlace(kind, a.x, a.y))
            return false;
        P(kind, a.x, a.y, { v });
        return true;
    };
    for (const i of order) {
        const x = i % exports.SW, y = (i / exports.SW) | 0;
        if (grid[i] !== tiles_1.T.FLOOR)
            continue;
        const z = zone[i];
        if (z === Zone.CLEARING)
            continue;
        const r = rng(), clump = vnoise(x, y, 4, 230), rockN = fbm(x, y, 203), wl = wallLine(x, y);
        if (z === Zone.GATE) {
            // taller weeds along the two buried wall lines; nothing else
            if ((x === wL || x === wR) && r < 0.4)
                tryPlace("tallgrass", x, y, 2, 3);
            continue;
        }
        let c = 0;
        const pick = (p) => { c += p; return r < c; };
        switch (z) {
            case Zone.WOODS:
                if (pick(0.12 + 0.5 * clump))
                    tryPlace("tree", x, y, (rng() * 3) | 0);
                else if (pick(0.07))
                    tryPlace("bush", x, y, (rng() * 4) | 0);
                else if (pick(0.04))
                    tryPlace("sapling", x, y, (rng() * 2) | 0);
                else if (pick(0.02))
                    tryPlace("log", x, y, (rng() * 3) | 0, 3);
                else if (pick(0.012))
                    tryPlace("stump", x, y, (rng() * 2) | 0);
                else if (pick(0.016))
                    tryPlace("rock", x, y, 2 + ((rng() * 2) | 0));
                else if (pick(0.26))
                    tryPlace("fern", x, y, (rng() * 3) | 0, 5);
                break;
            case Zone.HOLLOW:
                if (pick(0.22))
                    tryPlace("fern", x, y, (rng() * 3) | 0, 5);
                else if (pick(0.1))
                    tryPlace("tallgrass", x, y, (rng() * 2) | 0, 5);
                else if (pick(0.05 * (0.5 + clump)))
                    tryPlace("tree", x, y, 2);
                else if (pick(0.05))
                    tryPlace("bush", x, y, 2 + ((rng() * 2) | 0));
                else if (pick(0.015))
                    tryPlace("log", x, y, (rng() * 3) | 0, 3);
                else if (pick(0.012))
                    tryPlace("boulder", x, y, 1);
                break;
            case Zone.ROCKY: {
                const rk = Math.max(0, rockN - 0.5) * 2.2 * (0.4 + clump);
                if (pick(0.16 * rk))
                    tryPlace("rock", x, y, (rng() * 2) | 0);
                else if (pick(0.06 * rk))
                    tryPlace("boulder", x, y, (rng() * 3) | 0);
                else if (pick(rockN > 0.66 ? 0.03 : 0))
                    tryPlace("outcrop", x, y, (rng() * 2) | 0, 2);
                else if (pick(0.03))
                    tryPlace("tree", x, y, (rng() * 3) | 0);
                else if (pick(0.035))
                    tryPlace("bush", x, y, (rng() * 4) | 0);
                else if (pick(0.04))
                    tryPlace("tallgrass", x, y, (rng() * 3) | 0, 5);
                else if (pick(0.03))
                    tryPlace("fern", x, y, (rng() * 3) | 0, 5);
                break;
            }
            default: // meadow
                if (pick(0.035 * clump))
                    tryPlace("tree", x, y, (rng() * 3) | 0);
                else if (pick(0.035 * (0.4 + clump)))
                    tryPlace("bush", x, y, (rng() * 4) | 0);
                else if (pick(0.012))
                    tryPlace("sapling", x, y, (rng() * 2) | 0);
                else if (pick(0.005))
                    tryPlace("stump", x, y, (rng() * 2) | 0);
                else if (pick(0.006))
                    tryPlace("rock", x, y, (rng() * 4) | 0);
                else if (pick((wl ? 0.16 : 0.05) * (0.5 + clump)))
                    tryPlace("tallgrass", x, y, (rng() * 3) | 0, 5);
        }
    }
    // ---- safety net: blocking props keep a free ring, so this should never fire;
    // if a pocket ever appears, open it by removing the vegetation around it.
    const blockBoxes = () => props.flatMap((p) => {
        const b = (0, props_1.propDef)(p.kind).box;
        return b ? [[p.x - b[0] / 2, p.y - b[1], p.x + b[0] / 2, p.y]] : [];
    });
    for (let pass = 0; pass < 4; pass++) {
        const boxes = blockBoxes();
        const reach = (0, reach_1.reachable)({ w: exports.SW, h: exports.SH, grid }, boxes, { x: rc.x, y: rc.y + 4 });
        const sealed = [];
        for (let k = 0; k < n; k++)
            if (!reach[k] && grid[k] === tiles_1.T.FLOOR && !occ[k])
                sealed.push(k);
        if (!sealed.length)
            break;
        const near = (p) => sealed.some((k) => Math.abs((k % exports.SW) * tiles_1.TS + 8 - p.x) < 40 && Math.abs(((k / exports.SW) | 0) * tiles_1.TS + 8 - p.y) < 40);
        const keep = new Set(placedRemains);
        for (let i = props.length - 1; i >= 0; i--) {
            const p = props[i];
            if ((0, props_1.propDef)(p.kind).box && !keep.has(p) && p.kind !== "cart" && near(p))
                props.splice(i, 1);
        }
        occ.fill(0);
        for (const p of props) {
            const f = footprint(p.kind, p.x, p.y);
            if (f)
                for (let y = f.y0; y <= f.y1; y++)
                    for (let x = f.x0; x <= f.x1; x++)
                        occ[y * exports.SW + x] = 1;
        }
    }
    // ---- decals, in three layers: land shape, ground cover, small plants
    const D = (kind, x, y, v = 0, w, h) => decals.push({ kind, x: Math.round(x), y: Math.round(y), v, w, h });
    /** Decals stay off the rune circle's footprint: nothing there the rune's own plants wouldn't explain. */
    const clearOfRune = (x, y, rad) => Math.hypot(x - rc.x, y - rc.y) > exports.RUNE_ART_R + 6 + rad;
    const jit = (s) => (rng() - 0.5) * s;
    // land shape: humps over the buried halls, low banks along the wall courses, hollows, canopy shade
    for (let y = 1; y < exports.SH - 1; y++)
        for (let x = 1; x < exports.SW - 1; x++) {
            const i = y * exports.SW + x;
            if (grid[i] !== tiles_1.T.FLOOR || zone[i] === Zone.GATE)
                continue;
            const bx = x * tiles_1.TS + 8, by = y * tiles_1.TS + 8, h = (0, rng_1.hash2)(x, y, 240);
            if (under[i] === 1 && h < 0.05) {
                const w = 26 + rng() * 44, hh = 12 + rng() * 14;
                if (clearOfRune(bx, by, w / 2))
                    D("hump", bx + jit(10), by + jit(8), style[i] === tiles_1.FS.EARTH || zone[i] === Zone.ROCKY ? 1 : 0, w, hh);
            }
            else if (wallLine(x, y) && h < 0.34 && vnoise(x, y, 5, 241) > 0.3) {
                const w = 18 + rng() * 14;
                if (clearOfRune(bx, by, w / 2))
                    D("hump", bx + jit(6), by + jit(6), style[i] === tiles_1.FS.EARTH ? 1 : 0, w, 9 + rng() * 6);
            }
            else if (zone[i] === Zone.HOLLOW && h > 0.95) {
                if (clearOfRune(bx, by, 30))
                    D("hollow", bx + jit(8), by + jit(8), 0, 30 + rng() * 30, 16 + rng() * 14);
            }
        }
    for (const p of props)
        if (p.kind === "tree" && (0, rng_1.hash2)(p.x, p.y, 242) < 0.65 && clearOfRune(p.x + 6, p.y - 12, 28))
            D("shade", p.x + 6 + jit(6), p.y - 12 + jit(4), 0, 44 + rng() * 14);
    // the buried stair, readable only if you look: two parallel low banks over its side walls. Between them the
    // ground is square-cut, not a round dent: the stair head's own kerb shows through the grass (the prop's sprite).
    {
        const top = geography_1.SURFACE_GATE_ZONE.y0 * tiles_1.TS + 4, len = (geography_1.SURFACE_GATE.y - geography_1.SURFACE_GATE_ZONE.y0) * tiles_1.TS + 4;
        D("ridge", wL * tiles_1.TS + 8, top, 1, len, 10);
        D("ridge", wR * tiles_1.TS + 8, top + 6, 1, len - 6, 10);
    }
    // ground cover
    for (let y = 1; y < exports.SH - 1; y++)
        for (let x = 1; x < exports.SW - 1; x++) {
            const i = y * exports.SW + x;
            if (grid[i] !== tiles_1.T.FLOOR)
                continue;
            const bx = x * tiles_1.TS, by = y * tiles_1.TS, r = rng(), s = style[i];
            if (!clearOfRune(bx + 8, by + 8, 14))
                continue;
            if (zone[i] === Zone.GATE) {
                if ((x === wL || x === wR) && r < 0.45)
                    D("mosspatch", bx + 8 + jit(6), by + 8 + jit(10), 1, 10 + rng() * 8);
                continue;
            }
            if (s === tiles_1.FS.MOSS) {
                if (r < 0.12)
                    D("mosspatch", bx + 8 + jit(8), by + 8 + jit(8), (rng() * 2) | 0, 10 + rng() * 14);
            }
            else if (s === tiles_1.FS.LEAF) {
                if (r < 0.4)
                    D("leaves", bx + 8 + jit(6), by + 8 + jit(6), 0);
                else if (r < 0.45)
                    D("mosspatch", bx + 8, by + 8, 0, 10 + rng() * 10);
            }
            else if (s === tiles_1.FS.MUD) {
                if (r < 0.06)
                    D("puddle", bx + jit(6), by + 4 + jit(4), (rng() * 2) | 0, 14 + rng() * 14, 6 + rng() * 4);
                else if (r < 0.1)
                    D("pebbles", bx + 8, by + 8, 0);
            }
            else if (s === tiles_1.FS.EARTH) {
                if (r < 0.09)
                    D("pebbles", bx + 8 + jit(6), by + 8 + jit(6), 0);
            }
            else if (s === tiles_1.FS.DIRT) {
                if (r < 0.06)
                    D("pebbles", bx + 8, by + 8, 0);
                else if (r < 0.09)
                    D("debris", bx + rng() * 12, by + rng() * 12, (rng() * 4) | 0);
            }
            else if (r < 0.025)
                D("mosspatch", bx + 8 + jit(8), by + 8 + jit(8), 1, 8 + rng() * 10);
        }
    // small plants
    const meadowFlowers = (x, y) => vnoise(x, y, 5, 270) > 0.62;
    for (let y = 1; y < exports.SH - 1; y++)
        for (let x = 1; x < exports.SW - 1; x++) {
            const i = y * exports.SW + x;
            if (grid[i] !== tiles_1.T.FLOOR)
                continue;
            const bx = x * tiles_1.TS, by = y * tiles_1.TS, r = rng(), s = style[i], z = zone[i];
            if (!clearOfRune(bx + 8, by + 8, 10))
                continue;
            if (z === Zone.GATE) {
                // sparse grass in the sunken strip, thick weeds along the buried walls
                if (x === wL || x === wR) {
                    if (r < 0.7)
                        D("weeds", bx + 8 + jit(8), by + 12 + jit(6), 0);
                }
                else if (r < 0.06)
                    D("tuft", bx + 3 + rng() * 10, by + 6 + rng() * 9, 0);
                continue;
            }
            if (wallLine(x, y) && r < 0.22) {
                D("weeds", bx + 8 + jit(10), by + 12 + jit(8), 0);
                continue;
            }
            if (s === tiles_1.FS.GRASS) {
                if (z === Zone.MEADOW && meadowFlowers(x, y) && r < 0.16)
                    D("wildflowers", bx + 8 + jit(8), by + 8 + jit(8), (vnoise(x, y, 9, 271) * 4) | 0);
                else if (r < 0.3)
                    D("tuft", bx + 3 + rng() * 10, by + 6 + rng() * 9, 0);
                else if (r < 0.34)
                    D("flowers", bx + 8, by + 8, (rng() * 4) | 0);
                if (rng() < 0.12)
                    D("tuft", bx + 3 + rng() * 10, by + 6 + rng() * 9, 0);
            }
            else if (s === tiles_1.FS.MOSS) {
                if (r < 0.1)
                    D("tuft", bx + 3 + rng() * 10, by + 6 + rng() * 9, 0);
                else if (r < 0.13)
                    D("flowers", bx + 8, by + 8, 0);
            }
            else if (s === tiles_1.FS.LEAF) {
                if (r < 0.05)
                    D("tuft", bx + 3 + rng() * 10, by + 6 + rng() * 9, 0);
            }
            else if (s === tiles_1.FS.MUD) {
                if (r < 0.08)
                    D("weeds", bx + 8 + jit(8), by + 12, 0);
            }
            else if (r < 0.1)
                D("tuft", bx + 3 + rng() * 10, by + 6 + rng() * 9, 0);
        }
    // roots at tree feet; moss, ivy and weeds creeping over the remains
    for (const p of props) {
        if ((p.kind === "tree" || p.kind === "stump") && rng() < 0.6)
            D("roots", p.x - 4 + jit(4), p.y - 4, 0);
        if (placedRemains.includes(p)) {
            for (let k = 0; k < 4; k++)
                D("ivy", p.x + jit(28), p.y - 2 + jit(6), (rng() * 4) | 0, 10 + rng() * 14);
            for (let k = 0; k < 2; k++)
                D("mosspatch", p.x + jit(30), p.y + jit(8), (rng() * 2) | 0, 10 + rng() * 10);
            D("weeds", p.x + jit(20), p.y + 2, 0);
        }
    }
    // ---- the old road west, to the village the Treasury Guardian remembers (now the
    // market town of Westwake: town.ts). Cut last, with no rng, so nothing else in
    // the wild moves: three rows of thicket open into a rutted earth track that runs
    // off the west edge, the track's line fades a few tiles into the meadow, and a
    // leaning waymark stands at its mouth. No light: only the rune glows up here.
    const portals = [], exits = [];
    if (opts.westRoad !== false) {
        const { y0, y1 } = geography_1.WEST_ROAD.surface, mid = (y0 + y1) >> 1;
        let mouth = exports.SW, far = 1;
        for (let y = y0; y <= y1; y++) {
            let x = 1;
            for (; x < exports.SW - 1 && grid[y * exports.SW + x] === tiles_1.T.THICKET; x++) {
                grid[y * exports.SW + x] = tiles_1.T.FLOOR;
                plan[y * exports.SW + x] = tiles_1.T.FLOOR;
                style[y * exports.SW + x] = y === mid || (0, rng_1.hash2)(x, y, 280) < 0.6 ? tiles_1.FS.EARTH : tiles_1.FS.DIRT;
            }
            mouth = Math.min(mouth, x);
            far = Math.max(far, x);
        }
        // the worn line carries on into the open ground (ground style only: no prop is touched)
        for (let x = mouth; x < far + 9; x++) {
            const y = mid + Math.round((vnoise(x, 3, 5, 281) - 0.5) * 2.4);
            for (const yy of [y, y + ((0, rng_1.hash2)(x, y, 282) < 0.5 ? 1 : -1)])
                if (inb(x, yy) && grid[yy * exports.SW + x] === tiles_1.T.FLOOR && dRune(x, yy) > 9)
                    style[yy * exports.SW + x] = yy === y ? tiles_1.FS.EARTH : tiles_1.FS.DIRT;
        }
        D("ruts", tiles_1.TS, mid * tiles_1.TS + 8, 0, (far + 5) * tiles_1.TS);
        for (let x = 1; x < far + 6; x++) {
            if ((0, rng_1.hash2)(x, 7, 283) < 0.5)
                D("pebbles", x * tiles_1.TS + 8, mid * tiles_1.TS + 4 + (0, rng_1.hash2)(x, 8, 284) * 10, 0);
            for (const y of [y0, y1])
                if ((0, rng_1.hash2)(x, y, 285) < 0.7)
                    D("weeds", x * tiles_1.TS + 3 + (0, rng_1.hash2)(x, y, 286) * 10, y * tiles_1.TS + (y === y0 ? 7 : 15), 0);
        }
        // the wood has been closing over the cut for years: ferns and long grass crowd both edges (no rng; nothing blocks)
        for (let x = 1; x < mouth; x++)
            for (const y of [y0, y1]) {
                const h = (0, rng_1.hash2)(x, y, 287);
                if (h > 0.82)
                    continue;
                const kind = h < 0.45 ? "fern" : "tallgrass", px = x * tiles_1.TS + 3 + Math.round((0, rng_1.hash2)(x, y, 288) * 10), py = y === y0 ? y * tiles_1.TS + 6 + Math.round((0, rng_1.hash2)(x, y, 289) * 4) : (y + 1) * tiles_1.TS - Math.round((0, rng_1.hash2)(x, y, 289) * 3);
                const id = `${kind}.road@${x},${y}`;
                ids.add(id);
                props.push({ id, kind, x: px, y: py, v: Math.floor(h * 40) % 3 });
                if (h < 0.3)
                    D("mosspatch", px, y === y0 ? y * tiles_1.TS + 3 : (y + 1) * tiles_1.TS - 3, 1, 10 + Math.floor(h * 30));
                if (h > 0.5)
                    D("leaves", px + 4, y === y0 ? y * tiles_1.TS + 5 : (y + 1) * tiles_1.TS - 6, 0);
            }
        // the waymark stands on ground that was thicket a moment ago, so it can never sit on a tree
        const wx = Math.max(2, mouth - 1);
        ids.add("waymark.west");
        props.push({ id: "waymark.west", kind: "waymark", x: wx * tiles_1.TS + 9, y: y0 * tiles_1.TS + 12, v: 0 });
        D("mosspatch", wx * tiles_1.TS + 8, y0 * tiles_1.TS + 12, 1, 12);
        portals.push({
            id: geography_1.WEST_ROAD.portal, x: tiles_1.TS, y: y0 * tiles_1.TS, w: tiles_1.TS + 4, h: (y1 - y0 + 1) * tiles_1.TS, dir: "left",
            to: { area: "town", portal: "east_road" }, arrive: { x: 2 * tiles_1.TS + 10, y: mid * tiles_1.TS + 12 }, label: "THE OLD ROAD",
        });
        exits.push({ x: 0, y: mid, label: "WESTWAKE", dir: "w" });
    }
    // ---- iron: rocks veined with ore, in the rocky ground first. Placed last and by hash, never by the rng, so
    // nothing else in the wild moves; each keeps the free ring every blocking prop has, so no pocket can form.
    if (opts.iron !== false) {
        const cand = [];
        for (let y = 2; y < exports.SH - 2; y++)
            for (let x = 2; x < exports.SW - 2; x++) {
                const z = zone[y * exports.SW + x];
                if (grid[y * exports.SW + x] !== tiles_1.T.FLOOR || z === Zone.GATE || z === Zone.CLEARING)
                    continue;
                cand.push([(0, rng_1.hash2)(x, y, 301) + (z === Zone.ROCKY ? 0 : 1), x, y]);
            }
        cand.sort((a, b) => a[0] - b[0] || a[2] - b[2] || a[1] - b[1]);
        const veins = [];
        for (const [, x, y] of cand) {
            if (veins.length >= exports.IRON_VEINS)
                break;
            if (dRune(x, y) < 8 || veins.some((v) => Math.hypot(v.x - x, v.y - y) < 5))
                continue;
            const a = at(x, y, 3);
            if (!canPlace("ironore", a.x, a.y))
                continue;
            P("ironore", a.x, a.y, { v: Math.floor((0, rng_1.hash2)(x, y, 302) * 3) });
            veins.push({ x, y });
        }
    }
    // ---- the hunters' camp (content/folk.ts: the forest's people). In the clearing in the north-west wood, well
    // away from the rune and the stair, out of sight of anyone arriving by the circle. Placed after everything else
    // and by fixed positions, never by the rng, so nothing else in the wild moves; each prop takes the nearest place
    // it can stand within a few px. `camp: false` leaves it out (the wild as it was).
    const spots = [{ id: "stairhead", kind: "door", x: gate.x, y: gate.y + 7, facing: "up" }];
    if (opts.camp !== false) {
        const place = (kind, id, px, py, o = {}) => {
            for (let r = 0; r <= 24; r += 4)
                for (const [dx, dy] of r ? [[r, 0], [-r, 0], [0, r], [0, -r], [r, r], [-r, -r], [r, -r], [-r, r]] : [[0, 0]]) {
                    if (canPlace(kind, px + dx, py + dy, false))
                        return P(kind, px + dx, py + dy, { ...o, id });
                }
            return null;
        };
        const C = exports.CAMP;
        place("campfire", "camp.fire", C.x, C.y, { lit: true });
        place("leanto", "camp.leanto", C.x - 42, C.y - 22);
        place("peltrack", "camp.rack", C.x + 72, C.y - 4);
        place("seatlog", "camp.log", C.x, C.y + 24);
        const beds = [[C.x - 44, C.y + 14], [C.x + 42, C.y - 24], [C.x + 46, C.y + 22]];
        // a sleeper's feet a little below the bedroll: the head lies on the pillow (its north end), the blanket over the wool
        beds.forEach(([x, y], i) => { const b = place("bedroll", `camp.bed.${i + 1}`, x, y, { v: i }); if (b)
            spots.push({ id: `bed.${i + 1}`, kind: "bed", x: b.x, y: b.y + 2, facing: "down" }); });
        // where people stand: the nearest tile with floor under it and nothing solid on it or beside it
        const stand = (id, kind, tx, ty, facing = "down") => {
            for (let r = 0; r <= 4; r++)
                for (let dy = -r; dy <= r; dy++)
                    for (let dx = -r; dx <= r; dx++) {
                        if (Math.max(Math.abs(dx), Math.abs(dy)) !== r)
                            continue;
                        const x = tx + dx, y = ty + dy;
                        if (![-1, 0, 1].every((i) => inb(x + i, y) && G(x + i, y) === tiles_1.T.FLOOR && !occ[y * exports.SW + x + i]))
                            continue;
                        if (!inb(x, y - 1) || occ[(y - 1) * exports.SW + x])
                            continue;
                        spots.push({ id, kind, x: x * tiles_1.TS + 8, y: y * tiles_1.TS + 12, facing });
                        return;
                    }
        };
        const ft = { x: Math.floor(C.x / tiles_1.TS), y: Math.floor((C.y - 1) / tiles_1.TS) };
        stand("camp.w", "camp", ft.x - 2, ft.y, "right");
        stand("camp.e", "camp", ft.x + 2, ft.y, "left");
        stand("camp.s", "camp", ft.x, ft.y + 2, "up");
        stand("camp.n", "camp", ft.x, ft.y - 2, "down");
        exports.FOREST_GROUNDS.hunt.forEach(([x, y], i) => stand(`hunt.${i + 1}`, "hunt", x, y));
        exports.FOREST_GROUNDS.forage.forEach(([x, y], i) => stand(`forage.${i + 1}`, "forage", x, y));
    }
    // ---- the stair head's south lip: once the stair is dug out, pushing north into the stairwell from here walks
    // down into the halls (and coming up out of them sets you down here). Shut until then (the entrance's flag).
    const stair = geography_1.ENTRANCES.surface_stair;
    portals.push({
        id: stair.above.portal, x: gate.x - 26, y: gate.y, w: 52, h: 10, dir: "up",
        to: { area: stair.below.area, portal: stair.below.portal }, arrive: { x: gate.x, y: gate.y + 7 }, flag: stair.flag, label: "THE SURFACE",
    });
    return {
        id: "surface", w: exports.SW, h: exports.SH, grid, plan, style, tvar, rooms: [], props, decals, lights, loose,
        start: { x: rc.x, y: rc.y + 4 }, exits, drips: [], outdoor: true, ambient: [0.32, 0.31, 0.42], portals,
        // where someone looking for the way in ends up (data only, like the town's spots), and the camp's places
        spots,
    };
}
