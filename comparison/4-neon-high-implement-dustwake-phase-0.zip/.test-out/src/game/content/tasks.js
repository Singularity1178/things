"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TASK_KINDS = exports.SLAM_RADIUS = exports.SLAM_HIT = void 0;
/** Fraction of a slam where the blow lands: the effect fires here, and the art's impact frame (golem.ts: slamPose) is pinned to it. */
exports.SLAM_HIT = 0.5;
/**
 * How far a slam's blow reaches, px, measured from where the fists meet the
 * ground (sim/tasks.ts: strikePoint), not from the golem's centre. Sized to the
 * dust ring the impact throws up (game.ts, case "slam"): that dust drifts a
 * median ~18 px and three quarters of it stops within ~24 px, so the blow
 * reaches about as far as the dust visibly does: little over a tile (TS = 16).
 * A glancing near miss still counts, but nothing standing a few tiles away does.
 */
exports.SLAM_RADIUS = 20;
/** When a task's effect fires, as a function of its duration. */
exports.TASK_KINDS = {
    reach: { fire: (d) => d * 0.55 },
    push: { fire: (d) => d * 0.55 },
    attach: { fire: () => 0.9 },
    /** The old one-arm overhead smash. No rule starts it any more (the slam breaks walls); kept so saved work in progress still plays out. */
    smash: { fire: () => 0.62 },
    /** The attack: a two-arm ground slam. Both fists land at SLAM_HIT of its duration. */
    slam: { fire: (d) => d * exports.SLAM_HIT },
    carve: { fire: (d) => d - 0.2 },
    /** Harvesting with fists: the blow lands just past half way. */
    punch: { fire: (d) => d * 0.5 },
    /** Rune travel: the jump happens at the very end of the channel. */
    channel: { fire: (d) => d },
    /** Addressing an NPC: the dialogue opens once the golem has turned to it. */
    talk: { fire: (d) => d },
    /** Taking a prop apart: it comes loose near the end. */
    dismantle: { fire: (d) => d * 0.85 },
    /** Working at a bench: the product is made near the end. */
    craft: { fire: (d) => d * 0.85 },
    scan: { fire: (d) => d * 0.85 },
};
