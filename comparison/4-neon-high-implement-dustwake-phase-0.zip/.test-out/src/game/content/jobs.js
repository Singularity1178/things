"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JOB_KINDS = void 0;
exports.JOB_KINDS = {
    gatherDeposit: { phase: "gather", capabilities: ["move", "harvest", "travel"] },
    craftAt: { phase: "craft", capabilities: ["move", "craft", "travel"] },
    walk: { phase: "walk", capabilities: ["move"] },
};
