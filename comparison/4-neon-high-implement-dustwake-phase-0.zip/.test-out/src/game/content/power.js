"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POWER_CORES = void 0;
exports.POWER_CORES = {
    ruby_core: { family: "golem", tier: 1 },
};
