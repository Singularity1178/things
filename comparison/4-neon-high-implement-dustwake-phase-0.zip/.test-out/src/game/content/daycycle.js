"use strict";
// The day/night cycle (data and pure maths: no DOM, no World).
//
// The World keeps one calendar clock, `world.day`: days since the world began,
// as a float whose fraction is the time of day (0 = midnight, 0.5 = noon).
// sim/daytime.ts advances it; everything else is derived from the hour:
//
//   - the sky: how much sun there is (`sunLevel`), the twilight tint, and from
//     them the ambient light of an area by how exposed it is to the sky
//     (`ambientAt`: open air, a room with windows, or buried and unaffected);
//   - lamps against daylight (`lampGain`): a flame that fills a street at night
//     is barely seen at noon;
//   - sky light reaching in (`skyLight`): the shaft through the throne room's
//     broken roof is moonlight by night and a sunbeam by day;
//   - who tends which light (`litLevel`): where people live, lights follow the
//     day. Each kind has its own habit, and each lamp its own minute, so a
//     town lights up and goes dark the way a town does, not like a switch.
//
// Nothing here is stored: a save holds the clock and nothing else.
Object.defineProperty(exports, "__esModule", { value: true });
exports.hearthSmoke = exports.SKY = exports.hourOf = exports.wrapHour = exports.FIRST_MORNING_HOUR = exports.FIRST_ARRIVAL_HOUR = exports.START_HOUR = exports.DAY_HOURS = exports.DAY_SECONDS = void 0;
exports.phaseAt = phaseAt;
exports.sunLevel = sunLevel;
exports.twilight = twilight;
exports.ambientAt = ambientAt;
exports.lampGain = lampGain;
exports.skyLight = skyLight;
exports.clockText = clockText;
exports.hash01 = hash01;
exports.litLevel = litLevel;
/** World seconds in one full day. 30 s to the hour: six minutes of day, four of night, a minute each of dawn and dusk. */
exports.DAY_SECONDS = 720;
/** The hours the day turns on. Dawn runs dawn -> sunrise, dusk runs dusk -> nightfall. */
exports.DAY_HOURS = { dawn: 5, sunrise: 7, dusk: 19, nightfall: 21 };
/** The golem wakes in the night. */
exports.START_HOUR = 22.5;
/** The first crossing to the surface lands in the last dark before dawn (sim/runes.ts), however long the halls took. */
exports.FIRST_ARRIVAL_HOUR = 4;
/** Where the clock stands when the crossing cutscene ends (watched or skipped): dawn, the sun nearly up. */
exports.FIRST_MORNING_HOUR = 6.6;
const clamp01 = (x) => (x < 0 ? 0 : x > 1 ? 1 : x);
const smooth = (x) => { x = clamp01(x); return x * x * (3 - 2 * x); };
const mix = (a, b, k) => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
const wrapHour = (h) => ((h % 24) + 24) % 24;
exports.wrapHour = wrapHour;
/** The hour of the day (0..24) of a calendar clock value. */
const hourOf = (day) => (0, exports.wrapHour)((day - Math.floor(day)) * 24);
exports.hourOf = hourOf;
function phaseAt(hour) {
    const h = (0, exports.wrapHour)(hour), D = exports.DAY_HOURS;
    return h < D.dawn ? "night" : h < D.sunrise ? "dawn" : h < D.dusk ? "day" : h < D.nightfall ? "dusk" : "night";
}
/** How much sun there is: 0 through the night, easing up across dawn, 1 all day, easing down across dusk. */
function sunLevel(hour) {
    const h = (0, exports.wrapHour)(hour), D = exports.DAY_HOURS;
    if (h < D.dawn || h >= D.nightfall)
        return 0;
    if (h < D.sunrise)
        return smooth((h - D.dawn) / (D.sunrise - D.dawn));
    if (h < D.dusk)
        return 1;
    return 1 - smooth((h - D.dusk) / (D.nightfall - D.dusk));
}
/** How deep into a twilight the hour is: 0 outside dawn and dusk, 1 at the middle of either. */
function twilight(hour) {
    const h = (0, exports.wrapHour)(hour), D = exports.DAY_HOURS;
    if (h >= D.dawn && h < D.sunrise)
        return Math.sin((Math.PI * (h - D.dawn)) / (D.sunrise - D.dawn));
    if (h >= D.dusk && h < D.nightfall)
        return Math.sin((Math.PI * (h - D.dusk)) / (D.nightfall - D.dusk));
    return 0;
}
/** The sky's colours. An area's own `ambient` is its night; these are what the sun adds. */
exports.SKY = {
    /** Full daylight in the open: a touch warm (the dithered lighting keeps a little grain in it). */
    day: [1.0, 0.97, 0.9],
    /** Added at the height of dawn: rose and gold. */
    dawnTint: [0.2, 0.04, -0.04],
    /** Added at the height of dusk: amber, the blue already going. */
    duskTint: [0.24, 0.02, -0.08],
    /** Daylight as it reaches a room through its windows and its door. */
    indoorDay: [0.72, 0.68, 0.6],
    /** A shaft of sky light by day (by night it keeps the colour it was authored with: moonlight). */
    sunbeam: [1, 0.86, 0.6],
    /** How much a lamp still counts at full sun, in the open and in a room. */
    lampInSun: 0.16, lampIndoorsByDay: 0.6,
};
/** An area's ambient light at `hour`. `night` is the ambient it was authored with. Buried areas never change. */
function ambientAt(night, hour, exposure) {
    if (exposure === "buried")
        return night;
    const s = sunLevel(hour), tw = twilight(hour);
    if (exposure === "interior") {
        const tint = (0, exports.wrapHour)(hour) < 12 ? exports.SKY.dawnTint : exports.SKY.duskTint, base = mix(night, exports.SKY.indoorDay, s);
        return [base[0] + tint[0] * tw * 0.4, base[1] + tint[1] * tw * 0.4, base[2] + tint[2] * tw * 0.4];
    }
    const tint = (0, exports.wrapHour)(hour) < 12 ? exports.SKY.dawnTint : exports.SKY.duskTint, base = mix(night, exports.SKY.day, s);
    return [base[0] + tint[0] * tw, base[1] + tint[1] * tw, base[2] + tint[2] * tw];
}
/** How much lamp and glow light counts against the daylight (1 at night, little at noon; always 1 under the earth). */
function lampGain(hour, exposure) {
    if (exposure === "buried")
        return 1;
    const s = sunLevel(hour);
    return 1 - s * (1 - (exposure === "interior" ? exports.SKY.lampIndoorsByDay : exports.SKY.lampInSun));
}
/** Sky light reaching in (a roof crack, a doorway): its colour and strength at `hour`. `night` is its authored colour. */
function skyLight(night, hour) {
    const s = sunLevel(hour), tw = twilight(hour), tint = (0, exports.wrapHour)(hour) < 12 ? exports.SKY.dawnTint : exports.SKY.duskTint;
    const c = mix(night, exports.SKY.sunbeam, s);
    return { col: [c[0] + tint[0] * tw, c[1] + tint[1] * tw * 0.5, Math.max(0, c[2] + tint[2] * tw)], gain: 1 + 0.35 * s };
}
/** "06:40": the hour as a clock reads it, to the ten minutes. */
function clockText(hour) {
    const m = Math.floor(((0, exports.wrapHour)(hour) * 60) / 10) * 10;
    return `${String(Math.floor(m / 60) % 24).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
}
/** A stable 0..1 number for an id (FNV-1a): each lamp's own minute. */
function hash01(id, salt = 0) {
    let h = (0x811c9dc5 ^ Math.imul(salt + 1, 0x9e3779b1)) >>> 0;
    for (let i = 0; i < id.length; i++) {
        h ^= id.charCodeAt(i);
        h = Math.imul(h, 16777619) >>> 0;
    }
    h ^= h >>> 15;
    h = Math.imul(h, 0x2c1b3c6d) >>> 0;
    h ^= h >>> 12;
    return (h >>> 0) / 4294967296;
}
/** 1 from `on` to `off` (hours, wrapping past midnight), easing over `fade` hours at each end; 0 outside. */
function span(h, on, off, fade) {
    const len = (0, exports.wrapHour)(off - on), d = (0, exports.wrapHour)(h - on);
    if (d >= len)
        return 0;
    return Math.min(1, d / fade, (len - d) / fade);
}
/** How lit (0..1) the tended light `id` is at `hour`. Pure: the same lamp keeps the same hours every day. */
function litLevel(habit, id, hour) {
    const h = (0, exports.wrapHour)(hour), a = hash01(id, 1), b = hash01(id, 2);
    if (habit === "rune") {
        const edge = 0.42 + (a - 0.5) * 0.1; // each stone trips at a slightly different dark: a ripple down the street
        return smooth((edge + 0.06 - sunLevel(h)) / 0.12);
    }
    if (habit === "fire")
        return span(h, 19.5 + a * 1.2, 6.3 + b * 0.9, 0.08);
    const evening = span(h, 19.2 + a * 1.5, 22 + b * 3.5, 0.06);
    const early = hash01(id, 3) < 0.4 ? span(h, 4.6 + a * 1.1, 6.4 + b * 0.8, 0.06) : 0;
    return Math.max(evening, early);
}
/** Chimneys where people live: thick at breakfast and supper, thin at noon, a thread through the night (a rate multiplier). */
const hearthSmoke = (hour) => {
    const h = (0, exports.wrapHour)(hour);
    return 0.3 + 0.7 * Math.max(Math.exp(-(((h - 7) / 1.6) ** 2)), Math.exp(-(((h - 19.5) / 2) ** 2)));
};
exports.hearthSmoke = hearthSmoke;
