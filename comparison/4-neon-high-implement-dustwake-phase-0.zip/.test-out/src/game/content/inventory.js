"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CAPACITY_TIERS = void 0;
const flags_1 = require("./flags");
exports.CAPACITY_TIERS = [
    { slots: 8 },
    { requires: { actorFlags: [flags_1.FLAGS.golemArm] }, slots: 16 },
    { requires: { worn: ["basket"] }, slots: 48 },
];
