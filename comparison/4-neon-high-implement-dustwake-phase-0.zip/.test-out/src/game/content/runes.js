"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runeDestination = exports.RUNE_LINKS = exports.RUNE_NODES = void 0;
exports.runeAt = runeAt;
exports.runeDestinations = runeDestinations;
exports.RUNE_NODES = {
    // The tutorial's translocation circle. Arrivals land just south of the
    // circle, well outside the stand-on radius, so arriving can't re-trigger it.
    dungeon: { id: "dungeon", area: "dungeon", prop: "rune.dungeon", flag: "rune.dungeon.active", arrive: { dx: 0, dy: 30, facing: "down" }, name: "TRANSLOCATION ROOM" },
    surface: { id: "surface", area: "surface", prop: "rune.surface", flag: "rune.surface.active", arrive: { dx: 0, dy: 4, facing: "down" }, name: "THE SURFACE" },
};
exports.RUNE_LINKS = [{ a: "dungeon", b: "surface", awakens: true }];
/** The rune node whose prop is `propId` in `area`, if any. */
function runeAt(area, propId) {
    for (const n of Object.values(exports.RUNE_NODES))
        if (n.area === area && n.prop === propId)
            return n;
    return undefined;
}
/** Where travelling from `id` leads, through which link, and whether that way wakes the far end (a -> b of an `awakens` link only). */
function runeDestinations(id) {
    const out = [];
    for (const link of exports.RUNE_LINKS) {
        if (link.a === id && exports.RUNE_NODES[link.b])
            out.push({ node: exports.RUNE_NODES[link.b], link, wakes: !!link.awakens });
        if (link.b === id && !link.oneWay && exports.RUNE_NODES[link.a])
            out.push({ node: exports.RUNE_NODES[link.a], link, wakes: false });
    }
    return out;
}
const runeDestination = (id, to) => runeDestinations(id).find((d) => !to || d.node.id === to) ?? null;
exports.runeDestination = runeDestination;
