"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.digTotal = exports.DIG_SITES = exports.DIG_DUR = exports.GROUND_COLUMN = exports.DIG_MATERIALS = void 0;
exports.digLayerAt = digLayerAt;
exports.digStage = digStage;
exports.propLook = propLook;
exports.DIG_MATERIALS = {
    dirt: { name: "EARTH", tool: "shovel", yields: "dirt", rules: "digDirt" },
    stone: { name: "STONE", tool: "pickaxe", yields: "stone", rules: "digStone" },
};
/** What lies under open ground where nothing else is said: the column a later "dig anywhere" starts from. Not read yet. */
exports.GROUND_COLUMN = [{ material: "dirt", work: 4 }, { material: "stone", work: 8 }];
/** Seconds a stroke takes. */
exports.DIG_DUR = 1.1;
exports.DIG_SITES = {
    // The old stair down into the halls: turf and a cellar's depth of earth, then the vault that fell into the stairwell.
    buriedgate: { layers: [{ material: "dirt", work: 8 }, { material: "stone", work: 8 }], dy: -20, reach: 28, opens: "surface_stair" },
};
const digTotal = (def) => def.layers.reduce((s, l) => s + l.work, 0);
exports.digTotal = digTotal;
/** The layer `done` units of work have reached: its index, material, the work already into it and what is left of it. Null once through. */
function digLayerAt(def, done) {
    let base = 0;
    for (let i = 0; i < def.layers.length; i++) {
        const l = def.layers[i];
        if (done < base + l.work - 1e-9)
            return { index: i, material: l.material, into: done - base, left: base + l.work - done };
        base += l.work;
    }
    return null;
}
/**
 * How far along a site looks, for its sprite: 0 untouched, then two looks per
 * layer (begun, half through), and 2 * layers + 1 once open. The buried
 * entrance: 0 grass, 1-2 earth, 3-4 stone, 5 the open stair.
 */
function digStage(def, done, open) {
    if (open)
        return def.layers.length * 2 + 1;
    if (done <= 0)
        return 0;
    const at = digLayerAt(def, done);
    if (!at)
        return def.layers.length * 2;
    return 1 + at.index * 2 + (at.into >= def.layers[at.index].work / 2 ? 1 : 0);
}
/** The sprite variant a prop is drawn with: its dig stage if it is a dig site, else its authored `v`. */
function propLook(p) {
    const def = exports.DIG_SITES[p.kind];
    return def ? digStage(def, p.dmg ?? 0, !!p.open) : p.v;
}
