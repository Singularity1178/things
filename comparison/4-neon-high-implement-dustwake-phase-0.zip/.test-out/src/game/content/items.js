"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isCritical = exports.isDroppable = exports.maxStack = exports.glyphItem = exports.isGlyph = exports.RELICS = exports.ITEM_NAMES = exports.ITEM_IDS = exports.ITEMS = exports.GEAR_SLOTS = void 0;
exports.effectLines = effectLines;
// Item definitions (data). Adding an item = adding an entry here plus its icon
// in art.ts (ITEM_ART). Interaction, inventory and UI code read behaviour from
// these fields instead of switching on item ids.
const glyphs_1 = require("./glyphs");
const flags_1 = require("./flags");
const gear_1 = require("./gear");
const tools_1 = require("./tools");
var gear_2 = require("./gear");
Object.defineProperty(exports, "GEAR_SLOTS", { enumerable: true, get: function () { return gear_2.GEAR_SLOTS; } });
const glyph = (i) => ({
    name: glyphs_1.GLYPHS[i].name, tags: ["glyph"], glyph: i, droppable: false,
    desc: ["A CARVED RUNE GLYPH.", "IT BELONGS ON A PEDESTAL."],
    glow: { color: glyphs_1.GLYPHS[i].color, rad: 30, int: 0.55, flick: 0.05 },
});
/** What each rune does while worn. One row per rune, read by the rune item and by a tool head with that rune set in it. */
const RUNE_WORN = {
    swift: { speed: gear_1.RUNE_SWIFT_SPEED_BONUS, mark: { col: "#5cf0c8", pat: ["#..", ".#.", "#.."] } },
    glow: { light: gear_1.RUNE_GLOW_LIGHT, mark: { col: "#ffffff", pat: [".#.", "###", ".#."] } },
};
/** The tool rows: per type, the head in every grade and inset, and the hafted tool plain and tempered. */
function toolRows() {
    const out = {};
    for (const t of tools_1.TOOL_TYPE_IDS) {
        const T = tools_1.TOOL_TYPES[t];
        const head = (bonus) => ({ type: t, form: "head", bonus });
        out[`head_${t}`] = {
            name: `${T.name} HEAD`, tags: ["tool"], wear: { kind: "arm" }, tool: head(tools_1.TOOL_BONUS.plain),
            desc: [`AN IRON ${T.name} HEAD FOR AN ARM`, "SLOT, OR TO HAFT AT A BENCH."],
        };
        out[`head_${t}_rusted`] = {
            name: `RUSTED ${T.name} HEAD`, tags: ["tool"],
            desc: [`A ${T.name} HEAD, EATEN BY RUST.`, "AN ANVIL AND ONE IRON INGOT", "WOULD MAKE IT SOUND AGAIN."],
        };
        out[`head_${t}_fine`] = {
            name: `FINE ${T.name} HEAD`, tags: ["tool"], wear: { kind: "arm" }, tool: head(tools_1.TOOL_BONUS.fine),
            desc: [`A TEMPERED ${T.name} HEAD. ITS`, "IRON WILL HOLD A RUNE (ANVIL)."],
        };
        for (const r of ["swift", "glow"]) {
            // The rune's sigil is drawn for rune slots only, so an inset head carries the effect without the mark.
            const { mark: _mark, ...worn } = RUNE_WORN[r];
            out[`head_${t}_${r}`] = {
                name: `${r.toUpperCase()} ${T.name} HEAD`, tags: ["tool"], wear: { kind: "arm" }, tool: head(tools_1.TOOL_BONUS.fine), worn,
                desc: [`A FINE ${T.name} HEAD, RUNE OF ${r.toUpperCase()}.`],
            };
        }
        out[t] = {
            name: T.full, tags: ["tool"], tool: { type: t, form: "full", bonus: tools_1.TOOL_BONUS.plain },
            desc: [`A ${T.full} ON A WOODEN HAFT, FOR`, "HANDS. GIVE IT TO A WORKER."],
        };
        out[`${t}_fine`] = {
            name: `FINE ${T.full}`, tags: ["tool"], tool: { type: t, form: "full", bonus: tools_1.TOOL_BONUS.fine },
            desc: [`A TEMPERED ${T.full} ON A HAFT.`, "GIVE IT TO A WORKER."],
        };
    }
    return out;
}
exports.ITEMS = {
    chisel: { name: "RUNE CHISEL", tags: ["tool"], droppable: false, desc: ["A CHISEL FOR CARVING RUNES.", "CARRY IT TO CARVE. IT IS", "NEVER USED UP."] },
    arm: { name: "IRON ARM", tags: ["part"], droppable: false, desc: ["AN IRON ARM FOR YOUR BROKEN", "SIDE. IT BOLTS ON AT ONCE."], equip: { flag: flags_1.FLAGS.golemArm, task: { kind: "attach", dur: 1.8 } } },
    key: { name: "RUSTED KEY", tags: ["key"], droppable: false, desc: ["A RUSTED KEY. IT FITS SOME", "OLD LOCK IN THE RUINS."] },
    core: { name: "AETHER CORE", tags: ["power"], droppable: false, desc: ["AN AETHER CORE. THE CIRCLE", "NEEDS IT TO WAKE. IT STAYS", "IN YOUR PACK, NOT ON YOU."] },
    // The ruby chain: the crown's gem, carved at a bench into the one core that can power a worker golem.
    ruby_core: { name: "RUBY GOLEM CORE", tags: ["power"], desc: ["A FIRST-TIER CORE FOR A WORKER.", "FACE A GOLEM, C TO SLOT IT IN.", "C AGAIN TAKES IT BACK OUT."] },
    large_ruby: { name: "HIGH-GRADE RUBY", tags: ["material"], stack: 10, desc: ["A LARGE RUBY, CUT CLEAN AND", "DEEP RED. FINE ENOUGH TO", "CARVE INTO A GOLEM CORE."] },
    glyph0: glyph(0), glyph1: glyph(1), glyph2: glyph(2), glyph3: glyph(3),
    schematic: { name: "SCHEMATIC", tags: ["document"], droppable: false, showOnProp: false, desc: ["THE PLAN OF THE CIRCLE.", "E TO STUDY IT AGAIN."], opens: "schematic", opensOnPickup: true },
    crown: { name: "BROKEN CROWN", tags: ["relic"], desc: ["A BROKEN CROWN. NO ONE", "RULES HERE ANY MORE."] },
    goblet: { name: "SILVER GOBLET", tags: ["relic"], desc: ["A SILVER GOBLET, DULL WITH", "AGE."] },
    coin: { name: "OLD COIN", tags: ["relic"], desc: ["AN OLD COIN FROM A LOST", "REALM."] },
    wood: { name: "WOOD", tags: ["material"], stack: 20, desc: ["ROUGH TIMBER. SAW IT INTO", "PLANKS AT A CRAFTING BENCH."] },
    stone: { name: "STONE", tags: ["material"], stack: 20, desc: ["ROUGH STONE. CUT IT AT A", "CRAFTING BENCH."] },
    // Processed materials (crafted at a bench: content/crafting.ts).
    planks: { name: "PLANKS", tags: ["material"], stack: 20, desc: ["SAWN PLANKS, FOR FINER", "BUILDS AND FURNITURE."] },
    cut_stone: { name: "CUT STONE", tags: ["material"], stack: 10, desc: ["SQUARED BLOCKS OF STONE, FOR", "MASONRY AND RUNE CARVING."] },
    // The iron chain: ore from the surface (content/harvest.ts), ingots from a smelter, tools from an anvil (content/crafting.ts).
    iron_ore: { name: "IRON ORE", tags: ["material"], stack: 20, desc: ["RUST-RED ORE. A SMELTER TURNS", "IT INTO IRON INGOTS."] },
    iron_ingot: { name: "IRON INGOT", tags: ["material"], stack: 20, desc: ["A BAR OF SMELTED IRON, READY", "FOR THE ANVIL."] },
    // What digging earth yields (content/digging.ts).
    dirt: { name: "DIRT", tags: ["material"], stack: 20, desc: ["LOOSE EARTH. NO USE FOR IT", "YET."] },
    ...toolRows(),
    // Gear for the back slot: an ordinary pack item until it is worn (sim/gear.ts); worn, it grows the pack.
    basket: { name: "WOVEN BASKET", tags: ["part"], wear: { kind: "back" }, desc: ["A WOVEN BASKET. STRAP IT TO", "YOUR BACK TO CARRY MORE."] },
    // Runes: worn in a rune slot, their effects apply only while worn.
    rune_swift: {
        name: "RUNE OF SWIFT", tags: ["rune"], wear: { kind: "rune" }, desc: ["A STONE CARVED WITH THE SIGN", "OF SWIFTNESS."],
        worn: RUNE_WORN.swift,
    },
    rune_glow: {
        name: "RUNE OF GLOW", tags: ["rune"], wear: { kind: "rune" }, desc: ["A STONE CARVED WITH THE SIGN", "OF LIGHT."],
        worn: RUNE_WORN.glow,
    },
    book_build: {
        name: "BUILDER'S PRIMER", tags: ["document"], opens: "book", opensOnPickup: true, desc: ["HOW TO RAISE THINGS. READING", "IT TEACHES BUILDING (E)."],
        book: {
            title: "ON RAISING THINGS", grants: flags_1.FLAGS.knowBuild,
            pages: [
                ["EVERY WORK BEGINS WITH", "GROUND THAT WILL BEAR IT.", "CLEAR THE PLACE. JUDGE", "IT LEVEL AND FIRM."],
                ["GATHER MATERIAL FIRST.", "TIMBER FOR FRAME AND", "FIRE. STONE FOR FOOTING", "AND FOR WEIGHT."],
                ["MEASURE TWICE, SET ONCE.", "A THING BADLY PLACED", "IS WORSE THAN NOTHING.", "(PRESS B TO BUILD)"],
            ],
        },
    },
    book_repair: {
        name: "MENDER'S MANUAL", tags: ["document"], opens: "book", opensOnPickup: true, desc: ["A WATER-DAMAGED BOOK ON", "MENDING (E TO READ)."],
        book: {
            title: "ON MENDING", grants: flags_1.FLAGS.knowRepair,
            pages: [["WHAT WAS WHOLE REMEMBERS", "ITS SHAPE. THE MENDER", "ONLY REMINDS IT.", "(THE REST IS WATER-DAMAGED)"]],
        },
    },
};
exports.ITEM_IDS = Object.keys(exports.ITEMS);
exports.ITEM_NAMES = Object.fromEntries(exports.ITEM_IDS.map((id) => [id, exports.ITEMS[id].name]));
exports.RELICS = exports.ITEM_IDS.filter((id) => exports.ITEMS[id].tags.includes("relic"));
const isGlyph = (id) => exports.ITEMS[id].glyph !== undefined;
exports.isGlyph = isGlyph;
const glyphItem = (gi) => ("glyph" + gi);
exports.glyphItem = glyphItem;
const maxStack = (id) => exports.ITEMS[id].stack ?? 1;
exports.maxStack = maxStack;
const isDroppable = (id) => exports.ITEMS[id].droppable !== false;
exports.isDroppable = isDroppable;
/**
 * Progress hangs on it: the tutorial's items (the ones that can't be dropped) and
 * any book that teaches something. A prop holding one can't be taken apart until
 * the item is taken (sim/build.ts: deconstructCheck), so it is never put in play
 * loose by a deconstruction.
 */
const isCritical = (id) => exports.ITEMS[id].droppable === false || !!exports.ITEMS[id].book?.grants;
exports.isCritical = isCritical;
/** The effect lines the pack shows for a worn item (generated from its data, so a new rune describes itself). The font has no percent sign: multipliers. */
function effectLines(id) {
    const w = exports.ITEMS[id].worn, tool = exports.ITEMS[id].tool, out = [];
    if (tool) {
        // A shovel only digs (bonus units a stroke); the others multiply the work of a blow.
        const mult = tool.type === "shovel" ? tool.bonus : 1 + tool.bonus;
        const what = `${tools_1.TOOL_TYPES[tool.type].works}${mult > 1 ? ` X${mult}` : ""}`;
        out.push(tool.form === "head" ? `ON AN ARM: ${what}` : tool.type === "shovel" ? "FOR HANDS. NO WORKER DIGS YET." : `WORKER'S TOOL: ${what}`);
    }
    if (!w)
        return out;
    if (w.speed)
        out.push(`WORN: SPEED X${(1 + w.speed).toFixed(1)}`);
    if (w.light)
        out.push(`WORN: BRIGHT WHITE LIGHT X${(w.light.rad / gear_1.GOLEM_LIGHT.rad).toFixed(1)}`);
    return out;
}
