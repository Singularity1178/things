"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runeItemId = exports.fineToolId = exports.fullToolId = exports.runedHeadId = exports.fineHeadId = exports.rustedHeadId = exports.headId = exports.HAFT_WOOD = exports.TEMPER_COST = exports.REPAIR_COST = exports.FORGE_COST = exports.TOOL_BONUS = exports.TOOL_TYPES = exports.TOOL_RUNES = exports.TOOL_TYPE_IDS = void 0;
exports.TOOL_TYPE_IDS = ["shovel", "pickaxe", "axe"];
exports.TOOL_RUNES = ["swift", "glow"];
exports.TOOL_TYPES = {
    shovel: { name: "SHOVEL", full: "SHOVEL", works: "DIGS EARTH" },
    pickaxe: { name: "PICK", full: "PICKAXE", works: "ROCK AND ORE" },
    axe: { name: "AXE", full: "AXE", works: "WOOD" },
};
// ---------------------------------------------------------------- tunables
exports.TOOL_BONUS = { plain: 1, fine: 2 };
/** Iron ingots to forge a head. */
exports.FORGE_COST = { shovel: 2, pickaxe: 3, axe: 3 };
/** Iron ingots to make a rusted head sound again (cheaper than forging one). */
exports.REPAIR_COST = 1;
/** Iron ingots to temper a head or a hafted tool. */
exports.TEMPER_COST = 2;
/** Wood for the haft of a full tool. */
exports.HAFT_WOOD = 2;
const headId = (t) => `head_${t}`;
exports.headId = headId;
const rustedHeadId = (t) => `head_${t}_rusted`;
exports.rustedHeadId = rustedHeadId;
const fineHeadId = (t) => `head_${t}_fine`;
exports.fineHeadId = fineHeadId;
const runedHeadId = (t, r) => `head_${t}_${r}`;
exports.runedHeadId = runedHeadId;
const fullToolId = (t) => t;
exports.fullToolId = fullToolId;
const fineToolId = (t) => `${t}_fine`;
exports.fineToolId = fineToolId;
const runeItemId = (r) => `rune_${r}`;
exports.runeItemId = runeItemId;
