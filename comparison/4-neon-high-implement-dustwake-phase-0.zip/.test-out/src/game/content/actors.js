"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.capable = exports.ACTORS = void 0;
exports.actorDef = actorDef;
// Bodies and abilities, not player/NPC classes. A worker is an optional
// capability; dialogue identity and presentation state live elsewhere.
const inventory_1 = require("./inventory");
const gear_1 = require("./gear");
exports.ACTORS = {
    golem: {
        name: "MAINTAINER", body: { box: [10, 5], height: 24, reach: 20 }, art: { key: "golem" },
        speed: 48, speedTiers: [{ requires: { actorFlags: ["golem.arm"] }, speed: 60 }], harvestPower: 1,
        inventory: { slots: 8, tiers: inventory_1.CAPACITY_TIERS }, gearSlots: gear_1.GEAR_SLOTS,
        gearUnlocks: Object.fromEntries(gear_1.GEAR_SLOT_DEFS.flatMap((d) => d.unlock ? [[d.id, d.unlock]] : [])),
        capabilities: ["move", "harvest", "craft", "build", "travel", "scan", "attack"],
    },
    guardian: {
        name: "TREASURY GUARDIAN", body: { box: [24, 10], height: 44, reach: 24 }, art: { key: "guardian" },
        speed: 0, harvestPower: 2, inventory: { slots: 0 }, gearSlots: ["core"],
        power: { family: "golem", tier: 3 }, capabilities: ["talk"],
        eyeLight: { dx: 0, dy: -24, rad: 46, col: [0.5, 0.85, 1] },
    },
    // The general worker body: simpler and lower in rank than the maintainer, no autonomy, only what it is tasked.
    // One stands dormant in the artificery (map.ts, `npc.worker.artificery`); the ?debug fixture uses it too.
    worker_golem: {
        name: "WORKER GOLEM", body: { box: [8, 4], height: 20, reach: 18 }, art: { key: "worker" },
        speed: 16, harvestPower: 0.5, inventory: { slots: 8 }, gearSlots: ["rune0"],
        power: { family: "golem", tier: 1 }, capabilities: ["move", "harvest", "craft", "travel", "worker", "wield"],
    },
    // Townsfolk (sim/folk.ts): every generic NPC's body. Soft (sim/collision.ts: actorBox gives none), so nobody can
    // be blocked by one; who they are and how they look is the actor's own `person` (folkArt.ts draws it).
    townsfolk: {
        name: "TOWNSFOLK", body: { box: [8, 4], height: 22, reach: 18 }, art: { key: "folk" },
        speed: 18, harvestPower: 0.5, inventory: { slots: 0 }, gearSlots: [], capabilities: ["move", "talk", "travel"],
    },
    // Shopkeepers (sim/shops.ts): one behind each of Westwake's counters. Soft like townsfolk. A placeholder body: the
    // art key "keeper" draws a plain black box until each keeper is textured (keeperArt.ts: KEEPER_ART).
    shopkeeper: {
        name: "SHOPKEEPER", body: { box: [10, 4], height: 22, reach: 18 }, art: { key: "keeper" },
        speed: 15, harvestPower: 0.5, inventory: { slots: 0 }, gearSlots: [], capabilities: ["talk"],
    },
    // Fixture-only (tests): no builder, NPCS row or migration produces one, and its "human" art is a stand-in.
    npc_worker: {
        name: "WORKER", body: { box: [8, 6], height: 22, reach: 18 }, art: { key: "human" },
        speed: 20, harvestPower: 0.75, inventory: { slots: 8 }, gearSlots: ["head", "back", "armR", "armL"],
        capabilities: ["move", "harvest", "craft", "travel", "worker", "wield"],
    },
};
function actorDef(a) {
    const d = exports.ACTORS[a.definition];
    if (!d)
        throw new Error(`unknown actor definition "${a.definition}"`);
    return d;
}
const capable = (a, capability) => actorDef(a).capabilities.includes(capability);
exports.capable = capable;
