"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.thoughtTriggers = exports.THOUGHTS = void 0;
exports.THOUGHTS = {
    // ---- the opening (content/cutscenes.ts fires these by id)
    "intro.assessing": { text: "ASSESSING..." },
    "intro.damage": { text: "MILD DAMAGE DETECTED.", tone: "warn" },
    "intro.arm": { text: "MISSING LEFT ARM.", tone: "warn" },
    "intro.directive": { text: "PRIME DIRECTIVE: NONE.", tone: "void", pace: 0.7 },
    // ---- play
    /** Golem vision (Z): a buildable's pattern was learned. Each analysis emits one `analyzed` per plan, hence the cooldown. */
    "vision.analyzed": { text: "OBJECT ANALYZED.", on: { event: "analyzed" }, once: false, cooldown: 1 },
    // ---- power. Only `dormantTouched` (E on a worker that has never had a core) diagnoses a body with no core:
    // `subjectNoPower` holds for the unpowered guardian too, and E on it is talk, so a broader trigger would say
    // this about the guardian. Once a core has been slotted in, the body's screen opens even with the core out
    // again, and the golem no longer says it.
    /** E on the dormant worker golem (or any worker) that has never held a core: its screen stays shut. */
    "golem.dormant": { text: "INTEGRITY INTACT, MISSING POWER SOURCE.", on: { event: "dormantTouched" }, if: ["subjectNoPower"], once: false, cooldown: 2 },
    /**
     * A body holding a core of its family too weak for it (the guardian given the ruby core): when the core goes in,
     * and on every interaction after. `talkedTo` fires on every talk, segment or idle line, unlike `dialogue`.
     */
    "golem.underpowered": {
        text: "INSUFFICIENT POWER SOURCE.", tone: "warn", once: false, cooldown: 2, if: ["subjectWeakPower"],
        on: [{ event: "manageActor" }, { event: "talkedTo" }, { event: "coreSlotted", match: { inserted: true } }],
    },
};
// ---- the town. The Treasury Guardian spoke of a village west of the keep; the road ends at a town.
exports.THOUGHTS["town.arrive"] = { text: "ON RECORD: A VILLAGE. OBSERVED: A TOWN.", on: { event: "portal", match: { fromArea: "surface", toArea: "town" } } };
const thoughtTriggers = (l) => (!l.on ? [] : Array.isArray(l.on) ? l.on : [l.on]);
exports.thoughtTriggers = thoughtTriggers;
// ---- the crossing: the first jump through the rune network (content/cutscenes.ts: CROSSING fires these by id).
// The far rune is eroded; the golem has to rewrite it from the pattern it left by before it can arrive.
exports.THOUGHTS["cross.engage"] = { text: "TRANSLOCATION ENGAGED." };
exports.THOUGHTS["cross.transit"] = { text: "TRANSLOCATING..." };
exports.THOUGHTS["cross.anchor"] = { text: "DESTINATION ANCHOR: DEGRADED.", tone: "warn" };
exports.THOUGHTS["cross.rewrite"] = { text: "REWRITING ANCHOR FROM SOURCE..." };
exports.THOUGHTS["cross.arrived"] = { text: "ANCHOR RESTORED. ARRIVAL CONFIRMED." };
exports.THOUGHTS["cross.observed"] = { text: "ON RECORD: THE UPPER HALLS. OBSERVED: FOREST." };
exports.THOUGHTS["cross.light"] = { text: "LIGHT LEVEL RISING.", tone: "void", pace: 0.7 };
// ---- the sky. The first dusk the golem stands under (the first dawn is the crossing's).
exports.THOUGHTS["sky.dusk"] = { text: "LIGHT LEVEL FALLING. NIGHT CYCLE.", on: { event: "dayPhase", match: { phase: "dusk" } }, if: ["underSky"] };
