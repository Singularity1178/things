"use strict";
// Geometry of the translocation circle (the future surface<->dungeon link).
Object.defineProperty(exports, "__esModule", { value: true });
exports.RITUAL_SPOTS = exports.SOCKET_COUNT = exports.SOCKET_R = void 0;
exports.socketPositions = socketPositions;
exports.SOCKET_R = 50;
exports.SOCKET_COUNT = 4;
function socketPositions(c) {
    return [
        { x: c.x, y: c.y - exports.SOCKET_R },
        { x: c.x + exports.SOCKET_R, y: c.y },
        { x: c.x, y: c.y + exports.SOCKET_R },
        { x: c.x - exports.SOCKET_R, y: c.y },
    ];
}
exports.RITUAL_SPOTS = {
    socket: { dy: 6, r: 18 },
    center: { r: 13 },
    gap: { dx: 38, dy: 38, r: 20 },
    /** Standing within sqrt(81)px of (c.x, c.y + 2) after activation teleports. */
    teleport: { dy: 2, r2: 81, delay: 3 },
};
