"use strict";
// Dialogue identities (data), keyed by NPC id. Bodies and art are ACTORS rows.
// An NPC in the world is an ordinary
// Actor of kind "npc" whose `npc` field names its row here; everything that
// makes it *this* NPC (name, dialogue, sprite, body) comes from the row, so the
// sim, the interaction path and the renderer never branch on a particular NPC.
//
// Two kinds are planned:
//   "special" — hand-authored identity: own name, dialogue script, sprite and
//               story arc (the Treasury Guardian is the first).
//   "generic" — archers, warriors, mages... with randomized looks, stats and
//               personality. NOT implemented yet: when it is, it adds its own
//               fields (archetype, stats, ...) to the union; nothing here
//               should be stretched to fit it.
Object.defineProperty(exports, "__esModule", { value: true });
exports.npcDef = exports.NPCS = void 0;
exports.NPCS = {
    guardian: {
        name: "TREASURY GUARDIAN", type: "special", dialogue: "guardian", actor: "guardian",
    },
};
const npcDef = (id) => (id ? exports.NPCS[id] : undefined);
exports.npcDef = npcDef;
