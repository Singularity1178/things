"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RUNE_GLOW_LIGHT = exports.GOLEM_LIGHT = exports.RUNE_SWIFT_SPEED_BONUS = exports.RUNE_SLOTS = exports.slotsOfKind = exports.slotDef = exports.GEAR_SLOTS = exports.GEAR_SLOT_DEFS = void 0;
const flags_1 = require("./flags");
const SEALED = ["THIS RUNE SLOT IS SEALED.", "SOMETHING WILL OPEN IT", "LATER."];
/**
 * Slot order is also the order a gear kind fills its slots in (the first empty
 * usable slot of the kind takes a new item).
 *
 * Which side is which: the golem's LEFT arm is the damaged one, the broken stub
 * the iron arm replaces (golem.ts draws it on screen-right facing down); its
 * RIGHT arm is the sound stone one. The right arm is usable from the start.
 * The left arm slot opens once there is an arm there to take fittings: the
 * iron arm (`golem.arm`: still an installed body part, never a slot item), or
 * the slot's own upgrade flag (`golem.slot.armL`, what the debug kit sets).
 * Nothing is stored for it: the slot is usable exactly while either holds.
 */
exports.GEAR_SLOT_DEFS = [
    { id: "head", kind: "head", name: "HELM", hint: ["A BARE HEAD.", "A HELM WOULD FIT HERE."] },
    { id: "back", kind: "back", name: "BACK", hint: ["NOTHING ON YOUR BACK.", "WEAR A BASKET FROM THE PACK."] },
    { id: "armR", kind: "arm", name: "R ARM", hint: ["THE SOUND STONE ARM.", "A TOOL HEAD FITS HERE."] },
    {
        id: "armL", kind: "arm", name: "L ARM", hint: ["THE IRON ARM.", "FITTINGS FOR AN ARM GO HERE."],
        unlock: { any: [{ actorFlags: [flags_1.FLAGS.golemArm] }, { actorFlags: [flags_1.FLAGS.slotArmLeft] }] },
        locked: [{ text: ["A BROKEN STUB. NOTHING CAN", "BE FITTED UNTIL THERE IS AN", "ARM HERE."] }],
    },
    { id: "core", kind: "core", name: "CORE", hint: ["A MOUNT BESIDE THE CORE.", "FOR ATTACHMENTS TO IT, NOT", "THE AETHER CORE ITSELF."] },
    { id: "rune0", kind: "rune", name: "RUNE 1", hint: ["AN OPEN RUNE SLOT.", "WEAR A RUNE FROM THE PACK."] },
    { id: "rune1", kind: "rune", name: "RUNE 2", unlock: { actorFlags: [flags_1.FLAGS.slotRune1] }, locked: [{ text: SEALED }] },
    { id: "rune2", kind: "rune", name: "RUNE 3", unlock: { actorFlags: [flags_1.FLAGS.slotRune2] }, locked: [{ text: SEALED }] },
    { id: "rune3", kind: "rune", name: "RUNE 4", unlock: { actorFlags: [flags_1.FLAGS.slotRune3] }, locked: [{ text: SEALED }] },
];
exports.GEAR_SLOTS = exports.GEAR_SLOT_DEFS.map((d) => d.id);
const slotDef = (id) => exports.GEAR_SLOT_DEFS.find((d) => d.id === id);
exports.slotDef = slotDef;
/** The slots that take a kind of gear, in fill order. */
const slotsOfKind = (kind) => exports.GEAR_SLOT_DEFS.filter((d) => d.kind === kind).map((d) => d.id);
exports.slotsOfKind = slotsOfKind;
exports.RUNE_SLOTS = (0, exports.slotsOfKind)("rune");
// ---------------------------------------------------------------- tunables
/**
 * RUNE OF SWIFT: "increases speed by 150%". Read literally as +150%, i.e. 2.5x
 * the base speed (the repo's own debug super-speed note reads "200% faster = 3x"
 * the same way). Effects add: the speed multiplier is 1 + the sum of the worn
 * bonuses. This is the one number to change.
 */
exports.RUNE_SWIFT_SPEED_BONUS = 1.5;
exports.GOLEM_LIGHT = { rad: 108, col: [1, 0.78, 0.5], int: 1 };
/** RUNE OF GLOW: a bright white light in a wider radius than the standard glow. */
exports.RUNE_GLOW_LIGHT = { rad: 176, col: [1, 1, 1], int: 1.25 };
