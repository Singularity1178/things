"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HARVEST = void 0;
exports.HARVEST = {
    tree: { hp: 4, perHit: { item: "wood", n: 1 }, final: { item: "wood", n: 2 }, tool: "axe" },
    /** A fallen, rotting trunk: quick wood, and the way opens once it's broken up. */
    log: { hp: 3, perHit: { item: "wood", n: 1 }, final: { item: "wood", n: 1 }, clearBox: true, tool: "axe" },
    rock: { hp: 3, perHit: { item: "stone", n: 1 }, final: { item: "stone", n: 2 }, clearBox: true, tool: "pickaxe" },
    /**
     * An outcrop veined with iron: half a piece per unit of work, so two bare-fisted
     * blows for each piece of ore, three pieces in all. A pickaxe head gets one a blow.
     */
    ironore: { hp: 6, perHit: { item: "iron_ore", n: 0.5 }, clearBox: true, tool: "pickaxe" },
};
