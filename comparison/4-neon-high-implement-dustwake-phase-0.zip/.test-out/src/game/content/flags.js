"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CORE_SEATED = exports.NPC_AWAKE = exports.npcFlag = exports.learnedText = exports.LEARNED_TEXT = exports.FLAGS = void 0;
// Progression flags. Progression is a set of namespaced string flags on the
// World, not boolean fields on a game object. Naming convention:
//   golem.arm / golem.slot.* are actor upgrades (v10); the legacy flag API
//                 redirects them to the player. golem.eye remains story progress.
//   know.*      — knowledge the golem has acquired
//   tutorial.*  — one-shot tutorial beats
//   rune.*      — teleportation rune sites (rune.<site>.active)
//   npc.<id>.*  — per-NPC runtime state and story progress, namespaced by the
//                 NPC actor's id (npc.guardian.awake, npc.guardian.met, ...).
//                 NPC state never lives under golem.* (that is the player).
exports.FLAGS = {
    golemArm: "golem.arm",
    /** The golem's flickering eye has been repaired (by the Treasury Guardian). Unlocks zoom. */
    golemEye: "golem.eye",
    // "golem.basket" (the basket installed on pickup) was retired in save v8: the
    // basket is gear worn in the actor's own back slot (Actor.gear, sim/gear.ts).
    knowSchematic: "know.schematic",
    knowBuild: "know.build",
    knowRepair: "know.repair",
    /** Smelting ore into ingots. Nobody teaches it: the golem reads it off a smelter (content/build.ts: Recipe.teaches). */
    knowSmelt: "know.smelt",
    /** Stonework (the brazier recipe). No book teaches it yet; Ctrl+4 grants it. */
    knowMasonry: "know.masonry",
    /**
     * Gear slot unlocks (content/gear.ts: GEAR_SLOT_DEFS[].unlock). A slot with no
     * unlock requirement is always usable; the ones below are locked until their
     * flag is set. Unlocking a slot later is setting its flag, nothing more.
     */
    slotArmLeft: "golem.slot.armL",
    slotRune1: "golem.slot.rune1",
    slotRune2: "golem.slot.rune2",
    slotRune3: "golem.slot.rune3",
    tutorialInsight: "tutorial.insight",
    /** Set when the golem first travels through the rune network (end of tutorial). */
    tutorialDone: "tutorial.done",
};
/** The note shown once when a knowledge flag is learned (the `learned` event). Unlisted flags show their name. */
exports.LEARNED_TEXT = {
    [exports.FLAGS.knowBuild]: "YOU LEARNED TO BUILD.",
    [exports.FLAGS.knowRepair]: "YOU LEARNED THE ART OF MENDING",
    [exports.FLAGS.knowMasonry]: "YOU LEARNED THE MASON'S CRAFT",
    [exports.FLAGS.knowSmelt]: "YOU LEARNED TO SMELT ORE.",
};
const learnedText = (flag) => exports.LEARNED_TEXT[flag] ?? `YOU LEARNED ${flag}`;
exports.learnedText = learnedText;
/** A flag namespaced by an NPC actor's id: npcFlag("npc.guardian", "met") -> "npc.guardian.met". */
const npcFlag = (actorId, key) => `${actorId}.${key}`;
exports.npcFlag = npcFlag;
/** Runtime state every NPC has: present = awake, absent = dormant. Reversible by design. */
exports.NPC_AWAKE = "awake";
/** Set once a body has had a power core in it (slotted, or taken out of one it held): a worker golem's management screen opens from then on, core or not. */
exports.CORE_SEATED = "coreSeated";
