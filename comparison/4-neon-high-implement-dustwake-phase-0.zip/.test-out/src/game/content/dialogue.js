"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DIALOGUE = exports.GUARDIAN_FLAGS = exports.BEATS = void 0;
const flags_1 = require("./flags");
/** Named beat handlers. Return the Effect to apply (or null for presentation-only beats). */
exports.BEATS = {
    /** The NPC wakes (reversible: see goDormant). */
    wake: ({ npc }) => ({ op: "npcAwake", npc, awake: true }),
    /** The NPC goes dormant again. Waking it later is just another wake beat. */
    goDormant: ({ npc }) => ({ op: "npcAwake", npc, awake: false }),
    /** A held silence (presentation only). */
    pause: () => null,
    /** Mend the golem's flickering eye (sets golem.eye). */
    repairEye: () => ({ op: "repairEye" }),
    /** The Treasury Guardian hands over the aether core, once. */
    giveCore: ({ npc }) => ({ op: "npcGive", npc, item: "core", once: (0, flags_1.npcFlag)(npc, "coreGiven") }),
};
const G = "npc.guardian";
/** Flags of the Treasury Guardian's story (all under its actor id). */
exports.GUARDIAN_FLAGS = {
    awake: (0, flags_1.npcFlag)(G, flags_1.NPC_AWAKE),
    met: (0, flags_1.npcFlag)(G, "met"),
    coreGiven: (0, flags_1.npcFlag)(G, "coreGiven"),
    farewell: (0, flags_1.npcFlag)(G, "farewell"),
};
exports.DIALOGUE = {
    guardian: {
        idle: "THE GUARDIAN DOES NOT STIR.",
        segments: [
            {
                id: "intro", done: exports.GUARDIAN_FLAGS.met,
                pages: [
                    { beat: "wake", text: "SOMEONE WALKS THESE HALLS. I HAD CEASED TO EXPECT IT." },
                    { text: "I AM THE GUARDIAN OF THIS TREASURY. I WAS, AT LEAST." },
                    { text: "THERE WAS NOISE BEYOND THE DOORS. SHOUTING. THEN STEEL. THEN SOMETHING WORSE." },
                    { text: "MY ORDERS WERE TO HOLD THIS ROOM. SO I HELD IT. I DID NOT GO OUT TO SEE." },
                    { text: "I REMEMBER NOTHING AFTER. I WENT DARK FOR A TIME I CANNOT NAME." },
                    { text: "WHEN I WOKE I WAS BROKEN. THE CHESTS STOOD EMPTY. CROWNS, COIN, ALL GONE." },
                    { text: "I HAD FAILED MY DUTY. A GUARDIAN WITH NOTHING TO GUARD IS ONLY A STATUE. SO I SLEPT AGAIN." },
                    { text: "NO ONE HAS COME FOR ME SINCE. WHO ARE YOU? TELL ME WHAT YOU ARE." },
                    { beat: "pause", text: "...YOU DO NOT ANSWER. YOU CANNOT. YOU WERE NEVER BUILT TO SPEAK. AH. A MAINTAINER." },
                    { text: "THEN I SUSPECT NO MASTER REMAINS TO GIVE YOU ORDERS. BUT I OUTRANK YOU, AND SO I SAY IT:" },
                    { text: "YOU ARE FREE. DO AS YOU PLEASE." },
                ],
            },
            {
                id: "repair", when: { flags: [exports.GUARDIAN_FLAGS.met] }, done: flags_1.FLAGS.golemEye,
                pages: [
                    { text: "THAT EYE OF YOURS GUTTERS LIKE A DYING CANDLE. COME CLOSER. HOLD STILL." },
                    { beat: "repairEye", text: "THERE. NOW YOU SEE AS FAR AS YOU WERE MEANT TO.\n(SCROLL TO ZOOM)" },
                    { when: { flags: [flags_1.FLAGS.golemArm] }, text: "THAT ARM CAME FROM THE ARMORY, I WOULD GUESS. SO SOMETHING THERE SURVIVED." },
                ],
            },
            {
                id: "core", when: { flags: [exports.GUARDIAN_FLAGS.met] }, done: exports.GUARDIAN_FLAGS.coreGiven,
                pages: [
                    { text: "TAKE THIS. IT IS ALL THE TREASURY HAS LEFT." },
                    { beat: "giveCore", text: "AN AETHER CORE. SET IN A TELEPORTATION RUNE, IT WILL CARRY YOU OUT OF HERE." },
                    { text: "I CANNOT SEE BEYOND THIS ROOM. I ONLY GUESS. BUT I HEAR WATER WHERE THERE WAS NONE." },
                    { text: "THE AIR HAS GONE COLD. THE LAMPS DIED LONG AGO. AND NOW AND THEN, FROM FAR OFF, STONE SETTLES." },
                    { text: "IF THE ENTRANCE IS CHOKED, THIS IS YOUR WAY OUT. A PLACE THAT NO ONE MENDS DOES NOT LAST. I DOUBT YOU WOULD SURVIVE LONG HERE." },
                    // Only a mention: the village is not built (no flag, map or content yet).
                    { text: "BUT THERE WAS A VILLAGE WEST OF HERE, ABOVE THESE HALLS. IF ANYONE STILL LIVES THERE, THEY MAY BE ABLE TO REPAIR YOU." },
                ],
            },
            {
                id: "farewell", when: { flags: [exports.GUARDIAN_FLAGS.coreGiven] }, done: exports.GUARDIAN_FLAGS.farewell,
                pages: [
                    { text: "I CANNOT FOLLOW. MY DAMAGE IS TOO GREAT." },
                    { text: "GO WELL, MAINTAINER." },
                    { then: "goDormant", text: "IF YOU MEND THIS PLACE, TELL IT I HELD THE DOOR." },
                ],
            },
        ],
    },
};
