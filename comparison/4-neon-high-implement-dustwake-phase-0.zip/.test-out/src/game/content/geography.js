"use strict";
// How the areas sit on top of each other (data). The surface is laid over the
// buried dungeon with a fixed tile offset: dungeon tile (x, y) lies under
// surface tile (x + dx, y + dy). Both builders read this one constant, so the
// surface's buried entrance and the dungeon's choked SURFACE GATE corridor
// always agree. Pure; no DOM.
Object.defineProperty(exports, "__esModule", { value: true });
exports.WEST_ROAD = exports.AREA_NAMES = exports.SURFACE_GATE_ZONE = exports.SURFACE_GATE_CORRIDOR = exports.SURFACE_GATE = exports.ENTRANCES = exports.STAIR_CHEEK_TOP = exports.STAIR_CHEEK = exports.GATE_STAIR = exports.GATE_HALL = exports.GATE_PASSAGE = exports.GATE_EXIT = exports.GATE_CORRIDOR = exports.surfaceToDungeon = exports.dungeonToSurface = exports.DUNGEON_TO_SURFACE = void 0;
/** Dungeon tile -> surface tile offset. */
exports.DUNGEON_TO_SURFACE = { dx: 12, dy: 6 };
const dungeonToSurface = (x, y) => ({ x: x + exports.DUNGEON_TO_SURFACE.dx, y: y + exports.DUNGEON_TO_SURFACE.dy });
exports.dungeonToSurface = dungeonToSurface;
const surfaceToDungeon = (x, y) => ({ x: x - exports.DUNGEON_TO_SURFACE.dx, y: y - exports.DUNGEON_TO_SURFACE.dy });
exports.surfaceToDungeon = surfaceToDungeon;
/**
 * The way up to the surface, in dungeon tiles: the south corridor out of the
 * Vestibule (choked with rock until it is dug out from above) and the exit tile
 * marked on the schematic. It was first called the surface gate, and the names
 * keep that; it is a stair (GATE_STAIR below).
 */
exports.GATE_CORRIDOR = { x: 34, y: 50, w: 4, h: 5 };
exports.GATE_EXIT = { x: 36, y: 55 };
/**
 * The whole way up, in dungeon tiles: the corridor plus the exit row. This is
 * what the fall filled (earth and fallen vault, to the roof) and what digging
 * the stair out from above clears.
 */
exports.GATE_PASSAGE = { x: exports.GATE_CORRIDOR.x, y: exports.GATE_CORRIDOR.y, w: exports.GATE_CORRIDOR.w, h: exports.GATE_CORRIDOR.h + 1 };
/** Its north end: a short flagged hall from the Vestibule to the foot of the stair, earth still trodden along it. */
exports.GATE_HALL = { x: exports.GATE_PASSAGE.x, y: exports.GATE_PASSAGE.y, w: exports.GATE_PASSAGE.w, h: 2 };
/**
 * The stair itself: the rest of the passage. The halls are the first cellar
 * floor; this flight climbs south to the surface, from the hall's end to the
 * exit row, between two cheek walls that end in a newel post each.
 */
exports.GATE_STAIR = { x: exports.GATE_PASSAGE.x, y: exports.GATE_HALL.y + exports.GATE_HALL.h, w: exports.GATE_PASSAGE.w, h: exports.GATE_PASSAGE.h - exports.GATE_HALL.h };
/**
 * The stair's stonework that stands in the way (px from the passage's west or
 * east wall, and from the flight's north edge): a newel post at the foot of
 * each cheek wall, then the cheek itself up the side of the flight. The
 * builder places them and art/stairs.ts draws the flight to the same numbers.
 *
 * A post's footprint is `w` wide and `d - 1` deep. Its feet stand `d - lift` px
 * south of the flight's north edge: `lift` raises it off the flight (it first
 * stood `d` px down, so the base of the sprite clipped into the lowest step).
 * `lift: d` puts the feet exactly on that edge, in the hall, and the cheek
 * wall's footprint then begins there too, so post and wall meet with no gap.
 */
exports.STAIR_CHEEK = { post: { w: 12, d: 7, lift: 7 }, wall: { w: 8 } };
/** Where the cheek wall's footprint begins, in px south of the flight's north edge (where the post's feet stand). */
exports.STAIR_CHEEK_TOP = exports.STAIR_CHEEK.post.d - exports.STAIR_CHEEK.post.lift;
exports.ENTRANCES = {
    surface_stair: {
        flag: "entrance.surface_stair.open",
        above: { area: "surface", portal: "stair_down" },
        below: { area: "dungeon", portal: "stair_up", clear: exports.GATE_PASSAGE, removes: ["rockpile", "stairfall"], lights: "stairlight" },
    },
};
/** The same entrance in surface tiles (where the arch lies buried). */
exports.SURFACE_GATE = (0, exports.dungeonToSurface)(exports.GATE_EXIT.x, exports.GATE_EXIT.y);
/** Surface footprint of the buried corridor (tiles), including its walls (x-1 .. x+w). */
exports.SURFACE_GATE_CORRIDOR = { ...(0, exports.dungeonToSurface)(exports.GATE_CORRIDOR.x, exports.GATE_CORRIDOR.y), w: exports.GATE_CORRIDOR.w, h: exports.GATE_CORRIDOR.h };
/**
 * The entrance zone on the surface: the corridor plus its two buried side walls
 * and the arch at its mouth. Everything in it must stay walkable (tested).
 */
exports.SURFACE_GATE_ZONE = {
    x0: exports.SURFACE_GATE_CORRIDOR.x - 1, x1: exports.SURFACE_GATE_CORRIDOR.x + exports.SURFACE_GATE_CORRIDOR.w,
    y0: exports.SURFACE_GATE_CORRIDOR.y - 1, y1: exports.SURFACE_GATE.y + 1,
};
/** What the order screens call an area (bitmap font text). Areas without a row read as their id, uppercased. */
exports.AREA_NAMES = {
    dungeon: "DUNGEON", surface: "SURFACE",
    // The market town west of the surface and the rooms behind its doors (content/town.ts).
    town: "WESTWAKE", town_smithy: "BLACK ANVIL", town_armory: "GILDED BUCKLER", town_jeweler: "BRIGHT FACET",
    town_tailor: "SILVER NEEDLE", town_tavern: "SUNKEN CROWN", town_guild: "GUILD HALL",
};
/**
 * The old road west. On the surface it leaves through the thicket at these rows
 * (tiles); in the town it comes in under the east gate. Both builders read this,
 * so the two ends of the road always agree.
 */
exports.WEST_ROAD = { surface: { y0: 33, y1: 35 }, portal: "west_road" };
