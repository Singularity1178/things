"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.craftRecipesFor = exports.CRAFT_RECIPES = exports.CRAFT_DUR = exports.STATION_REQUIRES = exports.isStation = exports.STATION_IDS = exports.STATIONS = void 0;
exports.rawValue = rawValue;
const flags_1 = require("./flags");
const tools_1 = require("./tools");
exports.STATIONS = {
    crafting: {
        name: "CRAFTING BENCH", prop: "workbench", verb: "CRAFT", requires: { flags: [flags_1.FLAGS.knowBuild] },
        lockedText: "YOU DON'T KNOW HOW TO CRAFT YET", lockedHint: "FIND OUT HOW TO BUILD.", accent: "#e8d8a8",
    },
    // Smelting is read off a smelter with golem vision (content/build.ts: the SMELTER row `teaches` it), not out of a book.
    smelting: {
        name: "SMELTER", prop: "forge", verb: "SMELT", requires: { flags: [flags_1.FLAGS.knowSmelt] },
        lockedText: "YOU DON'T KNOW HOW TO SMELT YET", lockedHint: "STUDY A SMELTER: Z, THEN E.", accent: "#ffa860",
    },
    smithing: {
        name: "ANVIL", prop: "anvil", verb: "FORGE", requires: { flags: [flags_1.FLAGS.knowBuild] },
        lockedText: "YOU DON'T KNOW HOW TO SMITH YET", lockedHint: "FIND OUT HOW TO BUILD.", accent: "#a8d0f0",
        tabs: [
            { id: "forge", name: "FORGE", verb: "FORGE", empty: ["NOTHING TO FORGE."] },
            { id: "repair", name: "REPAIR", verb: "REPAIR", empty: ["NOTHING TO REPAIR.", "CARRY A RUSTED HEAD."] },
            { id: "modify", name: "MODIFY", verb: "TEMPER", empty: ["NOTHING TO MODIFY.", "CARRY A TOOL OR A HEAD.", "TAKE IT OFF YOUR ARM."] },
            { id: "runes", name: "RUNES", verb: "SET", empty: ["NO HEAD TO SET A RUNE", "IN. IT MUST BE FINE", "(TEMPERED) IRON."] },
        ],
    },
};
exports.STATION_IDS = Object.keys(exports.STATIONS);
const isStation = (s) => s in exports.STATIONS;
exports.isStation = isStation;
/** What a crafter must know before a station shows any plans (from STATIONS). The bench and the anvil: building. The smelter: smelting. */
exports.STATION_REQUIRES = Object.fromEntries(exports.STATION_IDS.map((id) => [id, exports.STATIONS[id].requires]));
exports.CRAFT_DUR = 1.2;
exports.CRAFT_RECIPES = [
    {
        id: "planks", name: "PLANKS", station: "crafting", dur: 1.0,
        desc: ["SAW ROUGH WOOD INTO PLANKS", "FOR TABLES, CHAIRS, BANNERS", "AND OTHER FINER BUILDS."],
        inputs: [{ item: "wood", n: 2 }], output: { item: "planks", n: 3 },
    },
    {
        id: "cut_stone", name: "CUT STONE", station: "crafting", dur: 1.4,
        desc: ["SQUARE ROUGH STONE INTO", "BLOCKS. SOME IS LOST IN THE", "CUTTING."],
        inputs: [{ item: "stone", n: 3 }], output: { item: "cut_stone", n: 2 },
    },
    {
        id: "rune_swift", name: "RUNE OF SWIFT", station: "crafting", dur: 2.4,
        desc: ["CARVE THE SIGN OF SWIFTNESS", "INTO CUT STONE. NEEDS THE", "RUNE CHISEL IN YOUR PACK."],
        inputs: [{ item: "cut_stone", n: 2 }], tools: ["chisel"], output: { item: "rune_swift", n: 1 },
    },
    {
        id: "rune_glow", name: "RUNE OF GLOW", station: "crafting", dur: 2.4,
        desc: ["CARVE THE SIGN OF LIGHT", "INTO CUT STONE. NEEDS THE", "RUNE CHISEL IN YOUR PACK."],
        inputs: [{ item: "cut_stone", n: 3 }], tools: ["chisel"], output: { item: "rune_glow", n: 1 },
    },
    {
        // The crown holds the game's one High-Grade Ruby, so exactly one core can ever be carved.
        id: "ruby_core", name: "RUBY GOLEM CORE", station: "crafting", dur: 2.4,
        desc: ["CARVE THE HIGH-GRADE RUBY", "INTO A GOLEM CORE. NEEDS THE", "RUNE CHISEL IN YOUR PACK."],
        inputs: [{ item: "large_ruby", n: 1 }], tools: ["chisel"], output: { item: "ruby_core", n: 1 },
    },
    // ---- inverse rows: names stay distinct (and within the list's 20 characters) so each reads on its own.
    {
        id: "unmake_crown", mode: "deconstruct", name: "UNMAKE BROKEN CROWN", station: "crafting", dur: 1.6,
        desc: ["PRY THE HIGH-GRADE RUBY OUT", "OF THE BROKEN CROWN. ITS", "SOFT GOLD IS OF NO USE."],
        inputs: [{ item: "crown", n: 1 }], output: { item: "large_ruby", n: 1 },
    },
    ...[["rune_swift", "SWIFT"], ["rune_glow", "GLOW"]].map(([item, sign]) => ({
        id: `unmake_${item}`, mode: "deconstruct", name: `UNMAKE RUNE OF ${sign}`, station: "crafting",
        desc: ["GRIND THE SIGN OFF A RUNE OF", `${sign}. ONE ROUGH STONE IS`, "ALL THAT IS LEFT."],
        inputs: [{ item, n: 1 }], output: { item: "stone", n: 1 },
    })),
    // ---- the crafting bench: a head on a wooden haft is a full tool, for hands (content/tools.ts)
    ...tools_1.TOOL_TYPE_IDS.flatMap((t) => [
        {
            id: (0, tools_1.fullToolId)(t), name: tools_1.TOOL_TYPES[t].full, station: "crafting", dur: 1.2,
            desc: [`FIT A ${tools_1.TOOL_TYPES[t].name} HEAD TO A WOODEN`, "HAFT: A TOOL FOR HANDS. GIVE", "IT TO A WORKER."],
            inputs: [{ item: (0, tools_1.headId)(t), n: 1 }, { item: "wood", n: tools_1.HAFT_WOOD }], output: { item: (0, tools_1.fullToolId)(t), n: 1 },
        },
        {
            id: (0, tools_1.fineToolId)(t), name: `FINE ${tools_1.TOOL_TYPES[t].full}`, station: "crafting", dur: 1.2, work: (0, tools_1.fineHeadId)(t),
            desc: [`HAFT A FINE ${tools_1.TOOL_TYPES[t].name} HEAD: A`, "TEMPERED TOOL FOR HANDS."],
            inputs: [{ item: (0, tools_1.fineHeadId)(t), n: 1 }, { item: "wood", n: tools_1.HAFT_WOOD }], output: { item: (0, tools_1.fineToolId)(t), n: 1 },
        },
    ]),
    // ---- the smelter: ore and a wood fire in, ingots out
    {
        id: "iron_ingot", name: "IRON INGOT", station: "smelting", dur: 2.6,
        desc: ["MELT IRON ORE OVER A WOOD", "FIRE AND POUR IT INTO BARS."],
        inputs: [{ item: "iron_ore", n: 2 }, { item: "wood", n: 1 }], output: { item: "iron_ingot", n: 2 },
    },
    {
        id: "iron_ingot_charge", name: "INGOTS, FULL CHARGE", station: "smelting", dur: 5, valuation: false,
        desc: ["FILL THE CRUCIBLE. A FULL", "CHARGE WASTES LESS FUEL."],
        inputs: [{ item: "iron_ore", n: 6 }, { item: "wood", n: 2 }], output: { item: "iron_ingot", n: 6 },
    },
    // ---- the anvil. FORGE: ingots into tool heads.
    ...tools_1.TOOL_TYPE_IDS.map((t) => ({
        id: (0, tools_1.headId)(t), name: `${tools_1.TOOL_TYPES[t].name} HEAD`, station: "smithing", tab: "forge", dur: 2.4,
        desc: [`HAMMER ${tools_1.FORGE_COST[t]} IRON INGOTS INTO A`, `${tools_1.TOOL_TYPES[t].name} HEAD. FIT IT TO AN ARM`, "OR HAFT IT AT A BENCH."],
        inputs: [{ item: "iron_ingot", n: tools_1.FORGE_COST[t] }], output: { item: (0, tools_1.headId)(t), n: 1 },
    })),
    // REPAIR: what time ruined, made sound for less iron than a new one. Never the head's valuation row.
    ...tools_1.TOOL_TYPE_IDS.map((t) => ({
        id: `repair_${(0, tools_1.headId)(t)}`, name: `REPAIR ${tools_1.TOOL_TYPES[t].name} HEAD`, station: "smithing", tab: "repair", dur: 1.6, valuation: false, work: (0, tools_1.rustedHeadId)(t),
        desc: ["BURN OFF THE RUST AND WELD", "NEW IRON INTO THE OLD HEAD."],
        inputs: [{ item: (0, tools_1.rustedHeadId)(t), n: 1 }, { item: "iron_ingot", n: tools_1.REPAIR_COST }], output: { item: (0, tools_1.headId)(t), n: 1 },
    })),
    // MODIFY: temper a head, or a tool on its haft.
    ...tools_1.TOOL_TYPE_IDS.flatMap((t) => [
        {
            id: `temper_${(0, tools_1.headId)(t)}`, name: `TEMPER ${tools_1.TOOL_TYPES[t].name} HEAD`, station: "smithing", tab: "modify", dur: 2.6, work: (0, tools_1.headId)(t),
            desc: ["FOLD IN MORE IRON AND QUENCH", "IT. BITES DEEPER, AND WILL", "HOLD A RUNE."],
            inputs: [{ item: (0, tools_1.headId)(t), n: 1 }, { item: "iron_ingot", n: tools_1.TEMPER_COST }], output: { item: (0, tools_1.fineHeadId)(t), n: 1 },
        },
        {
            id: `temper_${(0, tools_1.fullToolId)(t)}`, name: `TEMPER ${tools_1.TOOL_TYPES[t].full}`, station: "smithing", tab: "modify", dur: 2.6, valuation: false, work: (0, tools_1.fullToolId)(t),
            desc: ["REWORK THE HEAD ON ITS HAFT", "WITH MORE IRON. IT BITES", "DEEPER."],
            inputs: [{ item: (0, tools_1.fullToolId)(t), n: 1 }, { item: "iron_ingot", n: tools_1.TEMPER_COST }], output: { item: (0, tools_1.fineToolId)(t), n: 1 },
        },
    ]),
    // RUNES: set a rune into a tempered head (its worn effect then rides on the arm), or pry it back out.
    ...tools_1.TOOL_TYPE_IDS.flatMap((t) => tools_1.TOOL_RUNES.flatMap((r) => [
        {
            id: `inset_${r}_${t}`, name: `${r.toUpperCase()} IN ${tools_1.TOOL_TYPES[t].name} HEAD`, station: "smithing", tab: "runes", dur: 2, work: (0, tools_1.fineHeadId)(t),
            desc: [`SET A RUNE OF ${r.toUpperCase()} INTO THE`, "TEMPERED HEAD. IT WORKS WHILE", "THE HEAD IS ON YOUR ARM."],
            inputs: [{ item: (0, tools_1.fineHeadId)(t), n: 1 }, { item: (0, tools_1.runeItemId)(r), n: 1 }], output: { item: (0, tools_1.runedHeadId)(t, r), n: 1 },
        },
        {
            id: `unset_${r}_${t}`, mode: "deconstruct", name: `UNSET ${r.toUpperCase()}, ${tools_1.TOOL_TYPES[t].name}`, station: "smithing", tab: "runes", verb: "UNSET", dur: 1.4, work: (0, tools_1.runedHeadId)(t, r),
            desc: ["PRY THE RUNE BACK OUT. BOTH", "THE HEAD AND THE RUNE ARE", "KEPT."],
            inputs: [{ item: (0, tools_1.runedHeadId)(t, r), n: 1 }], output: { item: (0, tools_1.fineHeadId)(t), n: 1 }, also: [{ item: (0, tools_1.runeItemId)(r), n: 1 }],
        },
    ])),
];
const craftRecipesFor = (station, list = exports.CRAFT_RECIPES) => list.filter((r) => r.station === station);
exports.craftRecipesFor = craftRecipesFor;
/**
 * What one unit of an item is worth in raw materials (wood, stone and anything
 * not crafted count 1), derived from the recipe that makes it. The build menu
 * sorts by this, so a crafted material weighs what it cost to make.
 */
function rawValue(item, list = exports.CRAFT_RECIPES, _depth = 0) {
    const value = (id, seen) => {
        if (seen.has(id))
            return 1;
        const rows = list.filter((r) => r.output.item === id && r.mode !== "deconstruct" && r.valuation !== false)
            .sort((a, b) => Number(!!b.valuation) - Number(!!a.valuation) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
        const r = rows[0];
        if (!r || r.output.n <= 0)
            return 1;
        const next = new Set(seen).add(id);
        return r.inputs.reduce((n, c) => n + c.n * value(c.item, next), 0) / r.output.n;
    };
    return value(item, new Set());
}
