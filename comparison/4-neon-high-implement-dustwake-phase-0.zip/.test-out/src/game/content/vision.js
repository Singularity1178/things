"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.analysisFlag = exports.VISION_OFF_OPS = exports.SCAN_DURATION = exports.HIGHLIGHT_RULES = exports.OVERLAY_PALETTES = exports.VISION_CATEGORIES = void 0;
exports.visionColor = visionColor;
exports.VISION_CATEGORIES = {
    important: { color: "#ffd27a", effect: "radiant" }, interactable: { color: "#74dce2", effect: "wireframe" },
    npc: { color: "#c5a0ff", effect: "signal" }, buildable: { color: "#97d38a", effect: "blueprint" },
};
/**
 * Color-blind-safe palettes for vision & management overlays (Phase 0.7).
 * Based on Okabe-Ito and Paul Tol high-separation categorical palettes.
 */
exports.OVERLAY_PALETTES = {
    default: {
        important: "#ffd27a", interactable: "#74dce2", npc: "#c5a0ff", buildable: "#97d38a",
        ok: "#7ae08a", warn: "#f0b050", alert: "#e86a6a", info: "#74dce2",
    },
    deuteranopia: {
        important: "#e69f00", interactable: "#56b4e9", npc: "#cc79a7", buildable: "#f0e442",
        ok: "#56b4e9", warn: "#f0e442", alert: "#d55e00", info: "#0072b2",
    },
    protanopia: {
        important: "#f0e442", interactable: "#56b4e9", npc: "#cc79a7", buildable: "#009e73",
        ok: "#009e73", warn: "#f0e442", alert: "#e69f00", info: "#56b4e9",
    },
    tritanopia: {
        important: "#ff8844", interactable: "#44ccbb", npc: "#ee6688", buildable: "#f0f0f0",
        ok: "#44ccbb", warn: "#ffaa44", alert: "#ee3355", info: "#77bbff",
    },
    highContrast: {
        important: "#ffee00", interactable: "#00ffff", npc: "#ff66ff", buildable: "#66ff66",
        ok: "#55ff55", warn: "#ffee00", alert: "#ff4444", info: "#00ffff",
    },
};
function visionColor(category, palette = "default") {
    return (exports.OVERLAY_PALETTES[palette] ?? exports.OVERLAY_PALETTES.default)[category];
}
/** First matching row wins. A new category rule is data, not a host branch. */
exports.HIGHLIGHT_RULES = [
    { category: "important", tags: ["rune", "glyph", "part", "document", "relic", "power"] },
    { category: "important", trait: "rune" },
    { category: "npc", trait: "actor" },
    { category: "buildable", trait: "buildable" },
    { category: "interactable", trait: "interactable" },
];
exports.SCAN_DURATION = 0.9;
/**
 * Effects that take the golem's attention elsewhere (a conversation, a rune jump,
 * a work/storage/management screen). Starting a task with one of these ends vision
 * mode on its own, so the overlay plays its normal switch-off.
 */
exports.VISION_OFF_OPS = ["talk", "travel", "useStation", "useStorage", "manageActor"];
const analysisFlag = (key) => `analysis.${key}`;
exports.analysisFlag = analysisFlag;
