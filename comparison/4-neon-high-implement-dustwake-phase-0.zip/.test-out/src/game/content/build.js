"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DECONSTRUCT_DUR = exports.BUILD_REACH = exports.recipeForProp = exports.AUTHORED_SALVAGE = exports.EXTRA_SALVAGE = exports.costTotal = exports.placeRule = exports.RECIPE_IDS = exports.RECIPES = exports.categoryIndex = exports.categoryName = exports.BUILD_CATEGORIES = void 0;
exports.scanHint = scanHint;
const flags_1 = require("./flags");
const crafting_1 = require("./crafting");
/** Build menu categories, in tab order. */
exports.BUILD_CATEGORIES = [
    { id: "light", name: "LIGHT" },
    { id: "craft", name: "CRAFT" },
    { id: "defense", name: "DEFENSE" },
    { id: "furniture", name: "FURNITURE" },
    { id: "decor", name: "DECOR" },
];
const categoryName = (c) => exports.BUILD_CATEGORIES.find((k) => k.id === c)?.name ?? c.toUpperCase();
exports.categoryName = categoryName;
const categoryIndex = (c) => exports.BUILD_CATEGORIES.findIndex((k) => k.id === c);
exports.categoryIndex = categoryIndex;
const KNOW_BUILD = { flags: [flags_1.FLAGS.knowBuild] };
exports.RECIPES = {
    torch_post: {
        name: "TORCH POST", category: "light", order: 0, prop: "torch_post", lit: true,
        desc: ["A FREESTANDING TORCH ON A", "WOODEN POLE. STANDS ON ANY", "OPEN GROUND."],
        cost: [{ item: "wood", n: 2 }, { item: "stone", n: 1 }], requires: KNOW_BUILD,
    },
    wall_torch: {
        name: "WALL TORCH", category: "light", order: 1, prop: "torch", lit: true, place: "wall",
        desc: ["AN IRON SCONCE FOR WALLS. HANGS", "ON THE LIT FACE OF A WALL", "WITH FLOOR IN FRONT OF IT."],
        cost: [{ item: "cut_stone", n: 1 }, { item: "wood", n: 1 }], requires: KNOW_BUILD, analysis: "wall_torch",
    },
    brazier: {
        name: "BRAZIER", category: "light", order: 2, prop: "brazier", lit: true, dur: 1.1,
        desc: ["A STONE FIRE BOWL. BURNS", "BRIGHT AND WIDE. NEEDS THE", "MASON'S KNOWLEDGE."],
        cost: [{ item: "cut_stone", n: 4 }, { item: "wood", n: 2 }], requires: { flags: [flags_1.FLAGS.knowMasonry] }, analysis: "brazier",
    },
    craftbench: {
        // Builds the same `workbench` prop the dungeon's artificery has (same sprite, same station).
        name: "CRAFTING BENCH", category: "craft", order: 0, prop: "workbench", dur: 1.4,
        desc: ["A STURDY BENCH TO WORK AT.", "USE IT TO OPEN THE CRAFTING", "PLANS. TAKES THREE TILES."],
        cost: [{ item: "wood", n: 6 }, { item: "stone", n: 2 }], requires: KNOW_BUILD, analysis: "craftbench",
    },
    smelter: {
        // Builds the artificery's own `forge` prop (same sprite, same station). Stone only: iron comes out of it.
        name: "SMELTER", category: "craft", order: 1, prop: "forge", dur: 1.6,
        desc: ["A STONE FURNACE. MELTS ORE", "INTO INGOTS OVER A WOOD FIRE.", "TAKES THREE TILES."],
        cost: [{ item: "cut_stone", n: 6 }, { item: "stone", n: 4 }], requires: KNOW_BUILD, analysis: "smelter", teaches: flags_1.FLAGS.knowSmelt,
    },
    anvil: {
        name: "ANVIL", category: "craft", order: 2, prop: "anvil", dur: 1.2,
        desc: ["AN IRON ANVIL ON AN OAK BLOCK.", "FORGE, REPAIR AND TEMPER TOOLS", "AND SET RUNES IN THEM."],
        cost: [{ item: "iron_ingot", n: 5 }, { item: "wood", n: 2 }], requires: KNOW_BUILD, analysis: "anvil",
    },
    barricade: {
        name: "BARRICADE", category: "defense", order: 0, prop: "barricade", dur: 1.0,
        desc: ["SHARPENED STAKES. NOTHING", "WALKS THROUGH IT. BLOCK A", "DOOR OR A PASSAGE."],
        cost: [{ item: "wood", n: 3 }], requires: KNOW_BUILD,
    },
    table: {
        name: "TABLE", category: "furniture", order: 0, prop: "table", dur: 1.0,
        desc: ["A PLAIN PLANK TABLE.", "TAKES THREE TILES OF FLOOR."],
        cost: [{ item: "planks", n: 4 }], requires: KNOW_BUILD, analysis: "table",
    },
    chair: {
        name: "CHAIR", category: "furniture", order: 1, prop: "chair",
        desc: ["SOMEWHERE TO SIT, IF A", "GOLEM EVER NEEDED TO."],
        cost: [{ item: "planks", n: 2 }], requires: KNOW_BUILD, analysis: "chair",
    },
    storage_chest: {
        // Its own kind (sharing only the looted chest's art), never the dungeon's `chest`: those stay out of
        // AUTHORED_SALVAGE. No storage chest stands in the dungeon, so its plan is read off the looted ones.
        name: "STORAGE CHEST", category: "furniture", order: 2, prop: "storage_chest", dur: 1.0,
        desc: ["A PLANK CHEST WITH 32 SLOTS", "FOR KEEPING MATERIALS. TAKES", "ONE TILE OF FLOOR."],
        cost: [{ item: "planks", n: 4 }], requires: KNOW_BUILD,
        analysis: "storage_chest", learnFrom: [{ kind: "chest", name: "OLD CHEST" }],
    },
    wall_banner: {
        name: "WALL BANNER", category: "decor", order: 0, prop: "banner", v: 3, place: "wall",
        desc: ["A CRIMSON BANNER ON AN IRON", "ROD. HANGS ON A WALL FACE."],
        cost: [{ item: "planks", n: 1 }, { item: "cut_stone", n: 1 }], requires: KNOW_BUILD, analysis: "wall_banner",
    },
};
exports.RECIPE_IDS = Object.keys(exports.RECIPES);
/** What the build menu tells the player to scan for a plan: the first `learnFrom` example, else the thing itself. */
function scanHint(r) {
    const name = r.learnFrom?.[0]?.name ?? r.name;
    return `${/^[AEIOU]/.test(name) ? "AN" : "A"} ${name}`;
}
const placeRule = (r) => r.place ?? "floor";
exports.placeRule = placeRule;
/** What a recipe costs in raw-material units (crafted materials weigh what they cost to make): the build menu's cost sort. */
const costTotal = (r) => Math.round(r.cost.reduce((s, c) => s + c.n * (0, crafting_1.rawValue)(c.item), 0) * 100) / 100;
exports.costTotal = costTotal;
/** Authored kinds that no recipe builds but may still be taken apart (none yet). */
exports.EXTRA_SALVAGE = {};
exports.AUTHORED_SALVAGE = (() => {
    const t = {};
    for (const [id, r] of Object.entries(exports.RECIPES))
        if (!(r.prop in t))
            t[r.prop] = { recipe: id };
    return { ...t, ...exports.EXTRA_SALVAGE };
})();
/** The recipe that builds a prop kind (first match), for built props saved before recipes were recorded. */
const recipeForProp = (kind) => Object.keys(exports.RECIPES).find((id) => exports.RECIPES[id].prop === kind);
exports.recipeForProp = recipeForProp;
/** How far (in tiles, Chebyshev) from the builder a placement may be. */
exports.BUILD_REACH = 2;
/** Seconds of work to take a prop apart. */
exports.DECONSTRUCT_DUR = 0.9;
