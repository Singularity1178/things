"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.meets = meets;
const world_1 = require("../world/world");
const tools_1 = require("./tools");
function meets(w, a, req) {
    if (!req)
        return true;
    if (req.items && !req.items.every((i) => a.inventory.some((s) => s?.item === i)))
        return false;
    if (req.flags && !req.flags.every((f) => (0, world_1.isBodyFlag)(f) ? (0, world_1.actorHasFlag)(a, f) : (0, world_1.hasFlag)(w, f)))
        return false;
    if (req.actorFlags && !req.actorFlags.every((f) => a.upgrades.includes(f)))
        return false;
    if (req.worn && !req.worn.every((i) => Object.values(a.gear ?? {}).includes(i)))
        return false;
    if (req.tools && !req.tools.every((t) => (0, tools_1.toolBonus)(a, t) > 0))
        return false;
    if (req.any && !req.any.some((r) => meets(w, a, r)))
        return false;
    return true;
}
