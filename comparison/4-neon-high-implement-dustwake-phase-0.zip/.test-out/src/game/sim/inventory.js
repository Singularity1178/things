"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeItems = exports.heldItems = exports.hasItem = exports.countItem = void 0;
exports.capacity = capacity;
exports.slotsNeeded = slotsNeeded;
exports.repackInto = repackInto;
exports.reconcileCapacity = reconcileCapacity;
exports.addItems = addItems;
exports.roomFor = roomFor;
exports.giveItem = giveItem;
exports.dropSpot = dropSpot;
exports.spawnLoose = spawnLoose;
// Actor inventories: an ordered array of slots ({item, n} or null). Capacity is
// derived from world/actor state (content/inventory.ts), never stored. All
// functions here are pure sim (no DOM) and work for any actor.
const props_1 = require("../content/props");
const actors_1 = require("../content/actors");
const items_1 = require("../content/items");
const tiles_1 = require("../content/tiles");
const world_1 = require("../world/world");
const requirements_1 = require("./requirements");
const collision_1 = require("./collision");
const inventoryOps_1 = require("./inventoryOps");
const discovery_1 = require("./discovery");
var inventoryOps_2 = require("./inventoryOps");
Object.defineProperty(exports, "countItem", { enumerable: true, get: function () { return inventoryOps_2.countItem; } });
Object.defineProperty(exports, "hasItem", { enumerable: true, get: function () { return inventoryOps_2.hasItem; } });
Object.defineProperty(exports, "heldItems", { enumerable: true, get: function () { return inventoryOps_2.heldItems; } });
Object.defineProperty(exports, "removeItems", { enumerable: true, get: function () { return inventoryOps_2.removeItems; } });
/** Slot count for this actor right now: the highest satisfied tier. */
function capacity(w, a) {
    const def = (0, actors_1.actorDef)(a).inventory;
    let n = def.slots;
    for (const t of def.tiers ?? [])
        if (t.slots > n && (0, requirements_1.meets)(w, a, t.requires))
            n = t.slots;
    return n;
}
/** Slots these stacks need when packed tight: units of one item merge, up to its stack size per slot. */
function slotsNeeded(stacks) {
    const units = new Map();
    for (const s of stacks)
        units.set(s.item, (units.get(s.item) ?? 0) + s.n);
    let k = 0;
    for (const [id, n] of units)
        k += Math.ceil(n / (0, items_1.maxStack)(id));
    return k;
}
/** Pour stacks into slots: matching stacks with room first, then empty slots (as addItems does). False if anything is left over. */
function pour(slots, stacks) {
    for (const st of stacks) {
        const max = (0, items_1.maxStack)(st.item);
        let n = st.n;
        for (let i = 0; i < slots.length && n > 0; i++) {
            const s = slots[i];
            if (s && s.item === st.item && s.n < max) {
                const k = Math.min(n, max - s.n);
                s.n += k;
                n -= k;
            }
        }
        for (let i = 0; i < slots.length && n > 0; i++) {
            if (slots[i])
                continue;
            const k = Math.min(n, max);
            slots[i] = { item: st.item, n: k };
            n -= k;
        }
        if (n > 0)
            return false;
    }
    return true;
}
/**
 * Fit the actor's pack, plus `extra`, into exactly `cap` slots without
 * dropping anything (taking gear off uses it). Gentle first: slots inside
 * `cap` stay where they are, and stacks beyond it, then `extra`, pour into
 * matching stacks and empty slots. Only if that isn't enough is the pack
 * compacted (same items merged, in order of first appearance). If even that
 * can't hold everything it returns false and changes nothing.
 */
function repackInto(a, cap, extra = []) {
    const inv = a.inventory;
    const held = inv.flatMap((s) => (s ? [{ item: s.item, n: s.n }] : []));
    if (slotsNeeded([...held, ...extra]) > cap)
        return false;
    let next = Array.from({ length: cap }, (_, i) => (inv[i] ? { ...inv[i] } : null));
    const beyond = inv.slice(cap).flatMap((s) => (s ? [{ item: s.item, n: s.n }] : []));
    if (!pour(next, [...beyond, ...extra])) {
        next = Array.from({ length: cap }, () => null);
        pour(next, [...held, ...extra]);
    }
    inv.length = 0;
    inv.push(...next);
    return true;
}
/**
 * Make the slot array match capacity. Growth only appends empty slots, so
 * nothing moves. If capacity shrinks (it shouldn't in play, but debug keys and
 * old saves can do it) items beyond capacity are first packed into free room
 * within capacity and anything that still doesn't fit is dropped into the
 * world next to the actor. Items never vanish.
 */
function reconcileCapacity(w, a) {
    const cap = capacity(w, a);
    const inv = a.inventory;
    while (inv.length < cap)
        inv.push(null);
    if (inv.length === cap)
        return;
    const extra = inv.splice(cap);
    for (const s of extra) {
        if (!s)
            continue;
        const left = addItems(w, a, s.item, s.n);
        if (left > 0) {
            const area = (0, world_1.areaOf)(w, a);
            const spot = dropSpot(area, a, (0, collision_1.actorBoxes)(w, area.id, a.id));
            const x = spot ? spot.x : a.x, y = spot ? spot.y : a.y;
            spawnLoose(area, s.item, left, x, y);
            (0, world_1.emit)(w, { t: "itemDropped", actor: a.id, item: s.item, n: left, x, y, reason: "overflow" });
        }
    }
}
/** Store up to n units. Fills existing stacks first, then empty slots. Returns units that did not fit. */
function addItems(w, a, id, n) {
    const left = (0, inventoryOps_1.insertItems)(a.inventory, capacity(w, a), id, n);
    if (left < n)
        (0, discovery_1.rememberItem)(w, a, id);
    return left;
}
/** How many units of `id` would fit right now. */
function roomFor(w, a, id) {
    return (0, inventoryOps_1.roomIn)(a.inventory, capacity(w, a), id);
}
/**
 * Give items to an actor. Whatever doesn't fit (full pack) is dropped on the
 * ground next to the actor as a loose item, so nothing is ever lost.
 */
function giveItem(w, a, id, n = 1) {
    (0, discovery_1.rememberItem)(w, a, id);
    const left = addItems(w, a, id, n);
    if (left < n)
        (0, world_1.emit)(w, { t: "itemGained", actor: a.id, item: id, stored: true, n: n - left });
    if (left > 0) {
        const area = (0, world_1.areaOf)(w, a);
        const spot = dropSpot(area, a, (0, collision_1.actorBoxes)(w, area.id, a.id));
        const x = spot ? spot.x : a.x, y = spot ? spot.y : a.y;
        spawnLoose(area, id, left, x, y);
        (0, world_1.emit)(w, { t: "packFull", actor: a.id, item: id });
        (0, world_1.emit)(w, { t: "itemDropped", actor: a.id, item: id, n: left, x, y, reason: "full" });
    }
}
// ---------------------------------------------------------------- placement
/** Candidate offsets as [forward, sideways] relative to the actor's facing, in preference order. */
const DROP_ORDER = [
    [1, 0], [0, 0], [1, -1], [1, 1], [0, -1], [0, 1], [-1, 0], [-1, -1], [-1, 1],
    [2, 0], [2, -1], [2, 1], [0, -2], [0, 2], [-2, 0], [2, -2], [2, 2], [-2, -1], [-2, 1],
];
function tileFree(area, tx, ty, bodies) {
    if (tx < 0 || ty < 0 || tx >= area.w || ty >= area.h)
        return false;
    if ((0, tiles_1.isSolidT)(area.grid[ty * area.w + tx]))
        return false;
    const cx = tx * tiles_1.TS + 8, cy = ty * tiles_1.TS + 11;
    for (const p of area.props) {
        const b = p.box;
        if (b && !p.taken && !((0, props_1.propDef)(p.kind).openBox && !p.open) && cx > b[0] - 3 && cx < b[2] + 3 && cy > b[1] - 3 && cy < b[3] + 3)
            return false;
    }
    for (const b of bodies)
        if (cx > b[0] - 3 && cx < b[2] + 3 && cy > b[1] - 3 && cy < b[3] + 3)
            return false;
    return true;
}
/**
 * Where an actor's dropped item lands: the tile in front of it if free, else
 * its own tile, then the nearest free tile around it in a fixed order relative
 * to facing. Fully deterministic (no randomness). Null if boxed in.
 */
function dropSpot(area, a, bodies = []) {
    const fx = a.facing === "left" ? -1 : a.facing === "right" ? 1 : 0;
    const fy = a.facing === "up" ? -1 : a.facing === "down" ? 1 : 0;
    const gx = Math.floor(a.x / tiles_1.TS), gy = Math.floor((a.y - 3) / tiles_1.TS);
    for (const [f, s] of DROP_ORDER) {
        const tx = gx + f * fx - s * fy, ty = gy + f * fy + s * fx;
        if (tileFree(area, tx, ty, bodies))
            return { x: tx * tiles_1.TS + 8, y: ty * tiles_1.TS + 11, tx, ty };
    }
    return null;
}
/** Put a loose stack in the world, merging into a same-item stack already on that spot. */
function spawnLoose(area, item, n, x, y) {
    const max = (0, items_1.maxStack)(item);
    for (const l of area.loose) {
        if (n <= 0)
            break;
        if (l.taken || l.item !== item || l.x !== x || l.y !== y)
            continue;
        const k = Math.min(n, max - (l.n ?? 1));
        if (k > 0) {
            area.setLooseCount(l.id, (l.n ?? 1) + k);
            n -= k;
        }
    }
    while (n > 0) {
        const k = Math.min(n, max);
        area.addLoose(item, k, x, y);
        n -= k;
    }
}
