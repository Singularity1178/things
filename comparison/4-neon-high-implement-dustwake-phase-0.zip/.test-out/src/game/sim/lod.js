"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_VIEW_PAD = exports.DEFAULT_FAR_STRIDE = exports.DEFAULT_NEAR_STRIDE = void 0;
exports.createLodConfig = createLodConfig;
exports.actorBucket = actorBucket;
exports.classifyActorLod = classifyActorLod;
exports.actorStepDt = actorStepDt;
exports.catchUpArea = catchUpArea;
const world_1 = require("../world/world");
const folk_1 = require("./folk");
exports.DEFAULT_NEAR_STRIDE = 4;
exports.DEFAULT_FAR_STRIDE = 4;
exports.DEFAULT_VIEW_PAD = 48;
function createLodConfig() {
    return {
        pad: exports.DEFAULT_VIEW_PAD,
        nearStride: exports.DEFAULT_NEAR_STRIDE,
        farStride: exports.DEFAULT_FAR_STRIDE,
        tick: 0,
        counts: { active: 0, near: 0, far: 0 },
    };
}
/** Deterministic small integer bucket from actor id (FNV-1a 32-bit). */
function actorBucket(id) {
    let h = 2166136261;
    for (let i = 0; i < id.length; i++) {
        h ^= id.charCodeAt(i);
        h = Math.imul(h, 16777619);
    }
    return h >>> 0;
}
/** Classify an actor into Active, Near, or Far relative to player & camera view. */
function classifyActorLod(w, a, view, pad = exports.DEFAULT_VIEW_PAD) {
    const pl = (0, world_1.player)(w);
    if (!pl)
        return "active";
    if (a.id === w.playerId)
        return "active";
    if (a.area !== pl.area)
        return "far";
    if (!view)
        return "active";
    const inView = a.x >= view.x - pad &&
        a.x <= view.x + view.w + pad &&
        a.y >= view.y - pad &&
        a.y <= view.y + view.h + pad;
    return inView ? "active" : "near";
}
/**
 * Determine whether an actor should step on this tick, and the effective `dt`
 * it should simulate with. Returns `0` when skipped this tick.
 */
function actorStepDt(w, a, dt) {
    const lod = w.lod;
    const tier = classifyActorLod(w, a, lod?.view, lod?.pad ?? exports.DEFAULT_VIEW_PAD);
    if (tier === "active")
        return { tier, stepDt: dt };
    if (tier === "near") {
        const stride = Math.max(1, lod?.nearStride ?? exports.DEFAULT_NEAR_STRIDE);
        if (stride === 1)
            return { tier, stepDt: dt };
        const tick = lod?.tick ?? 0;
        const due = (actorBucket(a.id) % stride) === (tick % stride);
        return { tier, stepDt: due ? dt * stride : 0 };
    }
    // Far tier:
    // - Folk & keepers are schedule-based and skipped completely until catch-up on area entry.
    // - Actors with an active task or unfinished job still progress at Far stride so
    //   off-screen workers complete logistics across areas.
    if ((0, folk_1.isFolk)(a) || a.kind === "keeper") {
        return { tier, stepDt: 0 };
    }
    const hasWork = !!a.task || (!!a.job && a.job.status !== "done");
    if (!hasWork)
        return { tier, stepDt: 0 };
    const farStride = lod?.view ? Math.max(1, lod.farStride ?? exports.DEFAULT_FAR_STRIDE) : 1;
    if (farStride === 1)
        return { tier, stepDt: dt };
    const tick = lod?.tick ?? 0;
    const due = (actorBucket(a.id) % farStride) === (tick % farStride);
    return { tier, stepDt: due ? dt * farStride : 0 };
}
/**
 * Catch up a Far area when the player enters it (or on explicit refresh),
 * using `elapsed = world.time - area.lastTicked`.
 * Advances area-level timers (rituals) and settles schedule-driven residents
 * to where the current calendar hour says they belong.
 */
function catchUpArea(w, area) {
    const elapsed = Math.max(0, w.time - area.lastTicked);
    if (elapsed > 0) {
        area.advanceRitual(elapsed);
        for (const a of w.actors) {
            if (a.area !== area.id)
                continue;
            if ((0, folk_1.isFolk)(a)) {
                // Respect active jobs/tasks; settle schedule-driven residents if stale
                if (!a.task && (!a.job || a.job.status === "done")) {
                    if (elapsed > 20 || w.time - a.life.seen > 20) {
                        (0, folk_1.settle)(w, a);
                    }
                    a.life.seen = w.time;
                }
            }
        }
    }
    area.lastTicked = w.time;
    return elapsed;
}
