"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.walkOrder = exports.craftOrder = exports.gatherOrder = exports.JOB_HANDLERS = void 0;
exports.assignJob = assignJob;
exports.workerRefusal = workerRefusal;
exports.orderRefusal = orderRefusal;
exports.setWorkerOrder = setWorkerOrder;
exports.cancelJob = cancelJob;
exports.pauseJob = pauseJob;
exports.resumeJob = resumeJob;
exports.tickJob = tickJob;
// Orders outlive their short, area-bound tasks. All continuation state is
// plain data on Actor.job, including a receipt written at a task's fire point.
const jobs_1 = require("../content/jobs");
const actors_1 = require("../content/actors");
const harvest_1 = require("../content/harvest");
const items_1 = require("../content/items");
const crafting_1 = require("../content/crafting");
const runes_1 = require("../content/runes");
const props_1 = require("../content/props");
const world_1 = require("../world/world");
const areas_1 = require("../world/areas");
const tasks_1 = require("./tasks");
const inventory_1 = require("./inventory");
const actorStats_1 = require("./actorStats");
const navigation_1 = require("./navigation");
const routes_1 = require("./routes");
const portals_1 = require("./portals");
const crafting_2 = require("./crafting");
const storage_1 = require("./storage");
const inventoryOps_1 = require("./inventoryOps");
const harvesting_1 = require("./harvesting");
const text = (x) => typeof x === "string" && x.length > 0;
const positive = (x) => typeof x === "number" && Number.isSafeInteger(x) && x > 0;
const refOf = (x) => x && typeof x === "object" && !Array.isArray(x) && text(x.area) && text(x.prop) ? { area: x.area, prop: x.prop } : null;
const validRef = (x) => { const ref = refOf(x); return !!ref && !!areas_1.AREAS[ref.area]; };
const quantity = (j) => j.args.repeat === true ? Infinity : j.args.amount;
const stop = (a) => { a.vx = 0; a.vy = 0; a.moving = false; };
function assignJob(w, a, order) {
    const def = jobs_1.JOB_KINDS[order.kind], handler = exports.JOB_HANDLERS[order.kind];
    if (!def || !handler || !handler.validate(order.args) || !def.capabilities.every((c) => (0, actors_1.capable)(a, c)))
        return false;
    if (a.task && a.task.jobId === undefined)
        return false;
    cancelJob(w, a);
    a.job = {
        ...JSON.parse(JSON.stringify(order)), id: ++a.jobSeq, phase: def.phase, status: (0, actorStats_1.powered)(a) ? "running" : "paused",
        completed: 0, waiting: false, transit: false, result: null, target: null, nav: null, retryAt: 0, failures: 0,
        reason: (0, actorStats_1.powered)(a) ? null : "power",
    };
    (0, world_1.emit)(w, { t: "jobChanged", actor: a.id, status: a.job.status });
    return true;
}
/**
 * Why a walk-up command on `targetId` is refused before the order itself is
 * looked at (a message for the management screen), or null if the commander can
 * reach it: a worker, in the commander's area, within reach, in clear sight.
 */
function workerRefusal(w, commander, targetId) {
    const target = (0, world_1.actorById)(w, targetId);
    if (!target || !(0, actors_1.capable)(target, "worker"))
        return "THAT IS NOT A WORKER";
    if (target.area !== commander.area || Math.hypot(target.x - commander.x, target.y - commander.y) > (0, actors_1.actorDef)(target).body.reach + 8)
        return "STEP UP TO THE WORKER";
    if (!(0, navigation_1.lineOfSight)((0, world_1.areaOf)(w, commander), commander, target))
        return "NO CLEAR LINE TO THE WORKER";
    return null;
}
/** What is wrong with the arguments of an order, in words (the handler's `validate` only says yes or no). */
function argumentRefusal(order) {
    const p = order.args;
    if (order.kind === "gatherDeposit") {
        if (!text(p.resource) || !items_1.ITEMS[p.resource])
            return "NO SUCH RESOURCE";
        if (!text(p.fromArea) || !areas_1.AREAS[p.fromArea])
            return "NO SUCH SOURCE AREA";
        if (p.storage !== null && !validRef(p.storage))
            return "NO SUCH STORAGE";
    }
    else if (order.kind === "craftAt") {
        if (!validRef(p.station))
            return "NO SUCH STATION";
        if (!crafting_1.CRAFT_RECIPES.some((r) => r.id === p.recipe))
            return "NO SUCH RECIPE";
    }
    else if (order.kind === "walk")
        return "THERE IS NOWHERE TO GO";
    return p.repeat === true || positive(p.amount) ? "THAT ORDER IS NOT VALID" : "THE AMOUNT IS NOT VALID";
}
/**
 * Why `setWorkerOrder` would refuse `order` for this commander and worker, in
 * the screen's words, or null if it would be accepted. Mirrors setWorkerOrder
 * and assignJob check for check, so the two never disagree (tested).
 */
function orderRefusal(w, commander, targetId, order) {
    const why = workerRefusal(w, commander, targetId);
    if (why)
        return why;
    const target = (0, world_1.actorById)(w, targetId), def = jobs_1.JOB_KINDS[order.kind], handler = exports.JOB_HANDLERS[order.kind];
    if (!def || !handler)
        return "THAT KIND OF ORDER IS UNKNOWN";
    if (!handler.validate(order.args))
        return argumentRefusal(order);
    if (!def.capabilities.every((c) => (0, actors_1.capable)(target, c)))
        return "IT CANNOT DO THAT WORK";
    if (target.task && target.task.jobId === undefined)
        return "IT IS BUSY. TRY AGAIN IN A MOMENT";
    return null;
}
/** Walk-up management command (the management screen's only way to order a worker; see commands.ts: giveWorkerOrder). */
function setWorkerOrder(w, commander, targetId, order) {
    if (workerRefusal(w, commander, targetId))
        return false;
    const target = (0, world_1.actorById)(w, targetId);
    if (order)
        return assignJob(w, target, order);
    cancelJob(w, target);
    return true;
}
function cancelJob(w, a) {
    if (!a.job)
        return;
    if (a.task?.jobId === a.job.id)
        a.task = null;
    a.queue = a.queue.filter((t) => t.jobId !== a.job.id);
    a.job = null;
    stop(a);
    (0, world_1.emit)(w, { t: "jobChanged", actor: a.id, status: "idle" });
}
function pauseJob(w, a) {
    if (!a.job || a.job.status === "done")
        return;
    a.job.status = "paused";
    a.job.reason = "manual";
    stop(a);
    (0, world_1.emit)(w, { t: "jobChanged", actor: a.id, status: "paused" });
}
function resumeJob(w, a) {
    if (!a.job || a.job.status === "done")
        return;
    a.job.status = (0, actorStats_1.powered)(a) ? "running" : "paused";
    a.job.reason = (0, actorStats_1.powered)(a) ? null : "power";
    a.job.failures = 0;
    a.job.retryAt = 0;
    (0, world_1.emit)(w, { t: "jobChanged", actor: a.id, status: a.job.status });
}
function block(w, a, reason) {
    const job = a.job;
    job.status = "blocked";
    job.reason = reason;
    job.failures++;
    job.retryAt = w.time + Math.min(8, 1 + job.failures);
    job.nav = null;
    stop(a);
    (0, world_1.emit)(w, { t: "jobChanged", actor: a.id, status: "blocked", reason });
}
function finish(w, a) {
    a.job.status = "done";
    a.job.reason = null;
    a.job.nav = null;
    stop(a);
    (0, world_1.emit)(w, { t: "jobChanged", actor: a.id, status: "done" });
}
function work(a, spec, target) {
    (0, tasks_1.faceTo)(a, target.x, target.y);
    (0, tasks_1.beginTask)(a, spec, target);
    a.task.jobId = a.job.id;
    a.job.waiting = true;
    a.job.result = null;
    stop(a);
}
function wayIn(area, a, hop) {
    if (hop.via === "rune") {
        const p = area.prop(runes_1.RUNE_NODES[hop.from].prop);
        return p ? { hop, x: p.x, y: p.y, range: 15, rune: p.id } : null;
    }
    // A portal is walked into: a place inside its box where this body can stand (sim/portals.ts).
    const p = (0, portals_1.portalById)(area, hop.portal), at = p && (0, portals_1.portalStand)(p, (0, navigation_1.navGrid)(area, a).free);
    return at ? { hop, x: at.x, y: at.y, range: 1 } : null;
}
/**
 * Walk to a local target, or set out for another area: by rune (walk up, channel, travel) or on foot through a
 * portal (a road, a door, the dug-out stair), whichever ways the route offers (sim/routes.ts). A body keeps to the
 * way it has set out on (its saved walk goal); choosing afresh, it takes the nearest one it can walk to.
 */
function approach(w, a, goal, dt) {
    if (a.area !== goal.area) {
        const area = (0, world_1.areaOf)(w, a), hops = (0, routes_1.firstHops)(w, (0, routes_1.meansOf)(a), a.area, goal.area);
        if (!hops.length) {
            block(w, a, (0, actors_1.capable)(a, "travel") ? "noRoute" : "noTravel");
            return false;
        }
        const ways = hops.flatMap((h) => wayIn(area, a, h) ?? []);
        if (!ways.length) {
            block(w, a, hops[0].via === "rune" ? "missingRune" : "pathBlocked");
            return false;
        }
        const heading = a.job.nav?.goal;
        let way = ways.find((x) => `${a.area}:${x.x},${x.y}:${x.range}` === heading);
        if (!way) {
            const near = [...ways].sort((p, q) => Math.hypot(p.x - a.x, p.y - a.y) - Math.hypot(q.x - a.x, q.y - a.y));
            way = near.find((x) => (0, navigation_1.findPath)(w, a, x, false) !== null) ?? near[0];
        }
        const result = (0, navigation_1.walkTo)(w, a, { area: a.area, x: way.x, y: way.y, range: way.range }, dt);
        if (result === "stuck")
            block(w, a, "pathBlocked");
        if (result === "arrived") {
            if (way.hop.via === "rune" && way.rune) {
                (0, tasks_1.beginTask)(a, { kind: "channel", dur: 2.2, effect: { op: "travel", destination: way.hop.to } }, { kind: "rune", x: way.x, y: way.y, propId: way.rune });
                a.task.jobId = a.job.id;
                a.job.transit = true;
                a.job.result = null;
                stop(a);
            }
            else if (way.hop.via === "portal") {
                // Nothing is channelled: with its feet in the box it steps through, as the maintainer does by pushing on.
                const p = (0, portals_1.portalById)(area, way.hop.portal);
                if (!p || !(0, portals_1.inPortal)(p, a.x, a.y) || !(0, portals_1.walkThrough)(w, a, area, p))
                    block(w, a, "arrivalBlocked");
                else
                    stop(a);
            }
        }
        return false;
    }
    const result = (0, navigation_1.walkTo)(w, a, goal, dt);
    if (result === "stuck")
        block(w, a, "pathBlocked");
    return result === "arrived";
}
function gatherDeposit(w, a, j, dt) {
    // `storage` null: it keeps what it gathers in its own pack. There is no deposit phase then, and the harvest
    // effect counts what each blow paid (sim/tasks.ts), so `completed` is what it gathered, not what it stored.
    const item = j.args.resource, storage = refOf(j.args.storage);
    if (j.waiting) {
        const failed = j.result === false;
        j.waiting = false;
        j.result = null;
        if (failed && j.phase === "deposit") {
            block(w, a, "storageFull");
            return;
        }
        if (failed)
            j.target = null;
    }
    if (j.completed >= quantity(j)) {
        finish(w, a);
        return;
    }
    const stock = (0, inventory_1.countItem)(a, item), remaining = quantity(j) - j.completed;
    const resource = j.target && w.areas.get(j.target.area)?.prop(j.target.prop);
    if (storage && stock > 0 && (stock >= remaining || (0, inventory_1.roomFor)(w, a, item) === 0 || resource?.taken)) {
        j.phase = "deposit";
        j.target = null;
    }
    if (storage && j.phase === "deposit") {
        const area = (0, world_1.getArea)(w, storage.area), p = area.prop(storage.prop);
        if (!p?.inventory) {
            block(w, a, "missingStorage");
            return;
        }
        if (!stock) {
            j.phase = "gather";
            j.target = null;
            return;
        }
        if (!approach(w, a, { area: area.id, x: p.x, y: p.y, range: (0, props_1.propReach)(p.kind) + 2 }, dt))
            return;
        const h = (0, storage_1.inventoryHandle)(w, (0, storage_1.storageRef)(area.id, p.id));
        if (!h || !(0, inventoryOps_1.roomIn)(h.inventory, h.capacity, item)) {
            block(w, a, "storageFull");
            return;
        }
        work(a, { kind: "reach", dur: 0.45, effect: { op: "deposit", item, n: Math.min(stock, remaining) } }, { kind: "storage", propId: p.id, x: p.x, y: p.y });
        return;
    }
    const source = (0, world_1.getArea)(w, j.args.fromArea);
    if (a.area !== source.id) {
        approach(w, a, { area: source.id, ...source.start, range: 1 }, dt);
        return;
    }
    if (!(0, inventory_1.roomFor)(w, a, item)) {
        block(w, a, "packFull");
        return;
    }
    let p = j.target ? source.prop(j.target.prop) : undefined;
    if (!p || p.taken) {
        const candidates = source.props.filter((p) => !p.taken && (harvest_1.HARVEST[p.kind]?.perHit.item === item || harvest_1.HARVEST[p.kind]?.final?.item === item))
            .sort((p, q) => Math.hypot(p.x - a.x, p.y - a.y) - Math.hypot(q.x - a.x, q.y - a.y) || (p.id < q.id ? -1 : 1));
        p = candidates.find((p) => (0, navigation_1.findPath)(w, a, { x: p.x, y: p.y, range: (0, props_1.propReach)(p.kind) + 2 }, false) !== null);
        if (!p) {
            if (stock && storage) {
                j.phase = "deposit";
                return;
            }
            block(w, a, "noResource");
            return;
        }
        j.target = { area: source.id, prop: p.id };
    }
    if (!approach(w, a, { area: source.id, x: p.x, y: p.y, range: (0, props_1.propReach)(p.kind) + 2 }, dt))
        return;
    const hit = (0, harvesting_1.harvestStep)(a, p);
    if (!hit) {
        block(w, a, "cannotHarvest");
        return;
    }
    if (hit.rewards.some((r) => (0, inventory_1.roomFor)(w, a, r.item) < r.n)) {
        if (stock && storage) {
            j.phase = "deposit";
            j.target = null;
        }
        else
            block(w, a, "packFull");
        return;
    }
    work(a, { kind: "punch", dur: 0.75, effect: { op: "harvest" } }, { kind: "harvest", propId: p.id, x: p.x, y: p.y });
}
function craftAt(w, a, j, dt) {
    if (j.waiting) {
        const ok = j.result;
        j.waiting = false;
        j.result = null;
        if (ok)
            j.completed++;
        else {
            block(w, a, "craftChanged");
            return;
        }
    }
    if (j.completed >= quantity(j)) {
        finish(w, a);
        return;
    }
    const station = refOf(j.args.station), area = (0, world_1.getArea)(w, station.area), p = area.prop(station.prop);
    const recipe = crafting_1.CRAFT_RECIPES.find((r) => r.id === j.args.recipe);
    if (!p || !recipe || (0, props_1.propDef)(p.kind).station !== recipe.station) {
        block(w, a, "missingStation");
        return;
    }
    if (!approach(w, a, { area: area.id, x: p.x, y: p.y, range: (0, props_1.propReach)(p.kind) + 2 }, dt))
        return;
    const entry = (0, crafting_2.craftEntry)(w, a, recipe, p);
    if ((0, crafting_2.craftLocked)(w, a, recipe.station) || entry.status !== "ok") {
        block(w, a, entry.status === "ok" ? "unknown" : entry.status);
        return;
    }
    if (!(0, crafting_2.outputFits)(w, a, recipe)) {
        block(w, a, "packFull");
        return;
    }
    if (!(0, crafting_2.orderCraft)(w, a, recipe.station, recipe.id, p.id)) {
        block(w, a, "craftChanged");
        return;
    }
    a.task.jobId = j.id;
    j.waiting = true;
    j.result = null;
    stop(a);
}
exports.JOB_HANDLERS = {
    gatherDeposit: {
        validate: (p) => text(p.resource) && !!items_1.ITEMS[p.resource] && text(p.fromArea) && !!areas_1.AREAS[p.fromArea] && (p.storage === null || validRef(p.storage)) && (p.repeat === true || positive(p.amount)),
        step: gatherDeposit,
    },
    craftAt: {
        validate: (p) => validRef(p.station) && text(p.recipe) && crafting_1.CRAFT_RECIPES.some((r) => r.id === p.recipe) && (p.repeat === true || positive(p.amount)),
        step: craftAt,
    },
    walk: {
        validate: (p) => text(p.area) && !!areas_1.AREAS[p.area] && typeof p.x === "number" && Number.isFinite(p.x) && typeof p.y === "number" && Number.isFinite(p.y),
        step: (w, a, j, dt) => {
            if (approach(w, a, { area: j.args.area, x: j.args.x, y: j.args.y, range: 1 }, dt))
                finish(w, a);
        },
    },
};
function tickJob(w, a, dt) {
    const job = a.job;
    if (!job || job.status === "done") {
        if (!a.task)
            stop(a);
        return;
    }
    if (!(0, actorStats_1.powered)(a)) {
        if (job.reason !== "manual") {
            job.status = "paused";
            job.reason = "power";
        }
        stop(a);
        return;
    }
    if (job.status === "paused" && job.reason === "power") {
        job.status = "running";
        job.reason = null;
    }
    if (job.status === "paused")
        return;
    if (job.status === "blocked") {
        // Bounded retries. Impossible corridors and missing resources settle into
        // an explicit, savable blocked order, not an infinite active-work loop.
        if (job.failures >= 3 || w.time < job.retryAt)
            return;
        job.status = "running";
        job.reason = null;
        job.nav = null;
    }
    if (a.task || a.queue.length)
        return;
    if (job.transit) {
        job.transit = false;
        const ok = job.result;
        job.result = null;
        if (!ok) {
            block(w, a, "arrivalBlocked");
            return;
        }
    }
    const handler = exports.JOB_HANDLERS[job.kind];
    if (!handler) {
        block(w, a, "unknownJob");
        return;
    }
    handler.step(w, a, job, dt);
}
/** `storage` null: the worker keeps what it gathers in its own pack (the order screen's INVENTORY), and the amount counts what it gathered. */
const gatherOrder = (resource, fromArea, storage, amount, repeat = false) => ({
    kind: "gatherDeposit", args: { resource, fromArea, storage: storage ? { ...storage } : null, amount, repeat },
});
exports.gatherOrder = gatherOrder;
const craftOrder = (station, recipe, amount, repeat = false) => ({
    kind: "craftAt", args: { station: { ...station }, recipe, amount, repeat },
});
exports.craftOrder = craftOrder;
/** Stand at a spot: the order screen's "go to". The spot should be free (sim/orders.ts: walkOptions picks one). */
const walkOrder = (area, x, y) => ({ kind: "walk", args: { area, x, y } });
exports.walkOrder = walkOrder;
