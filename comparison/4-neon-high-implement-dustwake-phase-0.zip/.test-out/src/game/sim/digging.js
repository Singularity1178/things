"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.entranceOpen = void 0;
exports.digSpot = digSpot;
exports.digRules = digRules;
exports.applyDig = applyDig;
exports.openEntrance = openEntrance;
// Digging (content/digging.ts). One stroke of the right tool clears work from
// the layer a dig site has reached and pays what that layer is made of; when
// the column is through, the site opens and, if it is an entrance, so does the
// way between its two areas. Pure sim: any actor with the tool can dig.
//
// `digSpot` is the one place that knows a site is a prop. Everything after it
// works on a column and a depth, which is what a later "dig any tile" needs to
// return from the same function.
const digging_1 = require("../content/digging");
const geography_1 = require("../content/geography");
const tools_1 = require("../content/tools");
const tiles_1 = require("../content/tiles");
const actors_1 = require("../content/actors");
const world_1 = require("../world/world");
const inventory_1 = require("./inventory");
const tools_2 = require("./tools");
const collision_1 = require("./collision");
const messages_1 = require("./messages");
/** What can be dug at a prop and how far it has got. Null: not a dig site, or already through. */
function digSpot(area, propId) {
    const prop = propId ? area.prop(propId) : undefined, def = prop && digging_1.DIG_SITES[prop.kind];
    if (!prop || !def || prop.open)
        return null;
    const layer = (0, digging_1.digLayerAt)(def, prop.dmg);
    return layer ? { prop, def, layer } : null;
}
/** The RULES row for E on a dig site now: by the material of the layer reached. */
function digRules(area, propId) {
    const s = digSpot(area, propId);
    return s ? digging_1.DIG_MATERIALS[s.layer.material].rules : null;
}
/**
 * The `dig` effect: one stroke. Re-validates when it lands (the site, the
 * reach, the tool still fitted) and changes nothing if any of it fails. A
 * stroke never runs on into the next layer: that one needs its own tool.
 */
function applyDig(w, a, area, target) {
    const spot = digSpot(area, target?.propId);
    if (!spot || a.area !== area.id)
        return false;
    const { prop, def, layer } = spot, mat = digging_1.DIG_MATERIALS[layer.material];
    if (Math.hypot(prop.x - a.x, prop.y + def.dy - a.y) > def.reach + 12)
        return false;
    const power = (0, tools_2.toolBonus)(a, mat.tool);
    if (power <= 0) {
        (0, messages_1.actorMessage)(w, a, `THE ${mat.name} NEEDS A ${tools_1.TOOL_TYPES[mat.tool].full} HEAD ON YOUR ARM`);
        return false;
    }
    const work = Math.min(power, layer.left);
    // Pay per whole unit of the layer crossed, like harvesting: fractional strokes conserve the total.
    const units = Math.floor(layer.into + work + 1e-9) - Math.floor(layer.into + 1e-9);
    const done = Math.round((prop.dmg + work) * 1e9) / 1e9;
    const through = done >= (0, digging_1.digTotal)(def) - 1e-9;
    if (units > 0)
        (0, inventory_1.giveItem)(w, a, mat.yields, units);
    // (an opened site is also `lit`: whatever light its kind has wakes with it, like the stair head's ward glyph)
    area.setPropState(prop.id, through ? { dmg: done, open: true, lit: true } : { dmg: done });
    const after = through ? null : (0, digging_1.digLayerAt)(def, done);
    (0, world_1.emit)(w, {
        t: "dug", actor: a.id, prop: prop.id, x: prop.x, y: prop.y + def.dy, material: layer.material, n: units,
        next: after && after.index !== layer.index ? after.material : undefined, opened: through,
    });
    if (through) {
        // The site is a hole now (PropKindDef.openBox): nobody is left standing in it.
        area.touch("layout");
        evict(w, area, prop);
        if (def.opens)
            openEntrance(w, a, def.opens);
    }
    return true;
}
/** Set every body that stands in a prop's footprint down on the nearest free ground, its south lip first. */
function evict(w, area, p) {
    const b = p.box;
    if (!b)
        return;
    for (const o of w.actors) {
        if (o.area !== area.id)
            continue;
        const [bw, bh] = (0, actors_1.actorDef)(o).body.box;
        if (!(o.x + bw / 2 > b[0] && o.x - bw / 2 < b[2] && o.y > b[1] && o.y - bh < b[3]))
            continue;
        const spot = (0, collision_1.nearestFree)(area, o.x, b[3] + bh + 1, (0, collision_1.actorBoxes)(w, area.id, o.id), [bw, bh]);
        if (spot) {
            o.x = spot.x;
            o.y = spot.y;
            o.vx = 0;
            o.vy = 0;
        }
    }
}
const entranceOpen = (w, id) => !!geography_1.ENTRANCES[id] && (0, world_1.hasFlag)(w, geography_1.ENTRANCES[id].flag);
exports.entranceOpen = entranceOpen;
/**
 * Open an entrance (content/geography.ts: ENTRANCES), once: its flag is set, so
 * both portals pass; at its lower end the fall is gone: the choked tiles are
 * floor, the rock that stood on them is removed, and its light comes on.
 */
function openEntrance(w, by, id) {
    const e = geography_1.ENTRANCES[id];
    if (!e || (0, world_1.hasFlag)(w, e.flag))
        return false;
    (0, world_1.setFlag)(w, e.flag);
    const below = (0, world_1.getArea)(w, e.below.area), c = e.below.clear;
    for (let y = c.y; y < c.y + c.h; y++)
        for (let x = c.x; x < c.x + c.w; x++)
            if (below.tile(x, y) !== tiles_1.T.FLOOR)
                below.setTile(x, y, tiles_1.T.FLOOR);
    const x0 = c.x * tiles_1.TS - 8, x1 = (c.x + c.w) * tiles_1.TS + 8, y0 = c.y * tiles_1.TS - 4, y1 = (c.y + c.h) * tiles_1.TS + 8;
    for (const p of [...below.props])
        if (e.below.removes.includes(p.kind) && p.x >= x0 && p.x <= x1 && p.y > y0 && p.y <= y1)
            below.removeProp(p.id);
    for (const p of below.props)
        if (p.kind === e.below.lights && !p.lit)
            below.setPropState(p.id, { lit: true });
    (0, world_1.emit)(w, { t: "entranceOpened", actor: by.id, entrance: id });
    return true;
}
