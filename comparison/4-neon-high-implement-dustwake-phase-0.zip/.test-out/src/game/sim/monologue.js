"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hasThought = exports.playerThinks = exports.THOUGHT_CONDITIONS = void 0;
exports.thoughtSubject = thoughtSubject;
exports.thoughtBlocked = thoughtBlocked;
exports.think = think;
exports.reactToEvents = reactToEvents;
// Inner monologue (sim). Decides *when* the player golem thinks a line; the
// host only shows the `thought` events this emits. Deterministic, no DOM.
//
// Three ways in (content/monologue.ts describes the rows):
//   think(w, a, id)        a script or cutscene fires a line by id
//   {op: "think", line}    an Effect (interaction rules, schedule, dialogue beats)
//   reactToEvents(w)       event triggers (`on`): run at the end of stepPlayer /
//                          stepWorld and by the host just before it drains
//                          events, so events emitted by paused-world commands
//                          (reading a book, the pack) are seen too.
const monologue_1 = require("../content/monologue");
const actors_1 = require("../content/actors");
const world_1 = require("../world/world");
const requirements_1 = require("./requirements");
const power_1 = require("./power");
/**
 * The other actor a thought is about: the event's target/NPC, or the effect's
 * target actor (`coreSlotted` names the body as its `target`, `talkedTo` as
 * its `npc`). `powerChanged` is about the actor whose power changed.
 */
function thoughtSubject(c) {
    const e = c.event;
    const id = (e && (typeof e.target === "string" ? e.target : typeof e.npc === "string" ? e.npc : e.t === "powerChanged" ? e.actor : undefined))
        ?? c.target?.actorId;
    return typeof id === "string" ? (0, world_1.actorById)(c.w, id) : undefined;
}
/**
 * Named conditions for `ThoughtLine.if`. Adding one is a row here. The two
 * power rows drive the dormant-golem line (E on a worker with no core) and the
 * weak-core line (the guardian given the ruby core).
 */
exports.THOUGHT_CONDITIONS = {
    /** The thinker stands under the open sky. */
    underSky: (c) => !!c.w.areas.get(c.a.area)?.base.outdoor,
    /** The subject has a body that needs power and no core in it. */
    subjectNoPower: (c) => { const s = thoughtSubject(c); return !!s && !!(0, actors_1.actorDef)(s).power && !s.powerCore; },
    /** The subject holds a core of its family that is too weak for its body. */
    subjectWeakPower: (c) => {
        const s = thoughtSubject(c);
        if (!s?.powerCore)
            return false;
        const chk = (0, power_1.coreCheck)(s, s.powerCore);
        return chk.accepts && !chk.sufficient;
    },
};
/** Why a line can't be thought right now (undefined: it can). Exported for tests and debugging. */
function thoughtBlocked(w, a, id, ctx = {}) {
    const line = monologue_1.THOUGHTS[id];
    if (!line)
        return "unknown";
    if (a.id !== w.playerId)
        return "notThinker";
    if (line.once !== false && w.monologue.said.includes(id))
        return "said";
    if ((w.monologue.ready[id] ?? -Infinity) > w.time)
        return "cooldown";
    if (!(0, requirements_1.meets)(w, a, line.when))
        return "when";
    for (const name of line.if ?? []) {
        const cond = exports.THOUGHT_CONDITIONS[name];
        if (!cond)
            return `unknownCondition:${name}`;
        if (!cond({ w, a, ...ctx }))
            return `if:${name}`;
    }
    return undefined;
}
/**
 * The golem thinks line `id`, if it may: records it (one-shot lines, cooldowns)
 * and emits `thought`. Returns whether it fired. Only the player thinks.
 */
function think(w, a, id, ctx = {}) {
    if (thoughtBlocked(w, a, id, ctx))
        return false;
    const line = monologue_1.THOUGHTS[id];
    if (line.once !== false)
        w.monologue.said.push(id);
    if (line.cooldown)
        w.monologue.ready[id] = w.time + line.cooldown;
    (0, world_1.emit)(w, { t: "thought", actor: a.id, line: id });
    return true;
}
/** Fire a line from a script without holding an actor reference (cutscenes). */
const playerThinks = (w, id) => think(w, (0, world_1.player)(w), id);
exports.playerThinks = playerThinks;
/** Has the golem already thought this one-shot line? */
const hasThought = (w, id) => w.monologue.said.includes(id);
exports.hasThought = hasThought;
// Events already offered to the triggers. Transient (events are never saved) and
// keyed by object identity, so it needs no World field and works across worlds.
const seen = new WeakSet();
/** Does the event belong to the player (its own, or a world event with no actor)? */
const playersEvent = (w, e) => !("actor" in e) || typeof e.actor !== "string" || e.actor === w.playerId;
function matches(e, trigger) {
    if (e.t !== trigger.event)
        return false;
    const rec = e;
    for (const [k, v] of Object.entries(trigger.match ?? {}))
        if (rec[k] !== v)
            return false;
    return true;
}
/**
 * Offer every not-yet-seen pending event to the event triggers, in emission
 * order and then in THOUGHTS row order. Thoughts never trigger thoughts.
 */
function reactToEvents(w) {
    if (!w.events.length)
        return;
    const pl = (0, world_1.player)(w);
    if (!pl)
        return;
    for (let i = 0; i < w.events.length; i++) {
        const e = w.events[i];
        if (seen.has(e))
            continue;
        seen.add(e);
        if (e.t === "thought" || !playersEvent(w, e))
            continue;
        for (const [id, line] of Object.entries(monologue_1.THOUGHTS)) {
            if ((0, monologue_1.thoughtTriggers)(line).some((tr) => matches(e, tr)))
                think(w, pl, id, { event: e });
        }
    }
}
