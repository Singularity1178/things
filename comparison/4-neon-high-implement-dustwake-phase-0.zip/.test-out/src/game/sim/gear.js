"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.usableSlots = exports.slotUsable = exports.wears = exports.wornIn = void 0;
exports.lockedText = lockedText;
exports.slotsFor = slotsFor;
exports.targetSlot = targetSlot;
exports.reconcileGear = reconcileGear;
exports.activeGear = activeGear;
exports.speedMultiplier = speedMultiplier;
exports.golemGlow = golemGlow;
exports.runeMarks = runeMarks;
exports.capacityWith = capacityWith;
exports.wearCheck = wearCheck;
exports.takeOffCheck = takeOffCheck;
exports.applyWear = applyWear;
exports.applyTakeOff = applyTakeOff;
exports.ensureWorn = ensureWorn;
exports.gearRefusal = gearRefusal;
// Gear: items worn on the body in named slots (Actor.gear: back, helm, two
// arms, a core attachment and four rune slots; content/gear.ts). Gear belongs
// to the actor, like its pack, so any golem or NPC could wear things later. A
// worn item is not in the pack, and capacity tiers can require worn items
// (content/inventory.ts): putting the basket on grows the pack, taking it off
// shrinks it.
//
// Slots can be locked. A slot is usable when its unlock requirement is met (a
// world flag today: content/gear.ts), so opening one later is setting a flag.
// A locked slot takes nothing, and anything found in one (a flag cleared, an
// odd save) goes back to the pack (`reconcileGear`), never deleted.
//
// Taking gear off is refused unless everything still fits afterwards, counting
// how stacks merge and the item itself, which needs a slot back in the pack. A
// refusal changes nothing, and nothing is ever dropped or lost by it.
//
// Effects (runes): `speedMultiplier` and `golemGlow` read only what is worn in
// usable slots, from the item rows (ItemDef.worn), so an effect lasts exactly
// as long as the item is equipped. Pure sim (no DOM). The pack screen goes
// through sim/commands.ts (wearFromSlot / takeOffGear); any actor can run the
// same "wear" / "takeOff" effects as tasks (sim/tasks.ts).
const items_1 = require("../content/items");
const gear_1 = require("../content/gear");
const world_1 = require("../world/world");
const inventory_1 = require("./inventory");
const requirements_1 = require("./requirements");
const actors_1 = require("../content/actors");
/** What `a` wears in `slot` (undefined: the slot is empty). */
const wornIn = (a, slot) => a.gear[slot];
exports.wornIn = wornIn;
/** Is `a` wearing `id`, in any slot? */
const wears = (a, id) => Object.values(a.gear).includes(id);
exports.wears = wears;
// ---------------------------------------------------------------- slots
/** Can `a` use `slot` right now? A slot with no unlock requirement always can. */
const slotUsable = (w, a, slot) => (0, actors_1.actorDef)(a).gearSlots.includes(slot) && (0, requirements_1.meets)(w, a, (0, actors_1.actorDef)(a).gearUnlocks?.[slot]);
exports.slotUsable = slotUsable;
const usableSlots = (w, a) => gear_1.GEAR_SLOT_DEFS.filter((d) => (0, exports.slotUsable)(w, a, d.id)).map((d) => d.id);
exports.usableSlots = usableSlots;
/** The lines that say why a locked slot is locked (the first `locked` entry whose condition holds). */
function lockedText(w, a, def) {
    if (!(0, actors_1.actorDef)(a).gearSlots.includes(def.id))
        return ["THIS BODY HAS NO SUCH SLOT."];
    const row = def.locked?.find((l) => (0, requirements_1.meets)(w, a, l.when));
    return row ? row.text : ["LOCKED."];
}
/** Every slot of the item's kind that it may go in and `a` can use, in fill order. */
function slotsFor(w, a, item) {
    const g = items_1.ITEMS[item].wear;
    if (!g)
        return [];
    return (0, gear_1.slotsOfKind)(g.kind).filter((s) => (!g.slot || g.slot === s) && (0, exports.slotUsable)(w, a, s));
}
/** Where `item` would go now: the first empty usable slot of its kind, else the first usable one (swapping what is there). */
function targetSlot(w, a, item) {
    const c = slotsFor(w, a, item);
    return c.find((s) => !a.gear[s]) ?? c[0];
}
/**
 * Anything worn in a slot that is not usable (its flag was cleared, a save from
 * somewhere odd) goes back into the pack. If the pack can't hold it the
 * overflow lands on the ground, like any pickup: nothing is deleted.
 */
function reconcileGear(w, a) {
    for (const d of gear_1.GEAR_SLOT_DEFS) {
        const item = a.gear[d.id];
        if (!item || (0, exports.slotUsable)(w, a, d.id))
            continue;
        delete a.gear[d.id];
        (0, inventory_1.reconcileCapacity)(w, a);
        (0, inventory_1.giveItem)(w, a, item, 1);
        (0, world_1.emit)(w, { t: "gearOff", actor: a.id, item, slot: d.id });
    }
}
// ---------------------------------------------------------------- effects
/** Items worn in usable slots: the ones whose effects count. */
function activeGear(w, a) {
    return gear_1.GEAR_SLOT_DEFS.flatMap((d) => (a.gear[d.id] && (0, exports.slotUsable)(w, a, d.id) ? [a.gear[d.id]] : []));
}
/** Movement speed multiplier from worn gear: 1 + the sum of the worn speed bonuses (1.5 = +150% = 2.5x). */
function speedMultiplier(w, a) {
    return 1 + activeGear(w, a).reduce((s, id) => s + (items_1.ITEMS[id].worn?.speed ?? 0), 0);
}
/** The golem's light now: its standard glow, or the widest light a worn item gives. */
function golemGlow(w, a) {
    let best = gear_1.GOLEM_LIGHT;
    for (const id of activeGear(w, a)) {
        const l = items_1.ITEMS[id].worn?.light;
        if (l && l.rad > best.rad)
            best = l;
    }
    return best;
}
/** The sigils glowing on the body, one entry per rune slot (colour and pattern, or null when empty or locked): what golem.ts draws. */
function runeMarks(w, a) {
    return gear_1.RUNE_SLOTS.map((s) => {
        const id = a.gear[s];
        return id && (0, exports.slotUsable)(w, a, s) ? items_1.ITEMS[id].worn?.mark ?? null : null;
    });
}
// ---------------------------------------------------------------- wear / take off
/** The capacity `a` would have wearing `gear` instead of what it wears now. */
function capacityWith(w, a, gear) {
    return (0, inventory_1.capacity)(w, { ...a, gear });
}
/** The pack as stacks, optionally with one unit taken out of pack slot `minus`. */
function packStacks(a, minus = -1) {
    return a.inventory.flatMap((s, i) => {
        if (!s)
            return [];
        const n = i === minus ? s.n - 1 : s.n;
        return n > 0 ? [{ item: s.item, n }] : [];
    });
}
/**
 * Can `a` put on the item in pack slot `slot`? It goes in `into` if given (a
 * usable slot of its kind), else in the first empty usable slot of its kind
 * (else it swaps with the first). Whatever it wears there swaps into the pack
 * slot being freed, so a swap needs no extra room, unless the new gear grants
 * fewer slots: then everything must still fit. No usable slot of its kind
 * (all locked) refuses: `noSlot`.
 */
function wearCheck(w, a, slot, into) {
    const s = a.inventory[slot];
    if (!s)
        return { ok: false, reason: "empty" };
    if (!items_1.ITEMS[s.item].wear)
        return { ok: false, reason: "notWearable", item: s.item };
    const cands = slotsFor(w, a, s.item);
    const target = into ? cands.find((c) => c === into) : targetSlot(w, a, s.item);
    if (!target)
        return { ok: false, reason: "noSlot", item: s.item };
    const prev = a.gear[target];
    if (prev) {
        const need = (0, inventory_1.slotsNeeded)([...packStacks(a, slot), { item: prev, n: 1 }]);
        const cap = capacityWith(w, a, { ...a.gear, [target]: s.item });
        if (need > cap)
            return { ok: false, reason: "noRoom", item: prev, over: need - cap, shrinks: cap < (0, inventory_1.capacity)(w, a) };
    }
    return { ok: true, item: s.item, slot: target };
}
/**
 * Can `a` take off what it wears in `slot`? Only if, at the capacity it would
 * have afterwards, the pack holds everything it holds now plus the item itself.
 */
function takeOffCheck(w, a, slot) {
    const item = a.gear[slot];
    if (!item)
        return { ok: false, reason: "empty" };
    const after = { ...a.gear };
    delete after[slot];
    const need = (0, inventory_1.slotsNeeded)([...packStacks(a), { item, n: 1 }]);
    const cap = capacityWith(w, a, after);
    if (need > cap)
        return { ok: false, reason: "noRoom", item, over: need - cap, shrinks: cap < (0, inventory_1.capacity)(w, a) };
    return { ok: true, item, slot };
}
/** Put on the item in pack slot `slot`. Re-validates; a refusal changes nothing. */
function applyWear(w, a, slot, into) {
    const chk = wearCheck(w, a, slot, into);
    if (!chk.ok)
        return chk;
    const s = a.inventory[slot];
    s.n -= 1;
    if (s.n === 0)
        a.inventory[slot] = null;
    const prev = a.gear[chk.slot];
    a.gear[chk.slot] = chk.item;
    const extra = [];
    if (prev) {
        if (!a.inventory[slot])
            a.inventory[slot] = { item: prev, n: 1 };
        else
            extra.push({ item: prev, n: 1 });
    }
    // Fit the pack to the new capacity: it grows (empty slots appended, nothing
    // moves); a swap to gear granting less was checked to fit above.
    if (!(0, inventory_1.repackInto)(a, (0, inventory_1.capacity)(w, a), extra)) {
        (0, inventory_1.reconcileCapacity)(w, a);
        for (const x of extra)
            (0, inventory_1.giveItem)(w, a, x.item, x.n);
    }
    if (prev)
        (0, world_1.emit)(w, { t: "gearOff", actor: a.id, item: prev, slot: chk.slot });
    (0, world_1.emit)(w, { t: "gearOn", actor: a.id, item: chk.item, slot: chk.slot });
    return chk;
}
/** Take off what `a` wears in `slot`, into the pack. Re-validates; a refusal changes nothing. */
function applyTakeOff(w, a, slot) {
    const chk = takeOffCheck(w, a, slot);
    if (!chk.ok)
        return chk;
    delete a.gear[slot];
    if (!(0, inventory_1.repackInto)(a, (0, inventory_1.capacity)(w, a), [{ item: chk.item, n: 1 }])) {
        // Unreachable (the check guarantees the fit), but never drop or lose anything.
        a.gear[slot] = chk.item;
        return { ok: false, reason: "noRoom", item: chk.item, over: 1 };
    }
    (0, world_1.emit)(w, { t: "gearOff", actor: a.id, item: chk.item, slot });
    return chk;
}
/**
 * Make sure `a` wears `item` (debug kits): put on the one in its pack if it
 * has one, else a new one straight onto the body. False if `item` isn't gear
 * or every slot it fits already holds something else.
 */
function ensureWorn(w, a, item) {
    if ((0, exports.wears)(a, item))
        return true;
    const s = targetSlot(w, a, item);
    if (!s || a.gear[s])
        return false;
    const i = a.inventory.findIndex((x) => x?.item === item);
    if (i >= 0)
        return applyWear(w, a, i, s).ok;
    a.gear[s] = item;
    (0, inventory_1.reconcileCapacity)(w, a);
    return true;
}
/** What to tell the player when gear can't be put on or taken off. */
function gearRefusal(chk) {
    if (chk.ok)
        return "";
    if (chk.reason === "notWearable")
        return "THAT CAN'T BE WORN";
    if (chk.reason === "empty")
        return "NOTHING TO TAKE OFF";
    if (chk.reason === "noSlot")
        return "NO FREE SLOT FOR THAT YET";
    const k = chk.over ?? 1;
    if (chk.shrinks)
        return `TOO MUCH TO CARRY WITHOUT THE ${items_1.ITEM_NAMES[chk.item]} - FREE ${k} SLOT${k === 1 ? "" : "S"}`;
    return `NO ROOM IN THE PACK FOR THE ${items_1.ITEM_NAMES[chk.item]} - FREE ${k} SLOT${k === 1 ? "" : "S"}`;
}
