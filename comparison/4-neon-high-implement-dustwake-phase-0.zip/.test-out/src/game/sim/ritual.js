"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkRune = checkRune;
exports.deactivate = deactivate;
exports.placeGlyph = placeGlyph;
// Translocation-circle puzzle rules (tutorial).
const items_1 = require("../content/items");
const ritual_1 = require("../content/ritual");
const runes_1 = require("../content/runes");
const world_1 = require("../world/world");
const tasks_1 = require("./tasks");
const inventory_1 = require("./inventory");
function checkRune(w, area) {
    const r = area.ritual;
    if (!r)
        return;
    if (r.sockets.some((s) => s < 0) || !r.core || !r.carved)
        return;
    const ok = r.sockets.every((s, i) => s === r.solution[i]);
    if (ok) {
        area.updateRitual({ active: true, actT: 0, wrong: r.wrong.map(() => false) });
        // The circle is this area's node in the rune network: lighting it activates the node.
        (0, world_1.setFlag)(w, runes_1.RUNE_NODES.dungeon.flag);
        (0, world_1.emit)(w, { t: "runeActivated" });
    }
    else {
        area.updateRitual({ wrong: r.sockets.map((s, i) => s !== r.solution[i]) });
        (0, world_1.emit)(w, { t: "runeFizzled" });
    }
}
function deactivate(w, area) {
    const r = area.ritual;
    if (!r)
        return;
    area.updateRitual({ active: false, actT: 0 });
    (0, world_1.clearFlag)(w, runes_1.RUNE_NODES.dungeon.flag);
    (0, world_1.emit)(w, { t: "runeDeactivated" });
}
/** Command from the glyph picker: seat a glyph immediately, then a short reach checks the circle. */
function placeGlyph(w, actor, area, socket, glyph) {
    const r = area.ritual;
    if (!r)
        return;
    const id = (0, items_1.glyphItem)(glyph);
    if (items_1.ITEMS[id].glyph === undefined)
        return;
    if (!(0, inventory_1.removeItems)(actor, id, 1))
        return;
    const sockets = [...r.sockets], wrong = [...r.wrong];
    sockets[socket] = glyph;
    wrong[socket] = false;
    area.updateRitual({ sockets, wrong });
    (0, world_1.emit)(w, { t: "glyphPlaced", socket });
    const s = (0, ritual_1.socketPositions)(area.ritualPos)[socket];
    (0, tasks_1.faceTo)(actor, s.x, s.y);
    (0, tasks_1.beginTask)(actor, { kind: "reach", dur: 0.45, effect: { op: "checkRune" } });
}
