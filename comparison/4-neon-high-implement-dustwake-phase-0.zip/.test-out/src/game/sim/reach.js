"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cellFeet = void 0;
exports.freeAt = freeAt;
exports.reachable = reachable;
exports.nearReached = nearReached;
// Walkable reachability over an area at tile granularity, using the same rule
// as locomotion (sim/collision.ts boxFree): a golem-sized 10x5 box must be
// free of solid tiles and blocking prop boxes. A cell is standable if the golem
// fits with its feet at the tile's centre; two neighbouring cells connect if
// the box stays free at every 4px along the straight step between them.
// Pure and deterministic; used by the surface builder (to open sealed pockets)
// and by the tests (to prove everything meaningful can be walked to).
const tiles_1 = require("../content/tiles");
/** Feet position used for a cell. */
const cellFeet = (tx, ty) => ({ x: tx * tiles_1.TS + 8, y: ty * tiles_1.TS + 11 });
exports.cellFeet = cellFeet;
/** Is the golem box (feet at x, y) free? Same test as sim/collision.ts boxFree. */
function freeAt(g, boxes, x, y, size = [10, 5]) {
    const x0 = x - size[0] / 2, x1 = x + size[0] / 2, y0 = y - size[1], y1 = y;
    for (let ty = Math.floor(y0 / tiles_1.TS); ty <= Math.floor((y1 - 0.01) / tiles_1.TS); ty++)
        for (let tx = Math.floor(x0 / tiles_1.TS); tx <= Math.floor((x1 - 0.01) / tiles_1.TS); tx++) {
            if (tx < 0 || ty < 0 || tx >= g.w || ty >= g.h)
                return false;
            if ((0, tiles_1.isSolidT)(g.grid[ty * g.w + tx]))
                return false;
        }
    for (const b of boxes)
        if (x1 > b[0] && x0 < b[2] && y1 > b[1] && y0 < b[3])
            return false;
    return true;
}
/** Bucket boxes by tile so the flood fill stays cheap on big areas. */
function bucketBoxes(g, boxes) {
    const buckets = new Map();
    for (const b of boxes) {
        for (let ty = Math.floor(b[1] / tiles_1.TS) - 1; ty <= Math.floor(b[3] / tiles_1.TS) + 1; ty++)
            for (let tx = Math.floor(b[0] / tiles_1.TS) - 1; tx <= Math.floor(b[2] / tiles_1.TS) + 1; tx++) {
                if (tx < 0 || ty < 0 || tx >= g.w || ty >= g.h)
                    continue;
                const k = ty * g.w + tx;
                let l = buckets.get(k);
                if (!l)
                    buckets.set(k, (l = []));
                l.push(b);
            }
    }
    return (x, y) => buckets.get(Math.floor(y / tiles_1.TS) * g.w + Math.floor(x / tiles_1.TS)) ?? [];
}
/**
 * Flood fill from the cell containing `start` (px). Returns a per-tile array:
 * 1 = reachable standing cell, 0 = not.
 */
function reachable(g, boxes, start) {
    const near = bucketBoxes(g, boxes);
    const ok = (x, y) => freeAt(g, near(x, y), x, y);
    const stand = new Int8Array(g.w * g.h).fill(-1);
    const canStand = (tx, ty) => {
        const k = ty * g.w + tx;
        if (stand[k] < 0) {
            const f = (0, exports.cellFeet)(tx, ty);
            stand[k] = ok(f.x, f.y) ? 1 : 0;
        }
        return stand[k] === 1;
    };
    const out = new Uint8Array(g.w * g.h);
    const sx = Math.floor(start.x / tiles_1.TS), sy = Math.floor((start.y - 3) / tiles_1.TS);
    if (sx < 0 || sy < 0 || sx >= g.w || sy >= g.h || !canStand(sx, sy))
        return out;
    const q = [sy * g.w + sx];
    out[q[0]] = 1;
    while (q.length) {
        const k = q.pop(), tx = k % g.w, ty = (k / g.w) | 0;
        const a = (0, exports.cellFeet)(tx, ty);
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
            const nx = tx + dx, ny = ty + dy;
            if (nx < 0 || ny < 0 || nx >= g.w || ny >= g.h)
                continue;
            const nk = ny * g.w + nx;
            if (out[nk] || !canStand(nx, ny))
                continue;
            let clear = true;
            for (let s = 4; s < tiles_1.TS; s += 4)
                if (!ok(a.x + dx * s, a.y + dy * s)) {
                    clear = false;
                    break;
                }
            if (!clear)
                continue;
            out[nk] = 1;
            q.push(nk);
        }
    }
    return out;
}
/** Is the point (px) within one tile of a reachable cell (i.e. something there can be walked up to)? */
function nearReached(g, reached, x, y, rTiles = 1) {
    const tx = Math.floor(x / tiles_1.TS), ty = Math.floor(y / tiles_1.TS);
    for (let j = -rTiles; j <= rTiles; j++)
        for (let i = -rTiles; i <= rTiles; i++) {
            const nx = tx + i, ny = ty + j;
            if (nx >= 0 && ny >= 0 && nx < g.w && ny < g.h && reached[ny * g.w + nx])
                return true;
        }
    return false;
}
