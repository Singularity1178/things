"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.heldItems = exports.hasItem = exports.countItem = exports.copySlots = void 0;
exports.roomIn = roomIn;
exports.insertItems = insertItems;
exports.removeItems = removeItems;
// Stack operations know neither actors nor props. Callers work on a copy and
// commit through its owner (Area.setInventory for a prop).
const items_1 = require("../content/items");
const copySlots = (slots) => slots.map((s) => s ? { ...s } : null);
exports.copySlots = copySlots;
const countItem = (a, id) => a.inventory.reduce((n, s) => n + (s?.item === id ? s.n : 0), 0);
exports.countItem = countItem;
const hasItem = (a, id) => (0, exports.countItem)(a, id) > 0;
exports.hasItem = hasItem;
const heldItems = (a) => a.inventory.flatMap((s) => s ? [s.item] : []);
exports.heldItems = heldItems;
function roomIn(slots, cap, item) {
    let room = 0;
    for (let i = 0; i < cap; i++) {
        const s = slots[i];
        if (!s)
            room += (0, items_1.maxStack)(item);
        else if (s.item === item)
            room += Math.max(0, (0, items_1.maxStack)(item) - s.n);
    }
    return room;
}
/** Returns the number that did not fit. Never overfills a slot. */
function insertItems(slots, cap, item, n) {
    if (!Number.isSafeInteger(n) || n < 0)
        throw new Error("invalid item count");
    while (slots.length < cap)
        slots.push(null);
    for (let i = 0; i < cap && n > 0; i++) {
        const s = slots[i];
        if (!s || s.item !== item)
            continue;
        const k = Math.min(n, Math.max(0, (0, items_1.maxStack)(item) - s.n));
        s.n += k;
        n -= k;
    }
    for (let i = 0; i < cap && n > 0; i++) {
        if (slots[i])
            continue;
        const k = Math.min(n, (0, items_1.maxStack)(item));
        slots[i] = { item, n: k };
        n -= k;
    }
    return n;
}
/** All-or-nothing, last matching slots first. */
function removeItems(a, item, n = 1) {
    if (!Number.isSafeInteger(n) || n < 0 || (0, exports.countItem)(a, item) < n)
        return false;
    for (let i = a.inventory.length - 1; i >= 0 && n > 0; i--) {
        const s = a.inventory[i];
        if (!s || s.item !== item)
            continue;
        const k = Math.min(n, s.n);
        s.n -= k;
        n -= k;
        if (!s.n)
            a.inventory[i] = null;
    }
    return true;
}
