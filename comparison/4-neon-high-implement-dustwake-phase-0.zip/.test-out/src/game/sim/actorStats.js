"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.actorLabel = exports.cleanActorName = exports.ACTOR_NAME_MAX = exports.harvestPower = void 0;
exports.powered = powered;
exports.powerEffects = powerEffects;
exports.actorSpeed = actorSpeed;
const actors_1 = require("../content/actors");
const power_1 = require("../content/power");
const requirements_1 = require("./requirements");
const gear_1 = require("./gear");
function powered(a) {
    const req = (0, actors_1.actorDef)(a).power;
    if (!req)
        return true;
    const core = a.powerCore && power_1.POWER_CORES[a.powerCore];
    return !!core && core.family === req.family && core.tier >= req.tier;
}
function powerEffects(a) {
    return powered(a) && a.powerCore ? power_1.POWER_CORES[a.powerCore]?.effects : undefined;
}
function actorSpeed(w, a) {
    const d = (0, actors_1.actorDef)(a);
    let speed = d.speed;
    for (const t of d.speedTiers ?? [])
        if ((0, requirements_1.meets)(w, a, t.requires))
            speed = Math.max(speed, t.speed);
    return powered(a) ? speed * (0, gear_1.speedMultiplier)(w, a) * Math.max(0, 1 + (powerEffects(a)?.speed ?? 0)) : 0;
}
const harvestPower = (a) => powered(a) ? Math.max(0, (0, actors_1.actorDef)(a).harvestPower * (1 + (powerEffects(a)?.harvest ?? 0))) : 0;
exports.harvestPower = harvestPower;
/** The longest name an orderable body may be given. */
exports.ACTOR_NAME_MAX = 14;
/** What a typed name becomes: upper case, one space between words, trimmed, no longer than ACTOR_NAME_MAX. Empty: no name of its own. */
const cleanActorName = (s) => s.toUpperCase().replace(/\s+/g, " ").trim().slice(0, exports.ACTOR_NAME_MAX).trim();
exports.cleanActorName = cleanActorName;
/** What a body is called: its own name in front of its kind ("BOB - WORKER GOLEM"), or just the kind. */
const actorLabel = (a) => (a.name ? `${a.name} - ${(0, actors_1.actorDef)(a).name}` : (0, actors_1.actorDef)(a).name);
exports.actorLabel = actorLabel;
