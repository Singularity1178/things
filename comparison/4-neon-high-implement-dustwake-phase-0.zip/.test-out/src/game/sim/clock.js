"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SimClock = exports.InterpBuffer = exports.GAME_SPEEDS = exports.SIM_DT = exports.SIM_HZ = void 0;
/** Fixed simulation rate (Hz) and tick duration (seconds). */
exports.SIM_HZ = 60;
exports.SIM_DT = 1 / exports.SIM_HZ;
exports.GAME_SPEEDS = [0, 1, 2, 4, 8];
/** Small epsilon so exact 1/60 frames never suffer IEEE-754 underflow. */
const EPS = 1e-9;
/** Maximum ticks per animation frame to prevent spiral-of-death on tab resume. */
const MAX_TICKS_PER_FRAME = 24;
/**
 * Snapshot of actor positions before the latest simulation tick so the renderer
 * can smoothly interpolate between ticks without mutating simulation state.
 */
class InterpBuffer {
    constructor() {
        Object.defineProperty(this, "prev", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
    }
    capture(world) {
        this.prev.clear();
        for (const a of world.actors) {
            this.prev.set(a.id, { x: a.x, y: a.y, area: a.area });
        }
    }
    clear() {
        this.prev.clear();
    }
    /** Interpolated world position for rendering `actor` at fraction `alpha` in [0, 1]. */
    position(a, alpha) {
        const p = this.prev.get(a.id);
        if (!p || p.area !== a.area)
            return { x: a.x, y: a.y };
        // Snap across teleports / portals / large jumps (> 32 px in a single tick)
        const dx = a.x - p.x, dy = a.y - p.y;
        if (dx * dx + dy * dy > 32 * 32)
            return { x: a.x, y: a.y };
        const k = alpha < 0 ? 0 : alpha > 1 ? 1 : alpha;
        return { x: p.x + dx * k, y: p.y + dy * k };
    }
}
exports.InterpBuffer = InterpBuffer;
/**
 * Accumulator-based fixed-timestep clock.
 * - `speed === 0` pauses simulation (accumulator does not advance).
 * - `speed === 8` runs 8x as many fixed `tickDt` steps over the same real time.
 */
class SimClock {
    constructor(tickDt = exports.SIM_DT) {
        Object.defineProperty(this, "tickDt", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "speed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        Object.defineProperty(this, "accumulator", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "tick", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "alpha", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        Object.defineProperty(this, "lastNonZeroSpeed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        this.tickDt = tickDt;
    }
    get paused() {
        return this.speed === 0;
    }
    setSpeed(s) {
        if (s !== 0)
            this.lastNonZeroSpeed = s;
        this.speed = s;
    }
    togglePause() {
        this.speed = this.speed === 0 ? this.lastNonZeroSpeed : 0;
        return this.speed;
    }
    stepSpeed(dir) {
        const idx = exports.GAME_SPEEDS.indexOf(this.speed);
        const next = exports.GAME_SPEEDS[Math.max(0, Math.min(exports.GAME_SPEEDS.length - 1, idx + dir))];
        this.setSpeed(next);
        return this.speed;
    }
    reset() {
        this.accumulator = 0;
        this.tick = 0;
        this.alpha = 1;
    }
    /**
     * Advance the clock by `frameDt` real seconds, invoking `onTick(tickDt, tickIndex)`
     * for each fixed simulation tick. Returns how many ticks ran and the render alpha.
     */
    advance(frameDt, onTick, onBeforeLastTick) {
        if (this.speed === 0 || frameDt <= 0) {
            return { ticks: 0, alpha: this.alpha };
        }
        // Clamp absurd frame spikes, then scale by game speed
        const clamped = Math.min(frameDt, 0.1);
        this.accumulator += clamped * this.speed;
        let pending = Math.floor((this.accumulator + EPS) / this.tickDt);
        if (pending > MAX_TICKS_PER_FRAME) {
            pending = MAX_TICKS_PER_FRAME;
            this.accumulator = pending * this.tickDt;
        }
        let ticks = 0;
        for (let i = 0; i < pending; i++) {
            if (i === pending - 1 && onBeforeLastTick)
                onBeforeLastTick();
            onTick(this.tickDt, this.tick);
            this.tick++;
            this.accumulator = Math.max(0, this.accumulator - this.tickDt);
            ticks++;
        }
        this.alpha = Math.min(1, Math.max(0, this.accumulator / this.tickDt));
        // When accumulator drains cleanly (e.g. exact 1/60 stepping), show the exact latest tick.
        if (this.accumulator < EPS)
            this.alpha = 1;
        return { ticks, alpha: this.alpha };
    }
}
exports.SimClock = SimClock;
