"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isAwake = void 0;
exports.npcActor = npcActor;
exports.scriptIdOf = scriptIdOf;
exports.scriptOf = scriptOf;
exports.currentSegment = currentSegment;
exports.segmentPages = segmentPages;
exports.applyDialogueEffect = applyDialogueEffect;
exports.talkTo = talkTo;
exports.dialogueBeat = dialogueBeat;
exports.finishSegment = finishSegment;
exports.playSegment = playSegment;
// Dialogue engine (sim side, no DOM). Scripts are data (content/dialogue.ts),
// keyed by the script id an NpcDef names. Nothing here knows any particular
// NPC: which segment plays is "the first segment whose requirement is met and
// whose completion flag is unset", so progress is derived from flags and a
// later chapter is a new data row.
//
// The presentation layer (the dialogue screen) only displays pages and calls
// the commands below at the right moments; every state change goes through
// Effects applied here, so tests drive whole encounters headlessly.
const dialogue_1 = require("../content/dialogue");
const npcs_1 = require("../content/npcs");
const flags_1 = require("../content/flags");
const world_1 = require("../world/world");
const requirements_1 = require("./requirements");
const inventory_1 = require("./inventory");
const tasks_1 = require("./tasks");
/** An NPC's reversible awake state (flag npc.<id>.awake; absent = dormant). */
const isAwake = (w, npcActorId) => (0, world_1.hasFlag)(w, (0, flags_1.npcFlag)(npcActorId, flags_1.NPC_AWAKE));
exports.isAwake = isAwake;
/** The NPC actor with this id, if it is one. */
function npcActor(w, npcActorId) {
    const a = (0, world_1.actorById)(w, npcActorId);
    return a && a.kind === "npc" && (0, npcs_1.npcDef)(a.npc) ? a : undefined;
}
/** Script id of an NPC actor (from its NpcDef). */
function scriptIdOf(w, npcActorId) {
    const a = npcActor(w, npcActorId);
    return a ? (0, npcs_1.npcDef)(a.npc).dialogue : undefined;
}
function scriptOf(w, npcActorId) {
    const id = scriptIdOf(w, npcActorId);
    return id ? dialogue_1.DIALOGUE[id] : undefined;
}
/** The segment talking would play now: the first available, uncompleted one. */
function currentSegment(w, listener, script) {
    return script.segments.find((s) => !(0, world_1.hasFlag)(w, s.done) && (0, requirements_1.meets)(w, listener, s.when)) ?? null;
}
/** A segment's pages as they would be shown now (optional pages filtered by their requirement). */
function segmentPages(w, listener, seg) {
    return seg.pages.filter((p) => (0, requirements_1.meets)(w, listener, p.when));
}
const npcTarget = (a) => ({ kind: "npc", x: a.x, y: a.y, actorId: a.id, npc: a.npc });
/** Apply a dialogue/NPC effect (called from applyEffect). All of these are idempotent. */
function applyDialogueEffect(w, a, e, target) {
    switch (e.op) {
        case "talk": {
            const npc = target?.actorId ? npcActor(w, target.actorId) : undefined;
            if (!npc || npc.area !== a.area)
                break;
            const scriptId = (0, npcs_1.npcDef)(npc.npc).dialogue;
            const script = dialogue_1.DIALOGUE[scriptId];
            if (!script)
                break;
            const seg = currentSegment(w, a, script);
            // Every talk, whatever it shows: a segment's `dialogue` follows, or the idle line once the story is done.
            (0, world_1.emit)(w, { t: "talkedTo", actor: a.id, npc: npc.id });
            if (seg)
                (0, world_1.emit)(w, { t: "dialogue", actor: a.id, npc: npc.id, script: scriptId, segment: seg.id });
            else
                (0, world_1.emit)(w, { t: "message", text: script.idle });
            break;
        }
        case "npcAwake": {
            const f = (0, flags_1.npcFlag)(e.npc, flags_1.NPC_AWAKE);
            if ((0, world_1.hasFlag)(w, f) === e.awake)
                break;
            if (e.awake)
                (0, world_1.setFlag)(w, f);
            else
                (0, world_1.clearFlag)(w, f);
            (0, world_1.emit)(w, { t: "npcState", npc: e.npc, awake: e.awake });
            break;
        }
        case "repairEye":
            if ((0, world_1.hasFlag)(w, flags_1.FLAGS.golemEye))
                break;
            (0, world_1.setFlag)(w, flags_1.FLAGS.golemEye);
            (0, world_1.emit)(w, { t: "eyeRepaired", actor: a.id, by: target?.actorId });
            break;
        case "npcGive":
            if ((0, world_1.hasFlag)(w, e.once))
                break;
            (0, world_1.setFlag)(w, e.once);
            (0, inventory_1.giveItem)(w, a, e.item, 1);
            break;
        case "segmentDone":
            (0, world_1.setFlag)(w, e.flag);
            break;
    }
}
/** The segment `segId` of an NPC's script, if `listener` may play it now (NPC present, requirement met). */
function playable(w, listener, npcActorId, segId) {
    const npc = npcActor(w, npcActorId);
    if (!npc || npc.area !== listener.area)
        return null;
    const script = dialogue_1.DIALOGUE[(0, npcs_1.npcDef)(npc.npc).dialogue];
    const seg = script?.segments.find((s) => s.id === segId);
    if (!script || !seg || !(0, requirements_1.meets)(w, listener, seg.when))
        return null;
    return { npc, script, seg };
}
// ------------------------------------------------------------------ commands
// Issued by the dialogue screen (world paused, like the pack's drop command)
// and by tests. Each validates and then applies plain Effects.
/** Talk to an NPC right now (the interaction path does the same via a `talk` task). Returns the segment that opens, if any. */
function talkTo(w, a, npcActorId) {
    const npc = npcActor(w, npcActorId);
    if (!npc)
        return null;
    (0, tasks_1.applyEffect)(w, a, { op: "talk" }, npcTarget(npc));
    const script = scriptOf(w, npcActorId);
    return currentSegment(w, a, script);
}
/** Fire a beat that belongs to segment `segId` of the NPC's script. Returns false if not allowed. */
function dialogueBeat(w, a, npcActorId, segId, beat) {
    const c = playable(w, a, npcActorId, segId);
    if (!c || !c.seg.pages.some((p) => p.beat === beat || p.then === beat))
        return false;
    const h = dialogue_1.BEATS[beat];
    if (!h)
        return false;
    const e = h({ npc: npcActorId });
    if (e)
        (0, tasks_1.applyEffect)(w, a, e, npcTarget(c.npc));
    return true;
}
/** A segment was played through: set its completion flag. Returns the segment that follows now, if any. */
function finishSegment(w, a, npcActorId, segId) {
    const c = playable(w, a, npcActorId, segId);
    if (!c)
        return null;
    (0, tasks_1.applyEffect)(w, a, { op: "segmentDone", npc: npcActorId, segment: segId, flag: c.seg.done }, npcTarget(c.npc));
    return currentSegment(w, a, c.script);
}
/**
 * Play a whole segment headlessly in screen order: show-beats, then dismiss
 * (then-beats), then finish. `upto` stops before dismissing that page index
 * (an interrupted dialogue). Used by tests and handy for debugging.
 */
function playSegment(w, a, npcActorId, seg, upto = Infinity) {
    const pages = segmentPages(w, a, seg);
    for (let i = 0; i < pages.length; i++) {
        const p = pages[i];
        if (p.beat)
            dialogueBeat(w, a, npcActorId, seg.id, p.beat);
        if (i >= upto)
            return null;
        if (p.then)
            dialogueBeat(w, a, npcActorId, seg.id, p.then);
    }
    return finishSegment(w, a, npcActorId, seg.id);
}
