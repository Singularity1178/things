"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recipeKnown = exports.buildRows = void 0;
exports.planLock = planLock;
exports.learnPlans = learnPlans;
exports.toggleScan = toggleScan;
exports.scanSpec = scanSpec;
exports.applyAnalysis = applyAnalysis;
exports.classifyHighlight = classifyHighlight;
exports.analysisState = analysisState;
exports.visionTargets = visionTargets;
const folk_1 = require("./folk");
const shops_1 = require("./shops");
const build_1 = require("../content/build");
const vision_1 = require("../content/vision");
const items_1 = require("../content/items");
const props_1 = require("../content/props");
const actors_1 = require("../content/actors");
const tiles_1 = require("../content/tiles");
const world_1 = require("../world/world");
const digging_1 = require("../content/digging");
const requirements_1 = require("./requirements");
const navigation_1 = require("./navigation");
/** The plans a prop of this kind teaches: the recipes that build it, and those that learn from it (`Recipe.learnFrom`). */
const buildRows = (kind) => Object.entries(build_1.RECIPES).filter(([, r]) => r.prop === kind || !!r.learnFrom?.some((l) => l.kind === kind));
exports.buildRows = buildRows;
function planLock(w, a, r) {
    if (!(0, requirements_1.meets)(w, a, r.requires))
        return "knowledge";
    if (r.analysis && !w.flags.has((0, vision_1.analysisFlag)(r.analysis)))
        return "analysis";
    return null;
}
const recipeKnown = (w, a, r) => planLock(w, a, r) === null;
exports.recipeKnown = recipeKnown;
/**
 * Read every plan a prop teaches (a scan, or taking it apart): grants each
 * unread analysis flag and emits one `analyzed` per plan. Returns the plans
 * read just now. Callers own the validation (reach, sight, capability).
 */
function learnPlans(w, a, p) {
    const fresh = [];
    for (const [id, r] of (0, exports.buildRows)(p.kind)) {
        const flag = (0, vision_1.analysisFlag)(r.analysis ?? id);
        if (!w.flags.has(flag)) {
            w.flags.add(flag);
            fresh.push([id, r]);
            (0, world_1.emit)(w, { t: "analyzed", actor: a.id, prop: p.id, flag });
        }
        // Studying the thing also shows how it is used (the smelter teaches smelting).
        if (r.teaches && !(0, world_1.hasFlag)(w, r.teaches)) {
            (0, world_1.setFlag)(w, r.teaches);
            (0, world_1.emit)(w, { t: "learned", flag: r.teaches });
        }
    }
    return fresh;
}
function toggleScan(a) {
    if ((0, actors_1.capable)(a, "scan"))
        a.mode = a.mode === "scan" ? "normal" : "scan";
}
function scanSpec(a, p) {
    return a.mode === "scan" && (0, actors_1.capable)(a, "scan") && p && (0, exports.buildRows)(p.kind).length
        ? { kind: "scan", dur: vision_1.SCAN_DURATION, effect: { op: "analyze" } } : null;
}
function applyAnalysis(w, a, area, target) {
    const p = target?.propId ? area.prop(target.propId) : undefined;
    if (!p || a.area !== area.id || !(0, actors_1.capable)(a, "scan") || Math.hypot(p.x - a.x, p.y - a.y) > (0, props_1.propReach)(p.kind) + 8 || !(0, navigation_1.lineOfSight)(area, a, p))
        return false;
    const rows = (0, exports.buildRows)(p.kind);
    if (!rows.length)
        return false;
    learnPlans(w, a, p);
    if (a.id === w.playerId)
        (0, world_1.emit)(w, { t: "message", text: `ANALYZED: ${rows[0][1].name}` });
    return true;
}
function classifyHighlight(facts) {
    for (const r of vision_1.HIGHLIGHT_RULES) {
        if (r.tags && facts.item && r.tags.some((tag) => items_1.ITEMS[facts.item].tags.includes(tag)))
            return r.category;
        if (r.trait && facts[r.trait])
            return r.category;
    }
    return null;
}
function analysisState(w, p) {
    const rows = (0, exports.buildRows)(p.kind);
    if (!rows.length)
        return undefined;
    return rows.every(([id, r]) => w.flags.has((0, vision_1.analysisFlag)(r.analysis ?? id))) ? "done" : "pending";
}
/** Interactive tiles only move when the layout does: scanning the whole grid every frame would cost O(w*h). */
const tileTargetCache = new WeakMap();
function tileTargets(area) {
    const c = tileTargetCache.get(area);
    if (c && c.rev === area.revision)
        return c.list;
    const list = [];
    for (let y = 0; y < area.h; y++)
        for (let x = 0; x < area.w; x++)
            if (tiles_1.TILE_INTERACT[area.tile(x, y)]) {
                list.push({ id: `tile:${x},${y}`, kind: `tile:${area.tile(x, y)}`, x: x * tiles_1.TS + 8, y: y * tiles_1.TS + 16, height: 16, category: "interactable", source: "tile" });
            }
    tileTargetCache.set(area, { rev: area.revision, list });
    return list;
}
/** Presentation consumes this read-only projection, never decides interaction semantics. */
function visionTargets(w, area) {
    const out = [];
    for (const p of area.props) {
        const d = (0, props_1.propDef)(p.kind);
        const category = classifyHighlight({
            item: !p.taken && !p.open ? p.item : undefined, rune: d.rune, buildable: (0, exports.buildRows)(p.kind).length > 0,
            interactable: !!(d.station || d.storage || d.examine || (!p.taken && p.item) || (p.container && !p.open) || (digging_1.DIG_SITES[p.kind] && !p.open)),
        });
        if (category)
            out.push({ id: p.id, kind: `prop:${p.kind}`, x: p.x, y: p.y, height: p.itemZ ?? 14, category, analysis: analysisState(w, p), source: "prop" });
    }
    for (const l of area.loose)
        if (!l.taken)
            out.push({ id: l.id, kind: `item:${l.item}`, x: l.x, y: l.y, height: 8, category: classifyHighlight({ item: l.item, interactable: true }), source: "loose" });
    for (const a of w.actors)
        if (a.area === area.id && a.id !== w.playerId && (0, folk_1.folkPresent)(a) && (0, shops_1.keeperPresent)(a))
            out.push({ id: a.id, kind: `actor:${a.npc ?? a.definition}`, x: a.x, y: a.y, height: (0, actors_1.actorDef)(a).body.height, category: "npc", source: "actor" });
    for (const t of tileTargets(area))
        out.push(t);
    return out;
}
