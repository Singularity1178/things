"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.flagOn = exports.heldCount = exports.allSlotsUnlocked = exports.slotUnlockFlags = exports.GEAR_KIT_RUNES = exports.GEAR_KIT = void 0;
exports.learnAllPlans = learnAllPlans;
exports.toggleGearKit = toggleGearKit;
exports.summonItem = summonItem;
exports.summonLoose = summonLoose;
exports.deleteItem = deleteItem;
exports.clearPack = clearPack;
exports.fillMaterials = fillMaterials;
exports.grantStoryKit = grantStoryKit;
exports.grantBuildKit = grantBuildKit;
exports.setAllSlots = setAllSlots;
exports.debugFlags = debugFlags;
exports.debugPlaces = debugPlaces;
exports.teleportTo = teleportTo;
// Debug kits (testing only, not part of the game's rules): the same pure sim
// functions the tests call, so what the Ctrl+6 key does is checked headless.
const flags_1 = require("../content/flags");
const build_1 = require("../content/build");
const vision_1 = require("../content/vision");
const actors_1 = require("../content/actors");
const items_1 = require("../content/items");
const glyphs_1 = require("../content/glyphs");
const runes_1 = require("../content/runes");
const geography_1 = require("../content/geography");
const npcs_1 = require("../content/npcs");
const tiles_1 = require("../content/tiles");
const areas_1 = require("../world/areas");
const world_1 = require("../world/world");
const inventory_1 = require("./inventory");
const collision_1 = require("./collision");
const gear_1 = require("./gear");
exports.GEAR_KIT = [["wood", 40], ["stone", 40], ["planks", 40], ["cut_stone", 40], ["chisel", 1]];
/** One of each: worn or carried, the kit never hands out a second. */
exports.GEAR_KIT_RUNES = ["rune_swift", "rune_glow"];
/** Every flag that unlocks a gear slot (read from the slot rows, so a new locked slot is covered with no change here). */
/** The upgrade flag that opens a slot by itself: its own `actorFlags`, or those of the last alternative (the left arm: the iron arm, else `golem.slot.armL`). */
const ownFlags = (r) => (!r ? [] : [...(r.actorFlags ?? []), ...(r.any?.length ? ownFlags(r.any[r.any.length - 1]) : [])]);
const slotUnlockFlags = (a) => Object.values((a ? (0, actors_1.actorDef)(a) : actors_1.ACTORS.golem).gearUnlocks ?? {}).flatMap((r) => ownFlags(r));
exports.slotUnlockFlags = slotUnlockFlags;
/** Debug only (Ctrl+4, Ctrl+6): every analysis-gated plan read, from the live catalog. Saves never do this. */
function learnAllPlans(w) {
    for (const r of Object.values(build_1.RECIPES))
        if (r.teaches)
            (0, world_1.setFlag)(w, r.teaches);
    for (const r of Object.values(build_1.RECIPES))
        if (r.analysis)
            w.flags.add((0, vision_1.analysisFlag)(r.analysis));
}
/** Are all the slots that can be unlocked, unlocked? */
const allSlotsUnlocked = (w, a = (0, world_1.player)(w)) => (0, exports.slotUnlockFlags)(a).every((f) => a.upgrades.includes(f));
exports.allSlotsUnlocked = allSlotsUnlocked;
/**
 * Ctrl+6, a toggle. ON: building knowledge (and masonry, for the brazier), the
 * basket worn so everything fits, the materials topped up (never stacked past
 * the target on a second press), the rune chisel, both runes (unless already
 * held or worn), and every locked gear slot unlocked (the second arm and the
 * other three rune slots). OFF: the slots lock again; anything worn in them
 * goes back to the pack (nothing is deleted). Materials and runes stay.
 * Returns whether the kit is now ON.
 */
function toggleGearKit(w, a) {
    if ((0, exports.allSlotsUnlocked)(w, a)) {
        for (const f of (0, exports.slotUnlockFlags)(a))
            (0, world_1.setActorFlag)(a, f, false);
        (0, gear_1.reconcileGear)(w, a);
        return false;
    }
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowMasonry);
    learnAllPlans(w);
    (0, gear_1.ensureWorn)(w, a, "basket");
    for (const [item, n] of exports.GEAR_KIT) {
        const have = (0, inventory_1.countItem)(a, item);
        if (have < n)
            (0, inventory_1.giveItem)(w, a, item, n - have);
    }
    for (const r of exports.GEAR_KIT_RUNES)
        if (!(0, gear_1.wears)(a, r) && (0, inventory_1.countItem)(a, r) === 0)
            (0, inventory_1.giveItem)(w, a, r, 1);
    for (const f of (0, exports.slotUnlockFlags)(a))
        (0, world_1.setActorFlag)(a, f);
    return true;
}
// ---------------------------------------------------------------- debug menu (Ctrl+0)
// Everything the debug menu does to the world lives here as pure sim functions,
// so tests run them headless. The menu (screens/debug.ts) only picks and displays.
/** The number of units of an item held in the pack, plus worn (the menu shows both). */
const heldCount = (a, id) => (0, inventory_1.countItem)(a, id) + ((0, gear_1.wears)(a, id) ? 1 : 0);
exports.heldCount = heldCount;
/**
 * Summon `n` of an item into the pack (what does not fit lands on the ground
 * beside the golem, as every pickup does). Body parts that install themselves
 * (the iron arm) are installed instead of packed, like picking them up.
 */
function summonItem(w, a, id, n) {
    const def = items_1.ITEMS[id];
    if (def.equip) {
        setActorOrWorldFlag(w, a, def.equip.flag, true);
        return { ok: true, text: `${def.name} INSTALLED` };
    }
    n = Math.max(1, Math.floor(n));
    const before = (0, inventory_1.countItem)(a, id);
    (0, inventory_1.giveItem)(w, a, id, n);
    const stored = (0, inventory_1.countItem)(a, id) - before;
    return { ok: true, text: stored >= n ? `+${n} ${def.name}` : `+${stored} PACKED, ${n - stored} ON THE GROUND` };
}
/** Summon `n` of an item onto the ground in front of the golem (stacks merge up to their stack size). */
function summonLoose(w, a, id, n) {
    const def = items_1.ITEMS[id];
    if (def.equip)
        return { ok: false, text: `${def.name} CANNOT LIE ON THE GROUND` };
    const area = (0, world_1.areaOf)(w, a);
    const spot = (0, inventory_1.dropSpot)(area, a, (0, collision_1.actorBoxes)(w, area.id, a.id));
    if (!spot)
        return { ok: false, text: "NO ROOM ON THE GROUND HERE" };
    n = Math.max(1, Math.floor(n));
    (0, inventory_1.spawnLoose)(area, id, n, spot.x, spot.y);
    return { ok: true, text: `${n} ${def.name} ON THE GROUND` };
}
/** Delete up to `n` of an item from the pack. Returns how many went. */
function deleteItem(a, id, n) {
    const k = Math.min(n, (0, inventory_1.countItem)(a, id));
    if (k > 0)
        (0, inventory_1.removeItems)(a, id, k);
    return k;
}
/** Empty the pack (worn gear stays on). Returns the number of units removed. */
function clearPack(a) {
    let n = 0;
    for (const id of new Set((0, inventory_1.heldItems)(a)))
        n += deleteItem(a, id, (0, inventory_1.countItem)(a, id));
    return n;
}
/** Every item with a stack size above one, topped up to `to` in the pack (what does not fit lands on the ground). */
function fillMaterials(w, a, to = 40) {
    for (const id of items_1.ITEM_IDS) {
        if (!items_1.ITEMS[id].tags.includes("material"))
            continue;
        const have = (0, inventory_1.countItem)(a, id);
        if (have < to)
            (0, inventory_1.giveItem)(w, a, id, to - have);
    }
}
/** The story kit (Ctrl+2): every rune glyph, the aether core, the chisel and the schematic, skipping what is held or placed. Returns how many were given. */
function grantStoryKit(w, a) {
    const r = (0, world_1.areaOf)(w, a).ritual;
    let given = 0;
    const give = (id) => { (0, inventory_1.addItems)(w, a, id, 1); given++; };
    for (let g = 0; g < glyphs_1.GLYPHS.length; g++) {
        const id = (0, items_1.glyphItem)(g);
        if ((0, inventory_1.countItem)(a, id) > 0 || r?.sockets.includes(g))
            continue;
        give(id);
    }
    if ((0, inventory_1.countItem)(a, "core") === 0 && !r?.core)
        give("core");
    for (const id of ["chisel", "schematic"])
        if ((0, inventory_1.countItem)(a, id) === 0)
            give(id);
    return given;
}
/** The build kit (Ctrl+4): every build flag and plan, the basket worn, 40 of each raw and crafted material. */
function grantBuildKit(w, a) {
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowMasonry);
    learnAllPlans(w);
    (0, gear_1.ensureWorn)(w, a, "basket");
    for (const id of ["wood", "stone", "planks", "cut_stone"])
        (0, inventory_1.addItems)(w, a, id, 40);
}
/** Set a flag wherever it lives: body flags (the arm, the slots) on the actor, the rest on the world. */
function setActorOrWorldFlag(w, _a, f, on) { if (on)
    (0, world_1.setFlag)(w, f);
else
    (0, world_1.clearFlag)(w, f); }
const flagOn = (w, f) => (0, world_1.hasFlag)(w, f);
exports.flagOn = flagOn;
/** Unlock every gear slot (true) or lock them all again (false: worn items go back to the pack). */
function setAllSlots(w, a, on) {
    for (const f of (0, exports.slotUnlockFlags)(a))
        (0, world_1.setActorFlag)(a, f, on);
    if (!on)
        (0, gear_1.reconcileGear)(w, a);
}
const pretty = (s) => s.replace(/[._]/g, " ").toUpperCase();
/** Every flag the game reads that can be toggled: the FLAGS table, the rune sites, every analysis plan and each NPC's awake state. */
function debugFlags(w) {
    const out = [];
    const seen = new Set();
    const add = (flag, label, group) => { if (!seen.has(flag)) {
        seen.add(flag);
        out.push({ flag, label, group });
    } };
    const group = (f) => (f.startsWith("golem.") ? "BODY" : f.startsWith("know.") ? "KNOWLEDGE" : "STORY");
    for (const f of Object.values(flags_1.FLAGS))
        add(f, pretty(f), group(f));
    for (const n of Object.values(runes_1.RUNE_NODES))
        add(n.flag, `RUNE: ${n.name}`, "RUNES");
    const keys = new Set();
    for (const r of Object.values(build_1.RECIPES))
        if (r.analysis)
            keys.add(r.analysis);
    for (const k of keys)
        add((0, vision_1.analysisFlag)(k), `PLAN: ${pretty(k)}`, "PLANS");
    for (const a of w.actors)
        if (a.kind === "npc")
            add((0, flags_1.npcFlag)(a.id, flags_1.NPC_AWAKE), `${(0, npcs_1.npcDef)(a.npc)?.name ?? pretty(a.id)} AWAKE`, "NPCS");
    // Anything else already set on the world (a flag a newer feature added) is listed too, so nothing is hidden.
    for (const f of [...w.flags].sort())
        add(f, pretty(f), group(f));
    return out;
}
const startCache = new Map();
const areaName = (id) => geography_1.AREA_NAMES[id] ?? id.toUpperCase();
/**
 * Every place worth jumping to: each area's start, its rooms, the rune sites
 * and circles, and every other actor standing in it. Areas not visited yet
 * offer just their start (read from the pure builder, never instantiated here,
 * so opening the menu changes nothing in the world).
 */
function debugPlaces(w) {
    const out = [];
    for (const id of Object.keys(areas_1.AREAS)) {
        const name = areaName(id), area = w.areas.get(id);
        if (!area) {
            if (!startCache.has(id))
                startCache.set(id, areas_1.AREAS[id]().start);
            const s = startCache.get(id);
            out.push({ label: `${name}: START (NEW AREA)`, group: name, area: id, x: s.x, y: s.y });
            continue;
        }
        out.push({ label: `${name}: START`, group: name, area: id, x: area.start.x, y: area.start.y });
        for (const r of area.rooms)
            out.push({ label: `${name}: ${r.name}`, group: name, area: id, x: (r.x + r.w / 2) * tiles_1.TS, y: (r.y + r.h / 2) * tiles_1.TS });
        if (area.base.ritual)
            out.push({ label: `${name}: CIRCLE`, group: name, area: id, x: area.base.ritual.x, y: area.base.ritual.y + 36 });
        for (const n of Object.values(runes_1.RUNE_NODES)) {
            const p = n.area === id ? area.prop(n.prop) : undefined;
            if (p)
                out.push({ label: `${name}: RUNE ${n.name}`, group: name, area: id, x: p.x + n.arrive.dx, y: p.y + n.arrive.dy });
        }
        for (const a of w.actors)
            if (a.area === id && a.id !== w.playerId)
                out.push({ label: `${name}: ${(0, npcs_1.npcDef)(a.npc)?.name ?? (0, actors_1.actorDef)(a).name}`, group: name, area: id, x: a.x, y: a.y + 14 });
    }
    return out;
}
/**
 * Put the actor at (x, y) in an area, nudged to the nearest free spot (a ring
 * search, so a room's centre that holds a table still works). Crosses areas
 * through enterArea. False (and nothing moves) if no free spot is near.
 */
function teleportTo(w, a, areaId, x, y) {
    if (!areas_1.AREAS[areaId])
        return false;
    const area = (0, world_1.getArea)(w, areaId);
    const bodies = (0, collision_1.actorBoxes)(w, areaId, a.id), size = (0, actors_1.actorDef)(a).body.box;
    let spot = null;
    for (let r = 0; r <= 12 && !spot; r++) {
        for (let dy = -r; dy <= r && !spot; dy++)
            for (let dx = -r; dx <= r && !spot; dx++) {
                if (Math.max(Math.abs(dx), Math.abs(dy)) !== r)
                    continue;
                const px = Math.round(x + dx * 4), py = Math.round(y + dy * 4);
                if ((0, collision_1.boxFree)(area, px, py, bodies, size))
                    spot = { x: px, y: py };
            }
    }
    if (!spot)
        return false;
    if (a.area !== areaId)
        (0, world_1.enterArea)(w, a, areaId, spot.x, spot.y);
    a.x = spot.x;
    a.y = spot.y;
    a.vx = 0;
    a.vy = 0;
    a.task = null;
    a.queue = [];
    return true;
}
