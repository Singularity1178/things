"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.harvestReach = harvestReach;
exports.harvestStep = harvestStep;
const harvest_1 = require("../content/harvest");
const actorStats_1 = require("./actorStats");
const tools_1 = require("./tools");
/**
 * The harvestable props a blow at (x, y) reaches: every standing tree, rock or
 * log with some part of its footprint (its collision box, or just its anchor if
 * it has none) within `radius` of the blow. The golem's own position is
 * irrelevant, as for every slam target. Nearest first, ties by id, so the order
 * is deterministic. Depleted props are not harvestable and are left out.
 */
function harvestReach(area, x, y, radius) {
    const found = [];
    for (const p of area.props) {
        if (p.taken || !harvest_1.HARVEST[p.kind])
            continue;
        const b = p.box ?? [p.x, p.y, p.x, p.y];
        const dx = Math.max(b[0] - x, 0, x - b[2]), dy = Math.max(b[1] - y, 0, y - b[3]);
        const d2 = dx * dx + dy * dy;
        if (d2 <= radius * radius)
            found.push({ p, d2 });
    }
    return found.sort((a, b) => a.d2 - b.d2 || (a.p.id < b.p.id ? -1 : 1)).map((f) => f.p);
}
/** One blow's entitlement, shared by the effect and the job's capacity check. */
function harvestStep(a, p) {
    // The right tool, fitted or wielded, multiplies the blow (content/tools.ts); bare fists do the base work.
    const def = harvest_1.HARVEST[p.kind], power = (0, actorStats_1.harvestPower)(a) * (1 + (0, tools_1.toolBonus)(a, def?.tool));
    if (!def || p.taken || !Number.isFinite(power) || power <= 0)
        return null;
    const before = Math.min(def.hp, p.dmg);
    const after = Math.min(def.hp, Math.round((before + power) * 1e9) / 1e9);
    if (after <= before)
        return null;
    const depleted = after >= def.hp, rewards = new Map();
    const units = Math.floor(after * def.perHit.n + 1e-9) - Math.floor(before * def.perHit.n + 1e-9);
    if (units)
        rewards.set(def.perHit.item, units);
    if (depleted && def.final)
        rewards.set(def.final.item, (rewards.get(def.final.item) ?? 0) + def.final.n);
    return { damage: after - before, depleted, rewards: [...rewards].map(([item, n]) => ({ item, n })) };
}
