"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.blockText = exports.BLOCK_TEXT = exports.AMOUNTS = exports.sourceCount = exports.gatherTargets = exports.INVENTORY_LABEL = exports.stationOptions = exports.storageOptions = exports.propName = exports.cleanPropName = exports.PROP_NAME_MAX = exports.canReach = exports.canTake = exports.areaName = void 0;
exports.knownAreas = knownAreas;
exports.propLabel = propLabel;
exports.defaultPropName = defaultPropName;
exports.gatherResources = gatherResources;
exports.gatherSources = gatherSources;
exports.gatherRefusal = gatherRefusal;
exports.craftChoices = craftChoices;
exports.walkOptions = walkOptions;
exports.powerState = powerState;
exports.refLabel = refLabel;
exports.jobView = jobView;
exports.workerStatus = workerStatus;
// What the worker management screen may offer, and how it words a worker's
// state. Pure sim (no DOM): every list is derived from the World and the data
// rows (HARVEST, CRAFT_RECIPES, JOB_KINDS, RUNE_NODES), never stored, so the
// screen only ever offers targets the order's own validation accepts. Orders
// themselves are built with gatherOrder / craftOrder and given through
// commands.ts: giveWorkerOrder.
const actors_1 = require("../content/actors");
const geography_1 = require("../content/geography");
const harvest_1 = require("../content/harvest");
const items_1 = require("../content/items");
const jobs_1 = require("../content/jobs");
const props_1 = require("../content/props");
const build_1 = require("../content/build");
const crafting_1 = require("../content/crafting");
const runes_1 = require("../content/runes");
const power_1 = require("./power");
const actorStats_1 = require("./actorStats");
const crafting_2 = require("./crafting");
const collision_1 = require("./collision");
const routes_1 = require("./routes");
const portals_1 = require("./portals");
const areas_1 = require("../world/areas");
const areaName = (id) => geography_1.AREA_NAMES[id] ?? id.toUpperCase().replace(/[^A-Z0-9]+/g, " ").trim();
exports.areaName = areaName;
/** Does this body have what an order kind needs (JOB_KINDS capabilities)? */
const canTake = (a, kind) => !!jobs_1.JOB_KINDS[kind] && jobs_1.JOB_KINDS[kind].capabilities.every((c) => (0, actors_1.capable)(a, c));
exports.canTake = canTake;
/** Can this actor get to `area`: it is there, or a route leads there for its body, by rune or on foot (sim/routes.ts). */
const canReach = (w, a, area) => (0, routes_1.routeExists)(w, (0, routes_1.meansOf)(a), a.area, area);
exports.canReach = canReach;
/**
 * The areas an order may name: those visited, and those an open road or door out of a visited area leads to. The
 * far end of a way one has stood at can be named (the waymark at the old road's mouth, the signs over the shops'
 * doors); the far end of a rune cannot until it has been used, so the surface stays unknown until the first crossing.
 */
function knownAreas(w) {
    const out = new Set(w.areas.keys());
    for (const area of w.areas.values())
        for (const p of (0, portals_1.portalsOf)(area))
            if (areas_1.AREAS[p.to.area] && (0, portals_1.portalOpen)(w, p))
                out.add(p.to.area);
    return [...out].sort();
}
const SHORT = { storage_chest: "CHEST", workbench: "BENCH" };
/** A prop kind's name: the recipe that builds it, else its kind. */
function propLabel(kind) {
    const id = (0, build_1.recipeForProp)(kind);
    return id ? build_1.RECIPES[id].name : kind.toUpperCase().replace(/_/g, " ");
}
/** The longest name a prop may be given. */
exports.PROP_NAME_MAX = 20;
/** What a typed name becomes: upper case, one space between words, trimmed, no longer than PROP_NAME_MAX. Empty means "no name of its own". */
const cleanPropName = (s) => s.toUpperCase().replace(/\s+/g, " ").trim().slice(0, exports.PROP_NAME_MAX).trim();
exports.cleanPropName = cleanPropName;
/** Which prop of its kind in its area this is, and how many there are: the orders' numbering (stable id order, among props of that kind). */
function kindIndex(area, p) {
    const same = area.props.filter((q) => q.kind === p.kind).sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
    return { n: same.indexOf(p) + 1, of: same.length };
}
/**
 * What a prop is called until the player names it: its area, its kind and (with several of a kind in the area) its
 * number, as every order screen words it: "DUNGEON CHEST 1", "DUNGEON CHEST 2", "SURFACE CHEST".
 */
function defaultPropName(area, p) {
    const { n, of } = kindIndex(area, p);
    return `${(0, exports.areaName)(area.id)} ${SHORT[p.kind] ?? p.kind.toUpperCase().replace(/_/g, " ")}${of > 1 ? ` ${n}` : ""}`;
}
/** A prop's name: the one the player gave it, else its default. The one name the storage screen and the orders both use. */
const propName = (area, p) => p.name || defaultPropName(area, p);
exports.propName = propName;
/** Props in the areas the worker can get to (areas already visited), in stable area then id order, with labels like "SURFACE CHEST 2". */
function propOptions(w, a, want) {
    const out = [];
    for (const id of [...w.areas.keys()].sort()) {
        if (!(0, exports.canReach)(w, a, id))
            continue;
        const area = w.areas.get(id), props = area.props.filter(want).sort((p, q) => (p.id < q.id ? -1 : p.id > q.id ? 1 : 0));
        for (const p of props) {
            out.push({ ref: { area: id, prop: p.id }, kind: p.kind, area: id, label: (0, exports.propName)(area, p) });
        }
    }
    return out;
}
/** Storage props the worker can deposit into. */
const storageOptions = (w, a) => propOptions(w, a, (p) => !!p.inventory && !!(0, props_1.propDef)(p.kind).storage);
exports.storageOptions = storageOptions;
/** Work stations the worker can craft at. */
const stationOptions = (w, a) => propOptions(w, a, (p) => !!(0, props_1.propDef)(p.kind).station);
exports.stationOptions = stationOptions;
/** What the order screen calls a worker's own pack as the place to put what it gathers. */
exports.INVENTORY_LABEL = "INVENTORY";
/**
 * Where a gather order may put what it gathers: every storage prop the worker can get to, then its own pack
 * (`ref: null`), which is always there, so a gather can be ordered before any chest is built.
 */
const gatherTargets = (w, a) => [...(0, exports.storageOptions)(w, a).map((o) => ({ label: o.label, ref: o.ref })), { label: exports.INVENTORY_LABEL, ref: null }];
exports.gatherTargets = gatherTargets;
/** Resources the world can yield: every item a harvestable pays, in data order. */
function gatherResources() {
    const out = [];
    for (const d of Object.values(harvest_1.HARVEST))
        for (const i of [d.perHit.item, d.final?.item])
            if (i && !out.includes(i))
                out.push(i);
    return out;
}
const yields = (p, item) => harvest_1.HARVEST[p.kind]?.perHit.item === item || harvest_1.HARVEST[p.kind]?.final?.item === item;
const sourceCount = (area, item) => area.props.filter((p) => !p.taken && yields(p, item)).length;
exports.sourceCount = sourceCount;
/** Areas the worker can get to that still hold something yielding `item`. */
function gatherSources(w, a, item) {
    return [...w.areas.keys()].sort().filter((id) => (0, exports.canReach)(w, a, id)).flatMap((id) => {
        const count = (0, exports.sourceCount)(w.areas.get(id), item);
        return count ? [{ area: id, label: (0, exports.areaName)(id), count }] : [];
    });
}
/** Why a gather from `from` into `storage` (null: its own pack) can't be run (text), or null. The worker finds its own way there and back. */
function gatherRefusal(w, a, item, from, storage) {
    if (!(0, exports.canTake)(a, "gatherDeposit"))
        return "IT CANNOT DO THAT WORK";
    if (!from)
        return `NO ${items_1.ITEM_NAMES[item]} TO BE FOUND`;
    // (keeping what it gathers, there is nowhere it has to get back to)
    if (storage && !(0, routes_1.routeExists)(w, (0, routes_1.meansOf)(a), from, storage.area))
        return "NO WAY BACK FROM THERE";
    return null;
}
/** Recipes a worker may be sent to craft: every one it knows how to make (unknown ones stay hidden, as at the bench). */
function craftChoices(w, a, station) {
    if (!station)
        return [];
    const p = w.areas.get(station.area)?.prop(station.ref.prop), kind = (0, props_1.propDef)(station.kind).station;
    if (!kind)
        return [];
    return (0, crafting_1.craftRecipesFor)(kind, crafting_1.CRAFT_RECIPES).map((r) => (0, crafting_2.craftEntry)(w, a, r, p)).filter((e) => e.status !== "unknown");
}
/** Places to send it: the start of each area, beside each storage prop and station, and by each rune. */
function walkOptions(w, a) {
    const size = (0, actors_1.actorDef)(a).body.box, out = [];
    const spot = (area, x, y) => (0, collision_1.nearestFree)(area, x, y, (0, collision_1.actorBoxes)(w, area.id, a.id), size);
    const add = (label, area, x, y) => { const s = spot(area, x, y); if (s)
        out.push({ label, area: area.id, x: s.x, y: s.y }); };
    for (const id of knownAreas(w)) {
        if (!(0, exports.canReach)(w, a, id))
            continue;
        const area = w.areas.get(id);
        if (!area) {
            // Known but not yet visited (the far end of a road): only where one comes in, read from its builder. Listing
            // it instantiates nothing; the area comes into being when someone walks in.
            const s = (0, routes_1.areaBase)(id)?.start;
            if (s)
                out.push({ label: `${(0, exports.areaName)(id)} START`, area: id, x: s.x, y: s.y });
            continue;
        }
        add(`${(0, exports.areaName)(id)} START`, area, area.start.x, area.start.y);
        for (const o of [...(0, exports.storageOptions)(w, a), ...(0, exports.stationOptions)(w, a)].filter((o) => o.area === id)) {
            const p = area.prop(o.ref.prop);
            add(o.label, area, p.x, p.y + 12);
        }
        for (const n of Object.values(runes_1.RUNE_NODES).filter((n) => n.area === id).sort((p, q) => (p.id < q.id ? -1 : 1))) {
            const p = area.prop(n.prop);
            if (p)
                add(`${(0, exports.areaName)(id)} RUNE`, area, p.x + n.arrive.dx, p.y + n.arrive.dy);
        }
    }
    return out;
}
// ---------------------------------------------------------------- amounts
/** What the amount row steps through; the last is "repeat until told otherwise". */
exports.AMOUNTS = [1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 30, 40, 50, 99, "REPEAT"];
/** Short reasons an order blocks (`Job.reason`), at most 15 characters so "BLOCKED: " fits beside them. */
exports.BLOCK_TEXT = {
    storageFull: "STORAGE FULL", missingStorage: "NO STORAGE", packFull: "PACK FULL", noResource: "NO RESOURCE",
    cannotHarvest: "CAN'T HARVEST", noTravel: "CAN'T TRAVEL", noRoute: "NO WAY THERE", missingRune: "RUNE MISSING",
    pathBlocked: "PATH BLOCKED", craftChanged: "CRAFT FAILED", missingStation: "NO STATION", cost: "NO MATERIALS",
    tools: "NEEDS TOOL", unknown: "UNKNOWN RECIPE", arrivalBlocked: "ARRIVAL BLOCKED", unknownJob: "UNKNOWN ORDER",
};
const blockText = (reason) => (reason && exports.BLOCK_TEXT[reason]) || "STUCK";
exports.blockText = blockText;
const PHASE_TEXT = { gather: "GATHERING", deposit: "STORING", craft: "CRAFTING", walk: "WALKING" };
/** The worker's body state: the core in it and whether it runs on it. */
function powerState(a) {
    if (!(0, actors_1.actorDef)(a).power)
        return { text: "NEEDS NO CORE", tone: "ok" };
    if (!a.powerCore)
        return { text: "NO CORE", tone: "bad" };
    if (!(0, power_1.coreCheck)(a, a.powerCore).sufficient)
        return { text: "CORE TOO WEAK", tone: "warn" };
    return { text: items_1.ITEM_NAMES[a.powerCore], tone: "ok" };
}
function refLabel(w, ref) {
    const p = w.areas.get(ref.area)?.prop(ref.prop);
    if (!p)
        return "MISSING";
    const same = (w.areas.get(ref.area)?.props ?? []).filter((q) => q.kind === p.kind).sort((q, r) => (q.id < r.id ? -1 : 1));
    return `${(0, exports.areaName)(ref.area)} ${SHORT[p.kind] ?? p.kind.toUpperCase().replace(/_/g, " ")}${same.length > 1 ? ` ${same.indexOf(p) + 1}` : ""}`;
}
const amountText = (j) => (j.args.repeat === true ? `${j.completed} DONE (REPEAT)` : `${j.completed}/${j.args.amount}`);
/** An actor's current order and how it is going, for the management screen. Null with no order. */
function jobView(w, a) {
    const j = a.job;
    if (!j)
        return null;
    let title = "ORDER", progress = "", lines = [];
    if (j.kind === "gatherDeposit") {
        title = `GATHER ${items_1.ITEM_NAMES[j.args.resource] ?? "?"}`;
        progress = amountText(j);
        lines = [`FROM ${(0, exports.areaName)(String(j.args.fromArea))}`, `TO ${j.args.storage ? refLabel(w, j.args.storage) : exports.INVENTORY_LABEL}`];
    }
    else if (j.kind === "craftAt") {
        title = `CRAFT ${crafting_1.CRAFT_RECIPES.find((r) => r.id === j.args.recipe)?.name ?? "?"}`;
        progress = amountText(j);
        lines = [`AT ${refLabel(w, j.args.station)}`];
    }
    else if (j.kind === "walk") {
        title = `GO TO ${(0, exports.areaName)(String(j.args.area))}`;
        lines = [`${Math.round(Number(j.args.x))},${Math.round(Number(j.args.y))}`];
    }
    const phase = j.transit || a.task?.effect?.op === "travel" ? "TRAVELLING" : PHASE_TEXT[j.phase] ?? j.phase.toUpperCase();
    let status = "WORKING", tone = "ok";
    if (j.status === "done") {
        status = "DONE";
        tone = "dim";
    }
    else if (j.status === "blocked") {
        status = `BLOCKED: ${(0, exports.blockText)(j.reason)}`;
        tone = "bad";
    }
    else if (j.status === "paused") {
        status = j.reason === "power" ? "WAITING FOR POWER" : "PAUSED";
        tone = "warn";
    }
    return { title, progress, phase: j.status === "done" ? "FINISHED" : phase, status, tone, lines };
}
/** One line for the head of the screen: what the body is doing. */
function workerStatus(w, a) {
    const v = jobView(w, a);
    if (v)
        return { text: v.status, tone: v.tone };
    return (0, actorStats_1.powered)(a) ? { text: "IDLE: NO ORDER", tone: "dim" } : { text: "OFF: NO POWER", tone: "bad" };
}
