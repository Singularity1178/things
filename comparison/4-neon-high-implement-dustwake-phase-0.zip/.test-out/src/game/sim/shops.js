"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.keeperReady = exports.keeperOf = exports.keeperLabel = exports.keeperPresent = exports.isKeeper = exports.keeperId = exports.KEEPER_REACH = exports.KEEPER_DEF = exports.KEEPER_KIND = exports.wellOff = exports.shopOpen = exports.shopOfArea = exports.SHOP_BY_AREA = void 0;
exports.shopOpenAt = shopOpenAt;
exports.openThrough = openThrough;
exports.openRun = openRun;
exports.tripsOf = tripsOf;
exports.shopStepAt = shopStepAt;
exports.keeperServe = keeperServe;
exports.populateKeepers = populateKeepers;
exports.tickKeepers = tickKeepers;
exports.keeperTalk = keeperTalk;
// Shops (sim): the keepers behind Westwake's counters, opening hours, and each person's shop trips. No DOM, no
// Math.random: like the townsfolk, every choice is a hash of the world seed, the actor and a counter.
//
// A keeper is an Actor of kind "keeper" (definition `shopkeeper`) with a `keeper` record: which shop, a name, and
// what they are doing. They are not townsfolk: no routine, no home, no wandering. They live in their shop's room and
// are only stepped while the golem is in it; coming in finds them where the hour says (at the counter, or gone
// upstairs: out of hours a keeper is "away", and like a person indoors is not drawn, scanned or talked to).
// At the counter they greet whoever comes in, serve the customer in front of them (sim/folk.ts runs the exchange and
// calls keeperServe), tidy the shelves behind them between customers, and answer the golem (RULES.keeper).
//
// A shop trip is part of a person's plan, worked out from the clock like the rest of it (sim/folk.ts: planAt): inside
// a block of their routine in which their archetype shops (content/shops.ts: SHOP_HABITS), at a time and to a shop
// and with a purpose chosen by hash for that person and day, and only while that shop is open. So trips need no
// catching up, survive a save for free, and arriving at any hour finds the right people inside.
//
// Seams: `keeper.with` / keeperServe is where a real sale will happen; keeperTalk is where a shop screen or the
// guild's contract desk opens; a keeper's art is KEEPER_ART (keeperArt.ts).
const shops_1 = require("../content/shops");
const town_1 = require("../content/town");
const folk_1 = require("../content/folk");
const daycycle_1 = require("../content/daycycle");
const world_1 = require("../world/world");
const folk_2 = require("./folk");
// ---------------------------------------------------------------- hours
exports.SHOP_BY_AREA = Object.fromEntries(town_1.ESTABLISHMENTS.map((e) => [(0, town_1.interiorId)(e), shops_1.SHOPS[e]]));
/** The shop whose room this area is. */
const shopOfArea = (area) => exports.SHOP_BY_AREA[area];
exports.shopOfArea = shopOfArea;
/** Is the shop open at this hour of the town clock? (Shut over lunch; `close` may run past midnight.) */
function shopOpenAt(def, hour) {
    const h = (0, daycycle_1.wrapHour)(hour), { open, close, lunch } = def.hours;
    const within = close > 24 ? h >= open || h < close - 24 : h >= open && h < close;
    return within && !(lunch && h >= lunch[0] && h < lunch[1]);
}
/** Open the whole way from `from` to `to` (hours, from <= to), with nothing shutting in between. */
function openThrough(def, from, to) {
    for (let h = from; h < to; h += 0.2)
        if (!shopOpenAt(def, h))
            return false;
    return shopOpenAt(def, to);
}
const shopOpen = (w, shop) => shopOpenAt(shops_1.SHOPS[shop], (0, daycycle_1.hourOf)(w.day));
exports.shopOpen = shopOpen;
/** The longest stretch between `from` and `to` (hours) through which the shop is open, or null if it is shut throughout. */
function openRun(def, from, to) {
    const step = 0.1, n = Math.floor((to - from) / step + 1e-9);
    let best = null, i0 = -1;
    for (let i = 0; i <= n + 1; i++) {
        const open = i <= n && shopOpenAt(def, from + i * step);
        if (open && i0 < 0)
            i0 = i;
        if (!open && i0 >= 0) {
            const a = from + i0 * step, b = i - 1 === n && shopOpenAt(def, to) ? to : from + (i - 1) * step;
            if (!best || b - a > best[1] - best[0])
                best = [a, b];
            i0 = -1;
        }
    }
    return best;
}
/** People whose house is lit by light runes have money (content/town.ts: the lighting is the town's map of itself). */
const wellOff = (p) => town_1.BUILDINGS.find((b) => `door.${b.id}` === p.home)?.light === "rune";
exports.wellOff = wellOff;
function weighted(rows, r) {
    const total = rows.reduce((s, [, n]) => s + Math.max(0, n), 0);
    if (total <= 0)
        return null;
    let k = r * total;
    for (const [x, n] of rows) {
        k -= Math.max(0, n);
        if (k < 0)
            return x;
    }
    return rows[rows.length - 1][0];
}
const tripCache = new Map();
/**
 * The shop trips of one person's day (their own clock's day `day`), from the seed by hash. Pure: the same world,
 * person and day always give the same trips (cached; nothing here is saved).
 */
function tripsOf(w, a, day, blocks) {
    const p = a.person, habit = shops_1.SHOP_HABITS[p.archetype];
    if (!habit)
        return [];
    const key = `${w.seed}|${a.id}|${day}|${p.archetype}|${p.routine}|${p.traits.join(",")}|${p.home}`;
    const hit = tripCache.get(key);
    if (hit)
        return hit;
    if (tripCache.size > 4000)
        tripCache.clear();
    const out = [], shift = (0, folk_2.shiftOf)(w, a, day), rich = (0, exports.wellOff)(p);
    const h = (i, k, salt) => (0, daycycle_1.hash01)(`${w.seed}:${a.id}:trip:${day}:${i}:${k}`, salt);
    blocks.forEach((b, i) => {
        const len = b.to - b.from;
        if (!habit.during.includes(b.act) || len < shops_1.TRIP.minBlock)
            return;
        const slots = len >= shops_1.TRIP.twoIn ? 2 : 1, seg = len / slots;
        for (let k = 0; k < slots; k++) {
            if (h(i, k, 0) > habit.chance)
                continue;
            const dur = Math.min(shops_1.TRIP.len[0] + h(i, k, 1) * (shops_1.TRIP.len[1] - shops_1.TRIP.len[0]), seg - 2 * shops_1.TRIP.margin);
            let from = b.from + seg * k + shops_1.TRIP.margin + h(i, k, 2) * (seg - dur - 2 * shops_1.TRIP.margin), to = from + dur;
            // where: by the archetype's habits, the person's means and traits, among the shops open for (enough of) that time:
            // a trip is cut to the shop's hours (out at closing, in when lunch is over), and not made if too little is left
            const runs = {};
            const shops = Object.keys(habit.shops).map((s) => {
                const def = shops_1.SHOPS[s], run = openRun(def, from + shift, to + shift);
                if (!run || run[1] - run[0] < Math.min(shops_1.TRIP.minTrip, dur - 0.01))
                    return [s, 0];
                runs[s] = run;
                let n = habit.shops[s] ?? 0;
                if (rich && def.wellOff)
                    n *= def.wellOff;
                for (const t of p.traits)
                    n *= def.traits?.[t] ?? 1;
                return [s, n];
            });
            const shop = weighted(shops, h(i, k, 3));
            if (!shop)
                continue;
            from = runs[shop][0] - shift;
            to = runs[shop][1] - shift;
            // what for: the shop's visits, by who likes doing what
            const visits = Object.entries(shops_1.SHOPS[shop].visits).map(([id, n]) => {
                const v = shops_1.VISITS[id];
                if (!v || (v.only && !v.only.includes(p.archetype)))
                    return [id, 0];
                let m = n * (v.likes?.[p.archetype] ?? 1);
                for (const t of p.traits)
                    m *= v.likes?.[t] ?? 1;
                return [id, m];
            });
            const visit = weighted(visits, h(i, k, 4));
            if (visit)
                out.push({ n: out.length, block: i, from, to, shop, visit });
        }
    });
    tripCache.set(key, out);
    return out;
}
/** The step of the visit a trip is at, at calendar time `day`: the first stretch of the trip is the walk there. */
function shopStepAt(plan, day) {
    const steps = shops_1.VISITS[plan.trip.visit].steps, total = steps.reduce((s, x) => s + x.share, 0);
    const frac = (day - plan.startDay) / Math.max(1e-9, plan.endDay - plan.startDay);
    let k = Math.min(0.9999, Math.max(0, (frac - shops_1.TRIP.lead) / (1 - shops_1.TRIP.lead))) * total;
    for (let i = 0; i < steps.length; i++) {
        k -= steps[i].share;
        if (k < 0)
            return { index: i, step: steps[i] };
    }
    return { index: steps.length - 1, step: steps[steps.length - 1] };
}
exports.KEEPER_KIND = "keeper";
exports.KEEPER_DEF = "shopkeeper";
/** How far the golem can speak to a keeper from: across the counter. */
exports.KEEPER_REACH = 38;
const NEVER = -1e9;
const KEEPER_SPEED = 15;
const keeperId = (shop) => `keeper.${shop}`;
exports.keeperId = keeperId;
const isKeeper = (a) => a.kind === exports.KEEPER_KIND && !!a.keeper;
exports.isKeeper = isKeeper;
/** In the shop (not gone upstairs out of hours). Away keepers are not drawn, scanned or talked to. */
const keeperPresent = (a) => !(0, exports.isKeeper)(a) || a.keeper.state !== "away";
exports.keeperPresent = keeperPresent;
/** "EDDA MARSH - SMITH": the name and trade, for notes and the scan. */
const keeperLabel = (a) => `${a.keeper.name} - ${shops_1.SHOPS[a.keeper.shop].keeper.title}`;
exports.keeperLabel = keeperLabel;
/** The keeper of the shop whose room `area` is, if they have been made. */
const keeperOf = (w, area) => { const s = (0, exports.shopOfArea)(area); return s ? (0, world_1.actorById)(w, (0, exports.keeperId)(s.id)) : undefined; };
exports.keeperOf = keeperOf;
/** At the counter with nobody in front of them: ready to serve. */
const keeperReady = (a) => (0, exports.isKeeper)(a) && a.keeper.state === "tend" && a.keeper.attend <= 0;
exports.keeperReady = keeperReady;
/** A customer's exchange at the counter begins (sim/folk.ts); it ends when the customer's chat does. */
function keeperServe(a, customer) { const K = a.keeper; K.state = "serve"; K.with = customer; K.goal = null; }
/**
 * Make the keeper of the shop whose room `area` is, once (world.getArea calls this when the room is first entered by
 * anyone; deserialize calls it for rooms an older save had already visited). No flag: the keeper's own actor is the
 * record. Their name is drawn from the seed by hash, never from w.rng.
 */
function populateKeepers(w, area) {
    const shop = (0, exports.shopOfArea)(area);
    if (!shop || (0, world_1.actorById)(w, (0, exports.keeperId)(shop.id)))
        return;
    // a shop's room is part of the town: its customers are the town's people, so the town exists once the room does
    // (the golem normally walks in from the street; a debug teleport straight into a shop must not find it empty for ever)
    (0, world_1.getArea)(w, town_1.TOWN_ID);
    const room = w.areas.get(area);
    const home = room ? (0, folk_2.spotById)(room, "keeper") : undefined;
    if (!home)
        return;
    const id = (0, exports.keeperId)(shop.id), h = (salt) => (0, daycycle_1.hash01)(`${w.seed}:${id}`, salt);
    const a = (0, world_1.makeActor)(id, exports.KEEPER_DEF, area, home.x, home.y);
    a.kind = exports.KEEPER_KIND;
    a.keeper = {
        shop: shop.id, name: `${folk_1.NAMES.given[Math.floor(h(1) * folk_1.NAMES.given.length)]} ${folk_1.NAMES.family[Math.floor(h(2) * folk_1.NAMES.family.length)]}`,
        state: "away", t: 0, cool: 0, greet: 0, attend: 0, seen: NEVER, with: null, goal: null, n: 0, talks: 0,
    };
    w.actors.push(a);
}
const faceTo = (dx, dy) => (Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? "right" : "left") : dy > 0 ? "down" : "up");
function say(w, a, lines, to) {
    const K = a.keeper;
    if (!lines.length)
        return;
    (0, world_1.emit)(w, { t: "folkSay", folk: a.id, to, line: lines[Math.floor((0, daycycle_1.hash01)(`${w.seed}:${a.id}`, 300 + K.talks++) * lines.length)] });
}
function moveToward(a, g, dt) {
    const dx = g.x - a.x, dy = g.y - a.y, d = Math.hypot(dx, dy), step = KEEPER_SPEED * dt;
    if (d <= step) {
        a.x = g.x;
        a.y = g.y;
        return true;
    }
    a.x += dx / d * step;
    a.y += dy / d * step;
    a.moving = true;
    a.facing = faceTo(dx, dy);
    a.phase += step * 0.26;
    return false;
}
/** Step the keeper of the room the golem is in (stepWorld calls this after the townsfolk). */
function tickKeepers(w, dt) {
    const pl = (0, world_1.player)(w);
    if (!pl)
        return;
    for (const a of w.actors)
        if ((0, exports.isKeeper)(a) && a.area === pl.area)
            tickKeeper(w, a, dt, pl);
}
function tickKeeper(w, a, dt, pl) {
    const K = a.keeper, def = shops_1.SHOPS[K.shop], area = (0, world_1.getArea)(w, a.area), home = (0, folk_2.spotById)(area, "keeper");
    if (!def || !home)
        return;
    const open = shopOpenAt(def, (0, daycycle_1.hourOf)(w.day)), fresh = w.time - K.seen > 1;
    const R = (salt) => (0, daycycle_1.hash01)(`${w.seed}:${a.id}`, salt + (K.n++ % 100000) * 7);
    K.seen = w.time;
    K.cool = Math.max(0, K.cool - dt);
    a.moving = false;
    if (fresh) {
        // the golem has just come in: the keeper is where the hour says
        K.state = open ? "tend" : "away";
        a.x = home.x;
        a.y = home.y;
        a.facing = "down";
        K.goal = null;
        K.with = null;
        K.attend = 0;
        K.t = 4 + R(1) * 8;
        K.greet = open ? 0.9 : 0;
        if (!open)
            (0, world_1.emit)(w, { t: "message", text: def.closedNote });
    }
    // a customer mid-exchange is finished with first, even at closing time
    if (K.state === "serve") {
        const c = K.with ? (0, world_1.actorById)(w, K.with) : undefined;
        if (c && c.area === a.area && c.life?.chat?.with === a.id) {
            a.facing = faceTo(c.x - a.x, c.y - a.y);
            return;
        }
        K.state = "tend";
        K.with = null;
        K.t = 3 + R(2) * 5;
        a.facing = "down";
    }
    if (!open) {
        if (K.state !== "away") {
            // closing time, or lunch: a word to whoever is still here, then up the stairs
            say(w, a, def.keeper.closing);
            K.state = "away";
            K.goal = null;
            K.attend = 0;
            a.x = home.x;
            a.y = home.y;
        }
        return;
    }
    if (K.state === "away") {
        K.state = "tend";
        a.x = home.x;
        a.y = home.y;
        a.facing = "down";
        K.t = 5 + R(3) * 8;
    }
    if (K.greet > 0) {
        K.greet -= dt;
        if (K.greet <= 0) {
            K.greet = 0;
            say(w, a, def.keeper.welcome, pl.id);
            K.cool = 6;
        }
    }
    if (K.attend > 0) {
        K.attend -= dt;
        a.facing = faceTo(pl.x - a.x, pl.y - a.y);
        return;
    }
    const waiting = w.actors.some((b) => (0, folk_2.isFolk)(b) && b.area === a.area && b.life.spot === "customer");
    switch (K.state) {
        case "tend": {
            a.facing = "down";
            if (K.cool <= 0) {
                // a word to whoever comes through the door
                const door = (0, folk_2.spotById)(area, "door");
                const c = door && w.actors.find((b) => (0, folk_2.isFolk)(b) && b.area === a.area && b.life.act === "shop" && b.life.state === "walk" && Math.hypot(b.x - door.x, b.y - door.y) < 34);
                if (c) {
                    say(w, a, def.keeper.hello, c.id);
                    K.cool = 18 + R(4) * 12;
                }
            }
            K.t -= dt;
            if (K.t > 0)
                break;
            const tidy = (area.base.spots ?? []).filter((s) => s.kind === "tidy");
            if (waiting || !tidy.length) {
                K.t = 3;
                break;
            }
            const s = tidy[Math.floor(R(5) * tidy.length)];
            K.goal = { x: s.x, y: s.y };
            K.state = "tidy";
            K.t = 2.5 + R(6) * 3;
            break;
        }
        case "tidy": {
            // someone is at the counter: leave the shelf and serve
            if (waiting) {
                K.state = "back";
                break;
            }
            if (!K.goal || moveToward(a, K.goal, dt)) {
                a.facing = "up";
                K.t -= dt;
                if (K.t <= 0)
                    K.state = "back";
            }
            break;
        }
        case "back":
            if (moveToward(a, home, dt)) {
                K.state = "tend";
                K.goal = null;
                a.facing = "down";
                K.t = 9 + R(7) * 14;
            }
            break;
    }
}
/** The `keeperTalk` effect (RULES.keeper): the keeper turns to the golem and says one of the shop's placeholder lines. */
function keeperTalk(w, by, targetId) {
    const a = targetId ? (0, world_1.actorById)(w, targetId) : undefined;
    if (!a || !(0, exports.isKeeper)(a) || a.area !== by.area || !(0, exports.keeperPresent)(a))
        return;
    const K = a.keeper, lines = shops_1.SHOPS[K.shop].keeper.greet;
    const line = lines[Math.floor((0, daycycle_1.hash01)(`${w.seed}:${a.id}`, 5000 + K.talks++) * lines.length)];
    K.attend = 3.6;
    K.greet = 0;
    a.facing = faceTo(by.x - a.x, by.y - a.y);
    (0, world_1.emit)(w, { t: "talkedTo", actor: by.id, npc: a.id });
    (0, world_1.emit)(w, { t: "folkSpoke", actor: by.id, folk: a.id, line });
}
void folk_1.TRAITS;
