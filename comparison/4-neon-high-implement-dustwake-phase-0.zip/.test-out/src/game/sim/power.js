"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CORE_TEXT = exports.canManage = exports.coreSeated = void 0;
exports.coreCheck = coreCheck;
exports.insertPowerCore = insertPowerCore;
exports.removePowerCore = removePowerCore;
exports.coreActionFor = coreActionFor;
exports.applySlotCore = applySlotCore;
const actors_1 = require("../content/actors");
const flags_1 = require("../content/flags");
const power_1 = require("../content/power");
const world_1 = require("../world/world");
const inventory_1 = require("./inventory");
const actorStats_1 = require("./actorStats");
const navigation_1 = require("./navigation");
const messages_1 = require("./messages");
/** Has this body ever had a core in it? (a flag on the world, set by the slot seam below) */
const coreSeated = (w, a) => w.flags.has((0, flags_1.npcFlag)(a.id, flags_1.CORE_SEATED));
exports.coreSeated = coreSeated;
/**
 * May the player open this body's management screen? A body that needs power stays shut (it is dormant:
 * E only makes the golem think about it) until a core has first been slotted in. After that the screen
 * opens even with the core taken out again. A body that needs no power is never locked.
 */
const canManage = (w, a) => !(0, actors_1.actorDef)(a).power || !!a.powerCore || (0, exports.coreSeated)(w, a);
exports.canManage = canManage;
function coreCheck(a, item) {
    const core = power_1.POWER_CORES[item], req = (0, actors_1.actorDef)(a).power;
    const accepts = !!core && !!req && core.family === req.family;
    return { accepts, sufficient: accepts && core.tier >= req.tier };
}
/** Insertion is allowed even when the tier is insufficient (the guardian).
 * Work remains unpowered. A replacement returns the previous core, never eats it. */
function insertPowerCore(w, source, target, item) {
    if (source.area !== target.area || Math.hypot(source.x - target.x, source.y - target.y) > (0, actors_1.actorDef)(target).body.reach + 8)
        return false;
    if (!(0, navigation_1.lineOfSight)((0, world_1.areaOf)(w, source), source, target))
        return false;
    if (!coreCheck(target, item).accepts || (0, inventory_1.countItem)(source, item) < 1)
        return false;
    const old = target.powerCore;
    (0, inventory_1.removeItems)(source, item);
    target.powerCore = item;
    w.flags.add((0, flags_1.npcFlag)(target.id, flags_1.CORE_SEATED));
    if (old)
        (0, inventory_1.giveItem)(w, source, old);
    (0, world_1.emit)(w, { t: "powerChanged", actor: target.id, powered: (0, actorStats_1.powered)(target) });
    return true;
}
function removePowerCore(w, source, target) {
    if (!target.powerCore || source.area !== target.area || Math.hypot(source.x - target.x, source.y - target.y) > (0, actors_1.actorDef)(target).body.reach + 8)
        return false;
    if (!(0, navigation_1.lineOfSight)((0, world_1.areaOf)(w, source), source, target))
        return false;
    const old = target.powerCore;
    target.powerCore = null;
    w.flags.add((0, flags_1.npcFlag)(target.id, flags_1.CORE_SEATED));
    (0, inventory_1.giveItem)(w, source, old);
    (0, world_1.emit)(w, { t: "powerChanged", actor: target.id, powered: (0, actorStats_1.powered)(target) });
    return true;
}
function coreActionFor(a, target) {
    if (!(0, actors_1.actorDef)(target).power)
        return { op: "none", reason: "noSocket" };
    if (target.powerCore)
        return { op: "remove", item: target.powerCore };
    const slot = a.inventory.find((s) => !!s && coreCheck(target, s.item).accepts);
    return slot ? { op: "insert", item: slot.item } : { op: "none", reason: "noCore" };
}
exports.CORE_TEXT = {
    reach: "STEP UP TO IT TO REACH ITS CORE",
    noCore: "YOU CARRY NO CORE THAT FITS IT",
    empty: "IT HOLDS NO CORE",
};
/**
 * The `slotCore` effect, when the reach lands: insert `item` (or remove the
 * core with null), re-validated by insertPowerCore / removePowerCore (reach,
 * sight, fit, the item still carried). On success emits `coreSlotted`, the
 * player's event (powerChanged belongs to the body), with the body's power after.
 */
function applySlotCore(w, a, target, item) {
    if (!target)
        return false;
    const old = target.powerCore;
    if (!item && !old) {
        (0, messages_1.actorMessage)(w, a, exports.CORE_TEXT.empty);
        return false;
    }
    const ok = item ? insertPowerCore(w, a, target, item) : removePowerCore(w, a, target);
    if (!ok) {
        (0, messages_1.actorMessage)(w, a, item && (0, inventory_1.countItem)(a, item) < 1 ? exports.CORE_TEXT.noCore : exports.CORE_TEXT.reach);
        return false;
    }
    (0, world_1.emit)(w, { t: "coreSlotted", actor: a.id, target: target.id, item: item ?? old, inserted: !!item, powered: (0, actorStats_1.powered)(target) });
    return true;
}
