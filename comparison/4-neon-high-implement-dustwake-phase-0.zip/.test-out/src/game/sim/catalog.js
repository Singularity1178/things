"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normSearch = exports.TAB_FAV = exports.TAB_ALL = exports.SORT_NAMES = exports.SORT_KEYS = void 0;
exports.entryFor = entryFor;
exports.catalogEntries = catalogEntries;
exports.matchesSearch = matchesSearch;
exports.matchesTab = matchesTab;
exports.sortEntries = sortEntries;
exports.queryCatalog = queryCatalog;
exports.entryReason = entryReason;
// Build catalog queries: per-entry status (can build / missing materials /
// unknown recipe), plus pure search, filter and sort over entries. No DOM; the
// build menu renders whatever `queryCatalog` returns, and tests drive these
// functions directly with synthetic catalogs of any size.
const build_1 = require("../content/build");
const items_1 = require("../content/items");
const inventory_1 = require("./inventory");
const analysis_1 = require("./analysis");
exports.SORT_KEYS = ["category", "name", "cost"];
exports.SORT_NAMES = { category: "TYPE", name: "NAME", cost: "COST" };
/** Pseudo-tabs before the real categories. */
exports.TAB_ALL = "all";
exports.TAB_FAV = "fav";
/** Status of one recipe for an actor. Hidden-until-known recipes return null. */
function entryFor(w, a, id, r = build_1.RECIPES[id]) {
    const lock = (0, analysis_1.planLock)(w, a, r);
    if (lock && r.unknown === "hidden")
        return null;
    const lines = r.cost.map((c) => ({ item: c.item, need: c.n, have: (0, inventory_1.countItem)(a, c.item) }));
    const status = lock ? "unknown" : lines.every((l) => l.have >= l.need) ? "ok" : "cost";
    return lock ? { id, recipe: r, status, lock, lines } : { id, recipe: r, status, lines };
}
/** Every listable entry of a recipe table (default: RECIPES) for an actor. */
function catalogEntries(w, a, recipes = build_1.RECIPES) {
    const out = [];
    for (const id of Object.keys(recipes)) {
        const e = entryFor(w, a, id, recipes[id]);
        if (e)
            out.push(e);
    }
    return out;
}
/** Normalise typed text the way names are written (uppercase, single spaces). */
const normSearch = (s) => s.toUpperCase().replace(/\s+/g, " ").trim();
exports.normSearch = normSearch;
/**
 * Search: every word of the query must appear in the entry's name, category
 * name or one of its material names ("STONE" finds everything that costs stone).
 */
function matchesSearch(e, search) {
    const q = (0, exports.normSearch)(search);
    if (!q)
        return true;
    const hay = [e.recipe.name, (0, build_1.categoryName)(e.recipe.category), ...e.recipe.cost.map((c) => items_1.ITEM_NAMES[c.item] ?? c.item)].join(" ").toUpperCase();
    return q.split(" ").every((word) => hay.includes(word));
}
function matchesTab(e, tab, favorites) {
    if (tab === exports.TAB_ALL)
        return true;
    if (tab === exports.TAB_FAV)
        return favorites.has(e.id);
    return e.recipe.category === tab;
}
const byName = (a, b) => (a.recipe.name < b.recipe.name ? -1 : a.recipe.name > b.recipe.name ? 1 : 0);
const byCategory = (a, b) => (0, build_1.categoryIndex)(a.recipe.category) - (0, build_1.categoryIndex)(b.recipe.category) || (a.recipe.order ?? 0) - (b.recipe.order ?? 0) || byName(a, b);
/** Stable sort; ties always fall back to name, then id, so the order is total. */
function sortEntries(list, sort) {
    const cmp = sort === "name" ? byName : sort === "cost" ? (a, b) => (0, build_1.costTotal)(a.recipe) - (0, build_1.costTotal)(b.recipe) || byName(a, b) : byCategory;
    return [...list].sort((a, b) => cmp(a, b) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
}
/** Tab, search and affordability filters, then sort. */
function queryCatalog(entries, q) {
    const kept = entries.filter((e) => matchesTab(e, q.tab, q.favorites) && matchesSearch(e, q.search) && (!q.affordableOnly || e.status === "ok"));
    return sortEntries(kept, q.sort);
}
/** Why an entry can't be built, for the detail panel's status line ("" if it can). At most 36 characters. */
function entryReason(e) {
    // Known how to build, plan not read yet: say what to scan, and that vision is Z.
    if (e.status === "unknown" && e.lock === "analysis")
        return `SCAN ${(0, build_1.scanHint)(e.recipe)} IN VISION (Z)`;
    if (e.status === "unknown")
        return "UNKNOWN RECIPE - NOT YET LEARNED";
    if (e.status === "cost") {
        const miss = e.lines.filter((l) => l.have < l.need).map((l) => `${l.need - l.have} ${items_1.ITEM_NAMES[l.item]}`);
        return `NEED ${miss.join(" + ")} MORE`;
    }
    return "";
}
