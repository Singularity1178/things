"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.beginTask = beginTask;
exports.enqueueTask = enqueueTask;
exports.tickTask = tickTask;
exports.strikePoint = strikePoint;
exports.slamReach = slamReach;
exports.faceTo = faceTo;
exports.schedule = schedule;
exports.runScheduled = runScheduled;
exports.applyEffect = applyEffect;
// Performing work. An actor holds one current Task and a queue. Each tick the
// task advances; at its fire point its Effect is applied to the world. This is
// the single path by which interactions change the world, for any actor.
const folk_1 = require("./folk");
const shops_1 = require("./shops");
const tiles_1 = require("../content/tiles");
const items_1 = require("../content/items");
const props_1 = require("../content/props");
const harvest_1 = require("../content/harvest");
const vision_1 = require("../content/vision");
const tasks_1 = require("../content/tasks");
const interactions_1 = require("../content/interactions");
const requirements_1 = require("./requirements");
const world_1 = require("../world/world");
const ritual_1 = require("./ritual");
const inventory_1 = require("./inventory");
const runes_1 = require("./runes");
const build_1 = require("./build");
const collision_1 = require("./collision");
const dialogue_1 = require("./dialogue");
const gear_1 = require("./gear");
const crafting_1 = require("./crafting");
const actorStats_1 = require("./actorStats");
const harvesting_1 = require("./harvesting");
const actors_1 = require("../content/actors");
const analysis_1 = require("./analysis");
const storage_1 = require("./storage");
const messages_1 = require("./messages");
const navigation_1 = require("./navigation");
const monologue_1 = require("./monologue");
const power_1 = require("./power");
const digging_1 = require("./digging");
/** Vision mode ends by itself when work starts that takes the golem's attention elsewhere (talking, rune travel, stations...). */
function endScanFor(a, spec) {
    if (a.mode === "scan" && spec.effect && vision_1.VISION_OFF_OPS.includes(spec.effect.op))
        a.mode = "normal";
}
function beginTask(a, spec, target) {
    a.task = { ...spec, t: 0, fired: false, target, area: a.area };
    a.vx = 0;
    a.vy = 0;
    endScanFor(a, spec);
}
/** Add work to the actor's queue; it starts when the current task finishes. */
function enqueueTask(a, spec, target) {
    a.queue.push({ ...spec, t: 0, fired: false, target, area: a.area });
}
/** Advance the actor's work by dt. */
function tickTask(w, a, dt) {
    if (!a.task && a.queue.length) {
        a.task = a.queue.shift();
        a.vx = 0;
        a.vy = 0;
        endScanFor(a, a.task);
    }
    const task = a.task;
    if (!task)
        return;
    if (task.jobId !== undefined && (!(0, actorStats_1.powered)(a) || a.job?.status === "paused"))
        return;
    // Work is bound to the area it was started in; never let it fire elsewhere.
    if (task.area && task.area !== a.area) {
        a.task = null;
        return;
    }
    task.t += dt;
    (0, world_1.emit)(w, { t: "taskTick", actor: a.id, task, dt });
    if (!task.fired && task.t >= tasks_1.TASK_KINDS[task.kind].fire(task.dur)) {
        task.fired = true;
        const ok = task.effect ? applyEffect(w, a, task.effect, task.target) : true;
        if (task.jobId !== undefined && a.job?.id === task.jobId)
            a.job.result = ok !== false;
    }
    // An effect may have replaced the task (e.g. picking up the arm begins attaching it).
    if (task.t >= task.dur && a.task === task)
        a.task = null;
}
/** Where a slam's fists meet the ground: just in front of the actor. */
function strikePoint(a) {
    const fx = a.facing === "left" ? -1 : a.facing === "right" ? 1 : 0;
    const fy = a.facing === "up" ? -1 : a.facing === "down" ? 1 : 0;
    return { x: a.x + fx * 10, y: a.y + (fy > 0 ? 3 : fy < 0 ? -7 : 0) };
}
/**
 * The slammable tiles a blow at (x, y) reaches: any tile with SLAM_RULES that
 * has some part of it within `radius` of the blow (so a wall the fists land in,
 * or just beside, is hit, but the golem's own position is irrelevant). Runs of
 * tiles that act as one thing (anchorTopOfRun, like the cracked wall) count
 * once, as the same anchored target an interaction would carry. Nearest first.
 */
function slamReach(area, x, y, radius) {
    const found = new Map();
    const tx0 = Math.floor((x - radius) / tiles_1.TS), tx1 = Math.floor((x + radius) / tiles_1.TS);
    const ty0 = Math.floor((y - radius) / tiles_1.TS), ty1 = Math.floor((y + radius) / tiles_1.TS);
    for (let ty = ty0; ty <= ty1; ty++)
        for (let tx = tx0; tx <= tx1; tx++) {
            const tile = area.tile(tx, ty), def = tiles_1.TILE_INTERACT[tile];
            if (!def || !interactions_1.SLAM_RULES[def.kind])
                continue;
            // Distance from the blow to the nearest point of this tile's square.
            const dx = Math.max(tx * tiles_1.TS - x, 0, x - (tx + 1) * tiles_1.TS), dy = Math.max(ty * tiles_1.TS - y, 0, y - (ty + 1) * tiles_1.TS);
            const d2 = dx * dx + dy * dy;
            if (d2 > radius * radius)
                continue;
            let ay = ty;
            if (def.anchorTopOfRun)
                while (area.tile(tx, ay - 1) === tile)
                    ay--;
            const key = `${tx},${ay}`, prev = found.get(key);
            if (!prev)
                found.set(key, { target: { kind: def.kind, x: tx * tiles_1.TS + def.dx, y: ay * tiles_1.TS + def.dy, tx, ty: ay }, d2 });
            else if (d2 < prev.d2)
                prev.d2 = d2;
        }
    return [...found.values()].sort((p, q) => p.d2 - q.d2).map((f) => f.target);
}
function faceTo(a, x, y) {
    const dx = x - a.x, dy = y - (a.y - 4);
    a.facing = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? "right" : "left") : dy > 0 ? "down" : "up";
}
/**
 * Run an effect after `delay` seconds of simulation time. It applies in the
 * area it was scheduled from (default: the actor's area now), even if the
 * actor has since travelled.
 */
function schedule(w, delay, actor, effect, area = actor.area) {
    w.scheduled.push({ at: w.time + delay, actor: actor.id, area, effect });
}
/** Fire scheduled effects that are due. */
function runScheduled(w) {
    if (!w.scheduled.length)
        return;
    const due = w.scheduled.filter((s) => s.at <= w.time);
    if (!due.length)
        return;
    w.scheduled = w.scheduled.filter((s) => s.at > w.time);
    for (const s of due) {
        const a = (0, world_1.actorById)(w, s.actor);
        if (a)
            applyEffect(w, a, s.effect, undefined, s.area);
    }
}
/** Apply one effect. `areaId` overrides the area it acts on (scheduled effects). */
function applyEffect(w, a, e, target, areaId) {
    const area = areaId ? (0, world_1.getArea)(w, areaId) : (0, world_1.areaOf)(w, a);
    switch (e.op) {
        case "cue":
            (0, world_1.emit)(w, { t: "cue", cue: e.cue, x: target?.x ?? a.x, y: target?.y ?? a.y, actor: a.id });
            break;
        case "message":
            (0, messages_1.actorMessage)(w, a, e.text);
            if (e.cue)
                (0, world_1.emit)(w, { t: "cue", cue: e.cue, x: target?.x ?? a.x, y: target?.y ?? a.y, actor: a.id });
            break;
        case "examine": {
            const p = target?.propId ? area.prop(target.propId) : undefined;
            const text = p && (0, props_1.propDef)(p.kind).examine;
            if (text)
                (0, world_1.emit)(w, { t: "message", text });
            break;
        }
        case "takeLoose": {
            const l = target?.looseId ? area.looseItem(target.looseId) : undefined;
            if (!l || l.taken)
                break;
            const def = items_1.ITEMS[l.item];
            if (def.equip) {
                area.takeLoose(l.id);
                (0, world_1.emit)(w, { t: "itemGained", actor: a.id, item: l.item, stored: false });
                beginTask(a, { kind: def.equip.task.kind, dur: def.equip.task.dur, effect: { op: "equip", item: l.item } });
                break;
            }
            const n = l.n ?? 1;
            const left = (0, inventory_1.addItems)(w, a, l.item, n);
            if (left === n) {
                (0, world_1.emit)(w, { t: "packFull", actor: a.id, item: l.item });
                break;
            }
            area.setLooseCount(l.id, left);
            (0, world_1.emit)(w, { t: "itemGained", actor: a.id, item: l.item, stored: true, n: n - left });
            if (left > 0)
                (0, world_1.emit)(w, { t: "packFull", actor: a.id, item: l.item });
            break;
        }
        case "takePropItem": {
            const p = target?.propId ? area.prop(target.propId) : undefined;
            if (!p || p.taken || !p.item)
                break;
            const def = items_1.ITEMS[p.item];
            if (def.equip) {
                area.setPropState(p.id, { taken: true });
                (0, world_1.emit)(w, { t: "itemGained", actor: a.id, item: p.item, stored: false });
                beginTask(a, { kind: def.equip.task.kind, dur: def.equip.task.dur, effect: { op: "equip", item: p.item } });
                break;
            }
            // Full pack: leave it where it is rather than dropping it on the floor.
            if ((0, inventory_1.addItems)(w, a, p.item, 1) > 0) {
                (0, world_1.emit)(w, { t: "packFull", actor: a.id, item: p.item });
                break;
            }
            area.setPropState(p.id, { taken: true });
            (0, world_1.emit)(w, { t: "itemGained", actor: a.id, item: p.item, stored: true, n: 1 });
            break;
        }
        case "openContainer": {
            const p = target?.propId ? area.prop(target.propId) : undefined;
            if (!p || p.open)
                break;
            const item = p.item;
            area.setPropState(p.id, { open: true, item: null });
            (0, world_1.emit)(w, { t: "containerOpened", x: p.x, y: p.y });
            if (item)
                schedule(w, 0.25, a, { op: "grantItem", item }, area.id);
            break;
        }
        case "grantItem":
            (0, inventory_1.giveItem)(w, a, e.item, 1);
            break;
        case "equip": {
            const def = items_1.ITEMS[e.item];
            if (def.equip)
                (0, world_1.setActorFlag)(a, def.equip.flag);
            (0, world_1.emit)(w, { t: "equipped", actor: a.id, item: e.item });
            break;
        }
        case "unlockTile": {
            if (target?.tx === undefined || target.ty === undefined)
                break;
            const def = tiles_1.TILE_INTERACT[area.tile(target.tx, target.ty)];
            if (e.consume)
                (0, inventory_1.removeItems)(a, e.consume, 1);
            area.setTile(target.tx, target.ty, tiles_1.T.FLOOR);
            if (def?.openDecal)
                area.addDecal({ kind: def.openDecal.kind, x: target.tx * tiles_1.TS + def.openDecal.dx, y: target.ty * tiles_1.TS + def.openDecal.dy, v: 0 });
            (0, world_1.emit)(w, { t: "doorUnlocked", x: target.x, y: target.y });
            break;
        }
        case "breakTile":
            if (target?.tx !== undefined && target.ty !== undefined)
                breakTileRun(w, area, target);
            break;
        case "placeCore": {
            const r = area.ritual;
            if (!r)
                break;
            (0, inventory_1.removeItems)(a, e.consume, 1);
            area.updateRitual({ core: true });
            (0, world_1.emit)(w, { t: "corePlaced" });
            (0, ritual_1.checkRune)(w, area);
            break;
        }
        case "carveGap": {
            const r = area.ritual;
            if (!r)
                break;
            area.updateRitual({ carved: true });
            (0, world_1.emit)(w, { t: "carved" });
            (0, ritual_1.checkRune)(w, area);
            break;
        }
        case "takeGlyph": {
            const r = area.ritual;
            const i = target?.socket;
            if (!r || i === undefined || r.sockets[i] < 0)
                break;
            const g = r.sockets[i];
            const sockets = [...r.sockets], wrong = [...r.wrong];
            sockets[i] = -1;
            wrong[i] = false;
            area.updateRitual({ sockets, wrong });
            (0, inventory_1.giveItem)(w, a, (0, items_1.glyphItem)(g), 1);
            if (r.active)
                (0, ritual_1.deactivate)(w, area);
            break;
        }
        case "checkRune":
            (0, ritual_1.checkRune)(w, area);
            break;
        case "drop": {
            const s = a.inventory[e.slot];
            if (!s)
                break;
            if (!(0, items_1.isDroppable)(s.item)) {
                (0, world_1.emit)(w, { t: "message", text: "THAT IS TOO IMPORTANT TO DROP" });
                break;
            }
            const spot = (0, inventory_1.dropSpot)(area, a, (0, collision_1.actorBoxes)(w, area.id, a.id));
            if (!spot) {
                (0, world_1.emit)(w, { t: "message", text: "NO ROOM TO DROP IT HERE" });
                break;
            }
            const n = Math.min(e.n, s.n), item = s.item;
            s.n -= n;
            if (s.n === 0)
                a.inventory[e.slot] = null;
            (0, inventory_1.spawnLoose)(area, item, n, spot.x, spot.y);
            (0, world_1.emit)(w, { t: "itemDropped", actor: a.id, item, n, x: spot.x, y: spot.y, reason: "drop" });
            break;
        }
        case "wear": {
            const r = (0, gear_1.applyWear)(w, a, e.slot, e.into);
            if (!r.ok && r.reason !== "empty")
                (0, world_1.emit)(w, { t: "message", text: (0, gear_1.gearRefusal)(r) });
            break;
        }
        case "takeOff": {
            const r = (0, gear_1.applyTakeOff)(w, a, e.gear);
            if (!r.ok && r.reason !== "empty")
                (0, world_1.emit)(w, { t: "message", text: (0, gear_1.gearRefusal)(r) });
            break;
        }
        case "slam": {
            // The blow lands: both fists into the ground in front of the actor, and
            // everything slammable within SLAM_RADIUS of the fists (not of the actor)
            // takes it. Targets are looked up now, in the world as it is at impact.
            // Harvestables (trees, rocks, logs) are slammable too: each one in reach
            // takes one blow of work and pays out, however many there are.
            const p = strikePoint(a);
            const hits = slamReach(area, p.x, p.y, tasks_1.SLAM_RADIUS)
                .map((t) => ({ t, rule: interactions_1.SLAM_RULES[t.kind].find((r) => (0, requirements_1.meets)(w, a, r.when)) }))
                .filter((h) => h.rule);
            const harvestables = (0, harvesting_1.harvestReach)(area, p.x, p.y, tasks_1.SLAM_RADIUS);
            (0, world_1.emit)(w, { t: "slam", actor: a.id, x: p.x, y: p.y, hit: hits.length > 0 || harvestables.length > 0 });
            for (const h of hits)
                applyEffect(w, a, h.rule.then, h.t);
            for (const hp of harvestables)
                harvestProp(w, a, area, hp);
            break;
        }
        case "withstand":
            // The target takes the blow and holds: nothing in the world changes.
            (0, world_1.emit)(w, { t: "withstood", actor: a.id, x: target?.x ?? a.x, y: target?.y ?? a.y, tx: target?.tx, ty: target?.ty });
            if (e.text)
                (0, world_1.emit)(w, { t: "message", text: e.text });
            break;
        case "travel":
            return !!target?.propId && (0, runes_1.travel)(w, a, area, target.propId, e.destination);
        case "analyze": return (0, analysis_1.applyAnalysis)(w, a, area, target);
        case "deposit": {
            const p = target?.propId ? area.prop(target.propId) : undefined;
            if (!p?.inventory || a.area !== area.id || Math.hypot(a.x - p.x, a.y - p.y) > (0, props_1.propReach)(p.kind) + 8)
                return false;
            const n = (0, storage_1.transferItems)(w, (0, storage_1.packRef)(a), (0, storage_1.storageRef)(area.id, p.id), e.item, e.n);
            if (a.job && a.task?.jobId === a.job.id)
                a.job.completed += n;
            return n > 0;
        }
        case "useStorage":
            if (target?.propId && area.prop(target.propId)?.inventory)
                (0, world_1.emit)(w, { t: "openStorage", actor: a.id, prop: target.propId });
            break;
        case "manageActor":
            if (target?.actorId) {
                const body = (0, world_1.actorById)(w, target.actorId);
                // A dormant body (never had a core) has no screen to open: the golem only notes it (content/monologue.ts).
                if (body)
                    (0, world_1.emit)(w, { t: (0, power_1.canManage)(w, body) ? "manageActor" : "dormantTouched", actor: a.id, target: body.id });
            }
            break;
        case "slotCore":
            return (0, power_1.applySlotCore)(w, a, target?.actorId ? (0, world_1.actorById)(w, target.actorId) : undefined, e.item);
        case "harvest": {
            // A worker's blow at a chosen prop (jobs). The golem's own harvesting is the slam, which finds props itself.
            const p = target?.propId ? area.prop(target.propId) : undefined;
            if (!p || Math.hypot(p.x - a.x, p.y - a.y) > (0, props_1.propReach)(p.kind) + 8 || !(0, navigation_1.lineOfSight)(area, a, p))
                return false;
            // An order that keeps what it gathers (no storage: sim/jobs.ts) counts it here, where the blow pays out, as a
            // deposit is counted where it lands: a save between the blow and the end of the swing never counts it twice.
            // Only what reached the pack counts, and never past the amount asked for.
            const job = a.job && a.task?.jobId === a.job.id && a.job.kind === "gatherDeposit" && a.job.args.storage === null ? a.job : null;
            const want = job ? job.args.resource : null, before = want ? (0, inventory_1.countItem)(a, want) : 0;
            const ok = harvestProp(w, a, area, p);
            if (job && want)
                job.completed = Math.min(job.args.repeat === true ? Infinity : Number(job.args.amount), job.completed + Math.max(0, (0, inventory_1.countItem)(a, want) - before));
            return ok;
        }
        case "dig":
            return (0, digging_1.applyDig)(w, a, area, target);
        case "regrow":
            area.setPropState(e.prop, { taken: false, dmg: 0 });
            break;
        case "build":
            (0, build_1.applyBuild)(w, a, area, e.recipe, e.tx, e.ty);
            break;
        case "deconstruct":
            (0, build_1.applyDeconstruct)(w, a, area, target?.propId);
            break;
        case "craft":
            return (0, crafting_1.applyCraft)(w, a, area, e.recipe, target?.propId);
        case "useStation": {
            const p = target?.propId ? area.prop(target.propId) : undefined;
            const station = p && (0, props_1.propDef)(p.kind).station;
            if (p && station)
                (0, world_1.emit)(w, { t: "openStation", actor: a.id, prop: p.id, station });
            break;
        }
        case "learn":
            if (!(0, world_1.hasFlag)(w, e.flag)) {
                (0, world_1.setFlag)(w, e.flag);
                (0, world_1.emit)(w, { t: "learned", flag: e.flag });
            }
            break;
        case "think":
            return (0, monologue_1.think)(w, a, e.line, { target });
        case "folkTalk":
            (0, folk_1.folkTalk)(w, a, target?.actorId);
            break;
        case "keeperTalk":
            (0, shops_1.keeperTalk)(w, a, target?.actorId);
            break;
        case "talk":
        case "npcAwake":
        case "repairEye":
        case "npcGive":
        case "segmentDone":
            (0, dialogue_1.applyDialogueEffect)(w, a, e, target);
            break;
    }
}
/**
 * One blow of work against a harvestable prop, by any actor: stores the damage
 * on the prop, pays for the cumulative work crossed, and depletes it. Reach is
 * the caller's business (a worker's job, or the slam's radius). False when
 * nothing came of it (not harvestable, already depleted, or the actor can't).
 */
function harvestProp(w, a, area, p) {
    const def = harvest_1.HARVEST[p.kind];
    if (!def || p.taken || !(0, actors_1.capable)(a, "harvest"))
        return false;
    const hit = (0, harvesting_1.harvestStep)(a, p);
    if (!hit)
        return false;
    area.damageProp(p.id, hit.damage);
    // Pay for cumulative work crossed, not the number of blows. Fractional,
    // mixed-actor and overkill hits conserve the original total yield.
    for (const reward of hit.rewards)
        (0, inventory_1.giveItem)(w, a, reward.item, reward.n);
    if (hit.depleted) {
        area.setPropState(p.id, { taken: true });
        if (def.regrow)
            schedule(w, def.regrow, a, { op: "regrow", prop: p.id }, area.id);
    }
    (0, world_1.emit)(w, { t: "harvestHit", actor: a.id, prop: p.id, kind: p.kind, x: p.x, y: p.y, depleted: hit.depleted });
    return true;
}
/** Clear a vertical run of breakable tiles starting at the anchor and scatter debris. */
function breakTileRun(w, area, target) {
    const tx = target.tx, ty = target.ty;
    const t0 = area.tile(tx, ty);
    const def = tiles_1.TILE_INTERACT[t0];
    for (let y = ty; area.tile(tx, y) === t0; y++)
        area.setTile(tx, y, tiles_1.T.FLOOR);
    const d = def?.breakDebris;
    if (d) {
        for (let i = 0; i < d.count; i++)
            area.addDecal({ kind: "debris", x: (tx + d.dxTiles) * tiles_1.TS + w.rng.next() * d.w, y: (ty + d.dyTiles) * tiles_1.TS + w.rng.next() * d.h, v: (w.rng.next() * 4) | 0 });
    }
    (0, world_1.emit)(w, { t: "wallBroken", x: target.x, y: target.y });
}
