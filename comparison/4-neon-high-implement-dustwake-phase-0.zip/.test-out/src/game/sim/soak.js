"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.totalWorldItems = totalWorldItems;
exports.buildSoakWorld = buildSoakWorld;
exports.runSoak = runSoak;
// Headless Soak-Test Harness (Phase 0.8 & 0.2 frame budget).
// Pure (no DOM). Spawns M residents across authored + generated areas, steps N
// in-game days at fixed timestep with simulation LOD enabled, and asserts:
//   1. No actor stuck for more than `maxStuckSeconds`
//   2. No item duplicated or deleted (exact item conservation)
//   3. No exclusive place held by two actors simultaneously
//   4. Save/load round-trip equals the live serialized state
//   5. Average and p95 simulation step time stay within `frameBudgetMs`
const daycycle_1 = require("../content/daycycle");
const folk_1 = require("../content/folk");
const world_1 = require("../world/world");
const save_1 = require("../world/save");
const folk_2 = require("./folk");
const step_1 = require("./step");
const lod_1 = require("./lod");
const clock_1 = require("./clock");
/** Count every item in the world across inventories, worn gear, storage props, and loose ground stacks. */
function totalWorldItems(w) {
    const totals = new Map();
    const add = (item, n) => totals.set(item, (totals.get(item) ?? 0) + n);
    for (const a of w.actors) {
        for (const slot of a.inventory)
            if (slot)
                add(slot.item, slot.n);
        for (const item of Object.values(a.gear))
            if (item)
                add(item, 1);
        if (a.powerCore)
            add(a.powerCore, 1);
    }
    for (const area of w.areas.values()) {
        for (const l of area.loose)
            if (!l.taken)
                add(l.item, l.n ?? 1);
        for (const p of area.props) {
            if (p.taken)
                continue;
            if (p.item && !p.container)
                add(p.item, 1);
            if (p.inventory)
                for (const slot of p.inventory)
                    if (slot)
                        add(slot.item, slot.n);
        }
    }
    return totals;
}
function mapsEqual(a, b) {
    const keys = new Set([...a.keys(), ...b.keys()]);
    for (const k of keys) {
        const va = a.get(k) ?? 0, vb = b.get(k) ?? 0;
        if (va !== vb)
            return `Item "${k}" count drifted: expected ${va}, got ${vb}`;
    }
    return null;
}
/** Populate a soak world with `targetActors` distributed across town, surface, dungeon, and a dynamic floor. */
function buildSoakWorld(targetActors = 300, seed = 4242) {
    const w = (0, world_1.createWorld)(seed);
    // Instantiate primary authored areas, shop interiors, and a dynamic runtime floor
    const town = (0, world_1.getArea)(w, "town");
    const surface = (0, world_1.getArea)(w, "surface");
    const dungeon = (0, world_1.getArea)(w, "dungeon");
    for (const shopId of ["town_tavern", "town_smithy", "town_armory", "town_jeweler", "town_tailor", "town_guild"]) {
        (0, world_1.getArea)(w, shopId);
    }
    const floor1 = (0, world_1.createDynamicArea)(w, { id: "soak_floor_1", kind: "dungeon_floor", depth: 1, parent: "dungeon", seed: seed + 1, w: 36, h: 28 });
    // Place player in Westwake (the busiest area) with a standard 320x180 camera rect
    (0, world_1.enterArea)(w, (0, world_1.player)(w), town.id, town.start.x, town.start.y);
    w.lod = (0, lod_1.createLodConfig)();
    w.lod.view = { x: town.start.x - 160, y: town.start.y - 90, w: 320, h: 180 };
    // Add additional residents up to targetActors across town (Active/Near) and surface/dungeon/floor1 (Far)
    const archIds = Object.keys(folk_1.ARCHETYPES).filter((id) => folk_1.ARCHETYPES[id].habitat === "town");
    const townDoors = (town.base.spots ?? []).filter((s) => s.kind === "door");
    const surfaceBeds = (surface.base.spots ?? []).filter((s) => s.kind === "bed");
    const floorSpots = floor1.base.spots ?? [];
    let extraIdx = 0;
    // ~45 additional townsfolk in Westwake (so town has ~70 folk: Active + Near!)
    // and remaining residents spread across Far areas (surface, dungeon, dynamic floor1)
    while (w.actors.length < targetActors) {
        const n = extraIdx++;
        if (n < 45 && townDoors.length) {
            const door = townDoors[n % townDoors.length];
            const arch = archIds[n % archIds.length];
            const row = { id: `soak.town.${n}`, area: "town", archetype: arch, home: door.id };
            w.actors.push((0, folk_2.makeFolk)(w, row));
        }
        else if (n < 140 && surfaceBeds.length) {
            const bed = surfaceBeds[n % surfaceBeds.length];
            const baseRow = folk_1.CENSUS.find((r) => r.area === "surface");
            const row = { id: `soak.camp.${n}`, area: "surface", archetype: baseRow?.archetype ?? "hunter", home: bed.id };
            w.actors.push((0, folk_2.makeFolk)(w, row));
        }
        else {
            const area = n % 2 === 0 ? floor1 : dungeon;
            const sp = area === floor1 && floorSpots.length ? floorSpots[n % floorSpots.length] : area.start;
            const worker = (0, world_1.makeActor)(`soak.resident.${n}`, "worker_golem", area.id, sp.x, sp.y);
            w.actors.push(worker);
        }
    }
    return w;
}
function runSoak(opts = {}) {
    const targetActors = opts.actors ?? 300;
    const days = opts.days ?? 0.25;
    const tickDt = opts.tickDt ?? clock_1.SIM_DT;
    const seed = opts.seed ?? 4242;
    const maxStuckSeconds = opts.maxStuckSeconds ?? 15;
    const frameBudgetMs = opts.frameBudgetMs ?? 12;
    const checkRoundTrip = opts.checkRoundTrip ?? true;
    const w = buildSoakWorld(targetActors, seed);
    const violations = [];
    // Baseline item conservation snapshot (soak does not harvest/craft)
    const initialItems = totalWorldItems(w);
    const totalSimSeconds = days * daycycle_1.DAY_SECONDS;
    const totalTicks = Math.max(1, Math.round(totalSimSeconds / tickDt));
    const checkEvery = Math.max(1, Math.floor(totalTicks / 40));
    const stuckTrack = new Map();
    const tickTimes = [];
    const town = (0, world_1.getArea)(w, "town");
    for (let tick = 0; tick < totalTicks; tick++) {
        // Slowly pan camera across town so actors transition between Active & Near tiers
        const pan = Math.sin((tick / Math.max(1, totalTicks)) * Math.PI * 2) * 180;
        w.lod.view = {
            x: Math.max(0, Math.min(town.w * 16 - 320, town.start.x - 160 + pan)),
            y: Math.max(0, Math.min(town.h * 16 - 180, town.start.y - 90)),
            w: 320,
            h: 180,
        };
        const t0 = performance.now();
        (0, step_1.stepWorld)(w, tickDt);
        // Drain transient presentation events so memory stays bounded during long soaks
        w.events.length = 0;
        const elapsedMs = performance.now() - t0;
        tickTimes.push(elapsedMs);
        // Periodic invariant checks
        if (tick % checkEvery === 0 || tick === totalTicks - 1) {
            // 1. Exclusive spot collision check (no two actors hold the same exclusive spot in an area)
            const heldByArea = new Map();
            for (const a of w.actors) {
                if (!(0, folk_2.isFolk)(a) || !a.life?.spot || a.life.state === "indoors")
                    continue;
                const area = w.areas.get(a.area);
                const spot = area ? (0, folk_2.spotById)(area, a.life.spot) : undefined;
                if (spot && (0, folk_2.isExclusive)(spot)) {
                    let m = heldByArea.get(a.area);
                    if (!m) {
                        m = new Map();
                        heldByArea.set(a.area, m);
                    }
                    const prev = m.get(a.life.spot);
                    if (prev && prev !== a.id) {
                        violations.push(`Tick ${tick}: exclusive spot "${a.life.spot}" in "${a.area}" held by both ${prev} and ${a.id}`);
                    }
                    else {
                        m.set(a.life.spot, a.id);
                    }
                }
            }
            // 2. Stuck walker check (no walking folk stuck without moving for > maxStuckSeconds)
            const checkDt = checkEvery * tickDt;
            for (const a of w.actors) {
                if (!(0, folk_2.isFolk)(a) || a.area !== town.id)
                    continue;
                if (a.life.state === "walk") {
                    const prev = stuckTrack.get(a.id);
                    if (prev && Math.hypot(a.x - prev.x, a.y - prev.y) < 0.5) {
                        prev.elapsed += checkDt;
                        if (prev.elapsed > maxStuckSeconds) {
                            violations.push(`Tick ${tick}: actor ${a.id} stuck walking at (${Math.round(a.x)},${Math.round(a.y)}) for ${prev.elapsed.toFixed(1)}s`);
                            prev.elapsed = 0; // report once per episode
                        }
                    }
                    else {
                        stuckTrack.set(a.id, { x: a.x, y: a.y, elapsed: 0 });
                    }
                }
                else {
                    stuckTrack.delete(a.id);
                }
            }
        }
    }
    // 3. Item conservation check
    const finalItems = totalWorldItems(w);
    const itemDiff = mapsEqual(initialItems, finalItems);
    if (itemDiff)
        violations.push(itemDiff);
    // 4. Save/load round-trip equality check
    if (checkRoundTrip) {
        const beforeJson = JSON.stringify((0, save_1.serialize)(w));
        const reloaded = (0, save_1.deserialize)(JSON.parse(beforeJson));
        const afterJson = JSON.stringify((0, save_1.serialize)(reloaded));
        if (beforeJson !== afterJson) {
            violations.push("Save/load round-trip mismatch after soak");
        }
    }
    // 5. Frame budget check
    const sorted = [...tickTimes].sort((a, b) => a - b);
    const avgTickMs = tickTimes.reduce((s, x) => s + x, 0) / tickTimes.length;
    const p95TickMs = sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * 0.95))];
    const maxTickMs = sorted[sorted.length - 1];
    if (avgTickMs > frameBudgetMs) {
        violations.push(`Frame budget exceeded: avg ${avgTickMs.toFixed(2)}ms > ${frameBudgetMs}ms for ${w.actors.length} actors`);
    }
    return {
        ok: violations.length === 0,
        actors: w.actors.length,
        ticks: totalTicks,
        simSeconds: totalSimSeconds,
        avgTickMs,
        p95TickMs,
        maxTickMs,
        lodCounts: { ...(w.lod?.counts ?? { active: 0, near: 0, far: 0 }) },
        violations,
    };
}
