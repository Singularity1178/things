"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.activeTools = activeTools;
exports.toolBonus = toolBonus;
// Tools at work (content/tools.ts). Pure sim, and deliberately small: it reads
// only the actor, so requirement checks, harvesting and digging can all use it
// without an import cycle.
//
// A head counts while it is fitted to an arm slot. Gear in a slot that is not
// usable is put back in the pack every world step (sim/gear.ts: reconcileGear),
// so whatever `Actor.gear` holds is in use. A hafted tool counts in the pack of
// a body that can `wield` (the workers); the maintainer fits heads instead.
const items_1 = require("../content/items");
const actors_1 = require("../content/actors");
/** The tools working for `a` right now. */
function activeTools(a) {
    const out = [];
    for (const id of Object.values(a.gear ?? {}))
        if (id && items_1.ITEMS[id]?.tool?.form === "head")
            out.push(id);
    if ((0, actors_1.capable)(a, "wield"))
        for (const s of a.inventory)
            if (s && items_1.ITEMS[s.item]?.tool?.form === "full")
                out.push(s.item);
    return out;
}
/** The best bonus `a` has for a tool type (0: none working). Two of a kind do not add: the better one counts. */
function toolBonus(a, type) {
    if (!type)
        return 0;
    let best = 0;
    for (const id of activeTools(a)) {
        const t = items_1.ITEMS[id].tool;
        if (t.type === type && t.bonus > best)
            best = t.bonus;
    }
    return best;
}
