"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.exposureOf = exports.worldPhase = exports.worldHour = void 0;
exports.stepDay = stepDay;
exports.advanceDay = advanceDay;
exports.advanceDayTo = advanceDayTo;
exports.advanceDayUpTo = advanceDayUpTo;
// The world's calendar clock (sim). `world.day` is days since the world began;
// its fraction is the time of day (content/daycycle.ts has the maths and what
// each hour means). stepWorld advances it with world time, so it stops when
// the world does (overlays, the title) and is saved with it.
//
// The clock only ever runs forward. When it crosses into another part of the
// day a `dayPhase` event is emitted, once, for presentation and the monologue.
const daycycle_1 = require("../content/daycycle");
const world_1 = require("../world/world");
const worldHour = (w) => (0, daycycle_1.hourOf)(w.day);
exports.worldHour = worldHour;
const worldPhase = (w) => (0, daycycle_1.phaseAt)((0, exports.worldHour)(w));
exports.worldPhase = worldPhase;
/** How much of the sky an area sees (content/daycycle.ts: Exposure). */
const exposureOf = (a) => (a.base.outdoor ? "outdoor" : a.base.interior ? "interior" : "buried");
exports.exposureOf = exposureOf;
function setDay(w, day) {
    if (!(day > w.day))
        return;
    const before = (0, daycycle_1.phaseAt)((0, daycycle_1.hourOf)(w.day));
    w.day = day;
    const after = (0, daycycle_1.phaseAt)((0, daycycle_1.hourOf)(day));
    if (after !== before)
        (0, world_1.emit)(w, { t: "dayPhase", phase: after, day: Math.floor(day) });
}
/** Advance the clock by `dt` world seconds (stepWorld). */
function stepDay(w, dt) { setDay(w, w.day + dt / daycycle_1.DAY_SECONDS); }
/** Advance the clock by a number of hours. */
function advanceDay(w, hours) { if (hours > 0)
    setDay(w, w.day + hours / 24); }
/** Advance to the next time the clock reads `hour`: later today, or tomorrow if that hour has passed. */
function advanceDayTo(w, hour) {
    const ahead = (0, daycycle_1.wrapHour)(hour - (0, exports.worldHour)(w));
    if (ahead > 1e-6 && ahead < 24 - 1e-6)
        advanceDay(w, ahead);
}
/**
 * Advance to `hour` only if it is still ahead today (less than `within` hours
 * off). Never back and never round the clock: safe to call every frame with a
 * rising target (a time-lapse), or once to make sure a moment has been reached.
 */
function advanceDayUpTo(w, hour, within = 12) {
    const ahead = (0, daycycle_1.wrapHour)(hour - (0, exports.worldHour)(w));
    if (ahead > 1e-6 && ahead < within)
        advanceDay(w, ahead);
}
