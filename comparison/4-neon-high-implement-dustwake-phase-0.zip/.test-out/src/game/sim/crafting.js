"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.atStation = exports.craftLocked = exports.craftGoneText = exports.craftLockedText = exports.CRAFT_GONE_TEXT = exports.CRAFT_LOCKED_TEXT = exports.CRAFT_TEXT = void 0;
exports.craftReason = craftReason;
exports.craftEntry = craftEntry;
exports.craftEntries = craftEntries;
exports.craftList = craftList;
exports.orderCraft = orderCraft;
exports.applyCraft = applyCraft;
exports.outputFits = outputFits;
// Crafting reads the actor's pack and nearby storage, then commits inputs
// atomically at the task fire point. Tools must stay in the actor's own pack.
//
// The CRAFT button (`orderCraft`) validates and starts a `craft` task. The
// `craft` effect (`applyCraft`) re-validates when it fires (the pack, the bench
// and the knowledge may all have changed in the meantime), then consumes the
// inputs and gives the output through `giveItem`, so a full pack drops the
// overflow on the ground like any pickup. Nothing is ever deleted: a failed
// check changes nothing. Tools (the rune chisel) must be carried, never used up.
// Any actor can run the same task, not just the player.
const crafting_1 = require("../content/crafting");
const items_1 = require("../content/items");
const props_1 = require("../content/props");
const world_1 = require("../world/world");
const requirements_1 = require("./requirements");
const inventory_1 = require("./inventory");
const tasks_1 = require("./tasks");
const storage_1 = require("./storage");
const actors_1 = require("../content/actors");
const actorStats_1 = require("./actorStats");
const props_2 = require("../content/props");
const inventoryOps_1 = require("./inventoryOps");
const discovery_1 = require("./discovery");
const navigation_1 = require("./navigation");
const messages_1 = require("./messages");
exports.CRAFT_TEXT = {
    unknown: "NOT YET LEARNED",
    cost: "NOT ENOUGH MATERIALS",
};
/** Shown when the crafter doesn't know the craft at all (the station opens greyed out). */
exports.CRAFT_LOCKED_TEXT = "YOU DON'T KNOW HOW TO CRAFT YET";
exports.CRAFT_GONE_TEXT = "THE BENCH IS GONE OR TOO FAR AWAY";
/** What a station says while its craft is unknown, and when it has gone: the bench's own lines, or the station's (content/crafting.ts: STATIONS). */
const craftLockedText = (station) => ((0, crafting_1.isStation)(station) ? crafting_1.STATIONS[station].lockedText : exports.CRAFT_LOCKED_TEXT);
exports.craftLockedText = craftLockedText;
const craftGoneText = (station) => ((0, crafting_1.isStation)(station) && station !== "crafting" ? `THE ${crafting_1.STATIONS[station].name} IS GONE OR TOO FAR AWAY` : exports.CRAFT_GONE_TEXT);
exports.craftGoneText = craftGoneText;
const validRecipe = (r) => !!items_1.ITEMS[r.output.item] && Number.isSafeInteger(r.output.n) && r.output.n > 0
    && r.inputs.every((c) => !!items_1.ITEMS[c.item] && Number.isSafeInteger(c.n) && c.n > 0)
    && (r.also ?? []).every((c) => !!items_1.ITEMS[c.item] && Number.isSafeInteger(c.n) && c.n > 0)
    && (r.tools ?? []).every((item) => !!items_1.ITEMS[item] && !r.inputs.some((c) => c.item === item));
/** The reason a recipe can't be made now, for the screen and the message line. */
function craftReason(e) {
    if (e.status === "ok")
        return "";
    if (e.status === "tools")
        return `NEED THE ${e.tools.filter((t) => !t.have).map((t) => items_1.ITEM_NAMES[t.item]).join(" + ")}`;
    return exports.CRAFT_TEXT[e.status];
}
/** True while `a` lacks the knowledge to read a station's plans (see STATION_REQUIRES). */
const craftLocked = (w, a, station) => !(0, requirements_1.meets)(w, a, crafting_1.STATION_REQUIRES[station]);
exports.craftLocked = craftLocked;
/** Status of one recipe for a crafter (knowledge, then tools carried, then materials). */
function craftEntry(w, a, r, station) {
    const sources = (0, storage_1.craftSources)(w, a, station);
    const totals = new Map();
    for (const c of r.inputs)
        totals.set(c.item, (totals.get(c.item) ?? 0) + c.n);
    const lines = [...totals].map(([item, need]) => ({ item, need, have: sources.reduce((s, h) => s + (0, inventory_1.countItem)(h, item), 0) }));
    const tools = (r.tools ?? []).map((item) => ({ item, have: (0, inventory_1.hasItem)(a, item) }));
    const status = !validRecipe(r) || !(0, requirements_1.meets)(w, a, r.requires) ? "unknown" : !tools.every((t) => t.have) ? "tools" : lines.every((l) => l.have >= l.need) ? "ok" : "cost";
    return { recipe: r, status, lines, tools };
}
/** The plans a station shows `a`. Empty while the craft is unknown: nothing is viewable. */
function craftEntries(w, a, station, list = crafting_1.CRAFT_RECIPES, propId) {
    if ((0, exports.craftLocked)(w, a, station))
        return [];
    const p = propId ? w.areas.get(a.area)?.prop(propId) : undefined;
    return (0, crafting_1.craftRecipesFor)(station, list).map((r) => craftEntry(w, a, r, p));
}
/** Is the piece a row works on (CraftRecipe.work) at hand? Rows without one always are. */
const atHand = (e) => !e.recipe.work || (e.lines.find((l) => l.item === e.recipe.work)?.have ?? 0) > 0;
/**
 * What a station's screen lists: its plans, one tab of them if `tab` is given,
 * without the rows whose piece to work on is not at hand (so the anvil's
 * repair, modify and rune tabs show what can be done to the tools brought to it).
 */
function craftList(w, a, station, propId, tab, list = crafting_1.CRAFT_RECIPES) {
    return craftEntries(w, a, station, list, propId).filter((e) => (!tab || e.recipe.tab === tab) && atHand(e));
}
/**
 * The CRAFT button. Validates, then starts the craft task (the effect does the
 * work when it fires). `propId` is the bench in use: the crafter turns to face
 * it, and the effect checks it is still there. Returns whether work started;
 * a refusal says why and changes nothing.
 */
function orderCraft(w, a, station, id, propId, list = crafting_1.CRAFT_RECIPES) {
    // A station-opening reach may be paused beneath its screen after firing.
    const opening = a.task?.fired && a.task.effect?.op === "useStation";
    if ((a.task && !opening) || !(0, actors_1.capable)(a, "craft") || !(0, actorStats_1.powered)(a))
        return false;
    if ((0, exports.craftLocked)(w, a, station)) {
        (0, messages_1.actorMessage)(w, a, (0, exports.craftLockedText)(station));
        return false;
    }
    const r = (0, crafting_1.craftRecipesFor)(station, list).find((x) => x.id === id);
    if (!r)
        return false;
    const p = propId ? w.areas.get(a.area)?.prop(propId) : undefined;
    const e = craftEntry(w, a, r, p);
    if (e.status !== "ok") {
        (0, messages_1.actorMessage)(w, a, craftReason(e));
        return false;
    }
    if (propId && (!p || (0, props_1.propDef)(p.kind).station !== station || !(0, exports.atStation)(a, p) || !(0, navigation_1.lineOfSight)(w.areas.get(a.area), a, p))) {
        (0, messages_1.actorMessage)(w, a, (0, exports.craftGoneText)(station));
        return false;
    }
    if (p)
        (0, tasks_1.faceTo)(a, p.x, p.y - 4);
    (0, tasks_1.beginTask)(a, { kind: "craft", dur: r.dur ?? crafting_1.CRAFT_DUR, effect: { op: "craft", recipe: r.id } }, { kind: "craft", x: p?.x ?? a.x, y: p?.y ?? a.y, propId: p?.id });
    return true;
}
/**
 * The `craft` effect. Re-validates everything (the bench may have been taken
 * apart, the inputs spent, the tool dropped) and applies nothing if any check
 * fails. Otherwise: inputs out, output in (overflow to the ground).
 */
function applyCraft(w, a, area, recipe, propId, list = crafting_1.CRAFT_RECIPES) {
    if (area.id !== a.area || !(0, actors_1.capable)(a, "craft") || !(0, actorStats_1.powered)(a))
        return false;
    const r = list.find((x) => x.id === recipe);
    if (!r)
        return false;
    if (propId) {
        const p = area.prop(propId);
        if (!p || (0, props_1.propDef)(p.kind).station !== r.station || !(0, exports.atStation)(a, p) || !(0, navigation_1.lineOfSight)(area, a, p)) {
            (0, messages_1.actorMessage)(w, a, (0, exports.craftGoneText)(r.station));
            return false;
        }
    }
    if ((0, exports.craftLocked)(w, a, r.station)) {
        (0, messages_1.actorMessage)(w, a, (0, exports.craftLockedText)(r.station));
        return false;
    }
    const p = propId ? area.prop(propId) : undefined;
    const e = craftEntry(w, a, r, p);
    if (e.status !== "ok") {
        (0, messages_1.actorMessage)(w, a, craftReason(e));
        return false;
    }
    if (a.task?.jobId !== undefined && !outputFits(w, a, r))
        return false;
    if (!(0, storage_1.consumeInputs)((0, storage_1.craftSources)(w, a, p), r.inputs))
        return false;
    for (const c of r.inputs)
        (0, discovery_1.rememberItem)(w, a, c.item);
    (0, inventory_1.giveItem)(w, a, r.output.item, r.output.n);
    for (const x of r.also ?? [])
        (0, inventory_1.giveItem)(w, a, x.item, x.n);
    (0, world_1.emit)(w, { t: "crafted", actor: a.id, recipe: r.id, item: r.output.item, n: r.output.n });
    return true;
}
const atStation = (a, p) => Math.hypot(a.x - p.x, a.y - p.y) <= (0, props_2.propReach)(p.kind) + 8;
exports.atStation = atStation;
/** Jobs wait rather than scattering products when their pack is full. Pack
 * ingredients are consumed first, so account for the slots they will free. */
function outputFits(w, a, r) {
    const pack = { inventory: (0, inventoryOps_1.copySlots)(a.inventory) };
    for (const c of r.inputs)
        (0, inventoryOps_1.removeItems)(pack, c.item, Math.min(c.n, (0, inventory_1.countItem)(pack, c.item)));
    return (0, inventoryOps_1.roomIn)(pack.inventory, (0, inventory_1.capacity)(w, a), r.output.item) >= r.output.n;
}
