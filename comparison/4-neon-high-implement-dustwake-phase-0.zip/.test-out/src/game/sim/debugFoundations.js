"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerFoundations = registerFoundations;
exports.foundationDemo = foundationDemo;
const runes_1 = require("../content/runes");
const world_1 = require("../world/world");
const areas_1 = require("../world/areas");
const foundationAreas_1 = require("../world/foundationAreas");
const inventory_1 = require("./inventory");
const power_1 = require("./power");
const jobs_1 = require("./jobs");
/**
 * Registers the two debug areas and their rune link (?debug and tests). The
 * storage chest, ruby and inverse recipes it used to opt into are production
 * rows now (content/build.ts, content/crafting.ts), so nothing here touches a
 * catalog. Idempotent, and performed before loading fixture saves.
 */
function registerFoundations() {
    for (const id of ["debug_yard", "debug_workshop"]) {
        areas_1.AREAS[id] = () => (0, foundationAreas_1.buildFoundationArea)(id);
        runes_1.RUNE_NODES[id] = { id, area: id, prop: `rune.${id}`, flag: `rune.${id}.active`, name: id.toUpperCase(), arrive: { dx: 0, dy: 16, facing: "down" } };
    }
    if (!runes_1.RUNE_LINKS.some((l) => l.a === "debug_yard"))
        runes_1.RUNE_LINKS.push({ a: "debug_yard", b: "debug_workshop" });
}
/** A complete gather/travel/deposit proof, without altering either real area. */
function foundationDemo(seed = 1178) {
    registerFoundations();
    const w = (0, world_1.createWorld)(seed), pl = (0, world_1.player)(w);
    (0, world_1.getArea)(w, "debug_yard");
    (0, world_1.getArea)(w, "debug_workshop");
    (0, world_1.enterArea)(w, pl, "debug_workshop", 136, 139);
    const worker = (0, world_1.makeActor)("debug.worker", "worker_golem", "debug_workshop", 120, 123);
    w.actors.push(worker);
    for (const f of ["know.build", "tutorial.done", "rune.debug_yard.active", "rune.debug_workshop.active"])
        (0, world_1.setFlag)(w, f);
    (0, inventory_1.giveItem)(w, pl, "ruby_core");
    (0, power_1.insertPowerCore)(w, pl, worker, "ruby_core");
    (0, inventory_1.giveItem)(w, pl, "chisel");
    (0, inventory_1.giveItem)(w, pl, "crown");
    (0, inventory_1.giveItem)(w, pl, "planks", 8);
    (0, jobs_1.assignJob)(w, worker, (0, jobs_1.gatherOrder)("wood", "debug_yard", { area: "debug_workshop", prop: "chest.fixture" }, 6));
    w.events = [];
    return w;
}
