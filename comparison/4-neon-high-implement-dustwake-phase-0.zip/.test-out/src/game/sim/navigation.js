"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.atDestination = exports.lineOfSight = void 0;
exports.sweptFree = sweptFree;
exports.navGrid = navGrid;
exports.findPath = findPath;
exports.walkTo = walkTo;
// Static geometry caches by Area + body + layout revision. Dynamic bodies are
// checked during planning and at every swept movement step, never baked in.
const actors_1 = require("../content/actors");
const tiles_1 = require("../content/tiles");
const world_1 = require("../world/world");
const collision_1 = require("./collision");
const reach_1 = require("./reach");
const actorStats_1 = require("./actorStats");
const DIRS = [[1, 0], [0, 1], [-1, 0], [0, -1]];
const cache = new WeakMap();
const keyAt = (area, p) => Math.floor((p.y - 3) / tiles_1.TS) * area.w + Math.floor(p.x / tiles_1.TS);
const feet = (area, k) => (0, reach_1.cellFeet)(k % area.w, Math.floor(k / area.w));
function sweptFree(from, to, free) {
    const steps = Math.max(1, Math.ceil(Math.hypot(to.x - from.x, to.y - from.y) / 2));
    for (let i = 0; i <= steps; i++)
        if (!free(from.x + (to.x - from.x) * i / steps, from.y + (to.y - from.y) * i / steps))
            return false;
    return true;
}
function navGrid(area, a) {
    const size = (0, actors_1.actorDef)(a).body.box, key = size.join(",");
    let grids = cache.get(area);
    if (!grids)
        cache.set(area, grids = new Map());
    const old = grids.get(key);
    if (old?.revision === area.layoutRevision)
        return old;
    const buckets = new Map();
    for (const p of area.props)
        if ((0, collision_1.propBlocks)(p)) {
            const b = p.box;
            for (let y = Math.floor((b[1] - size[1]) / tiles_1.TS) - 1; y <= Math.floor((b[3] + size[1]) / tiles_1.TS) + 1; y++)
                for (let x = Math.floor((b[0] - size[0]) / tiles_1.TS) - 1; x <= Math.floor((b[2] + size[0]) / tiles_1.TS) + 1; x++) {
                    if (x < 0 || y < 0 || x >= area.w || y >= area.h)
                        continue;
                    const k = y * area.w + x;
                    const list = buckets.get(k) ?? [];
                    list.push(b);
                    buckets.set(k, list);
                }
        }
    const free = (x, y) => (0, reach_1.freeAt)(area, buckets.get(Math.floor(y / tiles_1.TS) * area.w + Math.floor(x / tiles_1.TS)) ?? [], x, y, size);
    const cells = new Int8Array(area.w * area.h).fill(-1), links = new Int8Array(cells.length).fill(-1);
    const stand = (k) => {
        if (k < 0 || k >= cells.length)
            return false;
        if (cells[k] < 0) {
            const p = feet(area, k);
            cells[k] = Number(free(p.x, p.y));
        }
        return cells[k] === 1;
    };
    const edges = (k) => {
        if (links[k] >= 0)
            return links[k];
        const x = k % area.w, y = Math.floor(k / area.w), p = feet(area, k);
        let mask = 0;
        if (stand(k))
            DIRS.forEach(([dx, dy], i) => {
                const nx = x + dx, ny = y + dy, nk = ny * area.w + nx;
                if (nx >= 0 && ny >= 0 && nx < area.w && ny < area.h && stand(nk) && sweptFree(p, feet(area, nk), free))
                    mask |= 1 << i;
            });
        links[k] = mask;
        return mask;
    };
    const grid = { revision: area.layoutRevision, size, free, stand, edges };
    grids.set(key, grid);
    return grid;
}
/** Work cannot reach through a solid tile. Props at the destination are not walls. */
const lineOfSight = (area, from, to) => sweptFree(from, to, (x, y) => !(0, tiles_1.isSolidT)(area.tileAtPx(x, y)));
exports.lineOfSight = lineOfSight;
const atDestination = (area, a, goal) => Math.hypot(a.x - goal.x, a.y - goal.y) <= goal.range + 0.01 && (0, exports.lineOfSight)(area, a, goal);
exports.atDestination = atDestination;
function findPath(w, a, goal, avoidActors = true) {
    const area = (0, world_1.areaOf)(w, a), grid = navGrid(area, a), bodies = avoidActors ? (0, collision_1.actorBoxes)(w, area.id, a.id) : [];
    const free = (x, y) => grid.free(x, y) && (0, reach_1.freeAt)(area, bodies, x, y, grid.size);
    const sx = Math.floor(a.x / tiles_1.TS), sy = Math.floor((a.y - 3) / tiles_1.TS);
    const starts = [];
    for (let y = sy - 2; y <= sy + 2; y++)
        for (let x = sx - 2; x <= sx + 2; x++) {
            if (x < 0 || y < 0 || x >= area.w || y >= area.h)
                continue;
            const k = y * area.w + x;
            if (grid.stand(k) && sweptFree(a, feet(area, k), free))
                starts.push(k);
        }
    starts.sort((i, j) => {
        const p = feet(area, i), q = feet(area, j);
        return Math.hypot(p.x - a.x, p.y - a.y) - Math.hypot(q.x - a.x, q.y - a.y) || i - j;
    });
    if (!starts.length)
        return null;
    const start = starts[0], queue = [start], prev = new Int32Array(area.w * area.h).fill(-2);
    prev[start] = -1;
    for (let head = 0; head < queue.length; head++) {
        const k = queue[head], p = feet(area, k);
        const exact = goal.range < 4 && Math.hypot(p.x - goal.x, p.y - goal.y) <= tiles_1.TS && sweptFree(p, goal, free);
        if ((0, exports.atDestination)(area, p, goal) || exact) {
            const path = [];
            for (let n = k; n >= 0; n = prev[n])
                path.push(feet(area, n));
            path.reverse();
            if (exact && !(0, exports.atDestination)(area, p, goal))
                path.push({ x: goal.x, y: goal.y });
            return path;
        }
        const mask = grid.edges(k);
        DIRS.forEach(([dx, dy], i) => {
            if (!(mask & (1 << i)))
                return;
            const n = k + dy * area.w + dx;
            if (prev[n] !== -2 || !sweptFree(p, feet(area, n), free))
                return;
            prev[n] = k;
            queue.push(n);
        });
    }
    return null;
}
/** Lower id keeps its route; the other actor backs into a reachable passing
 * place outside that route. No teleporting, pushing or disabling collision. */
function yieldPath(w, a) {
    const area = (0, world_1.areaOf)(w, a), grid = navGrid(area, a);
    const peers = w.actors.filter((b) => b.id < a.id && b.area === a.area && b.job?.status === "running" && Math.hypot(b.x - a.x, b.y - a.y) < tiles_1.TS * 3)
        .sort((a, b) => a.id < b.id ? -1 : 1);
    const peer = peers[0];
    if (!peer)
        return null;
    const route = [peer, ...(peer.job?.nav?.path ?? [])];
    const cells = [], k0 = keyAt(area, a), sx = k0 % area.w, sy = Math.floor(k0 / area.w);
    for (let y = sy - 5; y <= sy + 5; y++)
        for (let x = sx - 5; x <= sx + 5; x++) {
            if (x < 0 || y < 0 || x >= area.w || y >= area.h)
                continue;
            const k = y * area.w + x, p = feet(area, k);
            if (k !== k0 && grid.stand(k) && route.every((q) => Math.hypot(q.x - p.x, q.y - p.y) >= tiles_1.TS - 1))
                cells.push(k);
        }
    cells.sort((i, j) => {
        const p = feet(area, i), q = feet(area, j);
        return Math.hypot(p.x - a.x, p.y - a.y) - Math.hypot(q.x - a.x, q.y - a.y) || i - j;
    });
    for (const k of cells) {
        const path = findPath(w, a, { ...feet(area, k), range: 1 });
        if (path)
            return path;
    }
    return null;
}
function walkTo(w, a, goal, dt) {
    const job = a.job, area = (0, world_1.areaOf)(w, a);
    if (!job || goal.area !== area.id)
        return "stuck";
    const key = `${goal.area}:${goal.x},${goal.y}:${goal.range}`;
    if (job.nav?.goal !== key)
        job.nav = { goal: key, path: [], blockedFor: 0, recoveries: 0, yielding: false, replanIn: 0 };
    const nav = job.nav;
    a.moving = false;
    a.vx = 0;
    a.vy = 0;
    if (!nav.yielding && (0, exports.atDestination)(area, a, goal)) {
        job.nav = null;
        return "arrived";
    }
    nav.replanIn = Math.max(0, nav.replanIn - dt);
    if (!nav.path.length && nav.replanIn > 0)
        return "moving";
    if (!nav.path.length)
        nav.path = findPath(w, a, goal) ?? findPath(w, a, goal, false) ?? [];
    const start = { x: a.x, y: a.y }, grid = navGrid(area, a), bodies = (0, collision_1.actorBoxes)(w, a.area, a.id);
    const free = (x, y) => grid.free(x, y) && (0, reach_1.freeAt)(area, bodies, x, y, grid.size);
    let budget = (0, actorStats_1.actorSpeed)(w, a) * dt;
    while (nav.path.length && budget > 0) {
        const p = nav.path[0], dx = p.x - a.x, dy = p.y - a.y, dist = Math.hypot(dx, dy);
        if (dist < 0.01) {
            nav.path.shift();
            continue;
        }
        const step = Math.min(dist, budget, 2), next = { x: a.x + dx / dist * step, y: a.y + dy / dist * step };
        if (!sweptFree(a, next, free))
            break;
        a.x = next.x;
        a.y = next.y;
        budget -= step;
        a.facing = Math.abs(dx) > Math.abs(dy) ? dx > 0 ? "right" : "left" : dy > 0 ? "down" : "up";
        if (step >= dist - 0.01)
            nav.path.shift();
    }
    const moved = Math.hypot(a.x - start.x, a.y - start.y);
    if (moved > 0.001) {
        a.moving = true;
        a.vx = (a.x - start.x) / Math.max(dt, 1e-6);
        a.vy = (a.y - start.y) / Math.max(dt, 1e-6);
        a.phase += moved * 0.2;
        nav.blockedFor = 0;
    }
    else
        nav.blockedFor += dt;
    if (nav.yielding && !nav.path.length) {
        nav.yielding = false;
        nav.replanIn = 0.8;
        nav.blockedFor = 0;
    }
    if (nav.blockedFor >= 0.65) {
        nav.blockedFor = 0;
        nav.recoveries++;
        if (nav.recoveries >= 6)
            return "stuck";
        const yielding = yieldPath(w, a);
        nav.yielding = !!yielding;
        nav.path = yielding ?? findPath(w, a, goal) ?? [];
        nav.replanIn = nav.path.length ? 0 : 0.2;
    }
    return "moving";
}
