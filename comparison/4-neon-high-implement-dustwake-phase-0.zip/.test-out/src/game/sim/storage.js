"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.storageRef = exports.packRef = void 0;
exports.inventoryHandle = inventoryHandle;
exports.transferItems = transferItems;
exports.transferSlot = transferSlot;
exports.nearbyStorage = nearbyStorage;
exports.craftSources = craftSources;
exports.consumeInputs = consumeInputs;
// Generic inventory transactions. Prop handles are snapshots; only the commit
// touches Area state. Source order for crafting is pack, then stable prop id.
const props_1 = require("../content/props");
const tiles_1 = require("../content/tiles");
const world_1 = require("../world/world");
const inventory_1 = require("./inventory");
const inventoryOps_1 = require("./inventoryOps");
const discovery_1 = require("./discovery");
const packRef = (a) => ({ kind: "actor", id: a.id });
exports.packRef = packRef;
const storageRef = (area, id) => ({ kind: "prop", area, id });
exports.storageRef = storageRef;
function inventoryHandle(w, ref) {
    if (ref.kind === "actor") {
        const a = (0, world_1.actorById)(w, ref.id);
        if (!a)
            return null;
        const h = { ref, inventory: (0, inventoryOps_1.copySlots)(a.inventory), capacity: (0, inventory_1.capacity)(w, a), commit: () => {
                a.inventory = (0, inventoryOps_1.copySlots)(h.inventory);
                for (const s of a.inventory)
                    if (s)
                        (0, discovery_1.rememberItem)(w, a, s.item);
            } };
        return h;
    }
    const area = w.areas.get(ref.area), p = area?.prop(ref.id), cap = p && (0, props_1.propDef)(p.kind).storage?.slots;
    if (!area || !p?.inventory || cap === undefined)
        return null;
    const h = { ref, inventory: (0, inventoryOps_1.copySlots)(p.inventory), capacity: cap, commit: () => area.setInventory(p.id, h.inventory) };
    return h;
}
/** Transfer as much as fits; a refusal or missing owner changes nothing. */
function transferItems(w, from, to, item, n) {
    const same = from.kind === to.kind && from.id === to.id && (from.kind !== "prop" || to.kind !== "prop" || from.area === to.area);
    if (!Number.isSafeInteger(n) || n <= 0 || same)
        return 0;
    const src = inventoryHandle(w, from), dst = inventoryHandle(w, to);
    if (!src || !dst)
        return 0;
    const moved = Math.min(n, (0, inventoryOps_1.countItem)(src, item), (0, inventoryOps_1.roomIn)(dst.inventory, dst.capacity, item));
    if (!moved)
        return 0;
    (0, inventoryOps_1.removeItems)(src, item, moved);
    (0, inventoryOps_1.insertItems)(dst.inventory, dst.capacity, item, moved);
    src.commit();
    dst.commit();
    return moved;
}
/**
 * Move up to `n` of what one slot of `from` holds into `to`, as much as fits.
 * Unlike `transferItems` it takes from that very slot, so a screen's cursor
 * stays on the stack it is moving. A refusal or a missing owner changes nothing.
 */
function transferSlot(w, from, to, slot, n) {
    const same = from.kind === to.kind && from.id === to.id && (from.kind !== "prop" || to.kind !== "prop" || from.area === to.area);
    if (!Number.isSafeInteger(n) || n <= 0 || same || !Number.isInteger(slot) || slot < 0)
        return 0;
    const src = inventoryHandle(w, from), dst = inventoryHandle(w, to);
    const s = src?.inventory[slot];
    if (!src || !dst || !s || slot >= src.capacity)
        return 0;
    const moved = Math.min(n, s.n, (0, inventoryOps_1.roomIn)(dst.inventory, dst.capacity, s.item));
    if (!moved)
        return 0;
    const item = s.item;
    s.n -= moved;
    if (!s.n)
        src.inventory[slot] = null;
    (0, inventoryOps_1.insertItems)(dst.inventory, dst.capacity, item, moved);
    src.commit();
    dst.commit();
    return moved;
}
function nearbyStorage(area, station, radius = 2) {
    const tx = Math.floor(station.x / tiles_1.TS), ty = Math.floor((station.y - 1) / tiles_1.TS);
    return area.props.filter((p) => p.inventory && Math.max(Math.abs(Math.floor(p.x / tiles_1.TS) - tx), Math.abs(Math.floor((p.y - 1) / tiles_1.TS) - ty)) <= radius)
        .sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
}
function craftSources(w, a, station) {
    const pack = inventoryHandle(w, (0, exports.packRef)(a));
    const area = w.areas.get(a.area);
    return [pack, ...(area && station ? nearbyStorage(area, station).map((p) => inventoryHandle(w, (0, exports.storageRef)(area.id, p.id))) : [])]
        .filter((h) => !!h);
}
/** Aggregate duplicate ingredient rows before validation; commit only after
 * every ingredient fits, so competing crafters cannot partially consume. */
function consumeInputs(sources, inputs) {
    const seen = new Set();
    sources = sources.filter((h) => {
        const key = JSON.stringify([h.ref.kind, h.ref.kind === "prop" ? h.ref.area : null, h.ref.id]);
        if (seen.has(key))
            return false;
        seen.add(key);
        return true;
    });
    const totals = new Map();
    for (const c of inputs) {
        if (!Number.isSafeInteger(c.n) || c.n <= 0)
            return false;
        totals.set(c.item, (totals.get(c.item) ?? 0) + c.n);
    }
    for (const [item, n] of totals)
        if (sources.reduce((s, h) => s + (0, inventoryOps_1.countItem)(h, item), 0) < n)
            return false;
    const dirty = new Set();
    for (const [item, total] of totals) {
        let left = total;
        for (const h of sources) {
            const n = Math.min(left, (0, inventoryOps_1.countItem)(h, item));
            if (n) {
                (0, inventoryOps_1.removeItems)(h, item, n);
                dirty.add(h);
                left -= n;
            }
        }
    }
    for (const h of dirty)
        h.commit();
    return true;
}
