"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RUNE_NODES = exports.runeAnswers = exports.runeActive = void 0;
exports.runeState = runeState;
exports.arrivalSpot = arrivalSpot;
exports.travel = travel;
exports.runeWays = runeWays;
exports.runeRoute = runeRoute;
// Rune network travel. Interacting with a rune that will carry runs a `channel`
// task whose `travel` effect lands here: resolve the link, wake a dormant
// partner if the link says so, find a free arrival spot next to the destination
// rune and move the actor with enterArea().
const runes_1 = require("../content/runes");
Object.defineProperty(exports, "RUNE_NODES", { enumerable: true, get: function () { return runes_1.RUNE_NODES; } });
const flags_1 = require("../content/flags");
const world_1 = require("../world/world");
const collision_1 = require("./collision");
const actors_1 = require("../content/actors");
const actorStats_1 = require("./actorStats");
const messages_1 = require("./messages");
const daytime_1 = require("./daytime");
const daycycle_1 = require("../content/daycycle");
const runeActive = (w, n) => (0, world_1.hasFlag)(w, n.flag);
exports.runeActive = runeActive;
/** Does the far end of a hop answer: it is lit, or going this way is what wakes it. */
const runeAnswers = (w, d) => (0, exports.runeActive)(w, d.node) || d.wakes;
exports.runeAnswers = runeAnswers;
function runeState(w, n) {
    if (!(0, exports.runeActive)(w, n))
        return "dormant";
    return (0, runes_1.runeDestinations)(n.id).some((d) => (0, exports.runeAnswers)(w, d)) ? "linked" : "severed";
}
function arrivalSpot(w, n, actor) {
    const area = (0, world_1.getArea)(w, n.area);
    const p = area.prop(n.prop);
    if (!p) {
        if (actor)
            return null;
        throw new Error(`rune ${n.id}: prop ${n.prop} missing in ${n.area}`);
    }
    const spot = (0, collision_1.nearestFree)(area, p.x + n.arrive.dx, p.y + n.arrive.dy, (0, collision_1.actorBoxes)(w, area.id, actor?.id), actor ? (0, actors_1.actorDef)(actor).body.box : undefined);
    if (!spot && !actor)
        throw new Error(`rune ${n.id}: no free arrival`);
    return spot;
}
function travel(w, a, area, propId, destination) {
    if (!(0, actors_1.capable)(a, "travel") || !(0, actorStats_1.powered)(a) || a.area !== area.id)
        return false;
    const from = (0, runes_1.runeAt)(area.id, propId);
    if (!from)
        return false;
    if (!(0, exports.runeActive)(w, from)) {
        (0, messages_1.actorMessage)(w, a, "THE RUNE IS DARK AND SILENT");
        return false;
    }
    // The link asked for, else the first that answers (a rune with several links never picks a dead one over a live one).
    const ways = (0, runes_1.runeDestinations)(from.id).filter((d) => !destination || d.node.id === destination);
    const dest = ways.find((d) => (0, exports.runeAnswers)(w, d)) ?? ways[0];
    if (!dest) {
        (0, messages_1.actorMessage)(w, a, "THE RUNE LEADS NOWHERE");
        return false;
    }
    const to = dest.node;
    // A dark far end is woken only by the hop that is allowed to wake it. Refused, nothing is set and nobody moves.
    if (!(0, exports.runeAnswers)(w, dest)) {
        (0, messages_1.actorMessage)(w, a, "NOTHING ANSWERS ON THE OTHER SIDE");
        return false;
    }
    const spot = arrivalSpot(w, to, a);
    if (!spot)
        return false;
    if (!(0, exports.runeActive)(w, to)) {
        (0, world_1.setFlag)(w, to.flag);
        (0, world_1.emit)(w, { t: "runeAwakened", rune: to.id, actor: a.id });
    }
    (0, world_1.enterArea)(w, a, to.area, spot.x, spot.y);
    a.facing = to.arrive.facing;
    if (a.id === w.playerId) {
        // The first crossing is not instant: the far anchor has to be rewritten on the way (the cutscene shows it), and
        // the golem comes up in the last dark before dawn however long the halls took. Later hops take no time.
        if (!(0, world_1.hasFlag)(w, flags_1.FLAGS.tutorialDone))
            (0, daytime_1.advanceDayTo)(w, daycycle_1.FIRST_ARRIVAL_HOUR);
        (0, world_1.setFlag)(w, flags_1.FLAGS.tutorialDone);
    }
    (0, world_1.emit)(w, { t: "travelled", actor: a.id, from: from.id, to: to.id, rune: to.prop });
    return true;
}
/**
 * The rune hops out of an area, in stable id order: from every lit rune in it (or the one woken on the way here,
 * `awake`), to every far end that answers. `woke` names a far rune this hop would wake (it is dark now).
 */
function runeWays(w, area, awake = "") {
    const out = [];
    const nodes = Object.values(runes_1.RUNE_NODES).filter((n) => n.area === area && ((0, exports.runeActive)(w, n) || n.id === awake)).sort((a, b) => a.id < b.id ? -1 : 1);
    for (const n of nodes)
        for (const d of (0, runes_1.runeDestinations)(n.id).sort((a, b) => a.node.id < b.node.id ? -1 : 1)) {
            if ((0, exports.runeAnswers)(w, d))
                out.push({ from: n, to: d.node, woke: (0, exports.runeActive)(w, d.node) ? "" : d.node.id });
        }
    return out;
}
/** Ordered hops by rune alone, respecting one-way links, activation and arrival awakening.
 * Routes are derived afresh; a saved job only keeps its destination. (Orders route over runes and portals
 * together: sim/routes.ts.) */
function runeRoute(w, fromArea, toArea) {
    if (fromArea === toArea)
        return [];
    const queue = [{ area: fromArea, awake: "", hops: [] }], seen = new Set();
    for (let i = 0; i < queue.length; i++) {
        const s = queue[i], key = `${s.area}:${s.awake}`;
        if (seen.has(key))
            continue;
        seen.add(key);
        for (const e of runeWays(w, s.area, s.awake)) {
            const hops = [...s.hops, { from: e.from.id, to: e.to.id }];
            if (e.to.area === toArea)
                return hops;
            queue.push({ area: e.to.area, awake: e.woke, hops });
        }
    }
    return null;
}
