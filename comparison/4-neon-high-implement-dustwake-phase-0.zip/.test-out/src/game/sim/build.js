"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.propTile = exports.isDeconstructable = exports.deconMessage = exports.DECON_TEXT = exports.actorTile = exports.buildAnchor = exports.BLOCK_TEXT = void 0;
exports.canBuild = canBuild;
exports.recipeAnchor = recipeAnchor;
exports.frontTile = frontTile;
exports.footprint = footprint;
exports.siteFor = siteFor;
exports.placement = placement;
exports.suggestTile = suggestTile;
exports.applyBuild = applyBuild;
exports.salvageOf = salvageOf;
exports.deconTargetAt = deconTargetAt;
exports.deconstructCheck = deconstructCheck;
exports.applyDeconstruct = applyDeconstruct;
// Building and deconstruction: placement validity, salvage rules and the two
// effects live here (sim, testable headless), not in the renderer. The build
// screens only ask `placement()` / `deconstructCheck()` and, on confirm, start
// a task whose effect re-validates when it fires (the world may have changed).
const build_1 = require("../content/build");
const tiles_1 = require("../content/tiles");
const props_1 = require("../content/props");
const items_1 = require("../content/items");
const world_1 = require("../world/world");
const inventory_1 = require("./inventory");
const collision_1 = require("./collision");
const analysis_1 = require("./analysis");
const actors_1 = require("../content/actors");
const actorStats_1 = require("./actorStats");
exports.BLOCK_TEXT = {
    unknown: "YOU DON'T KNOW HOW TO BUILD THAT",
    cost: "NOT ENOUGH MATERIALS",
    reach: "TOO FAR AWAY",
    solid: "CAN'T BUILD THERE",
    occupied: "SOMETHING IS IN THE WAY",
    noWall: "MUST HANG ON A WALL",
    wallFace: "ONLY ON A WALL FACE WITH FLOOR BELOW",
};
/** Knowledge + materials, independent of where. */
function canBuild(w, a, recipe) {
    const r = build_1.RECIPES[recipe];
    if (!r || !(0, actors_1.capable)(a, "build") || !(0, actorStats_1.powered)(a) || !(0, analysis_1.recipeKnown)(w, a, r))
        return { ok: false, reason: "unknown" };
    if (!r.cost.every((c) => (0, inventory_1.countItem)(a, c.item) >= c.n))
        return { ok: false, reason: "cost" };
    return { ok: true };
}
/** Anchor (feet) of a floor prop built on a tile. */
const buildAnchor = (tx, ty) => ({ x: tx * tiles_1.TS + 8, y: ty * tiles_1.TS + 14 });
exports.buildAnchor = buildAnchor;
/**
 * Anchor of a recipe's prop on a tile. Wall props hang at the bottom edge of
 * their wall tile (tx*16+8, ty*16+16): the same anchor the dungeon builder gives
 * its wall torches, banners and chains, so they sort just in front of the wall.
 */
function recipeAnchor(recipe, tx, ty) {
    const r = build_1.RECIPES[recipe];
    return r && (0, build_1.placeRule)(r) === "wall" ? { x: tx * tiles_1.TS + 8, y: ty * tiles_1.TS + 16 } : (0, exports.buildAnchor)(tx, ty);
}
/** The tile directly in front of the actor (default placement target). */
function frontTile(a) {
    const fx = a.facing === "left" ? -1 : a.facing === "right" ? 1 : 0;
    const fy = a.facing === "up" ? -1 : a.facing === "down" ? 1 : 0;
    return { tx: Math.floor(a.x / tiles_1.TS) + fx, ty: Math.floor((a.y - 3) / tiles_1.TS) + fy };
}
const actorTile = (a) => ({ tx: Math.floor(a.x / tiles_1.TS), ty: Math.floor((a.y - 3) / tiles_1.TS) });
exports.actorTile = actorTile;
const inReach = (a, tx, ty) => {
    const t = (0, exports.actorTile)(a);
    return Math.max(Math.abs(tx - t.tx), Math.abs(ty - t.ty)) <= build_1.BUILD_REACH;
};
/**
 * Space a floor recipe claims on tile (tx, ty), in px [x0, y0, x1, y1]: the
 * tile itself plus the prop's collision box (wide props like the bench and
 * the table spill into the neighbouring tiles).
 */
function footprint(r, tx, ty) {
    const x0 = tx * tiles_1.TS, y0 = ty * tiles_1.TS, x1 = x0 + tiles_1.TS, y1 = y0 + tiles_1.TS;
    const bx = (0, props_1.propDef)(r.prop).box;
    if (!bx)
        return [x0, y0, x1, y1];
    const a = (0, exports.buildAnchor)(tx, ty);
    return [Math.min(x0, a.x - bx[0] / 2), Math.min(y0, a.y - bx[1]), Math.max(x1, a.x + bx[0] / 2), Math.max(y1, a.y)];
}
const overlaps = (a, b) => a[2] > b[0] && a[0] < b[2] && a[3] > b[1] && a[1] < b[3];
/** Where-only check for a floor recipe. */
function floorSite(w, area, r, tx, ty) {
    if (tx < 0 || ty < 0 || tx >= area.w || ty >= area.h || (0, tiles_1.isSolidT)(area.grid[ty * area.w + tx]))
        return { ok: false, reason: "solid" };
    const fp = footprint(r, tx, ty);
    for (let y = Math.floor(fp[1] / tiles_1.TS); y <= Math.floor((fp[3] - 0.01) / tiles_1.TS); y++)
        for (let x = Math.floor(fp[0] / tiles_1.TS); x <= Math.floor((fp[2] - 0.01) / tiles_1.TS); x++)
            if ((0, tiles_1.isSolidT)(area.tile(x, y)))
                return { ok: false, reason: "solid" };
    const [x0, y0, x1, y1] = fp;
    for (const p of area.props) {
        // Rune circles keep a clear ring; any prop anchored in the footprint or a blocking box overlapping it occupies it.
        if ((0, props_1.propDef)(p.kind).rune && Math.hypot(p.x - (tx * tiles_1.TS + 8), p.y - (ty * tiles_1.TS + 8)) < 40)
            return { ok: false, reason: "occupied" };
        if ((0, props_1.propDef)(p.kind).wallMounted)
            continue;
        if (p.x >= x0 && p.x < x1 && p.y > y0 && p.y <= y1 + 2 && !(p.taken && !(0, collision_1.propBlocks)(p)))
            return { ok: false, reason: "occupied" };
        if (p.box && (0, collision_1.propBlocks)(p) && overlaps(p.box, fp))
            return { ok: false, reason: "occupied" };
    }
    if (area.ritual) {
        const c = area.ritualPos;
        if (Math.hypot(c.x - (tx * tiles_1.TS + 8), c.y - (ty * tiles_1.TS + 8)) < 64)
            return { ok: false, reason: "occupied" };
    }
    // not on top of anyone (the builder included)
    for (const b of (0, collision_1.actorBoxes)(w, area.id))
        if (overlaps(b, fp))
            return { ok: false, reason: "occupied" };
    return { ok: true };
}
/**
 * Where-only check for a wall recipe. "On a wall" means the visible (south)
 * face of a plain WALL tile: the tile itself is WALL (not a door, cracked wall,
 * pillar or rubble, so tutorial walls are never covered) and the tile directly
 * below it is open floor, which is where the face shows and where the golem
 * stands to reach it. Side and back faces aren't drawn in this 3/4 view, so
 * they can't carry anything. One wall-mounted prop per face tile.
 */
function wallSite(area, tx, ty) {
    if (tx < 0 || ty < 0 || tx >= area.w || ty >= area.h)
        return { ok: false, reason: "noWall" };
    if (area.tile(tx, ty) !== tiles_1.T.WALL)
        return { ok: false, reason: "noWall" };
    if ((0, tiles_1.isSolidT)(area.tile(tx, ty + 1)))
        return { ok: false, reason: "wallFace" };
    const ax = tx * tiles_1.TS + 8, ay = ty * tiles_1.TS + 16;
    for (const p of area.props) {
        if ((0, props_1.propDef)(p.kind).wallMounted && Math.abs(p.x - ax) < 12 && Math.abs(p.y - ay) < 8)
            return { ok: false, reason: "occupied" };
    }
    return { ok: true };
}
/** Is (tx, ty) a site this recipe could stand on (ignoring knowledge, cost and reach)? */
function siteFor(w, area, recipe, tx, ty) {
    const r = build_1.RECIPES[recipe];
    if (!r)
        return { ok: false, reason: "unknown" };
    return (0, build_1.placeRule)(r) === "wall" ? wallSite(area, tx, ty) : floorSite(w, area, r, tx, ty);
}
/** Full validity check for placing `recipe` on tile (tx, ty). */
function placement(w, a, area, recipe, tx, ty) {
    const can = canBuild(w, a, recipe);
    if (!can.ok)
        return can;
    if (!inReach(a, tx, ty))
        return { ok: false, reason: "reach" };
    return siteFor(w, area, recipe, tx, ty);
}
/**
 * Where the placement ghost should start: the tile in front of the builder if
 * the recipe fits there, else the nearest fitting tile in reach (so a wall
 * torch's ghost snaps to the closest wall face), else the front tile.
 */
function suggestTile(w, a, area, recipe) {
    const f = frontTile(a), t = (0, exports.actorTile)(a);
    if (siteFor(w, area, recipe, f.tx, f.ty).ok)
        return f;
    let best = null, bd = Infinity;
    for (let dy = -build_1.BUILD_REACH; dy <= build_1.BUILD_REACH; dy++)
        for (let dx = -build_1.BUILD_REACH; dx <= build_1.BUILD_REACH; dx++) {
            const tx = t.tx + dx, ty = t.ty + dy;
            const d = Math.hypot(tx - f.tx, ty - f.ty);
            if (d < bd && siteFor(w, area, recipe, tx, ty).ok) {
                bd = d;
                best = { tx, ty };
            }
        }
    return best ?? f;
}
/** The `build` effect. Re-validates (the world may have changed since the order). */
function applyBuild(w, a, area, recipe, tx, ty) {
    const ok = placement(w, a, area, recipe, tx, ty);
    if (!ok.ok) {
        (0, world_1.emit)(w, { t: "message", text: exports.BLOCK_TEXT[ok.reason] });
        return;
    }
    const r = build_1.RECIPES[recipe];
    for (const c of r.cost)
        (0, inventory_1.removeItems)(a, c.item, c.n);
    const at = recipeAnchor(recipe, tx, ty);
    const p = area.addProp(r.prop, at.x, at.y, { recipe, refund: r.cost.map((c) => ({ ...c })), ...(r.v ? { v: r.v } : {}), ...(r.lit ? { lit: true } : {}) });
    (0, world_1.emit)(w, { t: "built", actor: a.id, prop: p.id, x: p.x, y: p.y });
}
exports.DECON_TEXT = {
    none: "NOTHING TO TAKE APART HERE",
    fixed: "THAT CAN'T BE TAKEN APART",
    reach: "TOO FAR AWAY",
    holds: "TAKE WHAT IS ON IT FIRST",
};
/** The refusal in words (a prop that still holds something names it). */
const deconMessage = (chk) => chk.reason === "holds" && chk.item ? `TAKE THE ${items_1.ITEM_NAMES[chk.item]} FIRST` : exports.DECON_TEXT[chk.reason];
exports.deconMessage = deconMessage;
/**
 * What taking a prop apart gives back, or null if it can't be. A built prop
 * refunds what it cost when it was built (`refund`; older saves didn't record
 * it: the cost of its recipe, else the recipe for its kind). An authored prop
 * only if its kind has a row in AUTHORED_SALVAGE (every kind a recipe builds is
 * one): the full cost of the recipe that makes it, crafted materials included.
 */
function salvageOf(p) {
    if (p.dyn) {
        if (p.refund)
            return p.refund.map((c) => ({ ...c }));
        const id = p.recipe && build_1.RECIPES[p.recipe] ? p.recipe : (0, build_1.recipeForProp)(p.kind);
        return id ? build_1.RECIPES[id].cost.map((c) => ({ ...c })) : null;
    }
    const s = build_1.AUTHORED_SALVAGE[p.kind];
    if (!s)
        return null;
    if ("refund" in s)
        return s.refund.map((c) => ({ ...c }));
    const r = build_1.RECIPES[s.recipe];
    return r ? r.cost.map((c) => ({ ...c })) : null;
}
const isDeconstructable = (p) => salvageOf(p) !== null;
exports.isDeconstructable = isDeconstructable;
/** Tile a prop is anchored in (wall props: their wall tile). */
const propTile = (p) => ({ tx: Math.floor(p.x / tiles_1.TS), ty: Math.floor((p.y - 1) / tiles_1.TS) });
exports.propTile = propTile;
/**
 * The prop a deconstruct cursor on tile (tx, ty) points at: one anchored in
 * the tile (deconstructable ones first), else one whose blocking box covers
 * it. Rune circles are never targets.
 */
function deconTargetAt(area, tx, ty) {
    const cands = area.props.filter((p) => !(0, props_1.propDef)(p.kind).rune && p.kind !== "pedestal");
    const anchored = cands.filter((p) => { const t = (0, exports.propTile)(p); return t.tx === tx && t.ty === ty; });
    const pick = anchored.find(exports.isDeconstructable) ?? anchored[0];
    if (pick)
        return pick;
    const r = [tx * tiles_1.TS, ty * tiles_1.TS, tx * tiles_1.TS + tiles_1.TS, ty * tiles_1.TS + tiles_1.TS];
    const boxed = cands.filter((p) => p.box && (0, collision_1.propBlocks)(p) && overlaps(p.box, r));
    return boxed.find(exports.isDeconstructable) ?? boxed[0] ?? null;
}
/**
 * Can actor `a` take apart prop `propId` right now? Refused while something
 * progress-critical (`isCritical`) still rests on it or is kept in it: the
 * dungeon workbench holds the rune chisel and the library table holds the
 * Builder's Primer, which the tutorial and all building knowledge depend on.
 * Take the item first, then the prop can go. Anything else resting on a prop
 * is spilled onto the ground when it is taken apart.
 */
function deconstructCheck(_w, a, area, propId) {
    const p = propId ? area.prop(propId) : undefined;
    if (!p)
        return { ok: false, reason: "none" };
    if (!(0, actors_1.capable)(a, "build") || !(0, actorStats_1.powered)(a))
        return { ok: false, reason: "fixed", prop: p };
    const refund = salvageOf(p);
    if (!refund)
        return { ok: false, reason: "fixed", prop: p };
    if (p.item && !p.taken && (0, items_1.isCritical)(p.item))
        return { ok: false, reason: "holds", prop: p, item: p.item };
    const critical = p.inventory?.find((s) => s && (0, items_1.isCritical)(s.item));
    if (critical)
        return { ok: false, reason: "holds", prop: p, item: critical.item };
    const t = (0, exports.propTile)(p);
    if (!inReach(a, t.tx, t.ty))
        return { ok: false, reason: "reach", prop: p };
    return { ok: true, prop: p, refund };
}
/**
 * The `deconstruct` effect. Re-validates, removes the prop (its light and
 * interactables follow via area.revision), spills anything non-critical resting
 * on or in it onto the ground, then refunds the full cost through giveItem, so a
 * full pack drops the overflow on the ground like any pickup.
 */
function applyDeconstruct(w, a, area, propId) {
    const chk = deconstructCheck(w, a, area, propId);
    if (!chk.ok) {
        (0, world_1.emit)(w, { t: "message", text: (0, exports.deconMessage)(chk) });
        return;
    }
    const p = chk.prop;
    const held = p.item && !p.taken ? p.item : undefined;
    const contents = p.inventory?.flatMap((s) => s ? [{ ...s }] : []) ?? [];
    area.removeProp(p.id);
    for (const s of contents) {
        const spot = (0, inventory_1.dropSpot)(area, a, (0, collision_1.actorBoxes)(w, area.id, a.id)) ?? a;
        (0, inventory_1.spawnLoose)(area, s.item, s.n, spot.x, spot.y);
    }
    if (held) {
        const spot = (0, inventory_1.dropSpot)(area, a, (0, collision_1.actorBoxes)(w, area.id, a.id));
        const x = spot ? spot.x : a.x, y = spot ? spot.y : a.y;
        (0, inventory_1.spawnLoose)(area, held, 1, x, y);
        (0, world_1.emit)(w, { t: "itemDropped", actor: a.id, item: held, n: 1, x, y, reason: "overflow" });
    }
    for (const c of chk.refund)
        (0, inventory_1.giveItem)(w, a, c.item, c.n);
    (0, world_1.emit)(w, { t: "deconstructed", actor: a.id, prop: p.id, kind: p.kind, x: p.x, y: p.y });
    // Taking a thing apart reads its pattern as surely as scanning it, so no plan
    // is ever lost with the last example of its kind (the dungeon's only workbench).
    if ((0, actors_1.capable)(a, "scan")) {
        const fresh = (0, analysis_1.learnPlans)(w, a, p);
        if (fresh.length && a.id === w.playerId)
            (0, world_1.emit)(w, { t: "message", text: `PLAN LEARNED: ${fresh[0][1].name}` });
    }
}
