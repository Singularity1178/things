"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.stepPlayer = stepPlayer;
exports.addPlayTime = addPlayTime;
exports.stepWorld = stepWorld;
exports.move = move;
// Per-frame simulation entry points. Deterministic given (world, dt, input)
// except where noted; no DOM. The host decides which of these run in which
// screen (e.g. overlays pause the world by simply not calling them).
const tiles_1 = require("../content/tiles");
const ritual_1 = require("../content/ritual");
const flags_1 = require("../content/flags");
const world_1 = require("../world/world");
const tasks_1 = require("./tasks");
const inventory_1 = require("./inventory");
const gear_1 = require("./gear");
const collision_1 = require("./collision");
const interactions_1 = require("../content/interactions");
const interact_1 = require("./interact");
const actors_1 = require("../content/actors");
const actorStats_1 = require("./actorStats");
const jobs_1 = require("./jobs");
const analysis_1 = require("./analysis");
const monologue_1 = require("./monologue");
const commands_1 = require("./commands");
const portals_1 = require("./portals");
const daytime_1 = require("./daytime");
const folk_1 = require("./folk");
const shops_1 = require("./shops");
const lod_1 = require("./lod");
/** Advance the player-controlled actor: work, locomotion, interaction, teleport. */
function stepPlayer(w, dt, input) {
    const pl = (0, world_1.player)(w);
    const area = (0, world_1.areaOf)(w, pl);
    if (input.toggleScan)
        (0, analysis_1.toggleScan)(pl);
    if (pl.job && pl.job.status !== "done" && (input.ix || input.iy || input.use || input.attack || input.core))
        (0, jobs_1.cancelJob)(w, pl);
    (0, tasks_1.tickTask)(w, pl, dt);
    if (pl.job && pl.job.status !== "done" && (pl.job.status !== "paused" || pl.job.reason === "power")) {
        (0, jobs_1.tickJob)(w, pl, dt);
        (0, monologue_1.reactToEvents)(w);
        return { target: null, ui: null };
    }
    move(w, area, pl, dt, pl.task ? 0 : input.ix, pl.task ? 0 : input.iy, (0, actorStats_1.actorSpeed)(w, pl) * (input.speed ?? 1), input.noclip);
    // Roads and doorways (sim/portals.ts): pushing on through one walks into the area beyond.
    if (!pl.task && (input.ix || input.iy)) {
        const way = (0, portals_1.portalAt)(area, pl.x, pl.y, input.ix, input.iy, (p) => (0, portals_1.portalOpen)(w, p));
        if (way && (0, portals_1.walkThrough)(w, pl, area, way)) {
            (0, monologue_1.reactToEvents)(w);
            return { target: null, ui: null };
        }
    }
    const scan = pl.task || pl.mode !== "scan" ? null : (0, interact_1.findScanTarget)(area, pl);
    const target = pl.task ? null : scan ?? (0, interact_1.findTarget)(area, pl, (0, interact_1.npcInteractables)(w, area));
    let ui = null;
    if (!pl.task && target && input.use)
        ui = (0, interact_1.interact)(w, pl, area, target);
    // C: the core seam, its own key so talking (E) can never slot or remove one by accident.
    if (!pl.task && !ui && input.core)
        (0, commands_1.coreKey)(w, pl, area);
    // The attack is separate from interacting: available whenever the golem could act, target or not.
    if (!pl.task && !ui && input.attack)
        (0, interact_1.startSlam)(pl);
    // Tutorial beat (one-shot): standing on the freshly charged circle starts the
    // first jump through the rune network. Afterwards runes are used with E.
    const r = area.ritual;
    if (r && r.active && r.actT > ritual_1.RITUAL_SPOTS.teleport.delay && !pl.task && !(0, world_1.hasFlag)(w, flags_1.FLAGS.tutorialDone)) {
        const c = area.ritualPos;
        const dx = c.x - pl.x, dy = c.y + ritual_1.RITUAL_SPOTS.teleport.dy - pl.y;
        if (dx * dx + dy * dy < ritual_1.RITUAL_SPOTS.teleport.r2) {
            pl.facing = "down";
            const first = interactions_1.RULES.rune[interactions_1.RULES.rune.length - 1].task;
            (0, tasks_1.beginTask)(pl, first, { kind: "rune", x: c.x, y: c.y, propId: "rune.dungeon" });
            (0, world_1.emit)(w, { t: "teleport", actor: pl.id, first: true, x: c.x, y: c.y });
        }
    }
    (0, monologue_1.reactToEvents)(w);
    return { target, ui };
}
/** Active-play time stat (shown on the chapter card that closes the first crossing). */
function addPlayTime(w, dt) { w.playTime += dt; }
/** Advance everything that runs on world time: clock, scheduled effects, non-player actors, area features. */
//
// Simulation LOD policy (Phase 0.2):
// - Active (in view): full step every tick.
// - Near (same area, off-camera): stepped every nearStride ticks with accumulated dt.
// - Far (other areas): schedule-based residents skipped until catch-up on area entry
//   (`world.time - area.lastTicked`); workers with active cross-area jobs step at farStride.
function stepWorld(w, dt) {
    w.time += dt;
    const lod = (w.lod ?? (w.lod = (0, lod_1.createLodConfig)()));
    lod.counts.active = 0;
    lod.counts.near = 0;
    lod.counts.far = 0;
    (0, daytime_1.stepDay)(w, dt);
    (0, tasks_1.runScheduled)(w);
    // Catch up the player's current area if it has been idle (Far -> Active transition)
    const pl = (0, world_1.player)(w);
    const curArea = pl ? (0, world_1.areaOf)(w, pl) : null;
    if (curArea) {
        if (w.time - curArea.lastTicked > Math.max(dt * 2, 0.5)) {
            (0, lod_1.catchUpArea)(w, curArea);
        }
        curArea.advanceRitual(dt);
        curArea.lastTicked = w.time;
    }
    // Deterministic actor stepping ordered by id with LOD tiering
    const ordered = w.actors.length <= 1 ? w.actors : [...w.actors].sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
    for (const a of ordered) {
        const { tier, stepDt } = (0, lod_1.actorStepDt)(w, a, dt);
        lod.counts[tier]++;
        if (stepDt <= 0)
            continue;
        (0, gear_1.reconcileGear)(w, a);
        (0, inventory_1.reconcileCapacity)(w, a);
        if (a.id !== w.playerId) {
            (0, tasks_1.tickTask)(w, a, stepDt);
            (0, jobs_1.tickJob)(w, a, stepDt);
        }
    }
    // townsfolk live by their routines (sim/folk.ts): LOD-tiered in player's area, caught up on entry elsewhere
    (0, folk_1.tickFolk)(w, dt);
    // shopkeepers keep their counters and their hours (sim/shops.ts): stepped in the room the golem is in
    (0, shops_1.tickKeepers)(w, dt);
    // Inner-monologue event triggers see everything this step emitted (sim/monologue.ts).
    (0, monologue_1.reactToEvents)(w);
    lod.tick++;
}
// ---------------------------------------------------------------- locomotion
/** Limping golem locomotion with wall sliding and corner nudging. */
function move(w, area, pl, dt, ix, iy, base, noclip = false) {
    const mag = Math.hypot(ix, iy);
    if (mag > 0) {
        ix /= mag;
        iy /= mag;
        pl.facing = Math.abs(ix) > Math.abs(iy) ? (ix > 0 ? "right" : "left") : iy > 0 ? "down" : "up";
    }
    const limp = 0.55 + 0.6 * Math.abs(Math.sin(pl.phase));
    const tx = ix * base * limp, ty = iy * base * limp;
    const acc = mag > 0 ? 7 : 10;
    pl.vx += (tx - pl.vx) * Math.min(1, acc * dt);
    pl.vy += (ty - pl.vy) * Math.min(1, acc * dt);
    const sp = Math.hypot(pl.vx, pl.vy);
    pl.moving = sp > 4;
    // Other actors' bodies (NPCs) block like props do.
    const bodies = (0, collision_1.actorBoxes)(w, area.id, pl.id);
    const boxFree = noclip
        ? (a, x, y) => x > 2 && y > 6 && x < a.w * tiles_1.TS - 2 && y < a.h * tiles_1.TS - 1
        : (a, x, y) => (0, collision_1.boxFree)(a, x, y, bodies, (0, actors_1.actorDef)(pl).body.box);
    const nx = pl.x + pl.vx * dt;
    if (boxFree(area, nx, pl.y))
        pl.x = nx;
    else {
        if (Math.abs(iy) < 0.3 && ix !== 0)
            for (const d of [2, 4, 6, 8]) {
                if (boxFree(area, nx, pl.y - d)) {
                    pl.y -= Math.min(d, 20 * dt);
                    break;
                }
                if (boxFree(area, nx, pl.y + d)) {
                    pl.y += Math.min(d, 20 * dt);
                    break;
                }
            }
        pl.vx *= 0.3;
    }
    const ny = pl.y + pl.vy * dt;
    if (boxFree(area, pl.x, ny))
        pl.y = ny;
    else {
        if (Math.abs(ix) < 0.3 && iy !== 0)
            for (const d of [2, 4, 6, 8]) {
                if (boxFree(area, pl.x - d, ny)) {
                    pl.x -= Math.min(d, 20 * dt);
                    break;
                }
                if (boxFree(area, pl.x + d, ny)) {
                    pl.x += Math.min(d, 20 * dt);
                    break;
                }
            }
        pl.vy *= 0.3;
    }
    if (pl.moving) {
        const before = Math.sin(pl.phase);
        pl.phase += dt * (3.2 + sp * 0.09);
        const after = Math.sin(pl.phase);
        if ((before < 0) !== (after < 0)) {
            pl.steps++;
            (0, world_1.emit)(w, { t: "step", actor: pl.id, heavy: pl.steps % 2 === 0 });
        }
    }
    else
        pl.phase = pl.phase % Math.PI < 0.2 ? pl.phase : pl.phase + dt * 2;
}
