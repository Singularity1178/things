"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.meets = exports.findScanTarget = exports.allInteractables = void 0;
exports.interactables = interactables;
exports.scanTargets = scanTargets;
exports.npcInteractables = npcInteractables;
exports.findTarget = findTarget;
exports.findTargetIn = findTargetIn;
exports.interact = interact;
exports.startSlam = startSlam;
// Interactables are *derived* from area state (props, loose items, tiles,
// ritual) and cached on the area's revision, so no call site has to remember
// to rebuild them after changing the world.
const folk_1 = require("./folk");
const shops_1 = require("./shops");
const tiles_1 = require("../content/tiles");
const props_1 = require("../content/props");
const harvest_1 = require("../content/harvest");
const runes_1 = require("../content/runes");
const items_1 = require("../content/items");
const interactions_1 = require("../content/interactions");
const ritual_1 = require("../content/ritual");
const world_1 = require("../world/world");
const flags_1 = require("../content/flags");
const npcs_1 = require("../content/npcs");
const requirements_1 = require("./requirements");
Object.defineProperty(exports, "meets", { enumerable: true, get: function () { return requirements_1.meets; } });
const tasks_1 = require("./tasks");
const actors_1 = require("../content/actors");
const analysis_1 = require("./analysis");
const digging_1 = require("../content/digging");
const digging_2 = require("./digging");
const runes_2 = require("./runes");
const cache = new WeakMap();
function interactables(area) {
    const c = cache.get(area);
    if (c && c.rev === area.interactionRevision)
        return c.list;
    const list = deriveInteractables(area);
    cache.set(area, { rev: area.interactionRevision, list });
    return list;
}
function deriveInteractables(area) {
    const I = [];
    for (const p of area.props) {
        if (p.kind === "pedestal")
            continue;
        const def = (0, props_1.propDef)(p.kind);
        if (def.rune) {
            // The dungeon circle only becomes a usable rune once its core is seated (before that its centre is the "center" spot).
            if (!(area.ritual && !area.ritual.core))
                I.push({ kind: "rune", x: p.x, y: p.y, r: 18, propId: p.id });
            continue;
        }
        // Standing trees, rocks and logs are not interactables (so not in the golem's vision either): they are harvested by slamming near them (sim/tasks.ts, op "slam").
        if (harvest_1.HARVEST[p.kind] && !p.taken)
            continue;
        // A dig site (the buried stair) is dug with E until it is through; open, it is only walked into (sim/portals.ts).
        const dig = digging_1.DIG_SITES[p.kind];
        if (dig) {
            if (!p.open && (0, digging_1.digLayerAt)(dig, p.dmg))
                I.push({ kind: "dig", x: p.x, y: p.y + dig.dy, r: dig.reach, propId: p.id });
            continue;
        }
        if (def.storage) {
            I.push({ kind: "storage", x: p.x, y: p.y + 2, r: (0, props_1.propReach)(p.kind) + 2, propId: p.id });
            continue;
        }
        // A station is used once nothing rests on it: the dungeon workbench hands over its chisel first (the tutorial
        // needs that), then works as a bench. Built benches carry no item, so they are stations straight away.
        if (def.station && !(p.item && !p.container && !p.taken)) {
            I.push({ kind: "station", x: p.x, y: p.y + 2, r: (0, props_1.propReach)(p.kind) + 2, propId: p.id });
            continue;
        }
        if (def.examine) {
            I.push({ kind: "examine", x: p.x, y: p.y + 2, r: (0, props_1.propReach)(p.kind) + 4, propId: p.id });
            continue;
        }
        const r = (0, props_1.propReach)(p.kind);
        if (p.container && !p.open)
            I.push({ kind: "container", x: p.x, y: p.y + 2, r, propId: p.id, itemZ: p.itemZ, hasItem: !!p.item });
        else if (p.item && !p.container && !p.taken)
            I.push({ kind: "propItem", x: p.x, y: p.y + 2, r, propId: p.id, itemZ: p.itemZ, hasItem: true });
    }
    for (const l of area.loose)
        if (!l.taken)
            I.push({ kind: "item", x: l.x, y: l.y, r: 16, looseId: l.id, hasItem: true });
    for (let ty = 0; ty < area.h; ty++)
        for (let tx = 0; tx < area.w; tx++) {
            const t = area.grid[ty * area.w + tx];
            const def = tiles_1.TILE_INTERACT[t];
            if (!def)
                continue;
            if (def.anchorTopOfRun && area.tile(tx, ty - 1) === t)
                continue;
            I.push({ kind: def.kind, x: tx * tiles_1.TS + def.dx, y: ty * tiles_1.TS + def.dy, r: def.r, tx, ty });
        }
    const r = area.ritual;
    if (r) {
        const c = area.ritualPos;
        (0, ritual_1.socketPositions)(c).forEach((s, i) => I.push({ kind: "socket", x: s.x, y: s.y + ritual_1.RITUAL_SPOTS.socket.dy, r: ritual_1.RITUAL_SPOTS.socket.r, socket: i }));
        if (!r.core)
            I.push({ kind: "center", x: c.x, y: c.y, r: ritual_1.RITUAL_SPOTS.center.r });
        if (!r.carved)
            I.push({ kind: "gap", x: c.x + ritual_1.RITUAL_SPOTS.gap.dx, y: c.y + ritual_1.RITUAL_SPOTS.gap.dy, r: ritual_1.RITUAL_SPOTS.gap.r });
    }
    return I;
}
const scanCache = new WeakMap();
/**
 * Buildable props as scan targets. They are deliberately not normal
 * interactables: E on furniture does nothing unless vision/scan mode is on.
 * `taken` is no reason to skip one: on a buildable it only means the item that
 * rested on it was picked up (the workbench's chisel, the library table's
 * Primer), and the furniture is still there to read. Cached on the same
 * revision as interactables because props move.
 */
function scanTargets(area) {
    const c = scanCache.get(area);
    if (c && c.rev === area.interactionRevision)
        return c.list;
    const list = [];
    for (const p of area.props) {
        if (!(0, analysis_1.buildRows)(p.kind).length)
            continue;
        list.push({ kind: "buildable", x: p.x, y: p.y + 2, r: (0, props_1.propReach)(p.kind) + 2, propId: p.id });
    }
    scanCache.set(area, { rev: area.interactionRevision, list });
    return list;
}
/**
 * Interactables derived from the NPC actors standing in an area (actors live on
 * the World, not the Area, so these are not part of the area's cached list).
 * One generic path for every NPC: the talk target carries the actor id and the
 * NpcDef id; the "npc" rules (content/interactions.ts) decide the work.
 */
function npcInteractables(w, area) {
    const out = [];
    for (const a of w.actors) {
        if (a.id === w.playerId || a.area !== area.id)
            continue;
        const d = (0, actors_1.actorDef)(a).body;
        if (!(0, folk_1.folkPresent)(a) || !(0, shops_1.keeperPresent)(a))
            continue; // a townsperson indoors, a keeper out of hours: not there to talk to
        const kind = (0, actors_1.capable)(a, "worker") ? "worker" : (0, npcs_1.npcDef)(a.npc) ? "npc" : (0, folk_1.isFolk)(a) ? "folk" : (0, shops_1.isKeeper)(a) ? "keeper" : null;
        // a keeper is spoken to across the counter
        if (kind)
            out.push({ kind, x: a.x, y: a.y + 2, r: kind === "keeper" ? shops_1.KEEPER_REACH : d.reach, itemZ: d.height - 12, actorId: a.id, npc: a.npc });
    }
    return out;
}
/** Everything the golem could interact with in an area: area-derived plus NPCs. */
const allInteractables = (w, area) => [...interactables(area), ...npcInteractables(w, area)];
exports.allInteractables = allInteractables;
/** Closest interactable in front of the actor, within its reach radius (`extra`: NPC interactables). */
function findTarget(area, a, extra = []) {
    return findTargetIn([...interactables(area), ...extra], a);
}
/** The buildable prop in front of the actor, used only while scan mode is on. */
const findScanTarget = (area, a) => findTargetIn(scanTargets(area), a);
exports.findScanTarget = findScanTarget;
/** findTarget's geometry over any list (scan targets use their own list). */
function findTargetIn(list, a, accept = () => true) {
    const fx = a.facing === "left" ? -1 : a.facing === "right" ? 1 : 0;
    const fy = a.facing === "up" ? -1 : a.facing === "down" ? 1 : 0;
    const px = a.x + fx * 6, py = a.y - 3 + fy * 6;
    let best = null, bd = 1;
    for (const it of list) {
        if (!accept(it))
            continue;
        const d = Math.hypot(it.x - px, it.y - py) / it.r;
        if (d < bd) {
            bd = d;
            best = it;
        }
    }
    return best;
}
const pick = (w, a, rules) => rules.find((r) => (0, requirements_1.meets)(w, a, r.when));
/** Start the work implied by interacting with `it`. Returns a UI request if a choice is needed first. */
function interact(w, a, area, it) {
    if (a.task || a.area !== area.id)
        return null;
    (0, tasks_1.faceTo)(a, it.x, it.y - 4);
    const scan = (0, analysis_1.scanSpec)(a, it.propId ? area.prop(it.propId) : undefined);
    if (scan) {
        (0, tasks_1.beginTask)(a, scan, it);
        return null;
    }
    let rules = interactions_1.RULES[it.kind];
    if (it.kind === "socket") {
        const filled = (area.ritual?.sockets[it.socket] ?? -1) >= 0;
        if (!filled && a.inventory.some((s) => s && (0, items_1.isGlyph)(s.item)))
            return { ui: "selectGlyph", socket: it.socket };
        rules = filled ? interactions_1.RULES.socketFilled : interactions_1.RULES.socketEmpty;
    }
    if (it.kind === "dig") {
        const key = (0, digging_2.digRules)(area, it.propId);
        rules = key ? interactions_1.RULES[key] : [];
    }
    let first = false;
    if (it.kind === "rune") {
        // A rune carries only while it is lit and something answers it (sim/runes.ts); otherwise E gets its refusal.
        const node = (0, runes_1.runeAt)(area.id, it.propId), state = node ? (0, runes_2.runeState)(w, node) : "dormant";
        if (state !== "linked")
            rules = state === "severed" ? interactions_1.RULES.runeSevered : interactions_1.RULES.runeDormant;
        else
            first = !(0, world_1.hasFlag)(w, flags_1.FLAGS.tutorialDone);
    }
    const rule = rules && pick(w, a, rules);
    if (!rule)
        return null;
    const { r: _r, itemZ: _z, hasItem: _h, ...target } = it;
    (0, tasks_1.beginTask)(a, rule.task, target);
    if (rule.task.kind === "channel")
        (0, world_1.emit)(w, { t: "teleport", actor: a.id, first, x: it.x, y: it.y });
    return null;
}
/**
 * Start the attack: the two-arm ground slam, separate from interacting. It
 * needs only what interacting needs (no task in progress), so it works
 * anywhere, facing anything, with or without the iron arm. Nothing is aimed or
 * chosen here: the blow is an area one around where the fists land (the task's
 * target is just that ground), and what it reaches is looked up when it lands
 * (sim/tasks.ts, op "slam"). With nothing in range, the slam still plays in
 * full and only strikes the ground.
 */
function startSlam(a) {
    if (a.task || !(0, actors_1.capable)(a, "attack"))
        return false;
    const at = (0, tasks_1.strikePoint)(a);
    (0, tasks_1.beginTask)(a, { ...interactions_1.SLAM_TASK, effect: { op: "slam" } }, { kind: "ground", x: at.x, y: at.y });
    return true;
}
