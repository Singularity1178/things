"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TRANSFER_TEXT = exports.ORDER_TEXT = exports.STORE_TEXT = void 0;
exports.dropFromSlot = dropFromSlot;
exports.wearFromSlot = wearFromSlot;
exports.takeOffGear = takeOffGear;
exports.orderBuild = orderBuild;
exports.orderDeconstruct = orderDeconstruct;
exports.readItem = readItem;
exports.orderCoreSwap = orderCoreSwap;
exports.coreTargetFor = coreTargetFor;
exports.coreKey = coreKey;
exports.moveStorageSlot = moveStorageSlot;
exports.renameStorage = renameStorage;
exports.giveWorkerOrder = giveWorkerOrder;
exports.controlWorker = controlWorker;
exports.renameActor = renameActor;
exports.transferWithActor = transferWithActor;
exports.equipActor = equipActor;
exports.unequipActor = unequipActor;
// Commands issued by UI screens (pack, build placement, reading). Each one
// validates and then goes through the normal Task/Effect path, so it is data,
// saveable and testable headless.
const items_1 = require("../content/items");
const props_1 = require("../content/props");
const build_1 = require("../content/build");
const interactions_1 = require("../content/interactions");
const actors_1 = require("../content/actors");
const world_1 = require("../world/world");
const power_1 = require("./power");
const inventory_1 = require("./inventory");
const interact_1 = require("./interact");
const tasks_1 = require("./tasks");
const build_2 = require("./build");
const inventory_2 = require("./inventory");
const collision_1 = require("./collision");
const tasks_2 = require("./tasks");
const gear_1 = require("./gear");
const storage_1 = require("./storage");
const jobs_1 = require("./jobs");
const actorStats_1 = require("./actorStats");
const messages_1 = require("./messages");
const orders_1 = require("./orders");
/**
 * Drop one unit from a slot (pack open, world paused). Applied immediately via
 * applyEffect so the result is visible at once; NPCs can queue the same
 * `{op: "drop"}` effect as a task.
 */
function dropFromSlot(w, a, slot, n = 1) {
    const s = a.inventory[slot];
    if (!s)
        return "empty";
    if (!(0, items_1.isDroppable)(s.item)) {
        (0, world_1.emit)(w, { t: "message", text: "THAT IS TOO IMPORTANT TO DROP" });
        return "undroppable";
    }
    if (!(0, inventory_2.dropSpot)((0, world_1.areaOf)(w, a), a, (0, collision_1.actorBoxes)(w, a.area, a.id))) {
        (0, world_1.emit)(w, { t: "message", text: "NO ROOM TO DROP IT HERE" });
        return "noRoom";
    }
    (0, tasks_1.applyEffect)(w, a, { op: "drop", slot, n });
    return "ok";
}
/**
 * Put on the gear in a pack slot (pack open, world paused), applied at once
 * like dropping: the basket goes onto the golem's back and the pack grows, a
 * rune goes into a rune slot. With no usable slot for it, it is refused.
 * NPCs can queue the same `{op: "wear"}` effect as a task.
 */
function wearFromSlot(w, a, slot, into) {
    const chk = (0, gear_1.wearCheck)(w, a, slot, into);
    if (!chk.ok) {
        if (chk.reason !== "empty")
            (0, world_1.emit)(w, { t: "message", text: (0, gear_1.gearRefusal)(chk) });
        return chk.reason;
    }
    (0, tasks_1.applyEffect)(w, a, { op: "wear", slot, into });
    return "ok";
}
/**
 * Take off what is worn in a gear slot, back into the pack. Refused, with a
 * message and no change at all, unless everything (the item itself included)
 * still fits once the pack shrinks. Nothing is ever dropped by it.
 */
function takeOffGear(w, a, gear) {
    const chk = (0, gear_1.takeOffCheck)(w, a, gear);
    if (!chk.ok) {
        if (chk.reason !== "empty")
            (0, world_1.emit)(w, { t: "message", text: (0, gear_1.gearRefusal)(chk) });
        return chk.reason;
    }
    (0, tasks_1.applyEffect)(w, a, { op: "takeOff", gear });
    return "ok";
}
/** Confirm a placement: start the build task (the effect re-validates when it fires). */
function orderBuild(w, a, recipe, tx, ty) {
    const ok = (0, build_2.placement)(w, a, (0, world_1.areaOf)(w, a), recipe, tx, ty);
    if (!ok.ok) {
        (0, world_1.emit)(w, { t: "message", text: build_2.BLOCK_TEXT[ok.reason] });
        return false;
    }
    const at = (0, build_2.recipeAnchor)(recipe, tx, ty);
    (0, tasks_2.faceTo)(a, at.x, at.y - 4);
    (0, tasks_1.beginTask)(a, { kind: "reach", dur: build_1.RECIPES[recipe].dur ?? 0.7, effect: { op: "build", recipe, tx, ty } }, { kind: "build", x: at.x, y: at.y, tx, ty });
    return true;
}
/**
 * Confirm a deconstruction: start a `dismantle` task aimed at the prop. The
 * `deconstruct` effect re-validates when it fires and refunds the full cost.
 */
function orderDeconstruct(w, a, propId) {
    const chk = (0, build_2.deconstructCheck)(w, a, (0, world_1.areaOf)(w, a), propId);
    if (!chk.ok) {
        (0, world_1.emit)(w, { t: "message", text: (0, build_2.deconMessage)(chk) });
        return false;
    }
    const p = chk.prop;
    (0, tasks_2.faceTo)(a, p.x, p.y - 4);
    (0, tasks_1.beginTask)(a, { kind: "dismantle", dur: build_1.DECONSTRUCT_DUR, effect: { op: "deconstruct" } }, { kind: "deconstruct", x: p.x, y: p.y, propId: p.id });
    return true;
}
/** Reading a book or document: grants its knowledge flag (once). */
function readItem(w, a, id) {
    const g = items_1.ITEMS[id].book?.grants;
    if (g)
        (0, tasks_1.applyEffect)(w, a, { op: "learn", flag: g });
}
/**
 * Order a power-core swap on the body `targetId`: slot `item` from the pack, or
 * take its core out (`item: null`). Validates now (same area, a body that takes
 * cores, the core carried and fitting, something to take out) and starts the
 * short CORE_TASK whose `slotCore` effect re-validates reach and sight when it
 * lands (sim/power.ts: applySlotCore). The one entry point for both ways: the C
 * key and the worker management screen (screens/manage.ts). The reach that
 * opened that screen may still be finishing beneath it (it already fired), so
 * it does not count as busy, as for a crafting bench.
 */
function orderCoreSwap(w, a, targetId, item) {
    const target = (0, world_1.actorById)(w, targetId);
    const opening = !!a.task?.fired && a.task.effect?.op === "manageActor";
    if ((a.task && !opening) || !target || target.id === a.id || target.area !== a.area || !(0, actors_1.actorDef)(target).power)
        return false;
    if (item && !((0, power_1.coreCheck)(target, item).accepts && (0, inventory_1.countItem)(a, item) > 0)) {
        (0, world_1.emit)(w, { t: "message", text: power_1.CORE_TEXT.noCore });
        return false;
    }
    if (!item && !target.powerCore) {
        (0, world_1.emit)(w, { t: "message", text: power_1.CORE_TEXT.empty });
        return false;
    }
    (0, tasks_2.faceTo)(a, target.x, target.y - 6);
    (0, tasks_1.beginTask)(a, { ...interactions_1.CORE_TASK, effect: { op: "slotCore", item } }, { kind: "core", x: target.x, y: target.y, actorId: target.id });
    return true;
}
/** The body in front of `a` that takes a power core (any actor whose definition needs power), within its reach. */
function coreTargetFor(w, a, area) {
    const bodies = w.actors.filter((x) => x.id !== a.id && x.area === area.id && !!(0, actors_1.actorDef)(x).power)
        .map((x) => ({ kind: "core", x: x.x, y: x.y + 2, r: (0, actors_1.actorDef)(x).body.reach, actorId: x.id }));
    const it = (0, interact_1.findTargetIn)(bodies, a);
    return it?.actorId ? (0, world_1.actorById)(w, it.actorId) : undefined;
}
/**
 * The C key on the play screen: a deliberate input of its own, never E (E on
 * the guardian always talks). Facing a body that takes cores, it takes the core
 * out if there is one, else slots the first fitting core carried. Nothing in
 * front: nothing happens. Returns whether work started.
 */
function coreKey(w, a, area) {
    if (a.task)
        return false;
    const target = coreTargetFor(w, a, area);
    if (!target)
        return false;
    const act = (0, power_1.coreActionFor)(a, target);
    if (act.op === "none") {
        (0, world_1.emit)(w, { t: "message", text: power_1.CORE_TEXT.noCore });
        return false;
    }
    return orderCoreSwap(w, a, target.id, act.op === "insert" ? act.item : null);
}
exports.STORE_TEXT = {
    empty: "NOTHING THERE TO MOVE",
    critical: "TOO IMPORTANT TO STORE",
    gone: "THE STORAGE IS GONE",
    far: "STEP UP TO THE STORAGE",
    chestFull: "THE STORAGE IS FULL",
    packFull: "YOUR PACK IS FULL",
};
/**
 * The storage screen's one move: up to `n` of what pack slot `slot` holds into
 * the storage prop (`store`), or out of its slot into the pack (`take`). Applied
 * at once, like dropping, through sim/storage.ts: as much as fits moves, the
 * rest stays where it was, and a refusal changes nothing. Items the golem can't
 * even drop (the tutorial's) are never stored, so progress can't be put out of
 * reach. Says what happened as a player message and returns it.
 */
function moveStorageSlot(w, a, propId, dir, slot, n) {
    const out = (result, moved, text) => { (0, messages_1.actorMessage)(w, a, text); return { result, moved, text }; };
    const area = (0, world_1.areaOf)(w, a), p = area.prop(propId);
    if (!p?.inventory || !(0, props_1.propDef)(p.kind).storage)
        return out("gone", 0, exports.STORE_TEXT.gone);
    if (Math.hypot(a.x - p.x, a.y - p.y) > (0, props_1.propReach)(p.kind) + 8)
        return out("far", 0, exports.STORE_TEXT.far);
    const chest = (0, storage_1.storageRef)(area.id, p.id), pack = (0, storage_1.packRef)(a);
    const from = dir === "store" ? pack : chest, to = dir === "store" ? chest : pack;
    const s = (0, storage_1.inventoryHandle)(w, from)?.inventory[slot];
    if (!s)
        return out("empty", 0, exports.STORE_TEXT.empty);
    if (dir === "store" && !(0, items_1.isDroppable)(s.item))
        return out("critical", 0, exports.STORE_TEXT.critical);
    const item = s.item, want = Math.max(1, Math.min(Math.floor(n), s.n));
    const moved = (0, storage_1.transferSlot)(w, from, to, slot, want), verb = dir === "store" ? "STORED" : "TOOK";
    const full = dir === "store" ? exports.STORE_TEXT.chestFull : exports.STORE_TEXT.packFull;
    if (!moved)
        return out("full", 0, full);
    if (moved < want)
        return out("partial", moved, `${verb} ${moved} OF ${want} ${items_1.ITEM_NAMES[item]}. ${full}`);
    return out("ok", moved, `${verb} ${moved} ${items_1.ITEM_NAMES[item]}`);
}
/**
 * Rename the storage prop `propId` in the player's area: `name` cleaned (cleanPropName), or empty to go back to
 * its default label ("DUNGEON CHEST 2"). The name is the prop's own (saved with it), so the storage screen and
 * every order that points at the chest show it. Needs the golem beside it, as the screen does. Says what happened.
 */
function renameStorage(w, a, propId, name) {
    const say = (ok, text) => { (0, messages_1.actorMessage)(w, a, text); return { ok, text }; };
    const area = (0, world_1.areaOf)(w, a), p = area.prop(propId);
    if (!p?.inventory || !(0, props_1.propDef)(p.kind).storage)
        return say(false, exports.STORE_TEXT.gone);
    if (Math.hypot(a.x - p.x, a.y - p.y) > (0, props_1.propReach)(p.kind) + 8)
        return say(false, exports.STORE_TEXT.far);
    const clean = (0, orders_1.cleanPropName)(name);
    if (!clean || clean === (0, orders_1.defaultPropName)(area, p)) {
        area.setPropName(p.id, undefined);
        return say(true, `NAMED ${(0, orders_1.propName)(area, p)}`);
    }
    area.setPropName(p.id, clean);
    return say(true, `NAMED ${clean}`);
}
exports.ORDER_TEXT = { given: "ORDER GIVEN", waits: "ORDER GIVEN. IT WAITS FOR A CORE" };
/**
 * Give a worker an order from the management screen: setWorkerOrder, with its
 * refusal (out of reach, no sight, not a worker, unknown or invalid order, can't
 * do that work, busy) said in words. The order replaces the one it had.
 */
function giveWorkerOrder(w, a, targetId, order) {
    const why = (0, jobs_1.orderRefusal)(w, a, targetId, order);
    if (why) {
        (0, messages_1.actorMessage)(w, a, why);
        return { ok: false, text: why };
    }
    const target = (0, world_1.actorById)(w, targetId);
    if (!(0, jobs_1.setWorkerOrder)(w, a, targetId, order)) {
        const text = "IT WILL NOT TAKE THE ORDER";
        (0, messages_1.actorMessage)(w, a, text);
        return { ok: false, text };
    }
    const text = (0, actorStats_1.powered)(target) ? exports.ORDER_TEXT.given : exports.ORDER_TEXT.waits;
    (0, messages_1.actorMessage)(w, a, text);
    return { ok: true, text };
}
/** Pause, resume (or retry a blocked order) or cancel a worker's order: pauseJob / resumeJob / setWorkerOrder(null), behind the same reach and sight rules. */
function controlWorker(w, a, targetId, what) {
    const say = (ok, text) => { (0, messages_1.actorMessage)(w, a, text); return { ok, text }; };
    const why = (0, jobs_1.workerRefusal)(w, a, targetId);
    if (why)
        return say(false, why);
    const target = (0, world_1.actorById)(w, targetId), job = target.job;
    if (!job)
        return say(false, "IT HAS NO ORDER");
    if (what === "cancel") {
        (0, jobs_1.setWorkerOrder)(w, a, targetId, null);
        return say(true, "ORDER CANCELLED");
    }
    if (job.status === "done")
        return say(false, "THAT ORDER IS DONE");
    if (what === "pause") {
        if (job.status === "paused" && job.reason === "manual")
            return say(false, "IT IS ALREADY PAUSED");
        (0, jobs_1.pauseJob)(w, target);
        return say(true, "ORDER PAUSED");
    }
    if (job.status === "running")
        return say(false, "IT IS ALREADY WORKING");
    (0, jobs_1.resumeJob)(w, target);
    return say(true, (0, actorStats_1.powered)(target) ? "ORDER RESUMED" : "NO POWER. IT WAITS FOR A CORE");
}
// ---------------------------------------------------------------- naming and transfer
/**
 * Give an orderable body (a worker) a name of its own, or clear it (empty). The name goes in front of its kind
 * everywhere it is shown ("BOB - WORKER GOLEM"). Needs the commander within reach and in sight, as the orders do.
 */
function renameActor(w, a, targetId, name) {
    const say = (ok, text) => { (0, messages_1.actorMessage)(w, a, text); return { ok, text }; };
    const why = (0, jobs_1.workerRefusal)(w, a, targetId);
    if (why)
        return say(false, why);
    const target = (0, world_1.actorById)(w, targetId), clean = (0, actorStats_1.cleanActorName)(name);
    if (clean)
        target.name = clean;
    else
        delete target.name;
    return say(true, clean ? `NAMED ${(0, actorStats_1.actorLabel)(target)}` : `NAME CLEARED`);
}
exports.TRANSFER_TEXT = {
    empty: "NOTHING THERE TO MOVE",
    critical: "TOO IMPORTANT TO GIVE AWAY",
    theirFull: "ITS PACK IS FULL",
    packFull: "YOUR PACK IS FULL",
    noWear: "IT CAN'T WEAR THAT",
};
/**
 * The transfer screen's move: up to `n` of what slot `slot` holds goes from the commander's pack to the worker's
 * (`give`) or from the worker's to the commander's (`take`). As much as fits moves, the rest stays; a refusal
 * changes nothing. Items the golem can't even drop (the tutorial's) are never given away.
 */
function transferWithActor(w, a, targetId, dir, slot, n) {
    const out = (ok, moved, text) => { (0, messages_1.actorMessage)(w, a, text); return { ok, moved, text }; };
    const why = (0, jobs_1.workerRefusal)(w, a, targetId);
    if (why)
        return out(false, 0, why);
    const target = (0, world_1.actorById)(w, targetId);
    const from = dir === "give" ? (0, storage_1.packRef)(a) : (0, storage_1.packRef)(target), to = dir === "give" ? (0, storage_1.packRef)(target) : (0, storage_1.packRef)(a);
    const s = (0, storage_1.inventoryHandle)(w, from)?.inventory[slot];
    if (!s)
        return out(false, 0, exports.TRANSFER_TEXT.empty);
    if (dir === "give" && !(0, items_1.isDroppable)(s.item))
        return out(false, 0, exports.TRANSFER_TEXT.critical);
    const item = s.item, want = Math.max(1, Math.min(Math.floor(n), s.n));
    const moved = (0, storage_1.transferSlot)(w, from, to, slot, want), full = dir === "give" ? exports.TRANSFER_TEXT.theirFull : exports.TRANSFER_TEXT.packFull;
    if (!moved)
        return out(false, 0, full);
    const verb = dir === "give" ? "GAVE" : "TOOK";
    if (moved < want)
        return out(true, moved, `${verb} ${moved} OF ${want} ${items_1.ITEM_NAMES[item]}. ${full}`);
    return out(true, moved, `${verb} ${moved} ${items_1.ITEM_NAMES[item]}`);
}
/**
 * Put gear on the worker (a rune into its rune slot). `from` says whose pack slot `slot` is: the commander's (one
 * of the stack goes across first) or the worker's own. If it can't be worn the item goes back where it came from
 * and nothing changes.
 */
function equipActor(w, a, targetId, from, slot) {
    const out = (ok, text) => { (0, messages_1.actorMessage)(w, a, text); return { ok, moved: ok ? 1 : 0, text }; };
    const why = (0, jobs_1.workerRefusal)(w, a, targetId);
    if (why)
        return out(false, why);
    const target = (0, world_1.actorById)(w, targetId);
    const src = from === "pack" ? a : target, s = src.inventory[slot];
    if (!s)
        return out(false, exports.TRANSFER_TEXT.empty);
    const item = s.item;
    if (!items_1.ITEMS[item].wear || !(0, gear_1.slotsFor)(w, target, item).length)
        return out(false, exports.TRANSFER_TEXT.noWear);
    let at = slot;
    if (from === "pack") {
        if (!(0, items_1.isDroppable)(item))
            return out(false, exports.TRANSFER_TEXT.critical);
        if (!(0, storage_1.transferSlot)(w, (0, storage_1.packRef)(a), (0, storage_1.packRef)(target), slot, 1))
            return out(false, exports.TRANSFER_TEXT.theirFull);
        at = target.inventory.findIndex((x) => x?.item === item);
    }
    const chk = (0, gear_1.wearCheck)(w, target, at);
    if (!chk.ok) {
        if (from === "pack")
            (0, storage_1.transferSlot)(w, (0, storage_1.packRef)(target), (0, storage_1.packRef)(a), at, 1);
        return out(false, (0, gear_1.gearRefusal)(chk));
    }
    (0, tasks_1.applyEffect)(w, target, { op: "wear", slot: at });
    return out(true, `${(0, actorStats_1.actorLabel)(target)} WEARS ${items_1.ITEM_NAMES[item]}`);
}
/** Take what the worker wears in `gear` off, into its own pack (refused, changing nothing, if it doesn't fit). */
function unequipActor(w, a, targetId, gear) {
    const out = (ok, text) => { (0, messages_1.actorMessage)(w, a, text); return { ok, moved: ok ? 1 : 0, text }; };
    const why = (0, jobs_1.workerRefusal)(w, a, targetId);
    if (why)
        return out(false, why);
    const target = (0, world_1.actorById)(w, targetId), chk = (0, gear_1.takeOffCheck)(w, target, gear);
    if (!chk.ok)
        return out(false, chk.reason === "empty" ? "NOTHING WORN THERE" : (0, gear_1.gearRefusal)(chk));
    (0, tasks_1.applyEffect)(w, target, { op: "takeOff", gear });
    return out(true, `TOOK OFF ${items_1.ITEM_NAMES[chk.item]}`);
}
