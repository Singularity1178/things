"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.actorMessage = actorMessage;
const world_1 = require("../world/world");
/** Keep legacy player messages unchanged, but never present off-screen work as
 * a player notification. The host filters actor-scoped events in one place. */
function actorMessage(w, a, text) {
    (0, world_1.emit)(w, { t: "message", text, ...(a.id === w.playerId ? {} : { actor: a.id }) });
}
