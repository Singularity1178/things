"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.relicCount = exports.relicFlag = void 0;
exports.rememberItem = rememberItem;
const items_1 = require("../content/items");
const inventoryOps_1 = require("./inventoryOps");
const relicFlag = (item) => `relic.found.${item}`;
exports.relicFlag = relicFlag;
function rememberItem(w, a, item) {
    if (a.id === w.playerId && items_1.ITEMS[item].tags.includes("relic"))
        w.flags.add((0, exports.relicFlag)(item));
}
/** Discovery, not possession: dropping or deconstructing a crown keeps credit. */
const relicCount = (w, a) => items_1.RELICS.filter((id) => w.flags.has((0, exports.relicFlag)(id)) || (0, inventoryOps_1.hasItem)(a, id)).length;
exports.relicCount = relicCount;
