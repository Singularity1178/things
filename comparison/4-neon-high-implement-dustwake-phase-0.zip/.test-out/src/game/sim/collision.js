"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.propBlocks = void 0;
exports.actorBox = actorBox;
exports.actorBoxes = actorBoxes;
exports.boxFree = boxFree;
exports.nearestFree = nearestFree;
// Collision queries shared by locomotion, drop placement, travel arrival and
// build placement. Pure sim.
const tiles_1 = require("../content/tiles");
const harvest_1 = require("../content/harvest");
const props_1 = require("../content/props");
const actors_1 = require("../content/actors");
/** Every actor has its definition's body, centred on x and ending at its feet. */
function actorBox(a) {
    // townsfolk are soft: they step out of the way themselves and never block anyone (sim/folk.ts)
    if (a.kind === "folk" || a.kind === "keeper")
        return null;
    const [w, h] = (0, actors_1.actorDef)(a).body.box;
    return [a.x - w / 2, a.y - h, a.x + w / 2, a.y];
}
/** Blocking bodies of the actors in an area, except one (usually the mover). */
function actorBoxes(w, areaId, except) {
    const out = [];
    for (const a of w.actors) {
        if (a.area !== areaId || a.id === except)
            continue;
        const b = actorBox(a);
        if (b)
            out.push(b);
    }
    return out;
}
/** Does this prop currently block movement / placement? */
const propBlocks = (p) => !!p.box && !(p.taken && harvest_1.HARVEST[p.kind]?.clearBox) && !((0, props_1.propDef)(p.kind).openBox && !p.open);
exports.propBlocks = propBlocks;
/** Is a golem-sized box (10x5 px, feet at x,y) free of solid tiles, props and the given actor bodies? */
function boxFree(area, x, y, bodies = [], size = [10, 5]) {
    const x0 = x - size[0] / 2, x1 = x + size[0] / 2, y0 = y - size[1], y1 = y;
    for (let ty = Math.floor(y0 / tiles_1.TS); ty <= Math.floor((y1 - 0.01) / tiles_1.TS); ty++)
        for (let tx = Math.floor(x0 / tiles_1.TS); tx <= Math.floor((x1 - 0.01) / tiles_1.TS); tx++) {
            if (tx < 0 || ty < 0 || tx >= area.w || ty >= area.h)
                return false;
            if ((0, tiles_1.isSolidT)(area.grid[ty * area.w + tx]))
                return false;
        }
    for (const p of area.props) {
        if (!(0, exports.propBlocks)(p))
            continue;
        const b = p.box;
        if (x1 > b[0] && x0 < b[2] && y1 > b[1] && y0 < b[3])
            return false;
    }
    for (const b of bodies)
        if (x1 > b[0] && x0 < b[2] && y1 > b[1] && y0 < b[3])
            return false;
    return true;
}
/**
 * Nearest free standing spot to (x, y): the spot itself, else rings of
 * candidates 8 px apart in a fixed order. Deterministic; null if nothing free
 * within ~6 tiles.
 */
function nearestFree(area, x, y, bodies = [], size = [10, 5]) {
    if (boxFree(area, x, y, bodies, size))
        return { x, y };
    for (let r = 1; r <= 12; r++) {
        for (let i = -r; i <= r; i++)
            for (const [dx, dy] of [[i, r], [i, -r], [r, i], [-r, i]]) {
                const px = x + dx * 8, py = y + dy * 8;
                if (boxFree(area, px, py, bodies, size))
                    return { x: px, y: py };
            }
    }
    return null;
}
