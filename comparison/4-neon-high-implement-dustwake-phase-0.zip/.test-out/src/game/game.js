"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Game = exports.UI2_H = exports.UI2_W = exports.ARRIVE = exports.viewSize = exports.ZOOM_DEFAULT = exports.ZOOM_STEPS = exports.H = exports.W = void 0;
// Host + presentation coordinator (split in Phase 0.6).
// Delegates world rendering (view/worldRenderer.ts), camera/zoom/shake
// (view/camera.ts), particles (view/particles.ts), event reactions
// (view/eventReactions.ts), fixed-timestep clock (sim/clock.ts), Input v2
// (ui/input.ts), Save v2 (view/saveStore.ts), Settings (settings.ts), and the
// 2x hi-res management UI shell (screens/managementHud.ts + modals).
const tiles_1 = require("./content/tiles");
const items_1 = require("./content/items");
const inventory_1 = require("./sim/inventory");
const gear_1 = require("./sim/gear");
const debug_1 = require("./sim/debug");
const debugFoundations_1 = require("./sim/debugFoundations");
const gear_2 = require("./content/gear");
const buildMenu_1 = require("./screens/buildMenu");
const crafting_1 = require("./screens/crafting");
const pack_1 = require("./screens/pack");
const storage_1 = require("./screens/storage");
const debug_2 = require("./screens/debug");
const manage_1 = require("./screens/manage");
const transfer_1 = require("./screens/transfer");
const book_1 = require("./screens/book");
const schematic_1 = require("./screens/schematic");
const dialogue_1 = require("./screens/dialogue");
const intro_1 = require("./screens/intro");
const crossing_1 = require("./screens/crossing");
const cutscenes_1 = require("./content/cutscenes");
Object.defineProperty(exports, "ARRIVE", { enumerable: true, get: function () { return cutscenes_1.ARRIVE; } });
const monologue_1 = require("./ui/monologue");
const monologue_2 = require("./sim/monologue");
const cards_1 = require("./screens/cards");
const props_1 = require("./content/props");
const vision_1 = require("./content/vision");
const flags_1 = require("./content/flags");
const portals_1 = require("./sim/portals");
const util_1 = require("./util");
const light_1 = require("./light");
const audio_1 = require("./audio");
const runeReveal_1 = require("./runeReveal");
const runes_1 = require("./content/runes");
const runes_2 = require("./sim/runes");
const runeFx_1 = require("./view/runeFx");
const font_1 = require("./font");
const world_1 = require("./world/world");
const step_1 = require("./sim/step");
const interact_1 = require("./sim/interact");
const lod_1 = require("./sim/lod");
const clock_1 = require("./sim/clock");
const areaView_1 = require("./view/areaView");
const screens_1 = require("./ui/screens");
const zoom_1 = require("./view/zoom");
Object.defineProperty(exports, "ZOOM_STEPS", { enumerable: true, get: function () { return zoom_1.ZOOM_STEPS; } });
Object.defineProperty(exports, "ZOOM_DEFAULT", { enumerable: true, get: function () { return zoom_1.ZOOM_DEFAULT; } });
Object.defineProperty(exports, "viewSize", { enumerable: true, get: function () { return zoom_1.viewSize; } });
const npcs_1 = require("./content/npcs");
const actors_1 = require("./content/actors");
const actors_2 = require("./view/actors");
const actorStats_1 = require("./sim/actorStats");
const workerAnim_1 = require("./workerAnim");
const audience_1 = require("./view/audience");
const vision_2 = require("./view/vision");
const dialogue_2 = require("./sim/dialogue");
const persistence_1 = require("./view/persistence");
const saveStore_1 = require("./view/saveStore");
const folk_1 = require("./sim/folk");
const shops_1 = require("./sim/shops");
const keeperArt_1 = require("./keeperArt");
const folkArt_1 = require("./folkArt");
const daycycle_1 = require("./content/daycycle");
const daytime_1 = require("./sim/daytime");
const camera_1 = require("./view/camera");
const particles_1 = require("./view/particles");
const worldRenderer_1 = require("./view/worldRenderer");
const eventReactions_1 = require("./view/eventReactions");
const settings_1 = require("./settings");
const input_1 = require("./ui/input");
Object.defineProperty(exports, "UI2_H", { enumerable: true, get: function () { return input_1.UI2_H; } });
Object.defineProperty(exports, "UI2_W", { enumerable: true, get: function () { return input_1.UI2_W; } });
const notifications_1 = require("./ui/notifications");
const managementHud_1 = require("./screens/managementHud");
const settingsModal_1 = require("./screens/settingsModal");
const saveModal_1 = require("./screens/saveModal");
const floorsModal_1 = require("./screens/floorsModal");
const components_1 = require("./ui/components");
const propFont_1 = require("./ui/propFont");
const DEBUG_SPEED_MULT = 3;
exports.W = zoom_1.BASE_W, exports.H = zoom_1.BASE_H;
const newSeed = () => (Math.random() * 4294967296) >>> 0;
class Game {
    // ---- Backwards-compatible accessors bridging extracted subsystems
    get cam() { return this.camera; }
    get vw() { return this.camera.vw; }
    set vw(v) { this.camera.vw = v; }
    get vh() { return this.camera.vh; }
    set vh(v) { this.camera.vh = v; }
    get zoom() { return this.camera.zoom; }
    set zoom(v) { this.camera.zoom = v; }
    get zoomAnim() { return this.camera.zoomAnim; }
    set zoomAnim(v) { this.camera.zoomAnim = v; }
    get shakeT() { return this.camera.shakeT; }
    set shakeT(v) { this.camera.shakeT = v; }
    get shakeMag() { return this.camera.shakeMag; }
    set shakeMag(v) { this.camera.shakeMag = v; }
    get particles() { return this.particleSys.list; }
    set particles(v) { this.particleSys.list = v; }
    get scene() { return this.renderer.scene; }
    get emit() { return this.renderer.emit; }
    get lighting() { return this.renderer.lighting; }
    get outImg() { return this.renderer.outImg; }
    get circle() { return this.renderer.circle; }
    get shaft() { return this.renderer.shaft; }
    get sunShaft() { return this.renderer.sunShaft; }
    get runeArt() { return this.renderer.runeArt; }
    constructor(canvas, uiCanvas, hiUiCanvas) {
        Object.defineProperty(this, "canvas", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: canvas
        });
        Object.defineProperty(this, "uiCanvas", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: uiCanvas
        });
        /** Base-size (320x180) UI layer for legacy screens. */
        Object.defineProperty(this, "ctx", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** World layer: lit scene sized to current view (vw x vh). */
        Object.defineProperty(this, "wctx", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** 2x hi-res UI layer (640x360) for Phase 0 management UI, tooltips, modals & mixed-case font. */
        Object.defineProperty(this, "hiCanvas", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "hiCtx", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Extracted Phase 0.6 subsystems. */
        Object.defineProperty(this, "camera", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new camera_1.Camera()
        });
        Object.defineProperty(this, "particleSys", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new particles_1.ParticleSystem()
        });
        Object.defineProperty(this, "renderer", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Phase 0.1 fixed-timestep clock & actor interpolation buffer. */
        Object.defineProperty(this, "clock", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new clock_1.SimClock()
        });
        Object.defineProperty(this, "interp", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new clock_1.InterpBuffer()
        });
        /** Phase 0.4, 0.5, 0.7 management subsystems. */
        Object.defineProperty(this, "settings", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: settings_1.settingsStore
        });
        Object.defineProperty(this, "store", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: saveStore_1.saveStore
        });
        Object.defineProperty(this, "input", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "feed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new notifications_1.NotificationFeed()
        });
        Object.defineProperty(this, "hud", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new managementHud_1.ManagementHud()
        });
        Object.defineProperty(this, "settingsModal", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new settingsModal_1.SettingsModal()
        });
        Object.defineProperty(this, "saveModal", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new saveModal_1.SaveModal()
        });
        Object.defineProperty(this, "floorsModal", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new floorsModal_1.FloorsModal()
        });
        /** Called when the view size changes (App refits canvases). */
        Object.defineProperty(this, "onView", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "npcLooks", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        Object.defineProperty(this, "bubbles", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        Object.defineProperty(this, "vision", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new vision_2.VisionView()
        });
        Object.defineProperty(this, "lastAnalyzed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { prop: "", t: -1 }
        });
        Object.defineProperty(this, "sfx", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new audio_1.Sfx()
        });
        Object.defineProperty(this, "world", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "view", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "screens", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new screens_1.ScreenStack()
        });
        Object.defineProperty(this, "t", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "toast", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "debugSpeed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "debugSpeedMult", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: DEBUG_SPEED_MULT
        });
        Object.defineProperty(this, "debugNoclip", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "debugHud", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "debugMsg", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "rumbleT", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 50
        });
        Object.defineProperty(this, "eyeBoost", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "crackFlash", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "shudder", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "fizzT", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "look", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { eye: 0, core: 0, dormant: 1, sparkT: 2, sputter: 0, z: 0 }
        });
        Object.defineProperty(this, "glight", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "keys", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Set()
        });
        Object.defineProperty(this, "pressed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Set()
        });
        Object.defineProperty(this, "dripT", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "target", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "uiTimers", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "S", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "note", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "tele", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { x: 0, y: 0, dur: 4.6, first: true, travelled: false }
        });
        Object.defineProperty(this, "arriveFade", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "doorFade", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "hideGolem", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "runeAnim", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "runeDud", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "buildUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "craftUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "packUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "storageUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "manageUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "transferUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "debugUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "bookUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "schemUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "dialogueUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "introUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "monologue", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new monologue_1.MonologueLog()
        });
        Object.defineProperty(this, "bars", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: { v: 0, to: 0 }
        });
        Object.defineProperty(this, "crossingUi", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "gaze", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        Object.defineProperty(this, "debugClock", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        Object.defineProperty(this, "skyT", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 3
        });
        Object.defineProperty(this, "typed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "autosaveTimer", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "lastSavedArea", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: ""
        });
        Object.defineProperty(this, "unsubSettings", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        // ---------------------------------------------------------------- update
        Object.defineProperty(this, "frameDt", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "visionArtCache", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
        });
        this.wctx = canvas.getContext("2d");
        this.wctx.imageSmoothingEnabled = false;
        this.ctx = uiCanvas.getContext("2d");
        this.ctx.imageSmoothingEnabled = false;
        if (hiUiCanvas) {
            this.hiCanvas = hiUiCanvas;
            this.hiCtx = hiUiCanvas.getContext("2d");
        }
        else {
            const c = (0, util_1.makeCanvas)(input_1.UI2_W, input_1.UI2_H);
            this.hiCanvas = c.c;
            this.hiCtx = c.ctx;
        }
        this.hiCtx.imageSmoothingEnabled = false;
        this.input = new input_1.InputManager(this.settings);
        this.renderer = new worldRenderer_1.WorldRenderer(this.wctx);
        this.camera.onResize = (w, h) => {
            this.renderer.resize(this.wctx, w, h);
            this.canvas.width = w;
            this.canvas.height = h;
            this.wctx.imageSmoothingEnabled = false;
            this.onView?.(w, h);
        };
        this.applySettings();
        this.unsubSettings = this.settings.onChange(() => this.applySettings());
        void this.store.migrateLegacyLocalStorage();
        this.makeScreens();
        this.reset();
        this.screens.set(this.S.title);
    }
    dispose() {
        this.unsubSettings?.();
        this.unsubSettings = null;
        this.view?.dispose();
    }
    applySettings() {
        const s = this.settings.data;
        this.sfx.setVolumes(s.masterVolume, s.sfxVolume, s.ambientVolume);
        (0, vision_2.setVisionPalette)(s.colorBlindPalette);
    }
    // ---------------------------------------------------------------- session
    reset(world = (0, world_1.createWorld)(newSeed())) {
        var _a;
        this.world = world;
        (_a = this.world).lod ?? (_a.lod = (0, lod_1.createLodConfig)());
        this.view?.dispose();
        const area = (0, world_1.currentArea)(world);
        this.view = new areaView_1.AreaView(area);
        this.schemUi.reset(world);
        const pl = (0, world_1.player)(world);
        this.glight = (0, light_1.makeLight)(pl.x, pl.y - 6, gear_2.GOLEM_LIGHT.rad, gear_2.GOLEM_LIGHT.col, 0, 0.05, "golem");
        this.dripT = area.drips.map(() => Math.random() * 4);
        this.look = { eye: 0, core: 0, dormant: 1, sparkT: 1.5, sputter: 0, z: 0 };
        this.camera.zoomAnim = null;
        this.setZoom((0, world_1.hasFlag)(world, flags_1.FLAGS.golemEye) ? zoom_1.ZOOM_DEFAULT : 1);
        this.camera.x = pl.x - this.vw / 2;
        this.camera.y = pl.y - this.vh / 2 - 10;
        this.npcLooks.clear();
        this.bubbles.clear();
        this.vision.reset(pl.mode === "scan");
        this.dialogueUi.reset();
        this.packUi.reset();
        this.storageUi.reset();
        this.manageUi.reset();
        this.transferUi.reset();
        this.particleSys.clear();
        this.toast = null;
        this.fizzT = 0;
        this.shudder = null;
        this.uiTimers = [];
        this.rumbleT = 45 + Math.random() * 30;
        this.note = null;
        this.arriveFade = 0;
        this.doorFade = 0;
        this.hideGolem = false;
        this.runeAnim = null;
        this.runeDud = null;
        this.gaze = null;
        this.skyT = 3;
        this.monologue.reset();
        this.bars = { v: 0, to: 0 };
        this.clock.reset();
        this.interp.clear();
        this.interp.capture(world);
        this.hud.selectedActors.clear();
        this.autosaveTimer = 0;
        this.lastSavedArea = area.id;
    }
    resume(world) {
        this.reset(world);
        this.look.dormant = 0;
        this.screens.set(this.S.play);
    }
    setSpeed(s) {
        this.clock.setSpeed(s);
        this.say(s === 0 ? "SIMULATION PAUSED" : `SPEED ${s}X`);
    }
    /** Save the world to both Save v2 store (`slot-1`) and legacy localStorage compatibility slot. */
    saveGame() {
        try {
            (0, persistence_1.saveToStorage)(this.world);
            void this.store.saveSlot("slot-1", this.world, "Quick Save (Slot 1)");
            this.say("GAME SAVED");
            this.sfx.tone(520, 0.1, "triangle", 0.05);
            this.notify({ title: "Game Saved", detail: `Saved ${(0, world_1.currentArea)(this.world).id} to Slot 1.`, severity: "success", category: "save", worldTime: this.world.time });
        }
        catch {
            this.say("COULD NOT SAVE");
            this.sfx.tone(180, 0.1, "square", 0.04);
        }
    }
    /** Trigger Save v2 autosave into the rolling `autosave` slot. */
    autosave(reason) {
        void this.store.saveSlot("autosave", this.world, `Autosave (${reason})`).then(() => {
            this.notify({ title: "Autosaved", detail: `${reason} (${(0, world_1.currentArea)(this.world).id})`, severity: "info", category: "save", worldTime: this.world.time });
        }).catch(() => { });
    }
    /** Load saved world synchronously from legacy storage (or asynchronously from Save v2 if empty). */
    loadGame() {
        let w = null;
        try {
            w = (0, persistence_1.loadFromStorage)();
        }
        catch {
            w = null;
        }
        if (w) {
            this.resume(w);
            this.say("GAME LOADED");
            return true;
        }
        // Async check Save v2 slot-1 / autosave in browser
        void this.store.loadSlot("slot-1").then(async (res) => res ?? this.store.loadSlot("autosave")).then((res) => {
            if (res) {
                this.resume(res.world);
                this.say(res.recoveredFrom ? `RECOVERED (${res.recoveredFrom.toUpperCase()})` : "GAME LOADED");
                if (res.warning)
                    this.notify({ title: "Save Recovered", detail: res.warning, severity: "warn", category: "save", worldTime: res.world.time });
            }
        }).catch(() => { });
        this.say("NO SAVED GAME");
        this.sfx.tone(180, 0.1, "square", 0.04);
        return false;
    }
    notify(opts) {
        const res = this.feed.push(opts, this.settings.data);
        if (res.pause && this.screens.is("play") && !this.clock.paused) {
            this.clock.setSpeed(0);
            this.say("PAUSED ON ALERT");
        }
    }
    syncView() {
        const area = (0, world_1.currentArea)(this.world);
        if (this.view.area === area)
            return;
        this.view.dispose();
        this.view = new areaView_1.AreaView(area);
        this.dripT = area.drips.map(() => Math.random() * 4);
        this.glight.vx = -999;
        this.camera.snap(this.pl.x, this.pl.y, area.w, area.h);
        this.interp.capture(this.world);
        if (this.settings.data.autosaveOnAreaChange && this.lastSavedArea && this.lastSavedArea !== area.id && this.screens.is("play")) {
            this.lastSavedArea = area.id;
            this.autosave("Area Change");
        }
        else {
            this.lastSavedArea = area.id;
        }
    }
    // ---------------------------------------------------------------- zoom
    setZoom(z) {
        const a = this.view ? this.area : undefined;
        this.camera.setZoom(z, a?.w, a?.h);
    }
    zoomTo(z, dur) { this.camera.zoomTo(z, dur); }
    wheel(deltaY) {
        this.input.onWheel(deltaY);
        if (this.hasHiModalOpen() || this.feed.drawerOpen)
            return;
        if (!this.screens.is("play") || !(0, world_1.hasFlag)(this.world, flags_1.FLAGS.golemEye) || deltaY === 0)
            return;
        const res = this.camera.applyWheel(deltaY);
        if (res.changed)
            this.sfx.tone(res.zoomIn ? 560 : 420, 0.05, "triangle", 0.03);
    }
    // ---------------------------------------------------------------- input
    keyDown(k) {
        if (this.settingsModal.captureKey(k, this.settings))
            return;
        const raw = k;
        k = k.toLowerCase();
        if (!this.keys.has(k))
            this.pressed.add(k);
        this.keys.add(k);
        if (raw.length === 1)
            this.typed.push(raw);
        else if (k === "backspace")
            this.typed.push("\b");
    }
    keyUp(k) { this.keys.delete(k.toLowerCase()); }
    pointer() { this.pressed.add("click"); }
    pointerMove(x2, y2) { this.input.onPointerMove(x2, y2, this.camera.x, this.camera.y, this.vw, this.vh); }
    pointerDown(btn, x2, y2) {
        this.input.onPointerDown(btn, x2, y2, this.camera.x, this.camera.y, this.vw, this.vh);
        if (btn === 0 && !this.hasHiModalOpen())
            this.pressed.add("click");
    }
    pointerUp(btn, x2, y2) { this.input.onPointerUp(btn, x2, y2, this.camera.x, this.camera.y, this.vw, this.vh); }
    pointerLeave() { this.input.onPointerLeave(); }
    hasHiModalOpen() {
        return this.settingsModal.open || this.saveModal.open || this.floorsModal.open;
    }
    debugKey(n) {
        const w = this.world, pl = this.pl;
        const say = (text) => { this.debugMsg = { text, t: 0 }; };
        if (n === 0)
            this.debugUi.toggle();
        else if (n === 1) {
            if (this.hasArm) {
                (0, world_1.clearFlag)(w, flags_1.FLAGS.golemArm);
                say("DEBUG: IRON ARM OFF");
            }
            else {
                (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
                say("DEBUG: IRON ARM ON");
            }
        }
        else if (n === 2) {
            const given = (0, debug_1.grantStoryKit)(w, pl);
            this.sfx.tone(520, 0.1, "triangle", 0.05);
            say(given ? "DEBUG: RUNES + CORE + TOOLS GRANTED" : "DEBUG: ALREADY HAVE ALL RUNES + CORE + TOOLS");
        }
        else if (n === 3) {
            this.debugSpeed = !this.debugSpeed;
            say(this.debugSpeed ? "DEBUG: SUPER SPEED ON" : "DEBUG: SUPER SPEED OFF");
        }
        else if (n === 4) {
            (0, debug_1.grantBuildKit)(w, pl);
            say("DEBUG: BUILD + MASONRY + PLANS + BASKET + MATERIALS");
        }
        else if (n === 6) {
            const on = (0, debug_1.toggleGearKit)(w, pl);
            this.sfx.tone(on ? 560 : 380, 0.1, "triangle", 0.05);
            say(on ? "DEBUG: GEAR KIT ON - ALL SLOTS UNLOCKED" : "DEBUG: GEAR KIT OFF - SLOTS LOCKED AGAIN");
        }
        else if (n === 5) {
            if ((0, world_1.hasFlag)(w, flags_1.FLAGS.golemEye)) {
                w.flags.delete(flags_1.FLAGS.golemEye);
                this.zoomTo(1, 0.4);
                say("DEBUG: EYE REPAIR OFF");
            }
            else {
                (0, world_1.setFlag)(w, flags_1.FLAGS.golemEye);
                this.zoomTo(zoom_1.ZOOM_DEFAULT, 1);
                this.eyeBoost = 1.5;
                say("DEBUG: EYE REPAIR ON (SCROLL TO ZOOM)");
            }
        }
    }
    has(...k) { return k.some((x) => this.keys.has(x)); }
    hit(...k) { return k.some((x) => this.pressed.has(x)); }
    debugSetFlag(flag, on) {
        const w = this.world;
        if (on)
            (0, world_1.setFlag)(w, flag);
        else
            (0, world_1.clearFlag)(w, flag);
        if (flag === flags_1.FLAGS.golemEye) {
            if (on) {
                this.zoomTo(zoom_1.ZOOM_DEFAULT, 0.6);
                this.eyeBoost = 1.5;
            }
            else
                this.zoomTo(1, 0.4);
        }
    }
    debugTeleport(p) {
        const pl = this.pl;
        if (!(0, debug_1.teleportTo)(this.world, pl, p.area, p.x, p.y))
            return false;
        this.syncView();
        this.camera.snap(pl.x, pl.y, this.area.w, this.area.h);
        this.glight.vx = -999;
        this.particleSys.clear();
        this.drainEvents();
        return true;
    }
    debugNewGame() { this.resume((0, world_1.createWorld)(newSeed())); this.say("NEW GAME (DEBUG)"); }
    debugFoundations() { this.resume((0, debugFoundations_1.foundationDemo)()); this.say("FOUNDATION FIXTURE: A WORKER GATHERS THROUGH THE RUNES."); }
    debugZoom() {
        const cur = this.zoomAnim?.to ?? this.zoom;
        const steps = [...zoom_1.ZOOM_STEPS].sort((x, y) => x - y);
        const next = steps.find((z) => z > cur + 1e-6) ?? steps[0];
        this.zoomTo(next, 0.3);
    }
    // ---------------------------------------------------------------- helpers
    get pl() { return (0, world_1.player)(this.world); }
    get area() { return (0, world_1.currentArea)(this.world); }
    get hasArm() { return (0, world_1.hasFlag)(this.world, flags_1.FLAGS.golemArm); }
    spawn(p) { this.particleSys.spawn(p); }
    shake(t, m) { this.camera.shake(t, m); }
    dist2(x, y) { const pl = this.pl, dx = x - pl.x, dy = y - pl.y; return dx * dx + dy * dy; }
    volAt(x, y) { return (0, util_1.clamp)(1 - Math.sqrt(this.dist2(x, y)) / 220, 0, 1); }
    later(delay, fn) { this.uiTimers.push({ at: this.t + delay, fn }); }
    sparkBurst(n) { this.particleSys.sparkBurst(this.pl, this.look.dormant, n); }
    coreSparks(a, n, bright) { this.particleSys.coreSparks(a, n, bright); }
    npcSparks(a, n) { this.particleSys.npcSparks(a, n); }
    npcDust(a) { this.particleSys.npcDust(a); }
    witherClump(x, y, size) { this.particleSys.witherClump(x, y, size); }
    clearParticles() { this.particleSys.clear(); }
    // ---------------------------------------------------------------- screens
    makeScreens() {
        const g = this;
        const scr = (id, opaque, update, render) => ({ id, opaque, t: 0, update, render });
        this.buildUi = new buildMenu_1.BuildUi(this);
        this.craftUi = new crafting_1.CraftingUi(this);
        this.packUi = new pack_1.PackUi(this);
        this.storageUi = new storage_1.StorageUi(this);
        this.manageUi = new manage_1.ManageUi(this);
        this.transferUi = new transfer_1.TransferUi(this, (id) => this.manageUi.open(id));
        this.manageUi.openTransfer = (id) => this.transferUi.open(id);
        this.debugUi = new debug_2.DebugUi(this);
        this.bookUi = new book_1.BookUi(this);
        this.schemUi = new schematic_1.SchematicUi(this);
        this.dialogueUi = new dialogue_1.DialogueUi(this);
        this.introUi = new intro_1.IntroCutscene(this);
        this.crossingUi = new crossing_1.CrossingCutscene(this);
        this.S = {
            title: scr("title", true, (dt) => {
                if (g.hasHiModalOpen())
                    return;
                if (g.hit("l") && g.loadGame()) {
                    g.sfx.init();
                    return;
                }
                if (g.hit("o")) {
                    g.settingsModal.toggle();
                    return;
                }
                // If user clicked a title button on the 2x UI canvas, let it handle itself; keyboard press starts intro
                const nonClickKey = [...g.pressed].some((k) => k !== "click");
                if (nonClickKey || (g.hit("click") && !g.input.pointer.consumed && g.input.pointer.y < 290)) {
                    g.sfx.init();
                    g.introUi.start();
                }
                if (Math.random() < 0.3)
                    g.spawn({ x: Math.random() * exports.W, y: exports.H + 2, vy: -10 - Math.random() * 12, vx: (Math.random() - 0.5) * 4, life: 6, kind: "ember", col: Math.random() < 0.5 ? "#ff8a3a" : "#c84a10", emit: true });
                g.updateParticles(dt);
            }, () => (0, cards_1.renderTitle)(g.ctx, g.t, g.particles)),
            intro: this.introUi.screen,
            play: scr("play", true, (dt) => g.updatePlay(dt), () => g.renderWorldScene()),
            tele: scr("tele", true, (dt) => {
                if (g.tele.first && g.S.tele.t > 0.2 && g.hit("escape")) {
                    g.skipCrossing();
                    return;
                }
                if (g.updateTele(dt))
                    return;
                (0, step_1.stepPlayer)(g.world, dt, { ix: 0, iy: 0, use: false });
                g.drainEvents();
                g.worldFrame(dt);
            }, () => {
                g.renderWorldScene();
                const t = g.S.tele.t, w0 = g.tele.dur - 1.6;
                if (t > w0 && g.settings.data.screenFlash) {
                    g.ctx.fillStyle = `rgba(235,240,255,${(0, util_1.clamp)((t - w0) / 1.4, 0, 1)})`;
                    g.ctx.fillRect(0, 0, exports.W, exports.H);
                }
                if (g.tele.first)
                    g.renderSkipHint(t);
            }),
            crossing: this.crossingUi.screen,
            book: this.bookUi.screen,
            build: this.buildUi.screen,
            crafting: this.craftUi.screen,
            storage: this.storageUi.screen,
            manage: this.manageUi.screen,
            debug: this.debugUi.screen,
            dialogue: this.dialogueUi.screen,
            inv: this.packUi.screen,
            schem: this.schemUi.screen,
        };
    }
    update(dt) {
        this.frameDt = dt;
        this.t += dt;
        this.feed.tick(dt);
        this.input.pollGamepad(this.keys, this.pressed);
        this.input.syncWorld(this.camera.x, this.camera.y, this.vw, this.vh);
        if (this.uiTimers.length) {
            const due = this.uiTimers.filter((u) => u.at <= this.t);
            this.uiTimers = this.uiTimers.filter((u) => u.at > this.t);
            for (const u of due)
                u.fn();
        }
        this.camera.stepZoom(dt, this.view ? this.area.w : undefined, this.view ? this.area.h : undefined);
        // Process 2x hi-res modals first (they pause world simulation while open)
        if (!this.hasHiModalOpen()) {
            this.screens.update(dt);
        }
        else {
            if (this.hit("escape")) {
                this.settingsModal.close();
                this.saveModal.close();
                this.floorsModal.close();
            }
        }
        // Note: pressed/typed clear after renderHiUi() or at end of update if render isn't called (headless tests!)
        // Save modal/HUD keyboard triggers are checked in updatePlay + renderHiUi uses pointer/keys safely.
        this.pressed.clear();
        this.typed.length = 0;
    }
    /** One simulation step plus presentation sync (used by cutscenes & overlays). */
    worldFrame(dt) {
        var _a;
        const lod = ((_a = this.world).lod ?? (_a.lod = (0, lod_1.createLodConfig)()));
        lod.view = this.camera.viewRect();
        (0, step_1.stepWorld)(this.world, dt);
        if (this.debugClock > 1)
            (0, daytime_1.advanceDay)(this.world, ((this.debugClock - 1) * dt * 24) / daycycle_1.DAY_SECONDS);
        this.drainEvents();
        this.syncView();
        if (this.view.flush())
            this.glight.vx = -999;
        this.updateWorldFx(dt);
    }
    eventHost() {
        const g = this;
        return {
            get world() { return g.world; },
            get pl() { return g.pl; },
            get area() { return g.area; },
            get t() { return g.t; },
            get hasArm() { return g.hasArm; },
            sfx: g.sfx,
            particles: g.particleSys,
            look: g.look,
            bubbles: g.bubbles,
            tele: g.tele,
            get toast() { return g.toast; }, set toast(v) { g.toast = v; },
            get eyeBoost() { return g.eyeBoost; }, set eyeBoost(v) { g.eyeBoost = v; },
            get crackFlash() { return g.crackFlash; }, set crackFlash(v) { g.crackFlash = v; },
            get shudder() { return g.shudder; }, set shudder(v) { g.shudder = v; },
            get fizzT() { return g.fizzT; }, set fizzT(v) { g.fizzT = v; },
            get doorFade() { return g.doorFade; }, set doorFade(v) { g.doorFade = v; },
            get lastAnalyzed() { return g.lastAnalyzed; }, set lastAnalyzed(v) { g.lastAnalyzed = v; },
            isPlayScreen: () => g.screens.is("play"),
            say: (txt) => g.say(txt),
            notify: (o) => g.notify(o),
            shake: (d, m) => g.shake(d, m),
            later: (d, fn) => g.later(d, fn),
            npcLook: (a) => g.npcLook(a),
            runeRefused: (x, y) => g.runeRefused(x, y),
            openBook: (id) => g.bookUi.open(id),
            openSchematic: () => g.schemUi.open(),
            openStation: (st, pr) => g.craftUi.open(st, pr),
            openStorage: (pr) => g.storageUi.open(pr),
            openManage: (target) => g.manageUi.open(target),
            openDialogue: (npc, sc, seg) => g.dialogueUi.open(npc, sc, seg),
            beginTeleport: (first) => {
                g.screens.set(g.S.tele);
                if (first) {
                    g.letterbox(true);
                    g.monologue.pinned = true;
                }
            },
            onDayPhase: (ph) => g.onDayPhase(ph),
            pushThought: (line) => g.monologue.push(line),
            zoomTo: (z, dur) => g.zoomTo(z, dur),
            markDialogueZoomHint: () => { g.dialogueUi.zoomHint = true; },
        };
    }
    drainEvents() {
        (0, monologue_2.reactToEvents)(this.world);
        const evs = this.world.events;
        if (!evs.length)
            return;
        this.world.events = [];
        const eh = this.eventHost();
        for (const e of evs) {
            if (e.t === "travelled" && e.actor !== this.world.playerId) {
                this.workerTravelled(e);
                continue;
            }
            if (e.t === "portal" && (0, world_1.actorById)(this.world, e.actor)?.kind === "folk")
                continue;
            if (e.t === "portal" && e.actor !== this.world.playerId) {
                this.workerWalked(e);
                continue;
            }
            const aud = (0, audience_1.eventAudience)(this.world, e);
            if (aud === "player")
                (0, eventReactions_1.handlePlayerEvent)(eh, e);
            else if (aud === "nearby")
                (0, eventReactions_1.handleNearbyEvent)(eh, e);
        }
    }
    updatePlay(dt) {
        var _a;
        const w = this.world, pl = this.pl, lk = this.look;
        const inp = this.input;
        // Speed & modal hotkeys (remappable via Settings)
        if (inp.actionHit("pause", this.pressed)) {
            this.setSpeed(this.clock.togglePause());
            return;
        }
        if (inp.actionHit("speedDown", this.pressed)) {
            this.setSpeed(this.clock.stepSpeed(-1));
            return;
        }
        if (inp.actionHit("speedUp", this.pressed)) {
            this.setSpeed(this.clock.stepSpeed(1));
            return;
        }
        if (inp.actionHit("settings", this.pressed)) {
            this.settingsModal.toggle();
            return;
        }
        if (inp.actionHit("floors", this.pressed)) {
            this.floorsModal.toggle();
            return;
        }
        if (inp.actionHit("alerts", this.pressed)) {
            this.feed.drawerOpen = !this.feed.drawerOpen;
            if (this.feed.drawerOpen)
                this.feed.markAllRead();
            return;
        }
        // Save / Load
        if (inp.actionHit("quickSave", this.pressed))
            this.saveGame();
        if (inp.actionHit("quickLoad", this.pressed) && this.loadGame())
            return;
        // Legacy overlays
        if (!pl.task) {
            if (inp.actionHit("pack", this.pressed)) {
                this.packUi.open("view");
                return this.worldFrame(dt);
            }
            if (inp.actionHit("map", this.pressed) && (0, inventory_1.hasItem)(pl, "schematic")) {
                this.schemUi.open();
                return this.worldFrame(dt);
            }
            if (inp.actionHit("build", this.pressed)) {
                this.buildUi.open();
                return this.worldFrame(dt);
            }
            if (inp.actionHit("quickPlace", this.pressed)) {
                this.buildUi.quickPlace();
                return this.worldFrame(dt);
            }
            if (this.buildUi.pending) {
                this.buildUi.resumeAfterWork();
                if (!this.screens.is("play"))
                    return this.worldFrame(dt);
            }
            if (this.craftUi.pending) {
                this.craftUi.resume();
                if (!this.screens.is("play"))
                    return this.worldFrame(dt);
            }
            if (this.manageUi.pending) {
                this.manageUi.resume();
                if (!this.screens.is("play"))
                    return this.worldFrame(dt);
            }
        }
        // Continuous + edge-triggered player inputs
        let ix = 0, iy = 0;
        if (inp.actionDown("moveLeft", this.keys))
            ix -= 1;
        if (inp.actionDown("moveRight", this.keys))
            ix += 1;
        if (inp.actionDown("moveUp", this.keys))
            iy -= 1;
        if (inp.actionDown("moveDown", this.keys))
            iy += 1;
        let use = inp.actionHit("interact", this.pressed);
        let attack = inp.actionHit("attack", this.pressed);
        let core = inp.actionHit("core", this.pressed);
        let toggleScan = inp.actionHit("scan", this.pressed);
        // Autosave timer (real play seconds)
        const interval = this.settings.data.autosaveInterval;
        if (interval > 0 && !this.clock.paused) {
            this.autosaveTimer += dt;
            if (this.autosaveTimer >= interval) {
                this.autosaveTimer = 0;
                this.autosave("Timer");
            }
        }
        // Fixed-timestep simulation ticks (Phase 0.1)
        const lod = ((_a = this.world).lod ?? (_a.lod = (0, lod_1.createLodConfig)()));
        lod.view = this.camera.viewRect();
        const t0 = typeof performance !== "undefined" ? performance.now() : 0;
        let openedSocket = null;
        const summary = this.clock.advance(dt, (tickDt) => {
            (0, step_1.addPlayTime)(w, tickDt);
            const res = (0, step_1.stepPlayer)(w, tickDt, {
                ix, iy, use, attack, core, toggleScan,
                speed: this.debugSpeed ? this.debugSpeedMult : 1,
                noclip: this.debugNoclip,
            });
            // Edge-triggered actions fire only on the first tick of this frame (consistent across 1x..8x)
            use = false;
            attack = false;
            core = false;
            toggleScan = false;
            this.target = res.target;
            if (res.ui)
                openedSocket = res.ui.socket;
            this.drainEvents();
            (0, step_1.stepWorld)(w, tickDt);
            if (this.debugClock > 1)
                (0, daytime_1.advanceDay)(w, ((this.debugClock - 1) * tickDt * 24) / daycycle_1.DAY_SECONDS);
            this.drainEvents();
        }, () => this.interp.capture(w));
        if (summary.ticks > 0 && typeof performance !== "undefined") {
            this.hud.recordTickMs(performance.now() - t0);
        }
        if (openedSocket !== null)
            this.packUi.open("select", openedSocket);
        // Presentation-only per-frame updates (golem sputter, rumble, FX, camera, particles)
        lk.sparkT -= dt;
        if (lk.sparkT <= 0) {
            lk.sparkT = 1.5 + Math.random() * 4;
            if (!this.hasArm) {
                this.sparkBurst(3 + ((Math.random() * 4) | 0));
                if (Math.random() < 0.6)
                    this.sfx.spark();
            }
            if (Math.random() < 0.12)
                lk.sputter = 0.25;
        }
        lk.sputter = Math.max(0, lk.sputter - dt);
        lk.core = lk.sputter > 0 ? (Math.random() < 0.5 ? 0.3 : 0.8) : 1;
        lk.eye = lk.sputter > 0 && !(0, world_1.hasFlag)(w, flags_1.FLAGS.golemEye) ? 0.3 : 1;
        lk.dormant = 0;
        this.eyeBoost = Math.max(0, this.eyeBoost - dt);
        if (!this.area.base.outdoor && !this.area.base.interior && !this.clock.paused)
            this.rumbleT -= dt;
        if (this.rumbleT <= 0) {
            this.rumbleT = 50 + Math.random() * 50;
            this.sfx.rumble();
            this.shake(2.2, 1.5);
            for (let i = 0; i < 30 * this.zoom * this.zoom; i++) {
                this.spawn({ x: this.cam.x + Math.random() * this.vw, y: this.cam.y + Math.random() * this.vh, z: 60 + Math.random() * 40, vz: -10, life: 4, kind: "debris", col: Math.random() < 0.5 ? "#6a6372" : "#4b4552", g: 60 });
            }
        }
        this.syncView();
        if (this.view.flush())
            this.glight.vx = -999;
        this.updateWorldFx(dt);
    }
    updateTele(_dt) {
        const t = this.S.tele.t, lk = this.look, tl = this.tele, pl = this.pl;
        if (!pl.task && t > 0.2) {
            this.sfx.setHum(0);
            if (tl.first && tl.travelled) {
                this.particleSys.clear();
                this.crossingUi.start();
            }
            else {
                if (tl.first) {
                    this.letterbox(false);
                    this.monologue.release();
                }
                this.screens.set(this.S.play);
                this.arriveFade = tl.travelled ? 1 : 0;
                lk.z = tl.travelled ? 16 : 0;
            }
            return true;
        }
        const lift = tl.dur - 1.6;
        lk.z = Math.min(t, lift) * (tl.first ? 4 : 6) + Math.sin(t * 3) * 1;
        lk.eye = 1;
        lk.core = 1;
        this.shake(0.1, Math.min(4, t * 1.2));
        const c = tl;
        for (let i = 0; i < 6; i++) {
            const a = Math.random() * Math.PI * 2, r = 20 + Math.random() * 50;
            this.spawn({ x: c.x + Math.cos(a) * r, y: c.y + Math.sin(a) * r, z: 2, vx: -Math.cos(a) * r * 0.8, vy: -Math.sin(a) * r * 0.8, vz: 10 + Math.random() * 20, life: 1.2, kind: "rune", col: Math.random() < 0.5 ? "#c0a0ff" : "#80e0ff", emit: true, g: -5 });
        }
        this.glight.int = 0.9 + t * 0.4;
        return false;
    }
    skipCrossing() {
        const pl = this.pl;
        for (let i = 0; i < 200 && pl.task; i++)
            (0, step_1.stepPlayer)(this.world, 0.1, { ix: 0, iy: 0, use: false });
        this.drainEvents();
        this.sfx.setHum(0);
        this.look.z = 0;
        if (!this.tele.travelled) {
            this.letterbox(false);
            this.monologue.release();
            this.screens.set(this.S.play);
            return;
        }
        this.syncView();
        this.particleSys.clear();
        this.crossingUi.start();
        this.crossingUi.skip();
    }
    // ---------------------------------------------------------------- daycycle & cutscenes
    tendedLevel(p, hour = (0, daytime_1.worldHour)(this.world)) {
        if (!this.area.base.tended || p.dyn)
            return 1;
        const habit = (0, props_1.propDef)(p.kind).habit;
        return habit ? (0, daycycle_1.litLevel)(habit, p.id, hour) : 1;
    }
    onDayPhase(phase) {
        const a = this.area;
        if (!a.base.outdoor || !this.screens.is("play"))
            return;
        const town = !!a.base.tended;
        if (phase === "dawn") {
            this.say(town ? "DAWN. THE TOWN PUTS OUT ITS LAMPS." : "DAWN BREAKS.");
            if (town)
                this.sfx.bell();
            this.notify({ title: "Dawn Breaks", detail: town ? "The town puts out its lamps." : "Daylight reaches the clearing.", severity: "info", category: "day", worldTime: this.world.time });
        }
        else if (phase === "dusk") {
            this.say(town ? "DUSK. THE TOWN LIGHTS ITS LAMPS." : "DUSK. THE LIGHT IS GOING.");
            if (town)
                this.sfx.bell();
            this.notify({ title: "Dusk Falls", detail: town ? "Lamplighters begin their round." : "Night approaches.", severity: "info", category: "day", worldTime: this.world.time });
        }
        else if (phase === "night") {
            this.say("NIGHT FALLS.");
        }
    }
    debugAdvanceTime() {
        const marks = [0, 5, 6, 7, 12, 19, 20, 21], h = (0, daytime_1.worldHour)(this.world);
        (0, daytime_1.advanceDayTo)(this.world, marks.find((m) => m > h + 0.01) ?? marks[0]);
        this.drainEvents();
        const now = (0, daytime_1.worldHour)(this.world);
        return `${(0, daycycle_1.clockText)(now)} ${(0, daycycle_1.phaseAt)(now).toUpperCase()}`;
    }
    surfaceRuneState() {
        if (this.runeAnim)
            return this.runeAnim;
        const state = (0, runes_2.runeState)(this.world, runes_1.RUNE_NODES.surface);
        const rest = state === "linked" ? (0, runeFx_1.linkedGlow)(this.t) : state === "severed" ? (0, runeFx_1.severedGlow)(this.t) : 0;
        const d = this.runeDud, p = d ? this.area.prop(runes_1.RUNE_NODES.surface.prop) : undefined;
        const glow = d && p && Math.hypot(p.x - d.x, p.y - d.y) < 4 ? (0, runeFx_1.runeDudGlow)(d.t, rest, state === "dormant" ? 0.5 : 1) : rest;
        return { t: state === "dormant" ? 0 : 1, glow, column: 0 };
    }
    arriveStep(t, dt) {
        const A = cutscenes_1.ARRIVE, t0 = t - dt, lk = this.look;
        const rp = this.area.prop("rune.surface");
        const c = rp ?? this.pl;
        const crossed = (at) => t >= at && t0 < at;
        const ease = (x) => x * x * (3 - 2 * x);
        const prog = ease((0, util_1.clamp)((t - A.SWEEP) / (A.SWEEP_END - A.SWEEP), 0, 1));
        let glow = 0;
        if (t >= A.GLOW && t < A.SWEEP)
            glow = 0.4 * ease((0, util_1.clamp)((t - A.GLOW) / (A.SWEEP - A.GLOW), 0, 1)) * (0.85 + 0.15 * Math.sin(t * 7));
        else if (t >= A.SWEEP && t < A.SWEEP_END)
            glow = 0.4 + 0.25 * prog + 0.06 * Math.sin(t * 6);
        else if (t >= A.SWEEP_END && t < A.PULSE_END)
            glow = 0.65 + 0.95 * Math.sin((Math.PI * (t - A.SWEEP_END)) / (A.PULSE_END - A.SWEEP_END));
        else if (t >= A.PULSE_END)
            glow = 0.75 + 0.2 * Math.sin(t * 5);
        const column = t < A.PULSE_END ? 0 : t < A.FLASH ? ease((t - A.PULSE_END) / (A.FLASH - A.PULSE_END)) : Math.max(0, 1 - (t - A.FLASH) / 0.9);
        const prev = this.runeAnim?.t ?? 0;
        this.runeAnim = { t: prog, glow, column };
        this.hideGolem = t < A.FLASH;
        if (crossed(A.GLOW)) {
            this.sfx.setHum(0.25);
            this.sfx.tone(98, 2.2, "sine", 0.05, 110);
        }
        if (t >= A.SWEEP && t < A.SWEEP_END)
            this.sfx.setHum(0.25 + prog * 0.75);
        if (crossed(A.SWEEP))
            this.sfx.tone(110, A.SWEEP_END - A.SWEEP, "sine", 0.05, 220);
        if (crossed(A.SWEEP_END)) {
            this.sfx.activate();
            this.shake(0.6, 2);
        }
        if (crossed(A.PULSE_END))
            this.sfx.tone(196, A.FLASH - A.PULSE_END, "triangle", 0.04, 392);
        if (crossed(A.FLASH)) {
            this.sfx.teleport();
            this.shake(0.9, 3.5);
            this.sfx.setHum(0.2);
        }
        if (crossed(A.END - 0.5))
            this.sfx.setHum(0);
        const px = this.circle.pixels;
        if (glow > 0 && t < A.FLASH && Math.random() < dt * 14 * Math.min(1, glow)) {
            const q = this.runeArt.model.pixels[(Math.random() * px.length) | 0];
            if ((0, runeReveal_1.carvingVisible)(q, prog))
                this.spawn({ x: c.x + q.x, y: c.y + q.y, z: 0, vz: 6 + Math.random() * 10, life: 1.2, kind: "rune", col: Math.random() < 0.6 ? "#a070ff" : "#70d0ff", emit: true, g: -2 });
        }
        if (prog > prev) {
            for (const cl of this.runeArt.model.clumps)
                if ((0, runeReveal_1.clumpCleared)(cl, prog) && !(0, runeReveal_1.clumpCleared)(cl, prev))
                    this.witherClump(c.x + cl.x, c.y + cl.y, cl.px.length);
            if (t < A.SWEEP_END)
                this.shake(0.1, 0.3 + prog * 0.8);
        }
        if (t >= A.PULSE_END && t < A.FLASH) {
            this.shake(0.1, 0.4 + column * 2.6);
            for (let i = 0; i < 2 + column * 8; i++) {
                const a = Math.random() * Math.PI * 2, r = 50 + Math.random() * 40;
                this.spawn({ x: c.x + Math.cos(a) * r, y: c.y + Math.sin(a) * r, z: 2 + Math.random() * 6, vx: -Math.cos(a) * r * 1.1, vy: -Math.sin(a) * r * 1.1, vz: 4 + column * 30, life: 0.9, kind: "rune", col: Math.random() < 0.5 ? "#c0a0ff" : "#80e0ff", emit: true, g: -4 });
            }
        }
        if (crossed(A.FLASH))
            for (let i = 0; i < 46; i++) {
                const a = Math.random() * Math.PI * 2, v = 30 + Math.random() * 70;
                this.spawn({ x: c.x, y: c.y + 4, z: 4 + Math.random() * 20, vx: Math.cos(a) * v, vy: Math.sin(a) * v * 0.5, vz: 20 + Math.random() * 40, life: 0.8 + Math.random() * 0.6, kind: "spark", col: Math.random() < 0.5 ? "#e8e0ff" : "#a070ff", emit: true, g: 90 });
            }
        const fall = (0, util_1.clamp)((t - A.FLASH) / A.FALL, 0, 1);
        lk.z = 30 * (1 - fall) ** 2;
        lk.eye = 1;
        lk.core = 1;
        lk.dormant = 0;
        this.camera.snap(c.x, c.y, this.area.w, this.area.h);
    }
    arriveEnd() {
        this.runeAnim = null;
        this.hideGolem = false;
        this.look.z = 0;
        this.look.eye = 1;
        this.look.core = 1;
        this.look.dormant = 0;
        this.sfx.setHum(0);
    }
    landFx() {
        const pl = this.pl;
        this.sfx.slam();
        this.shake(0.35, 2.2);
        for (let i = 0; i < 22; i++) {
            const ang = Math.random() * Math.PI * 2, v = 16 + Math.random() * 30;
            this.spawn({ x: pl.x + Math.cos(ang) * 4, y: pl.y + Math.sin(ang) * 2, z: 1, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v * 0.5, vz: 6 + Math.random() * 12, life: 0.7 + Math.random() * 0.6, kind: "dust", col: Math.random() < 0.5 ? "#8a8478" : "#a09a8c", g: 20 });
        }
        if (!this.hasArm)
            this.sparkBurst(6);
    }
    sunrise(level) {
        if (level <= 0 && !this.view.lights.has("sunrise"))
            return;
        const pl = this.pl;
        const lt = this.view.dynamicLight("sunrise", () => (0, light_1.makeLight)(pl.x + 190, pl.y - 30, 330, [1, 0.7, 0.4], 0, 0, "sunrise"));
        lt.int = 0.75 * (0, util_1.clamp)(level, 0, 1);
    }
    anyKey() { return this.pressed.size > 0; }
    wakeAgain() { this.reset(); this.introUi.start(); }
    arriveOverlay(t) {
        const A = cutscenes_1.ARRIVE, ctx = this.ctx;
        if (t < A.FADE) {
            ctx.fillStyle = `rgba(0,0,0,${1 - t / A.FADE})`;
            ctx.fillRect(0, 0, exports.W, exports.H);
        }
        if (this.settings.data.screenFlash && t > A.FLASH && t < A.FLASH + 1) {
            ctx.fillStyle = `rgba(235,240,255,${1 - (t - A.FLASH)})`;
            ctx.fillRect(0, 0, exports.W, exports.H);
        }
    }
    renderCinema() {
        this.renderBars();
        const bar = this.bars.v * this.bars.v * (3 - 2 * this.bars.v);
        (0, monologue_1.drawMonologue)(this.ctx, this.monologue, this.t, 7 + Math.round(12 * bar));
    }
    renderSkipHint(t) {
        const ctx = this.ctx;
        ctx.globalAlpha = (0, util_1.clamp)((t - 0.6) * 1.5, 0, 1) * 0.85;
        (0, font_1.drawText)(ctx, "ESC - SKIP", exports.W - 5, exports.H - 9, "#8a8392", 1, "right");
        ctx.globalAlpha = 1;
    }
    // ---------------------------------------------------------------- world presentation FX
    updateWorldFx(dt) {
        const pl = this.pl, area = this.area;
        const VW = this.vw, VH = this.vh;
        this.camera.follow(pl.x, pl.y, area.w, area.h, dt);
        this.camera.stepShake(dt);
        this.crackFlash = Math.max(0, this.crackFlash - dt);
        if (this.shudder && (this.shudder.t -= dt) <= 0)
            this.shudder = null;
        const gl = this.glight;
        gl.x = pl.x;
        gl.y = pl.y - 6;
        (0, light_1.applyGlow)(gl, (0, gear_1.golemGlow)(this.world, pl));
        if (Math.abs(gl.x - gl.vx) > 2 || Math.abs(gl.y - gl.vy) > 2)
            (0, light_1.computeVis)(gl, area);
        const base = this.screens.is("tele") ? gl.int : 1.0;
        gl.cur = base * this.look.core * (0.95 + 0.05 * Math.sin(this.t * 13) * Math.sin(this.t * 3.1)) + this.eyeBoost * 0.3;
        this.updateNpcLooks(dt);
        const hour = (0, daytime_1.worldHour)(this.world), sun = (0, daycycle_1.sunLevel)(hour);
        for (const L of this.view.lights.values()) {
            const n = Math.sin(this.t * 9 + L.seed) * 0.5 + Math.sin(this.t * 23.7 + L.seed * 2) * 0.3 + Math.sin(this.t * 3.3 + L.seed) * 0.2;
            L.cur = L.int * (1 - L.flick * (0.5 + 0.5 * n));
            if (L.habit)
                L.day = (0, daycycle_1.litLevel)(L.habit, L.owner, hour);
            else if (L.sky) {
                const s = (0, daycycle_1.skyLight)(L.sky, hour);
                L.r = s.col[0];
                L.g = s.col[1];
                L.b = s.col[2];
                L.day = s.gain;
            }
        }
        const r = area.ritual;
        const cl = this.view.byId("circle");
        if (r?.active) {
            this.sfx.setHum(Math.min(1, r.actT / 2));
            if (cl) {
                const target = 120;
                if (cl.rad < target) {
                    cl.rad = Math.min(target, cl.rad + dt * 30);
                    if (Math.abs(cl.rad - cl.vx) > 0)
                        (0, light_1.computeVis)(cl, area);
                }
                cl.int = 0.6 + Math.min(1, r.actT / 3) * 0.6;
                cl.cur = cl.int * (0.85 + 0.15 * Math.sin(this.t * 3));
            }
            const c = area.ritualPos;
            if (Math.random() < dt * 30) {
                const p = this.circle.pixels[(Math.random() * this.circle.pixels.length) | 0];
                this.spawn({ x: c.x + p.x, y: c.y + p.y, z: 0, vz: 8 + Math.random() * 12, life: 1.5, kind: "rune", col: Math.random() < 0.6 ? "#a070ff" : "#70d0ff", emit: true, g: -2 });
            }
        }
        else if (cl) {
            cl.cur = cl.int * (0.8 + 0.2 * Math.sin(this.t * 1.3)) + (this.fizzT > 0 ? Math.random() * 0.6 : 0);
        }
        this.fizzT = Math.max(0, this.fizzT - dt);
        if (this.runeDud) {
            const d = this.runeDud;
            if (d.t < runeFx_1.RUNE_DUD.gutter && Math.random() < dt * 40) {
                const p = this.circle.pixels[(Math.random() * this.circle.pixels.length) | 0];
                this.spawn({ x: d.x + p.x, y: d.y + p.y, z: 1, vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.5) * 30, vz: 20 + Math.random() * 30, life: 0.45, kind: "spark", col: Math.random() < 0.5 ? "#ff6a8a" : "#a070ff", emit: true, g: 120 });
            }
            if ((d.t += dt) >= runeFx_1.RUNE_DUD.dur)
                this.runeDud = null;
        }
        const rg = this.view.byId("runeglow");
        if (rg) {
            const st = this.surfaceRuneState();
            rg.cur = rg.int * (st.glow * (0.92 + 0.08 * Math.sin(this.t * 2.3)) + st.column * 0.7);
            if (!this.runeAnim && (0, runes_2.runeState)(this.world, runes_1.RUNE_NODES.surface) === "linked" && Math.random() < dt * 8) {
                const p = this.circle.pixels[(Math.random() * this.circle.pixels.length) | 0];
                this.spawn({ x: rg.x + p.x, y: rg.y + p.y, z: 0, vz: 6 + Math.random() * 10, life: 1.4, kind: "rune", col: Math.random() < 0.6 ? "#a070ff" : "#70d0ff", emit: true, g: -2 });
            }
        }
        if (this.arriveFade > 0) {
            this.arriveFade = Math.max(0, this.arriveFade - dt * 1.4);
            this.look.z = Math.max(0, this.look.z - dt * 24);
        }
        if (this.doorFade > 0)
            this.doorFade = Math.max(0, this.doorFade - dt * 2.8);
        if (this.note) {
            this.note.t += dt;
            if (this.note.t > 3)
                this.note = null;
        }
        this.stepMonologue(dt);
        // Ambient outdoor / dungeon / prop particles
        if (area.base.outdoor && Math.random() < dt * 1.5)
            this.spawn({ x: this.cam.x - 20 + Math.random() * VW, y: this.cam.y + Math.random() * VH, z: 30 + Math.random() * 40, vx: 8 + Math.random() * 8, vy: (Math.random() - 0.3) * 3, vz: -4 - Math.random() * 3, life: 7, kind: "mote", col: ["#7a5630", "#946a34", "#5a7a34", "#a07c40"][(Math.random() * 4) | 0], emit: false, g: 0 });
        if (area.base.outdoor && Math.random() < dt * 3 * this.zoom * this.zoom * (1 - sun))
            this.spawn({ x: this.cam.x + Math.random() * VW, y: this.cam.y + Math.random() * VH, z: 6 + Math.random() * 20, vx: (Math.random() - 0.5) * 4, vy: (Math.random() - 0.5) * 3, life: 4, kind: "mote", col: "#d8f080", emit: true, g: 0 });
        if (area.base.outdoor && Math.random() < dt * 1.2 * this.zoom * this.zoom * sun)
            this.spawn({ x: this.cam.x + Math.random() * VW, y: this.cam.y + Math.random() * VH, z: 8 + Math.random() * 18, vx: (Math.random() - 0.5) * 10, vy: (Math.random() - 0.5) * 6, life: 5, kind: "mote", col: ["#f0e8c0", "#e8c860", "#d8d0e8", "#e89a5a"][(Math.random() * 4) | 0], emit: false, g: 0 });
        if (area.base.outdoor && (this.skyT -= dt) <= 0) {
            this.skyT = 2.5 + Math.random() * 6;
            if (sun > 0.6)
                this.sfx.bird();
            else if (sun < 0.25)
                this.sfx.cricket();
        }
        area.drips.forEach((d, i) => {
            this.dripT[i] -= dt;
            if (this.dripT[i] <= 0) {
                this.dripT[i] = 1.5 + Math.random() * 4;
                if (Math.abs(d.x - this.cam.x - VW / 2) < VW / 2 + 100 && Math.abs(d.y - this.cam.y - VH / 2) < VH / 2 + 90)
                    this.spawn({ x: d.x, y: d.y, z: 70, vz: -20, life: 3, kind: "drip", col: "#6a8aa8", g: 140 });
            }
        });
        for (const p of area.props) {
            if (p.lit) {
                const fire = (0, props_1.propDef)(p.kind).fire;
                if (fire && this.tendedLevel(p, hour) > 0.05 && Math.abs(p.x - this.cam.x - VW / 2) <= VW / 2 + 40 && Math.abs(p.y - this.cam.y - VH / 2) <= VH / 2 + 50 && Math.random() < dt * fire.embers)
                    this.spawn({ x: p.x + (Math.random() - 0.5) * 4, y: p.y + fire.emberDy, z: 14, vx: (Math.random() - 0.5) * 6, vz: 10 + Math.random() * 10, life: 1 + Math.random(), kind: "ember", col: Math.random() < 0.5 ? "#ffb040" : "#ff6a1a", emit: true, g: -4 });
            }
            const sm = (0, props_1.propDef)(p.kind).smoke;
            if (sm && Math.abs(p.x - this.cam.x - VW / 2) <= VW / 2 + 40 && Math.abs(p.y - this.cam.y - VH / 2) <= VH / 2 + 70 && Math.random() < dt * sm.rate * (area.base.tended ? (0, daycycle_1.hearthSmoke)(hour) : 1))
                this.spawn({ x: p.x + sm.dx + (Math.random() - 0.5) * 3, y: p.y, z: sm.z, vx: 3 + Math.random() * 4, vy: (Math.random() - 0.5) * 1.5, vz: 7 + Math.random() * 5, life: 2.2 + Math.random() * 1.8, kind: "smoke", col: Math.random() < 0.5 ? "#6e6a70" : "#585460", g: -1, size: 2, emit: false });
        }
        if (Math.random() < dt * 8 * this.zoom * this.zoom)
            this.spawn({ x: this.cam.x + Math.random() * VW, y: this.cam.y + Math.random() * VH, z: 4 + Math.random() * 30, vx: (Math.random() - 0.5) * 3, vy: (Math.random() - 0.5) * 2, vz: (Math.random() - 0.5) * 2, life: 5, kind: "mote", col: "#b8b0a0", emit: false, g: 0 });
        const moon = this.view.byId("moon");
        if (moon && Math.random() < dt * 5)
            this.spawn({ x: moon.x - 14 + Math.random() * 30, y: moon.y + 2, z: 10 + Math.random() * 70, vx: (Math.random() - 0.5) * 2, vz: -3 - Math.random() * 3, life: 6, kind: "mote", col: sun > 0.5 ? "#ffe8b0" : "#a8c0ff", emit: true, g: 0 });
        if (Math.random() < dt * 2) {
            const cands = [];
            for (const it of (0, interact_1.interactables)(area))
                if (it.kind === "item" || it.kind === "propItem" || (it.kind === "container" && it.hasItem))
                    cands.push([it.x, it.y - (it.itemZ ?? 6) - 2]);
            const near = cands.filter(([x, y]) => Math.abs(x - this.cam.x - VW / 2) < VW / 2 + 10 && Math.abs(y - this.cam.y - VH / 2) < VH / 2 + 10);
            if (near.length) {
                const [x, y] = near[(Math.random() * near.length) | 0];
                this.spawn({ x: x + (Math.random() - 0.5) * 8, y: y + 2, z: 2 + Math.random() * 4, life: 0.45, kind: "glint", col: "#fff4d0", emit: true });
            }
        }
        if (this.debugMsg) {
            this.debugMsg.t += dt;
            if (this.debugMsg.t > 2)
                this.debugMsg = null;
        }
        if (this.toast) {
            this.toast.t += dt;
            if (this.toast.t > 3)
                this.toast = null;
        }
        const focus = this.screens.is("play") && this.target ? visionId(this.target) : null;
        for (const c of this.vision.update(dt, this.world, pl, gl, focus, this.visionArt()))
            this.onVisionCue(c);
        this.updateParticles(dt);
    }
    visionArt() {
        const a = (this.visionArtCache ?? (this.visionArtCache = {
            t: 0,
            npcLook: (x) => this.npcLook(x),
            circle: { lines: [this.circle.glow, this.circle.glowGap], r: 64 },
            self: () => (this.hideGolem ? null : this.renderer.selfPose),
        }));
        a.t = this.t;
        return a;
    }
    eyeSpot() {
        if (this.hideGolem)
            return null;
        const pl = this.pl, lk = this.look, f = pl.facing;
        const y = Math.round(pl.y - lk.z) - 18 + Math.round(lk.dormant * 4) + Math.round(lk.dormant * 3);
        const x = Math.round(pl.x) + (f === "right" ? 2 : f === "left" ? -4 : -2);
        return { x, y, w: f === "down" ? 4 : 2, show: f !== "up" };
    }
    onVisionCue(c) {
        switch (c.t) {
            case "on":
                this.sfx.visionOn();
                break;
            case "off":
                this.sfx.visionOff();
                break;
            case "ping":
                if (c.n < 10)
                    this.sfx.visionPing(c.category, c.pending, c.n);
                break;
            case "lock": {
                const col = vision_1.VISION_CATEGORIES[c.target.category].color;
                for (let i = 0; i < 18; i++) {
                    const edge = Math.random() < 0.5, px = c.x + (edge ? (Math.random() < 0.5 ? 0 : c.w) : Math.random() * c.w), py = c.y + (edge ? Math.random() * c.h : (Math.random() < 0.5 ? 0 : c.h));
                    const zx = c.target.y - py;
                    this.spawn({ x: px, y: c.target.y, z: zx, vx: (px - (c.x + c.w / 2)) * (1.5 + Math.random() * 2), vz: 6 + Math.random() * 16, life: 0.5 + Math.random() * 0.5, kind: "rune", col: Math.random() < 0.35 ? "#ffffff" : col, emit: true, g: -6 });
                }
                this.eyeBoost = Math.max(this.eyeBoost, 0.6);
                break;
            }
        }
    }
    updateParticles(dt) {
        this.particleSys.update(dt, (x, y) => this.sfx.drip(this.volAt(x, y)));
    }
    // ---------------------------------------------------------------- UiHost / CutsceneHost
    say(text) { this.note = { text, t: 0 }; }
    letterbox(on) { this.bars.to = on ? 1 : 0; if (on)
        this.bars.v = 1; }
    startPlay() { this.screens.set(this.S.play); }
    renderScene() { this.renderWorldScene(); }
    read(id) {
        const opens = items_1.ITEMS[id].opens;
        if (opens === "schematic")
            this.schemUi.open();
        else if (opens === "book")
            this.bookUi.open(id);
    }
    boostEye(level) { this.eyeBoost = level; }
    animate(dt) { this.updateWorldFx(dt); }
    stepMonologue(dt) {
        const s = this.monologue.update(dt);
        if (s.started)
            this.sfx.thoughtStart();
        for (let i = 0; i < s.typed; i++)
            this.sfx.thoughtTick(s.tone === "void");
        const b = this.bars;
        if (b.v !== b.to)
            b.v = b.to > b.v ? Math.min(b.to, b.v + dt * 4) : Math.max(b.to, b.v - dt * 2.2);
    }
    renderBars() {
        const b = this.bars.v;
        if (b <= 0)
            return;
        const e = b * b * (3 - 2 * b), h = Math.round(14 * e);
        this.ctx.fillStyle = "#000";
        this.ctx.fillRect(0, 0, exports.W, h);
        this.ctx.fillRect(0, exports.H - h, exports.W, h);
    }
    renderNote(y = exports.H - 40) {
        if (!this.note)
            return;
        const ctx = this.ctx;
        ctx.globalAlpha = (0, util_1.clamp)(3 - this.note.t, 0, 1);
        (0, font_1.drawTextS)(ctx, this.note.text, exports.W / 2, y, "#e8d8b0", 1, "center", "#000");
        ctx.globalAlpha = 1;
    }
    // ---------------------------------------------------------------- render
    render() {
        this.ctx.clearRect(0, 0, exports.W, exports.H);
        this.hiCtx.clearRect(0, 0, input_1.UI2_W, input_1.UI2_H);
        this.screens.render();
        this.renderHiUi();
        this.input.endFrame();
    }
    renderWorldScene() {
        this.view.flush();
        this.renderWorld();
        this.renderHud();
    }
    renderWorld() {
        const { camX, camY } = this.camera.renderOrigin(this.settings.data.screenShake);
        this.renderer.render({
            wctx: this.wctx,
            world: this.world,
            area: this.area,
            view: this.view,
            particles: this.particleSys,
            vision: this.vision,
            glight: this.glight,
            camX,
            camY,
            vw: this.vw,
            vh: this.vh,
            t: this.t,
            look: this.look,
            gaze: this.gaze,
            hasArm: this.hasArm,
            hideGolem: this.hideGolem,
            eyeBoost: this.eyeBoost,
            crackFlash: this.settings.data.screenFlash ? this.crackFlash : 0,
            fizzT: this.fizzT,
            shudder: this.shudder,
            tendedLevel: (p, hour) => this.tendedLevel(p, hour),
            surfaceRuneState: () => this.surfaceRuneState(),
            npcLook: (a) => this.npcLook(a),
            eyeSpot: () => this.eyeSpot(),
            interp: this.interp,
            alpha: this.clock.alpha,
            selectedActors: this.hud.selectedActors,
        });
    }
    /** Render the 2x Hi-Res UI Layer (management HUD, modals, title buttons, tooltips). */
    renderHiUi() {
        const ctx = this.hiCtx;
        const pal = this.settings.data.colorBlindPalette;
        const hitKey = (...k) => this.hit(...k);
        // Title screen mouse-clickable quick bar
        if (this.screens.is("title") && !this.hasHiModalOpen()) {
            const ptr = this.input.pointer;
            const by = input_1.UI2_H - 42;
            if ((0, components_1.hiButton)(ctx, { x: 170, y: by, w: 92, h: 20 }, "New Game", ptr, { active: true })) {
                this.sfx.init();
                this.introUi.start();
            }
            if ((0, components_1.hiButton)(ctx, { x: 274, y: by, w: 96, h: 20 }, "Save Slots", ptr)) {
                this.sfx.init();
                void this.saveModal.show(this.store);
            }
            if ((0, components_1.hiButton)(ctx, { x: 382, y: by, w: 92, h: 20 }, "Settings", ptr)) {
                this.sfx.init();
                this.settingsModal.toggle();
            }
            (0, propFont_1.drawPropText)(ctx, "Phase 0 Engine: Fixed-Timestep 1x-8x | Simulation LOD | Dynamic Areas | Save v2 | Hi-Res UI", input_1.UI2_W / 2, input_1.UI2_H - 15, components_1.UI2.dim, 1, "center");
        }
        // Play screen Management HUD shell
        if (this.screens.is("play") && !this.hasHiModalOpen()) {
            this.hud.updateAndRender(ctx, this.input, this.world, this.clock, this.feed, this.settings, hitKey, {
                setSpeed: (s) => this.setSpeed(s),
                openFloors: () => this.floorsModal.toggle(),
                openSaves: () => { void this.saveModal.show(this.store); },
                openSettings: () => this.settingsModal.toggle(),
                quickSave: () => this.saveGame(),
                openManage: (id) => { if ((0, world_1.actorById)(this.world, id))
                    this.manageUi.open(id); },
                focusCameraOn: (areaId, x, y) => {
                    if (this.area.id === areaId)
                        this.camera.snap(x, y, this.area.w, this.area.h);
                },
                createQuickFloor: () => {
                    const parent = this.area.id;
                    const depth = (this.area.spec?.depth ?? 0) + 1;
                    const a = (0, world_1.createDynamicArea)(this.world, { kind: "dungeon_floor", depth, parent, w: 36, h: 28, label: `Generated Floor D${depth}` });
                    (0, world_1.enterArea)(this.world, this.pl, a.id, a.start.x, a.start.y);
                    this.syncView();
                    this.notify({ title: `Entered ${a.spec?.label ?? a.id}`, detail: `Seed ${a.spec?.seed} (${a.w}x${a.h})`, severity: "info", category: "world", worldTime: this.world.time });
                },
            }, true);
        }
        // Modals (highest priority)
        if (this.settingsModal.open) {
            this.settingsModal.updateAndRender(ctx, this.input, this.settings, hitKey, this.hud.tips);
        }
        else if (this.saveModal.open) {
            this.saveModal.updateAndRender(ctx, this.input, this.store, {
                getWorld: () => this.world,
                onLoaded: (w, msg, rec) => {
                    this.resume(w);
                    this.say(rec ? `RECOVERED (${rec.toUpperCase()})` : "GAME LOADED");
                    this.notify({ title: rec ? "Save Recovered" : "Save Loaded", detail: msg, severity: rec ? "warn" : "success", category: "save", worldTime: w.time });
                },
                onStatus: (msg, sev = "info") => this.notify({ title: "Save System", detail: msg, severity: sev, category: "save", worldTime: this.world.time }),
            }, pal, hitKey, this.hud.tips);
        }
        else if (this.floorsModal.open) {
            this.floorsModal.updateAndRender(ctx, this.input, this.world, pal, hitKey, this.hud.tips, (areaId) => {
                this.syncView();
                this.say(`ENTERED ${areaId.toUpperCase()}`);
                this.notify({ title: `Travelled to ${areaId}`, detail: "Area caught up via simulation LOD.", severity: "info", category: "world", worldTime: this.world.time });
            });
        }
        this.hud.tips.render(ctx);
    }
    // ---------------------------------------------------------------- NPC looks & bubbles
    npcLook(a) {
        let L = this.npcLooks.get(a.id);
        if (!L) {
            const on = (0, dialogue_2.isAwake)(this.world, a.id) ? 1 : 0;
            L = { awake: on, eye: on, wakeT: 99, sleepT: 99, reach: 0, flare: 0, lift: 0, seen: -99, arrived: false };
            this.npcLooks.set(a.id, L);
        }
        return L;
    }
    updateNpcLooks(dt) {
        const area = this.area;
        for (const a of this.world.actors) {
            if (a.area !== area.id || a.id === this.world.playerId)
                continue;
            if (a.kind === "folk") {
                this.updateFolkLook(a);
                continue;
            }
            if (a.kind === "keeper")
                continue;
            if (!(0, npcs_1.npcDef)(a.npc)) {
                this.updateWorkerLook(a, dt);
                continue;
            }
            if (a.kind !== "npc")
                continue;
            const def = (0, actors_1.actorDef)(a);
            const L = this.npcLook(a), on = (0, dialogue_2.isAwake)(this.world, a.id);
            L.wakeT += dt;
            L.sleepT += dt;
            const target = on ? (L.wakeT > 0.6 ? 1 : 0) : (L.sleepT > 0.7 ? 0 : 1);
            L.awake += (0, util_1.clamp)(target - L.awake, -dt / 1.1, dt / 1.1);
            if (on)
                L.eye = L.wakeT < 0.9 ? (Math.random() < 0.45 + L.wakeT * 0.5 ? 1 : 0.12) : 1;
            else
                L.eye = Math.max(0, Math.min(L.eye, 1 - L.sleepT / 1.2));
            if (on && L.wakeT < 0.05)
                L.flare = 0.8;
            L.flare = Math.max(0, L.flare - dt * 1.5);
            L.reach = Math.max(0, L.reach - dt * 0.7);
            const el = def.eyeLight;
            if (el) {
                const lt = this.view.dynamicLight("npc:" + a.id, () => (0, light_1.makeLight)(a.x + el.dx, a.y + el.dy, el.rad, el.col, 0, 0.05, "npc:" + a.id));
                lt.int = L.eye * 0.42 + L.flare * 0.5 + (L.reach > 0.8 ? 0.25 : 0);
            }
        }
    }
    updateWorkerLook(a, dt) {
        const L = this.npcLook(a);
        const inp = { powered: (0, actorStats_1.powered)(a), active: (0, actors_2.actorActive)(a), moving: a.moving, hasCore: !!a.powerCore };
        if (!L.worker || this.t - L.seen > 0.5) {
            L.worker = (0, workerAnim_1.initWorkerAnim)(inp);
            if (!L.arrived)
                L.lift = 0;
        }
        L.seen = this.t;
        L.arrived = false;
        (0, workerAnim_1.stepWorkerAnim)(L.worker, dt, inp);
        for (const cue of (0, workerAnim_1.drainCues)(L.worker))
            this.workerCue(a, cue);
        L.flare = Math.max(0, L.flare - dt * 0.8);
        const task = a.task;
        if (task?.kind === "channel" && task.target) {
            const c = task.target, lift = task.dur - 1.0;
            L.lift = Math.min(task.t, lift) * 5.5 + Math.sin(task.t * 3);
            const n = Math.floor(dt * 150 + Math.random());
            for (let i = 0; i < n; i++) {
                const ang = Math.random() * Math.PI * 2, r = 12 + Math.random() * 26;
                this.spawn({ x: c.x + Math.cos(ang) * r, y: c.y + Math.sin(ang) * r, z: 1, vx: -Math.cos(ang) * r * 0.8, vy: -Math.sin(ang) * r * 0.8, vz: 8 + Math.random() * 16, life: 1.0, kind: "rune", col: Math.random() < 0.5 ? "#c0a0ff" : "#80e0ff", emit: true, g: -5 });
            }
            if (task.t - dt <= 0)
                this.runeBlip(c.x, c.y, 0.7);
        }
        else
            L.lift = Math.max(0, L.lift - dt * 26);
        const lt = this.view.dynamicLight("npc:" + a.id, () => (0, light_1.makeLight)(a.x, a.y - 9, 38, [1, 0.38, 0.34], 0, 0.07, "npc:" + a.id));
        lt.x = a.x;
        lt.y = a.y - 9 - L.lift;
        if (Math.abs(lt.x - lt.vx) > 2 || Math.abs(lt.y - lt.vy) > 2)
            (0, light_1.computeVis)(lt, this.area);
        lt.int = L.worker.out.core * 0.2 + L.worker.out.eye * 0.1 + (task?.kind === "channel" ? 0.3 : 0);
    }
    updateFolkLook(a) {
        if ((0, folk_1.archetypeOf)(a).garb !== "watch")
            return;
        const on = (0, folk_1.folkPresent)(a) && (0, actors_2.folkLantern)(this.world, a);
        const side = a.facing === "left" ? -1 : a.facing === "right" ? 1 : -4 / 3;
        const lx = a.x + side * 4, ly = a.y - 6;
        const lt = this.view.dynamicLight("folk:" + a.id, () => (0, light_1.makeLight)(lx, ly, 70, [1, 0.7, 0.38], 0, 0.14, "folk:" + a.id));
        lt.x = lx;
        lt.y = ly;
        if (on && (Math.abs(lt.x - lt.vx) > 2 || Math.abs(lt.y - lt.vy) > 2))
            (0, light_1.computeVis)(lt, this.area);
        lt.int = on ? 0.62 : 0;
    }
    renderFolkBubbles(dt) {
        const ctx = this.wctx, area = this.area, camX = this.cam.x, camY = this.cam.y;
        for (const [id, b] of this.bubbles) {
            b.t += dt;
            if (b.t > b.dur)
                this.bubbles.delete(id);
        }
        const shop = (0, shops_1.shopOfArea)(area.id), counter = shop && !(0, shops_1.shopOpen)(this.world, shop.id) ? area.base.spots?.find((s) => s.id === "keeper") : undefined;
        if (counter)
            (0, keeperArt_1.drawClosedSign)(ctx, Math.round(counter.x - camX), Math.round(counter.y - camY) + 12);
        for (const a of this.world.actors) {
            if (a.area !== area.id || !(a.kind === "folk" ? (0, folk_1.folkPresent)(a) && !!a.life : a.kind === "keeper" && (0, shops_1.keeperPresent)(a)))
                continue;
            const x = Math.round(a.x - camX), y = Math.round(a.y - camY);
            if (x < -60 || y < -60 || x > this.vw + 60 || y > this.vh + 60)
                continue;
            if (a.life?.pose === "lie") {
                const k = (this.t * 0.5 + (0, daycycle_1.hash01)(a.id, 4)) % 1;
                ctx.globalAlpha = Math.sin(k * Math.PI) * 0.8;
                (0, font_1.drawTextS)(ctx, k < 0.5 ? "z" : "Z", x + 4 + k * 6, y - 26 - k * 10, "#d8e0f0", 1, "left", "#1a1418");
                ctx.globalAlpha = 1;
            }
            const b = this.bubbles.get(a.id);
            if (!b)
                continue;
            const fade = (0, util_1.clamp)(Math.min(b.t / 0.12, (b.dur - b.t) / 0.25), 0, 1), top = y - (a.life?.pose === "sit" ? 27 : a.kind === "keeper" ? 26 : 30);
            ctx.globalAlpha = fade;
            if (b.text)
                (0, folkArt_1.drawSpeech)(ctx, b.text, x, top, this.vw);
            else if (b.icon)
                (0, folkArt_1.drawChatIcon)(ctx, b.icon, x + 3, top - Math.round((1 - fade) * 3));
            ctx.globalAlpha = 1;
        }
    }
    workerCue(a, cue) {
        const near = this.volAt(a.x, a.y) > 0.15;
        const dust = (n) => { for (let i = 0; i < n; i++)
            this.spawn({ x: a.x + (Math.random() - 0.5) * 12, y: a.y + 1, z: 1, vx: (Math.random() - 0.5) * 22, vy: (Math.random() - 0.5) * 8, vz: 6 + Math.random() * 6, life: 0.6, kind: "dust", col: "#8a7a68", g: 20 }); };
        switch (cue) {
            case "spark":
                this.coreSparks(a, 9, true);
                if (near)
                    this.sfx.spark();
                break;
            case "creak":
                if (near)
                    this.sfx.scrape();
                break;
            case "lamp":
                this.coreSparks(a, 3, true);
                if (near)
                    this.sfx.wakeSputter();
                break;
            case "plant":
                dust(7);
                if (near)
                    this.sfx.thud();
                break;
            case "jolt":
                this.coreSparks(a, 8, false);
                dust(3);
                if (near)
                    this.sfx.clank();
                break;
            case "lampOut":
                if (near)
                    this.sfx.tone(420, 0.25, "sine", 0.03, 110);
                break;
            case "settle":
                if (near)
                    this.sfx.tone(190, 0.7, "sine", 0.035, 70);
                break;
        }
    }
    runeBlip(x, y, k = 1) {
        const v = this.volAt(x, y) * k;
        if (v > 0.05) {
            this.sfx.tone(520, 0.35, "sine", 0.06 * v, 1040);
            this.sfx.tone(780, 0.5, "triangle", 0.04 * v, undefined, 0.07);
        }
    }
    runeBurst(x, y) {
        this.runeBlip(x, y);
        this.particleSys.runeBurst(x, y);
    }
    runeRefused(x, y) {
        this.sfx.fizzle();
        this.fizzT = 0.5;
        this.runeDud = { x, y, t: 0 };
        this.shake(0.25, 1.2);
        for (let i = 0; i < 18; i++) {
            const a = Math.random() * Math.PI * 2, rr = 44 + Math.random() * 13;
            this.spawn({ x: x + Math.cos(a) * rr, y: y + Math.sin(a) * rr, z: 1, vx: (Math.random() - 0.5) * 60, vy: (Math.random() - 0.5) * 40, vz: 30 + Math.random() * 30, life: 0.5, kind: "spark", col: Math.random() < 0.5 ? "#ff6a8a" : "#a070ff", emit: true, g: 120 });
        }
    }
    workerWalked(e) {
        const here = this.pl.area, a = (0, world_1.actorById)(this.world, e.actor);
        const from = e.fromArea === here ? (0, portals_1.portalById)(this.area, e.from) : undefined;
        const out = !from && a && e.toArea === here ? (0, portals_1.portalById)(this.area, e.to) : undefined;
        const at = from ? { x: from.x + from.w / 2, y: from.y + from.h / 2, door: !!from.door } : out && a ? { x: a.x, y: a.y, door: !!out.door } : null;
        if (!at || this.volAt(at.x, at.y) < 0.15)
            return;
        if (at.door)
            this.sfx.open();
        else
            this.sfx.step(true);
    }
    workerTravelled(e) {
        const a = (0, world_1.actorById)(this.world, e.actor), pa = this.pl.area;
        const from = runes_1.RUNE_NODES[e.from], p = from && from.area === pa ? this.area.prop(from.prop) : null;
        if (p)
            this.runeBurst(p.x, p.y);
        if (a && a.area === pa) {
            const L = this.npcLook(a);
            L.lift = 13;
            L.arrived = true;
            this.runeBurst(a.x, a.y);
        }
    }
    // ---------------------------------------------------------------- base 1x HUD
    renderHud() {
        const ctx = this.ctx;
        if (this.screens.is("play") && this.target) {
            const wctx = this.wctx, it = this.target;
            const x = Math.round(it.x - this.cam.x), y = Math.round(it.y - this.cam.y - (it.itemZ ?? 10) - 14 + Math.sin(this.t * 4) * 1.5);
            wctx.fillStyle = "rgba(0,0,0,0.6)";
            wctx.fillRect(x - 3, y, 7, 1);
            wctx.fillRect(x - 2, y + 1, 5, 1);
            wctx.fillRect(x - 1, y + 2, 3, 1);
            wctx.fillStyle = "#d8cfa8";
            wctx.fillRect(x - 2, y - 1, 5, 1);
            wctx.fillRect(x - 1, y, 3, 1);
            wctx.fillRect(x, y + 1, 1, 1);
        }
        if (this.screens.is("play") || this.screens.is("dialogue"))
            this.renderFolkBubbles(this.frameDt);
        if (this.settings.data.screenFlash && this.arriveFade > 0) {
            ctx.fillStyle = `rgba(235,240,255,${this.arriveFade})`;
            ctx.fillRect(0, 0, exports.W, exports.H);
        }
        if (this.doorFade > 0) {
            ctx.fillStyle = `rgba(6,5,9,${this.doorFade})`;
            ctx.fillRect(0, 0, exports.W, exports.H);
        }
        this.renderBars();
        const bar = this.bars.v * this.bars.v * (3 - 2 * this.bars.v);
        (0, monologue_1.drawMonologue)(ctx, this.monologue, this.t, (this.settings.data.showHudBar ? 15 : 7) + Math.round(12 * bar));
        if (this.screens.is("play")) {
            this.renderNote();
            this.vision.drawHud(ctx, exports.W);
            this.renderClock();
        }
        if (this.debugMsg) {
            ctx.globalAlpha = (0, util_1.clamp)(2 - this.debugMsg.t, 0, 1);
            (0, font_1.drawTextS)(ctx, this.debugMsg.text, exports.W / 2, 16, "#ff9a5a", 1, "center");
            ctx.globalAlpha = 1;
        }
        if (this.debugHud || this.debugNoclip || this.debugSpeed) {
            const pl = this.pl, modes = [this.debugNoclip ? "NOCLIP" : "", this.debugSpeed ? `SPEED X${this.debugSpeedMult}` : ""].filter(Boolean).join("  ");
            const lines = [
                ...(this.debugHud ? [`${pl.area.toUpperCase()}  X ${Math.round(pl.x)}  Y ${Math.round(pl.y)}  TILE ${Math.floor(pl.x / tiles_1.TS)},${Math.floor((pl.y - 3) / tiles_1.TS)}`] : []),
                ...(modes ? [`DEBUG: ${modes}`] : []),
            ];
            lines.forEach((l, i) => (0, font_1.drawTextS)(ctx, l, 4, exports.H - 8 - (lines.length - 1 - i) * 8, "#ff9a5a", 1, "left", "#000"));
        }
        if (!this.screens.is("schem") && !this.screens.is("dialogue"))
            this.renderToast(exports.H - 26);
    }
    renderClock() {
        if (!this.area.base.outdoor && !(0, world_1.hasFlag)(this.world, flags_1.FLAGS.tutorialDone))
            return;
        const ctx = this.ctx, hour = (0, daytime_1.worldHour)(this.world), ph = (0, daycycle_1.phaseAt)(hour), x = exports.W - 35, y = exports.H - 11;
        ctx.fillStyle = "rgba(6,5,9,0.6)";
        ctx.fillRect(x - 3, y - 2, 36, 11);
        const px = (c, cells) => { ctx.fillStyle = c; for (const [cx, cy, w = 1, h = 1] of cells)
            ctx.fillRect(x + cx, y + cy, w, h); };
        if (ph === "day") {
            px("#ffb030", [[3, 0], [3, 6], [0, 3], [6, 3], [1, 1], [5, 1], [1, 5], [5, 5]]);
            px("#ffd860", [[2, 2, 3, 3]]);
        }
        else if (ph === "night") {
            px("#c8d4f0", [[2, 1, 3, 1], [1, 2, 2, 1], [1, 3, 2, 1], [1, 4, 3, 1], [2, 5, 3, 1]]);
            px("#7a88b0", [[5, 2], [6, 0]]);
        }
        else {
            px("#ff9a40", [[2, 3, 3, 2], [1, 4, 5, 1], [3, 1], [1, 2], [5, 2]]);
            px("#8a5a3a", [[0, 5, 7, 1]]);
        }
        (0, font_1.drawText)(ctx, (0, daycycle_1.clockText)(hour), x + 10, y + 1, ph === "night" ? "#a8b4d8" : ph === "day" ? "#e8d8a0" : "#f0b078");
    }
    renderToast(y) {
        const ctx = this.ctx;
        if (this.toast) {
            const t = this.toast.t;
            const a = t < 0.2 ? t / 0.2 : t > 2.5 ? 1 - (t - 2.5) / 0.5 : 1;
            ctx.globalAlpha = (0, util_1.clamp)(a, 0, 1);
            const name = this.toast.name;
            const w = name.length * 4 + 30;
            const x = Math.round(exports.W / 2 - w / 2);
            ctx.fillStyle = "#0c0a0e";
            ctx.fillRect(x, y, w, 20);
            ctx.fillStyle = "#3a3540";
            ctx.fillRect(x, y, w, 1);
            ctx.fillRect(x, y + 19, w, 1);
            ctx.fillRect(x, y, 1, 20);
            ctx.fillRect(x + w - 1, y, 1, 20);
            ctx.drawImage(this.toast.icon.a, x + 3, y + 2);
            (0, font_1.drawText)(ctx, name, x + 23, y + 8, "#d8d0b8");
            ctx.globalAlpha = 1;
        }
    }
}
exports.Game = Game;
function visionId(t) {
    return t.propId ?? t.looseId ?? t.actorId ?? (t.tx !== undefined && t.ty !== undefined ? `tile:${t.tx},${t.ty}` : null);
}
