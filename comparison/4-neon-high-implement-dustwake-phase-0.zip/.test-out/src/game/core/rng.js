"use strict";
// Pure, DOM-free randomness helpers. Shared by simulation and presentation.
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeededRng = void 0;
exports.mulberry = mulberry;
exports.hash2 = hash2;
/** mulberry32 as a closure. Used by procedural art (deterministic per seed). */
function mulberry(seed) {
    let a = seed >>> 0;
    return () => {
        a = (a + 0x6d2b79f5) >>> 0;
        let t = a;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}
/**
 * The same mulberry32 generator, but with its state exposed so it can be saved
 * and restored. All *simulation* randomness goes through one of these (owned by
 * the World); presentation-only randomness (particles, flicker, shake) keeps
 * using Math.random.
 */
class SeededRng {
    constructor(seed) {
        Object.defineProperty(this, "state", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.state = seed >>> 0;
    }
    next() {
        this.state = (this.state + 0x6d2b79f5) >>> 0;
        let t = this.state;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    }
}
exports.SeededRng = SeededRng;
function hash2(x, y, s = 0) {
    let h = (x * 374761393 + y * 668265263 + s * 982451653) | 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
}
