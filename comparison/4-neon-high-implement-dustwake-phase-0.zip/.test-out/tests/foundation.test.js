"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Foundations: change propagation, save/load + migration, determinism,
// non-player actors performing queued work, travel between areas.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const world_1 = require("../src/game/world/world");
const areas_1 = require("../src/game/world/areas");
const save_1 = require("../src/game/world/save");
const inventory_1 = require("../src/game/sim/inventory");
const tasks_1 = require("../src/game/sim/tasks");
const step_1 = require("../src/game/sim/step");
const interact_1 = require("../src/game/sim/interact");
const tiles_1 = require("../src/game/content/tiles");
const flags_1 = require("../src/game/content/flags");
const helpers_1 = require("./helpers");
(0, node_test_1.test)("tile changes publish padded dirty rects and invalidate derived data", () => {
    const w = (0, helpers_1.newWorld)();
    const a = (0, world_1.currentArea)(w);
    const rects = [];
    const off = a.onChange((r) => rects.push(r));
    const before = (0, interact_1.interactables)(a);
    strict_1.default.equal((0, interact_1.interactables)(a), before, "cached while unchanged");
    a.setTile(51, 5, tiles_1.T.FLOOR);
    strict_1.default.deepEqual(rects, [{ x0: 49, y0: 3, x1: 53, y1: 7 }]);
    strict_1.default.notEqual((0, interact_1.interactables)(a), before);
    strict_1.default.ok(!(0, interact_1.interactables)(a).some((i) => i.kind === "door"));
    off();
    a.setTile(0, 0, tiles_1.T.FLOOR);
    strict_1.default.equal(rects.length, 1, "unsubscribed");
});
/** A mid-tutorial world with pending scheduled work and an in-progress task. */
function midGame() {
    const w = (0, helpers_1.newWorld)(4242);
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "limbrack@65.5,3"));
    (0, helpers_1.slamAt)(w, (0, helpers_1.find)(w, (i) => i.kind === "cracked"));
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "skeleton@66,32"));
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "door"));
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "lectern@5,29"));
    // open a container and stop before the delayed grant fires, mid-task
    const hearth = (0, helpers_1.propItem)(w, "hearth@60.5,43");
    const pl = (0, world_1.player)(w);
    pl.x = hearth.x;
    pl.y = hearth.y + 9;
    pl.facing = "up";
    (0, helpers_1.frame)(w, { ix: 0, iy: 0, use: true });
    while (!w.scheduled.length)
        (0, helpers_1.frame)(w);
    (0, helpers_1.events)(w);
    return w;
}
(0, node_test_1.test)("save/load round-trips world changes, pending schedule and in-progress work", () => {
    const w = midGame();
    const json = JSON.stringify((0, save_1.serialize)(w));
    const w2 = (0, save_1.deserialize)(JSON.parse(json));
    strict_1.default.deepEqual((0, save_1.serialize)(w2), (0, save_1.serialize)(w));
    const a2 = (0, world_1.currentArea)(w2);
    strict_1.default.equal(a2.tile(51, 5), tiles_1.T.FLOOR);
    strict_1.default.equal(a2.tile(47, 10), tiles_1.T.FLOOR);
    strict_1.default.ok((0, world_1.hasFlag)(w2, flags_1.FLAGS.golemArm));
    strict_1.default.ok((0, world_1.player)(w2).task, "task in progress survives");
    strict_1.default.equal(w2.scheduled.length, 1);
    strict_1.default.ok(json.length < 20000, `save is a diff, not a dump (${json.length} bytes)`);
    // ...and both continue identically (determinism)
    (0, helpers_1.frames)(w, 120);
    (0, helpers_1.frames)(w2, 120);
    strict_1.default.deepEqual((0, save_1.serialize)(w2), (0, save_1.serialize)(w));
    strict_1.default.ok((0, inventory_1.hasItem)((0, world_1.player)(w2), "glyph0"), "scheduled grant fired after load");
});
(0, node_test_1.test)("same seed + same inputs => identical worlds", () => {
    strict_1.default.deepEqual((0, save_1.serialize)(midGame()), (0, save_1.serialize)(midGame()));
});
(0, node_test_1.test)("migrations upgrade old saves and newer saves are rejected", () => {
    const s = (0, save_1.serialize)((0, helpers_1.newWorld)());
    strict_1.default.equal(s.version, save_1.SAVE_VERSION);
    strict_1.default.throws(() => (0, save_1.migrate)({ ...s, version: save_1.SAVE_VERSION + 1 }), /newer/);
    strict_1.default.throws(() => (0, save_1.migrate)({ nope: 1 }), /not a Dustwake save/);
    // fixture: pretend v1 -> v2 renamed playTime
    const v2 = (0, save_1.migrate)(s, { ...save_1.MIGRATIONS, [save_1.SAVE_VERSION]: (o) => ({ ...o, version: save_1.SAVE_VERSION + 1, stats: { playTime: o.playTime } }) }, save_1.SAVE_VERSION + 1);
    strict_1.default.equal(v2.version, save_1.SAVE_VERSION + 1);
    strict_1.default.equal(v2.stats.playTime, s.playTime);
});
(0, node_test_1.test)("non-player actors perform queued work over world time", () => {
    const w = (0, helpers_1.newWorld)();
    const a = (0, world_1.makeActor)("helper", "fixture", "dungeon", 100, 100);
    w.actors.push(a);
    (0, tasks_1.enqueueTask)(a, { kind: "reach", dur: 0.5, effect: { op: "cue", cue: "scrape" } });
    (0, tasks_1.enqueueTask)(a, { kind: "push", dur: 0.5, effect: { op: "cue", cue: "clank" } });
    for (let i = 0; i < 30; i++)
        (0, step_1.stepWorld)(w, 1 / 60);
    strict_1.default.equal(a.queue.length, 1, "second task waits");
    for (let i = 0; i < 60; i++)
        (0, step_1.stepWorld)(w, 1 / 60);
    const cues = (0, helpers_1.events)(w).flatMap((e) => (e.t === "cue" ? [e.cue] : []));
    strict_1.default.deepEqual(cues, ["scrape", "clank"]);
    strict_1.default.equal(a.task, null);
    // actors are saved
    const w2 = (0, save_1.deserialize)((0, save_1.serialize)(w));
    strict_1.default.ok(w2.actors.some((x) => x.id === "helper" && x.kind === "fixture"));
});
(0, node_test_1.test)("scheduled effects run on simulation time only", () => {
    const w = (0, helpers_1.newWorld)();
    (0, tasks_1.schedule)(w, 1, (0, world_1.player)(w), { op: "grantItem", item: "coin" });
    for (let i = 0; i < 59; i++)
        (0, step_1.stepWorld)(w, 1 / 60);
    strict_1.default.ok(!(0, inventory_1.hasItem)((0, world_1.player)(w), "coin"));
    (0, step_1.stepWorld)(w, 2 / 60);
    strict_1.default.ok((0, inventory_1.hasItem)((0, world_1.player)(w), "coin"));
});
(0, node_test_1.test)("travel to a second area of a different size; both areas persist", () => {
    const fixture = () => {
        const W = 10, H = 6, n = W * H;
        const grid = new Uint8Array(n).fill(tiles_1.T.FLOOR);
        return {
            id: "fixture", w: W, h: H, grid, plan: grid.slice(), style: new Uint8Array(n), tvar: new Uint8Array(n),
            rooms: [], props: [], decals: [], lights: [], loose: [], ritual: { x: 80, y: 48 }, start: { x: 40, y: 40 }, exits: [], drips: [],
        };
    };
    areas_1.AREAS.fixture = fixture;
    try {
        const w = (0, helpers_1.newWorld)();
        const pl = (0, world_1.player)(w);
        (0, world_1.currentArea)(w).setTile(51, 5, tiles_1.T.FLOOR);
        (0, world_1.enterArea)(w, pl, "fixture", 40, 40);
        strict_1.default.equal((0, world_1.currentArea)(w).id, "fixture");
        strict_1.default.equal((0, world_1.currentArea)(w).w, 10);
        strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "areaEntered"));
        (0, helpers_1.frames)(w, 30, { ix: 1, iy: 0, use: false });
        strict_1.default.ok(pl.x > 40, "can move in the new area");
        const w2 = (0, save_1.deserialize)((0, save_1.serialize)(w));
        strict_1.default.equal((0, world_1.currentArea)(w2).id, "fixture");
        strict_1.default.equal((0, world_1.getArea)(w2, "dungeon").tile(51, 5), tiles_1.T.FLOOR, "dungeon changes kept while away");
    }
    finally {
        delete areas_1.AREAS.fixture;
    }
});
