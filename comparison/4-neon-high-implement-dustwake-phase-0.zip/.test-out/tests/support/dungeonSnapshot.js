"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapShot = mapShot;
exports.viewShot = viewShot;
exports.region = region;
exports.run = run;
// Developer tool (not a test): renders the tutorial dungeon to PNG without a
// browser, for auditing its layout and art. Like daySnapshot.ts it drives the
// real host (a Game on a pixel canvas, stepped with update() and drawn with
// render()), so everything the player would see is there: the baked tiles and
// decals, every prop, the tile sprites (rubble, the cracked wall, pillars, the
// door, bars), the NPCs, flames, the roof crack's shaft and the real lighting.
//
// The whole map is drawn in one frame by zooming the view out past the area's
// size, in three modes:
//   lit   what the game shows (nothing but the dungeon's own lights)
//   dim   the same lights over a raised ambient, so dark corners can be read
//   flat  full-bright albedo plus glow, no lighting at all (art and layout)
// and cut into overlapping regions with tile coordinates along the top and
// left edges. In-game close-ups (the golem standing somewhere, at 1x) show a
// place exactly as it is met in play. The layout audit the town uses
// (townAudit.ts: props in walls, things standing in each other, things hung
// on walls that are not there) is run over the dungeon too.
//
//   node scripts/dungeonPreview.mjs                 -> .preview/dungeon/*.png, and the audit's findings
//   node scripts/dungeonPreview.mjs name=x,y,w,h[,scale[,lit|dim|flat[,hour]]] ...
//                                                   -> only those regions (tiles) of the whole-map render
//   node scripts/dungeonPreview.mjs name=@x,y[,scale[,lit|dim|flat[,hour]]] ...
//                                                   -> only those in-game close-ups (the golem at tile x,y)
const node_fs_1 = require("node:fs");
const uiSnapshot_1 = require("./uiSnapshot");
const daySnapshot_1 = require("./daySnapshot");
const townAudit_1 = require("./townAudit");
const game_1 = require("../../src/game/game");
const world_1 = require("../../src/game/world/world");
const debug_1 = require("../../src/game/sim/debug");
const daytime_1 = require("../../src/game/sim/daytime");
const flags_1 = require("../../src/game/content/flags");
const tiles_1 = require("../../src/game/content/tiles");
const font_1 = require("../../src/game/font");
const DT = 1 / 60;
const AREA = "dungeon";
/* eslint-disable @typescript-eslint/no-explicit-any */
const mk = (w, h) => {
    const c = globalThis.document.createElement("canvas");
    c.width = w;
    c.height = h;
    c.getContext();
    return c;
};
/** A game in play with the golem standing at a tile, at an hour of the day, settled for a moment. */
function host(tx, ty, hour) {
    const g = new game_1.Game(mk(320, 180), mk(320, 180)), w = (0, world_1.createWorld)(7);
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
    if (!(0, debug_1.teleportTo)(w, (0, world_1.player)(w), AREA, tx * tiles_1.TS + 8, ty * tiles_1.TS + 8))
        throw new Error(`no room for the golem at ${tx},${ty}`);
    g.resume(w);
    (0, daytime_1.advanceDayTo)(w, hour);
    for (let i = 0; i < 90; i++)
        g.update(DT);
    return { g, w };
}
/** Swap the frame's lighting for an audit view (the game's own is left alone for `lit`). */
function relight(g, mode) {
    if (mode === "lit")
        return;
    const L = g.lighting, orig = L.compose.bind(L);
    L.compose = (s, e, o, amb, steps, gain) => mode === "flat" ? orig(s, e, o, [1, 1, 1], steps, 0) : orig(s, e, o, [Math.max(amb[0], 0.5), Math.max(amb[1], 0.5), Math.max(amb[2], 0.55)], steps, gain);
}
function frame(g) {
    g.canvas.getContext(); // the snapshot canvas only takes a new size here
    g.render();
    return g.canvas;
}
function crop(src, x, y, w, h) {
    const c = mk(w, h);
    c.getContext().drawImage(src, x, y, w, h, 0, 0, w, h);
    return c;
}
/** The whole dungeon in one frame, with nobody in it. */
function mapShot(mode, hour = 1) {
    const { g, w } = host(9, 38, hour), a = (0, world_1.getArea)(w, AREA);
    const W = a.w * tiles_1.TS, H = a.h * tiles_1.TS;
    g.hideGolem = true;
    g.setZoom(Math.ceil(Math.max(W / 320, H / 180)));
    g.cam.x = 0;
    g.cam.y = 0;
    relight(g, mode);
    return crop(frame(g), 0, 0, W, H);
}
/** The view with the golem standing at a tile: what the player sees there. */
function viewShot(tx, ty, mode, hour = 1) {
    const { g } = host(tx, ty, hour);
    relight(g, mode);
    const f = frame(g);
    return crop(f, 0, 0, f.width, f.height);
}
/** A region of a map render (tiles), with tile coordinates along the top and left. */
function region(map, x, y, w, h) {
    const mx = 10, my = 7, out = mk(w * tiles_1.TS + mx, h * tiles_1.TS + my), ctx = out.getContext();
    ctx.fillStyle = "#101014";
    ctx.fillRect(0, 0, out.width, out.height);
    ctx.drawImage(map, x * tiles_1.TS, y * tiles_1.TS, w * tiles_1.TS, h * tiles_1.TS, mx, my, w * tiles_1.TS, h * tiles_1.TS);
    for (let i = 0; i < w; i++)
        (0, font_1.drawText)(ctx, String(x + i), mx + i * tiles_1.TS + 8, 1, (x + i) % 5 ? "#8a8a94" : "#ffffff", 1, "center");
    for (let j = 0; j < h; j++)
        (0, font_1.drawText)(ctx, String(y + j), mx - 1, my + j * tiles_1.TS + 6, (y + j) % 5 ? "#8a8a94" : "#ffffff", 1, "right");
    return out;
}
/** The default sheet: the map in nine overlapping regions. */
const REGIONS = [
    ["nw", 0, 0, 26, 20], ["n", 23, 0, 26, 20], ["ne", 46, 0, 26, 20],
    ["w", 0, 18, 26, 20], ["c", 23, 18, 26, 20], ["e", 46, 18, 26, 20],
    ["sw", 0, 36, 26, 20], ["s", 23, 36, 26, 20], ["se", 46, 36, 26, 20],
];
/** In-game close-ups: the places most worth seeing as the player meets them. */
const VIEWS = [
    ["throne_night", 34, 9, 1], ["throne_day", 34, 9, 12], ["crack_east", 49, 10, 1], ["crack_west", 45, 10, 1],
    ["greathall_n", 35, 25, 1], ["greathall_s", 35, 37, 1], ["barracks", 59, 17, 1], ["gaol", 57, 34, 1],
    ["start", 9, 38, 1], ["library", 10, 28, 1], ["circle", 11, 12, 1], ["chapel", 23, 49, 1], ["vestibule", 35, 48, 1], ["kitchen", 60, 46, 1],
];
function run(dir = ".preview/dungeon", args = []) {
    (0, daySnapshot_1.installDom)();
    (0, node_fs_1.mkdirSync)(dir, { recursive: true });
    const save = (name, c, scale = 1) => { (0, node_fs_1.writeFileSync)(`${dir}/${name}.png`, (0, uiSnapshot_1.png)(c, scale)); console.log(`${dir}/${name}.png  ${c.width * scale}x${c.height * scale}`); };
    const maps = new Map();
    const map = (mode, hour) => { const k = `${mode}@${hour}`; if (!maps.has(k))
        maps.set(k, mapShot(mode, hour)); return maps.get(k); };
    if (args.length) {
        for (const arg of args) {
            const [name, spec] = arg.split("=");
            if (!spec)
                throw new Error(`expected name=x,y,w,h[,scale[,mode[,hour]]] or name=@x,y[,scale[,mode[,hour]]], got "${arg}"`);
            const close = spec.startsWith("@"), p = (close ? spec.slice(1) : spec).split(","), n = close ? 2 : 4;
            const scale = Number(p[n] ?? 3), mode = (p[n + 1] ?? "dim"), hour = Number(p[n + 2] ?? 1);
            if (close)
                save(name, viewShot(Number(p[0]), Number(p[1]), mode, hour), scale);
            else
                save(name, region(map(mode, hour), Number(p[0]), Number(p[1]), Number(p[2]), Number(p[3])), scale);
        }
        return 0;
    }
    save("map_lit", map("lit", 1));
    save("map_dim", map("dim", 1));
    save("map_flat", map("flat", 1));
    save("map_lit_noon", map("lit", 12));
    for (const [name, x, y, w, h] of REGIONS) {
        save(`dim_${name}`, region(map("dim", 1), x, y, w, h), 3);
        save(`flat_${name}`, region(map("flat", 1), x, y, w, h), 3);
    }
    for (const [name, tx, ty, hour] of VIEWS)
        save(`view_${name}`, viewShot(tx, ty, "lit", hour), 3);
    // What the audit reports that is there on purpose (tests/dungeonAudit.test.ts names the same things): the
    // boulders heaped on the collapsed SURFACE GATE's rubble and the seam of night air buried in it, and the
    // places nobody can walk to yet (behind the cracked wall, the locked door, the gaol's bars).
    const byDesign = (f) => (f.check === "in-wall" && f.msg.startsWith("rockpile@")) || f.check === "light" || f.check === "sealed";
    const found = (0, townAudit_1.auditArea)(AREA), wrong = found.filter((f) => !byDesign(f));
    for (const f of found)
        console.log(`${byDesign(f) ? "(by design) " : ""}[${f.check}] ${f.msg}`);
    console.log(wrong.length ? `${wrong.length} finding(s) in the dungeon's layout` : `dungeon layout: clean (${found.length} by design)`);
    return wrong.length ? 1 : 0;
}
