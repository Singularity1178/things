"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tile = exports.chestCount = exports.chestProp = exports.worker = exports.DT = exports.BENCH = exports.CHEST = exports.WORKER_ID = void 0;
exports.beside = beside;
exports.besideChest = besideChest;
exports.fixture = fixture;
exports.until = until;
exports.finishTask = finishTask;
// The worker/storage fixture the screen tests share: the ?debug foundations
// (a lesser golem with a ruby core, a 32-slot chest and a bench in the workshop,
// a tree and a rock in the yard, the rune link between them), with the worker's
// opening order cancelled and the player beside it.
const world_1 = require("../../src/game/world/world");
const jobs_1 = require("../../src/game/sim/jobs");
const debugFoundations_1 = require("../../src/game/sim/debugFoundations");
const step_1 = require("../../src/game/sim/step");
const helpers_1 = require("../helpers");
const tiles_1 = require("../../src/game/content/tiles");
(0, debugFoundations_1.registerFoundations)();
exports.WORKER_ID = "debug.worker";
exports.CHEST = { area: "debug_workshop", prop: "chest.fixture" };
exports.BENCH = { area: "debug_workshop", prop: "bench.fixture" };
exports.DT = 0.05;
const worker = (w) => (0, world_1.actorById)(w, exports.WORKER_ID);
exports.worker = worker;
const chestProp = (w) => (0, world_1.getArea)(w, exports.CHEST.area).prop(exports.CHEST.prop);
exports.chestProp = chestProp;
const chestCount = (w, item) => ((0, exports.chestProp)(w).inventory ?? []).reduce((n, s) => n + (s?.item === item ? s.n : 0), 0);
exports.chestCount = chestCount;
/** Stand just below `a`, facing it, as the player does to use it. */
function beside(w, a) {
    const pl = (0, world_1.player)(w);
    pl.x = a.x;
    pl.y = a.y + 11;
    pl.vx = 0;
    pl.vy = 0;
    pl.facing = "up";
    pl.area = a.area;
}
/** Stand just below the chest. */
function besideChest(w) {
    const pl = (0, world_1.player)(w), p = (0, exports.chestProp)(w);
    pl.x = p.x;
    pl.y = p.y + 9;
    pl.vx = 0;
    pl.vy = 0;
    pl.facing = "up";
}
/** The foundations with the worker idle and powered, and the player beside it. */
function fixture(seed = 1178) {
    const w = (0, debugFoundations_1.foundationDemo)(seed);
    (0, jobs_1.cancelJob)(w, (0, exports.worker)(w));
    w.events = [];
    beside(w, (0, exports.worker)(w));
    return { w, pl: (0, world_1.player)(w), worker: (0, exports.worker)(w) };
}
/** Step the world (the player stays put) until `check` holds. */
function until(w, check, limit = 6000) {
    for (let i = 0; i < limit && !check(); i++)
        (0, step_1.stepWorld)(w, exports.DT);
    if (!check())
        throw new Error("condition never held");
}
/** Let the player's task (a core swap) finish, one frame at a time. */
function finishTask(w, limit = 900) {
    const pl = (0, world_1.player)(w);
    for (let i = 0; i < limit && pl.task; i++)
        (0, helpers_1.frame)(w);
}
const tile = (n) => n * tiles_1.TS;
exports.tile = tile;
