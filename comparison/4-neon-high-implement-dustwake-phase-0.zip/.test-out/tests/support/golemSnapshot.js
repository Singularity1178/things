"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ROWS = exports.GLOW_MARK = exports.SWIFT_MARK = void 0;
exports.runPack = runPack;
exports.run = run;
// Developer tool (not a test): draws the golem in every facing for a set of
// states (bare, iron arm, basket on the back, slam frames...) into one PNG, so
// sprite changes can be eyeballed without a browser. Rows top to bottom are
// the states, columns are down / left / up / right. After `npm test` compiled:
//   node -e "require('./.test-out/tests/support/golemSnapshot.js').run('snapshots')"
const node_fs_1 = require("node:fs");
const uiSnapshot_1 = require("./uiSnapshot");
const golem_1 = require("../../src/game/golem");
const util_1 = require("../../src/game/util");
const pack_1 = require("../../src/game/screens/pack");
const screens_1 = require("../../src/game/ui/screens");
const world_1 = require("../../src/game/world/world");
const inventory_1 = require("../../src/game/sim/inventory");
const gear_1 = require("../../src/game/sim/gear");
const debug_1 = require("../../src/game/sim/debug");
const flags_1 = require("../../src/game/content/flags");
const FACINGS = ["down", "left", "up", "right"];
exports.SWIFT_MARK = { col: "#5cf0c8", pat: ["#..", ".#.", "#.."] };
exports.GLOW_MARK = { col: "#ffffff", pat: [".#.", "###", ".#."] };
exports.ROWS = [
    ["bare", {}],
    ["arm", { hasArm: true }],
    ["basket", { back: "basket" }],
    ["arm+basket", { hasArm: true, back: "basket" }],
    ["walk+basket", { hasArm: true, back: "basket", moving: true, phase: 1.3 }],
    ["slumped+basket", { back: "basket", dormant: 1, eye: 0, core: 0 }],
    ["slam top (arm)", { hasArm: true, slam: 1, dip: -1 }],
    ["slam halfway (arm)", { hasArm: true, slam: -0.2 }],
    ["slam impact (arm)", { hasArm: true, slam: -1, dip: 2 }],
    ["slam top (stub)", { slam: 1, dip: -1 }],
    ["slam impact (stub)", { slam: -1, dip: 2 }],
    ["slam impact+basket", { hasArm: true, back: "basket", slam: -1, dip: 2 }],
    ["runes (swift, glow)", { hasArm: true, runes: [exports.SWIFT_MARK, exports.GLOW_MARK, null, null] }],
    ["4 runes + basket", { hasArm: true, back: "basket", runes: [exports.SWIFT_MARK, exports.GLOW_MARK, exports.SWIFT_MARK, exports.GLOW_MARK] }],
    ["walk + runes", { hasArm: true, moving: true, phase: 1.3, runes: [exports.SWIFT_MARK, exports.GLOW_MARK, exports.SWIFT_MARK, exports.GLOW_MARK] }],
];
/**
 * The pack screen at 320x180 in a few gear states, one PNG each (cursor: a pack
 * index, or a gear slot id for the paper doll):
 *   node -e "require('./.test-out/tests/support/golemSnapshot.js').runPack('snapshots')"
 */
function runPack(dir = "snapshots", scale = 3) {
    globalThis.document = { createElement: () => new uiSnapshot_1.RCanvas() };
    const kit = (w) => { (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm); (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild); (0, debug_1.toggleGearKit)(w, (0, world_1.player)(w)); };
    const shots = [
        ["pack-basket-in-pack", (w) => { (0, inventory_1.addItems)(w, (0, world_1.player)(w), "basket", 1); (0, inventory_1.addItems)(w, (0, world_1.player)(w), "wood", 25); }, 0],
        ["pack-basket-worn", (w) => { (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm); (0, gear_1.ensureWorn)(w, (0, world_1.player)(w), "basket"); (0, inventory_1.addItems)(w, (0, world_1.player)(w), "stone", 90); }, "back"],
        ["pack-back-empty", (w) => { (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm); (0, inventory_1.addItems)(w, (0, world_1.player)(w), "coin", 1); }, "back"],
        ["pack-locked-arm", (w) => { (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm); (0, gear_1.ensureWorn)(w, (0, world_1.player)(w), "basket"); (0, inventory_1.addItems)(w, (0, world_1.player)(w), "coin", 3); }, "armL"],
        ["pack-locked-rune", (w) => { (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm); (0, gear_1.ensureWorn)(w, (0, world_1.player)(w), "basket"); }, "rune2"],
        ["pack-runes-worn", (w) => { kit(w); const p = (0, world_1.player)(w); (0, gear_1.ensureWorn)(w, p, "rune_swift"); p.gear.rune1 = "rune_glow"; }, "rune1"],
        ["pack-runes-in-pack", (w) => { kit(w); }, 0],
        ["pack-rune-selected", (w) => { kit(w); }, 0],
        ["pack-small", (w) => { (0, inventory_1.addItems)(w, (0, world_1.player)(w), "wood", 5); (0, inventory_1.addItems)(w, (0, world_1.player)(w), "chisel", 1); }, "head"],
    ];
    (0, node_fs_1.mkdirSync)(dir, { recursive: true });
    for (const [name, setup, cursor] of shots) {
        const w = (0, world_1.createWorld)(7);
        setup(w);
        const ui = new uiSnapshot_1.RCanvas(320, 180);
        const host = {
            ctx: ui.getContext(), world: w, get pl() { return (0, world_1.player)(w); }, get area() { return (0, world_1.currentArea)(w); }, t: 0.5,
            cam: { x: 0, y: 0 }, vw: 320, vh: 180, sfx: new Proxy({}, { get: () => () => { } }), screens: new screens_1.ScreenStack(), typed: [],
            hit: () => false, say: () => { }, renderNote: () => { }, drainEvents: () => { w.events = []; }, renderToast: () => { },
            read: () => { }, boostEye: () => { }, animate: () => { },
        };
        const p = new pack_1.PackUi(host);
        p.open("view");
        if (typeof cursor === "number")
            p.cursor = cursor;
        else
            p.slot = cursor;
        if (name === "pack-rune-selected")
            p.cursor = (0, world_1.player)(w).inventory.findIndex((s) => s?.item === "rune_glow");
        p.screen.render();
        (0, node_fs_1.writeFileSync)(`${dir}/${name}.png`, (0, uiSnapshot_1.png)(ui, scale));
    }
}
function run(dir = "snapshots", rows = exports.ROWS, name = "golem", scale = 6) {
    const cw = 40, ch = 44;
    const c = new uiSnapshot_1.RCanvas(cw * FACINGS.length, ch * rows.length);
    const ctx = c.getContext();
    rows.forEach(([, extra], r) => FACINGS.forEach((facing, i) => {
        ctx.fillStyle = (r + i) % 2 ? "#3a3540" : "#302c36";
        ctx.fillRect(i * cw, r * ch, cw, ch);
        const pose = { facing, phase: 0, moving: false, hasArm: false, dormant: 0, eye: 1, core: 1, raise: 0, reach: 0, t: 0.3, eyeFixed: true, ...extra };
        (0, golem_1.drawGolem)(new util_1.Pen(ctx, false), i * cw + 20, r * ch + 38, pose);
    }));
    (0, node_fs_1.mkdirSync)(dir, { recursive: true });
    (0, node_fs_1.writeFileSync)(`${dir}/${name}.png`, (0, uiSnapshot_1.png)(c, scale));
}
