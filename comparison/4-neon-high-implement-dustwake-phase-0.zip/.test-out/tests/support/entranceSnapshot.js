"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.run = run;
// Developer preview for the entrance update (run by scripts/entrancePreview.mjs, no browser): through the real
// host on the pixel canvas,
//   stairhead-stages.png  the surface's stair head at each dig stage (buried, earth, earth, stone, stone, open)
//   stair-open.png        the stair below once it is dug out, the sky coming down it
//   screen-*.png          the smelter's screen and the anvil's (its FORGE and RUNES tabs)
//   sprites.png           every sprite and icon the update added or redrew
// Nothing is asserted here; tests/entrance.test.ts and tests/smithing.test.ts hold the behaviour.
const node_fs_1 = require("node:fs");
const uiSnapshot_1 = require("./uiSnapshot");
const daySnapshot_1 = require("./daySnapshot");
const game_1 = require("../../src/game/game");
const world_1 = require("../../src/game/world/world");
const daytime_1 = require("../../src/game/sim/daytime");
const digging_1 = require("../../src/game/sim/digging");
const inventory_1 = require("../../src/game/sim/inventory");
const digging_2 = require("../../src/game/content/digging");
const flags_1 = require("../../src/game/content/flags");
const geography_1 = require("../../src/game/content/geography");
const tiles_1 = require("../../src/game/content/tiles");
const items_1 = require("../../src/game/content/items");
const props_1 = require("../../src/game/art/props");
const items_2 = require("../../src/game/art/items");
const DT = 1 / 60, GATE = "buriedgate@48,61";
function run(dir = ".preview/entrance") {
    (0, daySnapshot_1.installDom)();
    (0, node_fs_1.mkdirSync)(dir, { recursive: true });
    const mk = (w, h) => { const c = globalThis.document.createElement("canvas"); c.width = w; c.height = h; c.getContext(); return c; };
    const cx = (c) => c.getContext();
    const save = (name, c, scale) => { (0, node_fs_1.writeFileSync)(`${dir}/${name}.png`, (0, uiSnapshot_1.png)(c, scale)); console.log(`${dir}/${name}.png  ${c.width * scale}x${c.height * scale}`); };
    const view = mk(320, 180), ui = mk(320, 180);
    const g = new game_1.Game(view, ui), w = (0, world_1.createWorld)(7), pl = (0, world_1.player)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowSmelt);
    g.resume(w);
    (0, daytime_1.advanceDayTo)(w, 12);
    const run = (n) => { for (let i = 0; i < n; i++)
        g.update(DT); };
    const frame = () => { view.getContext(); g.render(); return view; };
    /** The world with the UI layer over it, as the page stacks them. */
    const both = () => { const f = frame(), c = mk(320, 180); cx(c).drawImage(f, 0, 0); cx(c).drawImage(ui, 0, 0); return c; };
    run(60);
    // ---- the stair head, stage by stage (noon, the game's own light)
    const surface = (0, world_1.getArea)(w, "surface"), gate = surface.prop(GATE), total = (0, digging_2.digTotal)(digging_2.DIG_SITES.buriedgate);
    (0, world_1.enterArea)(w, pl, "surface", gate.x - 52, gate.y + 12);
    const sheet = mk(3 * 130 - 2, 2 * 100 - 2), sc = cx(sheet);
    const cell = (i) => { const f = frame(), cam = g.cam; sc.drawImage(f, Math.round(gate.x - 64 - cam.x), Math.round(gate.y - 78 - cam.y), 128, 98, (i % 3) * 130, Math.floor(i / 3) * 100, 128, 98); };
    [0, 2, 6, 8, 13].forEach((dmg, i) => { surface.setPropState(GATE, { dmg }); run(40); cell(i); });
    surface.setPropState(GATE, { dmg: total, open: true, lit: true });
    surface.touch("layout");
    (0, digging_1.openEntrance)(w, pl, "surface_stair");
    pl.x = gate.x;
    pl.y = gate.y + 7;
    pl.facing = "up";
    run(40);
    cell(5);
    save("stairhead-stages", sheet, 3);
    // ---- the stair below, open
    (0, world_1.enterArea)(w, pl, "dungeon", (geography_1.GATE_PASSAGE.x + 2) * tiles_1.TS, (geography_1.GATE_PASSAGE.y + 3) * tiles_1.TS);
    pl.facing = "down";
    run(90);
    save("stair-open", both(), 4);
    // ---- the two station screens
    const give = (items) => { for (const [id, n] of items)
        (0, inventory_1.addItems)(w, pl, id, n); };
    (0, world_1.enterArea)(w, pl, "dungeon", 96, 621);
    pl.facing = "up";
    give([["iron_ore", 7], ["wood", 3]]);
    run(30);
    const cu = g.craftUi;
    cu.open("smelting", "forge@5.5,37");
    cu.focus = "button";
    save("screen-smelter", both(), 3);
    g.screens.popToBase();
    pl.x = 104;
    pl.y = 667;
    give([["iron_ingot", 6], ["head_shovel_rusted", 1], ["head_pickaxe", 1], ["head_axe_fine", 1], ["rune_glow", 1]]);
    run(30);
    cu.open("smithing", "anvil@6,40");
    cu.cursor = 1;
    save("screen-anvil-forge", both(), 3);
    cu.tab = 3;
    cu.cursor = 0;
    save("screen-anvil-runes", both(), 3);
    g.screens.popToBase();
    // ---- sprites and icons
    const props = [
        ["forge", 0, false], ["anvil", 0, false], ["toolboard", 0, false], ["runetable", 0, false], ["clayvat", 0, false], ["husk", 0, false],
        ["weaponrack", 0, false], ["weaponrack", 1, false], ["armorstand", 0, false], ["armorstand", 1, false], ["armorstand", 2, false], ["staffrack", 0, false],
        ["wallhooks", 0, false], ["wallhooks", 1, false], ["armorpile", 0, false], ["stairpost", 0, false], ["stairpost", 1, false], ["stairfall", 0, false],
        ["ironore", 0, false], ["ironore", 1, false], ["ironore", 2, false], ["ironore", 0, true],
    ];
    const out = mk(300, 150), oc = cx(out);
    oc.fillStyle = "#3a3640";
    oc.fillRect(0, 0, 300, 150);
    let x = 4, y = 4, rowH = 0;
    for (const [kind, v, alt] of props) {
        const s = (0, props_1.propSprite)(kind, v, alt), sw = s.a.width, sh = s.a.height;
        if (x + sw > 296) {
            x = 4;
            y += rowH + 4;
            rowH = 0;
        }
        oc.drawImage(s.a, x, y);
        x += sw + 5;
        rowH = Math.max(rowH, sh);
    }
    x = 4;
    y += rowH + 6;
    for (const id of items_1.ITEM_IDS.filter((i) => items_1.ITEMS[i].tool || /^head_|^iron_|^dirt$/.test(i))) {
        if (x + 16 > 296) {
            x = 4;
            y += 18;
        }
        oc.fillStyle = "#1c1a20";
        oc.fillRect(x, y, 16, 16);
        oc.drawImage((0, items_2.itemIcon)(id).a, x, y);
        x += 18;
    }
    save("sprites", out, 4);
    return 0;
}
