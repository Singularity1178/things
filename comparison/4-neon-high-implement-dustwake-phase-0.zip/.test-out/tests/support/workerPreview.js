"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.golemCell = exports.workerCell = void 0;
exports.cell = cell;
exports.sheet = sheet;
exports.save = save;
exports.run = run;
// Developer tool (not a test): rasterises the worker golem (and the maintainer, for scale) into PNG
// contact sheets, albedo + emissive composited the way the engine lights them, so poses and animations
// can be inspected without a browser. After `npm test` has compiled:
//   node -e "require('./.test-out/tests/support/workerPreview.js').run('.preview')"
const node_fs_1 = require("node:fs");
const uiSnapshot_1 = require("./uiSnapshot");
const util_1 = require("../../src/game/util");
const workerArt_1 = require("../../src/game/workerArt");
const golem_1 = require("../../src/game/golem");
const ctxOf = (c) => c.getContext();
/** One sprite cell: floor tint behind, albedo, then the emissive pass added on top. */
function cell(draw, w = 40, h = 36, fy = 29) {
    const a = new uiSnapshot_1.RCanvas(w, h), e = new uiSnapshot_1.RCanvas(w, h);
    const ac = ctxOf(a);
    ac.fillStyle = "#3a3640";
    ac.fillRect(0, 0, w, h);
    ac.fillStyle = "#2c2832";
    ac.fillRect(0, fy, w, h - fy);
    ac.fillStyle = "rgba(0,0,0,0.45)";
    ac.fillRect(w / 2 - 6, fy - 1, 12, 2);
    ac.fillRect(w / 2 - 3, fy - 3, 6, 4);
    draw(new util_1.Pen(ac, false).constructor === util_1.Pen ? Object.assign(new util_1.Pen(ac, false), { ox: 0 }) : new util_1.Pen(ac, false));
    draw(new util_1.Pen(ctxOf(e), true));
    // additive glow
    for (let i = 0; i < a.data.length; i += 4) {
        if (e.data[i + 3] > 0)
            for (let k = 0; k < 3; k++)
                a.data[i + k] = Math.min(255, a.data[i + k] + e.data[i + k] * 0.9);
    }
    return a;
}
/** Lay cells out on a sheet: rows of cells. */
function sheet(rows) {
    const cw = rows[0][0].width, ch = rows[0][0].height, cols = Math.max(...rows.map((r) => r.length));
    const out = new uiSnapshot_1.RCanvas(cw * cols + (cols + 1), ch * rows.length + (rows.length + 1));
    out.data.fill(255);
    rows.forEach((r, j) => r.forEach((c, i) => {
        const ox = 1 + i * (cw + 1), oy = 1 + j * (ch + 1);
        for (let y = 0; y < ch; y++)
            for (let x = 0; x < cw; x++) {
                const si = (y * cw + x) * 4, di = ((oy + y) * out.width + ox + x) * 4;
                for (let k = 0; k < 4; k++)
                    out.data[di + k] = c.data[si + k];
            }
    }));
    return out;
}
function save(dir, name, rows, scale = 6) {
    (0, node_fs_1.mkdirSync)(dir, { recursive: true });
    (0, node_fs_1.writeFileSync)(`${dir}/${name}.png`, (0, uiSnapshot_1.png)(sheet(rows), scale));
}
const workerCell = (pose, w = 40, h = 36) => cell((p) => (0, workerArt_1.drawWorker)(p, w / 2, h - 7, pose), w, h, h - 7);
exports.workerCell = workerCell;
const golemCell = (pose, w = 40, h = 36) => cell((p) => (0, golem_1.drawGolem)(p, w / 2, 29, pose), w, h);
exports.golemCell = golemCell;
function run(dir) {
    const mod = require("./workerPreviewSheets");
    mod.sheets(dir);
}
