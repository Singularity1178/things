"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.installDom = installDom;
exports.renderArea = renderArea;
exports.crop = crop;
exports.spriteSheet = spriteSheet;
exports.run = run;
// Developer tool (not a test): renders the market town, its six interiors and
// the surface's west road to PNG without a browser, lit the way the game lights
// them (the real bake, the real prop sprites and emissive layer, the real light
// tracing and compose), plus a contact sheet of every town sprite. Used to look
// at layout, palette and the rune-light / firelight split while building.
//
//   node scripts/townPreview.mjs        -> .preview/town/*.png
const node_fs_1 = require("node:fs");
const uiSnapshot_1 = require("./uiSnapshot");
const areas_1 = require("../../src/game/world/areas");
const area_1 = require("../../src/game/world/area");
const tiles_1 = require("../../src/game/art/tiles");
const props_1 = require("../../src/game/art/props");
const propsTown_1 = require("../../src/game/art/propsTown");
const props_2 = require("../../src/game/content/props");
const light_1 = require("../../src/game/light");
const tiles_2 = require("../../src/game/content/tiles");
const town_1 = require("../../src/game/content/town");
const geography_1 = require("../../src/game/content/geography");
/** The UI snapshot canvas, plus the two pixel calls the background bake and the lighting need. */
class TCanvas extends uiSnapshot_1.RCanvas {
    getContext() {
        const ctx = super.getContext();
        if (!ctx.__px) {
            ctx.__px = true;
            ctx.putImageData = (img, x, y) => {
                for (let j = 0; j < img.height; j++) {
                    const ty = y + j;
                    if (ty < 0 || ty >= this.height)
                        continue;
                    for (let i = 0; i < img.width; i++) {
                        const tx = x + i;
                        if (tx < 0 || tx >= this.width)
                            continue;
                        const s = (j * img.width + i) * 4, d = (ty * this.width + tx) * 4;
                        this.data[d] = img.data[s];
                        this.data[d + 1] = img.data[s + 1];
                        this.data[d + 2] = img.data[s + 2];
                        this.data[d + 3] = 255;
                    }
                }
            };
            ctx.getImageData = (x, y, w, h) => {
                const out = new Uint8ClampedArray(w * h * 4);
                for (let j = 0; j < h; j++)
                    for (let i = 0; i < w; i++) {
                        const s = ((y + j) * this.width + x + i) * 4, d = (j * w + i) * 4;
                        out[d] = this.data[s];
                        out[d + 1] = this.data[s + 1];
                        out[d + 2] = this.data[s + 2];
                        out[d + 3] = this.data[s + 3];
                    }
                return { data: out, width: w, height: h };
            };
        }
        return ctx;
    }
}
const canvas = (w, h) => { const c = new TCanvas(w, h); c.getContext(); return c; };
/** Stand in for the browser's document, so sprites and bakes can be made in Node. */
function installDom() { globalThis.document = { createElement: () => new TCanvas() }; }
/** One area, as the game would draw it with nobody in it: [lit, unlit albedo]. */
function renderArea(id) {
    const area = new area_1.Area(areas_1.AREAS[id]());
    const W = area.w * tiles_2.TS, H = area.h * tiles_2.TS;
    const scene = canvas(W, H), emit = canvas(W, H);
    (0, tiles_1.bakeRegion)(scene.getContext(), area, 0, 0, area.w - 1, area.h - 1);
    const ec = emit.getContext(), sc = scene.getContext();
    ec.fillStyle = "#000";
    ec.fillRect(0, 0, W, H);
    const list = [];
    for (const p of area.props) {
        const def = (0, props_2.propDef)(p.kind), alt = def.alt === "lit" ? !!p.lit : def.alt === "taken" ? p.taken : p.open;
        const s = (0, props_1.propSprite)(p.kind, p.v, alt);
        if (!s)
            continue;
        list.push({ y: def.wallMounted ? p.y - 0.5 : def.flat ? p.y - 16 : p.y, f: () => { sc.drawImage(s.a, Math.round(p.x - s.ax), Math.round(p.y - s.ay)); ec.drawImage(s.e, Math.round(p.x - s.ax), Math.round(p.y - s.ay)); } });
    }
    list.sort((a, b) => a.y - b.y);
    for (const d of list)
        d.f();
    const flat = canvas(W, H);
    flat.getContext().drawImage(scene, 0, 0);
    const lights = [];
    for (const l of area.lights) {
        if (l.owner) {
            const p = area.prop(l.owner);
            if (!p || ((0, props_2.propDef)(p.kind).light?.when === "lit" && !p.lit))
                continue;
        }
        const L = (0, light_1.makeLight)(l.x, l.y, l.rad, l.col, l.int, l.flick, l.id);
        if (l.id === "runeglow")
            L.cur = 0;
        (0, light_1.computeVis)(L, area);
        lights.push(L);
    }
    const lighting = new light_1.Lighting(W, H);
    lighting.accumulate(lights, 0, 0);
    const out = canvas(W, H);
    lighting.compose(scene.data, emit.data, out.data, area.base.ambient ?? [0.05, 0.045, 0.065]);
    return { lit: out, flat, area };
}
function crop(src, x, y, w, h) {
    const c = canvas(w, h);
    c.getContext().drawImage(src, x, y, w, h, 0, 0, w, h);
    return c;
}
/** Every town sprite (4 variants), on a mid-grey ground, with its glow added. */
function spriteSheet() {
    const kinds = Object.keys(propsTown_1.TOWN_PROP_ART), cols = 8, cw = 84, chh = 66;
    const rows = Math.ceil((kinds.length * 4) / cols), c = canvas(cols * cw, rows * chh), ctx = c.getContext();
    ctx.fillStyle = "#4a4a50";
    ctx.fillRect(0, 0, c.width, c.height);
    let n = 0;
    for (const k of kinds)
        for (let v = 0; v < 4; v++, n++) {
            const s = (0, props_1.propSprite)(k, v, false);
            const x = (n % cols) * cw + ((cw - s.w) >> 1), y = Math.floor(n / cols) * chh + chh - 2 - s.h;
            ctx.drawImage(s.a, x, y);
            ctx.globalCompositeOperation = "lighter"; // the snapshot canvas ignores this; glow pixels were drawn into the albedo too
        }
    return c;
}
function run(dir = ".preview/town") {
    installDom();
    (0, node_fs_1.mkdirSync)(dir, { recursive: true });
    const save = (name, c, scale = 1) => (0, node_fs_1.writeFileSync)(`${dir}/${name}.png`, (0, uiSnapshot_1.png)(c, scale));
    if (!Object.keys(props_1.PROP_ART).length)
        throw new Error("no art");
    save("sprites", spriteSheet(), 2);
    const t = renderArea("town");
    save("town_night", t.lit);
    save("town_flat", t.flat);
    const views = [
        ["square", 32, 16, 30, 24], ["high", 58, 14, 34, 22], ["oldquarter", 4, 4, 36, 24], ["low", 30, 34, 36, 16],
        ["yard", 58, 44, 32, 20], ["back", 4, 44, 44, 20], ["westroad", 4, 20, 34, 28], ["north_east", 52, 3, 38, 18],
        ["westbar", 0, 22, 24, 18], ["eastgate", 74, 22, 22, 18], ["wall_nw", 0, 0, 30, 14], ["wall_se", 66, 54, 30, 14],
    ];
    for (const [name, x, y, w, h] of views) {
        save(`town_${name}`, crop(t.lit, x * tiles_2.TS, y * tiles_2.TS, w * tiles_2.TS, h * tiles_2.TS), 2);
    }
    save("town_square_flat", crop(t.flat, 32 * tiles_2.TS, 16 * tiles_2.TS, 30 * tiles_2.TS, 24 * tiles_2.TS), 2);
    for (const e of town_1.ESTABLISHMENTS) {
        const r = renderArea((0, town_1.interiorId)(e)), rm = r.area.rooms[0];
        const x = (rm.x - 2) * tiles_2.TS, y = (rm.y - 3) * tiles_2.TS, w = (rm.w + 4) * tiles_2.TS, h = (rm.h + 6) * tiles_2.TS;
        save(`in_${e}`, crop(r.lit, x, y, w, h), 3);
        save(`in_${e}_flat`, crop(r.flat, x, y, w, h), 2);
    }
    const s = renderArea("surface"), ry = geography_1.WEST_ROAD.surface.y0;
    save("surface_road", crop(s.lit, 0, (ry - 6) * tiles_2.TS, 26 * tiles_2.TS, 15 * tiles_2.TS), 2);
    save("surface_road_flat", crop(s.flat, 0, (ry - 6) * tiles_2.TS, 26 * tiles_2.TS, 15 * tiles_2.TS), 2);
}
