"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.run = run;
// Developer tool (not a test): renders the shops in use to PNG without a browser, through the real host (a Game on a
// pixel canvas, stepped and drawn as the browser would; see folkSnapshot.ts).
//
//   node scripts/shopPreview.mjs [dir] [only,these]     -> .preview/shops/*.png
//
// Names: poses (the new poses in every garb and facing, beside the placeholder keeper for scale), interiors (each
// shop at its busiest hour of the day, people at the shelves and the counter), deal (a customer's exchange with the
// keeper, frame by frame: the bubbles come in turn), board (the guild's board being read), street (the square: talk
// in bubbles, the notice board), door (the smithy's door from outside through a morning), closed (out of hours: no
// keeper, the card on the counter), scan (scan mode in a shop).
const node_fs_1 = require("node:fs");
const uiSnapshot_1 = require("./uiSnapshot");
const folkSnapshot_1 = require("./folkSnapshot");
const world_1 = require("../../src/game/world/world");
const debug_1 = require("../../src/game/sim/debug");
const daytime_1 = require("../../src/game/sim/daytime");
const step_1 = require("../../src/game/sim/step");
const daycycle_1 = require("../../src/game/content/daycycle");
const font_1 = require("../../src/game/font");
const folk_1 = require("../../src/game/content/folk");
const shops_1 = require("../../src/game/content/shops");
const town_1 = require("../../src/game/content/town");
const folk_2 = require("../../src/game/sim/folk");
const folkArt_1 = require("../../src/game/folkArt");
const keeperArt_1 = require("../../src/game/keeperArt");
const util_1 = require("../../src/game/util");
const tiles_1 = require("../../src/game/content/tiles");
const hhmm = (h) => `${String(Math.floor(h)).padStart(2, "0")}:${String(Math.floor((h % 1) * 60)).padStart(2, "0")}`;
/** A tile near the middle of a shop's floor where the golem fits (so the whole room is in view). */
function standTile(e) {
    const w = (0, world_1.createWorld)(1), area = (0, world_1.getArea)(w, (0, town_1.interiorId)(e)), r = area.base.rooms[0], pl = (0, world_1.player)(w);
    for (const [dx, dy] of [[0, 1], [0, 2], [1, 1], [-1, 1], [2, 2], [-2, 2], [0, 0], [3, 1], [-3, 1], [0, 3]]) {
        const tx = Math.round(r.x + r.w / 2 + dx), ty = Math.round(r.y + r.h / 2 + dy);
        if ((0, debug_1.teleportTo)(w, pl, area.id, tx * tiles_1.TS + 8, ty * tiles_1.TS + 8))
            return [tx, ty];
    }
    return [-1, -1];
}
/** Sim only: how many customers are in a shop just after arriving at an hour. */
function customersAt(e, hour, seed, board = false) {
    const w = (0, world_1.createWorld)(seed);
    (0, world_1.getArea)(w, "town");
    const A = (0, world_1.getArea)(w, (0, town_1.interiorId)(e));
    (0, debug_1.teleportTo)(w, (0, world_1.player)(w), A.id, A.start.x, A.start.y);
    (0, daytime_1.advanceDayTo)(w, hour);
    for (let i = 0; i < 40; i++) {
        (0, step_1.stepWorld)(w, 0.05);
        w.events = [];
    }
    return w.actors.filter((a) => (0, folk_2.isFolk)(a) && a.area === A.id && (!board || a.life.spot?.startsWith(shops_1.BOARD.spots))).length;
}
function busiest(e, seed, board = false) {
    let best = shops_1.SHOPS[e].hours.open + 1, n = -1;
    for (let h = shops_1.SHOPS[e].hours.open + 0.4; h < Math.min(20, shops_1.SHOPS[e].hours.close - 0.5); h += 0.35) {
        const k = customersAt(e, h, seed, board);
        if (k > n) {
            n = k;
            best = h;
        }
    }
    return best;
}
/** The first shop trip of kind `visit` in a seed's day: who, where, and when its time at the counter comes. */
function findTrip(visit, seeds) {
    for (const seed of seeds) {
        const w = (0, world_1.createWorld)(seed);
        (0, world_1.getArea)(w, "town");
        for (const a of w.actors.filter(folk_2.isFolk))
            for (let d = w.day + 0.01; d < w.day + 1; d += 0.004) {
                const p = (0, folk_2.planAt)(w, a, d);
                if (p.trip?.visit === visit && p.endDay - p.startDay > 2.1 / 24)
                    return { seed, id: a.id, shop: p.trip.shop, start: p.startDay, end: p.endDay };
            }
    }
    return null;
}
const POSES = ["browse", "point", "pay", "read", "note", "nod", "shake"];
function poseSheet() {
    const w0 = (0, world_1.createWorld)(1), cw = 22, ch = 40, facings = ["down", "left", "right", "up"];
    const archs = Object.values(folk_1.ARCHETYPES).filter((a) => a.habitat === "town");
    const cols = POSES.length * facings.length * 2 + 2, out = (0, folkSnapshot_1.canvas)(cols * cw + 44, archs.length * ch + 12), ctx = out.getContext();
    ctx.fillStyle = "#2a2a30";
    ctx.fillRect(0, 0, out.width, out.height);
    POSES.forEach((p, i) => (0, font_1.drawTextS)(ctx, p.toUpperCase(), 44 + i * facings.length * 2 * cw + 2, 2, "#ffffff", 1, "left", "#000"));
    archs.forEach((arch, j) => {
        const y0 = 12 + j * ch, look = (0, folk_2.makePerson)(w0, { id: `sheet.${arch.id}.0`, area: "town", archetype: arch.id, home: "door.watch" }).look;
        ctx.fillStyle = j % 2 ? "#5a5650" : "#6a6862";
        ctx.fillRect(0, y0, out.width, ch);
        (0, font_1.drawTextS)(ctx, arch.title.slice(0, 10), 2, y0 + 2, "#ffffff", 1, "left", "#000");
        let i = 0;
        for (const pose of POSES)
            for (const facing of facings)
                for (const frame of [0, 1]) {
                    const head = pose === "shake" ? ({ up: ["left", "right"], down: ["right", "left"], left: ["down", "up"], right: ["up", "down"] }[facing][frame]) : null;
                    const s = (0, folkArt_1.folkSprite)(arch.garb, arch.age, look, { facing, head, pose, frame, carry: false, lantern: false, pole: false, blink: false });
                    const x = 44 + i++ * cw + 11, y = y0 + ch - 4;
                    ctx.fillStyle = "rgba(0,0,0,0.3)";
                    ctx.fillRect(x - 5, y - 1, 11, 2);
                    ctx.drawImage(s.a, x - s.ax, y - s.ay);
                }
        // the placeholder keeper beside them, for scale
        const kx = 44 + i * cw + 16, ky = y0 + ch - 4;
        (0, keeperArt_1.keeperPainter)("default")(new util_1.Pen(ctx, false), kx, ky, { facing: "down", state: "tend", moving: false, phase: 0, t: 0 });
    });
    void keeperArt_1.KEEPER_BOX;
    return out;
}
/** Play on as the browser does: every tick is also a frame for the speech bubbles (the host ages them while drawing). */
function play(g, seconds) { for (let i = 0; i < Math.round(seconds * 60); i++) {
    g.update(1 / 60);
    g.renderFolkBubbles(1 / 60);
} }
/** The middle of a shot (offset by dx, dy), so a sheet of frames stays small enough to read. */
function cut(img, w, h, dx = 0, dy = 0) {
    const c = (0, folkSnapshot_1.canvas)(w, h);
    c.getContext().drawImage(img, Math.round((img.width - w) / 2 + dx), Math.round((img.height - h) / 2 + dy), w, h, 0, 0, w, h);
    return c;
}
function run(dir = ".preview/shops", only = "") {
    (0, folkSnapshot_1.installDom)();
    (0, node_fs_1.mkdirSync)(dir, { recursive: true });
    const want = (n) => !only || only.split(",").includes(n);
    const save = (name, c, scale = 1) => { (0, node_fs_1.writeFileSync)(`${dir}/${name}.png`, (0, uiSnapshot_1.png)(c, scale)); console.log(`${dir}/${name}.png  ${c.width * scale}x${c.height * scale}`); };
    const live = (area, tx, ty, hour, secs, seed = 7) => { const s = (0, folkSnapshot_1.scene)(area, tx, ty, hour, 0.2, seed); play(s.g, secs); return s; };
    const frames = (g, label, n, gap, box) => {
        const out = [];
        for (let i = 0; i < n; i++) {
            if (i)
                play(g, gap);
            const img = (0, folkSnapshot_1.shot)(g);
            out.push({ label: `${label} +${(i * gap).toFixed(0)}S`, img: box ? cut(img, ...box) : img });
        }
        return out;
    };
    if (want("poses"))
        save("poses", poseSheet(), 2);
    if (want("interiors")) {
        const now = [], later = [];
        for (const e of town_1.ESTABLISHMENTS) {
            const [tx, ty] = standTile(e), h = busiest(e, 7), s = live((0, town_1.interiorId)(e), tx, ty, h, 9);
            now.push({ label: `${e.toUpperCase()} ${hhmm(h)}`, img: cut((0, folkSnapshot_1.shot)(s.g), 352, 230) });
            play(s.g, 8);
            later.push({ label: `${e.toUpperCase()} +8S`, img: cut((0, folkSnapshot_1.shot)(s.g), 352, 230) });
        }
        save("interiors", (0, folkSnapshot_1.sheet)(3, now), 1.5);
        save("interiors_later", (0, folkSnapshot_1.sheet)(3, later), 1.5);
    }
    if (want("deal")) {
        const t = findTrip("buy", [1, 2, 3, 4, 5, 6, 7, 8, 9]);
        if (t) {
            const [tx, ty] = standTile(t.shop), at = t.start + (t.end - t.start) * 0.5;
            const s = live((0, town_1.interiorId)(t.shop), tx, ty, (0, daycycle_1.hourOf)(at), 0.5, t.seed), who = (0, world_1.actorById)(s.w, t.id);
            // run on until they are being served, then a frame every two seconds
            for (let i = 0; i < 900 && who.life.chat?.with !== `keeper.${t.shop}`; i++)
                play(s.g, 0.05);
            play(s.g, 0.9);
            save("deal", (0, folkSnapshot_1.sheet)(3, frames(s.g, `${t.shop.toUpperCase()} DEAL`, 6, 2.3, [250, 170, -20, -20])), 2);
        }
        else
            console.log("no buy trip found");
    }
    if (want("board")) {
        const [tx, ty] = standTile("guild"), h = busiest("guild", 7, true), s = live("town_guild", tx, ty, h, 6);
        save("board", (0, folkSnapshot_1.sheet)(3, frames(s.g, `BOARD ${hhmm(h)}`, 6, 3, [250, 170, -70, -50])), 2);
    }
    if (want("street")) {
        const a = live("town", 47, 33, 10.2, 8), b = live("town", 52, 35, 13.4, 8), c = live("town", 25, 14, 16.4, 8);
        save("street", (0, folkSnapshot_1.sheet)(3, [...frames(a.g, "SQUARE 10:12", 3, 6, [250, 170, 0, 0]), ...frames(b.g, "NOTICES 13:24", 3, 6, [250, 170, 0, 0]), ...frames(c.g, "WELL 16:24", 3, 6, [250, 170, 0, 0])]), 2);
    }
    if (want("door")) {
        const s = live("town", 54, 47, 8.4, 2);
        save("door", (0, folkSnapshot_1.sheet)(3, frames(s.g, "SMITHY DOOR 08:24", 6, 9, [250, 170, 0, -10])), 2);
    }
    if (want("closed")) {
        const [tx, ty] = standTile("smithy"), [jx, jy] = standTile("jeweler");
        const night = live("town_smithy", tx, ty, 3, 2), lunch = live("town_jeweler", jx, jy, 13.3, 2), open = live("town_jeweler", jx, jy, 15, 6);
        save("closed", (0, folkSnapshot_1.sheet)(3, [{ label: "SMITHY 03:00", img: cut((0, folkSnapshot_1.shot)(night.g), 300, 200) }, { label: "JEWELLER 13:18 LUNCH", img: cut((0, folkSnapshot_1.shot)(lunch.g), 300, 200) }, { label: "JEWELLER 15:00", img: cut((0, folkSnapshot_1.shot)(open.g), 300, 200) }]), 1.5);
    }
    if (want("scan")) {
        const [tx, ty] = standTile("guild"), s = live("town_guild", tx, ty, busiest("guild", 7), 5);
        s.g.keyDown("z");
        (0, folkSnapshot_1.tick)(s.g, 2);
        s.g.keyUp("z");
        (0, folkSnapshot_1.tick)(s.g, 90);
        save("scan", cut((0, folkSnapshot_1.shot)(s.g), 352, 230), 2);
    }
}
