"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUDIT_AREAS = void 0;
exports.auditArea = auditArea;
exports.asciiMap = asciiMap;
exports.main = main;
// Developer tool (not a test): looks for layout mistakes in the market town and
// the rooms behind its doors, the kind that are easy to make by hand and hard
// to see at a glance. It reads the built areas the way the game does (the real
// tiles, the real collision boxes, the real sprites) and prints what is wrong:
//
//   - a prop whose collision box sits in a wall or a building, or off the map;
//   - two solid props standing in each other;
//   - something hung on a wall that is not there, a light buried in masonry;
//   - a standing place (Spot) that is blocked or cannot be walked to;
//   - open ground nobody can reach (a yard fenced all the way round);
//   - a door with something standing on its step or drawn across it;
//   - a ground decal painted over a roof;
//   - a building row that contradicts itself (a lit window that is not a window).
//
//   node scripts/townAudit.mjs                      -> the report (exit code 1 if anything is wrong)
//   node scripts/townAudit.mjs map                  -> an ASCII plan of the town's tiles
//   node scripts/townAudit.mjs shot name=area:x,y,w,h[,scale[,lit|flat[,grid]]] ...
//                                                   -> .preview/audit/name.png (tiles; grid: a line per tile, bright every 5)
const node_fs_1 = require("node:fs");
const uiSnapshot_1 = require("./uiSnapshot");
const townSnapshot_1 = require("./townSnapshot");
const areas_1 = require("../../src/game/world/areas");
const area_1 = require("../../src/game/world/area");
const props_1 = require("../../src/game/art/props");
const props_2 = require("../../src/game/content/props");
const decals_1 = require("../../src/game/art/decals");
const tiles_1 = require("../../src/game/content/tiles");
const town_1 = require("../../src/game/content/town");
const reach_1 = require("../../src/game/sim/reach");
const collision_1 = require("../../src/game/sim/collision");
exports.AUDIT_AREAS = [town_1.TOWN_ID, ...town_1.ESTABLISHMENTS.map(town_1.interiorId)];
/** Foliage the ground-cover pass scatters: it may brush against things. */
const SOFT = new Set(["towntree", "tree", "bush", "tallgrass", "fern", "fence", "fence_v"]);
/** Furniture that belongs pushed together. */
const TOGETHER = new Set(["bench+longtable", "longtable+bench"]);
/** Things that stand on a roof or a wall by design. */
const ON_ROOF = new Set(["chimney"]);
const at = (x, y) => `(${(x / tiles_1.TS).toFixed(1)},${(y / tiles_1.TS).toFixed(1)})`;
const rectOverlap = (a, b) => [Math.min(a[2], b[2]) - Math.max(a[0], b[0]), Math.min(a[3], b[3]) - Math.max(a[1], b[1])];
function spriteRect(p) {
    const def = (0, props_2.propDef)(p.kind), alt = def.alt === "lit" ? !!p.lit : def.alt === "taken" ? p.taken : p.open;
    const s = (0, props_1.propSprite)(p.kind, p.v, alt);
    return s ? [Math.round(p.x - s.ax), Math.round(p.y - s.ay), Math.round(p.x - s.ax) + s.w, Math.round(p.y - s.ay) + s.h] : null;
}
function auditArea(id) {
    const data = areas_1.AREAS[id](), a = new area_1.Area(data), W = a.w, H = a.h, out = [];
    const say = (check, msg) => out.push({ area: id, check, msg });
    const tile = (tx, ty) => (tx < 0 || ty < 0 || tx >= W || ty >= H ? -1 : a.grid[ty * W + tx]);
    const blockers = a.props.filter(collision_1.propBlocks), boxes = blockers.map((p) => p.box);
    // ---- props against tiles
    for (const p of a.props) {
        const def = (0, props_2.propDef)(p.kind), fx = Math.floor(p.x / tiles_1.TS), fy = Math.floor((p.y - 1) / tiles_1.TS);
        if (def.wallMounted) {
            const t = tile(fx, fy);
            if (t !== tiles_1.T.WALL && t !== tiles_1.T.FRONT)
                say("wall-mounted", `${p.id} at ${at(p.x, p.y)} hangs on nothing (tile ${fx},${fy} is not wall)`);
            continue;
        }
        if (ON_ROOF.has(p.kind) || def.rune)
            continue;
        if (p.box) {
            const b = p.box;
            let hit = "";
            for (let ty = Math.floor((b[1] + 0.01) / tiles_1.TS); ty <= Math.floor((b[3] - 0.01) / tiles_1.TS) && !hit; ty++)
                for (let tx = Math.floor((b[0] + 0.01) / tiles_1.TS); tx <= Math.floor((b[2] - 0.01) / tiles_1.TS) && !hit; tx++) {
                    const t = tile(tx, ty);
                    if (t < 0)
                        hit = `off the map at ${tx},${ty}`;
                    else if ((0, tiles_1.isSolidT)(t))
                        hit = `in solid tile ${tx},${ty}`;
                }
            if (hit)
                say("in-wall", `${p.id} at ${at(p.x, p.y)}: its box is ${hit}`);
        }
        else if (!def.flat) {
            const t = tile(fx, fy);
            if (t < 0 || (0, tiles_1.isSolidT)(t))
                say("in-wall", `${p.id} at ${at(p.x, p.y)} stands in solid tile ${fx},${fy}`);
        }
        const r = spriteRect(p);
        if (!r)
            say("art", `${p.id}: no sprite for kind "${p.kind}"`);
        else if (r[0] < 0 || r[1] < 0 || r[2] > W * tiles_1.TS || r[3] > H * tiles_1.TS)
            say("off-map", `${p.id} at ${at(p.x, p.y)}: its sprite runs off the map`);
    }
    // ---- solid props against each other
    for (let i = 0; i < blockers.length; i++)
        for (let j = i + 1; j < blockers.length; j++) {
            const p = blockers[i], q = blockers[j];
            if (Math.abs(p.x - q.x) > 60 || Math.abs(p.y - q.y) > 60)
                continue;
            const [ox, oy] = rectOverlap(p.box, q.box);
            if (ox > 1 && oy > 1 && !(p.kind.startsWith("fence") && q.kind.startsWith("fence")))
                say("overlap", `${p.id} ${at(p.x, p.y)} and ${q.id} ${at(q.x, q.y)}: boxes overlap ${ox.toFixed(0)}x${oy.toFixed(0)}px`);
            // a hand-placed thing mostly hidden behind (or standing in the picture of) another
            if (SOFT.has(p.kind) || SOFT.has(q.kind))
                continue;
            const rp = spriteRect(p), rq = spriteRect(q);
            if (!rp || !rq)
                continue;
            const [sx, sy] = rectOverlap(rp, rq), small = Math.min((rp[2] - rp[0]) * (rp[3] - rp[1]), (rq[2] - rq[0]) * (rq[3] - rq[1]));
            if (sx > 0 && sy > 0 && sx * sy > small * 0.4 && !(ox > 1 && oy > 1) && !TOGETHER.has(`${p.kind}+${q.kind}`))
                say("crowded", `${p.id} ${at(p.x, p.y)} and ${q.id} ${at(q.x, q.y)}: sprites overlap ${sx}x${sy}px`);
        }
    // ---- lights
    for (const l of a.lights) {
        if (l.owner && !a.prop(l.owner))
            say("light", `a light at ${at(l.x, l.y)} belongs to "${l.owner}", which does not exist`);
        const t = tile(Math.floor(l.x / tiles_1.TS), Math.floor(l.y / tiles_1.TS));
        if (t < 0 || (0, tiles_1.isOpaqueT)(t))
            say("light", `the light of ${l.owner ?? "(none)"} at ${at(l.x, l.y)} is buried in an opaque tile`);
    }
    // ---- standing places, and ground nobody can get to
    const reach = (0, reach_1.reachable)(a, boxes, data.start);
    for (const s of data.spots ?? []) {
        // reachability is per tile: a place counts if it, or free ground a step away, is in a tile the golem can walk to
        let ok = false;
        for (let dy = -8; dy <= 8 && !ok; dy += 2)
            for (let dx = -8; dx <= 8 && !ok; dx += 2) {
                const px = s.x + dx, py = s.y + dy, tx = Math.floor(px / tiles_1.TS), ty = Math.floor((py - 1) / tiles_1.TS);
                ok = tx >= 0 && ty >= 0 && tx < W && ty < H && !!reach[ty * W + tx] && (0, collision_1.boxFree)(a, px, py);
            }
        if (!(0, collision_1.boxFree)(a, s.x, s.y))
            say("spot", `${s.id} (${s.kind}) at ${at(s.x, s.y)} is blocked`);
        else if (!ok)
            say("spot", `${s.id} (${s.kind}) at ${at(s.x, s.y)} cannot be walked to`);
    }
    const seen = new Uint8Array(W * H);
    const standable = (k) => { const f = (0, reach_1.cellFeet)(k % W, (k / W) | 0); return a.grid[k] === tiles_1.T.FLOOR && (0, reach_1.freeAt)(a, boxes, f.x, f.y); };
    for (let k0 = 0; k0 < W * H; k0++) {
        if (seen[k0] || reach[k0] || !standable(k0))
            continue;
        let n = 0, x0 = W, y0 = H, x1 = 0, y1 = 0;
        const q = [k0];
        seen[k0] = 1;
        while (q.length) {
            const k = q.pop(), x = k % W, y = (k / W) | 0;
            n++;
            x0 = Math.min(x0, x);
            x1 = Math.max(x1, x);
            y0 = Math.min(y0, y);
            y1 = Math.max(y1, y);
            for (const d of [1, -1, W, -W]) {
                const j = k + d;
                if (j < 0 || j >= W * H || (Math.abs(d) === 1 && ((j / W) | 0) !== y) || seen[j] || reach[j] || !standable(j))
                    continue;
                seen[j] = 1;
                q.push(j);
            }
        }
        if (n >= 4)
            say("sealed", `${n} tiles of open ground at ${x0},${y0}..${x1},${y1} cannot be walked to`);
    }
    if (id !== town_1.TOWN_ID)
        return out;
    // ---- the town's buildings: the table itself, their doors, and what is painted over them
    const rects = town_1.BUILDINGS.map((b) => [b.x * tiles_1.TS, b.y * tiles_1.TS, (b.x + b.w) * tiles_1.TS, (b.y + b.h) * tiles_1.TS]);
    town_1.BUILDINGS.forEach((b) => {
        const cols = (l) => (l ?? []).filter((c) => c < 0 || c >= b.w);
        if (cols(b.win).length || cols(b.lit).length || cols(b.dormers).length)
            say("building", `${b.id}: a window / dormer column is outside its ${b.w} columns`);
        for (const c of b.lit ?? [])
            if (!b.win?.includes(c))
                say("building", `${b.id}: column ${c} is lit but is not a window`);
        if (b.chimney !== undefined && (b.chimney < 0 || b.chimney >= b.w))
            say("building", `${b.id}: chimney column ${b.chimney} is off the roof`);
        if (!b.door)
            return;
        const kind = b.door.kind ?? "plain", dc = kind === "hauler" ? [b.door.col, b.door.col + 1] : [b.door.col];
        for (const c of dc) {
            if (c < 0 || c >= b.w)
                say("building", `${b.id}: door column ${c} is outside the front`);
            if (b.win?.includes(c))
                say("building", `${b.id}: column ${c} is both door and window`);
        }
        const d = (0, town_1.doorPx)(b), half = town_1.DOOR[d.kind].w / 2, leaf = [d.x - half, d.y - town_1.DOOR[d.kind].h, d.x + half, d.y], step = [d.x - half, d.y, d.x + half, d.y + 10];
        for (let x = Math.floor(step[0] / tiles_1.TS); x <= Math.floor((step[2] - 1) / tiles_1.TS); x++)
            if (tile(x, b.y + b.h) !== tiles_1.T.FLOOR)
                say("door", `${b.id}: no ground in front of its door at ${x},${b.y + b.h}`);
        if (!(0, collision_1.boxFree)(a, d.x, d.y + 9))
            say("door", `${b.id}: nobody can stand on its doorstep`);
        for (const p of a.props) {
            const def = (0, props_2.propDef)(p.kind);
            if (def.wallMounted || def.flat || ON_ROOF.has(p.kind))
                continue;
            if (p.box) {
                const [ox, oy] = rectOverlap(p.box, step);
                if (ox > 0 && oy > 0)
                    say("door", `${b.id}: ${p.id} ${at(p.x, p.y)} stands on its doorstep`);
            }
            const r = spriteRect(p);
            if (!r || p.y < d.y)
                continue;
            const [sx, sy] = rectOverlap(r, leaf);
            if (sx >= 3 && sy >= 4)
                say("door", `${b.id}: ${p.id} ${at(p.x, p.y)} is drawn across its door (${sx}x${sy}px)`);
        }
    });
    const db = (0, decals_1.decalBounds)(data.decals);
    data.decals.forEach((dc, i) => {
        if (dc.kind === "building" || dc.kind === "doormat")
            return;
        const r = [db[i * 4], db[i * 4 + 1], db[i * 4 + 2], db[i * 4 + 3]];
        if (r[2] - r[0] === 160 && r[3] - r[1] === 240)
            return; // a kind with no declared extent: the bake's catch-all bounds, not its size
        // buildings are painted after the ground decals (town.ts), so only what comes later in the list lands on a roof
        if (i < data.decals.findIndex((x) => x.kind === "building"))
            return;
        rects.forEach((br, j) => { const [ox, oy] = rectOverlap(r, br); if (ox > 3 && oy > 3)
            say("decal", `${dc.kind} at ${at(dc.x, dc.y)} is painted ${ox.toFixed(0)}x${oy.toFixed(0)}px over ${town_1.BUILDINGS[j].id}`); });
    });
    return out;
}
/** An ASCII plan of an area's tiles, with the street furniture marked. */
function asciiMap(id) {
    const a = new area_1.Area(areas_1.AREAS[id]()), rows = [];
    const FL = { [tiles_1.FS.GRASS]: ".", [tiles_1.FS.MOSS]: ",", [tiles_1.FS.DIRT]: ":", [tiles_1.FS.EARTH]: "e", [tiles_1.FS.MUD]: "m", [tiles_1.FS.SETT]: "s", [tiles_1.FS.WEAVE]: "w", [tiles_1.FS.COBBLE]: "c" };
    for (let y = 0; y < a.h; y++) {
        const row = [];
        for (let x = 0; x < a.w; x++) {
            const t = a.grid[y * a.w + x], s = a.style[y * a.w + x];
            row.push(t === tiles_1.T.THICKET ? "~" : t === tiles_1.T.FRONT ? "F" : t === tiles_1.T.WALL ? (s === tiles_1.WS.RAMPART ? "R" : "#") : t === tiles_1.T.FLOOR ? FL[s] ?? "_" : "?");
        }
        rows.push(row);
    }
    const mark = { rune_lamp: "L", torch_post: "t", towntree: "T", fence: "-", fence_v: "|", bush: "b", bannerpole: "P", brazier: "B" };
    for (const p of a.props) {
        const c = mark[p.kind], x = Math.floor(p.x / tiles_1.TS), y = Math.floor((p.y - 1) / tiles_1.TS);
        if (c && rows[y]?.[x] !== undefined)
            rows[y][x] = c;
    }
    const head = "    " + Array.from({ length: a.w }, (_, x) => (x % 10 === 0 ? String((x / 10) | 0) : x % 5 === 0 ? "+" : " ")).join("");
    return [head, ...rows.map((r, y) => String(y).padStart(3) + " " + r.join(""))].join("\n");
}
/** Tile grid over a crop: a faint line per tile, brighter every fifth, brightest every tenth. */
function gridOver(c, px0, py0) {
    for (let j = 0; j < c.height; j++)
        for (let i = 0; i < c.width; i++) {
            const gx = (px0 + i) % tiles_1.TS === 0, gy = (py0 + j) % tiles_1.TS === 0;
            if (!gx && !gy)
                continue;
            const n = gx ? (px0 + i) / tiles_1.TS : (py0 + j) / tiles_1.TS, k = (j * c.width + i) * 4;
            const [r, g, b, f] = n % 10 === 0 ? [255, 60, 60, 0.75] : n % 5 === 0 ? [255, 230, 60, 0.6] : [255, 255, 255, 0.16];
            c.data[k] += (r - c.data[k]) * f;
            c.data[k + 1] += (g - c.data[k + 1]) * f;
            c.data[k + 2] += (b - c.data[k + 2]) * f;
        }
}
function main(argv) {
    (0, townSnapshot_1.installDom)();
    if (argv[0] === "map") {
        console.log(asciiMap(argv[1] ?? town_1.TOWN_ID));
        return 0;
    }
    if (argv[0] === "shot") {
        const dir = ".preview/audit", cache = new Map();
        (0, node_fs_1.mkdirSync)(dir, { recursive: true });
        for (const spec of argv.slice(1)) {
            const [name, rest] = spec.split("="), [area, nums] = rest.split(":"), f = nums.split(",");
            const r = cache.get(area) ?? (0, townSnapshot_1.renderArea)(area);
            cache.set(area, r);
            const [x, y, w, h] = f.slice(0, 4).map(Number), scale = Number(f[4] ?? 2), src = f[5] === "flat" ? r.flat : r.lit;
            const cw = Math.min(w, r.area.w - x), ch = Math.min(h, r.area.h - y), c = (0, townSnapshot_1.crop)(src, x * tiles_1.TS, y * tiles_1.TS, cw * tiles_1.TS, ch * tiles_1.TS);
            if (f[6] === "grid")
                gridOver(c, x * tiles_1.TS, y * tiles_1.TS);
            (0, node_fs_1.writeFileSync)(`${dir}/${name}.png`, (0, uiSnapshot_1.png)(c, scale));
        }
        return 0;
    }
    let n = 0;
    for (const id of exports.AUDIT_AREAS) {
        const found = auditArea(id);
        n += found.length;
        console.log(`== ${id}: ${found.length ? found.length + " finding(s)" : "clean"}`);
        const by = new Map();
        for (const f of found)
            by.set(f.check, [...(by.get(f.check) ?? []), f.msg]);
        for (const [check, msgs] of by) {
            console.log(`  [${check}] x${msgs.length}`);
            for (const m of msgs.slice(0, 40))
                console.log(`    ${m}`);
            if (msgs.length > 40)
                console.log(`    ... and ${msgs.length - 40} more`);
        }
    }
    console.log(n ? `\n${n} finding(s).` : "\nNothing wrong found.");
    return n ? 1 : 0;
}
