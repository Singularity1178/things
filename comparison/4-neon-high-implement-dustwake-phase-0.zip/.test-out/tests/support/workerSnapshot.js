"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.run = run;
// Developer tool (not a test): the worker golem in its three states (off,
// powered-idle, working: standing, two walk frames, a punch) in every facing,
// beside the maintainer and the guardian for scale and style, plus the ruby
// icons, the crown and the aether core. Each sheet is drawn twice: albedo, and
// "in the dark" (albedo dimmed, the emissive pass added), so glow can be judged.
// After `npm test` compiled:
//   node -e "require('./.test-out/tests/support/workerSnapshot.js').run('snapshots')"
const node_fs_1 = require("node:fs");
const uiSnapshot_1 = require("./uiSnapshot");
const workerArt_1 = require("../../src/game/workerArt");
const golem_1 = require("../../src/game/golem");
const npcArt_1 = require("../../src/game/npcArt");
const items_1 = require("../../src/game/art/items");
const util_1 = require("../../src/game/util");
const FACINGS = ["down", "left", "up", "right"];
function sheet(rows, cw, ch, ax, ay) {
    const W = cw * Math.max(...rows.map((r) => r.length)), H = ch * rows.length;
    const a = new uiSnapshot_1.RCanvas(W, H), e = new uiSnapshot_1.RCanvas(W, H);
    const actx = a.getContext(), ectx = e.getContext();
    rows.forEach((row, r) => row.forEach((f, i) => {
        actx.fillStyle = (r + i) % 2 ? "#3a3540" : "#302c36";
        actx.fillRect(i * cw, r * ch, cw, ch);
        ectx.fillStyle = "#000";
        ectx.fillRect(i * cw, r * ch, cw, ch);
        f(new util_1.Pen(actx, false), i * cw + ax, r * ch + ay);
        f(new util_1.Pen(ectx, true), i * cw + ax, r * ch + ay);
    }));
    const dark = new uiSnapshot_1.RCanvas(W, H);
    dark.getContext();
    for (let k = 0; k < a.data.length; k += 4)
        for (let c = 0; c < 3; c++)
            dark.data[k + c] = Math.min(255, a.data[k + c] * 0.3 + e.data[k + c]);
    const out = new uiSnapshot_1.RCanvas(W, H * 2);
    out.getContext();
    out.data.set(a.data, 0);
    out.data.set(dark.data, a.data.length);
    return out;
}
function run(dir = "snapshots", scale = 6) {
    globalThis.document = { createElement: () => new uiSnapshot_1.RCanvas() };
    (0, node_fs_1.mkdirSync)(dir, { recursive: true });
    const worker = (state, extra = {}) => FACINGS.map((facing) => (p, x, y) => (0, workerArt_1.drawWorker)(p, x, y, (0, workerArt_1.workerPose)(state, { facing, phase: extra.phase ?? 0, moving: !!extra.moving, t: 0.3, hasCore: extra.hasCore ?? state !== "off", swing: extra.swing, reach: extra.reach, boot: extra.boot })));
    const rows = [
        worker("off"), worker("idle"), worker("idle", { boot: 1 }), worker("work"),
        worker("work", { moving: true, phase: 1.3 }), worker("work", { moving: true, phase: 4.4 }), worker("work", { swing: 1 }), worker("work", { reach: 1 }),
        [
            (p, x, y) => (0, golem_1.drawGolem)(p, x, y, { facing: "down", phase: 0, moving: false, hasArm: true, dormant: 0, eye: 1, core: 1, raise: 0, reach: 0, t: 0.3, eyeFixed: true }),
            (p, x, y) => (0, workerArt_1.drawWorker)(p, x, y, (0, workerArt_1.workerPose)("work", { facing: "down", phase: 0, moving: false, t: 0.3, hasCore: true })),
            (p, x, y) => (0, golem_1.drawGolem)(p, x, y, { facing: "down", phase: 0, moving: false, hasArm: false, dormant: 1, eye: 0, core: 0, raise: 0, reach: 0, t: 0.3 }),
            (p, x, y) => (0, workerArt_1.drawWorker)(p, x, y, (0, workerArt_1.workerPose)("off", { facing: "down", phase: 0, moving: false, t: 0.3, hasCore: false })),
        ],
    ];
    (0, node_fs_1.writeFileSync)(`${dir}/worker.png`, (0, uiSnapshot_1.png)(sheet(rows, 28, 30, 14, 26), scale));
    const cmp = sheet([[
            (p, x, y) => (0, npcArt_1.drawGuardian)(p, x + 4, y, { facing: "down", awake: 0, eye: 0, reach: 0, t: 0 }),
            (p, x, y) => (0, golem_1.drawGolem)(p, x, y, { facing: "down", phase: 0, moving: false, hasArm: true, dormant: 0, eye: 1, core: 1, raise: 0, reach: 0, t: 0.3, eyeFixed: true }),
            (p, x, y) => (0, workerArt_1.drawWorker)(p, x, y, (0, workerArt_1.workerPose)("idle", { facing: "down", phase: 0, moving: false, t: 0.3, hasCore: true })),
            (p, x, y) => (0, workerArt_1.drawWorker)(p, x, y, (0, workerArt_1.workerPose)("work", { facing: "right", phase: 0, moving: false, t: 0.3, hasCore: true })),
        ]], 40, 52, 20, 48);
    (0, node_fs_1.writeFileSync)(`${dir}/worker-lineup.png`, (0, uiSnapshot_1.png)(cmp, scale));
    const icons = ["large_ruby", "ruby_core", "crown", "core", "coin", "rune_glow"];
    (0, node_fs_1.writeFileSync)(`${dir}/ruby-icons.png`, (0, uiSnapshot_1.png)(sheet([icons.map((id) => (p, x, y) => { p.ox = x; p.oy = y; items_1.ITEM_ART[id](p); })], 18, 18, 1, 1), 8));
}
