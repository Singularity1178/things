"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resetTrace = resetTrace;
exports.traceHash = traceHash;
exports.installFakeCanvas = installFakeCanvas;
// A recording stand-in for the browser canvas, so procedural art can run in
// Node. Every drawing operation (in order, per context) is folded into one
// running FNV-1a hash. Two runs that issue the same operations with the same
// arguments produce the same pixels, so equal hashes == identical output.
let H = 0x811c9dc5;
let ids = 0;
const mix = (s) => {
    for (let i = 0; i < s.length; i++) {
        H ^= s.charCodeAt(i);
        H = Math.imul(H, 16777619) >>> 0;
    }
};
function resetTrace() { H = 0x811c9dc5; ids = 0; }
function traceHash() { return (H >>> 0).toString(16); }
class FakeCtx {
    constructor(canvas) {
        Object.defineProperty(this, "canvas", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: canvas
        });
        Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "_fs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "#000"
        });
        Object.defineProperty(this, "_ga", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        Object.defineProperty(this, "_gco", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "source-over"
        });
        Object.defineProperty(this, "imageSmoothingEnabled", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        this.id = canvas.id;
    }
    get fillStyle() { return this._fs; }
    set fillStyle(v) { this._fs = v; mix(`${this.id}fs${v}`); }
    get globalAlpha() { return this._ga; }
    set globalAlpha(v) { this._ga = v; mix(`${this.id}ga${v}`); }
    get globalCompositeOperation() { return this._gco; }
    set globalCompositeOperation(v) { this._gco = v; mix(`${this.id}gco${v}`); }
    fillRect(x, y, w, h) { mix(`${this.id}fr${x},${y},${w},${h}`); }
    clearRect(x, y, w, h) { mix(`${this.id}cr${x},${y},${w},${h}`); }
    createImageData(w, h) { return { width: w, height: h, data: new Uint8ClampedArray(w * h * 4) }; }
    getImageData(_x, _y, w, h) { return this.createImageData(w, h); }
    putImageData(img, x, y) {
        let h = 0x811c9dc5;
        const d = img.data;
        for (let i = 0; i < d.length; i++) {
            h ^= d[i];
            h = Math.imul(h, 16777619) >>> 0;
        }
        mix(`${this.id}pid${h},${img.width},${x},${y}`);
    }
    drawImage(src, ...a) { mix(`${this.id}di${src.id}:${a.join(",")}`); }
    save() { mix(`${this.id}sv`); }
    restore() { mix(`${this.id}rs`); }
    beginPath() { mix(`${this.id}bp`); }
    rect(x, y, w, h) { mix(`${this.id}rc${x},${y},${w},${h}`); }
    clip() { mix(`${this.id}cl`); }
}
class FakeCanvas {
    constructor() {
        Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: ++ids
        });
        Object.defineProperty(this, "width", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "height", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        Object.defineProperty(this, "ctx", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
    getContext() { return (this.ctx ?? (this.ctx = new FakeCtx(this))); }
}
/** Install `document.createElement("canvas")` for Node. */
function installFakeCanvas() {
    globalThis.document = {
        createElement: (tag) => {
            if (tag !== "canvas")
                throw new Error("fake document only makes canvases");
            return new FakeCanvas();
        },
    };
}
