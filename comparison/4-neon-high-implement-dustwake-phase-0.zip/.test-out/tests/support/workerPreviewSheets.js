"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sheets = sheets;
const workerPreview_1 = require("./workerPreview");
const workerArt_1 = require("../../src/game/workerArt");
const workerAnim_1 = require("../../src/game/workerAnim");
const F = ["down", "right", "up", "left"];
const m = (facing, extra = {}) => ({ facing, phase: 0, moving: false, t: 0.3, hasCore: true, ...extra });
const with_ = (p, x) => ({ ...p, ...x });
/** Step a sequencer from `start` through `seconds`, sampling `n` frames. */
function strip(start, then, seconds, n, facing, cols = 8, w = 30, h = 30) {
    const a = (0, workerAnim_1.initWorkerAnim)(start);
    const out = [];
    const dt = 1 / 60, per = seconds / (n - 1);
    let next = 0, t = 0;
    for (let i = 0; i < n; i++) {
        while (t < next) {
            (0, workerAnim_1.stepWorkerAnim)(a, dt, then);
            t += dt;
        }
        out.push((0, workerPreview_1.workerCell)((0, workerAnim_1.animPose)(a, m(facing, { t })), w, h));
        next += per;
    }
    const rows = [];
    for (let i = 0; i < out.length; i += cols)
        rows.push(out.slice(i, i + cols));
    return rows;
}
const OFF = { powered: false, active: false, moving: false, hasCore: false };
const IDLE = { powered: true, active: false, moving: false, hasCore: true };
const WORK = { powered: true, active: true, moving: false, hasCore: true };
function sheets(dir) {
    const rows = [
        F.map((f) => (0, workerPreview_1.workerCell)((0, workerArt_1.workerPose)("off", m(f, { hasCore: false })))),
        F.map((f) => (0, workerPreview_1.workerCell)((0, workerArt_1.workerPose)("idle", m(f)))),
        F.map((f) => (0, workerPreview_1.workerCell)((0, workerArt_1.workerPose)("work", m(f)))),
        F.map((f) => (0, workerPreview_1.workerCell)((0, workerArt_1.workerPose)("work", m(f, { moving: true, phase: 1.5 })))),
        F.map((f) => (0, workerPreview_1.workerCell)((0, workerArt_1.workerPose)("work", m(f, { moving: true, phase: 4.6 })))),
    ];
    (0, workerPreview_1.save)(dir, "stand", rows, 5);
    const w = (f) => (0, workerArt_1.workerPose)("work", m(f));
    (0, workerPreview_1.save)(dir, "tasks", [
        F.map((f) => (0, workerPreview_1.workerCell)(with_(w(f), { swing: 1 }))),
        F.map((f) => (0, workerPreview_1.workerCell)(with_(w(f), { swing: -1, dip: 2 }))),
        F.map((f) => (0, workerPreview_1.workerCell)(with_(w(f), { reach: 1 }))),
    ], 5);
    (0, workerPreview_1.save)(dir, "boot", [...strip(OFF, IDLE, 3.7, 16, "down", 8)], 4);
    (0, workerPreview_1.save)(dir, "bootSide", [...strip(OFF, IDLE, 3.7, 16, "right", 8)], 4);
    (0, workerPreview_1.save)(dir, "shutdown", [...strip(WORK, OFF, 2.7, 16, "down", 8), ...strip(WORK, OFF, 2.7, 8, "right", 8)], 4);
    (0, workerPreview_1.save)(dir, "settle", [...strip(WORK, IDLE, 5.8, 16, "down", 8), ...strip(WORK, IDLE, 5.8, 8, "right", 8)], 4);
    (0, workerPreview_1.save)(dir, "wake", [...strip(IDLE, { ...WORK, moving: false }, 0.75, 8, "down", 8), ...strip(IDLE, WORK, 0.75, 8, "right", 8)], 4);
    const blow = [];
    for (let i = 0; i < 16; i++)
        blow.push((0, workerPreview_1.workerCell)(with_(w("right"), { ...(0, workerAnim_1.blowMotion)(i / 15) })));
    const blowF = [];
    for (let i = 0; i < 16; i++)
        blowF.push((0, workerPreview_1.workerCell)(with_(w("down"), { ...(0, workerAnim_1.blowMotion)(i / 15) })));
    (0, workerPreview_1.save)(dir, "blow", [blow.slice(0, 8), blow.slice(8), blowF.slice(0, 8), blowF.slice(8)], 4);
}
module.exports = { sheets };
