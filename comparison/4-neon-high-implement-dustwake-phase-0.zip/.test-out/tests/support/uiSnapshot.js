"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RCanvas = void 0;
exports.png = png;
exports.renderDialogueScreens = renderDialogueScreens;
exports.run = run;
// Developer tool (not a test): rasterises the build menu, placement and
// deconstruct tools, the crafting screen and every screen of the guardian's
// dialogue at the base 320x180 into PNGs, with
// a minimal pixel canvas, so layouts can be checked for overflow without a
// browser. Run after `npm test` has compiled:
//   node -e "require('./.test-out/tests/support/uiSnapshot.js').run('snapshots')"
const node_fs_1 = require("node:fs");
const node_zlib_1 = require("node:zlib");
const world_1 = require("../../src/game/world/world");
const inventory_1 = require("../../src/game/sim/inventory");
const commands_1 = require("../../src/game/sim/commands");
const buildMenu_1 = require("../../src/game/screens/buildMenu");
const crafting_1 = require("../../src/game/screens/crafting");
const dialogue_1 = require("../../src/game/screens/dialogue");
const dialogue_2 = require("../../src/game/content/dialogue");
const screens_1 = require("../../src/game/ui/screens");
const flags_1 = require("../../src/game/content/flags");
const step_1 = require("../../src/game/sim/step");
const props_1 = require("../../src/game/art/props");
const props_2 = require("../../src/game/content/props");
const tiles_1 = require("../../src/game/content/tiles");
function parseColor(s) {
    if (s.startsWith("#")) {
        const h = s.length === 4 ? s.slice(1).split("").map((c) => c + c).join("") : s.slice(1, 7);
        const n = parseInt(h, 16);
        return [(n >> 16) & 255, (n >> 8) & 255, n & 255, 1];
    }
    const m = s.match(/rgba?\(([^)]+)\)/);
    if (m) {
        const p = m[1].split(",").map(Number);
        return [p[0], p[1], p[2], p[3] ?? 1];
    }
    return [0, 0, 0, 1];
}
class RCtx {
    constructor(canvas) {
        Object.defineProperty(this, "canvas", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: canvas
        });
        Object.defineProperty(this, "fillStyle", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "#000"
        });
        Object.defineProperty(this, "globalAlpha", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 1
        });
        Object.defineProperty(this, "globalCompositeOperation", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "source-over"
        });
        Object.defineProperty(this, "imageSmoothingEnabled", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        // Drawing state and paths, as far as the game uses them: save/restore keep the state (vision mode sets a
        // composite operation and an alpha inside a save), and a path is rects (vision's rings and ticks are 1 px rects),
        // filled once as their union. Anything else the browser has is left out, so a new use fails loudly here.
        Object.defineProperty(this, "stack", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "path", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
    }
    blend(i, c, a) {
        const d = this.canvas.data, k = c[3] * a;
        d[i] = d[i] * (1 - k) + c[0] * k;
        d[i + 1] = d[i + 1] * (1 - k) + c[1] * k;
        d[i + 2] = d[i + 2] * (1 - k) + c[2] * k;
        d[i + 3] = Math.min(255, d[i + 3] + 255 * k);
    }
    fillRect(x, y, w, h) {
        const c = parseColor(this.fillStyle), W = this.canvas.width, H = this.canvas.height;
        const x0 = Math.max(0, Math.round(x)), y0 = Math.max(0, Math.round(y)), x1 = Math.min(W, Math.round(x + w)), y1 = Math.min(H, Math.round(y + h));
        for (let yy = y0; yy < y1; yy++)
            for (let xx = x0; xx < x1; xx++)
                this.blend((yy * W + xx) * 4, c, this.globalAlpha);
    }
    clearRect(x, y, w, h) {
        const W = this.canvas.width;
        for (let yy = Math.max(0, y); yy < Math.min(this.canvas.height, y + h); yy++)
            for (let xx = Math.max(0, x); xx < Math.min(W, x + w); xx++)
                this.canvas.data.fill(0, (yy * W + xx) * 4, (yy * W + xx) * 4 + 4);
    }
    createImageData(w, h) { return { width: w, height: h, data: new Uint8ClampedArray(w * h * 4) }; }
    getImageData(_x, _y, w, h) { return this.createImageData(w, h); }
    putImageData() { }
    drawImage(src, ...a) {
        let sx = 0, sy = 0, sw = src.width, sh = src.height, dx, dy, dw = src.width, dh = src.height;
        if (a.length === 2)
            [dx, dy] = a;
        else if (a.length === 4)
            [dx, dy, dw, dh] = a;
        else
            [sx, sy, sw, sh, dx, dy, dw, dh] = a;
        const W = this.canvas.width, H = this.canvas.height;
        for (let j = 0; j < Math.round(dh); j++)
            for (let i = 0; i < Math.round(dw); i++) {
                const tx = Math.round(dx) + i, ty = Math.round(dy) + j;
                if (tx < 0 || ty < 0 || tx >= W || ty >= H)
                    continue;
                const ux = Math.floor(sx + (i * sw) / dw), uy = Math.floor(sy + (j * sh) / dh), si = (uy * src.width + ux) * 4;
                const al = src.data[si + 3] / 255;
                if (al > 0)
                    this.blend((ty * W + tx) * 4, [src.data[si], src.data[si + 1], src.data[si + 2], al], this.globalAlpha);
            }
    }
    save() { this.stack.push([this.fillStyle, this.globalAlpha, this.globalCompositeOperation, this.imageSmoothingEnabled]); }
    restore() { const s = this.stack.pop(); if (s)
        [this.fillStyle, this.globalAlpha, this.globalCompositeOperation, this.imageSmoothingEnabled] = s; }
    beginPath() { this.path = []; }
    rect(x, y, w, h) { this.path.push([x, y, w, h]); }
    fill() {
        const c = parseColor(this.fillStyle), W = this.canvas.width, H = this.canvas.height, done = new Set();
        for (const [x, y, w, h] of this.path) {
            const x0 = Math.max(0, Math.round(x)), y0 = Math.max(0, Math.round(y)), x1 = Math.min(W, Math.round(x + w)), y1 = Math.min(H, Math.round(y + h));
            for (let yy = y0; yy < y1; yy++)
                for (let xx = x0; xx < x1; xx++) {
                    const i = yy * W + xx;
                    if (!done.has(i)) {
                        done.add(i);
                        this.blend(i * 4, c, this.globalAlpha);
                    }
                }
        }
    }
    clip() { }
}
class RCanvas {
    constructor(w = 0, h = 0) {
        Object.defineProperty(this, "width", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "height", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "data", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "ctx", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.width = w;
        this.height = h;
        this.data = new Uint8ClampedArray(Math.max(1, w * h * 4));
    }
    getContext() {
        if (this.data.length !== this.width * this.height * 4)
            this.data = new Uint8ClampedArray(this.width * this.height * 4);
        return (this.ctx ?? (this.ctx = new RCtx(this)));
    }
}
exports.RCanvas = RCanvas;
function png(c, scale) {
    const W = c.width * scale, H = c.height * scale;
    const raw = Buffer.alloc((W * 3 + 1) * H);
    for (let y = 0; y < H; y++) {
        raw[y * (W * 3 + 1)] = 0;
        for (let x = 0; x < W; x++) {
            const si = (Math.floor(y / scale) * c.width + Math.floor(x / scale)) * 4, di = y * (W * 3 + 1) + 1 + x * 3;
            raw[di] = c.data[si];
            raw[di + 1] = c.data[si + 1];
            raw[di + 2] = c.data[si + 2];
        }
    }
    const crcT = Array.from({ length: 256 }, (_, n) => { let k = n; for (let i = 0; i < 8; i++)
        k = k & 1 ? 0xedb88320 ^ (k >>> 1) : k >>> 1; return k >>> 0; });
    const crc = (b) => { let r = 0xffffffff; for (const v of b)
        r = crcT[(r ^ v) & 255] ^ (r >>> 8); return (r ^ 0xffffffff) >>> 0; };
    const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const cb = Buffer.alloc(4); cb.writeUInt32BE(crc(td)); return Buffer.concat([l, td, cb]); };
    const ih = Buffer.alloc(13);
    ih.writeUInt32BE(W, 0);
    ih.writeUInt32BE(H, 4);
    ih[8] = 8;
    ih[9] = 2;
    return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk("IHDR", ih), chunk("IDAT", (0, node_zlib_1.deflateSync)(raw)), chunk("IEND", Buffer.alloc(0))]);
}
/**
 * Render every screen of every segment of an NPC script's dialogue box onto a
 * 320x180 UI canvas, fully typed out, calling `shot` for each. Shared by the
 * PNG dump and the overflow test (tests/dialogueWrap.test.ts).
 */
function renderDialogueScreens(w, npc, script, shot) {
    const ui = new RCanvas(320, 180);
    const host = {
        ctx: ui.getContext(), world: w, get pl() { return (0, world_1.player)(w); }, get area() { return (0, world_1.currentArea)(w); },
        t: 0, screens: new screens_1.ScreenStack(), typed: [], sfx: new Proxy({}, { get: () => () => { } }),
        hit: () => false, say: () => { }, renderNote: () => { }, renderToast: () => { }, animate: () => { }, drainEvents: () => { w.events = []; },
    };
    host.screens.set({ id: "play", opaque: true, t: 0, update() { }, render() { } });
    for (const seg of dialogue_2.DIALOGUE[script].segments) {
        const d = new dialogue_1.DialogueUi(host);
        d.open(npc, script, seg.id);
        if (!d.dlg)
            continue;
        d.dlg.pages.forEach((_, i) => {
            Object.assign(d.dlg, { page: i, chars: 1e9, hold: 0 });
            ui.data.fill(0);
            ui.getContext().fillStyle = "#1a1620";
            ui.getContext().fillRect(0, 0, 320, 180);
            d.screen.render();
            shot(`dialogue-${script}-${seg.id}-${i + 1}`, ui);
        });
        host.screens.popToBase();
    }
}
function run(dir = "snapshots") {
    globalThis.document = { createElement: () => new RCanvas() };
    (0, node_fs_1.mkdirSync)(dir, { recursive: true });
    const w = (0, world_1.createWorld)(7);
    (0, step_1.stepWorld)(w, 1 / 60);
    const pl = (0, world_1.player)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    (0, inventory_1.addItems)(w, pl, "wood", 5);
    (0, inventory_1.addItems)(w, pl, "stone", 3);
    const ui = new RCanvas(320, 180), world = new RCanvas(320, 180);
    const host = {
        ctx: ui.getContext(), wctx: world.getContext(), world: w, get pl() { return (0, world_1.player)(w); }, get area() { return (0, world_1.currentArea)(w); },
        t: 0.1, cam: { x: 0, y: 0 }, vw: 320, vh: 180, screens: new screens_1.ScreenStack(), typed: [],
        sfx: new Proxy({}, { get: () => () => { } }), hit: () => false, say: (s) => { host.note = s; }, renderNote: () => { }, drainEvents: () => { w.events = []; },
    };
    host.screens.set({ id: "play", opaque: true, t: 0, update() { }, render() { } });
    const scene = () => {
        // crude world: tiles and props, so the ghost has context
        const a = (0, world_1.currentArea)(w), c = world.getContext();
        c.globalAlpha = 1;
        for (let ty = 0; ty < 12; ty++)
            for (let tx = 0; tx < 21; tx++) {
                const gx = Math.floor(host.cam.x / tiles_1.TS) + tx, gy = Math.floor(host.cam.y / tiles_1.TS) + ty;
                c.fillStyle = (0, tiles_1.isSolidT)(a.tile(gx, gy)) ? "#2e2a33" : "#4a4238";
                c.fillRect(gx * tiles_1.TS - host.cam.x, gy * tiles_1.TS - host.cam.y, tiles_1.TS, tiles_1.TS);
            }
        for (const p of [...a.props].sort((x, y) => x.y - y.y)) {
            const d = (0, props_2.propDef)(p.kind), s = (0, props_1.propSprite)(p.kind, p.v, d.alt === "lit" ? !!p.lit : d.alt === "taken" ? p.taken : p.open);
            if (s)
                c.drawImage(s.a, Math.round(p.x - s.ax - host.cam.x), Math.round(p.y - s.ay - host.cam.y));
        }
        c.fillStyle = "#c0c0d0";
        c.fillRect(pl.x - 5 - host.cam.x, pl.y - 14 - host.cam.y, 10, 14);
    };
    const shot = (name, draw) => {
        world.data.fill(0);
        ui.data.fill(0);
        scene();
        draw();
        const out = new RCanvas(320, 180);
        out.getContext().drawImage(world, 0, 0);
        out.getContext().drawImage(ui, 0, 0);
        (0, node_fs_1.writeFileSync)(`${dir}/${name}.png`, png(out, 3));
    };
    const b = new buildMenu_1.BuildUi(host);
    // translocation room, below the wall between the two torches
    pl.x = 10 * tiles_1.TS + 8;
    pl.y = 4 * tiles_1.TS + 12;
    pl.facing = "up";
    host.cam.x = 0;
    host.cam.y = 0;
    b.open();
    b.favorites.add("wall_torch");
    shot("build-menu", () => b.screen.render());
    b.cursor = b["list"].findIndex((e) => e.id === "brazier");
    shot("build-menu-locked", () => b.screen.render());
    b.search.active = true;
    b.search.value = "STONE";
    b["refresh"]();
    shot("build-menu-search", () => b.screen.render());
    b.search.active = false;
    b.search.value = "";
    b.tab = 2;
    b["refresh"]();
    b.cursor = b["list"].findIndex((e) => e.id === "wall_torch");
    shot("build-menu-light", () => b.screen.render());
    b.tab = 3;
    b["refresh"]();
    b.cursor = b["list"].findIndex((e) => e.id === "craftbench");
    shot("build-menu-craft", () => b.screen.render());
    b.tab = 2;
    b["refresh"]();
    b.cursor = b["list"].findIndex((e) => e.id === "wall_torch");
    b.recipe = "wall_torch";
    b["toPlace"]();
    shot("place-wall-torch", () => b.screen.render());
    b.cur = { tx: 10, ty: 3 };
    shot("place-wall-torch-invalid", () => b.screen.render());
    b["toRemove"]();
    shot("remove-authored-torch", () => b.screen.render());
    b.cur = { tx: 10, ty: 2 };
    shot("remove-nothing", () => b.screen.render());
    // surface clearing for floor props and the bench
    (0, world_1.enterArea)(w, pl, "surface", 20 * tiles_1.TS + 8, 50 * tiles_1.TS + 14);
    const sa = (0, world_1.currentArea)(w);
    for (let ty = 46; ty <= 54; ty++)
        for (let tx = 16; tx <= 24; tx++)
            sa.setTile(tx, ty, 1);
    for (const p of [...sa.props])
        if (Math.abs(p.x - pl.x) < 96 && Math.abs(p.y - pl.y) < 96)
            sa.removeProp(p.id);
    (0, inventory_1.addItems)(w, pl, "wood", 20);
    (0, inventory_1.addItems)(w, pl, "stone", 10);
    host.cam.x = pl.x - 160;
    host.cam.y = pl.y - 100;
    // The player's own task advances in stepPlayer (stepWorld only ticks other actors), so step both like the host does.
    (0, commands_1.orderBuild)(w, pl, "craftbench", 20, 52);
    for (let i = 0; i < 200; i++) {
        (0, step_1.stepPlayer)(w, 1 / 60, { ix: 0, iy: 0, use: false });
        (0, step_1.stepWorld)(w, 1 / 60);
    }
    b.recipe = "table";
    b["toPlace"]();
    b.cur = { tx: 22, ty: 49 };
    shot("place-table", () => b.screen.render());
    b["toRemove"]();
    b.cur = { tx: 20, ty: 52 };
    shot("remove-bench", () => b.screen.render());
    const cu = new crafting_1.CraftingUi(host);
    cu.open("crafting", "x");
    shot("crafting", () => cu.screen.render());
    // the same bench for a golem that doesn't know how to build: greyed out, nothing listed
    w.flags.delete(flags_1.FLAGS.knowBuild);
    host.screens.popToBase();
    cu.open("crafting", "x");
    shot("crafting-locked", () => cu.screen.render());
    // the guardian's whole script (with the iron arm, so the optional page shows too)
    const dw = (0, world_1.createWorld)(7);
    (0, world_1.setFlag)(dw, flags_1.FLAGS.golemArm);
    renderDialogueScreens(dw, "npc.guardian", "guardian", (name, c) => (0, node_fs_1.writeFileSync)(`${dir}/${name}.png`, png(c, 3)));
}
