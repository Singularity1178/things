"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Actor, power, storage and work foundations. The optional rows are registered
// in this test process only; the production content lists remain unchanged.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const actors_1 = require("../src/game/content/actors");
const power_1 = require("../src/game/content/power");
const crafting_1 = require("../src/game/content/crafting");
const build_1 = require("../src/game/content/build");
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const debugFoundations_1 = require("../src/game/sim/debugFoundations");
const inventory_1 = require("../src/game/sim/inventory");
const gear_1 = require("../src/game/sim/gear");
const actorStats_1 = require("../src/game/sim/actorStats");
const power_2 = require("../src/game/sim/power");
const storage_1 = require("../src/game/sim/storage");
const crafting_2 = require("../src/game/sim/crafting");
const tasks_1 = require("../src/game/sim/tasks");
const step_1 = require("../src/game/sim/step");
const navigation_1 = require("../src/game/sim/navigation");
const interact_1 = require("../src/game/sim/interact");
const build_2 = require("../src/game/sim/build");
const discovery_1 = require("../src/game/sim/discovery");
const tiles_1 = require("../src/game/content/tiles");
(0, debugFoundations_1.registerFoundations)();
function workshop() {
    const w = (0, world_1.createWorld)(11), area = (0, world_1.getArea)(w, "debug_workshop");
    const pl = (0, world_1.player)(w), bench = area.prop("bench.fixture"), chest = area.prop("chest.fixture");
    (0, world_1.enterArea)(w, pl, area.id, bench.x, bench.y + 14);
    (0, world_1.setFlag)(w, "know.build");
    return { w, area, pl, bench, chest };
}
const total = (slots, item) => slots.reduce((n, s) => n + (s?.item === item ? s.n : 0), 0);
(0, node_test_1.test)("definitions isolate bodies, speed, capacity and usable slots for every actor", () => {
    const { w, pl } = workshop();
    const small = (0, world_1.makeActor)("small", "worker_golem", pl.area, 40, 40), human = (0, world_1.makeActor)("human", "npc_worker", pl.area, 80, 40);
    small.powerCore = "ruby_core";
    w.actors.push(small, human);
    (0, world_1.setFlag)(w, "golem.arm");
    for (const f of ["golem.slot.armL", "golem.slot.rune1", "golem.slot.rune2", "golem.slot.rune3"])
        (0, world_1.setFlag)(w, f);
    (0, step_1.stepWorld)(w, 0.01);
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 16);
    strict_1.default.equal(small.inventory.length, 8);
    strict_1.default.equal(human.inventory.length, 8);
    strict_1.default.ok((0, gear_1.slotUsable)(w, human, "armL"), "the human does not inherit the maintainer's damaged-arm lock");
    strict_1.default.equal((0, world_1.actorById)(w, "npc.guardian").inventory.length, 0);
    strict_1.default.deepEqual((0, gear_1.usableSlots)(w, small), ["rune0"]);
    (0, world_1.setActorFlag)(small, "golem.slot.rune1");
    strict_1.default.equal((0, gear_1.slotUsable)(w, small, "rune1"), false, "an unlock never creates a slot the body lacks");
    strict_1.default.ok((0, actorStats_1.actorSpeed)(w, small) < (0, actorStats_1.actorSpeed)(w, pl));
    strict_1.default.ok((0, actorStats_1.harvestPower)(small) < (0, actorStats_1.harvestPower)(pl));
    strict_1.default.notDeepEqual((0, actors_1.actorDef)(small).body.box, (0, actors_1.actorDef)(pl).body.box);
    strict_1.default.equal(w.flags.has("golem.arm"), false, "body state is not world state");
    (0, inventory_1.addItems)(w, small, "rune_swift", 1);
    (0, inventory_1.addItems)(w, small, "rune_glow", 1);
    strict_1.default.ok((0, gear_1.applyWear)(w, small, 0).ok);
    strict_1.default.ok((0, gear_1.applyWear)(w, small, 1).ok);
    strict_1.default.equal(small.gear.rune0, "rune_glow");
    strict_1.default.equal((0, inventory_1.countItem)(small, "rune_swift"), 1);
});
(0, node_test_1.test)("a new body and capacity tier are data rows; NPC overflow is conserved", () => {
    const { w, pl, area } = workshop();
    actors_1.ACTORS.porter = { ...actors_1.ACTORS.npc_worker, inventory: { slots: 2, tiers: [{ slots: 4, requires: { worn: ["basket"] } }] } };
    try {
        const a = (0, world_1.makeActor)("porter", "porter", area.id, pl.x - 48, pl.y);
        w.actors.push(a);
        (0, inventory_1.addItems)(w, a, "basket", 1);
        strict_1.default.ok((0, gear_1.applyWear)(w, a, 0).ok);
        strict_1.default.equal((0, inventory_1.capacity)(w, a), 4);
        (0, inventory_1.addItems)(w, a, "coin", 4);
        a.gear = {};
        (0, inventory_1.reconcileCapacity)(w, a);
        strict_1.default.equal(a.inventory.length, 2);
        strict_1.default.equal((0, inventory_1.countItem)(a, "coin") + area.loose.filter((l) => !l.taken && l.item === "coin").reduce((n, l) => n + (l.n ?? 1), 0), 4);
    }
    finally {
        delete actors_1.ACTORS.porter;
    }
});
(0, node_test_1.test)("body power accepts a low-tier core but refuses to power a higher-rank actor; gear core mount is separate", () => {
    const { w, pl } = workshop();
    const small = (0, world_1.makeActor)("small", "worker_golem", pl.area, pl.x + 12, pl.y);
    const guardian = (0, world_1.actorById)(w, "npc.guardian");
    w.actors.push(small);
    strict_1.default.equal((0, actorStats_1.powered)(small), false);
    strict_1.default.deepEqual((0, power_2.coreCheck)(small, "ruby_core"), { accepts: true, sufficient: true });
    strict_1.default.deepEqual((0, power_2.coreCheck)(guardian, "ruby_core"), { accepts: true, sufficient: false });
    strict_1.default.equal((0, power_2.coreCheck)(small, "core").accepts, false, "the ritual's aether core is not body fuel");
    (0, inventory_1.addItems)(w, pl, "ruby_core", 2);
    strict_1.default.ok((0, power_2.insertPowerCore)(w, pl, small, "ruby_core"));
    strict_1.default.ok((0, actorStats_1.powered)(small));
    strict_1.default.deepEqual(small.gear, {});
    (0, world_1.enterArea)(w, pl, guardian.area, guardian.x, guardian.y + 15);
    strict_1.default.ok((0, power_2.insertPowerCore)(w, pl, guardian, "ruby_core"), "insufficient is not incompatible");
    strict_1.default.equal((0, actorStats_1.powered)(guardian), false);
    strict_1.default.equal((0, actorStats_1.actorSpeed)(w, guardian), 0);
    strict_1.default.equal(guardian.powerCore, "ruby_core");
    strict_1.default.equal(guardian.gear.core, undefined);
    strict_1.default.ok((0, power_2.removePowerCore)(w, pl, guardian));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "ruby_core"), 1);
    strict_1.default.equal((0, power_2.insertPowerCore)(w, pl, small, "ruby_core"), false, "not remotely across areas");
    const loaded = (0, save_1.deserialize)((0, save_1.serialize)(w));
    strict_1.default.equal((0, world_1.actorById)(loaded, small.id).powerCore, "ruby_core");
});
(0, node_test_1.test)("core tiers and effects are data, and ineffective cores grant no effects", () => {
    const { w, pl } = workshop();
    const a = (0, world_1.makeActor)("powered", "worker_golem", pl.area, 40, 40);
    const old = power_1.POWER_CORES.ruby_core;
    try {
        power_1.POWER_CORES.ruby_core = { family: "golem", tier: 3, effects: { speed: 0.25, harvest: 1 } };
        a.powerCore = "ruby_core";
        strict_1.default.equal((0, actorStats_1.actorSpeed)(w, a), actors_1.ACTORS.worker_golem.speed * 1.25);
        strict_1.default.equal((0, actorStats_1.harvestPower)(a), 1);
        const g = (0, world_1.actorById)(w, "npc.guardian");
        g.powerCore = "ruby_core";
        strict_1.default.ok((0, actorStats_1.powered)(g));
        power_1.POWER_CORES.ruby_core = { family: "golem", tier: 1, effects: { harvest: 20 } };
        strict_1.default.equal((0, actorStats_1.harvestPower)(g), 0, "tier must be sufficient before effects apply");
        strict_1.default.equal((0, power_2.coreCheck)((0, world_1.makeActor)("human", "npc_worker", pl.area, 0, 0), "ruby_core").accepts, false);
    }
    finally {
        power_1.POWER_CORES.ruby_core = old;
    }
});
(0, node_test_1.test)("generic inventories transfer and stack atomically without layout or interactable cache churn", () => {
    const { w, pl, area, chest } = workshop();
    const ref = (0, storage_1.storageRef)(area.id, chest.id), grid = (0, navigation_1.navGrid)(area, pl), inter = (0, interact_1.interactables)(area);
    const layout = area.layoutRevision, interaction = area.interactionRevision, revision = area.revision;
    (0, inventory_1.addItems)(w, pl, "wood", 53);
    strict_1.default.equal((0, storage_1.transferItems)(w, (0, storage_1.packRef)(pl), ref, "wood", 53), 53);
    strict_1.default.equal(chest.inventory.length, 32);
    strict_1.default.deepEqual(chest.inventory.slice(0, 3), [{ item: "wood", n: 20 }, { item: "wood", n: 20 }, { item: "wood", n: 13 }]);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 0);
    strict_1.default.equal((0, navigation_1.navGrid)(area, pl), grid);
    strict_1.default.equal((0, interact_1.interactables)(area), inter);
    strict_1.default.equal(area.layoutRevision, layout);
    strict_1.default.equal(area.interactionRevision, interaction);
    strict_1.default.ok(area.revision > revision && area.storageRevision > 0);
    strict_1.default.equal((0, storage_1.transferItems)(w, ref, ref, "wood", 10), 0);
    strict_1.default.equal((0, storage_1.transferItems)(w, ref, (0, storage_1.packRef)(pl), "wood", -1), 0);
    const snapshot = (0, storage_1.inventoryHandle)(w, ref);
    snapshot.inventory[0] = null;
    strict_1.default.equal(total(chest.inventory, "wood"), 53, "reading gives an isolated snapshot");
    const w2 = (0, save_1.deserialize)((0, save_1.serialize)(w));
    strict_1.default.deepEqual((0, save_1.serialize)(w2), (0, save_1.serialize)(w), "authored storage diffs round-trip");
    area.setTile(1, 1, tiles_1.T.WALL);
    strict_1.default.notEqual((0, navigation_1.navGrid)(area, pl), grid);
});
(0, node_test_1.test)("full storage gives a partial transfer, never deletes the remainder", () => {
    const { w, pl, area, chest } = workshop();
    area.setInventory(chest.id, Array.from({ length: 32 }, () => ({ item: "wood", n: 20 })));
    const slots = chest.inventory.map((s) => s ? { ...s } : null);
    slots[31].n = 18;
    area.setInventory(chest.id, slots);
    (0, inventory_1.addItems)(w, pl, "wood", 10);
    strict_1.default.equal((0, storage_1.transferItems)(w, (0, storage_1.packRef)(pl), (0, storage_1.storageRef)(area.id, chest.id), "wood", 10), 2);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 8);
    strict_1.default.equal(total(chest.inventory, "wood"), 640);
    strict_1.default.throws(() => area.setInventory(chest.id, [{ item: "wood", n: 21 }]), /stack/);
});
(0, node_test_1.test)("storage deconstruction spills every non-critical stack and never makes looted dungeon chests salvageable", () => {
    const { w, pl, area } = workshop();
    const chest = area.addProp("storage_chest", pl.x - 24, pl.y, { recipe: "storage_chest", refund: [{ item: "planks", n: 4 }] });
    area.setInventory(chest.id, [{ item: "wood", n: 20 }, { item: "stone", n: 7 }]);
    (0, build_2.applyDeconstruct)(w, pl, area, chest.id);
    strict_1.default.equal(area.prop(chest.id), undefined);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "planks"), 4);
    strict_1.default.equal(area.loose.filter((l) => l.item === "wood").reduce((n, l) => n + (l.n ?? 1), 0), 20);
    const locked = area.addProp("storage_chest", pl.x - 24, pl.y, { recipe: "storage_chest" });
    area.setInventory(locked.id, [{ item: "chisel", n: 1 }]);
    const chk = (0, build_2.deconstructCheck)(w, pl, area, locked.id);
    strict_1.default.ok(!chk.ok && chk.reason === "holds");
    strict_1.default.equal(build_1.AUTHORED_SALVAGE.chest, undefined);
    strict_1.default.equal((0, build_2.salvageOf)((0, world_1.getArea)(w, "dungeon").prop("chest@57,4")), null);
    strict_1.default.deepEqual((0, save_1.serialize)((0, save_1.deserialize)((0, save_1.serialize)(w))), (0, save_1.serialize)(w), "built storage diff survives too");
});
(0, node_test_1.test)("crafting draws from pack plus storage within two station tiles, but the tool must be carried", () => {
    const { w, pl, area, bench, chest } = workshop();
    (0, inventory_1.addItems)(w, pl, "wood", 1);
    area.setInventory(chest.id, [{ item: "wood", n: 1 }, { item: "cut_stone", n: 2 }, { item: "chisel", n: 1 }]);
    strict_1.default.ok((0, crafting_2.orderCraft)(w, pl, "crafting", "planks", bench.id));
    (0, tasks_1.tickTask)(w, pl, 2);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "planks"), 3);
    strict_1.default.equal(total(chest.inventory, "wood"), 0);
    strict_1.default.equal((0, crafting_2.orderCraft)(w, pl, "crafting", "rune_swift", bench.id), false);
    (0, inventory_1.addItems)(w, pl, "chisel", 1);
    strict_1.default.ok((0, crafting_2.orderCraft)(w, pl, "crafting", "rune_swift", bench.id));
    (0, tasks_1.tickTask)(w, pl, 3);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "chisel"), 1);
    strict_1.default.equal(total(chest.inventory, "chisel"), 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "rune_swift"), 1);
    const near = area.addProp("storage_chest", bench.x + 32, bench.y), far = area.addProp("storage_chest", bench.x + 48, bench.y);
    strict_1.default.ok((0, storage_1.nearbyStorage)(area, bench).includes(near));
    strict_1.default.ok(!(0, storage_1.nearbyStorage)(area, bench).includes(far));
    area.setInventory(far.id, [{ item: "wood", n: 20 }]);
    strict_1.default.equal((0, crafting_2.craftEntry)(w, pl, crafting_1.CRAFT_RECIPES.find((r) => r.id === "planks"), bench).status, "cost");
});
(0, node_test_1.test)("two crafters competing for one chest revalidate atomically at the fire point", () => {
    const { w, pl, area, bench, chest } = workshop();
    pl.x = 40;
    pl.y = 40;
    const a = (0, world_1.makeActor)("a", "npc_worker", area.id, bench.x - 12, bench.y + 16), b = (0, world_1.makeActor)("b", "npc_worker", area.id, bench.x + 12, bench.y + 16);
    w.actors.push(a, b);
    area.setInventory(chest.id, [{ item: "wood", n: 2 }]);
    strict_1.default.ok((0, crafting_2.orderCraft)(w, a, "crafting", "planks", bench.id));
    strict_1.default.ok((0, crafting_2.orderCraft)(w, b, "crafting", "planks", bench.id));
    (0, step_1.stepWorld)(w, 2);
    strict_1.default.equal((0, inventory_1.countItem)(a, "planks") + (0, inventory_1.countItem)(b, "planks"), 3);
    strict_1.default.equal(total(chest.inventory, "wood"), 0);
    strict_1.default.equal(w.events.filter((e) => e.t === "crafted").length, 1);
});
(0, node_test_1.test)("duplicate ingredients and changed stations cannot partially consume materials", () => {
    const { w, pl, area, bench } = workshop();
    (0, inventory_1.addItems)(w, pl, "wood", 3);
    strict_1.default.equal((0, storage_1.consumeInputs)((0, storage_1.craftSources)(w, pl, bench), [{ item: "wood", n: 2 }, { item: "wood", n: 2 }]), false);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 3);
    strict_1.default.ok((0, crafting_2.orderCraft)(w, pl, "crafting", "planks", bench.id));
    pl.x = 32;
    pl.y = 32;
    (0, tasks_1.tickTask)(w, pl, 2);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 3);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "planks"), 0);
    pl.x = bench.x;
    pl.y = bench.y + 14;
    strict_1.default.ok((0, crafting_2.orderCraft)(w, pl, "crafting", "planks", bench.id));
    area.removeProp(bench.id);
    (0, tasks_1.tickTask)(w, pl, 2);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 3);
});
(0, node_test_1.test)("inverse recipes preserve raw values and relic discovery; core carving carries its tool", () => {
    const { w, pl, area, bench } = workshop();
    const before = [(0, crafting_1.rawValue)("stone"), (0, crafting_1.rawValue)("cut_stone"), (0, crafting_1.rawValue)("planks")];
    strict_1.default.deepEqual(before, [1, 1.5, 2 / 3]);
    strict_1.default.deepEqual([(0, crafting_1.rawValue)("stone", [...crafting_1.CRAFT_RECIPES].reverse()), (0, crafting_1.rawValue)("cut_stone", [...crafting_1.CRAFT_RECIPES].reverse()), (0, crafting_1.rawValue)("planks", [...crafting_1.CRAFT_RECIPES].reverse())], before);
    (0, inventory_1.addItems)(w, pl, "crown", 1);
    strict_1.default.equal((0, discovery_1.relicCount)(w, pl), 1);
    strict_1.default.ok((0, crafting_2.applyCraft)(w, pl, area, "unmake_crown", bench.id));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "crown"), 0);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "large_ruby"), 1);
    strict_1.default.equal((0, discovery_1.relicCount)(w, pl), 1);
    strict_1.default.equal((0, crafting_2.applyCraft)(w, pl, area, "ruby_core", bench.id), false);
    (0, inventory_1.addItems)(w, pl, "chisel", 1);
    strict_1.default.ok((0, crafting_2.applyCraft)(w, pl, area, "ruby_core", bench.id));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "ruby_core"), 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "chisel"), 1);
    (0, inventory_1.addItems)(w, pl, "rune_glow", 1);
    strict_1.default.ok((0, crafting_2.applyCraft)(w, pl, area, "unmake_rune_glow", bench.id));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "stone"), 1);
    strict_1.default.equal((0, discovery_1.relicCount)((0, save_1.deserialize)((0, save_1.serialize)(w)), (0, world_1.player)((0, save_1.deserialize)((0, save_1.serialize)(w)))), 1);
    strict_1.default.ok(crafting_1.CRAFT_RECIPES.filter((r) => r.mode === "deconstruct").every((r) => !r.tools));
});
(0, node_test_1.test)("weak, strong and mixed harvesters get exactly the same finite yield, including a fractional-work save", () => {
    for (const powers of [[1], [0.5], [0.25, 1.75], [10]]) {
        const w = (0, world_1.createWorld)(6), area = (0, world_1.getArea)(w, "debug_yard"), p = area.prop("tree.fixture");
        const pl = (0, world_1.player)(w);
        (0, world_1.enterArea)(w, pl, area.id, p.x, p.y + 12);
        actors_1.ACTORS.harvester = { ...actors_1.ACTORS.golem, harvestPower: powers[0] };
        pl.definition = "harvester";
        let hits = 0;
        while (!p.taken && hits < 100) {
            actors_1.ACTORS.harvester.harvestPower = powers[hits % powers.length];
            (0, tasks_1.applyEffect)(w, pl, { op: "harvest" }, { kind: "harvest", x: p.x, y: p.y, propId: p.id });
            if (++hits === 1)
                strict_1.default.deepEqual((0, save_1.serialize)((0, save_1.deserialize)((0, save_1.serialize)(w))), (0, save_1.serialize)(w));
        }
        strict_1.default.equal(p.dmg, 4);
        strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 6);
        (0, tasks_1.applyEffect)(w, pl, { op: "harvest" }, { kind: "harvest", x: p.x, y: p.y, propId: p.id });
        strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 6);
        if (powers[0] === 0.5)
            strict_1.default.equal(hits, 8);
        delete actors_1.ACTORS.harvester;
    }
});
(0, node_test_1.test)("removing storage between craft start and completion leaves every input intact", () => {
    const { w, pl, area, bench, chest } = workshop();
    (0, inventory_1.addItems)(w, pl, "wood", 1);
    area.setInventory(chest.id, [{ item: "wood", n: 1 }]);
    strict_1.default.ok((0, crafting_2.orderCraft)(w, pl, "crafting", "planks", bench.id));
    area.removeProp(chest.id);
    (0, tasks_1.tickTask)(w, pl, 2);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "planks"), 0);
    (0, inventory_1.removeItems)(pl, "wood");
});
