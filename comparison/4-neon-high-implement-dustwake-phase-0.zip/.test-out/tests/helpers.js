"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.currentSegment = exports.guardianIt = exports.GUARDIAN = exports.newWorld = exports.propItem = exports.DT = void 0;
exports.frame = frame;
exports.frames = frames;
exports.events = events;
exports.find = find;
exports.standAt = standAt;
exports.useOn = useOn;
exports.slamAt = slamAt;
exports.talkThrough = talkThrough;
// Test helpers: drive the simulation the way the play screen does, without a browser.
const world_1 = require("../src/game/world/world");
const step_1 = require("../src/game/sim/step");
const interact_1 = require("../src/game/sim/interact");
const dialogue_1 = require("../src/game/sim/dialogue");
Object.defineProperty(exports, "currentSegment", { enumerable: true, get: function () { return dialogue_1.currentSegment; } });
exports.DT = 1 / 60;
const NONE = { ix: 0, iy: 0, use: false };
/** One play-screen frame: player step, then world step (same order as the host). */
function frame(w, input = NONE) {
    (0, step_1.addPlayTime)(w, exports.DT);
    const r = (0, step_1.stepPlayer)(w, exports.DT, input);
    (0, step_1.stepWorld)(w, exports.DT);
    return r;
}
function frames(w, n, input = NONE) {
    for (let i = 0; i < n; i++)
        frame(w, input);
}
/** Drain and return events emitted so far. */
function events(w) {
    const e = w.events;
    w.events = [];
    return e;
}
function find(w, pred) {
    const it = (0, interact_1.allInteractables)(w, (0, world_1.currentArea)(w)).find(pred);
    if (!it)
        throw new Error("interactable not found");
    return it;
}
/** Stand just below an interactable, facing up at it (as the player would). */
function standAt(w, it) {
    const pl = (0, world_1.player)(w);
    pl.x = it.x;
    pl.y = it.y + 9;
    pl.vx = 0;
    pl.vy = 0;
    pl.facing = "up";
}
/** Walk up to `it`, press use, and let the resulting work finish (plus a little slack for scheduled effects). */
function useOn(w, it) {
    standAt(w, it);
    const r = frame(w, { ix: 0, iy: 0, use: true });
    let guard = 0;
    while ((0, world_1.player)(w).task && guard++ < 1000)
        frame(w);
    frames(w, 30);
    return r;
}
/** Press attack (Space), optionally after standing at `it`, and let the slam play out. */
function slamAt(w, it) {
    if (it)
        standAt(w, it);
    const r = frame(w, { ix: 0, iy: 0, use: false, attack: true });
    let guard = 0;
    while ((0, world_1.player)(w).task && guard++ < 1000)
        frame(w);
    frames(w, 5);
    return r;
}
const propItem = (w, propId) => find(w, (i) => i.propId === propId);
exports.propItem = propItem;
const newWorld = (seed = 12345) => (0, world_1.createWorld)(seed);
exports.newWorld = newWorld;
exports.GUARDIAN = "npc.guardian";
const guardianIt = (w) => find(w, (i) => i.kind === "npc" && i.actorId === exports.GUARDIAN);
exports.guardianIt = guardianIt;
/**
 * Talk to an NPC through the normal interaction path, then play every segment
 * the dialogue offers in order, exactly as the dialogue screen would. Returns
 * the ids of the segments played.
 */
function talkThrough(w, it) {
    events(w);
    useOn(w, it);
    const ev = events(w).find((e) => e.t === "dialogue");
    if (!ev || ev.t !== "dialogue")
        return [];
    const pl = (0, world_1.player)(w), played = [];
    let seg = (0, dialogue_1.scriptOf)(w, ev.npc).segments.find((s) => s.id === ev.segment) ?? null;
    while (seg) {
        played.push(seg.id);
        seg = (0, dialogue_1.playSegment)(w, pl, ev.npc, seg);
    }
    return played;
}
