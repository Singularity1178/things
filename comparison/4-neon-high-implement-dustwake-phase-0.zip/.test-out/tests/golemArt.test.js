"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.legacyPoses = legacyPoses;
exports.golemTrace = golemTrace;
// Golem sprite regression: draws the golem (albedo and emissive passes, as the
// host does) through the recording fake canvas for a matrix of poses and
// compares the draw-call trace hash with goldens.
//  - LEGACY: every pose that existed before gear and the slam (facings x arm x
//    gait phases x raise x reach x boot-up/eye states). Captured from golem.ts
//    before either change; it must never move.
//  - New states have their own goldens (gear on the back, the two-arm slam).
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const golem_1 = require("../src/game/golem");
const tasks_1 = require("../src/game/content/tasks");
const util_1 = require("../src/game/util");
const FACINGS = ["down", "up", "left", "right"];
/** The legacy pose matrix, with optional extra pose fields applied to every entry. */
function legacyPoses(extra = {}) {
    const out = [];
    for (const facing of FACINGS)
        for (const hasArm of [false, true]) {
            const base = { facing, phase: 0, moving: false, hasArm, dormant: 0, eye: 1, core: 1, raise: 0, reach: 0, t: 0.3, eyeFixed: false, ...extra };
            out.push(base);
            for (const phase of [0.4, 1.3, 2.2, 3.6, 5.0])
                out.push({ ...base, phase, moving: true });
            for (const raise of [-1, -0.5, 0.5, 1])
                out.push({ ...base, raise });
            for (const reach of [0.5, 1])
                out.push({ ...base, reach });
            out.push({ ...base, dormant: 1, eye: 0, core: 0 }, { ...base, dormant: 0.5, eye: 0.4, core: 0.6 }, { ...base, eyeFixed: true, t: 1.7 }, { ...base, eye: 1.6 });
        }
    return out;
}
function golemTrace(list) {
    (0, fakeCanvas_1.resetTrace)();
    const c = (0, util_1.makeCanvas)(48, 48);
    for (const p of list) {
        (0, golem_1.drawGolem)(new util_1.Pen(c.ctx, false), 24, 40, p);
        (0, golem_1.drawGolem)(new util_1.Pen(c.ctx, true), 24, 40, p);
    }
    return (0, fakeCanvas_1.traceHash)();
}
const GOLDEN = { legacy: "44dd8ba5", basket: "ed623359", slam: "a263db97" };
const BASE = { facing: "down", phase: 0, moving: false, hasArm: false, dormant: 0, eye: 1, core: 1, raise: 0, reach: 0, t: 0.3, eyeFixed: false };
(0, node_test_1.test)("legacy golem poses are pixel-identical", () => {
    strict_1.default.equal(golemTrace(legacyPoses()), GOLDEN.legacy);
    strict_1.default.equal(golemTrace(legacyPoses({ back: undefined })), GOLDEN.legacy, "an empty back slot draws nothing extra");
});
(0, node_test_1.test)("the basket on the back: every facing, walking, slumped, with and without the arm", () => {
    const withBasket = legacyPoses({ back: "basket" });
    strict_1.default.equal(golemTrace(withBasket), GOLDEN.basket);
    // It changes every facing (it is visible from all four), and it rides the body bob.
    for (const facing of FACINGS) {
        const at = (p) => golemTrace([{ ...withBasket[0], facing, ...p }]);
        strict_1.default.notEqual(at({}), at({ back: undefined }), `${facing}: basket visible`);
        strict_1.default.notEqual(at({ dormant: 1 }), at({ dormant: 0 }), `${facing}: moves with the body`);
    }
});
(0, node_test_1.test)("the two-arm slam: both arms (or the arm and the broken stub) through the arc, in every facing, with gear", () => {
    const list = [];
    for (const facing of FACINGS)
        for (const hasArm of [false, true])
            for (const back of [undefined, "basket"])
                for (const k of [0.1, 0.3, 0.42, 0.47, 0.5, 0.6, 0.8, 0.95]) {
                    const { lift, dip } = (0, golem_1.slamPose)(k);
                    list.push({ ...BASE, facing, hasArm, back, slam: lift, dip });
                }
    strict_1.default.equal(golemTrace(list), GOLDEN.slam);
    for (const facing of FACINGS)
        for (const hasArm of [false, true]) {
            const at = (p) => golemTrace([{ ...BASE, facing, hasArm, ...p }]);
            strict_1.default.notEqual(at({ slam: 1 }), at({ slam: -1 }), `${facing}: overhead vs in the ground`);
            strict_1.default.notEqual(at({ slam: 1 }), at({}), `${facing}: raised is not the rest pose`);
        }
    // The impact frame is the fire point: the fists reach the ground exactly when the effect lands.
    strict_1.default.deepEqual((0, golem_1.slamPose)(tasks_1.SLAM_HIT), { lift: -1, dip: 2 });
    strict_1.default.ok((0, golem_1.slamPose)(tasks_1.SLAM_HIT - 0.005).lift > -1, "still swinging just before");
    strict_1.default.deepEqual((0, golem_1.slamPose)(0), { lift: 0, dip: 0 });
    strict_1.default.deepEqual((0, golem_1.slamPose)(1), { lift: 0, dip: 0 });
});
