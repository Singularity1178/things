"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Dialogue text layout: the word wrapper, pagination, how authored pages map
// onto box screens (beats on the right screen), the box's real capacity, and a
// rendered check that the guardian's text stays inside the box and uses its width.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const textWrap_1 = require("../src/game/ui/textWrap");
const dialogueLayout_1 = require("../src/game/ui/dialogueLayout");
const font_1 = require("../src/game/font");
const world_1 = require("../src/game/world/world");
const flags_1 = require("../src/game/content/flags");
const uiSnapshot_1 = require("./support/uiSnapshot");
// ------------------------------------------------------------------ wrapper
(0, node_test_1.test)("wrap: greedy fill up to the width, breaking only at spaces", () => {
    strict_1.default.deepEqual((0, textWrap_1.wrapText)("AAA BBB CCC DDD", 7), ["AAA BBB", "CCC DDD"]);
    strict_1.default.deepEqual((0, textWrap_1.wrapText)("AAA BBB CCC", 11), ["AAA BBB CCC"]);
    strict_1.default.deepEqual((0, textWrap_1.wrapText)("A B C D E F", 3), ["A B", "C D", "E F"]);
});
(0, node_test_1.test)("wrap: exact-fit lines stay on one line; one more character moves the word down", () => {
    strict_1.default.deepEqual((0, textWrap_1.wrapText)("ABCD EFGH", 9), ["ABCD EFGH"]);
    strict_1.default.deepEqual((0, textWrap_1.wrapText)("ABCD EFGHI", 9), ["ABCD", "EFGHI"]);
    strict_1.default.deepEqual((0, textWrap_1.wrapText)("ABCDEFGHI", 9), ["ABCDEFGHI"]);
    const full = "X".repeat(dialogueLayout_1.DIALOGUE_COLS);
    strict_1.default.deepEqual((0, textWrap_1.wrapText)(full, dialogueLayout_1.DIALOGUE_COLS), [full]);
    strict_1.default.deepEqual((0, textWrap_1.wrapText)(full + " Y", dialogueLayout_1.DIALOGUE_COLS), [full, "Y"]);
});
(0, node_test_1.test)("wrap: a word longer than a line is broken across lines", () => {
    strict_1.default.deepEqual((0, textWrap_1.wrapText)("ABCDEFGHIJ", 4), ["ABCD", "EFGH", "IJ"]);
    strict_1.default.deepEqual((0, textWrap_1.wrapText)("HI ABCDEFGHIJ YO", 4), ["HI", "ABCD", "EFGH", "IJ", "YO"]);
    strict_1.default.deepEqual((0, textWrap_1.wrapText)("ABCDEFGH", 4), ["ABCD", "EFGH"]);
    for (const l of (0, textWrap_1.wrapText)("A ".repeat(30) + "Z".repeat(200), 13))
        strict_1.default.ok(l.length <= 13);
});
(0, node_test_1.test)("wrap: spaces collapse, \\n forces a break, empty paragraphs keep an empty line", () => {
    strict_1.default.deepEqual((0, textWrap_1.wrapText)("  AA   BB  ", 10), ["AA BB"]);
    strict_1.default.deepEqual((0, textWrap_1.wrapText)("AA\nBB", 10), ["AA", "BB"]);
    strict_1.default.deepEqual((0, textWrap_1.wrapText)("AA\n\nBB", 10), ["AA", "", "BB"]);
    strict_1.default.deepEqual((0, textWrap_1.wrapText)("", 10), [""]);
    strict_1.default.throws(() => (0, textWrap_1.wrapText)("A", 0));
});
// ------------------------------------------------------------------ pagination
(0, node_test_1.test)("paginate: chunks of the line capacity, exact fit is one page", () => {
    strict_1.default.deepEqual((0, textWrap_1.paginate)(["1", "2", "3", "4"], 4), [["1", "2", "3", "4"]]);
    strict_1.default.deepEqual((0, textWrap_1.paginate)(["1", "2", "3", "4", "5"], 4), [["1", "2", "3", "4"], ["5"]]);
    strict_1.default.deepEqual((0, textWrap_1.paginate)([], 4), [[]]);
    strict_1.default.throws(() => (0, textWrap_1.paginate)(["1"], 0));
});
(0, node_test_1.test)("layout: a long page spills over screens; beat on its first screen, then on its last", () => {
    const long = Array.from({ length: 9 }, (_, i) => "W" + i).join(" "); // 9 words of 2 chars
    const s = (0, dialogueLayout_1.layoutDialogue)([
        { text: "HELLO.", beat: "pause" },
        { text: long, beat: "wake", then: "goDormant", speaker: "ECHO" },
        { text: "BYE.", then: "goDormant" },
    ], 4, 2); // 4 cols: one 2-char word per line ("W0 W1" is 5); 2 lines per screen
    strict_1.default.deepEqual(s.map((p) => p.lines), [["HELL", "O."], ["W0", "W1"], ["W2", "W3"], ["W4", "W5"], ["W6", "W7"], ["W8"], ["BYE."]]);
    strict_1.default.deepEqual(s.map((p) => p.source), [0, 1, 1, 1, 1, 1, 2]);
    strict_1.default.deepEqual(s.map((p) => p.beat ?? "-"), ["pause", "wake", "-", "-", "-", "-", "-"]);
    strict_1.default.deepEqual(s.map((p) => p.then ?? "-"), ["-", "-", "-", "-", "-", "goDormant", "goDormant"]);
    strict_1.default.ok(s.slice(1, 6).every((p) => p.speaker === "ECHO") && !s[0].speaker);
    // a page that fits keeps both beats on its single screen
    const one = (0, dialogueLayout_1.layoutDialogue)([{ text: "SHORT.", beat: "wake", then: "goDormant" }]);
    strict_1.default.equal(one.length, 1);
    strict_1.default.deepEqual([one[0].beat, one[0].then], ["wake", "goDormant"]);
});
// ------------------------------------------------------------------ the real box
(0, node_test_1.test)("box capacity is derived from its geometry: 68 characters x 4 lines", () => {
    const B = dialogueLayout_1.DIALOGUE_BOX, inner = B.w - 2 * B.padX;
    strict_1.default.equal(dialogueLayout_1.DIALOGUE_COLS, 68);
    strict_1.default.equal(dialogueLayout_1.DIALOGUE_LINES, 4);
    // a full line plus its 1 px shadow fits the inset text area; one more character doesn't
    strict_1.default.ok((0, font_1.textWidth)("X".repeat(dialogueLayout_1.DIALOGUE_COLS)) + 1 <= inner);
    strict_1.default.ok((0, font_1.textWidth)("X".repeat(dialogueLayout_1.DIALOGUE_COLS + 1)) + 1 > inner);
    // the last line (5 px glyph + shadow) clears the footer row; one more line wouldn't
    const bottom = (n) => B.textY + (n - 1) * B.lineH + 5;
    strict_1.default.ok(bottom(dialogueLayout_1.DIALOGUE_LINES) < B.footerY - 1);
    strict_1.default.ok(bottom(dialogueLayout_1.DIALOGUE_LINES + 1) >= B.footerY);
});
(0, node_test_1.test)("rendered: every guardian screen stays inside the box, and long pages use its width", () => {
    globalThis.document = { createElement: () => new uiSnapshot_1.RCanvas() };
    const w = (0, world_1.createWorld)(7);
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm); // the optional arm page too
    const B = dialogueLayout_1.DIALOGUE_BOX, x0 = B.x + B.padX, x1 = B.x + B.w - B.padX, y0 = B.y + B.textY, y1 = B.y + B.footerY - 1;
    let screens = 0, widest = 0;
    (0, uiSnapshot_1.renderDialogueScreens)(w, "npc.guardian", "guardian", (name, c) => {
        screens++;
        for (let y = 0; y < c.height; y++)
            for (let x = 0; x < c.width; x++) {
                const i = (y * c.width + x) * 4;
                if (c.data[i] !== 0xe8 || c.data[i + 1] !== 0xdc || c.data[i + 2] !== 0xc0)
                    continue; // body text colour
                // the pixel and its shadow (+1, +1) are inside the text area, above the footer
                strict_1.default.ok(x >= x0 && x + 1 < x1 && y >= y0 && y + 1 < y1, `${name}: text pixel at ${x},${y} outside ${x0}..${x1} x ${y0}..${y1}`);
                widest = Math.max(widest, x);
            }
    });
    strict_1.default.ok(screens >= 20, `rendered ${screens} screens`);
    // the old hand-broken lines never passed x0 + 26 chars; wrapped text reaches the right margin
    strict_1.default.ok(widest > x1 - 16, `widest text pixel at ${widest}, right margin ${x1}`);
});
