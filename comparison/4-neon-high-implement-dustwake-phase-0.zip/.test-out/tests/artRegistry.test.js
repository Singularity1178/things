"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Procedural art regression for EVERYTHING the art modules draw, captured
// before art.ts was split into src/game/art/* (tests/art.test.ts only covers
// the pre-registry legacy sprites and the dungeon bake). Every PROP_ART kind
// (4 variants x alt), every ITEM_ART icon, the tile-standing sprites, glyph
// patterns and the full surface bake go through the recording fake canvas and
// are compared with golden draw-call trace hashes.
//
// Its own file on purpose: node --test runs each file in a fresh process, so
// the shared sprite cache starts empty and the traces don't depend on which
// other tests ran first. Keep the order of the tests below.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const props_1 = require("../src/game/art/props");
const propsTown_1 = require("../src/game/art/propsTown");
const propsFolk_1 = require("../src/game/art/propsFolk");
const items_1 = require("../src/game/art/items");
const tiles_1 = require("../src/game/art/tiles");
const glyphs_1 = require("../src/game/content/glyphs");
const surface_1 = require("../src/game/surface");
const util_1 = require("../src/game/util");
// items: updated deliberately for the crown's retexture (its main stone is the High-Grade Ruby now); with the old
// crown swapped back in the list still hashes to the previous "6253c0e8", so no other legacy icon moved.
// props and tiles: updated deliberately for the dungeon audit (docs/ARCHITECTURE.md: "The dungeon audit").
// Compared pixel for pixel with the art as it was: of the prop sprites only `bed` and `brazier` differ
// (props was "e4c643ed"), and of the tile sprites only the cracked wall, redrawn as a stretch of the wall it
// stands in (tiles was "5eb324bb"); rubble, both pillars, the door and the bars are untouched.
// The entrance update (v14): props (was "9ff9b39a"): `buriedgate`, `forge`, `anvil`, `weaponrack` and
// `armorstand` were redrawn and eleven kinds added (ironore, toolboard, runetable, clayvat, husk, staffrack,
// wallhooks, armorpile, stairfoot, stairfall, stairlight); the 123 other sprites hash as before. surface (was
// "c332aec8"): only tiles inside 46-50,56-62 differ, where the round hollow and hump over the buried stair
// were taken out (compared pixel by pixel against the bake as it was).
// The rock and stair retexture (docs/ARCHITECTURE.md: "Rocks and the stair, redrawn"): props (was "b2f6aee3"):
// compared sprite by sprite with the tree as it was (trace hash per kind, six variants, both states), exactly six
// kinds differ, all redrawn on purpose: `rock`, `ironore`, `boulder` and `outcrop` (cut stone instead of two
// ellipses, art/rocks.ts), `stairfoot` (the flight's own steps) and `buriedgate` (the fall as boulders at dig
// stage 3; stages 4 and 5, the breach and the open stair, are variants this list does not reach and are pinned
// in tests/rockArt.test.ts). The 135 other sprites hash as before, and no kind was added or removed. surface:
// unmoved, as it must be: the bake holds no props, and no tile of the surface changed (0 of 6912 differ).
// The stair below, with depth (docs/ARCHITECTURE.md): props (was "a5f81c69"): compared sprite by sprite with the tree
// as it was (pixel hash per kind, six variants, both states), no sprite that was there changed; `stairfoot` was
// removed and `stairpost` and `staircheek` added, which is all that moved this hash. surface: unmoved (0 of 6912
// tiles differ).
const GOLDEN = { props: "694d07cd", items: "94b2678e", tiles: "c9958a0", glyphs: "25b715f1", surface: "6b2c4609" };
(0, node_test_1.test)("every PROP_ART sprite is pixel-identical", () => {
    (0, fakeCanvas_1.resetTrace)();
    // The surface's and the dungeon's sprites, in registry order. The market town's kinds were added after them
    // (art/propsTown.ts, checked in tests/town.test.ts) and are left out here, so this golden never has to move.
    for (const k of Object.keys(props_1.PROP_ART)) {
        if (k in propsTown_1.TOWN_PROP_ART || k in propsFolk_1.FOLK_PROP_ART)
            continue;
        for (let v = 0; v < 4; v++)
            for (const alt of [false, true])
                (0, props_1.propSprite)(k, v, alt);
    }
    strict_1.default.equal((0, fakeCanvas_1.traceHash)(), GOLDEN.props);
});
// The icons that existed before crafted materials, runes and slot silhouettes, in their original registry order.
// Items added since have their own golden below (tests/gearArt.test.ts); this one must never move.
const LEGACY_ITEMS = ["chisel", "arm", "key", "core", "schematic", "crown", "goblet", "coin", "glyph0", "glyph1", "glyph2", "glyph3", "wood", "stone", "book_build", "book_repair", "basket"];
(0, node_test_1.test)("every ITEM_ART icon is pixel-identical", () => {
    (0, fakeCanvas_1.resetTrace)();
    for (const id of LEGACY_ITEMS)
        (0, items_1.itemIcon)(id);
    strict_1.default.equal((0, fakeCanvas_1.traceHash)(), GOLDEN.items);
    strict_1.default.ok(LEGACY_ITEMS.every((id) => id in items_1.ITEM_ART));
});
(0, node_test_1.test)("tile sprites (rubble, cracked wall, pillars, door, bars) are pixel-identical", () => {
    (0, fakeCanvas_1.resetTrace)();
    for (let v = 0; v < 3; v++)
        for (const cracked of [false, true])
            (0, tiles_1.rubbleSprite)(v, cracked);
    (0, tiles_1.pillarSprite)(false);
    (0, tiles_1.pillarSprite)(true);
    (0, tiles_1.doorSprite)();
    (0, tiles_1.barsSprite)();
    strict_1.default.equal((0, fakeCanvas_1.traceHash)(), GOLDEN.tiles);
});
(0, node_test_1.test)("glyph patterns (lit and unlit) are pixel-identical", () => {
    (0, fakeCanvas_1.resetTrace)();
    const c = (0, util_1.makeCanvas)(16, 16);
    for (const glow of [false, true]) {
        const p = new util_1.Pen(c.ctx, glow);
        glyphs_1.GLYPHS.forEach((g, i) => (0, items_1.glyphPattern)(p, i, 1, 1, g.color, glow));
    }
    strict_1.default.equal((0, fakeCanvas_1.traceHash)(), GOLDEN.glyphs);
});
(0, node_test_1.test)("surface background bake is pixel-identical", () => {
    (0, fakeCanvas_1.resetTrace)();
    // The wild as it was before the town: the old road west (cut last in the builder, with no rng) is left out, so
    // this golden proves that adding the road and the town's tile styles moved no pixel of the existing surface.
    const s = (0, surface_1.buildSurface)({ westRoad: false });
    const c = (0, util_1.makeCanvas)(s.w * 16, s.h * 16);
    (0, tiles_1.bakeRegion)(c.ctx, s, 0, 0, s.w - 1, s.h - 1);
    strict_1.default.equal((0, fakeCanvas_1.traceHash)(), GOLDEN.surface);
});
