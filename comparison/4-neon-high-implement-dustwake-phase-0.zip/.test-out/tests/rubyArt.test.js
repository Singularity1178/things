"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Art added with the production rollout. Own file: node --test runs each file
// in a fresh process, so the sprite cache starts empty and the traces don't
// depend on other tests. The High-Grade Ruby, the Ruby Golem Core and the
// worker golem body are new art (they had no goldens before); among the
// existing goldens only the crown's moved (tests/art.test.ts,
// tests/artRegistry.test.ts). The golem's and the guardian's are untouched.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const items_1 = require("../src/game/art/items");
const workerArt_1 = require("../src/game/workerArt");
const actors_1 = require("../src/game/view/actors");
const uiSnapshot_1 = require("./support/uiSnapshot");
const util_1 = require("../src/game/util");
const world_1 = require("../src/game/world/world");
const map_1 = require("../src/game/map");
const actorStats_1 = require("../src/game/sim/actorStats");
const GOLDEN = { icons: "24c7cf22", worker: "fb2f6126" };
const FACINGS = ["down", "left", "up", "right"];
const STATES = ["off", "idle", "work"];
const pose = (state, facing, extra = {}) => (0, workerArt_1.workerPose)(state, { facing, phase: extra.phase ?? 0, moving: !!extra.moving, t: 0.3, hasCore: state !== "off", swing: extra.swing, reach: extra.reach, boot: extra.boot });
/** Rasterise one pass of one pose at feet (16, 26) on a 32x32 canvas; returns its RGBA pixels. */
function raster(p, emit) {
    const c = new uiSnapshot_1.RCanvas(32, 32), ctx = c.getContext();
    (0, workerArt_1.drawWorker)(new util_1.Pen(ctx, emit), 16, 26, p);
    return c.data;
}
const glow = (d) => {
    const out = [];
    for (let i = 0; i < d.length; i += 4)
        if (d[i + 3] > 0 && d[i] + d[i + 1] + d[i + 2] > 0)
            out.push({ i: i / 4, r: d[i], g: d[i + 1], b: d[i + 2] });
    return out;
};
(0, node_test_1.test)("new icons: the High-Grade Ruby and the Ruby Golem Core are pixel-stable", () => {
    (0, fakeCanvas_1.resetTrace)();
    for (const id of ["large_ruby", "ruby_core"])
        (0, items_1.itemIcon)(id);
    strict_1.default.equal((0, fakeCanvas_1.traceHash)(), GOLDEN.icons);
});
(0, node_test_1.test)("the worker body: three states in every facing, walking, swinging and reaching, both passes, pixel-stable", () => {
    strict_1.default.equal(workerArt_1.BODY_ART.worker, workerArt_1.drawWorker);
    (0, fakeCanvas_1.resetTrace)();
    const c = (0, util_1.makeCanvas)(32, 32);
    const all = [...STATES.flatMap((s) => FACINGS.map((f) => pose(s, f))), ...FACINGS.flatMap((f) => [pose("work", f, { moving: true, phase: 1.3 }), pose("work", f, { moving: true, phase: 4.4 }), pose("work", f, { swing: 1 }), pose("work", f, { swing: -1 }), pose("work", f, { reach: 1 }), pose("idle", f, { boot: 1 })])];
    for (const p of all) {
        (0, workerArt_1.drawWorker)(new util_1.Pen(c.ctx, false), 16, 26, p);
        (0, workerArt_1.drawWorker)(new util_1.Pen(c.ctx, true), 16, 26, p);
    }
    strict_1.default.equal((0, fakeCanvas_1.traceHash)(), GOLDEN.worker);
});
(0, node_test_1.test)("glow by state: unpowered emits nothing; powered-idle only a faint core; working a bright core and a lit eye", () => {
    for (const f of FACINGS) {
        strict_1.default.deepEqual(glow(raster(pose("off", f), true)), [], `${f}: switched off, no glow at all`);
        const idle = glow(raster(pose("idle", f), true)), work = glow(raster(pose("work", f), true));
        strict_1.default.ok(idle.length > 0, `${f}: the core shows`);
        const amber = (px) => px.g > px.b * 1.8 && px.g > 60;
        strict_1.default.ok(!idle.some(amber), `${f}: idle, the eye stays shuttered`);
        const peak = (l) => Math.max(...l.map((px) => Math.max(px.r, px.g, px.b)));
        // from behind the core shows only through the grille (60%), so there "bright" means well above idle
        strict_1.default.ok(peak(idle) <= 0.45 * 255 && peak(work) >= (f === "up" ? 2 * peak(idle) : 0.9 * 255), `${f}: idle faint (${peak(idle)}), working bright (${peak(work)})`);
        if (f !== "up")
            strict_1.default.ok(work.some(amber), `${f}: working, the lamp-eye is lit`);
    }
    strict_1.default.ok(workerArt_1.WORKER_CORE.idle < workerArt_1.WORKER_CORE.work / 2 && workerArt_1.WORKER_CORE.off === 0);
    strict_1.default.ok(pose("idle", "down", { boot: 1 }).core > pose("idle", "down").core, "a core flares as it boots, then settles");
});
(0, node_test_1.test)("powered-idle keeps the dormant posture: against unpowered, only the core's pixels change (window, or vent slats from behind)", () => {
    for (const f of FACINGS) {
        const a = raster(pose("off", f), false), b = raster(pose("idle", f), false), diff = [];
        for (let i = 0; i < a.length; i += 4)
            if (a[i] !== b[i] || a[i + 1] !== b[i + 1] || a[i + 2] !== b[i + 2] || a[i + 3] !== b[i + 3])
                diff.push(i / 4);
        strict_1.default.ok(diff.length > 0 && diff.length <= 6, `${f}: ${diff.length} pixels differ`);
        // crouched: the torso top is 26 - 2 - 8 = 16; the hatch window and the vent slats sit 3..5 rows below it
        for (const i of diff)
            strict_1.default.ok(Math.floor(i / 32) >= 16 + 3 && Math.floor(i / 32) <= 16 + 5, `${f}: a change outside the core (${i % 32},${Math.floor(i / 32)})`);
        const work = raster(pose("work", f), false);
        strict_1.default.notDeepEqual([...work], [...b], `${f}: working stands differently`);
    }
});
(0, node_test_1.test)("through drawActor (and so golem vision's per-frame retrace into its scratch canvas) the worker draws in every state", () => {
    const w = (0, world_1.createWorld)(3), wk = (0, world_1.actorById)(w, map_1.ARTIFICERY_WORKER.id);
    const states = [];
    for (const setup of [() => { }, () => { wk.powerCore = "ruby_core"; }, () => { wk.task = { kind: "punch", dur: 0.75, t: 0.2, fired: false }; }]) {
        setup();
        states.push((0, workerArt_1.workerState)((0, actorStats_1.powered)(wk), (0, actors_1.actorActive)(wk)));
        const look = { awake: 0, eye: 0, flare: 0, reach: 0 }; // a fresh look per state: the sequencer starts at rest in what the sim says
        const sc = new uiSnapshot_1.RCanvas(56, 64), ec = new uiSnapshot_1.RCanvas(56, 64); // view/vision.ts: ACTOR_BOX, feet at (28, 58)
        (0, actors_1.drawActor)(sc.getContext(), ec.getContext(), w, wk, Math.round(wk.x) - 28, Math.round(wk.y) - 58, 0.3, look);
        let opaque = 0;
        for (let i = 3; i < sc.data.length; i += 4)
            if (sc.data[i] > 0)
                opaque++;
        strict_1.default.ok(opaque > 100, `${states[states.length - 1]}: drawn into the scratch canvas`);
        strict_1.default.equal(glow(ec.data).length > 0, (0, actorStats_1.powered)(wk), "glows only when powered");
    }
    strict_1.default.deepEqual(states, ["off", "idle", "work"]);
});
