"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The real host (Game, on the fake canvas, driven by key presses) with the
// storage and management screens: E opens the right screen from the play
// screen, the keys do what the screens say, the core swap hands the golem its
// reach and brings the screen back, and a worker's events (or a player event
// from the wrong screen) can never open or replace the player's screens.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const g0 = globalThis;
g0.localStorage ?? (g0.localStorage = { getItem: () => null, setItem: () => { }, removeItem: () => { } });
const game_1 = require("../src/game/game");
const jobs_1 = require("../src/game/sim/jobs");
const power_1 = require("../src/game/sim/power");
const actorStats_1 = require("../src/game/sim/actorStats");
const inventoryOps_1 = require("../src/game/sim/inventoryOps");
const vision_1 = require("../src/game/content/vision");
const workerFixture_1 = require("./support/workerFixture");
const canvas = () => globalThis.document.createElement("canvas");
const tick = (g, n = 1, dt = 1 / 60) => { for (let i = 0; i < n; i++)
    g.update(dt); };
const press = (g, key) => { g.keyDown(key); tick(g); g.keyUp(key); };
function host() {
    const f = (0, workerFixture_1.fixture)(), g = new game_1.Game(canvas(), canvas());
    g.resume(f.w);
    return { ...f, g };
}
(0, node_test_1.test)("E on the chest opens the storage screen, E on the worker the management screen; each closes with Esc", () => {
    const { g, w, pl, worker: wk } = host();
    (0, workerFixture_1.besideChest)(w);
    tick(g);
    press(g, "e");
    tick(g, 30);
    strict_1.default.ok(g.screens.is("storage"), "the chest");
    press(g, "escape");
    strict_1.default.ok(g.screens.is("play"));
    tick(g, 30); // the golem's reach finishes under the play screen
    (0, workerFixture_1.beside)(w, wk);
    tick(g);
    press(g, "e");
    tick(g, 30);
    strict_1.default.ok(g.screens.is("manage"), "the worker");
    press(g, "tab");
    strict_1.default.ok(g.screens.is("play"));
    tick(g, 30);
    strict_1.default.equal(pl.task, null);
    strict_1.default.ok(vision_1.VISION_OFF_OPS.includes("manageActor") && vision_1.VISION_OFF_OPS.includes("useStorage"), "both still turn the scan off");
});
(0, node_test_1.test)("storage through the keys: the cursor, E and Q, crossing panes, the host's note, and the saved result", () => {
    const { g, w, pl } = host();
    (0, workerFixture_1.besideChest)(w);
    tick(g);
    press(g, "e");
    tick(g, 30);
    press(g, "e");
    strict_1.default.equal(g.note?.text, "TOO IMPORTANT TO STORE", "the chisel stays");
    press(g, "d");
    press(g, "d");
    press(g, "e");
    strict_1.default.equal((0, workerFixture_1.chestCount)(w, "planks"), 8);
    strict_1.default.equal(g.note?.text, "STORED 8 PLANKS");
    press(g, "d");
    press(g, "d");
    strict_1.default.equal(g.storageUi.pane, "chest");
    press(g, "q");
    strict_1.default.equal((0, inventoryOps_1.countItem)(pl, "planks"), 1);
    strict_1.default.equal(g.note?.text, "TOOK 1 PLANKS");
    press(g, "i");
    strict_1.default.ok(g.screens.is("play"));
    g.render(); // draws the world, nothing throws
    tick(g, 30);
    press(g, "i");
    strict_1.default.ok(g.screens.is("inv"), "the pack still opens normally");
    press(g, "escape");
});
(0, node_test_1.test)("management through the keys: a gather order from the form, then the worker gets on with it under the play screen", () => {
    const { g, w, worker: wk } = host();
    (0, workerFixture_1.beside)(w, wk);
    tick(g);
    press(g, "e");
    tick(g, 30);
    strict_1.default.ok(g.screens.is("manage"));
    for (const k of ["s", "e", "s", "s", "s", "d", "s", "e"])
        press(g, k); // GATHER, to AMOUNT (6), ISSUE
    strict_1.default.equal(g.note?.text, "ORDER GIVEN");
    strict_1.default.deepEqual(wk.job && [wk.job.kind, wk.job.args.resource, wk.job.args.amount], ["gatherDeposit", "wood", 6]);
    const twin = (0, workerFixture_1.fixture)();
    strict_1.default.ok((0, jobs_1.setWorkerOrder)(twin.w, twin.pl, twin.worker.id, (0, jobs_1.gatherOrder)("wood", "debug_yard", { ...workerFixture_1.CHEST }, 6)));
    strict_1.default.deepEqual(wk.job, twin.worker.job, "the order the builder makes");
    press(g, "escape");
    strict_1.default.ok(g.screens.is("play"));
    for (let i = 0; i < 6000 && wk.job?.status !== "done"; i++)
        g.update(0.05);
    strict_1.default.equal(wk.job?.status, "done");
    strict_1.default.equal((0, workerFixture_1.chestCount)(w, "wood"), 6);
    strict_1.default.ok(g.screens.is("play"), "the worker working never opened or closed a screen");
});
(0, node_test_1.test)("the core row hands the golem its reach, the world runs, and the screen comes back with the worker powered", () => {
    const { g, w, pl, worker: wk } = host();
    (0, power_1.removePowerCore)(w, pl, wk);
    w.events = [];
    (0, workerFixture_1.beside)(w, wk);
    tick(g);
    press(g, "e");
    tick(g, 30);
    strict_1.default.ok(g.screens.is("manage") && !(0, actorStats_1.powered)(wk));
    press(g, "e"); // SLOT IN RUBY GOLEM CORE
    strict_1.default.ok(g.screens.is("play") && g.manageUi.pending, "the screen steps aside while the golem works");
    tick(g, 30);
    strict_1.default.ok(g.screens.is("play"), "still reaching");
    tick(g, 60);
    strict_1.default.ok((0, actorStats_1.powered)(wk));
    strict_1.default.equal(g.note?.text, "RUBY GOLEM CORE SLOTTED - IT POWERS ON");
    strict_1.default.ok(g.screens.is("manage") && !g.manageUi.pending, "and back");
    press(g, "e");
    tick(g, 90); // TAKE OUT
    strict_1.default.ok(!(0, actorStats_1.powered)(wk));
    strict_1.default.equal((0, inventoryOps_1.countItem)(pl, "ruby_core"), 1);
    strict_1.default.ok(g.screens.is("manage"));
    // the same through C inside the screen
    press(g, "c");
    tick(g, 90);
    strict_1.default.ok((0, actorStats_1.powered)(wk) && g.screens.is("manage"));
    press(g, "escape");
    strict_1.default.ok(g.screens.is("play"));
});
(0, node_test_1.test)("a worker's events cannot open, replace or close the player's screens; neither can the player's from the wrong screen", () => {
    const { g, w, pl, worker: wk } = host();
    const forged = (actor) => [
        { t: "openStorage", actor, prop: workerFixture_1.CHEST.prop }, { t: "manageActor", actor, target: wk.id },
        { t: "jobChanged", actor, status: "blocked", reason: "storageFull" },
        { t: "coreSlotted", actor, target: wk.id, item: "ruby_core", inserted: false, powered: false },
        { t: "message", text: "FORGED", actor }, { t: "itemGained", actor, item: "wood", n: 1, stored: true },
    ];
    w.events.push(...forged(wk.id));
    tick(g, 2);
    strict_1.default.ok(g.screens.is("play"), "play stays play");
    strict_1.default.notEqual(g.note?.text, "FORGED");
    // the player's own event, but from a screen that is not play
    press(g, "i");
    strict_1.default.ok(g.screens.is("inv"));
    w.events.push(...forged(pl.id).slice(0, 2));
    tick(g, 2);
    strict_1.default.ok(g.screens.is("inv"), "the pack is not replaced");
    press(g, "escape");
    // and with the storage screen open, a worker's events leave it alone
    (0, workerFixture_1.besideChest)(w);
    tick(g);
    press(g, "e");
    tick(g, 30);
    strict_1.default.ok(g.screens.is("storage"));
    w.events.push(...forged(wk.id));
    tick(g, 2);
    strict_1.default.ok(g.screens.is("storage") && g.storageUi.propId === workerFixture_1.CHEST.prop);
    press(g, "escape");
    // while the worker is mid-order in another area, the player's screens are theirs alone
    (0, workerFixture_1.beside)(w, wk);
    tick(g);
    press(g, "e");
    tick(g, 30);
    strict_1.default.ok(g.screens.is("manage"));
    w.events.push({ t: "openStorage", actor: wk.id, prop: workerFixture_1.CHEST.prop });
    tick(g, 2);
    strict_1.default.ok(g.screens.is("manage"));
    press(g, "escape");
    strict_1.default.equal((0, workerFixture_1.worker)(w), wk);
});
