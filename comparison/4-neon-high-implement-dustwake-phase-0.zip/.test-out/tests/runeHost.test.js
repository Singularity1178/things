"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The rune's refusal as the real host plays it (Game on the fake canvas, driven by keys), and the maths under it
// (view/runeFx.ts). The sim's side (when a rune will not carry, and that nothing is woken) is tests/routes.test.ts.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const g0 = globalThis;
g0.localStorage ?? (g0.localStorage = { getItem: () => null, setItem: () => { }, removeItem: () => { } });
const game_1 = require("../src/game/game");
const world_1 = require("../src/game/world/world");
const runes_1 = require("../src/game/content/runes");
const flags_1 = require("../src/game/content/flags");
const runeFx_1 = require("../src/game/view/runeFx");
const helpers_1 = require("./helpers");
const canvas = () => globalThis.document.createElement("canvas");
const tick = (g, n = 1, dt = 1 / 60) => { for (let i = 0; i < n; i++)
    g.update(dt); };
const tap = (g, key) => { g.keyDown(key); tick(g); g.keyUp(key); tick(g); };
(0, node_test_1.test)("the refusal's glow: a surge past full, an uneven guttering that weakens, and back to rest; the same every time", () => {
    const rest = (0, runeFx_1.severedGlow)(0), D = runeFx_1.RUNE_DUD;
    strict_1.default.equal((0, runeFx_1.runeDudGlow)(0, rest), rest);
    strict_1.default.equal((0, runeFx_1.runeDudGlow)(D.dur, rest), rest);
    strict_1.default.equal((0, runeFx_1.runeDudGlow)(99, rest), rest);
    strict_1.default.ok((0, runeFx_1.runeDudGlow)(D.surge * 0.999, rest) > 1.1, "overdriven at the top of the surge");
    const at = (i) => (0, runeFx_1.runeDudGlow)(D.surge + (i / 200) * (D.gutter - D.surge), rest);
    const gutter = Array.from({ length: 200 }, (_, i) => at(i));
    strict_1.default.ok(gutter.some((v) => v > 0.6) && gutter.some((v) => v < rest), "bright and dark by turns");
    strict_1.default.ok(Math.max(...gutter.slice(133)) < Math.max(...gutter.slice(0, 66)), "weaker toward the end");
    const tail = [0.25, 0.5, 0.75].map((k) => (0, runeFx_1.runeDudGlow)(D.gutter + k * (D.dur - D.gutter), rest));
    strict_1.default.ok(tail[0] > tail[1] && tail[1] > tail[2] && tail[2] >= rest, "dying back to rest");
    // the guttering is beats, as data: flashes inside it, each weaker than the last, each long enough to be seen at
    // 60 Hz, and the rune dark between them (drawn from noise it was dark for most of the guttering: rendered, it read
    // as one flash and nothing)
    const F = D.flashes;
    strict_1.default.ok(F.length >= 4);
    F.forEach(([start, len, level], i) => {
        strict_1.default.ok(start >= D.surge && start + len <= D.gutter && len >= 2 / 60, `flash ${i}: inside the guttering, two frames or more`);
        strict_1.default.ok(Math.abs((0, runeFx_1.runeDudGlow)(start + len / 2, rest) - level) < 1e-9, `flash ${i}: lit at its level`);
        if (!i)
            return;
        const prev = F[i - 1];
        strict_1.default.ok(level < prev[2], `flash ${i}: weaker than the last`);
        strict_1.default.ok(start > prev[0] + prev[1] && (0, runeFx_1.runeDudGlow)((prev[0] + prev[1] + start) / 2, rest) < rest, `dark before flash ${i}`);
    });
    strict_1.default.ok((0, runeFx_1.runeDudGlow)((D.surge + F[0][0]) / 2, rest) < rest, "dark after the surge, before the first flash");
    strict_1.default.deepEqual(gutter, Array.from({ length: 200 }, (_, i) => at(i)), "a function of time alone");
    // left alone: a linked rune pulses high, a severed one breathes low and never comes near it
    for (let t = 0; t < 12; t += 0.37)
        strict_1.default.ok((0, runeFx_1.severedGlow)(t) > 0.03 && (0, runeFx_1.severedGlow)(t) < 0.2 && (0, runeFx_1.linkedGlow)(t) > 0.3, `t ${t}`);
    // a dark rune only spits: half the flare, and nothing once it is over
    strict_1.default.ok((0, runeFx_1.runeDudGlow)(D.surge * 0.999, 0, 0.5) < 0.7 && (0, runeFx_1.runeDudGlow)(D.surge * 0.999, 0, 0.5) > 0.4);
    strict_1.default.equal((0, runeFx_1.runeDudGlow)(D.dur, 0, 0.5), 0);
});
(0, node_test_1.test)("the host: a severed surface rune burns low, and E on it plays the refusal: a surge, a guttering with sparks, then embers again, going nowhere", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), g = new game_1.Game(canvas(), canvas());
    const rp = (0, world_1.getArea)(w, "surface").prop(runes_1.RUNE_NODES.surface.prop);
    for (const f of [runes_1.RUNE_NODES.surface.flag, runes_1.RUNE_NODES.dungeon.flag, flags_1.FLAGS.tutorialDone])
        (0, world_1.setFlag)(w, f);
    (0, world_1.enterArea)(w, pl, "surface", rp.x, rp.y + 9);
    pl.facing = "up";
    g.resume(w);
    tick(g, 5);
    strict_1.default.ok(g.screens.is("play"));
    const light = g.view.byId("runeglow");
    strict_1.default.ok(g.surfaceRuneState().glow > 0.3 && light.cur > 0.2, "linked: the steady pulse, and its light");
    // the circle below goes dark: still carved (it was restored), but embers
    (0, world_1.clearFlag)(w, runes_1.RUNE_NODES.dungeon.flag);
    tick(g, 3);
    const rest = g.surfaceRuneState();
    strict_1.default.equal(rest.t, 1);
    strict_1.default.ok(rest.glow > 0 && rest.glow < 0.2, `embers (${rest.glow})`);
    strict_1.default.ok(light.cur < 0.15, "and its light all but gone");
    strict_1.default.equal(g.runeDud, null);
    // E: the golem reaches, the rune refuses
    tap(g, "e");
    const glows = [];
    let sparks = 0, lit = 0;
    for (let i = 0; i < 300 && (pl.task || g.runeDud || !glows.length); i++) {
        tick(g);
        if (!g.runeDud)
            continue;
        glows.push(g.surfaceRuneState().glow);
        sparks = Math.max(sparks, g.particles.filter((p) => p.kind === "spark").length);
        lit = Math.max(lit, light.cur);
        if (glows.length === 4)
            g.render(); // a frame of it, drawn
    }
    strict_1.default.ok(glows.length > 40, "the refusal played out over many frames");
    strict_1.default.equal(g.note?.text, "THE RUNE GUTTERS OUT. NOTHING ANSWERS ON THE OTHER SIDE");
    strict_1.default.ok(Math.max(...glows) > 1, "it surges past its full glow");
    strict_1.default.ok(glows.some((v) => v < 0.1) && glows.some((v) => v > 0.5), "and gutters, bright and dark by turns");
    // frame by frame, as the screen shows it: the rune comes back out of the dark again and again
    let flashes = 0;
    for (let i = 1; i < glows.length; i++)
        if (glows[i - 1] < 0.1 && glows[i] > 0.3)
            flashes++;
    strict_1.default.ok(flashes >= runeFx_1.RUNE_DUD.flashes.length, `it stutters: ${flashes} flashes out of the dark over ${glows.length} frames`);
    strict_1.default.ok(sparks >= 10, "throwing sparks");
    strict_1.default.ok(lit > 0.5, "its light flaring with it");
    strict_1.default.equal(g.runeDud, null);
    strict_1.default.ok(g.surfaceRuneState().glow < 0.2, "back to embers");
    strict_1.default.ok(g.screens.is("play") && pl.area === "surface" && !w.flags.has(runes_1.RUNE_NODES.dungeon.flag), "nobody went anywhere, and nothing below was woken");
    // lit again below, E carries as before
    (0, world_1.setFlag)(w, runes_1.RUNE_NODES.dungeon.flag);
    pl.x = rp.x;
    pl.y = rp.y + 9;
    pl.facing = "up";
    tap(g, "e");
    strict_1.default.ok(g.screens.is("tele"), "the jump's lift-off");
});
(0, node_test_1.test)("the host: a worker stepping through a door or off along a road is only heard; the player's view, fade and note are left alone", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), g = new game_1.Game(canvas(), canvas());
    const rp = (0, world_1.getArea)(w, "surface").prop(runes_1.RUNE_NODES.surface.prop);
    (0, world_1.enterArea)(w, pl, "surface", rp.x, rp.y + 9);
    g.resume(w);
    tick(g, 5);
    const before = { area: g.area.id, note: g.note, fade: g.doorFade, particles: g.particles.length };
    w.events.push({ t: "portal", actor: "npc.worker.artificery", fromArea: "surface", from: "west_road", toArea: "town", to: "east_road" });
    w.events.push({ t: "portal", actor: "npc.worker.artificery", fromArea: "dungeon", from: "stair_up", toArea: "surface", to: "stair_down" });
    g.drainEvents();
    strict_1.default.deepEqual({ area: g.area.id, note: g.note, fade: g.doorFade, particles: g.particles.length }, before);
    strict_1.default.ok(g.screens.is("play") && pl.area === "surface");
});
