"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Runes: the Rune of Swift's speed (through the sim) and the Rune of Glow's light
// (through the light system), both only while equipped, both data-driven; and
// carving them from cut stone end to end.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const world_1 = require("../src/game/world/world");
const inventory_1 = require("../src/game/sim/inventory");
const commands_1 = require("../src/game/sim/commands");
const crafting_1 = require("../src/game/sim/crafting");
const gear_1 = require("../src/game/sim/gear");
const gear_2 = require("../src/game/content/gear");
const items_1 = require("../src/game/content/items");
const flags_1 = require("../src/game/content/flags");
const font_1 = require("../src/game/font");
const light_1 = require("../src/game/light");
const tiles_1 = require("../src/game/content/tiles");
const helpers_1 = require("./helpers");
const give = (w, id) => (0, inventory_1.addItems)(w, (0, world_1.player)(w), id, 1);
const slotOf = (w, id) => (0, world_1.player)(w).inventory.findIndex((s) => s?.item === id);
const wear = (w, id) => strict_1.default.equal((0, commands_1.wearFromSlot)(w, (0, world_1.player)(w), slotOf(w, id)), "ok");
/** The golem in a cleared patch of the surface, walking right for `n` frames: how far it gets. */
function walk(runes, n = 90) {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    const pl = (0, world_1.player)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
    (0, world_1.enterArea)(w, pl, "surface", 10 * tiles_1.TS + 8, 50 * tiles_1.TS + 14);
    const a = (0, world_1.currentArea)(w);
    for (let ty = 46; ty <= 54; ty++)
        for (let tx = 4; tx <= 80; tx++)
            a.setTile(tx, ty, tiles_1.T.FLOOR);
    a.props = a.props.filter((p) => Math.abs(p.y - pl.y) > 90);
    for (const id of runes) {
        give(w, id);
        wear(w, id);
    }
    const x0 = pl.x;
    for (let i = 0; i < n; i++)
        (0, helpers_1.frame)(w, { ix: 1, iy: 0, use: false });
    return pl.x - x0;
}
(0, node_test_1.test)("Rune of Swift: +150% speed (2.5x) through the sim, only while worn, one tunable constant", () => {
    strict_1.default.equal(gear_2.RUNE_SWIFT_SPEED_BONUS, 1.5);
    strict_1.default.equal(items_1.ITEMS.rune_swift.worn.speed, gear_2.RUNE_SWIFT_SPEED_BONUS, "the item row reads the constant");
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    strict_1.default.equal((0, gear_1.speedMultiplier)(w, (0, world_1.player)(w)), 1);
    give(w, "rune_swift");
    strict_1.default.equal((0, gear_1.speedMultiplier)(w, (0, world_1.player)(w)), 1, "carried in the pack: nothing");
    wear(w, "rune_swift");
    strict_1.default.equal((0, gear_1.speedMultiplier)(w, (0, world_1.player)(w)), 2.5);
    strict_1.default.equal((0, commands_1.takeOffGear)(w, (0, world_1.player)(w), "rune0"), "ok");
    strict_1.default.equal((0, gear_1.speedMultiplier)(w, (0, world_1.player)(w)), 1, "taken off: the effect is gone");
    // movement itself: the same walk, with and without it
    const base = walk([]), fast = walk(["rune_swift"]);
    strict_1.default.ok(base > 20, "the golem actually walks");
    strict_1.default.ok(fast / base > 2.2 && fast / base < 2.8, `ratio ${(fast / base).toFixed(2)} is about 2.5x`);
});
(0, node_test_1.test)("Rune of Glow: a bright white light in a wider radius than the standard glow, only while worn, applied by the light system", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    const pl = (0, world_1.player)(w);
    strict_1.default.deepEqual((0, gear_1.golemGlow)(w, pl), gear_2.GOLEM_LIGHT);
    give(w, "rune_glow");
    strict_1.default.deepEqual((0, gear_1.golemGlow)(w, pl), gear_2.GOLEM_LIGHT, "in the pack: standard glow");
    wear(w, "rune_glow");
    const g = (0, gear_1.golemGlow)(w, pl);
    strict_1.default.deepEqual(g, gear_2.RUNE_GLOW_LIGHT);
    strict_1.default.ok(g.rad > gear_2.GOLEM_LIGHT.rad);
    strict_1.default.deepEqual(g.col, [1, 1, 1], "white");
    strict_1.default.ok(g.int >= gear_2.GOLEM_LIGHT.int, "at least as bright");
    // the light object follows it, and a wider reach invalidates the traced visibility
    const L = (0, light_1.makeLight)(100, 100, gear_2.GOLEM_LIGHT.rad, gear_2.GOLEM_LIGHT.col, 0, 0, "golem");
    L.vx = 100;
    strict_1.default.equal((0, light_1.applyGlow)(L, gear_2.GOLEM_LIGHT), false);
    strict_1.default.equal(L.vx, 100, "no change, no re-trace");
    strict_1.default.equal((0, light_1.applyGlow)(L, g), true);
    strict_1.default.deepEqual([L.rad, L.r, L.g, L.b, L.glow, L.vx], [g.rad, 1, 1, 1, g.int, -999]);
    strict_1.default.equal((0, commands_1.takeOffGear)(w, pl, "rune0"), "ok");
    strict_1.default.deepEqual((0, gear_1.golemGlow)(w, pl), gear_2.GOLEM_LIGHT, "taken off: standard glow again");
});
(0, node_test_1.test)("the dark is easier to see in: lit pixels beyond the standard radius, and white instead of amber", () => {
    const W = 320, H = 180, grid = new Uint8Array(40 * 24).fill(tiles_1.T.FLOOR);
    const area = { grid, w: 40, h: 24 };
    const light = (g) => {
        const L = (0, light_1.makeLight)(160, 90, g.rad, g.col, 1, 0);
        L.cur = 1;
        (0, light_1.applyGlow)(L, g);
        (0, light_1.computeVis)(L, area);
        const lt = new light_1.Lighting(W, H);
        lt.accumulate([L], 0, 0);
        return lt;
    };
    const base = light(gear_2.GOLEM_LIGHT), rune = light(gear_2.RUNE_GLOW_LIGHT);
    const at = (lt, x, y) => [lt.ar[y * W + x], lt.ag[y * W + x], lt.ab[y * W + x]];
    // 140 px away: dark for the standard glow, lit with the rune
    strict_1.default.deepEqual(at(base, 300, 90), [0, 0, 0]);
    strict_1.default.ok(at(rune, 300, 90)[0] > 0.01);
    const lit = (lt) => lt.ar.reduce((s, v) => s + (v > 0.02 ? 1 : 0), 0);
    strict_1.default.ok(lit(rune) > lit(base) * 1.5, "a much larger lit area");
    // white: equal channels (the standard glow is warm: red > blue)
    const [r, g, b] = at(rune, 200, 90);
    strict_1.default.ok(Math.abs(r - g) < 1e-6 && Math.abs(g - b) < 1e-6);
    const [r0, , b0] = at(base, 200, 90);
    strict_1.default.ok(r0 > b0);
});
(0, node_test_1.test)("both runes together once a second slot is open: effects combine", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.slotRune1);
    give(w, "rune_swift");
    give(w, "rune_glow");
    wear(w, "rune_swift");
    wear(w, "rune_glow");
    const pl = (0, world_1.player)(w);
    strict_1.default.deepEqual((0, gear_1.activeGear)(w, pl).sort(), ["rune_glow", "rune_swift"]);
    strict_1.default.equal((0, gear_1.speedMultiplier)(w, pl), 2.5);
    strict_1.default.deepEqual((0, gear_1.golemGlow)(w, pl), gear_2.RUNE_GLOW_LIGHT);
    // the body shows what is worn: a sigil per worn rune, in slot order
    const marks = (0, gear_1.runeMarks)(w, pl);
    strict_1.default.deepEqual(marks.map((m) => m?.col ?? null), [items_1.ITEMS.rune_swift.worn.mark.col, items_1.ITEMS.rune_glow.worn.mark.col, null, null]);
});
(0, node_test_1.test)("effects are data: a new rune is just a new row (speeds add, the widest light wins), no code change", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.slotRune1);
    (0, world_1.setFlag)(w, flags_1.FLAGS.slotRune2);
    const items = items_1.ITEMS;
    items.rune_test = { name: "RUNE OF TEST", tags: ["rune"], wear: { kind: "rune" }, worn: { speed: 0.5, light: { rad: 300, col: [0.5, 1, 0.5], int: 1 } } };
    try {
        give(w, "rune_swift");
        give(w, "rune_glow");
        give(w, "rune_test");
        for (const id of ["rune_swift", "rune_glow", "rune_test"])
            wear(w, id);
        const pl = (0, world_1.player)(w);
        strict_1.default.equal((0, gear_1.speedMultiplier)(w, pl), 1 + 1.5 + 0.5);
        strict_1.default.equal((0, gear_1.golemGlow)(w, pl).rad, 300);
        strict_1.default.deepEqual((0, items_1.effectLines)("rune_test"), ["WORN: SPEED X1.5", "WORN: BRIGHT WHITE LIGHT X2.8"]);
    }
    finally {
        delete items.rune_test;
    }
    for (const id of ["rune_swift", "rune_glow"])
        strict_1.default.ok((0, items_1.effectLines)(id).length > 0 && (0, items_1.effectLines)(id).every((l) => [...l].every((c) => font_1.FONT_GLYPHS.has(c)) && l.length <= 34), id);
});
(0, node_test_1.test)("carving end to end: stone -> cut stone -> rune (chisel carried) -> worn -> effect", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    const pl = (0, world_1.player)(w);
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "workbench@13.5,37")); // the tutorial's chisel
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    const bench = (0, world_1.currentArea)(w).prop("workbench@13.5,37");
    pl.x = bench.x;
    pl.y = bench.y + 12;
    pl.facing = "up";
    (0, inventory_1.addItems)(w, pl, "stone", 6);
    for (const id of ["cut_stone", "cut_stone", "rune_glow"]) {
        strict_1.default.equal((0, crafting_1.orderCraft)(w, pl, "crafting", id, bench.id), true, id);
        let g = 0;
        while (pl.task && g++ < 600)
            (0, helpers_1.frame)(w);
    }
    strict_1.default.equal((0, inventory_1.countItem)(pl, "rune_glow"), 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "stone"), 0);
    wear(w, "rune_glow");
    strict_1.default.equal((0, gear_1.golemGlow)(w, pl).rad, gear_2.RUNE_GLOW_LIGHT.rad);
    (0, helpers_1.frames)(w, 3);
    strict_1.default.equal(pl.gear.rune0, "rune_glow");
});
