"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The dormant worker golem's shut screen (opens only once a core has been slotted
// in, and stays open after the core comes out) and storage chest names (the
// orders' own labels by default, renamable from the storage screen, saved).
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const map_1 = require("../src/game/map");
const monologue_1 = require("../src/game/content/monologue");
const flags_1 = require("../src/game/content/flags");
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const inventory_1 = require("../src/game/sim/inventory");
const power_1 = require("../src/game/sim/power");
const interact_1 = require("../src/game/sim/interact");
const commands_1 = require("../src/game/sim/commands");
const orders_1 = require("../src/game/sim/orders");
const storage_1 = require("../src/game/screens/storage");
const helpers_1 = require("./helpers");
const screenHost_1 = require("./support/screenHost");
const workerFixture_1 = require("./support/workerFixture");
const WORKER = map_1.ARTIFICERY_WORKER.id;
const thoughts = (evs) => evs.filter((e) => e.t === "thought").map((e) => e.line);
const roundTrip = (w) => (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
const coreKey = (w) => { (0, helpers_1.frame)(w, { ix: 0, iy: 0, use: false, core: true }); (0, helpers_1.frames)(w, 150); };
// ------------------------------------------------------------------ the golem
(0, node_test_1.test)("a worker that never had a core: E shuts, thinks the dormant line; slot a core in and out, and the screen opens, silently", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), wk = (0, world_1.actorById)(w, WORKER);
    const it = () => (0, interact_1.npcInteractables)(w, (0, world_1.currentArea)(w)).find((i) => i.actorId === WORKER);
    strict_1.default.equal((0, power_1.canManage)(w, wk), false);
    (0, helpers_1.events)(w);
    (0, helpers_1.useOn)(w, it());
    let evs = (0, helpers_1.events)(w);
    strict_1.default.ok(evs.some((e) => e.t === "dormantTouched"));
    strict_1.default.ok(!evs.some((e) => e.t === "manageActor"));
    strict_1.default.deepEqual(thoughts(evs), ["golem.dormant"]);
    // the first time a core goes in: powered, screen open, no dormant line, and the seated flag is set
    (0, inventory_1.addItems)(w, pl, "ruby_core", 1);
    coreKey(w);
    strict_1.default.equal(wk.powerCore, "ruby_core");
    strict_1.default.ok(w.flags.has((0, flags_1.npcFlag)(WORKER, flags_1.CORE_SEATED)));
    strict_1.default.ok(!thoughts((0, helpers_1.events)(w)).includes("golem.dormant"), "slotting it in is not 'missing power source'");
    (0, helpers_1.useOn)(w, it());
    evs = (0, helpers_1.events)(w);
    strict_1.default.ok(evs.some((e) => e.t === "manageActor"));
    strict_1.default.deepEqual(thoughts(evs), []);
    // core out again: the screen still opens, and the golem says nothing about it
    coreKey(w);
    (0, helpers_1.events)(w);
    strict_1.default.equal(wk.powerCore, null);
    strict_1.default.equal((0, power_1.canManage)(w, wk), true);
    (0, helpers_1.useOn)(w, it());
    evs = (0, helpers_1.events)(w);
    strict_1.default.ok(evs.some((e) => e.t === "manageActor"));
    strict_1.default.ok(!evs.some((e) => e.t === "dormantTouched"));
    strict_1.default.deepEqual(thoughts(evs), []);
    // and that survives a save
    const loaded = roundTrip(w);
    strict_1.default.equal((0, power_1.canManage)(loaded, (0, world_1.actorById)(loaded, WORKER)), true);
});
(0, node_test_1.test)("the dormant line fires every time until the first core, and a body that needs no power is never locked", () => {
    strict_1.default.deepEqual([monologue_1.THOUGHTS["golem.dormant"].once, monologue_1.THOUGHTS["golem.dormant"].cooldown], [false, 2]);
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    strict_1.default.equal((0, power_1.canManage)(w, pl), true, "the maintainer has no power socket to wait on");
});
// ------------------------------------------------------------------ chest names
function addChest(w) {
    const area = (0, world_1.getArea)(w, workerFixture_1.CHEST.area);
    return area.addProp("storage_chest", 11 * 16 + 8, 8 * 16 + 14);
}
(0, node_test_1.test)("a chest goes by the name the orders give it: area, kind, and a number once there are several", () => {
    const { w, pl } = (0, workerFixture_1.fixture)(), area = (0, world_1.getArea)(w, workerFixture_1.CHEST.area);
    strict_1.default.equal((0, orders_1.propName)(area, (0, workerFixture_1.chestProp)(w)), "DEBUG WORKSHOP CHEST");
    const second = addChest(w);
    const names = (0, orders_1.storageOptions)(w, pl).filter((o) => o.area === workerFixture_1.CHEST.area);
    strict_1.default.deepEqual(names.map((o) => o.label), ["DEBUG WORKSHOP CHEST 1", "DEBUG WORKSHOP CHEST 2"].sort());
    for (const o of names)
        strict_1.default.equal(o.label, (0, orders_1.propName)(area, area.prop(o.ref.prop)), "the screen and the orders agree");
    strict_1.default.ok(second.id);
});
(0, node_test_1.test)("renaming: the storage screen's R, typed letters, Enter; the orders and the save follow; empty goes back to the default", () => {
    const { w, pl } = (0, workerFixture_1.fixture)(), sh = (0, screenHost_1.screenHost)(w), ui = new storage_1.StorageUi(sh.host), area = (0, world_1.getArea)(w, workerFixture_1.CHEST.area);
    (0, workerFixture_1.besideChest)(w);
    ui.open(workerFixture_1.CHEST.prop);
    const type = (...ch) => { sh.host.typed = ch; sh.press(); sh.host.typed = []; };
    sh.press("r");
    strict_1.default.ok(ui.nameField.active);
    strict_1.default.equal(ui.nameField.value, "DEBUG WORKSHOP CHEST", "starts from the current name");
    // typing "e", "q", "w" must not move the cursor, move items or close the screen
    const cursor = ui.cursor;
    for (let i = 0; i < 25; i++)
        type("\b");
    type("w", "o", "o", "d", " ", "s", "t", "o", "r", "e");
    sh.press("q", "e", "w", "i"); // command keys while typing: nothing happens
    strict_1.default.equal(ui.nameField.value, "WOOD STORE");
    strict_1.default.equal(ui.cursor, cursor);
    strict_1.default.ok(sh.host.screens.is("storage"));
    (0, screenHost_1.assertTextFits)("storage rename", sh.draw());
    sh.save(".test-out/shots/storage-rename.png");
    sh.press("enter");
    strict_1.default.ok(!ui.nameField.active);
    strict_1.default.equal((0, workerFixture_1.chestProp)(w).name, "WOOD STORE");
    strict_1.default.equal((0, orders_1.propName)(area, (0, workerFixture_1.chestProp)(w)), "WOOD STORE");
    strict_1.default.deepEqual((0, orders_1.storageOptions)(w, pl).map((o) => o.label), ["WOOD STORE"], "an order's chest list uses it");
    (0, screenHost_1.assertTextFits)("storage renamed", sh.draw());
    sh.save(".test-out/shots/storage-renamed.png");
    // it is saved with the chest
    const loaded = roundTrip(w);
    strict_1.default.equal((0, world_1.getArea)(loaded, workerFixture_1.CHEST.area).prop(workerFixture_1.CHEST.prop).name, "WOOD STORE");
    strict_1.default.deepEqual((0, save_1.serialize)(loaded), (0, save_1.serialize)(w));
    // Esc cancels, leaving the name
    sh.press("r");
    type("\b", "\b");
    sh.press("escape");
    strict_1.default.ok(!ui.nameField.active && sh.host.screens.is("storage"));
    strict_1.default.equal((0, workerFixture_1.chestProp)(w).name, "WOOD STORE");
    // an empty name is the default again
    sh.press("r");
    for (let i = 0; i < 25; i++)
        type("\b");
    sh.press("enter");
    strict_1.default.equal((0, workerFixture_1.chestProp)(w).name, undefined);
    strict_1.default.equal((0, orders_1.propName)(area, (0, workerFixture_1.chestProp)(w)), "DEBUG WORKSHOP CHEST");
    strict_1.default.ok(!("name" in ((0, save_1.serialize)(w).areas[workerFixture_1.CHEST.area].props[workerFixture_1.CHEST.prop] ?? {})));
});
(0, node_test_1.test)("names are cleaned, bounded, need the golem beside the chest, and a built chest keeps its name through a save", () => {
    strict_1.default.equal((0, orders_1.cleanPropName)("  my   chest  "), "MY CHEST");
    strict_1.default.equal((0, orders_1.cleanPropName)("x".repeat(40)).length, orders_1.PROP_NAME_MAX);
    const { w, pl } = (0, workerFixture_1.fixture)(), built = addChest(w);
    (0, workerFixture_1.besideChest)(w);
    strict_1.default.equal((0, commands_1.renameStorage)(w, pl, workerFixture_1.CHEST.prop, "  iron  ore ").ok, true);
    strict_1.default.equal((0, workerFixture_1.chestProp)(w).name, "IRON ORE");
    pl.x += 120;
    strict_1.default.equal((0, commands_1.renameStorage)(w, pl, workerFixture_1.CHEST.prop, "NOPE").ok, false);
    strict_1.default.equal((0, workerFixture_1.chestProp)(w).name, "IRON ORE");
    pl.x = built.x;
    pl.y = built.y + 9;
    strict_1.default.equal((0, commands_1.renameStorage)(w, pl, built.id, "spare").ok, true);
    const loaded = roundTrip(w), area = (0, world_1.getArea)(loaded, workerFixture_1.CHEST.area);
    strict_1.default.equal(area.prop(built.id).name, "SPARE");
    strict_1.default.equal(area.prop(workerFixture_1.CHEST.prop).name, "IRON ORE");
    strict_1.default.deepEqual((0, save_1.serialize)(loaded), (0, save_1.serialize)(w));
});
