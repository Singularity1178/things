"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The real host (Game, on the fake canvas, driven by keys) through the entrance update: E digs the stair head
// stroke by stroke and the host says what the sim reports, the open stair is walked both ways with the view
// following, and E on the smelter and the anvil opens the station screen under its own name. The sim side is
// tests/entrance.test.ts and tests/smithing.test.ts.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const g0 = globalThis;
g0.localStorage ?? (g0.localStorage = { getItem: () => null, setItem: () => { }, removeItem: () => { } });
const game_1 = require("../src/game/game");
const world_1 = require("../src/game/world/world");
const inventory_1 = require("../src/game/sim/inventory");
const commands_1 = require("../src/game/sim/commands");
const digging_1 = require("../src/game/content/digging");
const geography_1 = require("../src/game/content/geography");
const flags_1 = require("../src/game/content/flags");
const helpers_1 = require("./helpers");
const GATE = "buriedgate@48,61", SITE = digging_1.DIG_SITES.buriedgate;
const canvas = () => globalThis.document.createElement("canvas");
const tick = (g, n = 1, dt = 1 / 60) => { for (let i = 0; i < n; i++)
    g.update(dt); };
const tap = (g, key) => { g.keyDown(key); tick(g); g.keyUp(key); tick(g); };
/** Close the station screen and let the reach that opened it (paused beneath the screen) finish. */
const close = (g) => { tap(g, "escape"); tick(g, 30); };
/** Press a key on the play screen and let the work it starts play out. */
function press(g, w, key) {
    tap(g, key);
    for (let i = 0; i < 400 && (0, world_1.player)(w).task; i++)
        tick(g);
    tick(g, 5);
}
function hold(g, key, done, max = 900) {
    g.keyDown(key);
    for (let i = 0; i < max && !done(); i++)
        tick(g);
    g.keyUp(key);
    tick(g);
    return done();
}
const fit = (w, id) => { const pl = (0, world_1.player)(w); (0, inventory_1.addItems)(w, pl, id, 1); strict_1.default.equal((0, commands_1.wearFromSlot)(w, pl, pl.inventory.findIndex((s) => s?.item === id)), "ok"); };
(0, node_test_1.test)("the host: E digs the stair head out stroke by stroke, says when the earth gives out and when the stair opens, and the open stair is walked down and back up", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), g = new game_1.Game(canvas(), canvas());
    const gate = (0, world_1.getArea)(w, "surface").prop(GATE);
    const stand = () => { pl.x = gate.x; pl.y = gate.y - 11; pl.vx = pl.vy = 0; pl.facing = "up"; };
    (0, world_1.enterArea)(w, pl, "surface", gate.x, gate.y - 11);
    g.resume(w);
    tick(g, 5);
    strict_1.default.ok(g.screens.is("play"));
    stand();
    press(g, w, "e");
    strict_1.default.match(g.note?.text ?? "", /SHOVEL HEAD/, "no tool: the golem says what it would take");
    strict_1.default.equal(gate.dmg, 0);
    fit(w, "head_shovel");
    stand();
    press(g, w, "e");
    strict_1.default.equal(gate.dmg, 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "dirt"), 1);
    g.render(); // the cut turf: the stair head drawn at its dig stage
    for (let i = 1; i < SITE.layers[0].work; i++) {
        stand();
        press(g, w, "e");
    }
    strict_1.default.equal((0, inventory_1.countItem)(pl, "dirt"), SITE.layers[0].work);
    strict_1.default.match(g.note?.text ?? "", /FALLEN STONE.*PICKAXE HEAD/, "the earth is out: the host says what lies under it");
    fit(w, "head_pickaxe");
    for (let i = 0; i < SITE.layers[1].work; i++) {
        stand();
        press(g, w, "e");
        g.render();
    }
    strict_1.default.ok(gate.open && (0, world_1.hasFlag)(w, geography_1.ENTRANCES.surface_stair.flag));
    strict_1.default.match(g.note?.text ?? "", /STAIR IS OPEN/);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "stone"), SITE.layers[1].work);
    strict_1.default.ok(pl.y > gate.y, "set down on the lip");
    g.render(); // the open stairwell, the glyph alight
    // down into the halls, the view following, the place named
    strict_1.default.ok(hold(g, "w", () => pl.area === "dungeon", 120), "pushing north into the stairwell walks down");
    strict_1.default.equal(g.area.id, "dungeon");
    strict_1.default.equal(g.note?.text, "THE HALLS: FIRST CELLAR");
    strict_1.default.ok(g.doorFade > 0);
    g.render(); // the stair from inside, the sky coming down it
    tick(g, 60);
    // and back up
    strict_1.default.ok(hold(g, "s", () => pl.area === "surface", 300), "walking south off the top of the flight comes out");
    strict_1.default.equal(g.area.id, "surface");
    strict_1.default.equal(g.note?.text, "THE SURFACE");
    strict_1.default.ok(g.screens.is("play"));
    g.render();
});
(0, node_test_1.test)("the host: E on the smelter and on the anvil opens the station screen under its own name, with the anvil's tabs", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), g = new game_1.Game(canvas(), canvas());
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    g.resume(w);
    tick(g, 5);
    const a = (0, world_1.getArea)(w, "dungeon"), forge = a.prop("forge@5.5,37"), anvil = a.prop("anvil@6,40");
    const at = (p) => { pl.x = p.x; pl.y = p.y + 11; pl.vx = pl.vy = 0; pl.facing = "up"; };
    // the smelter, before the golem has studied one: its screen opens, dark
    at(forge);
    press(g, w, "e");
    strict_1.default.ok(g.screens.is("crafting"), "the smelter opens the station screen");
    strict_1.default.equal(g.craftUi.station, "smelting");
    strict_1.default.equal(g.craftUi.def.name, "SMELTER");
    strict_1.default.ok(g.craftUi.locked, "no plans until smelting is learned");
    g.render();
    close(g);
    strict_1.default.ok(g.screens.is("play"));
    // studied (the scan's own path is tests/smithing.test.ts): the rows are there, and SMELT sets the golem to work
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowSmelt);
    (0, inventory_1.addItems)(w, pl, "iron_ore", 2);
    (0, inventory_1.addItems)(w, pl, "wood", 1);
    at(forge);
    press(g, w, "e");
    strict_1.default.ok(g.screens.is("crafting") && !g.craftUi.locked);
    strict_1.default.deepEqual(g.craftUi.entries.map((e) => e.recipe.id), ["iron_ingot", "iron_ingot_charge"]);
    g.render();
    tap(g, "e");
    tap(g, "e"); // to the button, then SMELT: the screen steps aside while the golem works
    strict_1.default.ok(g.screens.is("play") && g.craftUi.pending);
    for (let i = 0; i < 600 && !g.screens.is("crafting"); i++)
        tick(g);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "iron_ingot"), 2);
    strict_1.default.ok(g.screens.is("crafting"), "and comes back when the ingots are poured");
    strict_1.default.match(g.note?.text ?? "", /MADE 2 IRON INGOT/);
    close(g);
    // the anvil: four tabs, Q / R to turn them
    (0, inventory_1.addItems)(w, pl, "head_shovel_rusted", 1);
    at(anvil);
    press(g, w, "e");
    strict_1.default.ok(g.screens.is("crafting"));
    strict_1.default.equal(g.craftUi.station, "smithing");
    strict_1.default.equal(g.craftUi.def.name, "ANVIL");
    strict_1.default.deepEqual(g.craftUi.tabs.map((t) => t.name), ["FORGE", "REPAIR", "MODIFY", "RUNES"]);
    strict_1.default.equal(g.craftUi.tabs[g.craftUi.tab].id, "forge");
    strict_1.default.equal(g.craftUi.entries.length, 3);
    g.render();
    tap(g, "r");
    strict_1.default.equal(g.craftUi.tabs[g.craftUi.tab].id, "repair");
    strict_1.default.deepEqual(g.craftUi.entries.map((e) => e.recipe.id), ["repair_head_shovel"]);
    g.render();
    tap(g, "4");
    strict_1.default.equal(g.craftUi.tabs[g.craftUi.tab].id, "runes");
    strict_1.default.equal(g.craftUi.entries.length, 0);
    g.render(); // an empty tab says what it needs
    tap(g, "q");
    tap(g, "q");
    strict_1.default.equal(g.craftUi.tabs[g.craftUi.tab].id, "repair");
    tap(g, "e");
    tap(g, "e"); // to the button, then REPAIR
    for (let i = 0; i < 600 && !g.screens.is("crafting"); i++)
        tick(g);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "head_shovel"), 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "head_shovel_rusted"), 0);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "iron_ingot"), 1);
    strict_1.default.equal(g.craftUi.tabs[g.craftUi.tab].id, "repair", "back on the tab it was working from");
    close(g);
    // one ingot forges nothing, but it mends: the screen opens on the first tab with something ready
    (0, inventory_1.addItems)(w, pl, "head_pickaxe_rusted", 1);
    at(anvil);
    press(g, w, "e");
    strict_1.default.equal(g.craftUi.tabs[g.craftUi.tab].id, "repair");
    strict_1.default.deepEqual(g.craftUi.entries.map((e) => [e.recipe.id, e.status]), [["repair_head_pickaxe", "ok"]]);
    close(g);
    strict_1.default.ok(g.screens.is("play"));
});
