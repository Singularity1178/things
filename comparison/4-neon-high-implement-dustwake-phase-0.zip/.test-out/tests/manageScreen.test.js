"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The worker management screen (screens/manage.ts): the worker's state as the
// screen reads it, the core in and out through orderCoreSwap, orders given
// through setWorkerOrder (gather, craft, go to) and run end to end, pause /
// resume / cancel, refusals in words, saves mid-job, and a text lint.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const manage_1 = require("../src/game/screens/manage");
const commands_1 = require("../src/game/sim/commands");
const jobs_1 = require("../src/game/sim/jobs");
const orders_1 = require("../src/game/sim/orders");
const tasks_1 = require("../src/game/sim/tasks");
const inventory_1 = require("../src/game/sim/inventory");
const power_1 = require("../src/game/sim/power");
const actorStats_1 = require("../src/game/sim/actorStats");
const inventoryOps_1 = require("../src/game/sim/inventoryOps");
const jobs_2 = require("../src/game/content/jobs");
const font_1 = require("../src/game/font");
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const helpers_1 = require("./helpers");
const screenHost_1 = require("./support/screenHost");
const workerFixture_1 = require("./support/workerFixture");
const roundTrip = (w) => (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
const texts = (b) => b.map((x) => x.text);
const has = (b, t) => strict_1.default.ok(texts(b).includes(t), `"${t}" not drawn; got ${texts(b).join(" | ")}`);
const last = (a) => a[a.length - 1];
const jobOf = (w) => JSON.stringify((0, workerFixture_1.worker)(w).job);
const fillChest = (w) => (0, world_1.getArea)(w, workerFixture_1.CHEST.area).setInventory(workerFixture_1.CHEST.prop, Array.from({ length: 32 }, () => ({ item: "stone", n: 20 })));
function open() {
    const f = (0, workerFixture_1.fixture)(), sh = (0, screenHost_1.screenHost)(f.w), ui = new manage_1.ManageUi(sh.host);
    ui.open(f.worker.id);
    return { ...f, sh, ui };
}
/** Move to the row starting `label` with W / S, as a player would. */
function goto(sh, ui, label) {
    const i = ui.menu.findIndex((r) => r.label.startsWith(label));
    strict_1.default.ok(i >= 0, `no row "${label}" in ${ui.menu.map((r) => r.label).join(" | ")}`);
    for (let d = i - ui.row; d !== 0; d += d > 0 ? -1 : 1)
        sh.press(d > 0 ? "s" : "w");
}
const choose = (sh, ui, label) => { goto(sh, ui, label); sh.press("e"); };
/** Turn a choice row until it shows `value`. */
function pickValue(sh, ui, label, value) {
    goto(sh, ui, label);
    for (let i = 0; i < 40 && ui.menu[ui.row].value !== value; i++)
        sh.press("d");
    strict_1.default.equal(ui.menu[ui.row].value, value);
}
const shot = (sh, name, w) => { const b = sh.draw(); (0, screenHost_1.assertTextFits)(name, b); sh.save(`.test-out/shots/${w ?? name}.png`); return b; };
// ------------------------------------------------------------------ state
(0, node_test_1.test)("shows the worker as it is: switched off, idle, working, paused, blocked on a full chest, done", () => {
    const { w, pl, worker: wk, sh, ui } = open();
    // idle and powered
    let b = shot(sh, "manage idle", "manage-idle");
    has(b, "WORKER GOLEM");
    has(b, "IDLE: NO ORDER");
    has(b, "POWER: RUBY GOLEM CORE");
    has(b, "AT: DEBUG WORKSHOP");
    has(b, "NO ORDER");
    has(b, "CARRIES 0/8");
    strict_1.default.equal(ui.menu[0].label, "TAKE OUT RUBY GOLEM CORE");
    // switched off: no core in it, none carried, then one carried
    (0, power_1.removePowerCore)(w, pl, wk);
    (0, inventory_1.giveItem)(w, pl, "ruby_core");
    pl.inventory = pl.inventory.map((s) => (s?.item === "ruby_core" ? null : s));
    b = shot(sh, "manage off");
    has(b, "OFF: NO POWER");
    has(b, "POWER: NO CORE");
    strict_1.default.equal(ui.menu[0].label, "NO CORE TO SLOT IN");
    strict_1.default.ok(!ui.menu[0].ok);
    (0, inventory_1.giveItem)(w, pl, "ruby_core");
    strict_1.default.equal(ui.menu[0].label, "SLOT IN RUBY GOLEM CORE");
    strict_1.default.ok(ui.menu[0].ok);
    wk.powerCore = "ruby_core";
    // working, with something in its hands and a rune on it
    wk.gear.rune0 = "rune_swift";
    strict_1.default.ok((0, jobs_1.assignJob)(w, wk, (0, jobs_1.gatherOrder)("wood", "debug_yard", { ...workerFixture_1.CHEST }, 6)));
    (0, workerFixture_1.until)(w, () => (0, inventoryOps_1.countItem)(wk, "wood") > 0 && wk.job.status === "running");
    b = shot(sh, "manage working", "manage-working");
    has(b, "WORKING");
    has(b, "GATHER WOOD 0/6");
    has(b, "FROM DEBUG YARD");
    has(b, "TO DEBUG WORKSHOP CHEST");
    has(b, "RUNE 1");
    strict_1.default.ok(texts(b).some((t) => t.startsWith("PHASE: ")));
    strict_1.default.ok(texts(b).some((t) => /^CARRIES [1-8]\/8$/.test(t)));
    // paused by hand
    (0, jobs_1.pauseJob)(w, wk);
    b = shot(sh, "manage paused");
    has(b, "PAUSED");
    (0, jobs_1.resumeJob)(w, wk);
    wk.gear = {};
    // blocked: the chest is full when it comes to store
    fillChest(w);
    (0, workerFixture_1.until)(w, () => wk.job.status === "blocked", 20000);
    strict_1.default.equal(wk.job.reason, "storageFull");
    b = shot(sh, "manage blocked", "manage-blocked");
    has(b, "BLOCKED: STORAGE FULL");
    strict_1.default.equal(ui.menu[6].label, "RETRY ORDER");
    // done
    (0, world_1.getArea)(w, workerFixture_1.CHEST.area).setInventory(workerFixture_1.CHEST.prop, []);
    (0, jobs_1.resumeJob)(w, wk);
    (0, workerFixture_1.until)(w, () => wk.job.status === "done");
    b = shot(sh, "manage done");
    has(b, "DONE");
    has(b, "PHASE: FINISHED");
    // unpowered with an order: waits for power
    wk.job.status = "running";
    wk.powerCore = null;
    (0, helpers_1.frame)(w);
    strict_1.default.equal(wk.job.reason, "power");
    b = shot(sh, "manage waiting");
    has(b, "WAITING FOR POWER");
});
// ------------------------------------------------------------------ the core
function twin(setup) {
    const a = open(), b = (0, workerFixture_1.fixture)();
    setup(a);
    setup(b);
    return { a, b };
}
for (const [name, setup, expect] of [
    ["take out", () => { }, (wk) => !wk.powerCore],
    ["slot in", (f) => { (0, power_1.removePowerCore)(f.w, f.pl, f.worker); }, (wk) => wk.powerCore === "ruby_core"],
    ["take out into a full pack: it drops", (f) => { f.pl.inventory = Array.from({ length: 8 }, () => ({ item: "wood", n: 20 })); }, (wk) => !wk.powerCore],
]) {
    (0, node_test_1.test)(`core, ${name}: the screen's row does exactly what orderCoreSwap does`, () => {
        const { a, b } = twin(setup);
        // the screen
        a.sh.press("e");
        strict_1.default.ok(a.ui.pending && a.sh.host.screens.is("play"), "the golem does the work with the world running; the screen steps aside");
        (0, workerFixture_1.finishTask)(a.w);
        // the command, on an identical world
        const wasOut = !!b.worker.powerCore;
        strict_1.default.ok((0, commands_1.orderCoreSwap)(b.w, b.pl, b.worker.id, wasOut ? null : "ruby_core"));
        (0, workerFixture_1.finishTask)(b.w);
        strict_1.default.ok(expect((0, workerFixture_1.worker)(a.w)), name);
        strict_1.default.deepEqual((0, save_1.serialize)(a.w), (0, save_1.serialize)(b.w), "identical worlds");
        if (name.includes("full pack")) {
            strict_1.default.equal((0, inventoryOps_1.countItem)((0, world_1.player)(a.w), "ruby_core"), 0);
            strict_1.default.ok((0, world_1.getArea)(a.w, "debug_workshop").loose.some((l) => l.item === "ruby_core" && !l.taken), "a full pack drops it on the ground");
        }
        // and the screen comes back, showing the new state
        a.ui.resume();
        strict_1.default.ok(a.sh.host.screens.is("manage"));
        const t = shot(a.sh, `manage core ${name}`);
        has(t, (0, actorStats_1.powered)((0, workerFixture_1.worker)(a.w)) ? "POWER: RUBY GOLEM CORE" : "POWER: NO CORE");
    });
}
(0, node_test_1.test)("core: from the reach that opened the screen; the guardian's C-style refusals are the same messages", () => {
    const f = (0, workerFixture_1.fixture)(), sh = (0, screenHost_1.screenHost)(f.w), ui = new manage_1.ManageUi(sh.host);
    // E on the worker as the play screen does: the reach fires its event and lingers
    let opened = false;
    for (let i = 0; i < 120 && !opened; i++) {
        (0, helpers_1.frame)(f.w, { ix: 0, iy: 0, use: true });
        opened = f.w.events.some((e) => e.t === "manageActor");
    }
    strict_1.default.ok(opened && f.pl.task?.fired, "the opening reach has fired and is still finishing");
    ui.open(f.worker.id);
    sh.press("e");
    strict_1.default.ok(ui.pending, "the lingering reach does not count as busy");
    (0, workerFixture_1.finishTask)(f.w);
    strict_1.default.equal(f.worker.powerCore, null);
    // nothing carried that fits: the row is greyed and says so
    f.pl.inventory = f.pl.inventory.map((x) => (x?.item === "ruby_core" ? null : x));
    ui.resume();
    goto(sh, ui, "NO CORE");
    sh.press("e");
    strict_1.default.equal(last(sh.notes), "YOU CARRY NO CORE THAT FITS IT");
    sh.press("c");
    strict_1.default.equal(last(sh.notes), "YOU CARRY NO CORE THAT FITS IT");
    strict_1.default.ok(!ui.pending);
});
// ------------------------------------------------------------------ orders
(0, node_test_1.test)("a gather order from the screen is the order gatherOrder builds, and runs end to end into the chest", () => {
    const a = open(), bf = (0, workerFixture_1.fixture)();
    strict_1.default.ok((0, jobs_1.setWorkerOrder)(bf.w, bf.pl, bf.worker.id, (0, jobs_1.gatherOrder)("wood", "debug_yard", { ...workerFixture_1.CHEST }, 6)));
    choose(a.sh, a.ui, "GATHER");
    strict_1.default.equal(a.ui.view, "gather");
    const b = shot(a.sh, "manage gather form", "manage-gather");
    has(b, "GATHER ORDER");
    strict_1.default.deepEqual(a.ui.menu.map((r) => r.label), ["RESOURCE", "FROM", "TO", "AMOUNT", "ISSUE ORDER"]);
    strict_1.default.deepEqual(a.ui.menu.slice(0, 4).map((r) => r.value), ["WOOD", "DEBUG YARD", "DEBUG WORKSHOP CHEST", "5"]);
    pickValue(a.sh, a.ui, "AMOUNT", "6");
    choose(a.sh, a.ui, "ISSUE ORDER");
    strict_1.default.equal(a.ui.view, "main");
    strict_1.default.equal(last(a.sh.notes), "ORDER GIVEN");
    strict_1.default.equal(jobOf(a.w), jobOf(bf.w), "the same job, field for field");
    (0, workerFixture_1.until)(a.w, () => (0, workerFixture_1.worker)(a.w).job?.status === "done");
    (0, workerFixture_1.until)(bf.w, () => (0, workerFixture_1.worker)(bf.w).job?.status === "done");
    strict_1.default.equal((0, workerFixture_1.chestCount)(a.w, "wood"), 6);
    strict_1.default.equal((0, inventoryOps_1.countItem)((0, workerFixture_1.worker)(a.w), "wood"), 0);
    strict_1.default.equal(a.w.events.filter((e) => e.t === "travelled").length + a.sh.seen.filter((e) => e.t === "travelled").length, 2, "to the yard and back, by rune");
    strict_1.default.deepEqual((0, save_1.serialize)(a.w), (0, save_1.serialize)(bf.w));
    // REPEAT is the repeat flag, and the resource row follows the data (wood, stone)
    (0, workerFixture_1.beside)(a.w, (0, workerFixture_1.worker)(a.w));
    choose(a.sh, a.ui, "GATHER");
    pickValue(a.sh, a.ui, "RESOURCE", "STONE");
    pickValue(a.sh, a.ui, "AMOUNT", "REPEAT");
    choose(a.sh, a.ui, "ISSUE ORDER");
    strict_1.default.equal(JSON.stringify((0, workerFixture_1.worker)(a.w).job).includes('"repeat":true'), true);
    const j = (0, workerFixture_1.worker)(a.w).job;
    strict_1.default.deepEqual([j.kind, j.args.resource, j.args.fromArea], ["gatherDeposit", "stone", "debug_yard"]);
});
(0, node_test_1.test)("a craft order from the screen is craftOrder's, and the worker crafts at the bench from the chest beside it", () => {
    const a = open(), bf = (0, workerFixture_1.fixture)();
    for (const w of [a.w, bf.w])
        (0, world_1.getArea)(w, workerFixture_1.CHEST.area).setInventory(workerFixture_1.CHEST.prop, [{ item: "wood", n: 4 }]);
    strict_1.default.ok((0, jobs_1.setWorkerOrder)(bf.w, bf.pl, bf.worker.id, (0, jobs_1.craftOrder)({ ...workerFixture_1.BENCH }, "planks", 2)));
    choose(a.sh, a.ui, "CRAFT");
    const b = shot(a.sh, "manage craft form", "manage-craft");
    has(b, "CRAFT ORDER");
    strict_1.default.deepEqual(a.ui.menu.slice(0, 2).map((r) => r.value), ["DEBUG WORKSHOP BENCH", "PLANKS"]);
    strict_1.default.equal(a.ui.menu[1].note[1], "IT HAS WHAT IT NEEDS RIGHT NOW.");
    pickValue(a.sh, a.ui, "AMOUNT", "2");
    choose(a.sh, a.ui, "ISSUE ORDER");
    strict_1.default.equal(jobOf(a.w), jobOf(bf.w));
    (0, workerFixture_1.until)(a.w, () => (0, workerFixture_1.worker)(a.w).job?.status === "done");
    (0, workerFixture_1.until)(bf.w, () => (0, workerFixture_1.worker)(bf.w).job?.status === "done");
    strict_1.default.equal((0, inventoryOps_1.countItem)((0, workerFixture_1.worker)(a.w), "planks"), 6);
    strict_1.default.equal((0, workerFixture_1.chestCount)(a.w, "wood"), 0);
    strict_1.default.deepEqual((0, save_1.serialize)(a.w), (0, save_1.serialize)(bf.w));
    // a recipe it can't make yet is offered with the reason, and its order waits
    choose(a.sh, a.ui, "CRAFT");
    pickValue(a.sh, a.ui, "RECIPE", "RUNE OF SWIFT");
    strict_1.default.equal(a.ui.menu[1].note[1], "NOW: NEED THE RUNE CHISEL. THE ORDER WAITS.");
    shot(a.sh, "manage craft waits");
});
(0, node_test_1.test)("a go-to order from the screen walks there and stands", () => {
    const { w, worker: wk, sh, ui } = open();
    choose(sh, ui, "GO TO");
    const b = shot(sh, "manage walk form", "manage-walk");
    has(b, "GO TO ORDER");
    const spots = (0, orders_1.walkOptions)(w, wk);
    strict_1.default.ok(spots.length >= 4 && spots.every((s) => s.label.length <= 24), spots.map((s) => s.label).join());
    pickValue(sh, ui, "WHERE", "DEBUG YARD RUNE");
    choose(sh, ui, "ISSUE ORDER");
    const spot = spots.find((s) => s.label === "DEBUG YARD RUNE");
    strict_1.default.deepEqual(wk.job.args, (0, jobs_1.walkOrder)(spot.area, spot.x, spot.y).args);
    (0, workerFixture_1.until)(w, () => wk.job?.status === "done");
    strict_1.default.equal(wk.area, "debug_yard");
    strict_1.default.ok(Math.hypot(wk.x - spot.x, wk.y - spot.y) < 3);
});
(0, node_test_1.test)("pause, resume and cancel go through the screen; a paused order holds still and loses nothing", () => {
    const { w, pl, worker: wk, sh, ui } = open();
    strict_1.default.ok(!ui.menu[6].ok && ui.menu[6].label === "PAUSE ORDER" && !ui.menu[7].ok, "nothing to pause or cancel yet");
    for (let i = 0; i < 6; i++)
        sh.press("s");
    sh.press("e");
    strict_1.default.equal(last(sh.notes), "IT HAS NO ORDER TO PAUSE");
    (0, jobs_1.assignJob)(w, wk, (0, jobs_1.gatherOrder)("wood", "debug_yard", { ...workerFixture_1.CHEST }, 6));
    (0, workerFixture_1.until)(w, () => wk.moving);
    (0, workerFixture_1.beside)(w, wk);
    choose(sh, ui, "PAUSE ORDER");
    strict_1.default.deepEqual([wk.job.status, wk.job.reason, last(sh.notes)], ["paused", "manual", "ORDER PAUSED"]);
    strict_1.default.equal(ui.menu[6].label, "RESUME ORDER");
    const at = [wk.x, wk.y];
    (0, helpers_1.frames)(w, 120);
    strict_1.default.deepEqual([wk.x, wk.y], at, "it stays where it is");
    choose(sh, ui, "RESUME ORDER");
    strict_1.default.deepEqual([wk.job.status, last(sh.notes)], ["running", "ORDER RESUMED"]);
    (0, workerFixture_1.until)(w, () => (0, inventoryOps_1.countItem)(wk, "wood") > 0);
    (0, workerFixture_1.beside)(w, wk);
    choose(sh, ui, "CANCEL ORDER");
    strict_1.default.equal(wk.job, null);
    strict_1.default.equal(last(sh.notes), "ORDER CANCELLED");
    strict_1.default.ok((0, inventoryOps_1.countItem)(wk, "wood") > 0, "what it carries stays with it");
    strict_1.default.equal((0, commands_1.controlWorker)(w, pl, wk.id, "cancel").text, "IT HAS NO ORDER");
    // resuming an unpowered worker says it waits
    (0, workerFixture_1.beside)(w, wk);
    (0, jobs_1.assignJob)(w, wk, (0, jobs_1.walkOrder)("debug_workshop", 100, 100));
    (0, commands_1.controlWorker)(w, pl, wk.id, "pause");
    wk.powerCore = null;
    strict_1.default.equal((0, commands_1.controlWorker)(w, pl, wk.id, "resume").text, "NO POWER. IT WAITS FOR A CORE");
    wk.job.status = "running";
    wk.job.reason = null;
    strict_1.default.equal((0, commands_1.controlWorker)(w, pl, wk.id, "resume").text, "IT IS ALREADY WORKING");
});
// ------------------------------------------------------------------ refusals
(0, node_test_1.test)("refusals are said in words, agree with setWorkerOrder, and change nothing", () => {
    const { w, pl, worker: wk, sh, ui } = open();
    const chest = { ...workerFixture_1.CHEST };
    const table = [
        ["unknown kind", { kind: "dance", args: {} }, "THAT KIND OF ORDER IS UNKNOWN"],
        ["no such resource", (0, jobs_1.gatherOrder)("nope", "debug_yard", chest, 3), "NO SUCH RESOURCE"],
        ["no such area", (0, jobs_1.gatherOrder)("wood", "nowhere", chest, 3), "NO SUCH SOURCE AREA"],
        ["no such storage", (0, jobs_1.gatherOrder)("wood", "debug_yard", { area: "nowhere", prop: "x" }, 3), "NO SUCH STORAGE"],
        ["bad amount", (0, jobs_1.gatherOrder)("wood", "debug_yard", chest, 0), "THE AMOUNT IS NOT VALID"],
        ["no such station", (0, jobs_1.craftOrder)({ area: "nowhere", prop: "x" }, "planks", 1), "NO SUCH STATION"],
        ["no such recipe", (0, jobs_1.craftOrder)({ ...workerFixture_1.BENCH }, "nope", 1), "NO SUCH RECIPE"],
        ["nowhere to go", { kind: "walk", args: { area: "debug_yard", x: NaN, y: 3 } }, "THERE IS NOWHERE TO GO"],
    ];
    for (const [name, order, text] of table) {
        strict_1.default.equal((0, jobs_1.orderRefusal)(w, pl, wk.id, order), text, name);
        strict_1.default.equal((0, jobs_1.setWorkerOrder)(w, pl, wk.id, order), false, name);
        strict_1.default.deepEqual((0, commands_1.giveWorkerOrder)(w, pl, wk.id, order), { ok: false, text }, name);
        sh.host.drainEvents();
        strict_1.default.equal(last(sh.notes), text, name);
        strict_1.default.equal(wk.job, null, name);
    }
    // who can be ordered
    const good = (0, jobs_1.gatherOrder)("wood", "debug_yard", chest, 2);
    strict_1.default.equal((0, jobs_1.orderRefusal)(w, pl, "npc.guardian", good), "THAT IS NOT A WORKER");
    strict_1.default.equal((0, jobs_1.orderRefusal)(w, pl, "nobody", good), "THAT IS NOT A WORKER");
    // busy with its own task
    (0, tasks_1.beginTask)(wk, { kind: "reach", dur: 5 });
    strict_1.default.equal((0, commands_1.giveWorkerOrder)(w, pl, wk.id, good).text, "IT IS BUSY. TRY AGAIN IN A MOMENT");
    strict_1.default.equal(wk.job, null);
    wk.task = null;
    // needs a capability it lacks
    jobs_2.JOB_KINDS.test_fly = { phase: "fly", capabilities: ["fly"] };
    jobs_1.JOB_HANDLERS.test_fly = { validate: () => true, step: () => { } };
    try {
        strict_1.default.equal((0, jobs_1.orderRefusal)(w, pl, wk.id, { kind: "test_fly", args: {} }), "IT CANNOT DO THAT WORK");
    }
    finally {
        delete jobs_2.JOB_KINDS.test_fly;
        delete jobs_1.JOB_HANDLERS.test_fly;
    }
    // too far, or no way through to it: same words as the screen's
    pl.x += 120;
    strict_1.default.equal((0, commands_1.giveWorkerOrder)(w, pl, wk.id, good).text, "STEP UP TO THE WORKER");
    strict_1.default.equal((0, jobs_1.setWorkerOrder)(w, pl, wk.id, good), false);
    strict_1.default.equal((0, commands_1.controlWorker)(w, pl, wk.id, "pause").text, "STEP UP TO THE WORKER");
    choose(sh, ui, "GO TO");
    choose(sh, ui, "ISSUE ORDER");
    strict_1.default.equal(last(sh.notes), "STEP UP TO THE WORKER");
    strict_1.default.equal(wk.job, null);
    // and when it is fine, they agree
    pl.x -= 120;
    strict_1.default.equal((0, jobs_1.orderRefusal)(w, pl, wk.id, good), null);
    strict_1.default.equal((0, jobs_1.setWorkerOrder)(w, pl, wk.id, good), true);
});
(0, node_test_1.test)("forms only offer what exists, and a form with nothing to offer cannot be issued and says why", () => {
    const { w, worker: wk, sh, ui } = open();
    // targets: storage props and stations only, in areas it can get to
    strict_1.default.deepEqual((0, orders_1.storageOptions)(w, wk).map((o) => o.ref), [{ ...workerFixture_1.CHEST }]);
    strict_1.default.deepEqual((0, orders_1.stationOptions)(w, wk).map((o) => o.ref), [{ ...workerFixture_1.BENCH }]);
    strict_1.default.deepEqual((0, orders_1.gatherSources)(w, wk, "wood").map((s) => s.area), ["debug_yard"]);
    strict_1.default.ok(!(0, world_1.getArea)(w, "dungeon").props.length || (0, orders_1.storageOptions)(w, wk).every((o) => o.area !== "dungeon"), "the dungeon's chests are not storage");
    const dungeonChest = (0, world_1.getArea)(w, "dungeon").props.find((p) => p.kind === "chest");
    strict_1.default.ok(dungeonChest, "the dungeon has a looted chest kind");
    strict_1.default.ok(!(0, orders_1.storageOptions)(w, wk).some((o) => o.ref.prop === dungeonChest.id));
    // no chest anywhere: the TO row still offers the worker's own pack, so a gather can always be ordered
    // (the order itself is run end to end in tests/routes.test.ts)
    (0, world_1.getArea)(w, workerFixture_1.CHEST.area).removeProp(workerFixture_1.CHEST.prop);
    choose(sh, ui, "GATHER");
    strict_1.default.deepEqual(ui.menu.map((r) => r.value ?? ""), ["WOOD", "DEBUG YARD", "INVENTORY", "5", ""]);
    strict_1.default.ok(ui.menu.every((r) => r.ok), "nothing is greyed out");
    goto(sh, ui, "TO");
    strict_1.default.deepEqual(ui.menu[ui.row].note, ["IT KEEPS WHAT IT GATHERS IN ITS OWN PACK.", "TAKE IT FROM THERE WITH TRANSFER."]);
    sh.press("d");
    strict_1.default.equal(ui.menu[ui.row].value, "INVENTORY", "the only choice there is");
    shot(sh, "manage gather no chest");
    goto(sh, ui, "ISSUE ORDER");
    strict_1.default.deepEqual(ui.menu[ui.row].note, ["GATHER 5 WOOD FROM DEBUG YARD, TO INVENTORY."]);
    sh.press("e");
    strict_1.default.equal(last(sh.notes), "ORDER GIVEN");
    strict_1.default.equal(ui.view, "main");
    strict_1.default.ok(sh.host.screens.is("manage"));
    strict_1.default.deepEqual(wk.job.args, (0, jobs_1.gatherOrder)("wood", "debug_yard", null, 5).args);
    has(shot(sh, "manage gather to inventory"), "TO INVENTORY");
    strict_1.default.ok((0, jobs_1.setWorkerOrder)(w, (0, world_1.player)(w), wk.id, null));
    strict_1.default.equal(wk.job, null);
    // with a chest the list is the chests first, then INVENTORY: the default stays the chest (the first test above)
    // nothing to gather: the rune route is dark, so the yard is out of reach
    strict_1.default.equal(ui.view, "main");
    (0, world_1.clearFlag)(w, "rune.debug_yard.active");
    strict_1.default.deepEqual((0, orders_1.gatherSources)(w, wk, "wood"), []);
    choose(sh, ui, "GATHER");
    strict_1.default.equal(ui.menu[1].value, "NONE");
    // no bench: no craft
    (0, world_1.getArea)(w, workerFixture_1.CHEST.area).removeProp(workerFixture_1.BENCH.prop);
    sh.press("escape");
    choose(sh, ui, "CRAFT");
    choose(sh, ui, "ISSUE ORDER");
    strict_1.default.equal(last(sh.notes), "BUILD A CRAFTING BENCH FIRST");
    // a body that can't do the work is not offered it
    sh.press("escape");
    (0, world_1.setFlag)(w, "rune.debug_yard.active");
    strict_1.default.ok(ui.menu[1].ok);
});
(0, node_test_1.test)("an order given to a switched-off worker is kept, and starts when a core goes in", () => {
    const { w, pl, worker: wk, sh, ui } = open();
    (0, power_1.removePowerCore)(w, pl, wk);
    choose(sh, ui, "GO TO");
    pickValue(sh, ui, "WHERE", "DEBUG WORKSHOP CHEST");
    choose(sh, ui, "ISSUE ORDER");
    strict_1.default.equal(last(sh.notes), "ORDER GIVEN. IT WAITS FOR A CORE");
    strict_1.default.deepEqual([wk.job.status, wk.job.reason], ["paused", "power"]);
    (0, helpers_1.frames)(w, 60);
    strict_1.default.equal(wk.job.status, "paused");
    strict_1.default.ok(sh.draw().some((b) => b.text === "WAITING FOR POWER"));
    const pc = ui.menu[0];
    strict_1.default.equal(pc.label, "SLOT IN RUBY GOLEM CORE");
    sh.press("e");
    (0, workerFixture_1.finishTask)(w);
    ui.resume();
    (0, workerFixture_1.until)(w, () => wk.job?.status === "done", 3000);
    strict_1.default.ok((0, actorStats_1.powered)(wk));
});
// ------------------------------------------------------------------ saving
(0, node_test_1.test)("a save in the middle of a screen-given order continues identically, and the screen reads the loaded worker", () => {
    const { w, sh, ui } = open();
    choose(sh, ui, "GATHER");
    pickValue(sh, ui, "AMOUNT", "3");
    choose(sh, ui, "ISSUE ORDER");
    (0, workerFixture_1.until)(w, () => (0, workerFixture_1.worker)(w).task?.kind === "punch" && (0, workerFixture_1.worker)(w).task.t > 0.2 && (0, inventoryOps_1.countItem)((0, workerFixture_1.worker)(w), "wood") >= 1);
    const loaded = roundTrip(w);
    strict_1.default.deepEqual((0, save_1.serialize)(loaded), (0, save_1.serialize)(w));
    for (let i = 0; i < 8000 && (0, workerFixture_1.worker)(w).job?.status !== "done"; i++) {
        (0, workerFixture_1.until)(w, () => true, 0);
        (0, helpers_1.frames)(w, 1);
        (0, helpers_1.frames)(loaded, 1);
    }
    strict_1.default.equal((0, workerFixture_1.worker)(w).job?.status, "done");
    strict_1.default.equal((0, workerFixture_1.chestCount)(loaded, "wood"), 3);
    strict_1.default.deepEqual((0, save_1.serialize)(loaded), (0, save_1.serialize)(w));
    // a screen on a loaded, still-working world
    const l2 = roundTrip(open().w);
    strict_1.default.ok((0, jobs_1.assignJob)(l2, (0, workerFixture_1.worker)(l2), (0, jobs_1.gatherOrder)("wood", "debug_yard", { ...workerFixture_1.CHEST }, 2)));
    const l3 = roundTrip(l2), sh3 = (0, screenHost_1.screenHost)(l3), ui3 = new manage_1.ManageUi(sh3.host);
    ui3.open((0, workerFixture_1.worker)(l3).id);
    const b = sh3.draw();
    (0, screenHost_1.assertTextFits)("manage loaded", b);
    has(b, "WORKING");
    has(b, "GATHER WOOD 0/2");
});
// ------------------------------------------------------------------ the lint
(0, node_test_1.test)("every state and form draws font glyphs only, inside the panel, with no text over text", () => {
    const { w, pl, worker: wk, sh, ui } = open();
    const every = (name) => {
        for (const view of ["main", "gather", "craft", "walk"]) {
            ui.view = view;
            ui.menu;
            for (let r = 0; r < ui.menu.length; r++) {
                ui.rows[view] = r;
                (0, screenHost_1.assertTextFits)(`${name} ${view} row ${r}`, sh.draw());
            }
        }
        ui.view = "main";
    };
    every("idle");
    (0, jobs_1.assignJob)(w, wk, (0, jobs_1.gatherOrder)("wood", "debug_yard", { ...workerFixture_1.CHEST }, 99));
    every("working");
    for (const reason of Object.keys(orders_1.BLOCK_TEXT)) {
        wk.job.status = "blocked";
        wk.job.reason = reason;
        every(`blocked ${reason}`);
        strict_1.default.ok((0, orders_1.blockText)(reason).length <= 15, reason);
    }
    wk.job.status = "paused";
    wk.job.reason = "power";
    every("waiting");
    (0, jobs_1.assignJob)(w, wk, (0, jobs_1.craftOrder)({ ...workerFixture_1.BENCH }, "rune_swift", 99, true));
    every("crafting");
    (0, jobs_1.assignJob)(w, wk, (0, jobs_1.walkOrder)("debug_yard", 20, 20));
    every("walking");
    (0, power_1.removePowerCore)(w, pl, wk);
    wk.inventory = Array.from({ length: 8 }, (_, i) => ({ item: ["wood", "stone", "planks", "cut_stone"][i % 4], n: 1 + i * 2 }));
    wk.gear.rune0 = "rune_glow";
    every("off, full");
    for (const t of [...Object.values(orders_1.BLOCK_TEXT), (0, orders_1.areaName)("dungeon"), (0, orders_1.areaName)("debug_yard")])
        strict_1.default.ok([...t].every((c) => font_1.FONT_GLYPHS.has(c)), t);
});
