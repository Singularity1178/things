"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The wild surface: builder determinism and reachability, the buried entrance
// (walkable, non-solid, readable), the dungeon's rock-choked SURFACE GATE, the
// overgrown rune's erosion / awakening model, and the v3 -> v4 save migration.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const surface_1 = require("../src/game/surface");
const map_1 = require("../src/game/map");
const tiles_1 = require("../src/game/content/tiles");
const props_1 = require("../src/game/content/props");
const harvest_1 = require("../src/game/content/harvest");
const geography_1 = require("../src/game/content/geography");
const reach_1 = require("../src/game/sim/reach");
const collision_1 = require("../src/game/sim/collision");
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const circle_1 = require("../src/game/circle");
const runeReveal_1 = require("../src/game/runeReveal");
const surfaceRune_1 = require("../src/game/surfaceRune");
const props_2 = require("../src/game/art/props");
const helpers_1 = require("./helpers");
const surfaceOf = (w = (0, helpers_1.newWorld)()) => (0, world_1.getArea)(w, "surface");
const boxesOf = (a) => a.props.filter(collision_1.propBlocks).map((p) => p.box);
const reachOf = (a) => (0, reach_1.reachable)(a, boxesOf(a), a.base.start);
// ------------------------------------------------------------------ builder
(0, node_test_1.test)("surface builder is deterministic", () => {
    const a = (0, surface_1.buildSurface)(), b = (0, surface_1.buildSurface)();
    strict_1.default.deepEqual([...a.grid], [...b.grid]);
    strict_1.default.deepEqual([...a.style], [...b.style]);
    strict_1.default.deepEqual(JSON.stringify([a.props, a.decals, a.lights, a.loose]), JSON.stringify([b.props, b.decals, b.lights, b.loose]));
    strict_1.default.equal(new Set(a.props.map((p) => p.id)).size, a.props.length, "prop ids are unique");
});
(0, node_test_1.test)("surface keeps its size, rune, start, ids and closing thicket edge", () => {
    const s = (0, surface_1.buildSurface)();
    strict_1.default.equal(s.id, "surface");
    strict_1.default.equal(s.w, 96);
    strict_1.default.equal(s.h, 72);
    const rune = s.props.find((p) => p.id === "rune.surface");
    strict_1.default.deepEqual([rune.x, rune.y], [surface_1.RUNE_T.x * tiles_1.TS + 8, surface_1.RUNE_T.y * tiles_1.TS + 8]);
    strict_1.default.ok(Math.hypot(s.start.x - rune.x, s.start.y - rune.y) < 12, "start beside the rune");
    strict_1.default.ok(s.loose.some((l) => l.id === "basket" && l.item === "basket"));
    strict_1.default.ok(s.props.some((p) => p.kind === "cart"));
    strict_1.default.ok(s.props.filter((p) => p.kind === "tree").length > 60 && s.props.some((p) => p.kind === "rock"), "harvestable trees and rocks");
    for (let x = 0; x < s.w; x++) {
        strict_1.default.equal(s.grid[x], tiles_1.T.THICKET);
        strict_1.default.equal(s.grid[(s.h - 1) * s.w + x], tiles_1.T.THICKET);
    }
    for (let y = 0; y < s.h; y++) {
        strict_1.default.equal(s.grid[y * s.w], tiles_1.T.THICKET);
        strict_1.default.equal(s.grid[y * s.w + s.w - 1], tiles_1.T.THICKET);
    }
});
(0, node_test_1.test)("the dungeon is hidden: no grates, no sinkholes, nothing glows but the rune (the stair's ward glyph is dark until it is dug out)", () => {
    // the wild as it was: the hunters' camp (new content, with a lit campfire) is left out here and checked below
    const s = (0, surface_1.buildSurface)({ camp: false });
    strict_1.default.ok(!("grate" in props_1.PROPS), "grate kind removed");
    strict_1.default.ok(!s.props.some((p) => p.kind === "grate"));
    strict_1.default.ok(s.grid.every((t) => t === tiles_1.T.FLOOR || t === tiles_1.T.THICKET), "only open ground and thicket (no PIT / wall / rubble tiles)");
    strict_1.default.deepEqual(s.lights.map((l) => l.id), ["runeglow", "wardglow"]);
    const ward = s.lights[1], head = s.props.find((p) => p.id === ward.owner);
    strict_1.default.equal(head.kind, "buriedgate");
    strict_1.default.equal((0, props_1.propDef)("buriedgate").light.when, "lit");
    strict_1.default.ok(!head.lit, "the ward's light is the stair head's, and that is not lit");
    strict_1.default.ok(!s.props.some((p) => { const L = (0, props_1.propDef)(p.kind).light; return L && (L.when === "always" || p.lit); }), "no glowing props");
    // The camp adds one light, the campfire's. Like every prop's light in every builder it names its owner, not an id
    // (the id-less light the full surface lists is this one), and it burns well away from the rune and the stair head.
    const real = (0, surface_1.buildSurface)(), fire = real.props.find((p) => p.id === "camp.fire");
    strict_1.default.deepEqual(real.lights.filter((l) => l.owner !== fire.id), s.lights, "every other light is as it was");
    const glow = real.lights.filter((l) => l.owner === fire.id);
    strict_1.default.equal(glow.length, 1);
    strict_1.default.equal(glow[0].id, undefined);
    strict_1.default.equal(fire.kind, "campfire");
    strict_1.default.ok(fire.lit);
    strict_1.default.deepEqual(real.props.filter((p) => { const L = (0, props_1.propDef)(p.kind).light; return L && (L.when === "always" || p.lit); }).map((p) => p.id), ["camp.fire"], "the only glowing prop is the campfire");
    for (const id of ["rune.surface", head.id]) {
        const o = real.props.find((p) => p.id === id);
        strict_1.default.ok(Math.hypot(o.x - glow[0].x, o.y - glow[0].y) > glow[0].rad * 2, `the fire's glow is nowhere near ${id}`);
    }
});
(0, node_test_1.test)("the wild has variety: several ground styles, overgrowth and a handful of remains", () => {
    const s = (0, surface_1.buildSurface)();
    const styles = new Set();
    for (let i = 0; i < s.grid.length; i++)
        if (s.grid[i] === tiles_1.T.FLOOR)
            styles.add(s.style[i]);
    strict_1.default.ok(styles.size >= 5, `ground styles: ${[...styles]}`);
    const kinds = new Set(s.props.map((p) => p.kind));
    for (const k of ["bush", "fern", "tallgrass", "sapling", "stump", "log", "boulder", "outcrop"])
        strict_1.default.ok(kinds.has(k), k);
    const remains = s.props.filter((p) => ["wallstub", "masonry", "stoneslab", "cairn", "standingstone", "statue_toppled"].includes(p.kind));
    strict_1.default.ok(remains.length >= 6 && remains.length <= 14, `remains: ${remains.length}`);
    const dk = new Set(s.decals.map((d) => d.kind));
    for (const k of ["hump", "mosspatch", "leaves", "ivy", "shade", "wildflowers", "weeds"])
        strict_1.default.ok(dk.has(k), k);
});
(0, node_test_1.test)("everything meaningful is reachable on foot, with no sealed pockets", () => {
    const a = surfaceOf(), r = reachOf(a);
    const rp = a.prop("rune.surface");
    strict_1.default.ok((0, reach_1.nearReached)(a, r, rp.x, rp.y + 4, 0), "rune");
    const basket = a.loose.find((l) => l.id === "basket");
    strict_1.default.ok((0, reach_1.nearReached)(a, r, basket.x, basket.y), "basket");
    const cart = a.props.find((p) => p.kind === "cart");
    strict_1.default.ok((0, reach_1.nearReached)(a, r, cart.x, cart.y + 8), "cart");
    for (let y = geography_1.SURFACE_GATE_ZONE.y0; y <= geography_1.SURFACE_GATE_ZONE.y1; y++)
        for (let x = geography_1.SURFACE_GATE_ZONE.x0; x <= geography_1.SURFACE_GATE_ZONE.x1; x++)
            strict_1.default.equal(r[y * a.w + x], 1, `entrance cell ${x},${y}`);
    for (const p of a.props)
        if (harvest_1.HARVEST[p.kind] || (0, props_1.propDef)(p.kind).examine)
            strict_1.default.ok((0, reach_1.nearReached)(a, r, p.x, p.y - 4), `${p.id} can be walked up to`);
    // no sealed pockets: every cell the golem could stand in is connected
    let pockets = 0;
    for (let ty = 0; ty < a.h; ty++)
        for (let tx = 0; tx < a.w; tx++) {
            const f = (0, reach_1.cellFeet)(tx, ty);
            if (!r[ty * a.w + tx] && (0, collision_1.boxFree)(a, f.x, f.y))
                pockets++;
        }
    strict_1.default.equal(pockets, 0);
});
(0, node_test_1.test)("nothing from the wild overlaps the rune circle's footprint", () => {
    const s = (0, surface_1.buildSurface)(), rc = { x: surface_1.RUNE_T.x * tiles_1.TS + 8, y: surface_1.RUNE_T.y * tiles_1.TS + 8 };
    for (const p of s.props)
        if (p.id !== "rune.surface")
            strict_1.default.ok(Math.hypot(p.x - rc.x, p.y - rc.y) >= surface_1.RUNE_CLEAR_PROPS * tiles_1.TS, p.id);
    for (const d of s.decals)
        strict_1.default.ok(Math.hypot(d.x - rc.x, d.y - rc.y) > surface_1.RUNE_ART_R + 6, `${d.kind} at ${d.x},${d.y}`);
});
// ------------------------------------------------------------------ entrance
(0, node_test_1.test)("one shared offset maps the dungeon's SURFACE STAIR onto the surface", () => {
    strict_1.default.deepEqual(geography_1.DUNGEON_TO_SURFACE, { dx: 12, dy: 6 });
    const d = (0, map_1.buildDungeon)();
    const ex = d.exits.find((e) => e.label === "SURFACE STAIR");
    strict_1.default.deepEqual({ x: ex.x, y: ex.y }, geography_1.GATE_EXIT, "schematic exit marker");
    strict_1.default.deepEqual((0, geography_1.dungeonToSurface)(geography_1.GATE_EXIT.x, geography_1.GATE_EXIT.y), { x: 48, y: 61 });
    strict_1.default.deepEqual(geography_1.SURFACE_GATE, { x: 48, y: 61 });
    // the corridor's walls (x-1 and x+w) bound the surface entrance zone
    strict_1.default.equal(geography_1.SURFACE_GATE_ZONE.x0, geography_1.GATE_CORRIDOR.x - 1 + geography_1.DUNGEON_TO_SURFACE.dx);
    strict_1.default.equal(geography_1.SURFACE_GATE_ZONE.x1, geography_1.GATE_CORRIDOR.x + geography_1.GATE_CORRIDOR.w + geography_1.DUNGEON_TO_SURFACE.dx);
    const s = (0, surface_1.buildSurface)();
    const gate = s.props.find((p) => p.kind === "buriedgate");
    strict_1.default.deepEqual([Math.floor(gate.x / tiles_1.TS), Math.floor((gate.y - 1) / tiles_1.TS)], [geography_1.SURFACE_GATE.x, geography_1.SURFACE_GATE.y]);
});
(0, node_test_1.test)("the buried entrance is plain floor with no solid prop on it", () => {
    const a = surfaceOf();
    const z = geography_1.SURFACE_GATE_ZONE, x0 = z.x0 * tiles_1.TS, x1 = (z.x1 + 1) * tiles_1.TS, y0 = z.y0 * tiles_1.TS, y1 = (z.y1 + 1) * tiles_1.TS;
    for (let y = z.y0; y <= z.y1; y++)
        for (let x = z.x0; x <= z.x1; x++)
            strict_1.default.equal(a.tile(x, y), tiles_1.T.FLOOR);
    for (const p of a.props) {
        const b = p.box;
        if (b && (0, collision_1.propBlocks)(p))
            strict_1.default.ok(b[2] <= x0 || b[0] >= x1 || b[3] <= y0 || b[1] >= y1, `${p.id} blocks the entrance`);
    }
    strict_1.default.equal((0, props_1.propDef)("buriedgate").box, undefined);
    strict_1.default.equal((0, props_1.propDef)("buriedgate").flat, true);
    strict_1.default.equal((0, props_1.propDef)("capstone").box, undefined);
});
(0, node_test_1.test)("the golem walks straight across the buried gate, and the ground sounds hollow", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, world_1.enterArea)(w, pl, "surface", geography_1.SURFACE_GATE.x * tiles_1.TS + 8, geography_1.SURFACE_GATE_ZONE.y0 * tiles_1.TS - 6);
    pl.facing = "down";
    const y0 = pl.y;
    (0, helpers_1.frames)(w, 60 * 14, { ix: 0, iy: 1, use: false });
    strict_1.default.ok(pl.y > (geography_1.SURFACE_GATE.y + 1) * tiles_1.TS, `walked from ${y0} to ${pl.y}`);
    (0, helpers_1.events)(w);
    // E on it with no shovel head fitted digs nothing: the golem only learns what it would take
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "dig" && (0, world_1.currentArea)(w).prop(i.propId).kind === "buriedgate"));
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "message" && /HOLLOW/.test(e.text) && /SHOVEL/.test(e.text)));
    strict_1.default.equal((0, world_1.currentArea)(w).props.find((p) => p.kind === "buriedgate").dmg, 0);
});
(0, node_test_1.test)("in the dungeon, the SURFACE GATE corridor is solid rock and can't be entered", () => {
    const w = (0, helpers_1.newWorld)(), d = (0, world_1.getArea)(w, "dungeon");
    const C = geography_1.GATE_CORRIDOR;
    for (let y = C.y; y < C.y + C.h; y++)
        for (let x = C.x; x < C.x + C.w; x++)
            strict_1.default.notEqual(d.tile(x, y), tiles_1.T.FLOOR, `${x},${y}`);
    strict_1.default.ok(d.props.filter((p) => p.kind === "rockpile").length >= 8, "heaped rock piles");
    strict_1.default.ok(d.decals.some((dc) => dc.kind === "earthspill") && d.decals.some((dc) => dc.kind === "rootfall"));
    const r = (0, reach_1.reachable)(d, boxesOf(d), d.base.start);
    // Nothing from the corridor's first row down (walls included) is reachable.
    // Row C.y - 1 is the Vestibule's own bottom floor row: the builder heaps
    // rubble on its outer tiles but leaves the corridor mouth open, so the golem
    // can walk up to the rock face (pinned below), just not into the corridor.
    for (let y = C.y; y < d.h; y++)
        for (let x = C.x - 1; x <= C.x + C.w; x++)
            strict_1.default.equal(r[y * d.w + x], 0, `reached ${x},${y}`);
    for (const x of [C.x - 1, C.x, C.x + C.w - 1, C.x + C.w])
        strict_1.default.equal(d.tile(x, C.y - 1), tiles_1.T.RUBBLE, `rubble at ${x},${C.y - 1}`);
    strict_1.default.equal(r[(C.y - 1) * d.w + C.x + 1], 1, "the corridor mouth in the Vestibule is reachable");
    // the Vestibule itself is still walkable
    strict_1.default.equal(r[46 * d.w + 33], 1);
});
// ------------------------------------------------------------------ rune
const model = (0, runeReveal_1.runeModel)((0, circle_1.circlePixels)());
const visibleSet = (t) => new Set(model.pixels.flatMap((p, i) => ((0, runeReveal_1.carvingVisible)(p, t) ? [i] : [])));
(0, node_test_1.test)("dormant rune: only a low fraction of carvings survive, in worn contiguous stretches", () => {
    const surv = model.pixels.filter((p) => p.survives);
    const f = surv.length / model.pixels.length;
    strict_1.default.ok(f > 0.05 && f < 0.3, `surviving fraction ${f.toFixed(3)} (target ${runeReveal_1.RUNE_SURVIVE})`);
    const at = new Set(surv.map((p) => `${p.x},${p.y}`));
    const lonely = surv.filter((p) => ![-1, 0, 1].some((j) => [-1, 0, 1].some((i) => (i || j) && at.has(`${p.x + i},${p.y + j}`)))).length;
    strict_1.default.ok(lonely / surv.length < 0.1, `isolated survivors ${lonely}/${surv.length}`);
    strict_1.default.equal(visibleSet(0).size, surv.length);
    strict_1.default.deepEqual(model, (0, runeReveal_1.runeModel)((0, circle_1.circlePixels)()), "deterministic");
});
(0, node_test_1.test)("plants grow where the carvings are missing", () => {
    const plantAt = new Set();
    for (const c of model.clumps)
        for (const px of c.px)
            if ((0, runeReveal_1.plantVisible)(model, c, px, 0))
                plantAt.add(`${px.x},${px.y}`);
    const missing = model.pixels.filter((p) => !p.survives);
    const covered = missing.filter((p) => [-1, 0, 1].some((j) => [-1, 0, 1].some((i) => plantAt.has(`${p.x + i},${p.y + j}`)))).length;
    strict_1.default.ok(covered / missing.length > 0.95, `covered ${covered}/${missing.length}`);
});
(0, node_test_1.test)("awakening sweep is monotonic and ends on the full carved circle", () => {
    let prev = visibleSet(0), prevPlants = Infinity;
    for (let k = 1; k <= 50; k++) {
        const t = k / 50, cur = visibleSet(t);
        for (const i of prev)
            strict_1.default.ok(cur.has(i), `carving ${i} vanished at ${t}`);
        let plants = 0;
        for (const c of model.clumps)
            for (const px of c.px) {
                if (!(0, runeReveal_1.plantVisible)(model, c, px, t))
                    continue;
                plants++;
                const kk = model.carvedAt[(px.y + 64) * 128 + px.x + 64];
                strict_1.default.ok(!(kk < 2 && (kk < 0 || kk <= t)), "no plant drawn over a visible carving");
            }
        strict_1.default.ok(plants <= prevPlants, "plants only ever clear");
        for (const c of model.clumps)
            if ((0, runeReveal_1.clumpCleared)(c, t - 1 / 50) && t - 1 / 50 > 0)
                strict_1.default.ok((0, runeReveal_1.clumpCleared)(c, t));
        prev = cur;
        prevPlants = plants;
    }
    strict_1.default.equal(visibleSet(1).size, model.pixels.length, "fully redrawn");
    strict_1.default.ok(model.clumps.every((c) => c.persist || (0, runeReveal_1.clumpCleared)(c, 1)), "only rim growth outside the circle remains");
    strict_1.default.ok(model.clumps.some((c) => c.persist));
});
(0, node_test_1.test)("rune layers smoke-render at 0, 0.5 and 1 through the fake canvas, ends cached", () => {
    const art = new surfaceRune_1.SurfaceRuneArt((0, circle_1.circlePixels)());
    for (const t of [0, 0.5, 1]) {
        const l = art.layers(t);
        strict_1.default.ok(l.scene && l.emit);
    }
    strict_1.default.equal(art.layers(0), art.layers(0));
    strict_1.default.equal(art.layers(1), art.layers(1));
    (0, fakeCanvas_1.resetTrace)();
    art.layers(0);
    art.layers(1);
    strict_1.default.equal((0, fakeCanvas_1.traceHash)(), "811c9dc5", "cached ends issue no draw calls");
    (0, fakeCanvas_1.resetTrace)();
    art.layers(0.25);
    const h = (0, fakeCanvas_1.traceHash)();
    art.layers(0.25);
    strict_1.default.equal((0, fakeCanvas_1.traceHash)(), h, "same progress is not re-rasterised");
});
(0, node_test_1.test)("new surface and gate sprites all render (additive art)", () => {
    const kinds = ["buriedgate", "bush", "fern", "tallgrass", "sapling", "stump", "log", "boulder", "outcrop", "wallstub", "masonry",
        "stoneslab", "cairn", "standingstone", "statue_toppled", "capstone", "rockpile"];
    for (const k of kinds)
        for (let v = 0; v < 4; v++)
            for (const alt of [false, true])
                strict_1.default.ok((0, props_2.propSprite)(k, v, alt), `${k} v${v}`);
    for (const v of [2, 3])
        strict_1.default.ok((0, props_2.propSprite)("rock", v, false), "mossy rock");
});
// ------------------------------------------------------------------ saves
(0, node_test_1.test)("a v3 save's stale surface diff is discarded; the player's things survive", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, world_1.getArea)(w, "surface");
    const s = (0, save_1.serialize)(w);
    (0, world_1.enterArea)(w, pl, "surface", 30 * tiles_1.TS, 40 * tiles_1.TS);
    const v3 = {
        ...JSON.parse(JSON.stringify(s)), version: 3,
        actors: s.actors.map((a) => ({ ...a, area: "surface", x: 30 * tiles_1.TS, y: 40 * tiles_1.TS, task: { kind: "reach", t: 0, dur: 1, effect: { op: "cue", cue: "scrape" }, area: "surface" } })),
        scheduled: [...s.scheduled, { at: 99, actor: pl.id, area: "surface", effect: { op: "regrow", prop: "tree@31,40" } }],
    };
    v3.areas.surface = {
        tiles: [[40 * 96 + 30, tiles_1.T.RUBBLE]], props: { "tree@31,40": { dmg: 2 }, "grate@44,34": { taken: true } },
        looseTaken: ["basket"], looseAdded: [{ id: "drop0", item: "coin", x: 30 * tiles_1.TS, y: 41 * tiles_1.TS }], looseSeq: 1,
        propsAdded: [{ id: "torch_post#b0", kind: "torch_post", x: 30 * tiles_1.TS, y: 42 * tiles_1.TS, v: 0, lit: true }], propSeq: 1, decalsAdded: [{ kind: "debris", x: 1, y: 1, v: 0 }], ritual: null,
    };
    const w2 = (0, save_1.deserialize)(v3), a = (0, world_1.getArea)(w2, "surface"), p2 = (0, world_1.player)(w2);
    strict_1.default.deepEqual([...a.grid], [...a.base.grid], "old tile edits dropped");
    strict_1.default.equal(a.decals.length, a.base.decals.length);
    strict_1.default.ok(a.looseItem("basket").taken, "basket stays picked up");
    const onGround = a.loose.filter((l) => !l.taken && l.dyn).map((l) => `${l.item}x${l.n ?? 1}`).sort();
    strict_1.default.deepEqual(onGround, ["coinx1", "stonex1", "woodx2"], "dropped coin kept, torch refunded");
    const rp = a.prop("rune.surface");
    strict_1.default.ok(Math.hypot(p2.x - rp.x, p2.y - rp.y) < 12 && (0, collision_1.boxFree)(a, p2.x, p2.y) && !p2.task, "player moved to the rune");
    strict_1.default.ok(!w2.scheduled.some((e) => e.area === "surface"));
    strict_1.default.ok((0, reach_1.nearReached)(a, reachOf(a), a.loose.find((l) => l.item === "coin").x, a.loose.find((l) => l.item === "coin").y), "refunds reachable");
    // and it round-trips at the current version
    strict_1.default.deepEqual((0, save_1.serialize)((0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w2))))), (0, save_1.serialize)(w2));
});
