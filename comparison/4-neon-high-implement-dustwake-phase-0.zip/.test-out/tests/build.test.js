"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Building overhaul: catalog data, wall placement, gating, built-prop saves,
// the crafting bench's station path, and deconstruction (refunds, overflow,
// caches, persistence of removed authored props, refusals).
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const inventory_1 = require("../src/game/sim/inventory");
const commands_1 = require("../src/game/sim/commands");
const build_1 = require("../src/game/sim/build");
const tasks_1 = require("../src/game/sim/tasks");
const interact_1 = require("../src/game/sim/interact");
const catalog_1 = require("../src/game/sim/catalog");
const crafting_1 = require("../src/game/sim/crafting");
const crafting_2 = require("../src/game/screens/crafting");
const screens_1 = require("../src/game/ui/screens");
const build_2 = require("../src/game/content/build");
const crafting_3 = require("../src/game/content/crafting");
const props_1 = require("../src/game/content/props");
const props_2 = require("../src/game/art/props");
const flags_1 = require("../src/game/content/flags");
const font_1 = require("../src/game/font");
const tiles_1 = require("../src/game/content/tiles");
const areaView_1 = require("../src/game/view/areaView");
const helpers_1 = require("./helpers");
const debug_1 = require("../src/game/sim/debug");
// ------------------------------------------------------------------ fixtures
const finish = (w) => { let g = 0; while ((0, world_1.player)(w).task && g++ < 600)
    (0, helpers_1.frame)(w); };
const kit = (w, wood = 30, stone = 30, planks = 30, cut = 30) => {
    // A builder who has also read every plan (analysis gating has its own tests: tests/rollout.test.ts).
    const pl = (0, world_1.player)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    (0, debug_1.learnAllPlans)(w);
    (0, inventory_1.addItems)(w, pl, "wood", wood);
    (0, inventory_1.addItems)(w, pl, "stone", stone);
    (0, inventory_1.addItems)(w, pl, "planks", planks);
    (0, inventory_1.addItems)(w, pl, "cut_stone", cut);
};
/** In the dungeon's translocation room, below a free plain wall face on row 2. */
function atWallFace(w) {
    const a = (0, world_1.currentArea)(w), pl = (0, world_1.player)(w);
    (0, helpers_1.frame)(w);
    for (let tx = 9; tx <= 13; tx++) {
        if (a.tile(tx, 2) === tiles_1.T.WALL && a.tile(tx, 3) === tiles_1.T.FLOOR && a.tile(tx, 4) === tiles_1.T.FLOOR && (0, build_1.siteFor)(w, a, "wall_torch", tx, 2).ok) {
            pl.x = tx * tiles_1.TS + 8;
            pl.y = 4 * tiles_1.TS + 12;
            pl.facing = "up";
            return { a, pl, tx, ty: 2 };
        }
    }
    throw new Error("no free wall face in the translocation room");
}
/** On the surface, standing in a cleared 9x9 patch of open ground. */
function inClearing(w) {
    const pl = (0, world_1.player)(w);
    (0, helpers_1.frame)(w);
    (0, world_1.enterArea)(w, pl, "surface", 20 * tiles_1.TS + 8, 50 * tiles_1.TS + 14);
    const a = (0, world_1.currentArea)(w);
    for (let ty = 46; ty <= 54; ty++)
        for (let tx = 16; tx <= 24; tx++)
            a.setTile(tx, ty, tiles_1.T.FLOOR);
    for (const p of [...a.props])
        if (Math.abs(p.x - pl.x) < 96 && Math.abs(p.y - pl.y) < 96)
            a.removeProp(p.id);
    pl.facing = "down";
    return { a, pl };
}
const roundTrip = (w) => (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
// ------------------------------------------------------------------ data
(0, node_test_1.test)("catalog data: every recipe has a prop kind with art, a known category, and valid font text", () => {
    const cats = new Set(build_2.BUILD_CATEGORIES.map((c) => c.id));
    const ok = (s) => [...s].every((ch) => font_1.FONT_GLYPHS.has(ch));
    for (const [id, r] of Object.entries(build_2.RECIPES)) {
        strict_1.default.ok(props_1.PROPS[r.prop], `${id}: prop kind ${r.prop}`);
        strict_1.default.ok(props_2.PROP_ART[props_1.PROPS[r.prop].art ?? r.prop], `${id}: sprite for ${r.prop}`); // a kind may borrow art (the storage chest: the chest's)
        strict_1.default.ok(cats.has(r.category), `${id}: category`);
        strict_1.default.ok(ok(r.name) && r.name.length <= 24, `${id}: name "${r.name}"`);
        strict_1.default.ok(r.desc.length <= 3 && r.desc.every((l) => ok(l) && l.length <= 34), `${id}: desc`);
        strict_1.default.ok(r.cost.length > 0 && r.cost.every((c) => c.n > 0));
    }
    for (const r of crafting_3.CRAFT_RECIPES)
        strict_1.default.ok(ok(r.name) && r.desc.every((l) => ok(l) && l.length <= 30), `craft ${r.id}`);
    // Specified costs and the shared wall-torch prop.
    strict_1.default.deepEqual(build_2.RECIPES.wall_torch.cost, [{ item: "cut_stone", n: 1 }, { item: "wood", n: 1 }]);
    strict_1.default.deepEqual(build_2.RECIPES.torch_post.cost, [{ item: "wood", n: 2 }, { item: "stone", n: 1 }]);
    strict_1.default.equal(build_2.RECIPES.wall_torch.prop, "torch");
    strict_1.default.equal(build_2.RECIPES.wall_torch.place, "wall");
    strict_1.default.ok(props_1.PROPS.torch.wallMounted);
    // Every kind a recipe builds opts in among authored props (derived from the catalog).
    strict_1.default.deepEqual(Object.keys(build_2.AUTHORED_SALVAGE).sort(), Object.values(build_2.RECIPES).map((r) => r.prop).sort());
    // The crafting bench IS the dungeon's workbench: same prop kind, same sprite, one station. No second kind.
    strict_1.default.equal(build_2.RECIPES.craftbench.prop, "workbench");
    strict_1.default.equal(props_1.PROPS.workbench.station, "crafting");
    strict_1.default.ok(!("craftbench" in props_1.PROPS) && !("craftbench" in props_2.PROP_ART), "no separate craftbench kind or sprite");
});
// ------------------------------------------------------------------ wall placement
(0, node_test_1.test)("wall torch: valid only on a plain wall face with floor below; failing cases name the reason", () => {
    const w = (0, helpers_1.newWorld)();
    kit(w);
    const { a, pl, tx, ty } = atWallFace(w);
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "wall_torch", tx, ty), { ok: true });
    // the floor in front of the wall is not a wall
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "wall_torch", tx, ty + 1), { ok: false, reason: "noWall" });
    // wall with more wall below: no visible face
    strict_1.default.equal(a.tile(tx, ty - 1), tiles_1.T.WALL);
    strict_1.default.deepEqual((0, build_1.siteFor)(w, a, "wall_torch", tx, ty - 1), { ok: false, reason: "wallFace" });
    // the authored torch's face is taken (pl stands below it)
    pl.x = 7 * tiles_1.TS + 8;
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "wall_torch", 7, 2), { ok: false, reason: "occupied" });
    // a wall face out of reach
    pl.x = tx * tiles_1.TS + 8;
    pl.y = 8 * tiles_1.TS + 12;
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "wall_torch", tx, ty), { ok: false, reason: "reach" });
    // the tutorial's cracked wall (and doors, pillars, rubble) never count as walls
    const ca = (0, world_1.currentArea)(w);
    strict_1.default.equal(ca.tile(47, 10), tiles_1.T.CRACKED);
    strict_1.default.deepEqual((0, build_1.siteFor)(w, ca, "wall_torch", 47, 10), { ok: false, reason: "noWall" });
    // the floor torch post is the opposite: never on a wall
    pl.y = 4 * tiles_1.TS + 12;
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "torch_post", tx, ty), { ok: false, reason: "solid" });
    // the surface has no masonry walls at all: no site anywhere for a wall torch
    const { a: sa } = inClearing(w);
    let any = false;
    for (let y = 0; y < sa.h && !any; y++)
        for (let x = 0; x < sa.w && !any; x++)
            any = (0, build_1.siteFor)(w, sa, "wall_torch", x, y).ok;
    strict_1.default.equal(any, false);
});
(0, node_test_1.test)("the placement ghost snaps a wall torch to the nearest free wall face", () => {
    const w = (0, helpers_1.newWorld)();
    kit(w);
    const { a, pl, tx, ty } = atWallFace(w);
    pl.facing = "down";
    const s = (0, build_1.suggestTile)(w, pl, a, "wall_torch");
    strict_1.default.ok((0, build_1.siteFor)(w, a, "wall_torch", s.tx, s.ty).ok);
    strict_1.default.equal(s.ty, ty);
    strict_1.default.ok(Math.abs(s.tx - tx) <= 2);
});
(0, node_test_1.test)("a built wall torch is the authored torch prop: lit, same kind, light reconciled, mounted at the wall anchor", () => {
    const w = (0, helpers_1.newWorld)();
    kit(w, 1, 0, 0, 1);
    const { a, pl, tx, ty } = atWallFace(w);
    const view = new areaView_1.AreaView(a);
    strict_1.default.ok((0, commands_1.orderBuild)(w, pl, "wall_torch", tx, ty));
    finish(w);
    const p = a.props.find((q) => q.dyn && q.kind === "torch");
    strict_1.default.ok(p && p.lit && p.recipe === "wall_torch");
    strict_1.default.deepEqual([p.x, p.y], [tx * tiles_1.TS + 8, ty * tiles_1.TS + 16], "same anchor the dungeon builder uses");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 0);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "cut_stone"), 0);
    view.flush();
    strict_1.default.ok(view.lights.has("prop:" + p.id));
    // the face is now taken
    strict_1.default.deepEqual((0, build_1.siteFor)(w, a, "wall_torch", tx, ty), { ok: false, reason: "occupied" });
});
// ------------------------------------------------------------------ gating
(0, node_test_1.test)("cost and knowledge gating for the new recipes (and the catalog's locked entries)", () => {
    const w = (0, helpers_1.newWorld)();
    const { a, pl } = inClearing(w);
    const tx = 20, ty = 52;
    for (const id of ["wall_torch", "craftbench", "barricade", "table", "chair", "wall_banner", "brazier"])
        strict_1.default.equal((0, catalog_1.entryFor)(w, pl, id).status, "unknown", id);
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "craftbench", tx, ty), { ok: false, reason: "unknown" });
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    // knowing how to build is not enough for an analysis-gated plan: the reason says what to scan, and that vision is Z
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "craftbench", tx, ty), { ok: false, reason: "unknown" });
    strict_1.default.equal((0, catalog_1.entryFor)(w, pl, "craftbench").lock, "analysis");
    strict_1.default.equal((0, catalog_1.entryReason)((0, catalog_1.entryFor)(w, pl, "craftbench")), "SCAN A CRAFTING BENCH IN VISION (Z)");
    (0, debug_1.learnAllPlans)(w);
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "craftbench", tx, ty), { ok: false, reason: "cost" });
    (0, inventory_1.addItems)(w, pl, "wood", 5);
    (0, inventory_1.addItems)(w, pl, "stone", 2);
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "craftbench", tx, ty), { ok: false, reason: "cost" }, "6 wood needed");
    const e = (0, catalog_1.entryFor)(w, pl, "craftbench");
    strict_1.default.equal(e.status, "cost");
    strict_1.default.equal((0, catalog_1.entryReason)(e), "NEED 1 WOOD MORE");
    (0, inventory_1.addItems)(w, pl, "wood", 1);
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "craftbench", tx, ty), { ok: true });
    // the brazier needs masonry on top of know.build: listed, but locked
    (0, inventory_1.addItems)(w, pl, "stone", 6);
    (0, inventory_1.addItems)(w, pl, "cut_stone", 4);
    strict_1.default.equal((0, catalog_1.entryFor)(w, pl, "brazier").status, "unknown");
    strict_1.default.equal((0, catalog_1.entryReason)((0, catalog_1.entryFor)(w, pl, "brazier")), "UNKNOWN RECIPE - NOT YET LEARNED");
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "brazier", tx, ty), { ok: false, reason: "unknown" });
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowMasonry);
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "brazier", tx, ty), { ok: true });
    // a hidden-until-known recipe is not listed at all until learned
    const secret = { ...build_2.RECIPES, secret: { ...build_2.RECIPES.chair, name: "SECRET", requires: { flags: ["know.secret"] }, unknown: "hidden" } };
    strict_1.default.ok(!(0, catalog_1.catalogEntries)(w, pl, secret).some((x) => x.id === "secret"));
    (0, world_1.setFlag)(w, "know.secret");
    strict_1.default.ok((0, catalog_1.catalogEntries)(w, pl, secret).some((x) => x.id === "secret"));
});
(0, node_test_1.test)("floor footprints: wide props need every tile of their box clear", () => {
    const w = (0, helpers_1.newWorld)();
    kit(w);
    const { a, pl } = inClearing(w);
    const tx = 20, ty = 52;
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "table", tx, ty), { ok: true });
    a.setTile(tx + 1, ty, tiles_1.T.RUBBLE);
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "table", tx, ty), { ok: false, reason: "solid" }, "the table spills into the next tile");
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "chair", tx, ty), { ok: true }, "a chair fits in one tile");
    a.setTile(tx + 1, ty, tiles_1.T.FLOOR);
    // the builder's own tile is occupied
    strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, "barricade", 20, 50), { ok: false, reason: "occupied" });
});
// ------------------------------------------------------------------ saves
(0, node_test_1.test)("every new buildable builds through the task path and round-trips through save/load", () => {
    const w = (0, helpers_1.newWorld)();
    w.actors.find((a) => a.id === w.playerId).gear.back = "basket";
    kit(w, 60, 60);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowMasonry);
    const { a, pl } = inClearing(w);
    (0, helpers_1.frame)(w);
    const spots = [["craftbench", 18, 48], ["table", 22, 48], ["chair", 18, 52], ["barricade", 22, 52], ["brazier", 20, 52], ["torch_post", 21, 49]];
    for (const [id, tx, ty] of spots) {
        strict_1.default.deepEqual((0, build_1.placement)(w, pl, a, id, tx, ty), { ok: true }, id);
        strict_1.default.ok((0, commands_1.orderBuild)(w, pl, id, tx, ty), id);
        finish(w);
    }
    const built = a.props.filter((p) => p.dyn);
    strict_1.default.deepEqual(built.map((p) => p.recipe).sort(), spots.map((s) => s[0]).sort());
    strict_1.default.ok(built.find((p) => p.kind === "brazier").lit);
    const w2 = roundTrip(w);
    strict_1.default.deepEqual((0, save_1.serialize)(w2), (0, save_1.serialize)(w));
    const a2 = (0, world_1.currentArea)(w2);
    for (const p of built) {
        const q = a2.prop(p.id);
        strict_1.default.ok(q && q.dyn, p.id);
        strict_1.default.deepEqual([q.kind, q.x, q.y, q.recipe, !!q.lit, q.box], [p.kind, p.x, p.y, p.recipe, !!p.lit, p.box]);
    }
    const v = new areaView_1.AreaView(a2);
    v.flush();
    strict_1.default.ok(v.lights.has("prop:" + built.find((p) => p.kind === "brazier").id));
});
(0, node_test_1.test)("v5 -> v6 migration: areas gain propsRemoved, pending 'torch' build work becomes 'torch_post'", () => {
    const w = (0, helpers_1.newWorld)();
    const s = (0, save_1.serialize)(w);
    s.version = 5;
    for (const d of Object.values(s.areas))
        delete d.propsRemoved;
    s.actors[0].task = { kind: "reach", dur: 0.7, t: 0.1, fired: false, effect: { op: "build", recipe: "torch", tx: 3, ty: 4 }, area: "dungeon" };
    const m = (0, save_1.migrate)(s);
    strict_1.default.equal(m.version, save_1.SAVE_VERSION);
    strict_1.default.equal(m.actors[0].task.effect.recipe, "torch_post");
    for (const d of Object.values(m.areas))
        strict_1.default.deepEqual(d.propsRemoved, []);
    strict_1.default.ok((0, save_1.deserialize)(s));
});
(0, node_test_1.test)("v6 -> v7 migration: a saved crafting bench becomes the workbench prop, keeping its id, recipe and station", () => {
    const w = (0, helpers_1.newWorld)();
    kit(w);
    const { a, pl } = inClearing(w);
    strict_1.default.ok((0, commands_1.orderBuild)(w, pl, "craftbench", 20, 52));
    finish(w);
    const bench = a.props.find((p) => p.dyn && p.kind === "workbench");
    // what a v6 save looked like: the bench was its own `craftbench` kind
    const s = (0, save_1.serialize)(w);
    s.version = 6;
    s.areas.surface.propsAdded.find((p) => p.id === bench.id).kind = "craftbench";
    const m = (0, save_1.migrate)(s);
    strict_1.default.equal(m.version, save_1.SAVE_VERSION);
    const moved = m.areas.surface.propsAdded.find((p) => p.id === bench.id);
    strict_1.default.deepEqual([moved.kind, moved.recipe], ["workbench", "craftbench"], "only the kind changes; the recipe id keeps its name");
    strict_1.default.ok(!m.areas.surface.propsAdded.some((p) => p.kind === "craftbench"));
    const w2 = (0, save_1.deserialize)(s), a2 = (0, world_1.currentArea)(w2);
    const b2 = a2.prop(bench.id);
    strict_1.default.ok(b2 && b2.dyn && b2.kind === "workbench" && b2.recipe === "craftbench");
    strict_1.default.equal((0, interact_1.interactables)(a2).find((i) => i.propId === bench.id).kind, "station");
    const expected = (0, save_1.serialize)(w);
    for (const f of ["wall_torch", "brazier", "craftbench", "table", "chair", "wall_banner"].map((id) => `analysis.${id}`))
        if (!expected.flags.includes(f))
            expected.flags.push(f);
    strict_1.default.deepEqual((0, save_1.serialize)(w2), expected, "same world, plus v10's frozen legacy analysis grants");
});
// ------------------------------------------------------------------ crafting bench
(0, node_test_1.test)("the built crafting bench is a workbench: interactable, and opens its UI through the normal rule + task path", () => {
    const w = (0, helpers_1.newWorld)();
    kit(w);
    const { a, pl } = inClearing(w);
    strict_1.default.ok((0, commands_1.orderBuild)(w, pl, "craftbench", 20, 52));
    finish(w);
    const bench = a.props.find((p) => p.dyn && p.kind === "workbench");
    strict_1.default.equal(bench.recipe, "craftbench");
    const it = (0, interact_1.interactables)(a).find((i) => i.propId === bench.id);
    strict_1.default.equal(it.kind, "station");
    (0, helpers_1.events)(w);
    (0, helpers_1.useOn)(w, it);
    const ev = (0, helpers_1.events)(w).find((e) => e.t === "openStation");
    strict_1.default.deepEqual(ev, { t: "openStation", actor: pl.id, prop: bench.id, station: "crafting" });
    // the bench lists the real plans and CRAFT starts work at this very bench
    const list = (0, crafting_1.craftEntries)(w, pl, "crafting");
    strict_1.default.equal(list.length, crafting_3.CRAFT_RECIPES.filter((r) => r.station === "crafting").length);
    strict_1.default.equal(list.find((e) => e.recipe.id === "planks").status, "ok");
    strict_1.default.equal((0, crafting_1.orderCraft)(w, pl, "crafting", "planks", bench.id), true);
    strict_1.default.equal(pl.task.kind, "craft");
});
(0, node_test_1.test)("the dungeon's workbench gives up its chisel first, then works as a crafting bench", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    const a = (0, world_1.currentArea)(w), pl = (0, world_1.player)(w);
    const id = "workbench@13.5,37";
    // chisel still on it: the pickup is what is offered (the tutorial depends on this)
    strict_1.default.equal((0, interact_1.interactables)(a).find((i) => i.propId === id).kind, "propItem");
    strict_1.default.ok(!(0, interact_1.interactables)(a).some((i) => i.kind === "station" && i.propId === id), "(the smelter and the anvil are stations of their own: tests/smithing.test.ts)");
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, id));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "chisel"), 1);
    // chisel gone: the same prop is now a station, and using it opens the crafting UI
    const it = (0, interact_1.interactables)(a).find((i) => i.propId === id);
    strict_1.default.equal(it.kind, "station");
    (0, helpers_1.events)(w);
    (0, helpers_1.useOn)(w, it);
    strict_1.default.deepEqual((0, helpers_1.events)(w).find((e) => e.t === "openStation"), { t: "openStation", actor: pl.id, prop: id, station: "crafting" });
    // and, like every buildable, it can now be taken apart for the crafting bench's cost (tests/salvage.test.ts)
    strict_1.default.deepEqual((0, build_1.salvageOf)(a.prop(id)), build_2.RECIPES.craftbench.cost);
});
(0, node_test_1.test)("without the knowledge to build, a workbench still opens but nothing is viewable or craftable", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    const a = (0, world_1.currentArea)(w), pl = (0, world_1.player)(w);
    const id = "workbench@13.5,37";
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, id)); // the chisel
    strict_1.default.ok(!(0, world_1.hasFlag)(w, flags_1.FLAGS.knowBuild));
    strict_1.default.ok((0, crafting_1.craftLocked)(w, pl, "crafting"));
    strict_1.default.deepEqual((0, crafting_1.craftEntries)(w, pl, "crafting"), [], "no plans are listed, not even greyed ones");
    // using it is not refused: the station still opens (the screen shows it greyed out)
    (0, helpers_1.events)(w);
    (0, helpers_1.useOn)(w, (0, interact_1.interactables)(a).find((i) => i.propId === id));
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "openStation"));
    // and CRAFT, even for a real plan id, only says why
    (0, helpers_1.events)(w);
    strict_1.default.equal((0, crafting_1.orderCraft)(w, pl, "crafting", "planks"), false);
    strict_1.default.deepEqual((0, helpers_1.events)(w), [{ t: "message", text: crafting_1.CRAFT_LOCKED_TEXT }]);
    // learning to build unlocks the plans
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    strict_1.default.ok(!(0, crafting_1.craftLocked)(w, pl, "crafting"));
    strict_1.default.equal((0, crafting_1.craftEntries)(w, pl, "crafting").length, crafting_3.CRAFT_RECIPES.filter((r) => r.station === "crafting").length);
});
/** A UiHost just big enough to drive the crafting screen against a real world and the recording canvas. */
function craftingHost(w) {
    const ctx = globalThis.document.createElement("canvas").getContext("2d");
    const keys = [], notes = [];
    const host = {
        ctx, wctx: ctx, world: w, get pl() { return (0, world_1.player)(w); }, get area() { return (0, world_1.currentArea)(w); },
        t: 0.1, cam: { x: 0, y: 0 }, vw: 320, vh: 180, screens: new screens_1.ScreenStack(), typed: [],
        sfx: new Proxy({}, { get: () => () => { } }), hit: (...k) => k.some((x) => keys.includes(x)),
        say: (s) => notes.push(s), renderNote: () => { }, drainEvents: () => { for (const e of w.events)
            if (e.t === "message")
                notes.push(e.text); w.events = []; },
    };
    host.screens.set({ id: "play", opaque: true, t: 0, update() { }, render() { } });
    return { host, press: (...k) => { keys.splice(0, keys.length, ...k); }, notes };
}
(0, node_test_1.test)("the crafting screen opens greyed out and empty while the craft is unknown, and lights up once it is learned", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    const { host, press, notes } = craftingHost(w);
    const ui = new crafting_2.CraftingUi(host);
    const draw = () => { (0, fakeCanvas_1.resetTrace)(); ui.screen.render(); return (0, fakeCanvas_1.traceHash)(); };
    ui.open("crafting", "workbench@13.5,37");
    strict_1.default.ok(host.screens.is("crafting"));
    strict_1.default.equal(ui.locked, true);
    const greyed = draw();
    // nothing to choose: movement does nothing, and E explains rather than crafting
    press("arrowdown", "s", "arrowright", "d");
    host.screens.update(1 / 60);
    strict_1.default.deepEqual([ui.cursor, ui.focus], [0, "list"]);
    press("e");
    host.screens.update(1 / 60);
    strict_1.default.deepEqual(notes, [crafting_1.CRAFT_LOCKED_TEXT]);
    strict_1.default.ok(host.screens.is("crafting"), "E doesn't close it");
    press("escape");
    host.screens.update(1 / 60);
    strict_1.default.ok(host.screens.is("play"), "Esc closes it");
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    ui.open("crafting", "workbench@13.5,37");
    strict_1.default.equal(ui.locked, false);
    strict_1.default.notEqual(draw(), greyed, "the unlocked screen draws differently from the greyed one");
    strict_1.default.equal(draw(), draw(), "rendering is deterministic");
});
// ------------------------------------------------------------------ deconstruction
(0, node_test_1.test)("deconstructing a built prop refunds 100% of its recipe and clears it from interactables and saves", () => {
    const w = (0, helpers_1.newWorld)();
    kit(w, 10, 10);
    const { a, pl } = inClearing(w);
    strict_1.default.ok((0, commands_1.orderBuild)(w, pl, "craftbench", 20, 52));
    finish(w);
    const bench = a.props.find((p) => p.dyn && p.kind === "workbench");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 4);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "stone"), 8);
    strict_1.default.ok((0, interact_1.interactables)(a).some((i) => i.propId === bench.id));
    strict_1.default.equal((0, build_1.deconTargetAt)(a, 20, 52)?.id, bench.id);
    strict_1.default.ok((0, commands_1.orderDeconstruct)(w, pl, bench.id));
    strict_1.default.equal(pl.task.kind, "dismantle");
    strict_1.default.ok(a.prop(bench.id), "takes time: nothing happens until the task fires");
    (0, helpers_1.events)(w);
    finish(w);
    strict_1.default.equal(a.prop(bench.id), undefined);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 10);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "stone"), 10);
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "deconstructed"));
    strict_1.default.ok(!(0, interact_1.interactables)(a).some((i) => i.propId === bench.id), "interactable cache follows revision");
    const s = (0, save_1.serialize)(w);
    strict_1.default.ok(!s.areas.surface.propsAdded.some((p) => p.id === bench.id));
    strict_1.default.ok(!(0, world_1.currentArea)(roundTrip(w)).prop(bench.id));
});
(0, node_test_1.test)("deconstructing the dungeon's authored wall torch: full wall-torch refund, light gone, stays gone after save/load", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    const a = (0, world_1.currentArea)(w), pl = (0, world_1.player)(w);
    const id = "torch@7,2", torch = a.prop(id);
    strict_1.default.ok(torch && torch.lit && !torch.dyn);
    const li = a.lights.findIndex((l) => l.owner === id);
    strict_1.default.ok(li >= 0);
    const view = new areaView_1.AreaView(a);
    view.flush();
    strict_1.default.ok(view.lights.has("area" + li));
    const interBefore = (0, interact_1.interactables)(a).map((i) => `${i.kind}:${i.propId ?? i.looseId ?? i.socket ?? i.tx}`);
    pl.x = 7 * tiles_1.TS + 8;
    pl.y = 4 * tiles_1.TS + 12;
    pl.facing = "up";
    strict_1.default.deepEqual((0, build_1.salvageOf)(torch), build_2.RECIPES.wall_torch.cost);
    strict_1.default.equal((0, build_1.deconTargetAt)(a, 7, 2)?.id, id);
    strict_1.default.ok((0, commands_1.orderDeconstruct)(w, pl, id));
    finish(w);
    strict_1.default.equal(a.prop(id), undefined);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "cut_stone"), 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 1);
    view.flush();
    strict_1.default.ok(!view.lights.has("area" + li), "the owned light goes with its prop");
    // no tutorial logic hangs off torches: everything else interactable is unchanged
    // (buildable furniture is a scan-only target, not part of this list)
    strict_1.default.deepEqual((0, interact_1.interactables)(a).map((i) => `${i.kind}:${i.propId ?? i.looseId ?? i.socket ?? i.tx}`), interBefore);
    const s = (0, save_1.serialize)(w);
    strict_1.default.deepEqual(s.areas.dungeon.propsRemoved, [id]);
    const w2 = roundTrip(w), a2 = (0, world_1.currentArea)(w2);
    strict_1.default.equal(a2.prop(id), undefined, "loading must not bring it back");
    strict_1.default.deepEqual((0, save_1.serialize)(w2), s);
    const v2 = new areaView_1.AreaView(a2);
    v2.flush();
    strict_1.default.ok(!v2.lights.has("area" + li));
    // and a built wall torch can go back on the same face
    (0, world_1.setFlag)(w2, flags_1.FLAGS.knowBuild);
    (0, debug_1.learnAllPlans)(w2);
    strict_1.default.deepEqual((0, build_1.placement)(w2, (0, world_1.player)(w2), a2, "wall_torch", 7, 2), { ok: true });
});
(0, node_test_1.test)("refund overflow lands on the ground when the pack is full; nothing is deleted", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    const a = (0, world_1.currentArea)(w), pl = (0, world_1.player)(w);
    (0, inventory_1.addItems)(w, pl, "coin", (0, inventory_1.capacity)(w, pl));
    strict_1.default.ok(pl.inventory.every((s) => s));
    pl.x = 7 * tiles_1.TS + 8;
    pl.y = 4 * tiles_1.TS + 12;
    (0, helpers_1.events)(w);
    strict_1.default.ok((0, commands_1.orderDeconstruct)(w, pl, "torch@7,2"));
    finish(w);
    const ev = (0, helpers_1.events)(w);
    const ground = a.loose.filter((l) => l.dyn && !l.taken);
    strict_1.default.deepEqual(ground.map((l) => [l.item, l.n ?? 1]).sort(), [["cut_stone", 1], ["wood", 1]]);
    strict_1.default.equal(ev.filter((e) => e.t === "itemDropped" && e.reason === "full").length, 2);
});
(0, node_test_1.test)("deconstruction is refused on authored props that haven't opted in, and re-validates when it fires", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    const a = (0, world_1.currentArea)(w), pl = (0, world_1.player)(w);
    // the chains on the gaol wall are not buildable: no recipe, no row, no salvage
    for (const id of ["chains@55,27", "bookshelf@5,20", "statue@32,3"]) {
        const p = a.prop(id);
        strict_1.default.ok(p, id);
        pl.x = p.x;
        pl.y = p.y + 20;
        strict_1.default.equal((0, build_1.salvageOf)(p), null, id);
        const c = (0, build_1.deconstructCheck)(w, pl, a, id);
        strict_1.default.ok(!c.ok && c.reason === "fixed", id);
        strict_1.default.equal((0, commands_1.orderDeconstruct)(w, pl, id), false);
        // even forced through the effect, the prop stays
        (0, tasks_1.applyEffect)(w, pl, { op: "deconstruct" }, { kind: "deconstruct", x: p.x, y: p.y, propId: id });
        strict_1.default.ok(a.prop(id), id);
    }
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "message" && e.text === "THAT CAN'T BE TAKEN APART"));
    // ordered in reach, then the golem is moved away before the blow lands
    pl.x = 7 * tiles_1.TS + 8;
    pl.y = 4 * tiles_1.TS + 12;
    strict_1.default.ok((0, commands_1.orderDeconstruct)(w, pl, "torch@7,2"));
    pl.x = 30 * tiles_1.TS;
    pl.y = 30 * tiles_1.TS;
    finish(w);
    strict_1.default.ok(a.prop("torch@7,2"), "re-validated: too far away when it fired");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "cut_stone"), 0);
});
(0, node_test_1.test)("contents spill on deconstruction; any actor can deconstruct through its task queue", () => {
    const w = (0, helpers_1.newWorld)();
    kit(w);
    const { a, pl } = inClearing(w);
    strict_1.default.ok((0, commands_1.orderBuild)(w, pl, "table", 20, 52));
    finish(w);
    const table = a.props.find((p) => p.kind === "table");
    a.setPropState(table.id, { item: "coin" });
    const helper = (0, world_1.makeActor)("helper", "fixture", a.id, table.x, table.y + 20);
    w.actors.push(helper);
    helper.inventory = new Array(8).fill(null);
    (0, tasks_1.enqueueTask)(helper, { kind: "dismantle", dur: 0.9, effect: { op: "deconstruct" } }, { kind: "deconstruct", x: table.x, y: table.y, propId: table.id });
    (0, helpers_1.frames)(w, 90);
    strict_1.default.equal(a.prop(table.id), undefined);
    strict_1.default.equal((0, inventory_1.countItem)(helper, "planks"), build_2.RECIPES.table.cost[0].n, "the helper gets the refund");
    strict_1.default.ok(a.loose.some((l) => l.item === "coin" && !l.taken), "what rested on it spills to the ground");
    strict_1.default.ok((0, interact_1.allInteractables)(w, a).some((i) => i.kind === "item"));
    // direct call on a missing prop is a polite no-op
    (0, build_1.applyDeconstruct)(w, pl, a, table.id);
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "message" && e.text === "NOTHING TO TAKE APART HERE"));
});
// ------------------------------------------------------------------ catalog queries (pure)
function synth(n) {
    const cats = build_2.BUILD_CATEGORIES.map((c) => c.id);
    const out = [];
    for (let i = 0; i < n; i++) {
        const r = {
            name: `ITEM ${String(n - i).padStart(3, "0")}`, category: cats[i % cats.length], desc: [], prop: "chair",
            cost: [{ item: i % 2 ? "stone" : "wood", n: 1 + (i % 7) }], requires: {}, order: i % 3,
        };
        out.push({ id: `r${i}`, recipe: r, status: i % 4 === 0 ? "ok" : i % 4 === 1 ? "cost" : i % 4 === 2 ? "ok" : "unknown", lines: [] });
    }
    return out;
}
const Q = (o) => ({ tab: "all", search: "", sort: "category", affordableOnly: false, favorites: new Set(), ...o });
(0, node_test_1.test)("catalog search matches name, category and material words, case-insensitively", () => {
    const list = synth(200);
    strict_1.default.equal((0, catalog_1.queryCatalog)(list, Q({})).length, 200);
    strict_1.default.equal((0, catalog_1.queryCatalog)(list, Q({ search: "item 007" })).length, 1);
    const stone = (0, catalog_1.queryCatalog)(list, Q({ search: "stone" }));
    strict_1.default.equal(stone.length, 100);
    strict_1.default.ok(stone.every((e) => e.recipe.cost[0].item === "stone"));
    strict_1.default.equal((0, catalog_1.queryCatalog)(list, Q({ search: "  light   stone " })).length, list.filter((e) => e.recipe.category === "light" && e.recipe.cost[0].item === "stone").length);
    strict_1.default.equal((0, catalog_1.queryCatalog)(list, Q({ search: "nothing like this" })).length, 0);
    strict_1.default.ok((0, catalog_1.matchesSearch)(list[0], ""));
});
(0, node_test_1.test)("catalog sort is total and stable for name, cost and category", () => {
    const list = synth(120);
    const byName = (0, catalog_1.sortEntries)(list, "name").map((e) => e.recipe.name);
    strict_1.default.deepEqual(byName, [...byName].sort());
    const byCost = (0, catalog_1.sortEntries)(list, "cost");
    for (let i = 1; i < byCost.length; i++) {
        const a = byCost[i - 1].recipe, b = byCost[i].recipe;
        const ca = a.cost[0].n, cb = b.cost[0].n;
        strict_1.default.ok(ca < cb || (ca === cb && a.name <= b.name));
    }
    const byCat = (0, catalog_1.sortEntries)(list, "category");
    const ci = (e) => build_2.BUILD_CATEGORIES.findIndex((c) => c.id === e.recipe.category);
    for (let i = 1; i < byCat.length; i++)
        strict_1.default.ok(ci(byCat[i - 1]) <= ci(byCat[i]));
    strict_1.default.deepEqual((0, catalog_1.sortEntries)([...list].reverse(), "category").map((e) => e.id), byCat.map((e) => e.id), "input order doesn't matter");
});
(0, node_test_1.test)("catalog filters: tabs, favorites and can-build-only compose", () => {
    const list = synth(60);
    const light = (0, catalog_1.queryCatalog)(list, Q({ tab: "light" }));
    strict_1.default.ok(light.length > 0 && light.every((e) => e.recipe.category === "light"));
    strict_1.default.deepEqual((0, catalog_1.queryCatalog)(list, Q({ tab: "fav", favorites: new Set(["r3", "r10"]) })).map((e) => e.id).sort(), ["r10", "r3"]);
    strict_1.default.equal((0, catalog_1.queryCatalog)(list, Q({ tab: "fav" })).length, 0);
    const afford = (0, catalog_1.queryCatalog)(list, Q({ affordableOnly: true }));
    strict_1.default.ok(afford.length === 30 && afford.every((e) => e.status === "ok"));
    const combo = (0, catalog_1.queryCatalog)(list, Q({ tab: "craft", affordableOnly: true, search: "wood", sort: "name" }));
    strict_1.default.ok(combo.every((e) => e.recipe.category === "craft" && e.status === "ok" && e.recipe.cost[0].item === "wood"));
});
(0, node_test_1.test)("the real catalog lists all recipes for a builder and reflects carried materials", () => {
    const w = (0, helpers_1.newWorld)();
    const pl = (0, world_1.player)(w);
    (0, helpers_1.frame)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    (0, debug_1.learnAllPlans)(w);
    (0, inventory_1.addItems)(w, pl, "planks", 2);
    (0, inventory_1.addItems)(w, pl, "wood", 3);
    const list = (0, catalog_1.catalogEntries)(w, pl);
    strict_1.default.equal(list.length, Object.keys(build_2.RECIPES).length);
    const chair = list.find((e) => e.id === "chair");
    strict_1.default.equal(chair.status, "ok");
    strict_1.default.deepEqual(chair.lines, [{ item: "planks", need: 2, have: 2 }]);
    strict_1.default.equal(list.find((e) => e.id === "wall_torch").status, "cost", "needs cut stone, which isn't carried");
    strict_1.default.deepEqual((0, catalog_1.queryCatalog)(list, Q({ affordableOnly: true })).map((e) => e.id).sort(), ["barricade", "chair"]);
});
