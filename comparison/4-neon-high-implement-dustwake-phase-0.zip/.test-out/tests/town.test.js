"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Westwake, the market town west of the surface: the road to it, the town, the
// six rooms behind its shop doors, and the walk-through portals that join them.
// Headless: builders, sim and the recording fake canvas only.
const town_1 = require("../src/game/content/town");
const shops_1 = require("../src/game/sim/shops");
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const areas_1 = require("../src/game/world/areas");
const area_1 = require("../src/game/world/area");
const town_2 = require("../src/game/town");
const townInteriors_1 = require("../src/game/townInteriors");
const surface_1 = require("../src/game/surface");
const town_3 = require("../src/game/content/town");
const props_1 = require("../src/game/content/props");
const harvest_1 = require("../src/game/content/harvest");
const dialogue_1 = require("../src/game/content/dialogue");
const monologue_1 = require("../src/game/content/monologue");
const geography_1 = require("../src/game/content/geography");
const tiles_1 = require("../src/game/content/tiles");
const font_1 = require("../src/game/font");
const reach_1 = require("../src/game/sim/reach");
const collision_1 = require("../src/game/sim/collision");
const portals_1 = require("../src/game/sim/portals");
const world_1 = require("../src/game/world/world");
const folk_1 = require("../src/game/content/folk");
const folk_2 = require("../src/game/sim/folk");
const actors_1 = require("../src/game/content/actors");
const save_1 = require("../src/game/world/save");
const debug_1 = require("../src/game/sim/debug");
const propsTown_1 = require("../src/game/art/propsTown");
const props_2 = require("../src/game/art/props");
const tiles_2 = require("../src/game/art/tiles");
const light_1 = require("../src/game/light");
const util_1 = require("../src/game/util");
const zoom_1 = require("../src/game/view/zoom");
const helpers_1 = require("./helpers");
const TOWN_AREAS = [town_3.TOWN_ID, ...town_3.ESTABLISHMENTS.map(town_3.interiorId)];
const areaOf = (id) => new area_1.Area(areas_1.AREAS[id]());
const boxesOf = (a) => a.props.filter(collision_1.propBlocks).map((p) => p.box);
const reachOf = (a) => (0, reach_1.reachable)(a, boxesOf(a), a.base.start);
/** Can the golem stand somewhere it can walk to, within `rad` px of (x, y)? */
function standNear(a, r, x, y, rad) {
    for (let dy = -rad; dy <= rad; dy += 2)
        for (let dx = -rad; dx <= rad; dx += 2) {
            if (dx * dx + dy * dy > rad * rad)
                continue;
            const px = x + dx, py = y + dy, tx = Math.floor(px / tiles_1.TS), ty = Math.floor((py - 1) / tiles_1.TS);
            if (tx < 0 || ty < 0 || tx >= a.w || ty >= a.h)
                continue;
            if (r[ty * a.w + tx] && (0, collision_1.boxFree)(a, px, py))
                return true;
        }
    return false;
}
/** Hold a direction until `done`, as the play screen would. */
function push(w, ix, iy, done, max = 900) {
    for (let i = 0; i < max && !done(); i++)
        (0, helpers_1.frame)(w, { ix, iy, use: false });
    return done();
}
const lint = (s, what) => { for (const ch of s)
    strict_1.default.ok(font_1.FONT_GLYPHS.has(ch), `${what}: "${ch}" is not in the bitmap font (${s})`); };
// ------------------------------------------------------------------ lore and the way there
(0, node_test_1.test)("the Guardian's village is where it said: a road leaves the surface westward and ends at Westwake", () => {
    const core = dialogue_1.DIALOGUE.guardian.segments.find((s) => s.id === "core");
    strict_1.default.ok(core.pages.some((p) => /VILLAGE WEST OF HERE/.test(p.text)), "the guardian still points west");
    const s = (0, surface_1.buildSurface)(), road = s.portals.find((p) => p.id === geography_1.WEST_ROAD.portal);
    strict_1.default.deepEqual(road.to, { area: town_3.TOWN_ID, portal: "east_road" });
    strict_1.default.equal(road.dir, "left");
    strict_1.default.ok(s.exits.some((e) => e.dir === "w" && e.label === "WESTWAKE"));
    for (let y = geography_1.WEST_ROAD.surface.y0; y <= geography_1.WEST_ROAD.surface.y1; y++) {
        strict_1.default.equal(s.grid[y * s.w], tiles_1.T.THICKET, "the edge column stays closed");
        strict_1.default.equal(s.grid[y * s.w + 1], tiles_1.T.FLOOR, "the road reaches it");
    }
    strict_1.default.ok(s.props.some((p) => p.kind === "waymark"), "a waymark stands at its mouth");
    const wild = (0, surface_1.buildSurface)({ westRoad: false });
    strict_1.default.ok(!wild.portals.some((p) => p.id === geography_1.WEST_ROAD.portal), "(the stair head's own portal is not a road: tests/entrance.test.ts)");
    strict_1.default.equal(wild.exits.length, 0);
    strict_1.default.equal(wild.grid[geography_1.WEST_ROAD.surface.y0 * wild.w + 1], tiles_1.T.THICKET, "without the road the wild is as it was");
    strict_1.default.equal(geography_1.AREA_NAMES[town_3.TOWN_ID], "WESTWAKE");
});
// ------------------------------------------------------------------ builders
(0, node_test_1.test)("town and interiors: deterministic, unique ids, big enough for the widest zoom, registered and named", () => {
    const a = (0, town_2.buildTown)(), b = (0, town_2.buildTown)();
    strict_1.default.deepEqual([...a.grid], [...b.grid]);
    strict_1.default.deepEqual([...a.style], [...b.style]);
    strict_1.default.equal(JSON.stringify([a.props, a.decals, a.lights, a.portals, a.spots]), JSON.stringify([b.props, b.decals, b.lights, b.portals, b.spots]));
    strict_1.default.equal(a.w, town_3.TOWN_W);
    strict_1.default.equal(a.h, town_3.TOWN_H);
    for (const e of town_3.ESTABLISHMENTS)
        strict_1.default.equal(JSON.stringify((0, townInteriors_1.buildInterior)(e).props), JSON.stringify((0, townInteriors_1.buildInterior)(e).props), e);
    const big = (0, zoom_1.viewSize)(Math.max(...zoom_1.ZOOM_STEPS));
    for (const id of TOWN_AREAS) {
        const d = areas_1.AREAS[id]();
        strict_1.default.equal(d.id, id);
        strict_1.default.equal(new Set(d.props.map((p) => p.id)).size, d.props.length, `${id}: prop ids unique`);
        strict_1.default.ok(d.w * tiles_1.TS >= big.w && d.h * tiles_1.TS >= big.h, `${id} fills the 2x view`);
        strict_1.default.ok(geography_1.AREA_NAMES[id], `${id} has a name`);
    }
});
(0, node_test_1.test)("buildings: inside the map, never overlapping, solid, with a street-level row that lets lamp light onto the front", () => {
    const t = (0, town_2.buildTown)();
    town_3.BUILDINGS.forEach((b, i) => {
        strict_1.default.ok(b.x >= 0 && b.y >= 0 && b.x + b.w <= t.w && b.y + b.h <= t.h, b.id);
        for (const c of town_3.BUILDINGS.slice(i + 1))
            strict_1.default.ok(b.x + b.w <= c.x || c.x + c.w <= b.x || b.y + b.h <= c.y || c.y + c.h <= b.y, `${b.id} overlaps ${c.id}`);
        for (let y = b.y; y < b.y + b.h; y++)
            for (let x = b.x; x < b.x + b.w; x++) {
                const tile = t.grid[y * t.w + x];
                strict_1.default.ok((0, tiles_1.isSolidT)(tile), `${b.id} is solid`);
                strict_1.default.equal((0, tiles_1.isOpaqueT)(tile), y < b.y + b.h - 1, `${b.id}: only the street-level row passes light`);
            }
        strict_1.default.ok(t.decals.some((d) => d.kind === "building" && d.v === i && d.x === b.x * tiles_1.TS && d.y === b.y * tiles_1.TS), `${b.id} is painted`);
    });
    for (const e of town_3.ESTABLISHMENTS) {
        strict_1.default.equal((0, town_3.building)(e).interior, (0, town_3.interiorId)(e));
        strict_1.default.ok(areas_1.AREAS[(0, town_3.interiorId)(e)], `${e} can be entered`);
    }
    // a lamp in the street lights both storeys of a front, and the roof behind stays dark
    const b = (0, town_3.building)("armory"), d = (0, town_3.doorPx)(b), area = new area_1.Area(t), tx = Math.floor(d.x / tiles_1.TS);
    const L = (0, light_1.makeLight)(d.x, d.y + 20, 110, [1, 1, 1], 1, 0);
    (0, light_1.computeVis)(L, area);
    const vis = (x, y) => L.vis[(y - L.oy) * L.n + (x - L.ox)];
    strict_1.default.ok(vis(tx, b.y + b.h - 1) > 0 && vis(tx, b.y + b.h - 2) > 0, "both rows of the front are lit");
    strict_1.default.equal(vis(tx, b.y + b.h - 3), 0, "the roof is not");
});
// ------------------------------------------------------------------ portals
(0, node_test_1.test)("portals pair up both ways and let out onto free, reachable ground", () => {
    for (const id of ["surface", ...TOWN_AREAS]) {
        const a = areaOf(id), r = reachOf(a);
        for (const p of (0, portals_1.portalsOf)(a)) {
            const dest = areaOf(p.to.area), q = (0, portals_1.portalById)(dest, p.to.portal);
            strict_1.default.ok(q, `${id}.${p.id} leads to a portal that exists`);
            strict_1.default.deepEqual(q.to, { area: id, portal: p.id }, `${id}.${p.id} is paired`);
            const at = (0, portals_1.portalArrival)(p);
            strict_1.default.ok((0, collision_1.boxFree)(a, at.x, at.y), `${id}.${p.id}: arrival is free`);
            strict_1.default.ok(standNear(a, r, at.x, at.y, 0), `${id}.${p.id}: arrival can be walked from`);
            strict_1.default.ok(standNear(a, r, p.x + p.w / 2, p.y + p.h / 2, Math.max(p.w, p.h) / 2), `${id}.${p.id}: its box can be walked into`);
        }
    }
    strict_1.default.equal((0, portals_1.portalsOf)(areaOf(town_3.TOWN_ID)).length, town_3.ESTABLISHMENTS.length + 1, "six doors and the road");
});
(0, node_test_1.test)("walking: down the old road into Westwake, in and out of all six doors, and back to the ruins", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    const surface = areaOf("surface"), out = (0, portals_1.portalArrival)((0, portals_1.portalById)(surface, geography_1.WEST_ROAD.portal));
    (0, world_1.enterArea)(w, pl, "surface", out.x + 40, out.y);
    (0, helpers_1.events)(w);
    strict_1.default.ok(push(w, -1, 0, () => pl.area === town_3.TOWN_ID), "pushing west along the road arrives in the town");
    strict_1.default.equal(pl.facing, "left");
    const ev = (0, helpers_1.events)(w).find((e) => e.t === "portal");
    strict_1.default.ok(ev && ev.t === "portal" && ev.fromArea === "surface" && ev.toArea === town_3.TOWN_ID && ev.actor === pl.id);
    strict_1.default.ok(w.monologue.said.includes("town.arrive"), "the golem notes that the village became a town");
    const town = areaOf(town_3.TOWN_ID);
    for (const e of town_3.ESTABLISHMENTS) {
        const door = (0, portals_1.portalArrival)((0, portals_1.portalById)(town, `door.${e}`));
        pl.x = door.x;
        pl.y = door.y;
        pl.vx = pl.vy = 0;
        strict_1.default.ok(push(w, 0, -1, () => pl.area === (0, town_3.interiorId)(e), 240), `${e}: pushing on the door goes in`);
        strict_1.default.equal(pl.facing, "up");
        for (let i = 0; i < 40; i++)
            (0, helpers_1.frame)(w, { ix: 0, iy: -1, use: false });
        strict_1.default.equal(pl.area, (0, town_3.interiorId)(e), `${e}: still inside after walking in`);
        strict_1.default.ok(push(w, 0, 1, () => pl.area === town_3.TOWN_ID, 600), `${e}: walking back down to the sill goes out`);
        strict_1.default.equal(pl.facing, "down");
        strict_1.default.ok(Math.hypot(pl.x - door.x, pl.y - door.y) < 10, `${e}: out by its own door`);
        for (let i = 0; i < 40; i++)
            (0, helpers_1.frame)(w, { ix: 0, iy: 1, use: false });
        strict_1.default.equal(pl.area, town_3.TOWN_ID, `${e}: stepping away from the door does not go back in`);
    }
    const east = (0, portals_1.portalArrival)((0, portals_1.portalById)(town, "east_road"));
    pl.x = east.x;
    pl.y = east.y;
    pl.vx = pl.vy = 0;
    strict_1.default.ok(push(w, 1, 0, () => pl.area === "surface", 600), "east through the gate leads back to the wild");
    strict_1.default.equal(pl.facing, "right");
    strict_1.default.equal(w.monologue.said.filter((s) => s === "town.arrive").length, 1);
});
(0, node_test_1.test)("a save made inside a shop loads back inside it, and the door still works", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), room = areaOf("town_tavern");
    (0, world_1.enterArea)(w, pl, "town_tavern", room.base.start.x, room.base.start.y);
    const w2 = (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w)))), p2 = (0, world_1.player)(w2);
    strict_1.default.equal(p2.area, "town_tavern");
    strict_1.default.ok(push(w2, 0, 1, () => p2.area === town_3.TOWN_ID, 600));
    strict_1.default.ok((0, debug_1.debugPlaces)(w2).some((d) => d.group === "WESTWAKE"), "the debug teleport lists the town");
});
// ------------------------------------------------------------------ laid out for later
(0, node_test_1.test)("every standing place is free and can be walked to; every sign and landmark can be read", () => {
    for (const id of TOWN_AREAS) {
        const a = areaOf(id), r = reachOf(a), spots = a.base.spots ?? [];
        strict_1.default.ok(spots.length > 0, `${id} has standing places`);
        strict_1.default.equal(new Set(spots.map((s) => s.id)).size, spots.length, `${id}: spot ids unique`);
        for (const s of spots) {
            strict_1.default.ok((0, collision_1.boxFree)(a, s.x, s.y), `${id}: spot ${s.id} is free`);
            strict_1.default.ok(standNear(a, r, s.x, s.y, 8), `${id}: spot ${s.id} can be walked to`);
        }
        for (const p of a.props)
            if ((0, props_1.propDef)(p.kind).examine)
                strict_1.default.ok(standNear(a, r, p.x, p.y + 2, (0, props_1.propReach)(p.kind) + 4), `${id}: ${p.id} can be walked up to`);
        if (id !== town_3.TOWN_ID) {
            const kinds = spots.map((s) => s.kind);
            strict_1.default.ok(kinds.includes("keeper") && kinds.includes("customer") && kinds.includes("door"), `${id}: a keeper, a customer and the door`);
        }
    }
    const t = areaOf(town_3.TOWN_ID), spots = t.base.spots;
    for (const b of town_3.BUILDINGS)
        if (b.door)
            strict_1.default.ok(spots.some((s) => s.id === `door.${b.id}`), `${b.id} has a doorstep`);
    strict_1.default.ok(spots.filter((s) => s.kind === "stall").length >= 6, "a pitch behind every market stall");
    strict_1.default.ok(areaOf("town_tavern").base.spots.filter((s) => s.kind === "seat").length >= 10, "the tavern seats a crowd");
});
// ------------------------------------------------------------------ light
(0, node_test_1.test)("light is the town's map of itself: runes for the bright side, fire for everyone else", () => {
    const RUNE = ["rune_lamp", "rune_sconce", "runestand", "winglow_rune", "marketcross"], FIRE = ["torch", "torch_post", "lantern", "candlestand", "brazier", "smithforge"];
    for (const k of RUNE)
        strict_1.default.equal((0, props_1.propDef)(k).light.flick, 0, `${k}: rune light is perfectly steady`);
    for (const k of ["lantern", "candlestand", "fireplace", "smithforge", "winglow", "torch"])
        strict_1.default.ok((0, props_1.propDef)(k).light.flick > 0, `${k}: fire flickers`);
    for (const e of town_3.ESTABLISHMENTS) {
        const d = (0, townInteriors_1.buildInterior)(e), kinds = d.props.map((p) => p.kind);
        const runes = kinds.filter((k) => RUNE.includes(k)).length, fires = kinds.filter((k) => FIRE.includes(k)).length;
        if (town_3.HIGH_END[e]) {
            strict_1.default.ok(runes >= 3, `${e} is lit by runes`);
            strict_1.default.equal(fires, 0, `${e} burns no torches`);
        }
        else {
            strict_1.default.equal(runes, 0, `${e} has no light runes`);
            strict_1.default.ok(fires >= 3, `${e} is lit by fire`);
        }
        strict_1.default.ok(d.interior && !d.outdoor, `${e} is a room`);
    }
    const t = (0, town_2.buildTown)(), near = (kind, x, y) => t.props.some((p) => p.kind === kind && Math.abs(p.x - x) < 24 && Math.abs(p.y - y) < 40);
    for (const e of town_3.ESTABLISHMENTS) {
        const d = (0, town_3.doorPx)((0, town_3.building)(e));
        strict_1.default.ok(near(town_3.HIGH_END[e] ? "rune_sconce" : "lantern", d.x, d.y), `${e}: the right lamp by the door`);
    }
    for (const p of t.props) {
        if (p.kind === "rune_lamp") {
            strict_1.default.ok(p.y <= 37 * tiles_1.TS, `${p.id}: no light rune south of the square`);
            const tx = Math.floor(p.x / tiles_1.TS), ty = Math.floor((p.y - 1) / tiles_1.TS);
            let paved = false;
            for (let dy = -2; dy <= 2; dy++)
                for (let dx = -2; dx <= 2; dx++) {
                    const s = t.style[(ty + dy) * t.w + tx + dx];
                    if (t.grid[(ty + dy) * t.w + tx + dx] === tiles_1.T.FLOOR && (s === tiles_1.FS.SETT || s === tiles_1.FS.WEAVE))
                        paved = true;
                }
            strict_1.default.ok(paved, `${p.id} stands by dressed paving`);
        }
        if (p.kind === "torch_post")
            strict_1.default.ok(!(p.y > 26 * tiles_1.TS && p.y < 34 * tiles_1.TS && p.x > 33 * tiles_1.TS), `${p.id}: no torches on the square or the High Street`);
    }
    strict_1.default.ok(t.props.filter((p) => p.kind === "rune_lamp").length >= 20 && t.props.filter((p) => p.kind === "torch_post" && p.lit).length >= 10);
});
// ------------------------------------------------------------------ scope
(0, node_test_1.test)("lived in, and every shop kept, but nothing for sale yet: the census's townsfolk and the six shopkeepers are the only people, and nothing can be bought, stored, crafted, taken or cut down", () => {
    for (const id of TOWN_AREAS) {
        const d = areas_1.AREAS[id]();
        strict_1.default.equal((d.npcs ?? []).length, 0, `${id}: the builder places nobody (no shopkeeper, golem or special NPC); townsfolk come from the census`);
        strict_1.default.equal(d.loose.length, 0, `${id}: nothing to pick up`);
        strict_1.default.equal(d.ritual, undefined);
        for (const p of d.props) {
            const def = (0, props_1.propDef)(p.kind);
            strict_1.default.ok(!def.station && !def.storage && !def.rune, `${id}: ${p.id} has no function`);
            strict_1.default.ok(!harvest_1.HARVEST[p.kind], `${id}: ${p.id} is not harvestable`);
            strict_1.default.ok(!p.item && !p.container, `${id}: ${p.id} holds nothing`);
        }
    }
    // who does live here: exactly the census's Westwake rows, all townsfolk (sim/folk.ts), none of them a golem, a
    // shopkeeper or anyone with a dialogue script or a pack (talking to one is a line in a bubble, not a shop)
    const w = (0, world_1.createWorld)(7);
    for (const id of TOWN_AREAS)
        (0, world_1.getArea)(w, id);
    const here = w.actors.filter((a) => TOWN_AREAS.includes(a.area));
    const rows = folk_1.CENSUS.filter((r) => TOWN_AREAS.includes(r.area));
    strict_1.default.ok(rows.length >= 10, "people live in Westwake");
    // (v19) and one keeper behind each of the six counters (sim/shops.ts), each in their own shop's room: placeholders
    // with a line to say, not yet a shop (no pack, no dialogue script, nothing made)
    const keepers = town_1.ESTABLISHMENTS.map((e) => (0, shops_1.keeperId)(e));
    strict_1.default.deepEqual(here.map((a) => a.id).sort(), [...rows.map((r) => r.id), ...keepers].sort(), "everyone in Westwake is a census row or the keeper of one of its six shops, and all of them are there");
    for (const a of here) {
        if ((0, shops_1.isKeeper)(a))
            strict_1.default.equal(a.area, (0, town_1.interiorId)(a.keeper.shop), `${a.id} keeps to their own shop`);
        else
            strict_1.default.ok((0, folk_2.isFolk)(a), `${a.id} is a townsperson`);
        strict_1.default.equal(a.npc, undefined, `${a.id}: no dialogue script`);
        strict_1.default.ok(!(0, actors_1.capable)(a, "worker") && !(0, actors_1.capable)(a, "craft") && !(0, actors_1.actorDef)(a).power, `${a.id}: not a golem, makes nothing`);
        strict_1.default.equal((0, actors_1.actorDef)(a).inventory.slots, 0, `${a.id}: carries nothing to sell or store`);
    }
});
// ------------------------------------------------------------------ text and art
(0, node_test_1.test)("every line of the town's text fits the bitmap font", () => {
    for (const [kind, text] of town_3.SIGNS) {
        lint(text, kind);
        strict_1.default.equal((0, props_1.propDef)(kind).examine, text);
    }
    for (const id of TOWN_AREAS) {
        const d = areas_1.AREAS[id]();
        lint(geography_1.AREA_NAMES[id], id);
        for (const r of d.rooms)
            lint(r.name, `${id} room`);
        for (const p of d.portals ?? [])
            if (p.label)
                lint(p.label, `${id}.${p.id}`);
        for (const p of d.props) {
            const t = (0, props_1.propDef)(p.kind).examine;
            if (t)
                lint(t, p.kind);
        }
    }
    for (const p of (0, surface_1.buildSurface)().props) {
        const t = (0, props_1.propDef)(p.kind).examine;
        if (t)
            lint(t, p.kind);
    }
    lint(monologue_1.THOUGHTS["town.arrive"].text, "town.arrive");
});
(0, node_test_1.test)("town art: every sprite draws and fits the renderer's culling margin; the town and its rooms bake", () => {
    for (const k of Object.keys(propsTown_1.TOWN_PROP_ART))
        for (let v = 0; v < 4; v++)
            for (const alt of [false, true]) {
                const s = (0, props_2.propSprite)(k, v, alt);
                strict_1.default.ok(s, `${k} v${v}`);
                strict_1.default.ok(s.w <= 96 && s.h <= 60, `${k}: ${s.w}x${s.h} stays inside the cull margin`);
            }
    for (const id of TOWN_AREAS)
        for (const p of areas_1.AREAS[id]().props)
            strict_1.default.ok((0, props_2.propSprite)(p.kind, p.v, false), `${id}: ${p.kind} has art`);
    for (const id of TOWN_AREAS) {
        const d = areas_1.AREAS[id](), c = (0, util_1.makeCanvas)(d.w * tiles_1.TS, d.h * tiles_1.TS);
        (0, tiles_2.bakeRegion)(c.ctx, d, 0, 0, d.w - 1, d.h - 1);
    }
});
