"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const world_1 = require("../src/game/world/world");
const audience_1 = require("../src/game/view/audience");
(0, node_test_1.test)("event audience separates the player, a nearby actor and a remote actor", () => {
    const w = (0, world_1.createWorld)(1), pl = (0, world_1.player)(w);
    const near = (0, world_1.makeActor)("near", "worker_golem", pl.area, pl.x + 20, pl.y);
    w.actors.push(near);
    strict_1.default.equal((0, audience_1.eventActor)({ t: "message", actor: near.id, text: "WORKING" }), near.id);
    strict_1.default.equal((0, audience_1.eventActor)({ t: "cue", cue: "clank", x: 0, y: 0, actor: near.id }), near.id);
    strict_1.default.equal((0, audience_1.eventAudience)(w, { t: "step", actor: pl.id, heavy: false }), "player");
    strict_1.default.equal((0, audience_1.eventAudience)(w, { t: "message", text: "THE RUNE IS DARK" }), "player");
    strict_1.default.equal((0, audience_1.eventAudience)(w, { t: "step", actor: near.id, heavy: false }), "nearby");
    near.area = "surface";
    strict_1.default.equal((0, audience_1.eventAudience)(w, { t: "step", actor: near.id, heavy: false }), "elsewhere");
});
