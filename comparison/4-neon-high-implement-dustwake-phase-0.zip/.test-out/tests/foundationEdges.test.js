"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const actors_1 = require("../src/game/content/actors");
const tiles_1 = require("../src/game/content/tiles");
const areas_1 = require("../src/game/world/areas");
const foundationAreas_1 = require("../src/game/world/foundationAreas");
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const debugFoundations_1 = require("../src/game/sim/debugFoundations");
const jobs_1 = require("../src/game/sim/jobs");
const inventory_1 = require("../src/game/sim/inventory");
const storage_1 = require("../src/game/sim/storage");
const step_1 = require("../src/game/sim/step");
const crafting_1 = require("../src/game/sim/crafting");
const tasks_1 = require("../src/game/sim/tasks");
const discovery_1 = require("../src/game/sim/discovery");
const navigation_1 = require("../src/game/sim/navigation");
const power_1 = require("../src/game/sim/power");
const requirements_1 = require("../src/game/sim/requirements");
const world_2 = require("../src/game/world/world");
const crafting_2 = require("../src/game/content/crafting");
const gear_1 = require("../src/game/sim/gear");
const world_3 = require("../src/game/world/world");
(0, debugFoundations_1.registerFoundations)();
(0, node_test_1.test)("authored storage is deterministic data and an emptied chest stays empty after loading", () => {
    areas_1.AREAS.stocked = () => {
        const area = (0, foundationAreas_1.buildFoundationArea)("debug_workshop");
        area.id = "stocked";
        area.props.find((p) => p.id === "chest.fixture").inventory = [{ item: "wood", n: 7 }, null, { item: "stone", n: 3 }];
        return area;
    };
    try {
        strict_1.default.deepEqual(areas_1.AREAS.stocked(), areas_1.AREAS.stocked());
        const w = (0, world_1.createWorld)(1), area = (0, world_1.getArea)(w, "stocked"), chest = area.prop("chest.fixture");
        strict_1.default.equal(chest.inventory[0].n, 7);
        strict_1.default.equal((0, save_1.serialize)(w).areas.stocked.props[chest.id], undefined, "no diff for builder contents");
        area.setInventory(chest.id, []);
        strict_1.default.equal(area.base.props.find((p) => p.id === chest.id).inventory[0].n, 7, "runtime slots do not alias builder data");
        const save = (0, save_1.serialize)(w);
        strict_1.default.deepEqual(save.areas.stocked.props[chest.id].inventory, [], "empty is an explicit diff against a non-empty builder");
        const loaded = (0, save_1.deserialize)(save);
        strict_1.default.ok((0, world_1.getArea)(loaded, area.id).prop(chest.id).inventory.every((s) => !s));
        strict_1.default.deepEqual((0, save_1.serialize)(loaded), save);
        strict_1.default.throws(() => area.addProp("storage_chest", 20, 20, {}, chest.id), /duplicate/);
    }
    finally {
        delete areas_1.AREAS.stocked;
    }
});
(0, node_test_1.test)("a worker deposits before a final harvest bonus that would spill out of its pack", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), a = (0, world_1.actorById)(w, "debug.worker"), yard = (0, world_1.getArea)(w, "debug_yard"), tree = yard.prop("tree.fixture");
    (0, jobs_1.cancelJob)(w, a);
    (0, world_1.enterArea)(w, a, yard.id, tree.x, tree.y + 12);
    (0, inventory_1.addItems)(w, a, "coin", 7);
    (0, inventory_1.addItems)(w, a, "wood", 19);
    yard.damageProp(tree.id, 3.5);
    (0, jobs_1.assignJob)(w, a, (0, jobs_1.gatherOrder)("wood", yard.id, { area: "debug_workshop", prop: "chest.fixture" }, 20));
    for (let i = 0; i < 4000 && a.job?.status !== "done"; i++)
        (0, step_1.stepWorld)(w, 0.05);
    strict_1.default.equal(a.job?.status, "done", JSON.stringify(a.job));
    const chest = (0, world_1.getArea)(w, "debug_workshop").prop("chest.fixture");
    strict_1.default.equal(chest.inventory.reduce((n, s) => n + (s?.item === "wood" ? s.n : 0), 0), 20);
    strict_1.default.equal((0, inventory_1.countItem)(a, "wood"), 2);
    strict_1.default.ok(yard.loose.every((l) => l.item !== "wood"), "no stranded harvest overflow");
});
(0, node_test_1.test)("storage transfers and inverse recipes retain relic discovery credit", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), pl = (0, world_1.player)(w), area = (0, world_1.getArea)(w, pl.area), bench = area.prop("bench.fixture");
    pl.inventory = [];
    w.flags.delete("relic.found.crown");
    area.setInventory("chest.fixture", [{ item: "crown", n: 1 }]);
    strict_1.default.equal((0, storage_1.transferItems)(w, (0, storage_1.storageRef)(area.id, "chest.fixture"), (0, storage_1.packRef)(pl), "crown", 1), 1);
    strict_1.default.ok(w.flags.has("relic.found.crown"));
    pl.x = bench.x;
    pl.y = bench.y + 12;
    strict_1.default.ok((0, crafting_1.applyCraft)(w, pl, area, "unmake_crown", bench.id));
    strict_1.default.equal((0, discovery_1.relicCount)(w, pl), 1);
});
(0, node_test_1.test)("mixed actors share one harvest work counter; changing bodies never changes total yield", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), small = (0, world_1.actorById)(w, "debug.worker"), pl = (0, world_1.player)(w), area = (0, world_1.getArea)(w, "debug_yard"), tree = area.prop("tree.fixture");
    (0, jobs_1.cancelJob)(w, small);
    (0, world_1.enterArea)(w, small, area.id, tree.x - 12, tree.y + 8);
    (0, world_1.enterArea)(w, pl, area.id, tree.x + 12, tree.y + 8);
    const target = { kind: "harvest", propId: tree.id, x: tree.x, y: tree.y };
    for (let i = 0; !tree.taken && i < 20; i++)
        (0, tasks_1.applyEffect)(w, i % 2 ? pl : small, { op: "harvest" }, target);
    strict_1.default.equal((0, inventory_1.countItem)(small, "wood") + (0, inventory_1.countItem)(pl, "wood"), 6);
    strict_1.default.equal(tree.dmg, 4);
});
(0, node_test_1.test)("pathfinding uses the moving actor's width through a narrow doorway", () => {
    areas_1.AREAS.doorway = () => {
        const area = (0, foundationAreas_1.buildFoundationArea)("debug_workshop");
        area.id = "doorway";
        area.props = [];
        for (let x = 1; x < area.w - 1; x++)
            area.grid[5 * area.w + x] = x === 7 ? tiles_1.T.FLOOR : tiles_1.T.WALL;
        area.plan = area.grid.slice();
        return area;
    };
    actors_1.ACTORS.wide = { ...actors_1.ACTORS.golem, body: { box: [24, 10], reach: 20, height: 40 } };
    try {
        const w = (0, world_1.createWorld)(3);
        (0, world_1.getArea)(w, "doorway");
        const small = (0, world_1.makeActor)("small", "worker_golem", "doorway", 120, 59), wide = (0, world_1.makeActor)("wide", "wide", "doorway", 120, 59);
        strict_1.default.ok((0, navigation_1.findPath)(w, small, { x: 120, y: 123, range: 1 }, false));
        strict_1.default.equal((0, navigation_1.findPath)(w, wide, { x: 120, y: 123, range: 1 }, false), null);
    }
    finally {
        delete areas_1.AREAS.doorway;
        delete actors_1.ACTORS.wide;
    }
});
(0, node_test_1.test)("slotting a core requires walking up, not reaching through a wall", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), pl = (0, world_1.player)(w), a = (0, world_1.actorById)(w, "debug.worker"), area = (0, world_1.getArea)(w, pl.area);
    (0, jobs_1.cancelJob)(w, a);
    a.powerCore = null;
    pl.x = 56;
    pl.y = 75;
    a.x = 80;
    a.y = 75;
    area.setTile(4, 4, tiles_1.T.WALL);
    (0, inventory_1.addItems)(w, pl, "ruby_core", 1);
    strict_1.default.equal((0, power_1.insertPowerCore)(w, pl, a, "ruby_core"), false);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "ruby_core"), 1);
});
(0, node_test_1.test)("a complete off-screen job and save round-trip need neither DOM nor ambient randomness", () => {
    const descriptor = Object.getOwnPropertyDescriptor(globalThis, "document"), random = Math.random;
    Object.defineProperty(globalThis, "document", { configurable: true, get: () => { throw new Error("simulation touched DOM"); } });
    Math.random = () => { throw new Error("simulation used ambient randomness"); };
    try {
        const w = (0, debugFoundations_1.foundationDemo)(), a = (0, world_1.actorById)(w, "debug.worker");
        for (let i = 0; i < 3000 && a.job?.status !== "done"; i++)
            (0, step_1.stepWorld)(w, 0.05);
        strict_1.default.equal(a.job?.status, "done");
        strict_1.default.deepEqual((0, save_1.serialize)((0, save_1.deserialize)((0, save_1.serialize)(w))), (0, save_1.serialize)(w));
    }
    finally {
        Math.random = random;
        if (descriptor)
            Object.defineProperty(globalThis, "document", descriptor);
        else
            delete globalThis.document;
    }
});
(0, node_test_1.test)("the same inventory cannot be counted twice in one material transaction", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), pl = (0, world_1.player)(w);
    (0, inventory_1.addItems)(w, pl, "wood", 1);
    const a = (0, storage_1.inventoryHandle)(w, (0, storage_1.packRef)(pl)), b = (0, storage_1.inventoryHandle)(w, (0, storage_1.packRef)(pl));
    strict_1.default.equal((0, storage_1.consumeInputs)([a, b], [{ item: "wood", n: 2 }]), false);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 1);
});
(0, node_test_1.test)("legacy body-flag requirements are actor-relative, never borrowed from the player", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), pl = (0, world_1.player)(w), a = (0, world_1.actorById)(w, "debug.worker");
    (0, world_2.setFlag)(w, "golem.arm");
    strict_1.default.equal((0, requirements_1.meets)(w, pl, { flags: ["golem.arm"] }), true);
    strict_1.default.equal((0, requirements_1.meets)(w, a, { flags: ["golem.arm"] }), false);
});
(0, node_test_1.test)("recipe data cannot consume a declared tool or spend inputs on an invalid output", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), pl = (0, world_1.player)(w), area = (0, world_1.getArea)(w, pl.area), bench = area.prop("bench.fixture");
    pl.x = bench.x;
    pl.y = bench.y + 12;
    const base = crafting_2.CRAFT_RECIPES.find((r) => r.id === "rune_swift");
    const invalid = { ...base, inputs: [{ item: "chisel", n: 1 }] };
    strict_1.default.equal((0, crafting_1.applyCraft)(w, pl, area, invalid.id, bench.id, [invalid]), false);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "chisel"), 1);
    (0, inventory_1.addItems)(w, pl, "cut_stone", 2);
    strict_1.default.equal((0, crafting_1.applyCraft)(w, pl, area, base.id, bench.id, [{ ...base, output: { item: "rune_swift", n: 0 } }]), false);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "cut_stone"), 2);
});
(0, node_test_1.test)("manual player input cancels automatic work and immediately restores direct control", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), pl = (0, world_1.player)(w);
    (0, jobs_1.assignJob)(w, pl, { kind: "walk", args: { area: pl.area, x: 72, y: 139 } });
    (0, step_1.stepPlayer)(w, 0.05, { ix: 0, iy: 0, use: false });
    strict_1.default.ok(pl.job);
    (0, step_1.stepPlayer)(w, 0.05, { ix: 1, iy: 0, use: false });
    strict_1.default.equal(pl.job, null);
    strict_1.default.equal(pl.task, null);
    strict_1.default.ok(pl.vx > 0);
});
(0, node_test_1.test)("another actor definition can put its own lock on a normally open slot", () => {
    actors_1.ACTORS.sealed = { ...actors_1.ACTORS.worker_golem, gearUnlocks: { rune0: { actorFlags: ["body.runeSocket"] } } };
    try {
        const w = (0, debugFoundations_1.foundationDemo)(), a = (0, world_1.makeActor)("sealed", "sealed", "debug_workshop", 40, 40);
        strict_1.default.equal((0, gear_1.slotUsable)(w, a, "rune0"), false);
        (0, world_3.setActorFlag)(a, "body.runeSocket");
        strict_1.default.equal((0, gear_1.slotUsable)(w, a, "rune0"), true);
        strict_1.default.equal((0, gear_1.slotUsable)(w, a, "rune1"), false);
    }
    finally {
        delete actors_1.ACTORS.sealed;
    }
});
