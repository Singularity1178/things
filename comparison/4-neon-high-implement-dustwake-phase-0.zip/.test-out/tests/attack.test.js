"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The attack (Space): a two-arm ground slam, separate from interacting (E).
// Always available when the golem could act; breaks cracked debris with the
// iron arm and only lands a hit without it. It is also how the golem harvests:
// every tree, rock and log in the blow's radius takes one blow of work.
// Headless, through stepPlayer.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const inventory_1 = require("../src/game/sim/inventory");
const interact_1 = require("../src/game/sim/interact");
const analysis_1 = require("../src/game/sim/analysis");
const harvest_1 = require("../src/game/content/harvest");
const interactions_1 = require("../src/game/content/interactions");
const tasks_1 = require("../src/game/content/tasks");
const flags_1 = require("../src/game/content/flags");
const tiles_1 = require("../src/game/content/tiles");
const helpers_1 = require("./helpers");
const ATTACK = { ix: 0, iy: 0, use: false, attack: true };
const USE = { ix: 0, iy: 0, use: true };
/** What the world is (areas, flags, the golem's pack and gear), without clocks and gait. */
const worldState = (w) => {
    const s = (0, save_1.serialize)(w);
    return JSON.stringify({ areas: s.areas, flags: s.flags, inv: (0, world_1.player)(w).inventory, gear: (0, world_1.player)(w).gear });
};
const crack = (w) => (0, helpers_1.find)(w, (i) => i.kind === "cracked");
/** The golem's current task (a call, so the type checker doesn't narrow it between frames). */
const taskOf = (w) => (0, world_1.player)(w).task;
(0, node_test_1.test)("Space attacks with nothing in front: the slam plays in full, thuds, and changes nothing (arm or not)", () => {
    for (const arm of [false, true]) {
        const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
        if (arm)
            (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
        (0, helpers_1.frames)(w, 2);
        strict_1.default.equal((0, interact_1.findTarget)((0, world_1.currentArea)(w), pl), null, "nothing to interact with here");
        const before = worldState(w);
        (0, helpers_1.events)(w);
        (0, helpers_1.frame)(w, ATTACK);
        strict_1.default.equal(pl.task?.kind, "slam");
        let n = 1;
        while (pl.task && n < 500) {
            (0, helpers_1.frame)(w);
            n++;
        }
        strict_1.default.ok(Math.abs(n * helpers_1.DT - interactions_1.SLAM_TASK.dur) <= 2 * helpers_1.DT, `plays in full (${n} frames)`);
        const ev = (0, helpers_1.events)(w);
        const slams = ev.filter((e) => e.t === "slam");
        strict_1.default.equal(slams.length, 1);
        strict_1.default.ok(slams[0].t === "slam" && !slams[0].hit, "just the ground");
        strict_1.default.ok(!ev.some((e) => e.t === "wallBroken" || e.t === "withstood" || e.t === "message"));
        strict_1.default.equal(worldState(w), before, "the world is unchanged");
    }
});
(0, node_test_1.test)("no attack while another action is in progress; pressing again mid-slam doesn't restart it", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.standAt)(w, (0, helpers_1.find)(w, (i) => i.kind === "door"));
    (0, helpers_1.frame)(w, USE);
    strict_1.default.equal(taskOf(w)?.kind, "reach");
    (0, helpers_1.frame)(w, ATTACK);
    strict_1.default.equal(taskOf(w)?.kind, "reach", "busy: Space does nothing");
    while (taskOf(w))
        (0, helpers_1.frame)(w);
    (0, helpers_1.frame)(w, ATTACK);
    const task = taskOf(w);
    strict_1.default.ok(task && task.kind === "slam");
    (0, helpers_1.frames)(w, 10, ATTACK);
    strict_1.default.equal(taskOf(w), task, "the same slam carries on");
    strict_1.default.ok(task.t >= 10 * helpers_1.DT);
    (0, helpers_1.frames)(w, 5, { ix: 1, iy: 0, use: false });
    strict_1.default.equal(taskOf(w), task, "it can't be walked out of");
});
(0, node_test_1.test)("next to something interactable, E interacts and Space attacks instead, leaving it alone", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), area = (0, world_1.currentArea)(w);
    const coin = (0, helpers_1.find)(w, (i) => i.looseId === "coin");
    (0, helpers_1.standAt)(w, coin);
    strict_1.default.equal((0, interact_1.findTarget)(area, pl)?.looseId, "coin", "the coin is the interaction target");
    (0, helpers_1.events)(w);
    (0, helpers_1.slamAt)(w);
    strict_1.default.ok(!(0, inventory_1.hasItem)(pl, "coin") && !area.looseItem("coin").taken, "Space didn't pick it up");
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "slam" && !e.hit));
    (0, helpers_1.useOn)(w, coin);
    strict_1.default.ok((0, inventory_1.hasItem)(pl, "coin"), "E picks it up");
    // The locked door: Space slams the floor in front of it, E tries the door.
    const door = (0, helpers_1.find)(w, (i) => i.kind === "door");
    (0, helpers_1.standAt)(w, door);
    (0, helpers_1.events)(w);
    (0, helpers_1.slamAt)(w);
    let ev = (0, helpers_1.events)(w);
    strict_1.default.ok(ev.some((e) => e.t === "slam") && !ev.some((e) => e.t === "cue"), "no door rattle");
    strict_1.default.equal(area.tile(51, 5), tiles_1.T.LOCKED);
    (0, helpers_1.useOn)(w, door);
    ev = (0, helpers_1.events)(w);
    strict_1.default.ok(ev.some((e) => e.t === "cue" && e.cue === "clank") && !ev.some((e) => e.t === "slam"));
});
(0, node_test_1.test)("with the iron arm the slam breaks cracked debris, the moment the fists land", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), area = (0, world_1.currentArea)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
    (0, helpers_1.standAt)(w, crack(w));
    const decals0 = area.decals.length;
    (0, helpers_1.events)(w);
    (0, helpers_1.frame)(w, ATTACK);
    let at = -1, n = 1;
    for (; pl.task && n < 300; n++) {
        const t = pl.task.t;
        (0, helpers_1.frame)(w);
        const ev = (0, helpers_1.events)(w);
        if (ev.some((e) => e.t === "wallBroken")) {
            at = t + helpers_1.DT;
            strict_1.default.ok(ev.some((e) => e.t === "slam" && e.hit), "the same frame as the blow");
        }
    }
    strict_1.default.ok(Math.abs(at - tasks_1.SLAM_HIT * interactions_1.SLAM_TASK.dur) <= helpers_1.DT + 1e-9, `breaks at the impact (${at.toFixed(3)}s)`);
    strict_1.default.equal(area.tile(47, 10), tiles_1.T.FLOOR);
    strict_1.default.equal(area.tile(47, 11), tiles_1.T.FLOOR);
    strict_1.default.equal(area.decals.length, decals0 + 26, "the usual debris");
    strict_1.default.ok(!(0, interact_1.interactables)(area).some((i) => i.kind === "cracked"));
});
/** Put the golem at (x, y) facing `facing`, slam, and report what the blow did. */
const slamFrom = (w, x, y, facing) => {
    const pl = (0, world_1.player)(w);
    pl.x = x;
    pl.y = y;
    pl.vx = 0;
    pl.vy = 0;
    pl.facing = facing;
    (0, helpers_1.events)(w);
    (0, helpers_1.frame)(w, ATTACK);
    let g = 0;
    while (pl.task && g++ < 300)
        (0, helpers_1.frame)(w);
    return (0, helpers_1.events)(w);
};
(0, node_test_1.test)("the slam hits in a radius around the fists, not around the golem's centre", () => {
    // The cracked wall is tiles (47, 10-11): pixels x 752..768, y 160..192. Facing right, the fists land 10 px ahead.
    const left = 47 * tiles_1.TS, mid = 11 * tiles_1.TS;
    const cases = [
        // The golem itself is 28 px from the wall, outside the radius, but its fists land 18 px from it: hit.
        { name: "fists reach it from beyond the golem's own radius", x: left - 28, facing: "right", breaks: true },
        // Only 24 px from the fists to the wall: just out of reach.
        { name: "fists land just out of reach", x: left - 34, facing: "right", breaks: false },
        // The golem is 12 px from the wall, well inside the radius, but facing away its fists land 22 px from it: no hit.
        { name: "facing away, the golem's own proximity doesn't count", x: left - 12, facing: "left", breaks: false },
        // Fists driven straight into the wall.
        { name: "fists in the wall", x: left - 8, facing: "right", breaks: true },
    ];
    for (const c of cases) {
        const w = (0, helpers_1.newWorld)(), area = (0, world_1.currentArea)(w);
        (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
        const ev = slamFrom(w, c.x, mid, c.facing);
        const slam = ev.find((e) => e.t === "slam");
        strict_1.default.ok(slam && slam.t === "slam", `${c.name}: the slam landed`);
        strict_1.default.equal(slam.x, c.x + (c.facing === "right" ? 10 : -10), `${c.name}: centred on the fists`);
        strict_1.default.equal(slam.hit, c.breaks, c.name);
        strict_1.default.equal(ev.some((e) => e.t === "wallBroken"), c.breaks, c.name);
        strict_1.default.equal(area.tile(47, 10), c.breaks ? tiles_1.T.FLOOR : tiles_1.T.CRACKED, c.name);
    }
});
(0, node_test_1.test)("the slam's reach is a small area, about the dust it throws up (a tile or so), whichever way the golem faces", () => {
    strict_1.default.ok(tasks_1.SLAM_RADIUS >= tiles_1.TS && tasks_1.SLAM_RADIUS <= 2 * tiles_1.TS, `radius ${tasks_1.SLAM_RADIUS}px`);
    const top = 10 * tiles_1.TS - 1, bottom = 12 * tiles_1.TS;
    const w = (0, helpers_1.newWorld)();
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
    // Above the wall facing down: the fists land 3 px below the golem; level with the wall's top edge they are in it.
    strict_1.default.ok(slamFrom(w, 47 * tiles_1.TS + 8, top - 4, "down").some((e) => e.t === "wallBroken"), "from above");
    const w2 = (0, helpers_1.newWorld)();
    (0, world_1.setFlag)(w2, flags_1.FLAGS.golemArm);
    // Below the wall facing up (fists 7 px up): in reach from just under its foot, not from 4 tiles away.
    strict_1.default.ok(!slamFrom(w2, 47 * tiles_1.TS + 8, bottom + 4 * tiles_1.TS, "up").some((e) => e.t === "wallBroken"), "far below");
    strict_1.default.equal((0, world_1.currentArea)(w2).tile(47, 11), tiles_1.T.CRACKED);
    strict_1.default.ok(slamFrom(w2, 47 * tiles_1.TS + 8, bottom + 10, "up").some((e) => e.t === "wallBroken"), "just below");
});
(0, node_test_1.test)("without the arm the debris takes the hit and holds: nothing changes, and it still breaks later", () => {
    const w = (0, helpers_1.newWorld)(), area = (0, world_1.currentArea)(w);
    (0, helpers_1.frames)(w, 2);
    const before = worldState(w);
    (0, helpers_1.slamAt)(w, crack(w));
    const ev = (0, helpers_1.events)(w);
    strict_1.default.ok(ev.some((e) => e.t === "slam" && e.hit), "the slam struck it");
    const held = ev.find((e) => e.t === "withstood");
    strict_1.default.ok(held?.t === "withstood" && held.tx === 47 && held.ty === 10, "it held (the shudder's tile)");
    strict_1.default.ok(ev.some((e) => e.t === "message" && /HOLDS/.test(e.text)));
    strict_1.default.ok(!ev.some((e) => e.t === "wallBroken"));
    strict_1.default.equal(area.tile(47, 10), tiles_1.T.CRACKED);
    strict_1.default.equal(worldState(w), before, "no world change at all");
    (0, helpers_1.slamAt)(w, crack(w));
    strict_1.default.equal(area.tile(47, 10), tiles_1.T.CRACKED, "again: still holds");
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
    (0, helpers_1.slamAt)(w, crack(w));
    strict_1.default.equal(area.tile(47, 10), tiles_1.T.FLOOR, "with the arm it breaks");
});
(0, node_test_1.test)("E on the cracked wall never breaks it: it shudders and hints at Space, with or without the arm", () => {
    for (const arm of [false, true]) {
        const w = (0, helpers_1.newWorld)();
        if (arm)
            (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
        (0, helpers_1.useOn)(w, crack(w));
        const ev = (0, helpers_1.events)(w);
        strict_1.default.ok(ev.some((e) => e.t === "cue" && e.cue === "push"));
        strict_1.default.ok(ev.some((e) => e.t === "message" && /\(SPACE\)/.test(e.text)));
        strict_1.default.ok(!ev.some((e) => e.t === "slam" || e.t === "wallBroken" || e.t === "withstood"));
        strict_1.default.equal((0, world_1.currentArea)(w).tile(47, 10), tiles_1.T.CRACKED);
    }
});
(0, node_test_1.test)("the blow re-checks its target: debris gone by the impact means the slam just hits the ground", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), area = (0, world_1.currentArea)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
    (0, helpers_1.standAt)(w, crack(w));
    (0, helpers_1.frame)(w, ATTACK);
    area.setTile(47, 10, tiles_1.T.FLOOR);
    area.setTile(47, 11, tiles_1.T.FLOOR);
    const decals = area.decals.length;
    (0, helpers_1.events)(w);
    while (pl.task)
        (0, helpers_1.frame)(w);
    const ev = (0, helpers_1.events)(w);
    strict_1.default.ok(ev.some((e) => e.t === "slam" && !e.hit));
    strict_1.default.ok(!ev.some((e) => e.t === "wallBroken"));
    strict_1.default.equal(area.decals.length, decals, "no second break");
});
(0, node_test_1.test)("a slam in progress is plain task data: saved mid-swing, it lands after loading", () => {
    const w = (0, helpers_1.newWorld)();
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
    (0, helpers_1.standAt)(w, crack(w));
    (0, helpers_1.frame)(w, ATTACK);
    (0, helpers_1.frames)(w, 10);
    const w2 = (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
    strict_1.default.equal((0, world_1.player)(w2).task?.kind, "slam");
    let g = 0;
    while ((0, world_1.player)(w2).task && g++ < 300)
        (0, helpers_1.frame)(w2);
    strict_1.default.equal((0, world_1.currentArea)(w2).tile(47, 10), tiles_1.T.FLOOR);
});
// ---------------------------------------------------------------- harvesting
// Trees, rocks and logs are not interactables (E does nothing, the golem's
// vision skips them). The golem harvests by attacking near them instead.
const HARVESTABLES = Object.keys(harvest_1.HARVEST);
const wood = (w) => (0, inventory_1.countItem)((0, world_1.player)(w), "wood");
const stone = (w) => (0, inventory_1.countItem)((0, world_1.player)(w), "stone");
const harvestHits = (ev) => ev.filter((e) => e.t === "harvestHit");
(0, node_test_1.test)("standing trees, rocks and logs are not interactables: E finds nothing and the golem's vision skips them", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), area = (0, world_1.currentArea)(w);
    const props = HARVESTABLES.map((k, i) => area.addProp(k, pl.x + 14, pl.y + i * 24));
    const ids = new Set(props.map((p) => p.id));
    strict_1.default.ok(!(0, interact_1.interactables)(area).some((i) => (i.propId && ids.has(i.propId)) || i.kind === "harvest"));
    strict_1.default.ok(!(0, analysis_1.visionTargets)(w, area).some((v) => ids.has(v.id)), "not in the dungeon's vision");
    for (const p of props) {
        pl.x = p.x - 12;
        pl.y = p.y;
        pl.vx = 0;
        pl.vy = 0;
        pl.facing = "right";
        strict_1.default.equal((0, interact_1.findTarget)(area, pl), null, `${p.kind}: nothing to interact with`);
        (0, helpers_1.frame)(w, USE);
        strict_1.default.equal(pl.task, null, `${p.kind}: E starts no work`);
        strict_1.default.equal(p.dmg, 0);
    }
    // The same on the wild surface, which is full of them.
    const surface = (0, world_1.getArea)(w, "surface"), wild = surface.props.filter((p) => harvest_1.HARVEST[p.kind]);
    strict_1.default.ok(wild.length > 60, "the surface has plenty of harvestables");
    const wildIds = new Set(wild.map((p) => p.id));
    strict_1.default.ok(!(0, interact_1.interactables)(surface).some((i) => (i.propId && wildIds.has(i.propId)) || i.kind === "harvest"));
    strict_1.default.ok(!(0, analysis_1.visionTargets)(w, surface).some((v) => wildIds.has(v.id)), "not in the surface's vision");
});
(0, node_test_1.test)("a slam harvests the tree it lands in: one blow of work each, wood per blow, then the final bonus on depletion", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), area = (0, world_1.currentArea)(w);
    const tree = area.addProp("tree", pl.x + 14, pl.y), d = harvest_1.HARVEST.tree;
    const at = { x: pl.x, y: pl.y };
    for (let i = 1; i < d.hp; i++) {
        const ev = slamFrom(w, at.x, at.y, "right");
        strict_1.default.ok(ev.some((e) => e.t === "slam" && e.hit), `blow ${i} struck it`);
        strict_1.default.equal(harvestHits(ev).length, 1);
        strict_1.default.equal(tree.dmg, i);
        strict_1.default.equal(wood(w), i * d.perHit.n);
        strict_1.default.equal(tree.taken, false);
    }
    const last = slamFrom(w, at.x, at.y, "right");
    const hit = harvestHits(last)[0];
    strict_1.default.ok(hit?.t === "harvestHit" && hit.depleted && hit.prop === tree.id && hit.actor === pl.id);
    strict_1.default.equal(tree.taken, true);
    strict_1.default.equal(wood(w), d.hp * d.perHit.n + d.final.n);
    // A stump isn't harvestable: the slam just hits the ground.
    const after = slamFrom(w, at.x, at.y, "right");
    strict_1.default.ok(after.some((e) => e.t === "slam" && !e.hit) && !harvestHits(after).length);
    strict_1.default.equal(wood(w), d.hp * d.perHit.n + d.final.n, "no more wood");
    // Rocks pay stone the same way.
    const rock = area.addProp("rock", pl.x + 14, pl.y + 40), rd = harvest_1.HARVEST.rock;
    for (let i = 0; i < rd.hp; i++)
        slamFrom(w, at.x, at.y + 40, "right");
    strict_1.default.equal(rock.taken, true);
    strict_1.default.equal(stone(w), rd.hp * rd.perHit.n + rd.final.n);
});
(0, node_test_1.test)("a slam in reach of several harvestables harvests all of them at once", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), area = (0, world_1.currentArea)(w);
    // Fists land at (x + 10, y). All three footprints are within the radius of that point; the fourth tree is not.
    const tree = area.addProp("tree", pl.x + 14, pl.y);
    const rock = area.addProp("rock", pl.x + 14, pl.y + 6);
    const log = area.addProp("log", pl.x + 14, pl.y - 8);
    const far = area.addProp("tree", pl.x + 10 + 3 * tiles_1.TS * 4, pl.y);
    const ev = slamFrom(w, pl.x, pl.y, "right");
    const hits = harvestHits(ev);
    strict_1.default.deepEqual(hits.map((e) => e.t === "harvestHit" && e.prop).sort(), [tree.id, rock.id, log.id].sort());
    strict_1.default.ok(ev.some((e) => e.t === "slam" && e.hit));
    strict_1.default.equal(wood(w), 2, "one wood from the tree and one from the log");
    strict_1.default.equal(stone(w), 1, "one stone from the rock");
    for (const p of [tree, rock, log])
        strict_1.default.equal(p.dmg, 1, p.kind);
    strict_1.default.equal(far.dmg, 0, "out of reach");
    // Once one is used up, the rest carry on in the same blows.
    for (let i = 0; i < harvest_1.HARVEST.rock.hp; i++)
        slamFrom(w, pl.x, pl.y, "right");
    strict_1.default.equal(rock.taken, true);
    strict_1.default.equal(tree.taken || log.taken, true, "the quicker ones were depleted along the way too");
    strict_1.default.equal(far.dmg, 0);
});
(0, node_test_1.test)("a slam harvests only what is within the radius of the fists, wherever the golem stands", () => {
    const edge = tasks_1.SLAM_RADIUS + 5; // a tree's box is 10 px wide, centred on its x
    const cases = [
        { name: "box edge just inside the radius of the fists", at: 10 + edge, facing: "right", hit: true },
        { name: "box edge just outside it", at: 10 + edge + 1, facing: "right", hit: false },
        { name: "the golem is close, but its fists land away from the tree", at: 30, facing: "left", hit: false },
        { name: "the same tree, fists toward it", at: 30, facing: "right", hit: true },
    ];
    for (const c of cases) {
        const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), area = (0, world_1.currentArea)(w), x = pl.x, y = pl.y;
        const tree = area.addProp("tree", x + c.at, y);
        const ev = slamFrom(w, x, y, c.facing);
        strict_1.default.equal(tree.dmg > 0, c.hit, c.name);
        strict_1.default.equal(harvestHits(ev).length, c.hit ? 1 : 0, c.name);
        strict_1.default.equal(ev.some((e) => e.t === "slam" && e.hit), c.hit, c.name);
        strict_1.default.equal(wood(w), c.hit ? 1 : 0, c.name);
    }
});
(0, node_test_1.test)("harvesting needs the attack to land: a slam saved mid-swing harvests after loading, and a busy golem harvests nothing", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), area = (0, world_1.currentArea)(w);
    const tree = area.addProp("tree", pl.x + 14, pl.y);
    pl.facing = "right";
    (0, helpers_1.frame)(w, ATTACK);
    (0, helpers_1.frames)(w, 10);
    const w2 = (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
    strict_1.default.equal((0, world_1.player)(w2).task?.kind, "slam");
    strict_1.default.equal((0, world_1.currentArea)(w2).prop(tree.id).dmg, 0, "nothing yet: the blow hasn't landed");
    let g = 0;
    while ((0, world_1.player)(w2).task && g++ < 300)
        (0, helpers_1.frame)(w2);
    strict_1.default.equal((0, world_1.currentArea)(w2).prop(tree.id).dmg, 1);
    strict_1.default.equal((0, inventory_1.countItem)((0, world_1.player)(w2), "wood"), 1);
    // Mid-task, Space is ignored, so nothing is harvested.
    const w3 = (0, helpers_1.newWorld)(), busy = (0, world_1.player)(w3), t3 = (0, world_1.currentArea)(w3).addProp("tree", busy.x + 14, busy.y);
    busy.facing = "right";
    const door = (0, helpers_1.find)(w3, (i) => i.kind === "door");
    (0, helpers_1.standAt)(w3, door);
    (0, helpers_1.frame)(w3, USE);
    (0, helpers_1.frame)(w3, ATTACK);
    strict_1.default.equal(taskOf(w3)?.kind, "reach");
    strict_1.default.equal(t3.dmg, 0);
});
