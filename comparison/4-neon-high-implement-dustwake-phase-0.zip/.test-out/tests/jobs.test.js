"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const actors_1 = require("../src/game/content/actors");
const jobs_1 = require("../src/game/content/jobs");
const runes_1 = require("../src/game/content/runes");
const tiles_1 = require("../src/game/content/tiles");
const world_1 = require("../src/game/world/world");
const areas_1 = require("../src/game/world/areas");
const foundationAreas_1 = require("../src/game/world/foundationAreas");
const save_1 = require("../src/game/world/save");
const debugFoundations_1 = require("../src/game/sim/debugFoundations");
const jobs_2 = require("../src/game/sim/jobs");
const step_1 = require("../src/game/sim/step");
const inventory_1 = require("../src/game/sim/inventory");
const collision_1 = require("../src/game/sim/collision");
const navigation_1 = require("../src/game/sim/navigation");
const runes_2 = require("../src/game/sim/runes");
(0, debugFoundations_1.registerFoundations)();
const DT = 0.05;
const worker = (w) => (0, world_1.actorById)(w, "debug.worker");
const stock = (w) => (0, world_1.getArea)(w, "debug_workshop").prop("chest.fixture").inventory.reduce((n, s) => n + (s?.item === "wood" ? s.n : 0), 0);
function until(w, check, limit = 4000) {
    for (let i = 0; i < limit && !check(); i++)
        (0, step_1.stepWorld)(w, DT);
    strict_1.default.ok(check(), JSON.stringify(w.actors.filter((a) => a.job).map((a) => ({ id: a.id, x: a.x, y: a.y, area: a.area, job: a.job }))));
}
const walk = (area, x, y) => ({ kind: "walk", args: { area, x, y } });
(0, node_test_1.test)("a smaller worker walks, travels, harvests eight times and deposits six wood across areas", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), a = worker(w);
    (0, world_1.clearFlag)(w, "tutorial.done");
    strict_1.default.notDeepEqual((0, actors_1.actorDef)(a).body.box, (0, actors_1.actorDef)((0, world_1.player)(w)).body.box);
    const origin = { x: a.x, y: a.y };
    until(w, () => a.job?.status === "done");
    strict_1.default.equal(stock(w), 6);
    strict_1.default.equal((0, inventory_1.countItem)(a, "wood"), 0);
    strict_1.default.equal(a.inventory.length, 8);
    strict_1.default.equal(a.area, "debug_workshop");
    strict_1.default.ok(Math.hypot(a.x - origin.x, a.y - origin.y) > 16);
    const hops = w.events.filter((e) => e.t === "travelled" && e.actor === a.id);
    strict_1.default.equal(hops.length, 2);
    strict_1.default.equal(w.events.filter((e) => e.t === "harvestHit" && e.actor === a.id).length, 8);
    strict_1.default.equal(w.flags.has("tutorial.done"), false, "workers cannot complete the player's tutorial");
    strict_1.default.equal(a.task, null);
    strict_1.default.equal(a.moving, false);
    const pos = [a.x, a.y];
    for (let i = 0; i < 100; i++)
        (0, step_1.stepWorld)(w, DT);
    strict_1.default.deepEqual([a.x, a.y], pos, "no idle wandering");
});
for (const phase of ["walking", "channel", "harvest", "deposit-fired"]) {
    (0, node_test_1.test)(`save/load during ${phase}: the order, path and receipts continue identically`, () => {
        const w = (0, debugFoundations_1.foundationDemo)();
        until(w, () => {
            const a = worker(w);
            if (phase === "walking")
                return !!a.job?.nav?.path.length && a.moving;
            if (phase === "channel")
                return a.task?.kind === "channel" && a.task.t > 0.5;
            if (phase === "harvest")
                return a.task?.kind === "punch" && a.task.t > 0.15 && !a.task.fired;
            return a.task?.effect?.op === "deposit" && a.task.fired;
        });
        const loaded = (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
        strict_1.default.deepEqual((0, save_1.serialize)(loaded), (0, save_1.serialize)(w));
        for (let i = 0; i < 4000 && worker(w).job?.status !== "done"; i++) {
            (0, step_1.stepWorld)(w, DT);
            (0, step_1.stepWorld)(loaded, DT);
        }
        strict_1.default.equal(worker(w).job?.status, "done");
        strict_1.default.equal(stock(loaded), 6);
        strict_1.default.deepEqual((0, save_1.serialize)(loaded), (0, save_1.serialize)(w));
    });
}
(0, node_test_1.test)("a non-golem with a worker capability runs the same job; actor.kind is irrelevant", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), a = worker(w);
    (0, jobs_2.cancelJob)(w, a);
    a.definition = "npc_worker";
    a.kind = "special-villager";
    a.powerCore = null;
    strict_1.default.ok((0, jobs_2.assignJob)(w, a, (0, jobs_2.gatherOrder)("stone", "debug_yard", { area: "debug_workshop", prop: "chest.fixture" }, 5)));
    until(w, () => a.job?.status === "done");
    strict_1.default.equal((0, world_1.getArea)(w, "debug_workshop").prop("chest.fixture").inventory.reduce((n, s) => n + (s?.item === "stone" ? s.n : 0), 0), 5);
    strict_1.default.equal(w.events.filter((e) => e.t === "harvestHit" && e.actor === a.id).length, 4);
});
(0, node_test_1.test)("power loss and manual pause preserve a partial task and do not consume anything twice", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), a = worker(w);
    until(w, () => a.task?.kind === "punch" && !a.task.fired && a.task.t > 0.1);
    const t = a.task.t, damage = (0, world_1.getArea)(w, a.area).prop("tree.fixture").dmg;
    a.powerCore = null;
    for (let i = 0; i < 50; i++)
        (0, step_1.stepWorld)(w, DT);
    strict_1.default.equal(a.task.t, t);
    strict_1.default.equal(a.job?.reason, "power");
    strict_1.default.equal((0, world_1.getArea)(w, a.area).prop("tree.fixture").dmg, damage);
    const loaded = (0, save_1.deserialize)((0, save_1.serialize)(w)), b = worker(loaded);
    (0, jobs_2.pauseJob)(loaded, b);
    b.powerCore = "ruby_core";
    for (let i = 0; i < 20; i++)
        (0, step_1.stepWorld)(loaded, DT);
    strict_1.default.equal(b.task.t, t);
    strict_1.default.equal(b.job?.reason, "manual");
    (0, jobs_2.resumeJob)(loaded, b);
    until(loaded, () => b.job?.status === "done");
    strict_1.default.equal(stock(loaded), 6);
});
(0, node_test_1.test)("walk-up order changes cancel only owned work, and cannot be issued remotely", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), a = worker(w), pl = (0, world_1.player)(w);
    const previousId = a.job.id;
    strict_1.default.ok((0, jobs_2.setWorkerOrder)(w, pl, a.id, walk(a.area, 88, 123)));
    strict_1.default.ok(a.job.id > previousId);
    const snapshot = JSON.stringify(a.job);
    pl.x = 20;
    pl.y = 20;
    strict_1.default.equal((0, jobs_2.setWorkerOrder)(w, pl, a.id, null), false);
    strict_1.default.equal(JSON.stringify(a.job), snapshot);
    pl.x = a.x;
    pl.y = a.y + 12;
    strict_1.default.ok((0, jobs_2.setWorkerOrder)(w, pl, a.id, null));
    strict_1.default.equal(a.job, null);
    strict_1.default.equal(a.task, null);
    strict_1.default.equal((0, inventory_1.countItem)(a, "wood"), 0);
});
(0, node_test_1.test)("crafting jobs stay at the station, use nearby storage and retain the chisel across a fired-task save", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), a = worker(w), area = (0, world_1.getArea)(w, "debug_workshop"), bench = area.prop("bench.fixture");
    (0, jobs_2.cancelJob)(w, a);
    a.x = bench.x - 20;
    a.y = bench.y + 16;
    area.setInventory("chest.fixture", [{ item: "cut_stone", n: 4 }]);
    (0, inventory_1.addItems)(w, a, "chisel", 1);
    strict_1.default.ok((0, jobs_2.assignJob)(w, a, (0, jobs_2.craftOrder)({ area: area.id, prop: bench.id }, "rune_swift", 2)));
    until(w, () => !!a.task?.fired && a.job?.result === true);
    strict_1.default.equal(a.job.completed, 0, "completion receipt is waiting for the task to finish");
    const loaded = (0, save_1.deserialize)((0, save_1.serialize)(w));
    until(loaded, () => worker(loaded).job?.status === "done");
    strict_1.default.equal(worker(loaded).job.completed, 2);
    strict_1.default.equal((0, inventory_1.countItem)(worker(loaded), "rune_swift"), 2);
    strict_1.default.equal((0, inventory_1.countItem)(worker(loaded), "chisel"), 1);
    strict_1.default.equal((0, world_1.getArea)(loaded, area.id).prop("chest.fixture").inventory.filter(Boolean).length, 0);
});
(0, node_test_1.test)("a crafter with a full pack blocks before consumption and can be resumed after making room", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), a = worker(w), area = (0, world_1.getArea)(w, a.area), bench = area.prop("bench.fixture");
    (0, jobs_2.cancelJob)(w, a);
    a.x = bench.x - 20;
    a.y = bench.y + 16;
    (0, inventory_1.addItems)(w, a, "coin", 8);
    area.setInventory("chest.fixture", [{ item: "wood", n: 2 }]);
    strict_1.default.ok((0, jobs_2.assignJob)(w, a, (0, jobs_2.craftOrder)({ area: area.id, prop: bench.id }, "planks", 1)));
    until(w, () => a.job?.status === "blocked");
    strict_1.default.equal(a.job.reason, "packFull");
    strict_1.default.equal(stock(w), 2);
    a.inventory[0] = null;
    (0, jobs_2.resumeJob)(w, a);
    until(w, () => a.job?.status === "done");
    strict_1.default.equal((0, inventory_1.countItem)(a, "planks"), 3);
    strict_1.default.equal(stock(w), 0);
});
(0, node_test_1.test)("a full deposit chest blocks and a removed resource never loops a harvest task", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), a = worker(w), area = (0, world_1.getArea)(w, "debug_workshop");
    area.setInventory("chest.fixture", Array.from({ length: 32 }, () => ({ item: "coin", n: 1 })));
    until(w, () => a.job?.status === "blocked" && a.job.reason === "storageFull");
    strict_1.default.equal((0, inventory_1.countItem)(a, "wood"), 6);
    strict_1.default.equal(a.task, null);
    const loaded = (0, save_1.deserialize)((0, save_1.serialize)(w));
    (0, world_1.getArea)(loaded, area.id).setInventory("chest.fixture", []);
    (0, jobs_2.resumeJob)(loaded, worker(loaded));
    until(loaded, () => worker(loaded).job?.status === "done");
    strict_1.default.equal(stock(loaded), 6);
    const empty = (0, debugFoundations_1.foundationDemo)(), b = worker(empty);
    (0, world_1.getArea)(empty, "debug_yard").removeProp("tree.fixture");
    until(empty, () => b.job?.status === "blocked" && b.job.reason === "noResource");
    strict_1.default.equal(b.task, null);
});
function corridor(bay) {
    areas_1.AREAS.corridor = () => {
        const area = (0, foundationAreas_1.buildFoundationArea)("debug_yard");
        area.id = "corridor";
        area.props = [];
        area.grid.fill(tiles_1.T.WALL);
        for (let x = 1; x < area.w - 1; x++)
            area.grid[4 * area.w + x] = tiles_1.T.FLOOR;
        if (bay) {
            area.grid[3 * area.w + 8] = tiles_1.T.FLOOR;
            area.grid[3 * area.w + 9] = tiles_1.T.FLOOR;
        }
        area.plan = area.grid.slice();
        return area;
    };
    const w = (0, world_1.createWorld)(77);
    (0, world_1.getArea)(w, "corridor");
    const a = (0, world_1.makeActor)("a", "worker_golem", "corridor", 3 * tiles_1.TS + 8, 4 * tiles_1.TS + 11);
    const b = (0, world_1.makeActor)("z", "worker_golem", "corridor", 12 * tiles_1.TS + 8, 4 * tiles_1.TS + 11);
    a.powerCore = b.powerCore = "ruby_core";
    w.actors.push(a, b);
    (0, jobs_2.assignJob)(w, a, walk(a.area, b.x, b.y));
    (0, jobs_2.assignJob)(w, b, walk(b.area, a.x, a.y));
    return { w, a, b };
}
function overlaps(a, b) {
    const x = (0, collision_1.actorBox)(a), y = (0, collision_1.actorBox)(b);
    return x[0] < y[2] - 0.001 && x[2] > y[0] + 0.001 && x[1] < y[3] - 0.001 && x[3] > y[1] + 0.001;
}
(0, node_test_1.test)("opposing workers yield into a passing bay without overlap or teleporting", () => {
    const { w, a, b } = corridor(true);
    let yielded = false;
    for (let i = 0; i < 2400 && (a.job?.status !== "done" || b.job?.status !== "done"); i++) {
        const positions = [[a.x, a.y], [b.x, b.y]];
        (0, step_1.stepWorld)(w, DT);
        yielded || (yielded = !!a.job?.nav?.yielding || !!b.job?.nav?.yielding);
        strict_1.default.equal(overlaps(a, b), false);
        for (const [n, actor] of [a, b].entries())
            strict_1.default.ok(Math.hypot(actor.x - positions[n][0], actor.y - positions[n][1]) <= 16 * DT + 0.01);
    }
    strict_1.default.equal(a.job?.status, "done", JSON.stringify(a.job));
    strict_1.default.equal(b.job?.status, "done", JSON.stringify(b.job));
    strict_1.default.ok(yielded, "the narrower corridor needs explicit cooperation");
});
(0, node_test_1.test)("impossible bottlenecks settle into resumable blocked orders with bounded retries", () => {
    const { w, a, b } = corridor(false);
    for (let i = 0; i < 2600; i++) {
        (0, step_1.stepWorld)(w, DT);
        strict_1.default.equal(overlaps(a, b), false);
    }
    const blocked = [a, b].filter((a) => a.job?.status === "blocked");
    strict_1.default.ok(blocked.length, "impossible traffic is reported, not left doing work forever");
    for (const a of blocked) {
        strict_1.default.equal(a.job?.reason, "pathBlocked");
        strict_1.default.equal(a.job?.failures, 3);
        strict_1.default.equal(a.moving, false);
    }
    const loaded = (0, save_1.deserialize)((0, save_1.serialize)(w));
    strict_1.default.deepEqual((0, save_1.serialize)(loaded), (0, save_1.serialize)(w));
    const area = (0, world_1.getArea)(w, "corridor");
    for (let x = 1; x < area.w - 1; x++)
        area.setTile(x, 3, tiles_1.T.FLOOR);
    for (const a of blocked)
        (0, jobs_2.resumeJob)(w, a);
    until(w, () => a.job?.status === "done" && b.job?.status === "done");
});
(0, node_test_1.test)("navigation caches per body and layout, and replans after a wall changes", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), a = worker(w), area = (0, world_1.getArea)(w, a.area);
    (0, jobs_2.cancelJob)(w, a);
    const grid = (0, navigation_1.navGrid)(area, a);
    strict_1.default.equal((0, navigation_1.navGrid)(area, a), grid);
    strict_1.default.notEqual((0, navigation_1.navGrid)(area, (0, world_1.player)(w)), grid, "different footprints have different grids");
    strict_1.default.ok((0, navigation_1.findPath)(w, a, { x: 40, y: 43, range: 1 }));
    area.setTile(2, 2, tiles_1.T.WALL);
    strict_1.default.notEqual((0, navigation_1.navGrid)(area, a), grid);
    (0, jobs_2.assignJob)(w, a, walk(area.id, 40, 123));
    until(w, () => a.job?.status === "done");
    strict_1.default.ok((0, collision_1.boxFree)(area, a.x, a.y, (0, collision_1.actorBoxes)(w, area.id, a.id), (0, actors_1.actorDef)(a).body.box));
});
(0, node_test_1.test)("rune routing respects direction, activation and data-only multi-hop links", () => {
    const w = (0, debugFoundations_1.foundationDemo)();
    const link = runes_1.RUNE_LINKS.find((l) => l.a === "debug_yard");
    link.oneWay = true;
    strict_1.default.equal((0, runes_2.runeRoute)(w, "debug_workshop", "debug_yard"), null);
    strict_1.default.equal((0, runes_2.runeRoute)(w, "debug_yard", "debug_workshop").length, 1);
    delete link.oneWay;
    runes_1.RUNE_NODES.annex = { id: "annex", area: "annex", prop: "annex", flag: "rune.annex.active", name: "ANNEX", arrive: { dx: 0, dy: 10, facing: "down" } };
    const extra = { a: "debug_yard", b: "annex", awakens: false };
    runes_1.RUNE_LINKS.push(extra);
    strict_1.default.equal((0, runes_2.runeRoute)(w, "debug_workshop", "annex"), null);
    extra.awakens = true;
    strict_1.default.deepEqual((0, runes_2.runeRoute)(w, "debug_workshop", "annex"), [{ from: "debug_workshop", to: "debug_yard" }, { from: "debug_yard", to: "annex" }]);
    runes_1.RUNE_LINKS.splice(runes_1.RUNE_LINKS.indexOf(extra), 1);
    delete runes_1.RUNE_NODES.annex;
});
(0, node_test_1.test)("blocked rune arrivals preserve the actor and its order instead of overlapping a body or looping channels", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), a = worker(w), yard = (0, world_1.getArea)(w, "debug_yard");
    until(w, () => a.task?.kind === "channel");
    yard.removeProp("rune.debug_yard");
    until(w, () => a.job?.status === "blocked");
    strict_1.default.equal(a.area, "debug_workshop");
    strict_1.default.equal(a.job?.reason, "arrivalBlocked");
    strict_1.default.equal(a.task, null);
});
(0, node_test_1.test)("the player can run an order through the same handler and locomotion path", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), pl = (0, world_1.player)(w);
    (0, jobs_2.cancelJob)(w, worker(w));
    strict_1.default.ok((0, jobs_2.assignJob)(w, pl, walk(pl.area, 72, 139)));
    for (let i = 0; i < 500 && pl.job?.status !== "done"; i++) {
        (0, step_1.stepPlayer)(w, DT, { ix: 0, iy: 0, use: false });
        (0, step_1.stepWorld)(w, DT);
    }
    strict_1.default.equal(pl.job?.status, "done");
});
(0, node_test_1.test)("a new job kind is a registry row and a small handler, with no scheduler branch", () => {
    jobs_1.JOB_KINDS.waitFixture = { phase: "wait", capabilities: [] };
    jobs_2.JOB_HANDLERS.waitFixture = { validate: (args) => typeof args.until === "number", step: (w, a, job) => {
            if (w.time >= job.args.until) {
                job.status = "done";
                job.completed = 1;
                a.moving = false;
            }
        } };
    try {
        const w = (0, debugFoundations_1.foundationDemo)(), a = worker(w);
        (0, jobs_2.cancelJob)(w, a);
        strict_1.default.ok((0, jobs_2.assignJob)(w, a, { kind: "waitFixture", args: { until: 1 } }));
        (0, step_1.stepWorld)(w, 0.25);
        const loaded = (0, save_1.deserialize)((0, save_1.serialize)(w));
        until(loaded, () => worker(loaded).job?.status === "done");
        strict_1.default.equal(worker(loaded).job?.completed, 1);
    }
    finally {
        delete jobs_2.JOB_HANDLERS.waitFixture;
        delete jobs_1.JOB_KINDS.waitFixture;
    }
});
(0, node_test_1.test)("a dormant worker resumes its saved order when powered without a new assignment", () => {
    const w = (0, debugFoundations_1.foundationDemo)(), a = worker(w);
    a.powerCore = null;
    (0, step_1.stepWorld)(w, DT);
    strict_1.default.equal(a.job?.status, "paused");
    const loaded = (0, save_1.deserialize)((0, save_1.serialize)(w)), b = worker(loaded);
    b.powerCore = "ruby_core";
    (0, world_1.setFlag)(loaded, "know.build");
    until(loaded, () => b.job?.status === "done");
    strict_1.default.equal(stock(loaded), 6);
});
