"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Procedural art regression: renders every pre-existing prop sprite variant,
// item icon and the full dungeon background bake through a recording fake
// canvas, and compares the draw-call trace hash with a golden value captured
// from the original `switch`-based art.ts (before the registry refactor).
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const props_1 = require("../src/game/art/props");
const items_1 = require("../src/game/art/items");
const tiles_1 = require("../src/game/art/tiles");
const map_1 = require("../src/game/map");
const util_1 = require("../src/game/util");
/** Prop kinds that existed before this change (sprite keys in art.ts). */
const LEGACY_PROPS = [
    "torch", "banner", "chains", "bookshelf", "shelfrow", "shelf_fallen", "table", "lectern", "chair", "chair_fallen",
    "bed", "footlocker", "weaponrack", "limbrack", "armorstand", "barrel", "crate", "sack", "statue", "statue_fallen",
    "throne", "maptable", "altar", "pew", "workbench", "forge", "anvil", "cradle", "slab", "parts", "hearth",
    "longtable", "bench", "chest", "pot", "brazier", "fountain", "pedestal", "mushrooms", "skeleton", "candles",
    "ladder", "bucket",
];
const LEGACY_ITEMS = ["chisel", "arm", "key", "core", "glyph0", "glyph1", "glyph2", "glyph3", "schematic", "crown", "goblet", "coin"];
// bake: updated deliberately for the collapsed SURFACE GATE (map.ts): the
// corridor's floor style became spilled earth, two rubble tiles at the corridor
// mouth, and 39 entrance decals appended after the procedural pass (all within
// tiles x 32-39, y 46-49). Everything else in the dungeon is unchanged
// (was "558f8993").
// items: updated deliberately for the crown's retexture (its main stone is now the High-Grade Ruby, set in the
// band): with the old crown function swapped back in, this list still hashes to the previous "6cae5365", so
// no other legacy icon moved.
// props and bake: updated deliberately for the dungeon audit (docs/ARCHITECTURE.md: "The dungeon audit").
// Compared pixel for pixel with the art and the builder as they were before it:
//   props (was "9b046139"): of every prop sprite only `bed` (no black band across the unmade cot; two new
//     variants with the head to the south) and `brazier` (a tripod that shows on dark tiles) differ.
//   bake (was "c475d9be"): only the cracked wall's two tiles and the six round them differ (it bakes as wall
//     mass now: tiles 46-48,9-12), and tiles 32-33,48-50 and 38,48-50, where three root decals at the SURFACE
//     GATE were moved off the top of the south wall. The 667 other decals are where they were: the throne
//     hall's pillars were re-spaced without disturbing the scatter (map.ts).
// The entrance update (v14) redrew the artificery's smelter and anvil and the armory's rack and stand, and laid
// the stair up to the surface. Checked against the tree as it was, sprite by sprite and pixel by pixel:
//   props (was "4dffe010"): of the legacy sprites only `forge`, `anvil`, `weaponrack` and `armorstand` differ
//     (the town keeps the old rack and stand as `shoprack` / `shopstand`).
//   bake (was "21fe34d"): 35 tiles differ, all meant to: the stair (tiles 34-37,50-55 and the two wall tiles
//     beside its last row: steps under the fall, where there was earth and wall) and the six decals added to the
//     two rooms (scorch 5-6,40-41; chalk and paper 6,8,9,44; fallen weapons 65,8 and 63,9).
// The rock and stair retexture (docs/ARCHITECTURE.md: "Rocks and the stair, redrawn") gave the flight in the
// halls the same steps as its head and its foot (art/stairs.ts). Checked against the tree as it was, pixel by
// pixel:
//   bake (was "d198b0dd"): 24 tiles differ, the stair's own (34-37,50-55) and nothing else; no tile, style or
//     decal changed, only how a stair tile is drawn.
//   props: unmoved. None of the legacy sprites was touched (the rocks and the stair's props came later).
// bake: updated deliberately for the stair below, redrawn with depth (docs/ARCHITECTURE.md): compared tile by tile
// with the bake as it was, 32 tiles differ, all within x 34-37, y 48-55: the passage's own 24 (two rows of flags,
// then the flight with its cheek walls) and the earth laid at its mouth, where the stair's foot used to be drawn.
// The other 4000 tiles are unchanged (was "e5a0da2e").
const GOLDEN = { props: "e200e828", items: "7dcab441", bake: "6623af73" };
(0, node_test_1.test)("legacy prop sprites are pixel-identical", () => {
    (0, fakeCanvas_1.resetTrace)();
    for (const k of LEGACY_PROPS)
        for (let v = 0; v < 4; v++)
            for (const alt of [false, true])
                (0, props_1.propSprite)(k, v, alt);
    strict_1.default.equal((0, fakeCanvas_1.traceHash)(), GOLDEN.props);
});
(0, node_test_1.test)("legacy item icons are pixel-identical", () => {
    (0, fakeCanvas_1.resetTrace)();
    for (const id of LEGACY_ITEMS)
        (0, items_1.itemIcon)(id);
    strict_1.default.equal((0, fakeCanvas_1.traceHash)(), GOLDEN.items);
});
(0, node_test_1.test)("dungeon background bake is pixel-identical", () => {
    (0, fakeCanvas_1.resetTrace)();
    const d = (0, map_1.buildDungeon)();
    const c = (0, util_1.makeCanvas)(d.w * 16, d.h * 16);
    (0, tiles_1.bakeRegion)(c.ctx, d, 0, 0, d.w - 1, d.h - 1);
    strict_1.default.equal((0, fakeCanvas_1.traceHash)(), GOLDEN.bake);
});
