"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The real host (Game) on the fake canvas, driven by key presses: on the play
// screen Space attacks and E / Enter interact, independently, even facing the
// same interactable; overlays keep their own keys (Space still confirms in the
// pack, and nothing attacks behind it). No browser: update() only, no render.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const g0 = globalThis;
g0.localStorage ?? (g0.localStorage = { getItem: () => null, setItem: () => { }, removeItem: () => { } });
const game_1 = require("../src/game/game");
const world_1 = require("../src/game/world/world");
const inventory_1 = require("../src/game/sim/inventory");
const debug_1 = require("../src/game/sim/debug");
const gear_1 = require("../src/game/content/gear");
const flags_1 = require("../src/game/content/flags");
const gear_2 = require("../src/game/sim/gear");
const helpers_1 = require("./helpers");
const canvas = () => globalThis.document.createElement("canvas");
function play() {
    const g = new game_1.Game(canvas(), canvas());
    const w = (0, helpers_1.newWorld)();
    g.resume(w);
    return { g, w };
}
const tick = (g, n = 1) => { for (let i = 0; i < n; i++)
    g.update(1 / 60); };
const press = (g, key) => { g.keyDown(key); tick(g); g.keyUp(key); };
(0, node_test_1.test)("play screen: Space slams and E / Enter interact, independently, facing the same interactable", () => {
    const { g, w } = play();
    (0, helpers_1.standAt)(w, (0, helpers_1.find)(w, (i) => i.looseId === "coin"));
    tick(g);
    press(g, " ");
    strict_1.default.equal((0, world_1.player)(w).task?.kind, "slam", "Space attacks");
    strict_1.default.ok(!(0, world_1.currentArea)(w).looseItem("coin").taken, "Space doesn't interact");
    tick(g, 90);
    strict_1.default.equal((0, world_1.player)(w).task, null, "the slam finished");
    press(g, "e");
    strict_1.default.equal((0, world_1.player)(w).task?.kind, "reach", "E interacts");
    tick(g, 60);
    strict_1.default.ok((0, world_1.currentArea)(w).looseItem("coin").taken);
    (0, helpers_1.standAt)(w, (0, helpers_1.find)(w, (i) => i.kind === "door"));
    tick(g);
    press(g, "enter");
    strict_1.default.equal((0, world_1.player)(w).task?.kind, "reach", "Enter is still an interact alias");
});
(0, node_test_1.test)("overlays keep their keys: in the pack Space uses the selected item, and no slam starts behind it", () => {
    const { g, w } = play();
    (0, inventory_1.addItems)(w, (0, world_1.player)(w), "basket", 1);
    press(g, "i");
    strict_1.default.ok(g.screens.is("inv"), "pack open");
    press(g, " ");
    strict_1.default.equal((0, gear_2.wornIn)((0, world_1.player)(w), "back"), "basket", "Space put it on, like E");
    strict_1.default.equal((0, world_1.player)(w).task, null, "nothing attacked behind the pack");
    press(g, "escape");
    strict_1.default.ok(g.screens.is("play"));
});
(0, node_test_1.test)("Ctrl+6 gear kit: unlocks every slot, and the pack's paper doll wears a rune the glow follows", () => {
    const { g, w } = play();
    const pl = (0, world_1.player)(w);
    g.debugKey(6);
    strict_1.default.ok((0, debug_1.allSlotsUnlocked)(w), "all locked slots are open");
    strict_1.default.equal(g.debugMsg?.text, "DEBUG: GEAR KIT ON - ALL SLOTS UNLOCKED");
    tick(g);
    strict_1.default.equal(g.glight.rad, gear_1.GOLEM_LIGHT.rad, "the standard glow before the rune");
    press(g, "i");
    strict_1.default.ok(g.screens.is("inv"));
    // put the rune of glow on from the pack (move the cursor to it, E)
    g.packUi.cursor = pl.inventory.findIndex((s) => s?.item === "rune_glow");
    press(g, "e");
    strict_1.default.equal((0, gear_2.wornIn)(pl, "rune0"), "rune_glow");
    strict_1.default.equal(g.packUi.slot, "rune0", "the cursor follows the rune onto the doll");
    press(g, "escape");
    tick(g, 3);
    strict_1.default.equal(g.glight.rad, gear_1.RUNE_GLOW_LIGHT.rad, "the light system applies the sim's glow");
    g.debugKey(6);
    strict_1.default.ok(!(0, debug_1.allSlotsUnlocked)(w), "second press locks them again");
    strict_1.default.equal(g.debugMsg?.text, "DEBUG: GEAR KIT OFF - SLOTS LOCKED AGAIN");
});
(0, node_test_1.test)("crafting through the host: E at a bench opens the plans, CRAFT works at the bench, and the plans reopen after", () => {
    const { g, w } = play();
    const pl = (0, world_1.player)(w);
    w.flags.add(flags_1.FLAGS.knowBuild);
    (0, inventory_1.addItems)(w, pl, "chisel", 1);
    (0, inventory_1.addItems)(w, pl, "wood", 4);
    const bench = (0, world_1.currentArea)(w).prop("workbench@13.5,37");
    (0, world_1.currentArea)(w).setPropState(bench.id, { taken: true }); // its chisel is already in the pack
    (0, helpers_1.standAt)(w, (0, helpers_1.find)(w, (i) => i.propId === bench.id));
    tick(g);
    press(g, "e");
    tick(g, 30);
    strict_1.default.ok(g.screens.is("crafting"), "the bench opened its plans");
    press(g, "e");
    press(g, "e");
    strict_1.default.ok(g.screens.is("play") && pl.task?.kind === "craft", "CRAFT starts the work with the world running");
    tick(g, 90);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "planks"), 3);
    strict_1.default.ok(g.screens.is("crafting"), "the plans are back for the next one");
    press(g, "escape");
    strict_1.default.ok(g.screens.is("play"));
});
(0, node_test_1.test)("the scan key reaches sim state on play but cannot toggle it through a paused overlay", () => {
    const { g, w } = play();
    press(g, "z");
    strict_1.default.equal((0, world_1.player)(w).mode, "scan");
    press(g, "i");
    press(g, "z");
    strict_1.default.equal((0, world_1.player)(w).mode, "scan");
    press(g, "escape");
    press(g, "z");
    strict_1.default.equal((0, world_1.player)(w).mode, "normal");
});
(0, node_test_1.test)("worker events cannot open player screens, show pickups or mark the player's teleport complete", () => {
    const { g, w } = play();
    const a = (0, world_1.makeActor)("worker", "worker_golem", "surface", 100, 100);
    w.actors.push(a);
    w.events.push({ t: "teleport", actor: a.id, first: true, x: 100, y: 100 }, { t: "runeAwakened", actor: a.id, rune: "surface" }, { t: "travelled", actor: a.id, from: "dungeon", to: "surface", rune: "rune.surface" }, { t: "itemGained", actor: a.id, item: "wood", n: 1, stored: true }, { t: "openStation", actor: a.id, prop: "bench", station: "crafting" }, { t: "message", actor: a.id, text: "WORKER HAS NO MATERIALS" });
    g.drainEvents();
    strict_1.default.ok(g.screens.is("play"));
    strict_1.default.equal(g.toast, null);
    strict_1.default.equal(g.note, null);
    strict_1.default.equal(g.tele.travelled, false);
});
(0, node_test_1.test)("nearby worker feedback stays in the world and never becomes a player note", () => {
    const { g, w } = play();
    const pl = (0, world_1.player)(w);
    const a = (0, world_1.makeActor)("near", "worker_golem", pl.area, pl.x + 20, pl.y);
    w.actors.push(a);
    const before = g.particles.length;
    w.events.push({ t: "harvestHit", actor: a.id, prop: "tree.fixture", kind: "tree", x: a.x, y: a.y, depleted: false }, { t: "cue", cue: "scrapeDust", x: a.x, y: a.y, actor: a.id }, { t: "message", actor: a.id, text: "WORKER IS BUSY" });
    g.drainEvents();
    strict_1.default.ok(g.particles.length > before, "nearby work makes local dust/debris");
    strict_1.default.equal(g.note, null, "a nearby worker's message is not the player's note");
    strict_1.default.equal(g.toast, null);
    strict_1.default.ok(g.screens.is("play"));
});
