"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Vision mode: the analysis state the overlay reads from the sim, and the host
// overlay's cues (switch on/off, the live lock-in when a scan completes). The
// host runs on the fake canvas: update() only, no render.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const g0 = globalThis;
g0.localStorage ?? (g0.localStorage = { getItem: () => null, setItem: () => { }, removeItem: () => { } });
const game_1 = require("../src/game/game");
const world_1 = require("../src/game/world/world");
const analysis_1 = require("../src/game/sim/analysis");
const vision_1 = require("../src/game/content/vision");
const tiles_1 = require("../src/game/content/tiles");
const helpers_1 = require("./helpers");
const tasks_1 = require("../src/game/sim/tasks");
(0, node_test_1.test)("vision targets carry analysis state: pending until every plan is read, absent when there is nothing to read", () => {
    const w = (0, helpers_1.newWorld)(), area = (0, world_1.currentArea)(w);
    const brazier = (0, analysis_1.visionTargets)(w, area).find((t) => t.id === "brazier@33,23");
    strict_1.default.equal(brazier.category, "buildable");
    strict_1.default.equal(brazier.analysis, "pending");
    for (const t of (0, analysis_1.visionTargets)(w, area))
        if (t.source !== "prop")
            strict_1.default.equal(t.analysis, undefined, `${t.id} has nothing to analyze`);
    // one plan covers every brazier: reading it flips them all at once
    w.flags.add((0, vision_1.analysisFlag)("brazier"));
    for (const t of (0, analysis_1.visionTargets)(w, area).filter((t) => t.id.startsWith("brazier@")))
        strict_1.default.equal(t.analysis, "done");
    strict_1.default.equal((0, analysis_1.analysisState)(w, area.prop("brazier@33,23")), "done");
});
(0, node_test_1.test)("the four category colours are unchanged, and each category has its own hologram effect", () => {
    strict_1.default.deepEqual(Object.fromEntries(Object.entries(vision_1.VISION_CATEGORIES).map(([k, v]) => [k, v.color])), { important: "#ffd27a", interactable: "#74dce2", npc: "#c5a0ff", buildable: "#97d38a" });
    strict_1.default.equal(new Set(Object.values(vision_1.VISION_CATEGORIES).map((v) => v.effect)).size, 4);
});
(0, node_test_1.test)("interactive tile targets are cached but follow tile changes", () => {
    const w = (0, helpers_1.newWorld)(), area = (0, world_1.currentArea)(w);
    const tiles = () => (0, analysis_1.visionTargets)(w, area).filter((t) => t.source === "tile").map((t) => t.id);
    const before = tiles();
    strict_1.default.ok(before.length > 0);
    const [tx, ty] = before[0].slice(5).split(",").map(Number);
    area.setTile(tx, ty, tiles_1.T.FLOOR);
    strict_1.default.ok(!tiles().includes(before[0]), "a broken wall leaves the projection");
});
function hostAt(x, y, facing) {
    const canvas = () => globalThis.document.createElement("canvas");
    const g = new game_1.Game(canvas(), canvas());
    const w = (0, helpers_1.newWorld)();
    g.resume(w);
    const pl = (0, world_1.player)(w);
    pl.x = x;
    pl.y = y;
    pl.facing = facing;
    const cues = [];
    const host = g;
    const orig = host.onVisionCue.bind(g);
    host.onVisionCue = (c) => { cues.push(c.t); orig(c); };
    const tick = (n = 1) => { for (let i = 0; i < n; i++)
        g.update(1 / 60); };
    const press = (k) => { g.keyDown(k); tick(); g.keyUp(k); };
    tick(5);
    return { g, w, pl, cues, tick, press };
}
(0, node_test_1.test)("host vision overlay: Z switches it on and off with a cue each way, and the sweep pings what is in sight", () => {
    const { g, cues, tick, press } = hostAt(576, 352, "down");
    press("z");
    strict_1.default.equal(g.vision.on, true);
    tick(30);
    strict_1.default.equal(g.vision.k, 1);
    strict_1.default.ok(cues.includes("on") && cues.includes("ping"));
    strict_1.default.ok(g.vision.tracks.has("brazier@33,23"), "a brazier within sight is tracked");
    strict_1.default.ok(!g.vision.tracks.has("brazier@33,39"), "one far out of sight is not");
    strict_1.default.equal(g.vision.counts.pending > 0, true);
    press("z");
    tick(20);
    strict_1.default.ok(cues.includes("off"));
    strict_1.default.equal(g.vision.k, 0);
    strict_1.default.equal(g.vision.tracks.size, 0);
});
(0, node_test_1.test)("host vision overlay: finishing a scan locks the target in live, from pending to done", () => {
    const { g, w, pl, cues, tick, press } = hostAt(536, 366, "down");
    press("z");
    tick(30);
    strict_1.default.equal(g.vision.tracks.get("brazier@33,23").state, "pending");
    const pendingBefore = g.vision.counts.pending;
    press("e");
    strict_1.default.equal(pl.task?.kind, "scan");
    tick(60);
    strict_1.default.ok(w.flags.has((0, vision_1.analysisFlag)("brazier")));
    strict_1.default.equal(g.vision.tracks.get("brazier@33,23").state, "done");
    strict_1.default.ok(cues.includes("lock"));
    strict_1.default.ok(g.vision.counts.pending < pendingBefore, "the readout counts one fewer plan to read");
});
(0, node_test_1.test)("vision targets carry a kind, so copies of one thing share it", () => {
    const w = (0, helpers_1.newWorld)(), area = (0, world_1.currentArea)(w);
    const ts = (0, analysis_1.visionTargets)(w, area).filter((t) => t.source === "prop");
    const braziers = ts.filter((t) => t.id.startsWith("brazier@"));
    strict_1.default.ok(braziers.length > 1);
    strict_1.default.equal(new Set(braziers.map((t) => t.kind)).size, 1);
});
(0, node_test_1.test)("the readout counts kinds of thing, not copies", () => {
    const { g, w } = hostAt(536, 366, "down");
    g.keyDown("z");
    g.update(1 / 60);
    g.keyUp("z");
    for (let i = 0; i < 40; i++)
        g.update(1 / 60);
    const seen = [...g.vision.tracks.values()].filter((t) => t.seen > 0.5).map((t) => t.target);
    const kinds = (st) => new Set(seen.filter((t) => t.analysis === st).map((t) => t.kind)).size;
    strict_1.default.equal(g.vision.counts.pending, kinds("pending"));
    strict_1.default.equal(g.vision.counts.done, kinds("done"));
    strict_1.default.ok(seen.filter((t) => t.analysis === "pending").length >= g.vision.counts.pending);
    void w;
});
(0, node_test_1.test)("vision turns itself off when a rune jump or a conversation begins", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    pl.mode = "scan";
    (0, tasks_1.beginTask)(pl, { kind: "talk", dur: 0.3, effect: { op: "talk" } });
    strict_1.default.equal(pl.mode, "normal");
    pl.mode = "scan";
    pl.task = null;
    (0, tasks_1.beginTask)(pl, { kind: "channel", dur: 2.2, effect: { op: "travel" } });
    strict_1.default.equal(pl.mode, "normal");
    pl.mode = "scan";
    pl.task = null;
    (0, tasks_1.beginTask)(pl, { kind: "scan", dur: 0.9, effect: { op: "analyze" } });
    strict_1.default.equal(pl.mode, "scan", "scanning itself keeps vision on");
});
