"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Zoom model, the guardian's sprite, and rendering cost at the widest zoom.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const zoom_1 = require("../src/game/view/zoom");
const npcArt_1 = require("../src/game/npcArt");
const npcs_1 = require("../src/game/content/npcs");
const actors_1 = require("../src/game/content/actors");
const util_1 = require("../src/game/util");
const world_1 = require("../src/game/world/world");
const areaView_1 = require("../src/game/view/areaView");
const light_1 = require("../src/game/light");
const helpers_1 = require("./helpers");
(0, node_test_1.test)("zoom levels are integer, 16:9 views; the wheel steps 1x / 1.5x / 2x", () => {
    strict_1.default.deepEqual((0, zoom_1.viewSize)(1), { w: zoom_1.BASE_W, h: zoom_1.BASE_H });
    strict_1.default.deepEqual((0, zoom_1.viewSize)(1.5), { w: 480, h: 270 });
    strict_1.default.deepEqual((0, zoom_1.viewSize)(2), { w: 640, h: 360 });
    for (let z = 1; z <= 2; z += 0.01) {
        const v = (0, zoom_1.viewSize)(z);
        strict_1.default.ok(Number.isInteger(v.w) && Number.isInteger(v.h) && v.w * 9 === v.h * 16, `z=${z}`);
    }
    strict_1.default.ok(zoom_1.ZOOM_STEPS.includes(zoom_1.ZOOM_DEFAULT));
    strict_1.default.equal((0, zoom_1.nextZoomStep)(1, 1), 1.5);
    strict_1.default.equal((0, zoom_1.nextZoomStep)(1.5, 1), 2);
    strict_1.default.equal((0, zoom_1.nextZoomStep)(2, 1), 2);
    strict_1.default.equal((0, zoom_1.nextZoomStep)(2, -1), 1.5);
    strict_1.default.equal((0, zoom_1.nextZoomStep)(1, -1), 1);
    strict_1.default.equal((0, zoom_1.nextZoomStep)(1.3, 1), 2, "mid-animation: steps from the nearest level");
});
(0, node_test_1.test)("the guardian sprite is registered by its NpcDef art key and renders dormant and awake states", () => {
    for (const d of Object.values(npcs_1.NPCS))
        strict_1.default.ok(npcArt_1.NPC_ART[actors_1.ACTORS[d.actor].art.key], d.actor);
    const draw = (pose) => {
        (0, fakeCanvas_1.resetTrace)();
        const c = (0, util_1.makeCanvas)(64, 64);
        const p = { facing: "down", awake: 0, eye: 0, reach: 0, t: 0, ...pose };
        (0, npcArt_1.drawGuardian)(new util_1.Pen(c.ctx, false), 32, 60, p);
        (0, npcArt_1.drawGuardian)(new util_1.Pen(c.ctx, true), 32, 60, p);
        return (0, fakeCanvas_1.traceHash)();
    };
    const dormant = draw({}), awake = draw({ awake: 1, eye: 1 }), reaching = draw({ awake: 1, eye: 1, reach: 1 });
    strict_1.default.equal(draw({}), dormant, "deterministic");
    strict_1.default.notEqual(dormant, awake);
    strict_1.default.notEqual(awake, reaching, "the hand pose shows");
    strict_1.default.notEqual(draw({ awake: 1, eye: 0 }), awake, "the eye is drawn only when lit");
});
(0, node_test_1.test)("perf report: the 96x72 surface at 2x zoom (640x360 view)", () => {
    const s = (0, world_1.getArea)((0, helpers_1.newWorld)(), "surface");
    const rp = s.prop("rune.surface");
    const out = [];
    for (const z of zoom_1.ZOOM_STEPS) {
        const { w, h } = (0, zoom_1.viewSize)(z);
        const v = new areaView_1.AreaView(s);
        let t0 = performance.now();
        v.prepare(rp.x - w / 2, rp.y - h / 2, w, h);
        const first = performance.now() - t0;
        const chunks = v.stats.chunksBaked;
        const L = new light_1.Lighting(w, h);
        const lights = [...v.lights.values(), (0, light_1.makeLight)(rp.x, rp.y, 108, [1, 0.78, 0.5], 1, 0.05)];
        for (const l of lights)
            if (l.n === 0)
                (0, light_1.computeVis)(l, s);
        const sc = new Uint8ClampedArray(w * h * 4), em = new Uint8ClampedArray(w * h * 4), o = new Uint8ClampedArray(w * h * 4);
        t0 = performance.now();
        for (let i = 0; i < 10; i++) {
            L.accumulate(lights, rp.x - w / 2, rp.y - h / 2);
            L.compose(sc, em, o, [0.2, 0.2, 0.3]);
        }
        const light = (performance.now() - t0) / 10;
        let n = 0;
        while (v.idle())
            n++;
        strict_1.default.ok(v.fullyBaked);
        out.push(`${z}x ${w}x${h}: first frame ${first.toFixed(1)}ms (${chunks} chunks), lighting ${light.toFixed(1)}ms/frame, ${n} chunks left for idle`);
    }
    console.log(`# PERF zoom (surface ${s.w}x${s.h}) | ${out.join(" | ")}`);
});
