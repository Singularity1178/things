"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The maintainer's doubled base speed, the worker rename (and how a name reads), and the transfer screen: giving
// and taking items, equipping a rune on the worker, and the refusals in words.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const actors_1 = require("../src/game/content/actors");
const manage_1 = require("../src/game/screens/manage");
const transfer_1 = require("../src/game/screens/transfer");
const actorStats_1 = require("../src/game/sim/actorStats");
const commands_1 = require("../src/game/sim/commands");
const inventory_1 = require("../src/game/sim/inventory");
const save_1 = require("../src/game/world/save");
const world_1 = require("../src/game/world/world");
const screenHost_1 = require("./support/screenHost");
const workerFixture_1 = require("./support/workerFixture");
const roundTrip = (w) => (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
const typeInto = (sh, ...chars) => { sh.host.typed = chars; sh.press(); sh.host.typed = []; };
function open() {
    const f = (0, workerFixture_1.fixture)(), sh = (0, screenHost_1.screenHost)(f.w), manage = new manage_1.ManageUi(sh.host);
    const transfer = new transfer_1.TransferUi(sh.host, (id) => manage.open(id));
    manage.openTransfer = (id) => transfer.open(id);
    manage.open(f.worker.id);
    return { ...f, sh, manage, transfer };
}
(0, node_test_1.test)("the maintainer's base speed is doubled (48, 60 with the iron arm); other bodies are unchanged", () => {
    const w = (0, world_1.createWorld)(5), pl = (0, world_1.player)(w);
    strict_1.default.equal((0, actors_1.actorDef)(pl).speed, 48);
    strict_1.default.equal((0, actorStats_1.actorSpeed)(w, pl), 48);
    (0, world_1.setFlag)(w, "golem.arm");
    strict_1.default.equal((0, actorStats_1.actorSpeed)(w, pl), 60);
    strict_1.default.equal((0, actors_1.actorDef)({ definition: "worker_golem" }).speed, 16);
});
(0, node_test_1.test)("a name reads in front of the kind: BOB - WORKER GOLEM; empty clears it; it is saved", () => {
    const { w, pl, worker: wk } = (0, workerFixture_1.fixture)();
    strict_1.default.equal((0, actorStats_1.actorLabel)(wk), "WORKER GOLEM");
    strict_1.default.ok((0, commands_1.renameActor)(w, pl, wk.id, "  bob ").ok);
    strict_1.default.equal(wk.name, "BOB");
    strict_1.default.equal((0, actorStats_1.actorLabel)(wk), "BOB - WORKER GOLEM");
    strict_1.default.equal(roundTrip(w).actors.find((a) => a.id === wk.id).name, "BOB");
    strict_1.default.equal((0, actorStats_1.cleanActorName)("a".repeat(40)).length, actorStats_1.ACTOR_NAME_MAX);
    strict_1.default.ok((0, commands_1.renameActor)(w, pl, wk.id, "   ").ok);
    strict_1.default.equal(wk.name, undefined);
    strict_1.default.equal((0, actorStats_1.actorLabel)(wk), "WORKER GOLEM");
    pl.x += 200;
    strict_1.default.ok(!(0, commands_1.renameActor)(w, pl, wk.id, "far").ok, "out of reach refuses");
    strict_1.default.equal(wk.name, undefined);
});
(0, node_test_1.test)("the management screen renames through its keys and shows the full name", () => {
    const { sh, manage, worker: wk } = open();
    const row = manage.menu.findIndex((r) => r.label.startsWith("RENAME"));
    strict_1.default.ok(row > 0);
    for (let i = 0; i < row; i++)
        sh.press("s");
    sh.press("e");
    strict_1.default.ok(manage.nameField.active);
    typeInto(sh, "b", "o", "b");
    sh.press("enter");
    strict_1.default.ok(!manage.nameField.active);
    strict_1.default.equal(wk.name, "BOB");
    const b = sh.draw();
    (0, screenHost_1.assertTextFits)("manage renamed", b);
    sh.save(".test-out/shots/manage-renamed.png");
    strict_1.default.ok(b.map((x) => x.text).includes("BOB - WORKER GOLEM"));
    // R from the list, Esc cancels and keeps the old name
    sh.press("r");
    strict_1.default.ok(manage.nameField.active);
    strict_1.default.equal(manage.nameField.value, "BOB");
    typeInto(sh, "x");
    sh.press("escape");
    strict_1.default.ok(sh.host.screens.is("manage"));
    strict_1.default.equal(wk.name, "BOB");
});
(0, node_test_1.test)("transfer: give and take stacks and single items through the sim", () => {
    const { w, pl, worker: wk } = (0, workerFixture_1.fixture)();
    (0, inventory_1.addItems)(w, pl, "wood", 7);
    const slot = pl.inventory.findIndex((s) => s?.item === "wood");
    strict_1.default.equal((0, commands_1.transferWithActor)(w, pl, wk.id, "give", slot, Infinity).moved, 7);
    strict_1.default.equal((0, inventory_1.countItem)(wk, "wood"), 7);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 0);
    const at = wk.inventory.findIndex((s) => s?.item === "wood");
    strict_1.default.equal((0, commands_1.transferWithActor)(w, pl, wk.id, "take", at, 1).moved, 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 1);
    strict_1.default.equal((0, inventory_1.countItem)(wk, "wood"), 6);
    strict_1.default.equal((0, commands_1.transferWithActor)(w, pl, wk.id, "give", 7, 1).text, "NOTHING THERE TO MOVE");
    pl.x += 200;
    strict_1.default.equal((0, commands_1.transferWithActor)(w, pl, wk.id, "take", at, 1).text, "STEP UP TO THE WORKER");
    strict_1.default.equal((0, inventory_1.countItem)(wk, "wood"), 6);
});
(0, node_test_1.test)("transfer: a full worker pack refuses and says so, changing nothing", () => {
    const { w, pl, worker: wk } = (0, workerFixture_1.fixture)();
    wk.inventory = Array.from({ length: 8 }, () => ({ item: "stone", n: 20 }));
    (0, inventory_1.addItems)(w, pl, "wood", 3);
    const r = (0, commands_1.transferWithActor)(w, pl, wk.id, "give", pl.inventory.findIndex((s) => s?.item === "wood"), Infinity);
    strict_1.default.deepEqual([r.ok, r.moved, r.text], [false, 0, "ITS PACK IS FULL"]);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 3);
});
(0, node_test_1.test)("equip: a rune from your pack goes onto the worker, comes off into its pack, and a non-wearable is refused", () => {
    const { w, pl, worker: wk } = (0, workerFixture_1.fixture)();
    (0, inventory_1.addItems)(w, pl, "rune_swift", 1);
    (0, inventory_1.addItems)(w, pl, "wood", 2);
    const slot = pl.inventory.findIndex((s) => s?.item === "rune_swift");
    strict_1.default.equal((0, commands_1.equipActor)(w, pl, wk.id, "pack", pl.inventory.findIndex((s) => s?.item === "wood")).text, "IT CAN'T WEAR THAT");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 2);
    strict_1.default.ok((0, commands_1.equipActor)(w, pl, wk.id, "pack", slot).ok);
    strict_1.default.equal(wk.gear.rune0, "rune_swift");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "rune_swift"), 0);
    strict_1.default.equal((0, inventory_1.countItem)(wk, "rune_swift"), 0);
    strict_1.default.ok((0, actorStats_1.actorSpeed)(w, wk) > (0, actors_1.actorDef)(wk).speed, "the rune speeds the worker");
    // a second rune with the slot taken swaps: the first goes to its pack
    (0, inventory_1.addItems)(w, pl, "rune_glow", 1);
    strict_1.default.ok((0, commands_1.equipActor)(w, pl, wk.id, "pack", pl.inventory.findIndex((s) => s?.item === "rune_glow")).ok);
    strict_1.default.equal(wk.gear.rune0, "rune_glow");
    strict_1.default.equal((0, inventory_1.countItem)(wk, "rune_swift"), 1);
    strict_1.default.ok((0, commands_1.unequipActor)(w, pl, wk.id, "rune0").ok);
    strict_1.default.equal(wk.gear.rune0, undefined);
    strict_1.default.equal((0, inventory_1.countItem)(wk, "rune_glow"), 1);
    strict_1.default.equal((0, commands_1.unequipActor)(w, pl, wk.id, "rune0").text, "NOTHING WORN THERE");
    // equipping from its own pack
    strict_1.default.ok((0, commands_1.equipActor)(w, pl, wk.id, "carry", wk.inventory.findIndex((s) => s?.item === "rune_swift")).ok);
    strict_1.default.equal(wk.gear.rune0, "rune_swift");
    strict_1.default.equal(roundTrip(w).actors.find((a) => a.id === wk.id).gear.rune0, "rune_swift");
});
(0, node_test_1.test)("the transfer screen through the keys: row on the management screen, cursor, give, equip, take off, Esc back", () => {
    const { w, pl, worker: wk, sh, manage, transfer } = open();
    (0, inventory_1.addItems)(w, pl, "wood", 5);
    (0, inventory_1.addItems)(w, pl, "rune_glow", 1);
    const row = manage.menu.findIndex((r) => r.label.startsWith("TRANSFER"));
    for (let i = 0; i < row; i++)
        sh.press("s");
    sh.press("e");
    strict_1.default.ok(sh.host.screens.is("transfer"));
    strict_1.default.ok(!sh.host.screens.has("manage"), "the management screen steps aside");
    (0, screenHost_1.assertTextFits)("transfer", sh.draw());
    sh.save(".test-out/shots/transfer0.png");
    strict_1.default.equal(transfer.pane, "pack");
    // slot 0 holds the first thing in the pack; find wood with the cursor
    const wood = pl.inventory.findIndex((s) => s?.item === "wood");
    for (let i = 0; i < wood; i++)
        sh.press("d");
    sh.press("e");
    strict_1.default.equal((0, inventory_1.countItem)(wk, "wood"), 5);
    // the rune: cursor onto it, F equips
    const rune = pl.inventory.findIndex((s) => s?.item === "rune_glow");
    transfer.cursors.pack = rune;
    sh.press("f");
    strict_1.default.equal(wk.gear.rune0, "rune_glow");
    const b = sh.draw();
    (0, screenHost_1.assertTextFits)("transfer worn", b);
    sh.save(".test-out/shots/transfer.png");
    // go to the worn slot (carry pane, then down off its last row) and take it off
    transfer.pane = "carry";
    transfer.cursors.carry = 4;
    sh.press("s");
    strict_1.default.equal(transfer.pane, "worn");
    sh.press("e");
    strict_1.default.equal(wk.gear.rune0, undefined);
    strict_1.default.equal((0, inventory_1.countItem)(wk, "rune_glow"), 1);
    sh.press("escape");
    strict_1.default.ok(sh.host.screens.is("manage"), "Esc goes back to the worker's screen");
    sh.press("escape");
    strict_1.default.ok(sh.host.screens.is("play"));
    (0, workerFixture_1.beside)(w, wk);
});
