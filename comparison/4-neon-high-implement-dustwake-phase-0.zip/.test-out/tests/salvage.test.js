"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Deconstructing everything buildable: every authored prop of a kind a recipe
// builds (the dungeon's braziers, banners, tables, chairs, torches and
// workbench) can be taken apart for that recipe's actual cost, crafted
// materials included; props that hold or gate tutorial progress refuse until the
// item is taken; refunds of props that already stand never change with a
// rebalance (v8 -> v9).
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const inventory_1 = require("../src/game/sim/inventory");
const commands_1 = require("../src/game/sim/commands");
const build_1 = require("../src/game/sim/build");
const build_2 = require("../src/game/content/build");
const items_1 = require("../src/game/content/items");
const props_1 = require("../src/game/content/props");
const flags_1 = require("../src/game/content/flags");
const helpers_1 = require("./helpers");
const finish = (w) => { let g = 0; while ((0, world_1.player)(w).task && g++ < 600)
    (0, helpers_1.frame)(w); };
const counts = (w) => { const o = {}; for (const s of (0, world_1.player)(w).inventory)
    if (s)
        o[s.item] = (o[s.item] ?? 0) + s.n; return o; };
const asCounts = (c) => Object.fromEntries(c.map((x) => [x.item, x.n]));
const stand = (w, id) => { const p = (0, world_1.currentArea)(w).prop(id); const pl = (0, world_1.player)(w); pl.x = p.x; pl.y = p.y + 14; pl.facing = "up"; return p; };
(0, node_test_1.test)("audit: every authored prop of a buildable kind, in the dungeon and on the surface, is deconstructable for its recipe's cost", () => {
    const w = (0, helpers_1.newWorld)();
    const kinds = new Map(Object.entries(build_2.RECIPES).map(([id, r]) => [r.prop, id]));
    const found = new Map();
    for (const area of ["dungeon", "surface"]) {
        for (const p of (0, world_1.getArea)(w, area).props) {
            const id = kinds.get(p.kind);
            if (!id)
                continue;
            found.set(p.kind, (found.get(p.kind) ?? 0) + 1);
            strict_1.default.ok((0, build_1.isDeconstructable)(p), `${area} ${p.id}`);
            strict_1.default.deepEqual((0, build_1.salvageOf)(p), build_2.RECIPES[id].cost, `${area} ${p.id}: refund is the recipe's actual cost`);
        }
    }
    // what the dungeon actually places (so the audit isn't vacuous)
    for (const k of ["torch", "brazier", "banner", "table", "chair", "workbench", "forge", "anvil"])
        strict_1.default.ok((found.get(k) ?? 0) > 0, `authored ${k} exists`);
    // every recipe's prop kind is a row in the salvage table; nothing else is, and non-buildable kinds stay fixed
    for (const r of Object.values(build_2.RECIPES))
        strict_1.default.ok(r.prop in build_2.AUTHORED_SALVAGE, r.prop);
    // (the smelter, kind `forge`, and the anvil became buildable with the entrance update, so they are in the table now)
    for (const k of ["chains", "bookshelf", "statue", "bed", "cradle", "runetable", "staffrack"])
        strict_1.default.ok(props_1.PROPS[k] && !(k in build_2.AUTHORED_SALVAGE), k);
});
(0, node_test_1.test)("each authored target is taken apart through the dismantle task and refunds the recipe's materials (crafted ones too)", () => {
    const pick = (w, kind, skip = () => false) => (0, world_1.currentArea)(w).props.find((p) => p.kind === kind && !p.item && !skip(p.id));
    for (const [kind, recipe] of [["brazier", "brazier"], ["banner", "wall_banner"], ["table", "table"], ["chair", "chair"], ["torch", "wall_torch"]]) {
        const w = (0, helpers_1.newWorld)();
        (0, helpers_1.frame)(w);
        const a = (0, world_1.currentArea)(w), pl = (0, world_1.player)(w);
        const p = pick(w, kind);
        strict_1.default.ok(p, kind);
        stand(w, p.id);
        (0, helpers_1.events)(w);
        strict_1.default.ok((0, commands_1.orderDeconstruct)(w, pl, p.id), kind);
        strict_1.default.equal(pl.task.kind, "dismantle");
        strict_1.default.ok(a.prop(p.id), "takes time");
        finish(w);
        strict_1.default.equal(a.prop(p.id), undefined, kind);
        strict_1.default.deepEqual(counts(w), asCounts(build_2.RECIPES[recipe].cost), `${kind}: refund equals the recipe cost`);
        strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "deconstructed" && e.kind === kind));
        // gone for good: saved as removed, still gone after loading
        strict_1.default.ok((0, save_1.serialize)(w).areas.dungeon.propsRemoved.includes(p.id));
        strict_1.default.equal((0, world_1.currentArea)((0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))))).prop(p.id), undefined, kind);
    }
    // a full pack: the (crafted) refund lands on the ground
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    const pl = (0, world_1.player)(w), a = (0, world_1.currentArea)(w);
    (0, inventory_1.addItems)(w, pl, "coin", 8);
    const t = pick(w, "table");
    stand(w, t.id);
    strict_1.default.ok((0, commands_1.orderDeconstruct)(w, pl, t.id));
    finish(w);
    strict_1.default.equal(a.loose.filter((l) => l.dyn && !l.taken && l.item === "planks").reduce((s, l) => s + (l.n ?? 1), 0), 4);
});
(0, node_test_1.test)("tutorial-critical props: the workbench holds the chisel and the library table holds the Builder's Primer, so both refuse until the item is taken", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    const a = (0, world_1.currentArea)(w), pl = (0, world_1.player)(w);
    // the general rule: no authored prop that is deconstructable may be dismantled while it holds a critical item
    let held = 0;
    for (const p of a.props) {
        if (!p.item || p.taken || !(0, items_1.isCritical)(p.item) || !(0, build_1.isDeconstructable)(p))
            continue;
        held++;
        stand(w, p.id);
        const c = (0, build_1.deconstructCheck)(w, pl, a, p.id);
        strict_1.default.ok(!c.ok && c.reason === "holds" && c.item === p.item, p.id);
    }
    strict_1.default.equal(held, 2, "exactly the workbench (chisel) and the table (primer)");
    const bench = "workbench@13.5,37", table = "table@11,29";
    stand(w, bench);
    (0, helpers_1.events)(w);
    strict_1.default.equal((0, commands_1.orderDeconstruct)(w, pl, bench), false);
    strict_1.default.deepEqual((0, helpers_1.events)(w), [{ t: "message", text: "TAKE THE RUNE CHISEL FIRST" }]);
    strict_1.default.ok(a.prop(bench) && a.prop(bench).item === "chisel" && !a.prop(bench).taken, "nothing changed");
    // the effect refuses too, even when forced
    const c = (0, build_1.deconstructCheck)(w, pl, a, bench);
    strict_1.default.equal(c.ok ? "" : (0, build_1.deconMessage)(c), "TAKE THE RUNE CHISEL FIRST");
    // take the chisel (the tutorial's normal path): now the bench goes, the chisel stays in the pack
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, bench));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "chisel"), 1);
    stand(w, bench);
    strict_1.default.ok((0, commands_1.orderDeconstruct)(w, pl, bench));
    finish(w);
    strict_1.default.equal(a.prop(bench), undefined);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "chisel"), 1, "the chisel is never lost");
    strict_1.default.deepEqual({ wood: (0, inventory_1.countItem)(pl, "wood"), stone: (0, inventory_1.countItem)(pl, "stone") }, { wood: 6, stone: 2 }, "a raw bench refunds raw materials, so it can always be rebuilt");
    // the table and its primer
    stand(w, table);
    strict_1.default.equal((0, commands_1.orderDeconstruct)(w, pl, table), false);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild); // (reading the primer teaches this; the book stays obtainable either way)
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, table));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "book_build"), 1);
    stand(w, table);
    strict_1.default.ok((0, commands_1.orderDeconstruct)(w, pl, table));
    finish(w);
    strict_1.default.equal(a.prop(table), undefined);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "book_build"), 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "planks"), build_2.RECIPES.table.cost[0].n);
});
(0, node_test_1.test)("non-critical contents still spill to the ground when their prop is taken apart", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    const a = (0, world_1.currentArea)(w), pl = (0, world_1.player)(w);
    const t = a.props.find((p) => p.kind === "chair" && !p.item);
    a.setPropState(t.id, { item: "coin" });
    stand(w, t.id);
    strict_1.default.ok((0, commands_1.orderDeconstruct)(w, pl, t.id));
    finish(w);
    strict_1.default.ok(a.loose.some((l) => l.item === "coin" && !l.taken));
});
(0, node_test_1.test)("a rebalance never changes what a standing prop refunds: built props record their cost, and v8 saves are stamped with the old one", () => {
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    const a = (0, world_1.currentArea)(w), pl = (0, world_1.player)(w);
    // a prop built under yesterday's costs: old save shape (no refund recorded), built from the table recipe
    a.addProp("table", pl.x, pl.y - 40, { recipe: "table", v: 0 }, "table#b0");
    a.propSeq = 1;
    const s = (0, save_1.serialize)(w);
    s.version = 8;
    delete s.areas.dungeon.propsAdded[0].refund;
    const m = (0, save_1.migrate)(s);
    strict_1.default.deepEqual(m.areas.dungeon.propsAdded[0].refund, [{ item: "wood", n: 4 }]);
    const w2 = (0, save_1.deserialize)(s);
    const t = (0, world_1.currentArea)(w2).prop("table#b0");
    strict_1.default.deepEqual((0, build_1.salvageOf)(t), [{ item: "wood", n: 4 }], "it was built for 4 wood: it gives 4 wood back, not 4 planks");
    // props without a recorded recipe (older saves) are matched by kind; unchanged recipes are left alone
    const s2 = (0, save_1.serialize)(w);
    s2.version = 8;
    delete s2.areas.dungeon.propsAdded[0].refund;
    delete s2.areas.dungeon.propsAdded[0].recipe;
    strict_1.default.deepEqual((0, save_1.migrate)(s2).areas.dungeon.propsAdded[0].refund, [{ item: "wood", n: 4 }]);
    const s3 = (0, save_1.serialize)(w);
    s3.version = 8;
    s3.areas.dungeon.propsAdded[0] = { ...s3.areas.dungeon.propsAdded[0], kind: "barricade", recipe: "barricade" };
    delete s3.areas.dungeon.propsAdded[0].refund;
    strict_1.default.equal((0, save_1.migrate)(s3).areas.dungeon.propsAdded[0].refund, undefined);
    // and the refund of the old table really is what comes back
    const pl2 = (0, world_1.player)(w2);
    pl2.x = t.x;
    pl2.y = t.y + 14;
    strict_1.default.ok((0, commands_1.orderDeconstruct)(w2, pl2, t.id));
    finish(w2);
    strict_1.default.equal((0, inventory_1.countItem)(pl2, "wood"), 4);
    strict_1.default.equal((0, inventory_1.countItem)(pl2, "planks"), 0);
});
