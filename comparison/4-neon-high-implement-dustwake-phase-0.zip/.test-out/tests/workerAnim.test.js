"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The worker golem's animation sequencer (src/game/workerAnim.ts): booting up and standing when a core goes in,
// settling dormant when it has been idle, powering down when the core comes out, the quick stand for a body
// that is given work, no pops between any of them, and no animation of its own while it channels a rune.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const workerAnim_1 = require("../src/game/workerAnim");
const workerArt_1 = require("../src/game/workerArt");
const actors_1 = require("../src/game/view/actors");
const uiSnapshot_1 = require("./support/uiSnapshot");
const world_1 = require("../src/game/world/world");
const map_1 = require("../src/game/map");
const OFF = { powered: false, active: false, moving: false, hasCore: false };
const IDLE = { powered: true, active: false, moving: false, hasCore: true };
const WORK = { powered: true, active: true, moving: false, hasCore: true };
const DT = 1 / 60;
const KEYS = ["rise", "neck", "yaw", "arms", "shake", "dip", "core", "eye"];
/** Run `seconds` at 60 fps, calling `each` after every frame; returns the cues that fired in order. */
function run(a, i, seconds, each) {
    const cues = [];
    for (let t = 0; t < seconds; t += DT) {
        (0, workerAnim_1.stepWorkerAnim)(a, DT, i);
        cues.push(...(0, workerAnim_1.drainCues)(a));
        each?.(a, t);
    }
    return cues;
}
/** The biggest one-frame change of the smooth posture channels while `fn` runs (flicker channels, eye and shake, are excluded). */
function maxStep(a, fn) {
    let prev = { ...a.out }, worst = 0, where = "";
    fn(() => { for (const k of ["rise", "neck", "arms"]) {
        const d = Math.abs(a.out[k] - prev[k]);
        if (d > worst) {
            worst = d;
            where = k;
        }
    } prev = { ...a.out }; });
    return { worst, where };
}
(0, node_test_1.test)("a body at rest starts in the posture the sim implies, with no animation", () => {
    strict_1.default.equal((0, workerAnim_1.initWorkerAnim)(OFF).mode, "off");
    strict_1.default.equal((0, workerAnim_1.initWorkerAnim)(IDLE).mode, "dormant");
    strict_1.default.equal((0, workerAnim_1.initWorkerAnim)(WORK).mode, "stand");
    const off = (0, workerAnim_1.initWorkerAnim)(OFF).out, dormant = (0, workerAnim_1.initWorkerAnim)(IDLE).out, stand = (0, workerAnim_1.initWorkerAnim)(WORK).out;
    strict_1.default.deepEqual([off.rise, off.neck, off.arms, off.eye, off.core], [0, 0, 0, 0, 0], "off: crouched, lid down, core dark");
    strict_1.default.deepEqual([dormant.rise, dormant.eye, dormant.core], [0, 0, workerArt_1.WORKER_CORE.idle], "dormant: crouched, lid down, core faintly warm");
    strict_1.default.deepEqual([stand.rise, stand.neck, stand.arms, stand.eye, stand.core], [1, 1, 1, 1, 1]);
});
(0, node_test_1.test)("slotting a core in: it boots (spark, lamp, a look left and right), stands, and plants its feet", () => {
    const a = (0, workerAnim_1.initWorkerAnim)(OFF), seen = [];
    const cues = run(a, IDLE, workerAnim_1.DUR.boot + 0.2, (x) => seen.push({ mode: x.mode, yaw: x.out.yaw, rise: x.out.rise }));
    strict_1.default.deepEqual(cues, ["spark", "creak", "lamp", "plant"], "in the order a body comes alive");
    strict_1.default.ok(seen.some((s) => s.mode === "boot") && seen[seen.length - 1].mode === "stand", "boot, then standing");
    strict_1.default.ok(seen.some((s) => s.yaw < -0.9) && seen.some((s) => s.yaw > 0.9), "it looks one way then the other");
    // it does not stand until its head is up and the lamp is lit
    const early = (0, workerAnim_1.initWorkerAnim)(OFF);
    run(early, IDLE, 1.0);
    strict_1.default.ok(early.out.rise === 0 && early.out.neck === 0, "still crouched, head down, a second in");
    strict_1.default.ok(Math.max(...seen.map((s) => s.rise)) === 1);
    strict_1.default.ok(a.out.rise === 1 && a.out.neck === 1 && a.out.arms === 1 && a.out.eye >= 0.85, "up, lamp lit (a touch under working brightness on standby)");
    strict_1.default.ok(Math.abs(a.out.core - workerAnim_1.STANDBY_CORE) < 0.1, "core settles to standby, not working brightness");
    strict_1.default.ok(a.out.yaw === 0 && a.out.shake === 0, "eyes front, still");
});
(0, node_test_1.test)("idle for a while: it settles into the dormant crouch, lamp out, core down, and stays there", () => {
    const a = (0, workerAnim_1.initWorkerAnim)(WORK);
    run(a, IDLE, workerAnim_1.IDLE_DELAY - 0.2);
    strict_1.default.equal(a.mode, "stand", "it waits about on standby first");
    strict_1.default.ok(a.out.eye > 0.8 && a.out.core > workerArt_1.WORKER_CORE.idle + 0.2);
    const cues = run(a, IDLE, 0.2 + workerAnim_1.DUR.settle + 0.2);
    strict_1.default.equal(a.mode, "dormant");
    strict_1.default.deepEqual(a.out, (0, workerAnim_1.steady)("dormant", true, false), "ends exactly on the dormant pose");
    strict_1.default.deepEqual(cues, ["lampOut", "settle", "plant"]);
    run(a, IDLE, 5);
    strict_1.default.equal(a.mode, "dormant", "stays down while idle");
    // work arrives while it is still settling: it just stands again
    const b = (0, workerAnim_1.initWorkerAnim)(WORK);
    run(b, IDLE, workerAnim_1.IDLE_DELAY + 1.0);
    strict_1.default.equal(b.mode, "settle");
    run(b, WORK, 0.1);
    strict_1.default.equal(b.mode, "stand");
    run(b, WORK, 0.6);
    strict_1.default.deepEqual([b.out.rise, b.out.neck, b.out.arms, b.out.eye], [1, 1, 1, 1]);
});
(0, node_test_1.test)("taking the core out: a jolt, the lamp and core gutter out, the head turns aside, it sags down", () => {
    const a = (0, workerAnim_1.initWorkerAnim)(WORK), yaws = [], cores = [], eyes = [], rises = [];
    const cues = run(a, OFF, workerAnim_1.DUR.shutdown + 0.2, (x) => { yaws.push(x.out.yaw); cores.push(x.out.core); eyes.push(x.out.eye); rises.push(x.out.rise); });
    strict_1.default.deepEqual(cues, ["jolt", "lampOut", "plant"]);
    strict_1.default.equal(a.mode, "off");
    strict_1.default.deepEqual(a.out, (0, workerAnim_1.steady)("off", false, false), "ends on the off pose, centred");
    strict_1.default.ok(Math.min(...yaws) <= -0.95, "the head turns aside on the way down");
    strict_1.default.ok(cores.some((c, i) => i > 1 && c < cores[i - 1]) && cores[cores.length - 1] === 0, "the core gutters, then dark");
    strict_1.default.ok(eyes.some((e) => e > 0.5) && eyes[eyes.length - 1] === 0);
    // it stays upright through the first part (the jolt), then sags
    strict_1.default.ok(rises[20] > 0.95 && rises[rises.length - 1] === 0);
    strict_1.default.ok(rises.every((r, i) => i === 0 || r <= rises[i - 1] + 1e-9), "it never gets up again on the way down");
    // a dormant body powered down only gutters: it never stands, never rises
    const d = (0, workerAnim_1.initWorkerAnim)(IDLE), top = [];
    run(d, OFF, workerAnim_1.DUR.shutdown + 0.2, (x) => top.push(x.out.rise));
    strict_1.default.equal(Math.max(...top), 0);
    strict_1.default.equal(d.mode, "off");
});
(0, node_test_1.test)("work for a dormant body: it wakes and stands quickly; a boot that has to walk is cut to the quick stand", () => {
    const a = (0, workerAnim_1.initWorkerAnim)(IDLE);
    const cues = run(a, WORK, 0.1);
    strict_1.default.equal(a.mode, "wake");
    cues.push(...run(a, WORK, 0.7));
    strict_1.default.equal(a.mode, "stand");
    strict_1.default.deepEqual(cues, ["spark", "plant"]);
    strict_1.default.deepEqual([a.out.rise, a.out.neck, a.out.arms], [1, 1, 1]);
    // boot with an order already waiting: standing in under a second or two, not the full boot
    const b = (0, workerAnim_1.initWorkerAnim)(OFF);
    run(b, { ...WORK, moving: true }, 0.8);
    strict_1.default.notEqual(b.mode, "boot");
    run(b, { ...WORK, moving: true }, 0.9);
    strict_1.default.equal(b.mode, "stand");
    strict_1.default.equal(b.out.rise, 1);
});
(0, node_test_1.test)("no pops: posture never jumps between frames across every transition, including interrupted ones", () => {
    const a = (0, workerAnim_1.initWorkerAnim)(OFF);
    const m = maxStep(a, (watch) => {
        const go = (i, s) => run(a, i, s, () => watch());
        go(IDLE, 1.5); // booting
        go(OFF, 0.9); // core pulled mid-boot
        go(IDLE, 1.2); // and put back mid-shutdown
        go(IDLE, 6); // booted, settled
        go(WORK, 0.3); // work: wake
        go(IDLE, workerAnim_1.IDLE_DELAY + 1.0); // mid-settle...
        go(WORK, 1); // ...work again
        go(OFF, 4); // power off
    });
    strict_1.default.ok(m.worst < 0.12, `largest one-frame change ${m.worst.toFixed(3)} in ${m.where}`);
});
(0, node_test_1.test)("the sequencer is pure and deterministic", () => {
    const trace = () => { const a = (0, workerAnim_1.initWorkerAnim)(OFF), out = []; run(a, IDLE, 4, (x) => out.push(...KEYS.map((k) => x.out[k]))); return out; };
    strict_1.default.deepEqual(trace(), trace());
    strict_1.default.equal((0, workerAnim_1.track)(0.5, [[0, 0], [1, 1]]), 0.5, "eased tracks hit their midpoint");
    strict_1.default.equal((0, workerAnim_1.track)(5, [[0, 2], [1, 7]]), 7);
});
(0, node_test_1.test)("task motion: harvest swings overhead and lands at its fire point; a rune channel is deliberately nothing", () => {
    strict_1.default.deepEqual((0, workerAnim_1.taskMotion)("channel", 1.1, 2.2), workerAnim_1.NO_MOTION, "no animation while teleporting");
    strict_1.default.deepEqual((0, workerAnim_1.taskMotion)(undefined, 0, 1), workerAnim_1.NO_MOTION);
    strict_1.default.ok((0, workerAnim_1.taskMotion)("reach", 0.225, 0.45).reach > 0.99);
    strict_1.default.ok((0, workerAnim_1.taskMotion)("craft", 0.3, 2).reach > 0.4);
    const k = (v) => (0, workerAnim_1.blowMotion)(v).swing;
    strict_1.default.ok(k(0.2) > 0 && k(0.4) === 1 && k(0.5) === -1, "up, overhead, fists in the ground exactly at the fire point");
    strict_1.default.ok(k(0.499) > -1 && k(0.6) === -1 && k(1) === 0);
    strict_1.default.equal((0, workerAnim_1.taskMotion)("punch", 0.375, 0.75).swing, -1, "the punch task fires at half its duration, and that is the landing");
});
(0, node_test_1.test)("a pose never walks or works while the body is down", () => {
    const a = (0, workerAnim_1.initWorkerAnim)(IDLE);
    const p = (0, workerAnim_1.animPose)(a, { facing: "down", phase: 1, moving: true, t: 0, hasCore: true, task: { swing: 1, reach: 1, dip: 2 } });
    strict_1.default.deepEqual([p.moving, p.swing, p.reach, p.dip], [false, 0, 0, 0]);
    const s = (0, workerAnim_1.animPose)((0, workerAnim_1.initWorkerAnim)(WORK), { facing: "down", phase: 1, moving: true, t: 0, hasCore: true, task: { swing: 1, reach: 0, dip: 0 } });
    strict_1.default.deepEqual([s.moving, s.swing], [true, 1]);
});
// ------------------------------------------------------------------ through drawActor
function drawn(setup, look = {}) {
    const w = (0, world_1.createWorld)(3), wk = (0, world_1.actorById)(w, map_1.ARTIFICERY_WORKER.id);
    wk.powerCore = "ruby_core";
    setup(wk);
    const sc = new uiSnapshot_1.RCanvas(56, 64), ec = new uiSnapshot_1.RCanvas(56, 64);
    (0, actors_1.drawActor)(sc.getContext(), ec.getContext(), w, wk, Math.round(wk.x) - 28, Math.round(wk.y) - 58, 0.3, { awake: 0, eye: 0, flare: 0, reach: 0, ...look });
    return { sc, ec };
}
const running = (wk) => { wk.job = { status: "running" }; };
(0, node_test_1.test)("a worker channelling a rune is drawn exactly as one standing (no reach, no gesture of its own)", () => {
    const channel = drawn((wk) => { wk.task = { kind: "channel", dur: 2.2, t: 0.9, fired: false, effect: { op: "travel", destination: "x" }, target: { kind: "rune", x: wk.x, y: wk.y, propId: "p" } }; });
    const standing = drawn(running);
    strict_1.default.deepEqual([...channel.sc.data], [...standing.sc.data]);
    strict_1.default.deepEqual([...channel.ec.data], [...standing.ec.data]);
    // whereas a deposit reach visibly moves the arms
    const reach = drawn((wk) => { wk.task = { kind: "reach", dur: 0.45, t: 0.22, fired: false }; });
    strict_1.default.notDeepEqual([...reach.sc.data], [...standing.sc.data]);
});
(0, node_test_1.test)("a rune holds a worker off the ground by `lift` px: the whole body rises (the shadow is translucent and stays)", () => {
    const down = drawn(running), up = drawn(running, { lift: 5 });
    const top = (c) => { for (let y = 0; y < c.height; y++)
        for (let x = 0; x < c.width; x++)
            if (c.data[(y * c.width + x) * 4 + 3] > 200)
                return y; return -1; };
    strict_1.default.equal(top(down.sc) - top(up.sc), 5);
});
