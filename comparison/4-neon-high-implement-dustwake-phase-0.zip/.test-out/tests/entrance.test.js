"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The entrance: digging the buried stair head out with a shovel head and a
// pickaxe head, the stair it opens between the surface and the halls, how both
// ends read before and after, and the save migrations (v13 -> v14, v14 -> v15
// for the stair's cheek walls, and v15 -> v16 for raising its newel posts).
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const world_1 = require("../src/game/world/world");
const digging_1 = require("../src/game/content/digging");
const geography_1 = require("../src/game/content/geography");
const tiles_1 = require("../src/game/content/tiles");
const props_1 = require("../src/game/content/props");
const props_2 = require("../src/game/art/props");
const fakeCanvas_1 = require("./support/fakeCanvas");
const inventory_1 = require("../src/game/sim/inventory");
const commands_1 = require("../src/game/sim/commands");
const collision_1 = require("../src/game/sim/collision");
const digging_2 = require("../src/game/sim/digging");
const portals_1 = require("../src/game/sim/portals");
const interact_1 = require("../src/game/sim/interact");
const analysis_1 = require("../src/game/sim/analysis");
const save_1 = require("../src/game/world/save");
const map_1 = require("../src/game/map");
const surface_1 = require("../src/game/surface");
const stairs_1 = require("../src/game/art/stairs");
const helpers_1 = require("./helpers");
const GATE = "buriedgate@48,61", SITE = digging_1.DIG_SITES.buriedgate;
const wear = (w, id) => { const pl = (0, world_1.player)(w); (0, inventory_1.addItems)(w, pl, id, 1); return (0, commands_1.wearFromSlot)(w, pl, pl.inventory.findIndex((s) => s?.item === id)); };
const digIt = (w) => (0, helpers_1.find)(w, (i) => i.kind === "dig");
/** A world with the golem standing on the surface by the buried stair head. */
function atGate() {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, helpers_1.frame)(w);
    const gate = (0, world_1.getArea)(w, "surface").prop(GATE);
    (0, world_1.enterArea)(w, pl, "surface", gate.x, gate.y + 8);
    return { w, pl, gate, surface: (0, world_1.getArea)(w, "surface"), dungeon: (0, world_1.getArea)(w, "dungeon") };
}
/** E on the dig site `n` times, each stroke played out. */
const dig = (w, n) => { for (let i = 0; i < n; i++)
    (0, helpers_1.useOn)(w, digIt(w)); };
/** Dig the stair out with a shovel head, then a pickaxe head. */
function digOut(w) {
    strict_1.default.equal(wear(w, "head_shovel"), "ok");
    dig(w, SITE.layers[0].work);
    strict_1.default.equal(wear(w, "head_pickaxe"), "ok");
    dig(w, SITE.layers[1].work);
}
// ------------------------------------------------------------------ data
(0, node_test_1.test)("dig data: earth over stone, the shovel for one and the pickaxe for the other; stages run 0 to open", () => {
    strict_1.default.deepEqual(SITE.layers.map((l) => l.material), ["dirt", "stone"]);
    strict_1.default.equal(SITE.opens, "surface_stair");
    strict_1.default.deepEqual([digging_1.DIG_MATERIALS.dirt.tool, digging_1.DIG_MATERIALS.dirt.yields], ["shovel", "dirt"]);
    strict_1.default.deepEqual([digging_1.DIG_MATERIALS.stone.tool, digging_1.DIG_MATERIALS.stone.yields], ["pickaxe", "stone"]);
    strict_1.default.deepEqual(digging_1.GROUND_COLUMN.map((l) => l.material), ["dirt", "stone"], "what open ground would be, for digging anywhere later");
    const total = (0, digging_1.digTotal)(SITE), d = SITE.layers[0].work;
    strict_1.default.deepEqual((0, digging_1.digLayerAt)(SITE, 0), { index: 0, material: "dirt", into: 0, left: d });
    strict_1.default.equal((0, digging_1.digLayerAt)(SITE, d - 0.5).material, "dirt");
    strict_1.default.deepEqual((0, digging_1.digLayerAt)(SITE, d), { index: 1, material: "stone", into: 0, left: total - d });
    strict_1.default.equal((0, digging_1.digLayerAt)(SITE, total), null);
    const stages = Array.from({ length: total + 1 }, (_, i) => (0, digging_1.digStage)(SITE, i, false));
    strict_1.default.equal(stages[0], 0);
    strict_1.default.deepEqual([...stages].sort((a, b) => a - b), stages, "never goes back");
    strict_1.default.deepEqual([...new Set(stages)], [0, 1, 2, 3, 4]);
    strict_1.default.equal((0, digging_1.digStage)(SITE, total, true), 5);
    strict_1.default.equal((0, digging_1.propLook)({ kind: "buriedgate", v: 0, dmg: d, open: false }), 3, "the stone shows once the earth is out");
    strict_1.default.equal((0, digging_1.propLook)({ kind: "tree", v: 2, dmg: 3 }), 2, "anything else keeps its authored variant");
    // every stage is drawn (and differs from the one before)
    (0, fakeCanvas_1.installFakeCanvas)();
    strict_1.default.ok(props_2.PROP_ART.buriedgate);
    for (let v = 0; v <= 5; v++)
        strict_1.default.ok((0, props_2.propSprite)("buriedgate", v, v === 5), `stage ${v}`);
});
// ------------------------------------------------------------------ digging
(0, node_test_1.test)("no shovel, no digging; with a shovel head the earth comes out as dirt, a unit a stroke, and stops at the stone", () => {
    const { w, pl, gate } = atGate();
    strict_1.default.equal(digIt(w).propId, GATE);
    strict_1.default.ok((0, analysis_1.visionTargets)(w, (0, world_1.currentArea)(w)).some((v) => v.id === GATE && v.category === "interactable"), "golem vision marks it");
    (0, helpers_1.events)(w);
    dig(w, 1);
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "message" && /SHOVEL HEAD/.test(e.text)));
    strict_1.default.equal(gate.dmg, 0);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "dirt"), 0);
    // a hafted shovel in the pack is no use to the maintainer: the head has to be on the arm
    (0, inventory_1.addItems)(w, pl, "shovel", 1);
    dig(w, 1);
    strict_1.default.equal(gate.dmg, 0);
    strict_1.default.equal(wear(w, "head_shovel"), "ok");
    (0, helpers_1.events)(w);
    dig(w, 1);
    strict_1.default.equal(gate.dmg, 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "dirt"), 1);
    strict_1.default.deepEqual((0, helpers_1.events)(w).filter((e) => e.t === "dug"), [{ t: "dug", actor: pl.id, prop: GATE, x: gate.x, y: gate.y + SITE.dy, material: "dirt", n: 1, next: undefined, opened: false }]);
    strict_1.default.equal((0, digging_1.propLook)(gate), 1);
    dig(w, SITE.layers[0].work - 2);
    (0, helpers_1.events)(w);
    dig(w, 1);
    const last = (0, helpers_1.events)(w).find((e) => e.t === "dug");
    strict_1.default.ok(last.t === "dug" && last.next === "stone" && !last.opened, "the last of the earth: stone under it");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "dirt"), SITE.layers[0].work);
    strict_1.default.equal(gate.dmg, SITE.layers[0].work);
    // the shovel does nothing to the stone
    (0, helpers_1.events)(w);
    dig(w, 2);
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "message" && /PICKAXE HEAD/.test(e.text)));
    strict_1.default.equal(gate.dmg, SITE.layers[0].work);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "stone"), 0);
    strict_1.default.ok(!gate.open && !(0, world_1.hasFlag)(w, geography_1.ENTRANCES.surface_stair.flag));
    // still flat ground: the golem can stand on it
    strict_1.default.ok(!(0, collision_1.propBlocks)(gate) && (0, collision_1.boxFree)((0, world_1.currentArea)(w), gate.x, gate.y - 20));
});
(0, node_test_1.test)("the stone takes a pickaxe head and comes out as stone; a fine head works twice as fast; a save mid-dig carries on", () => {
    const { w, pl } = atGate();
    strict_1.default.equal(wear(w, "head_shovel_fine"), "ok");
    dig(w, SITE.layers[0].work / 2);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "dirt"), SITE.layers[0].work, "two units a stroke");
    strict_1.default.equal(wear(w, "head_pickaxe"), "ok");
    strict_1.default.equal(pl.gear.armR, "head_pickaxe");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "head_shovel_fine"), 1, "one arm: the shovel head comes off for the pick");
    dig(w, 3);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "stone"), 3);
    const w2 = (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w)))), pl2 = (0, world_1.player)(w2), gate2 = (0, world_1.getArea)(w2, "surface").prop(GATE);
    strict_1.default.equal(gate2.dmg, SITE.layers[0].work + 3);
    strict_1.default.ok(!gate2.open);
    strict_1.default.equal((0, digging_1.propLook)(gate2), 3);
    dig(w2, SITE.layers[1].work - 3);
    strict_1.default.equal((0, inventory_1.countItem)(pl2, "stone"), SITE.layers[1].work);
    strict_1.default.ok(gate2.open && (0, digging_2.entranceOpen)(w2, "surface_stair"));
});
(0, node_test_1.test)("dug through, the stair is open: the stair head is a hole with a lip, the fall is gone from the stair below, and daylight comes down it", () => {
    const { w, pl, gate, surface, dungeon } = atGate();
    // before: the way up is choked solid, hall and flight; the toe of its fall lies in the Vestibule, and no light burns in it
    const S = geography_1.GATE_PASSAGE, stair = (fn) => { for (let y = S.y; y < S.y + S.h; y++)
        for (let x = S.x; x < S.x + S.w; x++)
            fn(x, y); };
    stair((x, y) => strict_1.default.equal(dungeon.tile(x, y), tiles_1.T.RUBBLE));
    strict_1.default.ok(dungeon.prop("stairfall") && !dungeon.prop("stairlight").lit);
    const piles = dungeon.props.filter((p) => p.kind === "rockpile").length;
    (0, helpers_1.events)(w);
    digOut(w);
    const ev = (0, helpers_1.events)(w);
    strict_1.default.ok(ev.some((e) => e.t === "dug" && e.opened) && ev.some((e) => e.t === "entranceOpened" && e.entrance === "surface_stair"));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "dirt"), SITE.layers[0].work);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "stone"), SITE.layers[1].work);
    // the surface end
    strict_1.default.ok(gate.open && gate.lit, "open, and the ward glyph on its lintel awake");
    strict_1.default.equal((0, digging_1.propLook)(gate), 5);
    strict_1.default.ok((0, collision_1.propBlocks)(gate) && !(0, collision_1.boxFree)(surface, gate.x, gate.y - 20), "a hole now: nobody walks across it");
    strict_1.default.ok((0, collision_1.boxFree)(surface, pl.x, pl.y), "the golem was set down clear of it");
    strict_1.default.ok(pl.y > gate.y && Math.abs(pl.x - gate.x) < 26, "on its south lip");
    strict_1.default.ok(!(0, interact_1.interactables)(surface).some((i) => i.kind === "dig" || i.propId === GATE), "nothing left to dig");
    strict_1.default.equal((0, digging_2.digSpot)(surface, GATE), null);
    // the lower end
    strict_1.default.ok((0, world_1.hasFlag)(w, geography_1.ENTRANCES.surface_stair.flag));
    stair((x, y) => { strict_1.default.equal(dungeon.tile(x, y), tiles_1.T.FLOOR); strict_1.default.equal(dungeon.style[y * dungeon.w + x], y < geography_1.GATE_STAIR.y ? tiles_1.FS.FLAG : tiles_1.FS.STAIR, "a flagged hall, then the steps"); });
    strict_1.default.ok(!dungeon.prop("stairfall"), "the fall is gone");
    for (const id of ["stairpost.w", "stairpost.e", "staircheek.w", "staircheek.e"])
        strict_1.default.ok(dungeon.prop(id), `${id}: the stair's own stonework stays`);
    strict_1.default.ok(dungeon.prop("stairlight").lit, "the sky comes down the stair");
    strict_1.default.equal(dungeon.props.filter((p) => p.kind === "rockpile").length, 2, `of ${piles} rock piles only the two in the Vestibule are left`);
    // once only
    strict_1.default.equal((0, digging_2.openEntrance)(w, pl, "surface_stair"), false);
    // and it all survives a save
    const w2 = (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w)))), d2 = (0, world_1.getArea)(w2, "dungeon"), g2 = (0, world_1.getArea)(w2, "surface").prop(GATE);
    strict_1.default.ok(g2.open && g2.lit && (0, collision_1.propBlocks)(g2) && (0, digging_2.entranceOpen)(w2, "surface_stair"));
    stair((x, y) => strict_1.default.equal(d2.tile(x, y), tiles_1.T.FLOOR));
    strict_1.default.ok(!d2.prop("stairfall") && d2.prop("stairlight").lit && d2.props.filter((p) => p.kind === "rockpile").length === 2);
    strict_1.default.deepEqual((0, save_1.serialize)(w2), (0, save_1.serialize)(w));
});
// ------------------------------------------------------------------ walking it
(0, node_test_1.test)("the open stair is walked both ways: down from the stair head's south lip into the halls, and south off the top of the flight back out", () => {
    const { w, pl, gate, surface, dungeon } = atGate();
    const down = (0, portals_1.portalById)(surface, "stair_down"), up = (0, portals_1.portalById)(dungeon, "stair_up");
    strict_1.default.deepEqual(down.to, { area: "dungeon", portal: "stair_up" });
    strict_1.default.deepEqual(up.to, { area: "surface", portal: "stair_down" });
    strict_1.default.equal(down.dir, "up");
    strict_1.default.equal(up.dir, "down");
    strict_1.default.equal(down.flag, geography_1.ENTRANCES.surface_stair.flag);
    strict_1.default.equal(up.flag, down.flag);
    // shut while it is buried: pushing north over the patch is just walking
    strict_1.default.ok(!(0, portals_1.portalOpen)(w, down));
    pl.x = gate.x;
    pl.y = gate.y + 6;
    (0, helpers_1.frames)(w, 60, { ix: 0, iy: -1, use: false });
    strict_1.default.equal(pl.area, "surface");
    strict_1.default.ok(pl.y < gate.y, "walked on across the buried stair");
    digOut(w);
    strict_1.default.ok((0, portals_1.portalOpen)(w, down) && (0, portals_1.portalOpen)(w, up));
    // down
    (0, helpers_1.events)(w);
    pl.x = gate.x;
    pl.y = gate.y + 6;
    (0, helpers_1.frames)(w, 4, { ix: 0, iy: -1, use: false });
    strict_1.default.equal(pl.area, "dungeon");
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "portal" && e.from === "stair_down" && e.to === "stair_up"));
    strict_1.default.equal(pl.facing, "up");
    strict_1.default.ok(pl.y > (geography_1.GATE_STAIR.y + geography_1.GATE_STAIR.h - 1) * tiles_1.TS && pl.x > geography_1.GATE_STAIR.x * tiles_1.TS && pl.x < (geography_1.GATE_STAIR.x + geography_1.GATE_STAIR.w) * tiles_1.TS, "at the top of the flight");
    strict_1.default.ok((0, collision_1.boxFree)(dungeon, pl.x, pl.y));
    // keep going: north down the steps into the Vestibule, with no trip back
    (0, helpers_1.frames)(w, 60 * 4, { ix: 0, iy: -1, use: false });
    strict_1.default.equal(pl.area, "dungeon");
    strict_1.default.ok(pl.y < geography_1.GATE_CORRIDOR.y * tiles_1.TS, `down the stair into the Vestibule (y ${pl.y})`);
    // and back: south up the steps, off the top
    (0, helpers_1.events)(w);
    (0, helpers_1.frames)(w, 60 * 6, { ix: 0, iy: 1, use: false });
    strict_1.default.equal(pl.area, "surface", "out on the surface again");
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "portal" && e.from === "stair_up" && e.to === "stair_down"));
    strict_1.default.ok(pl.y > gate.y && Math.abs(pl.x - gate.x) < 30, "south of the stair head");
    strict_1.default.equal(pl.facing, "down");
    strict_1.default.ok((0, collision_1.boxFree)(surface, pl.x, pl.y));
    // the hole is only entered from its south lip: pushing into it from the side goes nowhere
    pl.x = gate.x - 40;
    pl.y = gate.y - 20;
    (0, helpers_1.frames)(w, 60, { ix: 1, iy: 0, use: false });
    strict_1.default.equal(pl.area, "surface");
    strict_1.default.ok(pl.x < gate.x - 30, "stopped at the kerb");
    // the standing place laid out for whoever comes looking for the way in: the stair head's south lip, the surface's only
    // doorstep (the hunters' camp has places of its own, none of them a way in: tests/folk.test.ts)
    const surf = (0, surface_1.buildSurface)(), headProp = surf.props.find((p) => p.kind === "buriedgate");
    strict_1.default.deepEqual(surf.spots.filter((s) => s.kind === "door").map((s) => [s.id, s.x, s.y, s.facing]), [["stairhead", headProp.x, headProp.y + 7, "up"]]);
    strict_1.default.deepEqual((0, surface_1.buildSurface)({ camp: false }).spots.map((s) => s.id), ["stairhead"], "without the camp it is the surface's only place");
    strict_1.default.ok((0, map_1.buildDungeon)().spots.some((s) => s.id === "stairfoot"));
});
// ------------------------------------------------------------------ how it reads
(0, node_test_1.test)("both ends read as a stair: below, a hall to steps climbing south, under a fall with no air through it; above, a square stair head, not a round dent", () => {
    const d = (0, map_1.buildDungeon)(), s = (0, surface_1.buildSurface)();
    // below: the halls are the first cellar floor and this is the stair up
    strict_1.default.ok(d.exits.some((e) => e.label === "SURFACE STAIR" && e.dir === "s"));
    for (let y = geography_1.GATE_STAIR.y; y < geography_1.GATE_STAIR.y + geography_1.GATE_STAIR.h; y++)
        for (let x = geography_1.GATE_STAIR.x; x < geography_1.GATE_STAIR.x + geography_1.GATE_STAIR.w; x++) {
            strict_1.default.equal(d.style[y * d.w + x], tiles_1.FS.STAIR, "steps under the fall");
            strict_1.default.equal(d.plan[y * d.w + x], tiles_1.T.FLOOR, "as built, an open flight");
        }
    // the passage is a hall, then the flight: together they are what the fall filled, and nothing else is a step
    strict_1.default.deepEqual([geography_1.GATE_HALL.y, geography_1.GATE_HALL.h, geography_1.GATE_STAIR.y, geography_1.GATE_STAIR.h], [geography_1.GATE_PASSAGE.y, 2, geography_1.GATE_PASSAGE.y + 2, geography_1.GATE_PASSAGE.h - 2]);
    strict_1.default.equal(geography_1.ENTRANCES.surface_stair.below.clear, geography_1.GATE_PASSAGE);
    for (let y = geography_1.GATE_HALL.y; y < geography_1.GATE_HALL.y + geography_1.GATE_HALL.h; y++)
        for (let x = geography_1.GATE_HALL.x; x < geography_1.GATE_HALL.x + geography_1.GATE_HALL.w; x++) {
            strict_1.default.equal(d.style[y * d.w + x], tiles_1.FS.FLAG, "flags under the fall");
            strict_1.default.equal(d.plan[y * d.w + x], tiles_1.T.FLOOR);
            strict_1.default.equal(d.grid[y * d.w + x], tiles_1.T.RUBBLE);
        }
    strict_1.default.equal(d.style.filter((st) => st === tiles_1.FS.STAIR).length, geography_1.GATE_STAIR.w * geography_1.GATE_STAIR.h, "no step anywhere but in the flight");
    // no steps stand out in the Vestibule any more: where the hall opens there is earth, and it runs on along the hall
    strict_1.default.ok(!d.props.some((p) => p.kind === "stairfoot") && !("stairfoot" in props_2.PROP_ART));
    const mouth = { x: (geography_1.GATE_PASSAGE.x + geography_1.GATE_PASSAGE.w / 2) * tiles_1.TS, y: geography_1.GATE_PASSAGE.y * tiles_1.TS }, earth = d.decals.filter((dc) => dc.kind === "earthspill");
    strict_1.default.ok(earth.some((dc) => Math.abs(dc.x - mouth.x) < 8 && dc.y < mouth.y && dc.y > mouth.y - tiles_1.TS && dc.w >= 36), "earth where the foot used to stand");
    strict_1.default.ok(earth.some((dc) => dc.y > mouth.y && dc.y < geography_1.GATE_STAIR.y * tiles_1.TS), "and in the hall, between the Vestibule and the first step");
    strict_1.default.ok(!earth.some((dc) => dc.y - (dc.h >> 1) > geography_1.GATE_STAIR.y * tiles_1.TS), "none of it out on the flight");
    // the flight stands between two cheek walls, each ending in a newel post at its foot, against the passage's walls
    const sy = geography_1.GATE_STAIR.y * tiles_1.TS, x0 = geography_1.GATE_STAIR.x * tiles_1.TS, x1 = (geography_1.GATE_STAIR.x + geography_1.GATE_STAIR.w) * tiles_1.TS, at = (id) => { const q = d.props.find((p) => p.id === id); return [q.kind, q.x, q.y]; };
    strict_1.default.deepEqual(at("stairpost.w"), ["stairpost", x0 + geography_1.STAIR_CHEEK.post.w / 2, sy + geography_1.STAIR_CHEEK_TOP]);
    strict_1.default.deepEqual(at("stairpost.e"), ["stairpost", x1 - geography_1.STAIR_CHEEK.post.w / 2, sy + geography_1.STAIR_CHEEK_TOP]);
    // a post's feet stand on the flight's north edge or north of it, in the hall: its base never clips into the first step
    // (it once stood `post.d` px down, with its lowest rows drawn over the step)
    strict_1.default.equal(geography_1.STAIR_CHEEK_TOP, geography_1.STAIR_CHEEK.post.d - geography_1.STAIR_CHEEK.post.lift);
    for (const id of ["stairpost.w", "stairpost.e"])
        strict_1.default.ok(at(id)[2] <= sy, `${id}: feet off the first step`);
    strict_1.default.ok(geography_1.STAIR_CHEEK.post.lift >= 5 && geography_1.STAIR_CHEEK.post.lift <= 10, "raised by a few pixels, not moved away");
    strict_1.default.deepEqual(at("staircheek.w"), ["staircheek", x0 + geography_1.STAIR_CHEEK.wall.w / 2, (geography_1.GATE_STAIR.y + geography_1.GATE_STAIR.h) * tiles_1.TS]);
    strict_1.default.deepEqual(at("staircheek.e"), ["staircheek", x1 - geography_1.STAIR_CHEEK.wall.w / 2, (geography_1.GATE_STAIR.y + geography_1.GATE_STAIR.h) * tiles_1.TS]);
    strict_1.default.deepEqual((0, props_1.propDef)("staircheek").box, [geography_1.STAIR_CHEEK.wall.w, geography_1.GATE_STAIR.h * tiles_1.TS - geography_1.STAIR_CHEEK_TOP]);
    strict_1.default.ok((0, props_1.propDef)("staircheek").flat && !(0, props_1.propDef)("staircheek").examine && !(0, props_1.propDef)("stairpost").examine, "masonry, not things to use");
    const leak = d.lights.find((l) => l.id === "gateleak");
    strict_1.default.equal(leak.owner, "stairlight");
    strict_1.default.ok(leak.sky, "daylight, when there is any");
    strict_1.default.equal((0, props_1.propDef)("stairlight").light.when, "lit");
    strict_1.default.ok(!d.props.find((p) => p.id === "stairlight").lit, "no night air comes through the fall: the stair is dark until it is dug out");
    strict_1.default.match((0, props_1.propDef)("stairfall").examine, /HALL RUNS SOUTH.*SURFACE STAIR.*FROM ABOVE/);
    const w = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(w);
    (0, helpers_1.events)(w);
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "examine" && i.propId === "stairfall"));
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "message" && /CLEARED FROM ABOVE/.test(e.text)));
    // above: no round hollow or hump is painted over it any more; the stair head is centred on the stair and lies in its zone
    const z = geography_1.SURFACE_GATE_ZONE, inZone = (x, y) => x >= z.x0 * tiles_1.TS && x <= (z.x1 + 1) * tiles_1.TS && y >= z.y0 * tiles_1.TS && y <= (z.y1 + 1) * tiles_1.TS;
    strict_1.default.ok(!s.decals.some((dc) => (dc.kind === "hollow" || dc.kind === "hump") && inZone(dc.x, dc.y)));
    strict_1.default.equal(s.decals.filter((dc) => dc.kind === "ridge" && inZone(dc.x, dc.y)).length, 2, "the two straight banks over its side walls stay");
    const head = s.props.find((p) => p.kind === "buriedgate");
    strict_1.default.equal(head.id, GATE);
    strict_1.default.equal(head.x, (geography_1.GATE_STAIR.x + geography_1.GATE_STAIR.w / 2 + 12) * tiles_1.TS, "over the middle of the flight");
    strict_1.default.equal(Math.floor((head.y - 1) / tiles_1.TS), geography_1.SURFACE_GATE.y);
    strict_1.default.deepEqual((0, props_1.propDef)("buriedgate").openBox, [60, 44]);
});
(0, node_test_1.test)("the flight stands between its cheek walls: a body keeps off the wall faces and the newel posts, the hall is its full width, and the way through is open", () => {
    const { w, pl, dungeon } = atGate();
    digOut(w);
    const S = geography_1.GATE_STAIR, K = geography_1.STAIR_CHEEK, x0 = S.x * tiles_1.TS, x1 = (S.x + S.w) * tiles_1.TS, sy = S.y * tiles_1.TS, mid = sy + (S.h * tiles_1.TS) / 2;
    // the hall: wall to wall
    for (const x of [x0 + 5, x1 - 5])
        strict_1.default.ok((0, collision_1.boxFree)(dungeon, x, geography_1.GATE_HALL.y * tiles_1.TS + 12), `hall at ${x}`);
    // the posts stand in the corners at the foot of the flight (their feet on its north edge), and between them the way is open
    const py = sy + geography_1.STAIR_CHEEK_TOP;
    for (const x of [x0 + 5, x1 - 5])
        strict_1.default.ok(!(0, collision_1.boxFree)(dungeon, x, py - 1), `post at ${x}`);
    for (let x = x0 + K.post.w + 5; x <= x1 - K.post.w - 5; x++)
        strict_1.default.ok((0, collision_1.boxFree)(dungeon, x, py - 1), `between the posts at ${x}`);
    // each cheek wall's footprint begins exactly where its post's ends: no gap to stand in between them, nothing overlapping
    for (const side of ["w", "e"]) {
        const post = dungeon.prop("stairpost." + side).box, cheek = dungeon.prop("staircheek." + side).box;
        strict_1.default.equal(post[3], cheek[1], `${side}: the wall starts where the post ends`);
        strict_1.default.ok(post[3] <= sy, `${side}: the post's footprint is in the hall`);
        strict_1.default.equal(cheek[3], (S.y + S.h) * tiles_1.TS, `${side}: the wall runs to the top of the flight`);
    }
    strict_1.default.ok(x1 - x0 - 2 * K.post.w >= 30, "room for three golems abreast");
    // up the flight: the wall's footprint down each side, the treads between
    for (let y = py + 5; y <= (S.y + S.h) * tiles_1.TS; y += 4) {
        for (const x of [x0 + 5, x0 + K.wall.w + 4, x1 - 5, x1 - K.wall.w - 4])
            strict_1.default.ok(!(0, collision_1.boxFree)(dungeon, x, y), `in the wall at ${x},${y}`);
        for (const x of [x0 + K.wall.w + 5, x1 - K.wall.w - 5])
            strict_1.default.ok((0, collision_1.boxFree)(dungeon, x, y), `on the tread at ${x},${y}`);
    }
    // the footprint never reaches past the face that is drawn beside the lowest step it runs along (art/stairs.ts)
    strict_1.default.ok(K.wall.w <= (0, stairs_1.flightStepAt)(geography_1.STAIR_CHEEK_TOP, S.h * tiles_1.TS).inset && K.post.w >= (0, stairs_1.flightSteps)(S.h * tiles_1.TS)[0].inset);
    // walked: pushing west half-way up stops at the cheek; the portal's arrival and the whole middle are clear
    (0, world_1.enterArea)(w, pl, "dungeon", x0 + 30, mid);
    (0, helpers_1.frames)(w, 90, { ix: -1, iy: 0, use: false });
    strict_1.default.ok(Math.abs(pl.x - (x0 + K.wall.w + 5)) < 0.05, `against the west cheek (${pl.x})`);
    (0, helpers_1.frames)(w, 120, { ix: 1, iy: 0, use: false });
    strict_1.default.ok(Math.abs(pl.x - (x1 - K.wall.w - 5)) < 0.05, `against the east cheek (${pl.x})`);
    const up = (0, portals_1.portalById)(dungeon, "stair_up");
    strict_1.default.ok((0, collision_1.boxFree)(dungeon, up.arrive.x, up.arrive.y));
    // from the Vestibule straight up the hall's west side: the post turns nobody back for good, the flight is reached round it
    (0, world_1.enterArea)(w, pl, "dungeon", x0 + 20, geography_1.GATE_PASSAGE.y * tiles_1.TS - 6);
    (0, helpers_1.frames)(w, 60 * 8, { ix: 0, iy: 1, use: false });
    strict_1.default.equal(pl.area, "surface", "south from the Vestibule, along the hall, up the flight and out");
});
// ------------------------------------------------------------------ saves
(0, node_test_1.test)("save v15: a v14 save loads with the stair as it is now laid; a body saved in a cheek wall or a newel post is set down beside it, in the passage", () => {
    strict_1.default.equal(save_1.SAVE_VERSION, 20);
    const base = () => { const { w } = atGate(); digOut(w); return w; };
    const old = (edit = () => { }) => { const s = JSON.parse(JSON.stringify((0, save_1.serialize)(base()))); s.version = 14; edit(s, s.actors.find((a) => a.id === s.playerId)); return s; };
    // v15 only: a body standing clear is not touched, nor is anything else in the save
    const to15 = (raw) => (0, save_1.migrate)(raw, save_1.MIGRATIONS, 15);
    const plain = old(), m = to15(plain);
    strict_1.default.equal(m.version, 15);
    strict_1.default.deepEqual(m.actors, plain.actors);
    strict_1.default.deepEqual(m.areas, plain.areas);
    strict_1.default.deepEqual(m.flags, plain.flags);
    // the stair dug out before v15: hall and flight open, the fall gone, the new stonework standing
    const w0 = (0, save_1.deserialize)(plain), d0 = (0, world_1.getArea)(w0, "dungeon");
    for (let y = geography_1.GATE_PASSAGE.y; y < geography_1.GATE_PASSAGE.y + geography_1.GATE_PASSAGE.h; y++)
        for (let x = geography_1.GATE_PASSAGE.x; x < geography_1.GATE_PASSAGE.x + geography_1.GATE_PASSAGE.w; x++) {
            strict_1.default.equal(d0.tile(x, y), tiles_1.T.FLOOR);
            strict_1.default.equal(d0.style[y * d0.w + x], y < geography_1.GATE_STAIR.y ? tiles_1.FS.FLAG : tiles_1.FS.STAIR);
        }
    strict_1.default.ok(!d0.prop("stairfall") && !d0.prop("stairfoot") && d0.prop("stairlight").lit && (0, digging_2.entranceOpen)(w0, "surface_stair"));
    strict_1.default.equal(d0.props.filter((p) => p.kind === "rockpile").length, 2, "no rock pile came back onto the stair");
    // a save that still names the old foot (nothing ever did, but a hand-edited one might) loads all the same
    strict_1.default.doesNotThrow(() => (0, save_1.deserialize)(old((s) => { s.areas.dungeon.props.stairfoot = { open: true }; s.areas.dungeon.propsRemoved.push("stairfoot"); })));
    // every footprint v15 added, as v15 placed them (frozen here: the posts have moved since, in v16): a golem saved on the
    // old stair's edge, inside one, ends beside it
    const S = geography_1.GATE_STAIR, passage = [geography_1.GATE_PASSAGE.x * tiles_1.TS, geography_1.GATE_PASSAGE.y * tiles_1.TS, (geography_1.GATE_PASSAGE.x + geography_1.GATE_PASSAGE.w) * tiles_1.TS, (geography_1.GATE_PASSAGE.y + geography_1.GATE_PASSAGE.h) * tiles_1.TS];
    const V15 = [[544, 833, 556, 839], [596, 833, 608, 839], [544, 839, 552, 896], [600, 839, 608, 896]];
    const inV15 = (x, y) => V15.some((b) => x + 5 > b[0] && x - 5 < b[2] && y > b[1] && y - 5 < b[3]);
    for (const [n, b] of V15.entries())
        for (const fy of [0.1, 0.5, 1]) {
            const x = b[0] < S.x * tiles_1.TS + 20 ? b[0] + 5 : b[2] - 5, y = b[1] + (b[3] - b[1]) * fy;
            const s = old((_s, pl) => { pl.area = "dungeon"; pl.x = x; pl.y = y; });
            const g = to15(s).actors.find((a) => a.id === s.playerId);
            strict_1.default.ok(inV15(x, y), `footprint ${n}: the old spot is inside it`);
            strict_1.default.ok(!inV15(g.x, g.y), `footprint ${n} ${fy}: set down clear of all four (${g.x},${g.y})`);
            strict_1.default.ok(g.x - 5 >= passage[0] && g.x + 5 <= passage[2] && g.y - 5 >= passage[1] && g.y <= passage[3], `footprint ${n}: still in the passage`);
            strict_1.default.ok(Math.hypot(g.x - x, g.y - y) <= 17, `footprint ${n}: a step aside, no further`);
            strict_1.default.equal(g.area, "dungeon");
        }
    // a body in another area at the same coordinates is left alone
    const far = old((_s, pl) => { pl.area = "surface"; pl.x = S.x * tiles_1.TS + 4; pl.y = S.y * tiles_1.TS + 40; });
    strict_1.default.deepEqual((0, save_1.migrate)(far).actors, far.actors);
    // v13 saves run every step
    const v13 = old((s) => { s.version = 13; });
    strict_1.default.equal((0, save_1.migrate)(v13).version, save_1.SAVE_VERSION);
});
(0, node_test_1.test)("save v16: a v15 save loads with the newel posts raised off the first step; a body saved where a post now stands is set down beside it, in the passage; nobody else moves", () => {
    strict_1.default.equal(save_1.SAVE_VERSION, 20);
    const base = () => { const { w } = atGate(); digOut(w); return w; };
    const old = (edit = () => { }) => { const s = JSON.parse(JSON.stringify((0, save_1.serialize)(base()))); s.version = 15; edit(s, s.actors.find((a) => a.id === s.playerId)); return s; };
    // a body standing clear is not touched, nor is anything else in the save
    const plain = old(), m = (0, save_1.migrate)(plain);
    strict_1.default.equal(m.version, 20);
    strict_1.default.deepEqual(m.actors, plain.actors);
    strict_1.default.deepEqual(m.areas, plain.areas);
    strict_1.default.deepEqual(m.flags, plain.flags);
    // the dug-out stair loads as it is laid now: the posts' feet on the flight's north edge, the cheek walls running on from them
    const S = geography_1.GATE_STAIR, sy = S.y * tiles_1.TS, w0 = (0, save_1.deserialize)(plain), d0 = (0, world_1.getArea)(w0, "dungeon");
    for (const side of ["w", "e"]) {
        const post = d0.prop("stairpost." + side), cheek = d0.prop("staircheek." + side);
        strict_1.default.equal(post.y, sy + geography_1.STAIR_CHEEK_TOP, `${side}: post's feet`);
        strict_1.default.ok(post.y <= sy, `${side}: off the first step`);
        strict_1.default.equal(post.box[3], cheek.box[1], `${side}: the wall begins where the post ends`);
    }
    strict_1.default.ok((0, digging_2.entranceOpen)(w0, "surface_stair") && !d0.prop("stairfall"), "the stair is still dug out");
    // every footprint, live: a golem saved inside one ends beside it, clear of all four, still in the passage
    const passage = [geography_1.GATE_PASSAGE.x * tiles_1.TS, geography_1.GATE_PASSAGE.y * tiles_1.TS, (geography_1.GATE_PASSAGE.x + geography_1.GATE_PASSAGE.w) * tiles_1.TS, (geography_1.GATE_PASSAGE.y + geography_1.GATE_PASSAGE.h) * tiles_1.TS];
    const fresh = (0, world_1.getArea)((0, helpers_1.newWorld)(), "dungeon"), solid = ["stairpost.w", "stairpost.e", "staircheek.w", "staircheek.e"].map((id) => fresh.prop(id));
    strict_1.default.deepEqual(fresh.props.filter((p) => p.kind === "stairpost" || p.kind === "staircheek").map((p) => p.id).sort(), solid.map((p) => p.id).sort(), "the frozen list is all of them");
    for (const p of solid)
        for (const fy of [0.1, 0.5, 1]) {
            const b = p.box, x = b[0] < S.x * tiles_1.TS + 20 ? b[0] + 5 : b[2] - 5, y = b[1] + (b[3] - b[1]) * fy;
            const s = old((_s, pl) => { pl.area = "dungeon"; pl.x = x; pl.y = y; });
            const v = (0, save_1.deserialize)(s), g = (0, world_1.player)(v), a = (0, world_1.getArea)(v, "dungeon");
            strict_1.default.ok(!(0, collision_1.boxFree)(a, x, y), `${p.id}: the old spot is inside it`);
            strict_1.default.ok((0, collision_1.boxFree)(a, g.x, g.y), `${p.id} ${fy}: set down on open floor (${g.x},${g.y})`);
            strict_1.default.ok(g.x - 5 >= passage[0] && g.x + 5 <= passage[2] && g.y - 5 >= passage[1] && g.y <= passage[3], `${p.id}: still in the passage`);
            strict_1.default.ok(Math.hypot(g.x - x, g.y - y) <= 17, `${p.id}: a step aside, no further`);
            strict_1.default.equal(g.area, "dungeon");
        }
    // the case the move is for: standing in the hall's last rows against the passage wall, where a post now is, a body
    // steps back up the hall
    const inHall = old((_s, pl) => { pl.area = "dungeon"; pl.x = S.x * tiles_1.TS + 6; pl.y = sy - 3; });
    const hall = (0, save_1.migrate)(inHall).actors.find((a) => a.id === inHall.playerId);
    strict_1.default.ok(hall.y < sy - 3 && hall.y - 5 >= geography_1.GATE_HALL.y * tiles_1.TS, `stepped up the hall (${hall.y})`);
    // and nobody is moved who need not be: the east half of a v15 post's base is open floor now (the post stands in the hall
    // and the wall is narrower than it was), as is the whole of the hall's middle and every tread
    for (const [x, y] of [[558, 838], [578, sy - 3], [578, sy + 30], [S.x * tiles_1.TS + 20, sy + 4]]) {
        const s = old((_s, pl) => { pl.area = "dungeon"; pl.x = x; pl.y = y; });
        const a = (0, world_1.getArea)((0, save_1.deserialize)(s), "dungeon");
        strict_1.default.ok((0, collision_1.boxFree)(a, x, y), `${x},${y} is open floor in v16`);
        strict_1.default.deepEqual((0, save_1.migrate)(s).actors, s.actors, `${x},${y}: left where it stood`);
    }
    // a body in another area at the same coordinates is left alone
    const far = old((_s, pl) => { pl.area = "surface"; pl.x = S.x * tiles_1.TS + 6; pl.y = sy - 3; });
    strict_1.default.deepEqual((0, save_1.migrate)(far).actors, far.actors);
    // older saves run every step
    const v14 = old((s) => { s.version = 14; });
    strict_1.default.equal((0, save_1.migrate)(v14).version, 20);
});
(0, node_test_1.test)("save v14: a v13 save loads; a body saved where the new furniture or an iron vein stands is set down beside it; nothing else moves", () => {
    strict_1.default.equal(save_1.SAVE_VERSION, 20);
    const old = (edit = () => { }) => { const s = JSON.parse(JSON.stringify((0, save_1.serialize)((0, helpers_1.newWorld)()))); s.version = 13; edit(s); return s; };
    const plain = old(), m = (0, save_1.migrate)(plain);
    strict_1.default.equal(m.version, 20);
    strict_1.default.deepEqual(m.actors, plain.actors, "a body standing clear is not touched");
    strict_1.default.deepEqual(m.areas, plain.areas);
    strict_1.default.deepEqual(m.flags, plain.flags);
    // the player on the spot the rune-cutter's table now takes, the worker where the slip vat stands
    const stuck = old((s) => {
        const pl = s.actors.find((a) => a.id === s.playerId), worker = s.actors.find((a) => a.id === "npc.worker.artificery");
        pl.x = 128;
        pl.y = 733;
        worker.x = 76;
        worker.y = 734;
    });
    const w = (0, save_1.deserialize)(stuck), a = (0, world_1.getArea)(w, "dungeon"), pl = (0, world_1.player)(w), worker = (0, world_1.actorById)(w, "npc.worker.artificery");
    strict_1.default.ok(a.prop("runetable@7.5,45") && a.prop("clayvat@4.25,45"), "the new furniture is there in an old save");
    strict_1.default.ok(pl.x !== 128 || pl.y !== 733);
    for (const body of [pl, worker])
        for (const p of a.props)
            if ((0, collision_1.propBlocks)(p)) {
                const b = p.box;
                strict_1.default.ok(!(body.x + 5 > b[0] && body.x - 5 < b[2] && body.y > b[1] && body.y - 5 < b[3]), `${body.id} is clear of ${p.id}`);
            }
    strict_1.default.ok((0, collision_1.boxFree)(a, pl.x, pl.y), "and on open floor");
    // the frozen list is every solid prop v14 added to the two rooms, and every vein
    const added = ["coalbin@4,37", "quench@4.5,40", "runetable@7.5,45", "clayvat@4.25,45", "husk@4.5,42", "weaponrack@67.25,4.25", "staffrack@62.75,5.5", "armorstand@62.5,9.5", "armorpile@66.75,8"];
    for (const id of added) {
        const p = (0, world_1.getArea)((0, helpers_1.newWorld)(), "dungeon").prop(id), b = p.box;
        const s = old((x) => { const g = x.actors.find((q) => q.id === x.playerId); g.x = (b[0] + b[2]) / 2; g.y = b[3]; });
        const g = (0, save_1.migrate)(s).actors.find((q) => q.id === s.playerId);
        strict_1.default.ok(g.x !== (b[0] + b[2]) / 2 || g.y !== b[3], `${id}: moved off it`);
    }
    const veins = (0, surface_1.buildSurface)().props.filter((p) => p.kind === "ironore");
    for (const p of veins) {
        const s = old((x) => { const g = x.actors.find((q) => q.id === x.playerId); g.area = "surface"; g.x = p.x; g.y = p.y; x.areas.surface = (0, save_1.serialize)((() => { const v = (0, helpers_1.newWorld)(); (0, world_1.getArea)(v, "surface"); return v; })()).areas.surface; });
        const v = (0, save_1.deserialize)(s), g = (0, world_1.player)(v);
        strict_1.default.ok((0, collision_1.boxFree)((0, world_1.getArea)(v, "surface"), g.x, g.y), `${p.id}: the golem is beside it, not in it`);
    }
    // the dig, the stair and the tools all work in a migrated world
    const world = (0, save_1.deserialize)(old()), golem = (0, world_1.player)(world);
    (0, helpers_1.frame)(world);
    const gate = (0, world_1.getArea)(world, "surface").prop(GATE);
    (0, world_1.enterArea)(world, golem, "surface", gate.x, gate.y + 8);
    digOut(world);
    strict_1.default.ok(gate.open && (0, digging_2.entranceOpen)(world, "surface_stair"));
    // loading from storage also never leaves the player inside a solid prop (settle), and leaves a sound save alone
    const store = new Map(), storage = { getItem: (k) => store.get(k) ?? null, setItem: (k, v) => void store.set(k, v) };
    const fresh = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(fresh);
    const at = { x: (0, world_1.player)(fresh).x, y: (0, world_1.player)(fresh).y };
    (0, save_1.saveToStorage)(fresh, storage);
    const same = (0, save_1.loadFromStorage)(storage);
    strict_1.default.deepEqual({ x: (0, world_1.player)(same).x, y: (0, world_1.player)(same).y }, at);
    const bin = (0, world_1.getArea)(fresh, "dungeon").prop("coalbin@4,37");
    (0, world_1.player)(fresh).x = bin.x;
    (0, world_1.player)(fresh).y = bin.y - 1;
    (0, save_1.saveToStorage)(fresh, storage);
    const moved = (0, save_1.loadFromStorage)(storage);
    strict_1.default.ok((0, collision_1.boxFree)((0, world_1.getArea)(moved, "dungeon"), (0, world_1.player)(moved).x, (0, world_1.player)(moved).y));
    // the open stair head counts as solid for it, the buried one does not
    const on = (0, helpers_1.newWorld)();
    (0, helpers_1.frame)(on);
    const head = (0, world_1.getArea)(on, "surface").prop(GATE);
    (0, world_1.enterArea)(on, (0, world_1.player)(on), "surface", head.x, head.y - 20);
    strict_1.default.deepEqual({ x: (0, world_1.player)((0, save_1.settle)(on)).x, y: (0, world_1.player)(on).y }, { x: head.x, y: head.y - 20 }, "standing on the buried stair is standing on ground");
});
