"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Shops in use (content/shops.ts, content/talk.ts, sim/shops.ts and the shop side of sim/folk.ts): the data (hours,
// visits, habits, every line in the font and within a bubble), shop trips off the clock (who goes where, only while
// it is open), a visit lived step by step (in by the door, the shelves, the queue, the deal over the counter, out),
// shopkeepers (hours, greeting, serving, tidying, the golem's talk, scan), conversations (in turn, varied, never the
// same exchange twice running), the guild board (a look only; the duty seam), saves (v18 -> v19, mid-visit), and the
// invariants over whole days in every room: nobody stuck, no place held by two, no head turned round. Plus timing.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const world_1 = require("../src/game/world/world");
const step_1 = require("../src/game/sim/step");
const debug_1 = require("../src/game/sim/debug");
const daytime_1 = require("../src/game/sim/daytime");
const save_1 = require("../src/game/world/save");
const daycycle_1 = require("../src/game/content/daycycle");
const folk_1 = require("../src/game/content/folk");
const shops_1 = require("../src/game/content/shops");
const talk_1 = require("../src/game/content/talk");
const town_1 = require("../src/game/content/town");
const folk_2 = require("../src/game/sim/folk");
const shops_2 = require("../src/game/sim/shops");
const interactions_1 = require("../src/game/content/interactions");
const interact_1 = require("../src/game/sim/interact");
const analysis_1 = require("../src/game/sim/analysis");
const collision_1 = require("../src/game/sim/collision");
const navigation_1 = require("../src/game/sim/navigation");
const font_1 = require("../src/game/font");
const textWrap_1 = require("../src/game/ui/textWrap");
const folkArt_1 = require("../src/game/folkArt");
const actors_1 = require("../src/game/view/actors");
const keeperArt_1 = require("../src/game/keeperArt");
const util_1 = require("../src/game/util");
const DT = 0.05;
const ROT = ["up", "right", "down", "left"];
const folkOf = (w) => w.actors.filter(folk_2.isFolk);
const natural = (facing, head) => !head || (head !== facing && head !== ROT[(ROT.indexOf(facing) + 2) % 4]);
/** The golem in an area (by its door, out of the doorway if there is room), at an hour of the day. */
function at(hour, area = "town", seed = 7) {
    const w = (0, world_1.createWorld)(seed);
    (0, world_1.getArea)(w, "town"); // the golem came through the town to get anywhere in it: its people exist
    const A = (0, world_1.getArea)(w, area), pl = (0, world_1.player)(w);
    if (!(area !== "town" && (0, debug_1.teleportTo)(w, pl, area, A.start.x - 36, A.start.y - 30)))
        strict_1.default.ok((0, debug_1.teleportTo)(w, pl, area, A.start.x, A.start.y), `room for the golem in ${area}`);
    (0, daytime_1.advanceDayTo)(w, hour);
    return w;
}
function run(w, seconds, each) {
    for (let t = 0; t < seconds - 1e-9; t += DT) {
        (0, step_1.stepWorld)(w, DT);
        each?.(w);
        w.events = [];
    }
}
/** Every shop trip that begins in the next day of the world's clock: who, and the plan. */
function tripsAhead(w) {
    const out = [];
    for (const a of folkOf(w)) {
        let last = "";
        for (let d = w.day + 0.002; d < w.day + 1; d += 0.002) {
            const p = (0, folk_2.planAt)(w, a, d);
            if (p.trip && p.key !== last && p.startDay > w.day)
                out.push({ a, plan: p });
            last = p.key;
        }
    }
    return out.sort((x, y) => x.plan.startDay - y.plan.startDay || (x.a.id < y.a.id ? -1 : 1));
}
const exclusiveHeld = (w) => {
    const out = new Map();
    for (const a of folkOf(w)) {
        const id = a.life.spot;
        if (!id || id.startsWith("lamp:"))
            continue;
        const s = (0, folk_2.spotById)((0, world_1.getArea)(w, a.area), id);
        if (!s || !(0, folk_2.isExclusive)(s))
            continue;
        const k = `${a.area}|${id}`;
        out.set(k, [...(out.get(k) ?? []), a.id]);
    }
    return out;
};
const said = (w) => w.events.filter((e) => e.t === "folkSay");
// ------------------------------------------------------------------ data
(0, node_test_1.test)("shop data resolves: hours, keepers, visits and habits name things that exist, and every step of every visit has a place in every shop that offers it", () => {
    strict_1.default.deepEqual(Object.keys(shops_1.SHOPS).sort(), [...town_1.ESTABLISHMENTS].sort(), "a row for each of the six shops");
    const w = (0, world_1.createWorld)(3);
    for (const e of town_1.ESTABLISHMENTS) {
        const def = shops_1.SHOPS[e], area = (0, world_1.getArea)(w, (0, town_1.interiorId)(e)), spots = area.base.spots ?? [];
        strict_1.default.equal(folk_1.FOLK_INTERIORS[e].area, area.id);
        strict_1.default.ok(folk_1.HABITAT_AREAS.town.includes(area.id), `${e}: townsfolk may go in`);
        strict_1.default.ok(def.hours.open < def.hours.close && (!def.hours.lunch || (def.hours.lunch[0] > def.hours.open && def.hours.lunch[1] < def.hours.close)), `${e}: hours`);
        for (const k of ["greet", "welcome", "hello", "closing"])
            strict_1.default.ok(def.keeper[k].length > 0, `${e}: keeper ${k} lines`);
        for (const id of ["keeper", "customer", "queue.1", "queue.2", "door"])
            strict_1.default.ok(spots.some((s) => s.id === id), `${e}: a ${id} spot`);
        strict_1.default.ok(spots.filter((s) => s.kind === "tidy").length >= 1, `${e}: shelves for the keeper to tidy`);
        for (const [vid, weight] of Object.entries(def.visits)) {
            const v = shops_1.VISITS[vid];
            strict_1.default.ok(v && weight > 0, `${e}: visit ${vid}`);
            for (const st of v.steps)
                for (const want of [st.at, st.after ?? st.at]) {
                    if (want[0] === "counter")
                        continue;
                    strict_1.default.ok(spots.some((s) => ["browse", "idle", "seat"].includes(s.kind) && want.some((p) => s.id.startsWith(p))), `${e}: ${vid} wants ${want}`);
                }
            for (const st of v.steps)
                if (st.deal)
                    strict_1.default.ok(talk_1.EXCHANGES.some((x) => x.ctx.includes(`deal.${st.deal}`) && !x.a && !x.b), `a deal.${st.deal} exchange anyone can have`);
            for (const st of v.steps)
                if (st.mutter)
                    strict_1.default.ok(talk_1.MUTTERS[st.mutter], `mutters: ${st.mutter}`);
        }
    }
    for (const [arch, h] of Object.entries(shops_1.SHOP_HABITS)) {
        strict_1.default.ok(folk_1.ARCHETYPES[arch] && folk_1.ARCHETYPES[arch].habitat === "town", `${arch} lives in the town`);
        for (const s of Object.keys(h.shops))
            strict_1.default.ok(shops_1.SHOPS[s], `${arch}: ${s}`);
        strict_1.default.ok(folk_1.ARCHETYPES[arch].routines.some((r) => folk_1.ROUTINES[r].blocks.some((b) => h.during.includes(b.act) && b.to - b.from >= shops_1.TRIP.minBlock)), `${arch}: a block of the day to shop in`);
    }
    for (const v of Object.values(shops_1.VISITS))
        for (const a of v.only ?? [])
            strict_1.default.ok(folk_1.ARCHETYPES[a], `${v.id}: only ${a}`);
});
(0, node_test_1.test)("every shop place is free floor a person can walk to from the door, and a keeper's shelves are a clear walk from the counter", () => {
    const w = (0, world_1.createWorld)(3);
    for (const e of town_1.ESTABLISHMENTS) {
        const area = (0, world_1.getArea)(w, (0, town_1.interiorId)(e)), spots = area.base.spots ?? [], door = spots.find((s) => s.id === "door");
        const probe = (0, world_1.makeActor)("probe", "townsfolk", area.id, door.x, door.y);
        probe.kind = "folk";
        w.actors.push(probe);
        const grid = (0, navigation_1.navGrid)(area, probe), keeper = spots.find((s) => s.id === "keeper");
        for (const s of spots.filter((x) => ["browse", "queue", "tidy", "customer", "keeper"].includes(x.kind) || x.id.startsWith(shops_1.BOARD.spots))) {
            strict_1.default.ok(grid.free(s.x, s.y), `${e}: ${s.id} stands on free floor`);
            probe.x = door.x;
            probe.y = door.y;
            strict_1.default.ok((0, navigation_1.findPath)(w, probe, { x: s.x, y: s.y, range: 2 }, false), `${e}: ${s.id} can be walked to from the door`);
            if (s.kind === "tidy")
                strict_1.default.ok((0, navigation_1.sweptFree)(keeper, s, grid.free), `${e}: ${s.id} is a straight clear walk from the counter`);
        }
        w.actors.splice(w.actors.indexOf(probe), 1);
    }
});
(0, node_test_1.test)("every line of talk is in the bitmap font and short enough for a bubble; exchanges alternate speakers; people have things of their own to say", () => {
    const glyphs = (s, what) => { for (const ch of s)
        strict_1.default.ok(ch === " " || font_1.FONT_GLYPHS.has(ch), `${what}: no glyph for "${ch}" in "${s}"`); };
    const longest = [...folk_1.NAMES.given].sort((a, b) => b.length - a.length)[0];
    const ids = new Set();
    for (const x of talk_1.EXCHANGES) {
        strict_1.default.ok(!ids.has(x.id), `exchange id ${x.id} is unique`);
        ids.add(x.id);
        strict_1.default.ok(x.lines.length >= 2 && x.lines.length <= 6 && x.ctx.length > 0, `${x.id}: two to six lines`);
        x.lines.forEach(([who, text], i) => {
            if (i)
                strict_1.default.notEqual(who, x.lines[i - 1][0], `${x.id}: line ${i} is the other side's (in turn)`);
            if (text.startsWith("@")) {
                strict_1.default.ok(["@say", "@re", "@gripe", "@news"].includes(text), `${x.id}: ${text}`);
                return;
            }
            const full = text.replace("{a}", longest).replace("{b}", longest).replace("{you}", longest).replace("{hail}", "AFTERNOON");
            strict_1.default.ok(!/[{}@]/.test(full), `${x.id}: unknown token in "${text}"`);
            glyphs(full, x.id);
            strict_1.default.ok(full.length <= talk_1.LINE_MAX, `${x.id}: "${full}" is ${full.length} long`);
            strict_1.default.ok((0, textWrap_1.wrapText)(full, 22).length <= 2, `${x.id}: "${full}" fits two rows of a bubble`);
        });
        for (const side of [x.a, x.b]) {
            for (const a of side?.arch ?? [])
                strict_1.default.ok(folk_1.ARCHETYPES[a], `${x.id}: ${a}`);
            for (const t of [...(side?.trait ?? []), ...(side?.not ?? [])])
                strict_1.default.ok(folk_1.TRAITS[t] || folk_1.ARCHETYPES[t], `${x.id}: ${t}`);
        }
    }
    for (const [k, pool] of [...Object.entries(talk_1.PEER_LINES), ...Object.entries(talk_1.REACTIONS), ...Object.entries(talk_1.MUTTERS), ["gripes", talk_1.GRIPES], ["news", talk_1.NEWS]]) {
        strict_1.default.ok(pool.length > 0, k);
        for (const l of pool) {
            glyphs(l, k);
            strict_1.default.ok(l.length <= talk_1.LINE_MAX && (0, textWrap_1.wrapText)(l, 22).length <= 3, `${k}: "${l}"`);
        }
    }
    for (const k of Object.keys(talk_1.PEER_LINES))
        strict_1.default.ok(folk_1.ARCHETYPES[k] || folk_1.TRAITS[k], `peer lines for ${k}`);
    for (const e of town_1.ESTABLISHMENTS)
        for (const k of ["greet", "welcome", "hello", "closing"])
            for (const l of shops_1.SHOPS[e].keeper[k]) {
                glyphs(l, `${e} ${k}`);
                if (k === "greet")
                    strict_1.default.ok((0, textWrap_1.wrapText)(l, 22).length <= 4, `${e}: "${l}" fits a bubble`);
                else
                    strict_1.default.ok(l.length <= talk_1.LINE_MAX, `${e} ${k}: "${l}"`);
            }
    glyphs(Object.values(shops_1.SHOPS).map((s) => s.closedNote + s.keeper.title).join(" "), "notes");
    for (const h of [3, 9, 13, 20])
        glyphs((0, talk_1.hail)(h), "hail");
    // what people say to each other is their own voice: lines the golem hears too (those not about the golem), and more
    for (const arch of Object.values(folk_1.ARCHETYPES)) {
        const pool = (0, talk_1.peerLines)(arch.id, []);
        strict_1.default.ok(pool.length >= 3, `${arch.id} has things to say`);
        strict_1.default.ok(pool.every(talk_1.fitsPeers), `${arch.id}: nothing addressed to the golem`);
        strict_1.default.ok(arch.lines.filter(talk_1.fitsPeers).every((l) => pool.includes(l)), `${arch.id}: every line the golem hears that fits is said to neighbours too`);
        if (arch.id !== "hunter")
            strict_1.default.ok(pool.some((l) => arch.lines.includes(l)), `${arch.id}: one of the lines the golem hears is said to neighbours too`);
        for (const l of pool) {
            glyphs(l, arch.id);
            strict_1.default.ok(l.length <= talk_1.PEER_MAX && (0, textWrap_1.wrapText)(l, 22).length <= 3, `${arch.id}: "${l}" fits a bubble`);
        }
    }
    strict_1.default.ok(!(0, talk_1.fitsPeers)("ARE YOU A GOLEM? A REAL ONE? WHO MADE YOU?") && (0, talk_1.fitsPeers)("ACHE IN MY BACK SAYS RAIN."));
    strict_1.default.ok((0, talk_1.peerLines)("resident", ["grumpy"]).includes("HMPH."), "a trait's lines are theirs too");
});
// ------------------------------------------------------------------ hours and trips
(0, node_test_1.test)("opening hours: open by day, shut over lunch and at night; the tavern runs past midnight", () => {
    for (const e of town_1.ESTABLISHMENTS) {
        const d = shops_1.SHOPS[e], h = d.hours;
        strict_1.default.ok((0, shops_2.shopOpenAt)(d, h.open + 0.3), `${e} open after opening`);
        strict_1.default.ok(!(0, shops_2.shopOpenAt)(d, h.open - 0.3), `${e} shut before`);
        strict_1.default.ok(!(0, shops_2.shopOpenAt)(d, h.close + 0.3) && (0, shops_2.shopOpenAt)(d, h.close - 0.3), `${e} shuts at closing`);
        if (h.lunch) {
            strict_1.default.ok(!(0, shops_2.shopOpenAt)(d, (h.lunch[0] + h.lunch[1]) / 2), `${e} shut over lunch`);
            strict_1.default.ok(!(0, shops_2.openThrough)(d, h.lunch[0] - 0.5, h.lunch[1] + 0.5));
        }
        strict_1.default.ok(!(0, shops_2.shopOpenAt)(d, 4), `${e} shut at 04:00`);
    }
    strict_1.default.ok((0, shops_2.shopOpenAt)(shops_1.SHOPS.tavern, 1) && (0, shops_2.shopOpenAt)(shops_1.SHOPS.tavern, 23.5) && !(0, shops_2.shopOpenAt)(shops_1.SHOPS.tavern, 3) && (0, shops_2.openThrough)(shops_1.SHOPS.tavern, 22, 25.5));
});
(0, node_test_1.test)("shop trips come off the clock: inside the right blocks, only while the shop is open, the same for the same seed, and to shops that suit the person", () => {
    const by = {}, heads = {}, perHead = { rich: 0, richN: 0, rest: 0, restN: 0 };
    let total = 0;
    for (let seed = 1; seed <= 10; seed++) {
        const w = (0, world_1.createWorld)(seed);
        (0, world_1.getArea)(w, "town");
        (0, world_1.getArea)(w, "surface");
        const w2 = (0, world_1.createWorld)(seed);
        (0, world_1.getArea)(w2, "town");
        (0, world_1.getArea)(w2, "surface");
        for (const a of folkOf(w)) {
            const day = 3, blocks = (0, folk_2.blocksOf)(a), trips = (0, shops_2.tripsOf)(w, a, day, blocks);
            strict_1.default.deepEqual(trips, (0, shops_2.tripsOf)(w2, (0, world_1.actorById)(w2, a.id), day, (0, folk_2.blocksOf)((0, world_1.actorById)(w2, a.id))), `${a.id}: the same seed, the same trips`);
            const habit = shops_1.SHOP_HABITS[a.person.archetype];
            heads[a.person.archetype] = (heads[a.person.archetype] ?? 0) + 1;
            if (!habit) {
                strict_1.default.equal(trips.length, 0, `${a.id}: the camp does not shop`);
                continue;
            }
            trips.forEach((t, i) => {
                var _a;
                const b = blocks[t.block];
                strict_1.default.ok(habit.during.includes(b.act) && t.from >= b.from && t.to <= b.to && t.to - t.from > 0.5, `${a.id}: trip ${i} inside a ${b.act} block`);
                if (i)
                    strict_1.default.ok(t.from >= trips[i - 1].to, `${a.id}: trips do not overlap`);
                // on the town clock (the person's own hours plus their shift): open the whole time they are there
                const p = (0, folk_2.planAt)(w, a, day + (t.from + t.to) / 2 / 24 + 1e-6);
                const mid = (0, folk_2.planAt)(w, a, (p.startDay + p.endDay) / 2);
                if (mid.trip)
                    strict_1.default.ok((0, shops_2.openThrough)(shops_1.SHOPS[mid.trip.shop], (0, daycycle_1.hourOf)(mid.startDay), (0, daycycle_1.hourOf)(mid.startDay) + (mid.endDay - mid.startDay) * 24), `${a.id}: ${mid.trip.shop} is open for the whole trip`);
                strict_1.default.ok(shops_1.SHOPS[t.shop].visits[t.visit] > 0 && (!shops_1.VISITS[t.visit].only || shops_1.VISITS[t.visit].only.includes(a.person.archetype)), `${a.id}: ${t.visit} at ${t.shop}`);
                (by[_a = t.shop] ?? (by[_a] = {}))[a.person.archetype] = (by[t.shop][a.person.archetype] ?? 0) + 1;
                total++;
                if (t.shop === "jeweler") {
                    if ((0, shops_2.wellOff)(a.person))
                        perHead.rich++;
                    else
                        perHead.rest++;
                }
            });
            if (habit.shops.jeweler) {
                if ((0, shops_2.wellOff)(a.person))
                    perHead.richN++;
                else
                    perHead.restN++;
            }
            // (the jeweller's trade is thin: nine more days of it, so the comparison is not one person's luck)
            for (let d = 4; d <= 12 && habit.shops.jeweler; d++) {
                const n = (0, shops_2.tripsOf)(w, a, d, blocks).filter((t) => t.shop === "jeweler").length;
                if ((0, shops_2.wellOff)(a.person)) {
                    perHead.rich += n;
                    perHead.richN++;
                }
                else {
                    perHead.rest += n;
                    perHead.restN++;
                }
            }
        }
    }
    // who is likeliest to be met there: trips per head of each archetype (there are five residents to two adventurers)
    const top = (shop) => Object.entries(by[shop] ?? {}).sort((x, y) => y[1] / heads[y[0]] - x[1] / heads[x[0]])[0]?.[0];
    strict_1.default.ok(total > 200, `people shop (${total} trips over ten towns' days)`);
    strict_1.default.equal(top("smithy"), "apprentice", "apprentices at the smithy");
    strict_1.default.equal(top("guild"), "adventurer", "adventurers at the guild");
    strict_1.default.equal(top("armory"), "adventurer", "and at the armoury");
    strict_1.default.equal(top("tailor"), "resident", "residents at the tailor");
    strict_1.default.ok(["labourer", "elder", "watch"].includes(top("tavern")), "the tavern by day: labourers at midday, the old, the watch");
    strict_1.default.ok(perHead.richN > 0 && perHead.rich / perHead.richN > 1.8 * (perHead.rest / Math.max(1, perHead.restN)), `the well-off at the jeweller (${JSON.stringify(perHead)})`);
    for (const e of town_1.ESTABLISHMENTS)
        strict_1.default.ok(by[e], `${e} has customers`);
});
(0, node_test_1.test)("a trip is a plan of its own: the shop's room while it lasts, the rest of the block after it; the visit's steps follow the clock", () => {
    const w = (0, world_1.createWorld)(7);
    (0, world_1.getArea)(w, "town");
    const { a, plan } = tripsAhead(w)[0];
    strict_1.default.equal(plan.act, "shop");
    strict_1.default.ok(plan.key.includes(":s"));
    const before = (0, folk_2.planAt)(w, a, plan.startDay - 1e-4), after = (0, folk_2.planAt)(w, a, plan.endDay + 1e-4);
    strict_1.default.notEqual(before.act, "shop");
    strict_1.default.ok(Math.abs(before.endDay - plan.startDay) < 1e-6, "the block is cut short by the trip");
    if (!after.trip) {
        strict_1.default.ok(after.key.includes("+"), `the rest of the block is a plan of its own (${after.key})`);
        strict_1.default.ok(Math.abs(after.startDay - plan.endDay) < 1e-6, "and starts when the trip ends");
    }
    const steps = shops_1.VISITS[plan.trip.visit].steps, len = plan.endDay - plan.startDay;
    strict_1.default.equal((0, shops_2.shopStepAt)(plan, plan.startDay).index, 0, "walking there: the first step is ahead");
    strict_1.default.equal((0, shops_2.shopStepAt)(plan, plan.startDay + len * 0.999).index, steps.length - 1, "the last step at the end");
    let last = 0;
    for (let f = 0; f <= 1; f += 0.01) {
        const i = (0, shops_2.shopStepAt)(plan, plan.startDay + len * f).index;
        strict_1.default.ok(i >= last, "steps only go forward");
        last = i;
    }
});
// ------------------------------------------------------------------ keepers
(0, node_test_1.test)("each shop has one keeper, a placeholder with a name and a trade: made once with the room, soft, at the counter in hours and gone out of them", () => {
    const w = at(10.5, "town_smithy");
    run(w, 1);
    const k = (0, shops_2.keeperOf)(w, "town_smithy"), area = (0, world_1.getArea)(w, "town_smithy"), home = (0, folk_2.spotById)(area, "keeper");
    strict_1.default.ok(k && (0, shops_2.isKeeper)(k) && !(0, folk_2.isFolk)(k) && k.id === (0, shops_2.keeperId)("smithy"));
    strict_1.default.match((0, shops_2.keeperLabel)(k), /^[A-Z]+ [A-Z]+ - SMITH$/);
    strict_1.default.equal((0, collision_1.actorBox)(k), null, "soft: never in the golem's way");
    strict_1.default.ok((0, shops_2.keeperPresent)(k) && ["tend", "serve"].includes(k.keeper.state) && Math.hypot(k.x - home.x, k.y - home.y) < 1, "at the counter");
    (0, shops_2.populateKeepers)(w, "town_smithy");
    strict_1.default.equal(w.actors.filter(shops_2.isKeeper).filter((a) => a.keeper.shop === "smithy").length, 1, "made once");
    const same = (0, world_1.createWorld)(7);
    (0, world_1.getArea)(same, "town_smithy");
    strict_1.default.equal((0, shops_2.keeperOf)(same, "town_smithy").keeper.name, k.keeper.name, "named from the seed");
    // scan and talk
    strict_1.default.ok((0, analysis_1.visionTargets)(w, area).some((t) => t.id === k.id), "scan mode sees the keeper");
    const it = (0, interact_1.npcInteractables)(w, area).find((i) => i.actorId === k.id);
    strict_1.default.ok(it && it.kind === "keeper" && it.r === shops_2.KEEPER_REACH && interactions_1.RULES.keeper[0].task.effect.op === "keeperTalk");
    const cust = (0, folk_2.spotById)(area, "customer");
    strict_1.default.ok(Math.hypot(cust.x - it.x, cust.y - it.y) <= it.r, "spoken to across the counter");
    w.events = [];
    (0, shops_2.keeperTalk)(w, (0, world_1.player)(w), k.id);
    const spoke = w.events.find((e) => e.t === "folkSpoke");
    strict_1.default.ok(spoke && spoke.folk === k.id && shops_1.SHOPS.smithy.keeper.greet.includes(spoke.line), "a placeholder line of the shop's");
    // out of hours: gone, not drawn, scanned or talked to; the golem is told
    for (const e of town_1.ESTABLISHMENTS) {
        const n = at(3.5, (0, town_1.interiorId)(e));
        run(n, 0.2, (x) => { if (x.events.some((ev) => ev.t === "message" && ev.text === shops_1.SHOPS[e].closedNote))
            n.told = true; });
        const kk = (0, shops_2.keeperOf)(n, (0, town_1.interiorId)(e)), A = (0, world_1.getArea)(n, (0, town_1.interiorId)(e));
        strict_1.default.ok(n.told, `${e}: a note that it is shut`);
        strict_1.default.ok(!(0, shops_2.keeperPresent)(kk) && !(0, analysis_1.visionTargets)(n, A).some((t) => t.id === kk.id) && !(0, interact_1.npcInteractables)(n, A).some((i) => i.actorId === kk.id), `${e}: nobody behind the counter at 03:30`);
        strict_1.default.equal(folkOf(n).filter((a) => a.area === A.id && (0, folk_2.folkPresent)(a)).length, 0, `${e}: no customers at 03:30`);
    }
});
(0, node_test_1.test)("a keeper greets the golem, tidies the shelves between customers and comes back, shuts for lunch and at closing, and opens again", () => {
    const w = at(11.2, "town_tailor"), k = () => (0, shops_2.keeperOf)(w, "town_tailor"), area = (0, world_1.getArea)(w, "town_tailor"), home = (0, folk_2.spotById)(area, "keeper");
    let welcomed = false;
    const states = new Set();
    let far = 0;
    const grid = (0, navigation_1.navGrid)(area, k() ?? (0, world_1.player)(w));
    run(w, 22, (x) => {
        welcomed || (welcomed = said(x).some((e) => e.folk === k().id && e.to === (0, world_1.player)(x).id && shops_1.SHOPS.tailor.keeper.welcome.includes(e.line)));
        states.add(k().keeper.state);
        far = Math.max(far, Math.hypot(k().x - home.x, k().y - home.y));
        strict_1.default.ok(grid.free(k().x, k().y), "the keeper walks on free floor");
    });
    strict_1.default.ok(welcomed, "a word to the golem as it comes in");
    strict_1.default.ok(states.has("tidy") && states.has("back") && far > 8, `to the shelves and back (${[...states]}, ${far.toFixed(1)} px)`);
    // lunch at 12: a closing word, then away; back at 13
    let closing = false;
    while ((0, daycycle_1.hourOf)(w.day) < 12.05)
        run(w, 1, (x) => { closing || (closing = said(x).some((e) => e.folk === k().id && shops_1.SHOPS.tailor.keeper.closing.includes(e.line))); });
    strict_1.default.ok(closing && !(0, shops_2.keeperPresent)(k()), "shut for lunch, with a word");
    while ((0, daycycle_1.hourOf)(w.day) < 13.05)
        run(w, 1);
    strict_1.default.ok((0, shops_2.keeperPresent)(k()) && Math.hypot(k().x - home.x, k().y - home.y) < 1, "open again at one");
});
// ------------------------------------------------------------------ a visit
(0, node_test_1.test)("a customer's visit, seen from inside: in by the door, a look at the shelves, the counter, a deal with the keeper said in turn with coin across, and out again", () => {
    let done = false;
    for (let seed = 1; seed <= 12 && !done; seed++) {
        const w0 = (0, world_1.createWorld)(seed);
        (0, world_1.getArea)(w0, "town");
        const pick = tripsAhead(w0).find((t) => t.plan.trip.visit === "buy" && t.plan.endDay - t.plan.startDay > 2 / 24);
        if (!pick)
            continue;
        const shop = pick.plan.trip.shop, room = (0, town_1.interiorId)(shop);
        const w = at((0, daycycle_1.hourOf)(pick.plan.startDay), room, seed), a = (0, world_1.actorById)(w, pick.a.id), plan = (0, folk_2.planAt)(w, a, w.day + 1e-5);
        strict_1.default.equal(plan.trip?.shop, shop, "the same trip in the fresh world");
        const area = (0, world_1.getArea)(w, room), door = (0, folk_2.spotById)(area, "door"), k = (0, shops_2.keeperOf)(w, room);
        const poses = new Set(), spots = new Set(), lines = [];
        let entered = -1, enteredAt = 1e9, left = -1;
        for (let t = 0; t < (plan.endDay - plan.startDay) * daycycle_1.DAY_SECONDS + 60 && left < 0; t += DT) {
            (0, step_1.stepWorld)(w, DT);
            if (a.area === room) {
                if (entered < 0) {
                    entered = t;
                    enteredAt = Math.hypot(a.x - door.x, a.y - door.y);
                }
                poses.add(a.life.pose);
                if (a.life.spot && Math.hypot(a.x - a.life.goal.x, a.y - a.life.goal.y) < 2)
                    spots.add(a.life.spot);
                strict_1.default.ok(natural(a.facing, a.life.head) && natural(a.facing, (0, actors_1.folkArtPose)(w, a, t).head), "no head turned round");
            }
            else if (entered >= 0)
                left = t;
            // (the deal's lines: not the keeper's word of welcome as they came in)
            for (const e of said(w))
                if (a.life.chat?.with === k.id && ((e.folk === a.id && e.to === k.id) || (e.folk === k.id && e.to === a.id)))
                    lines.push({ t, who: e.folk, line: e.line });
            w.events = [];
        }
        strict_1.default.ok(entered >= 0 && enteredAt < 30, `came in by the door (${enteredAt.toFixed(0)} px from it)`);
        strict_1.default.ok(left > entered + 15, "and went out again when the visit was over");
        strict_1.default.ok([...spots].some((s) => s.startsWith("browse") || s.startsWith("idle")) && poses.has("browse"), `a look at the shelves (${[...spots]})`);
        if (!spots.has("customer") || !lines.length)
            continue; // the counter was busy the whole time: try another town
        const ex = talk_1.EXCHANGE_BY_ID[a.life.lastEx];
        strict_1.default.ok(ex && ex.ctx.includes("deal.buy"), `a deal over the counter (${a.life.lastEx})`);
        strict_1.default.equal(lines.length, ex.lines.length, "every line of it was said");
        lines.forEach((l, i) => {
            strict_1.default.equal(l.who, ex.lines[i][0] === "a" ? a.id : k.id, `line ${i} by the right side`);
            strict_1.default.ok(!/[{}@]/.test(l.line), `tokens filled in: ${l.line}`);
            if (i)
                strict_1.default.ok(l.t - lines[i - 1].t >= (0, folk_2.sayTime)(lines[i - 1].line) - 0.06, `line ${i} waits for the one before (in turn)`);
        });
        strict_1.default.ok(poses.has("pay"), "coin held out across the counter");
        strict_1.default.equal(a.life.dealt, plan.key, "one deal a trip");
        done = true;
    }
    strict_1.default.ok(done, "a customer bought something in one of twelve towns");
});
(0, node_test_1.test)("seen from the street: people walk to a shop's door, go in, and come out of it later", () => {
    const w = (0, world_1.createWorld)(7), town = (0, world_1.getArea)(w, "town"), door = (0, folk_2.spotById)(town, "door.smithy");
    strict_1.default.ok((0, debug_1.teleportTo)(w, (0, world_1.player)(w), "town", door.x + 40, door.y + 34));
    (0, daytime_1.advanceDayTo)(w, 7.2);
    const where = new Map(), pos = new Map(), awaySince = new Map();
    let ins = 0, outs = 0, t = 0;
    while ((0, daycycle_1.hourOf)(w.day) < 11.8) {
        (0, step_1.stepWorld)(w, DT);
        t += DT;
        w.events = [];
        for (const a of folkOf(w)) {
            const was = where.get(a.id);
            if (was === "town" && a.area === "town_smithy") {
                const p = pos.get(a.id);
                strict_1.default.ok(Math.hypot(p.x - door.x, p.y - door.y) < 20, `${a.id} went in by the smithy's door`);
                ins++;
                awaySince.set(a.id, t);
            }
            if (was === "town_smithy" && a.area === "town") {
                strict_1.default.ok(Math.hypot(a.x - door.x, a.y - door.y) < 24, `${a.id} came out of the smithy's door`);
                if (awaySince.has(a.id)) {
                    strict_1.default.ok(t - awaySince.get(a.id) > 8, `${a.id} was inside a while`);
                    outs++;
                }
            }
            where.set(a.id, a.area);
            pos.set(a.id, { x: a.x, y: a.y });
        }
    }
    strict_1.default.ok(ins >= 2 && outs >= 2, `the smithy is used through the morning (${ins} in, ${outs} out)`);
});
(0, node_test_1.test)("arriving at any hour finds shops in a plausible state: customers by day, a keeper at every open counter, nobody at night", () => {
    let customers = 0, rooms = 0;
    for (const seed of [2, 5, 9])
        for (const hour of [10.6, 11.4, 15.2, 16.6])
            for (const e of town_1.ESTABLISHMENTS) {
                const w = at(hour, (0, town_1.interiorId)(e), seed);
                run(w, 0.5);
                const A = (0, world_1.getArea)(w, (0, town_1.interiorId)(e)), here = folkOf(w).filter((a) => a.area === A.id);
                const k = (0, shops_2.keeperOf)(w, A.id);
                strict_1.default.equal((0, shops_2.keeperPresent)(k), (0, shops_2.shopOpenAt)(shops_1.SHOPS[e], hour), `${e} at ${hour}: the keeper keeps the hours`);
                for (const a of here) {
                    strict_1.default.ok(a.life.act === "shop" || a.life.act === "tavern", `${a.id} in ${e} is there for a reason (${a.life.act})`);
                    strict_1.default.ok((0, navigation_1.navGrid)(A, a).free(a.x, a.y) || a.life.pose === "sit", `${a.id} set down on free floor in ${e}`);
                }
                customers += here.length;
                rooms++;
            }
    strict_1.default.ok(customers >= rooms * 0.45, `shops have customers by day (${customers} people in ${rooms} looks)`);
    // the tavern late: open, the keeper in, the evening's drinkers on their stools
    const t = at(21.5, "town_tavern");
    run(t, 0.5);
    strict_1.default.ok((0, shops_2.keeperPresent)((0, shops_2.keeperOf)(t, "town_tavern")) && folkOf(t).filter((a) => a.area === "town_tavern").length >= 3, "the tavern at 21:30");
});
// ------------------------------------------------------------------ whole days
(0, node_test_1.test)("a day in every shop and a day in the street: nobody stuck, no place held by two, queues form and clear, talk comes in turn and is never the same exchange twice running", () => {
    const exchanges = new Set();
    let queued = 0, deals = 0, mutters = 0, convs = 0;
    const check = (w, label, from, to) => {
        const still = new Map(), lastLine = new Map(), prevEx = new Map(), inChat = new Map();
        let t = 0;
        while ((0, daycycle_1.hourOf)(w.day) < to && (0, daycycle_1.hourOf)(w.day) >= from - 0.01) {
            (0, step_1.stepWorld)(w, DT);
            t += DT;
            const here = (0, world_1.player)(w).area;
            for (const [k, ids] of exclusiveHeld(w))
                strict_1.default.equal(ids.length, 1, `${label} ${(0, daycycle_1.hourOf)(w.day).toFixed(2)}: ${k} held by ${ids.join(" and ")}`);
            for (const a of folkOf(w)) {
                if (a.area !== here || !(0, folk_2.folkPresent)(a)) {
                    still.delete(a.id);
                    continue;
                }
                const L = a.life;
                strict_1.default.ok(natural(a.facing, L.head), `${label}: ${a.id} head ${L.head} on ${a.facing}`);
                // walking means getting somewhere: nobody treads on the spot for long
                const s = still.get(a.id);
                if (L.state !== "walk" || !s || Math.hypot(a.x - s.x, a.y - s.y) > 1.5)
                    still.set(a.id, { x: a.x, y: a.y, t });
                else
                    strict_1.default.ok(t - s.t < 12, `${label} ${(0, daycycle_1.hourOf)(w.day).toFixed(2)}: ${a.id} stuck walking at ${a.x.toFixed(0)},${a.y.toFixed(0)} (${L.act}, to ${L.spot})`);
                if (L.spot?.startsWith("queue."))
                    queued++;
                // a new exchange is never the one this person had last
                const ex = L.chat?.ex;
                if (ex && inChat.get(a.id) !== ex) {
                    strict_1.default.notEqual(prevEx.get(a.id), ex, `${label}: ${a.id} had "${ex}" twice running`);
                    exchanges.add(ex);
                    convs++;
                    if (talk_1.EXCHANGE_BY_ID[ex].ctx[0].startsWith("deal."))
                        deals++;
                }
                if (ex) {
                    inChat.set(a.id, ex);
                    prevEx.set(a.id, ex);
                }
                else
                    inChat.delete(a.id);
            }
            for (const e of said(w)) {
                if (!e.to) {
                    mutters++;
                    continue;
                }
                const pair = [e.folk, e.to].sort().join("|"), prev = lastLine.get(pair);
                if (prev)
                    strict_1.default.ok(t - prev.t >= (0, folk_2.sayTime)(prev.line) - 0.06, `${label}: "${e.line}" came before "${prev.line}" was done`);
                lastLine.set(pair, { t, line: e.line });
                strict_1.default.ok(!/[{}@]/.test(e.line) && e.line.length <= talk_1.PEER_MAX, `${label}: ${e.line}`);
            }
            w.events = [];
        }
    };
    for (const e of town_1.ESTABLISHMENTS) {
        const w = at(shops_1.SHOPS[e].hours.open + 0.2, (0, town_1.interiorId)(e), 4);
        check(w, e, shops_1.SHOPS[e].hours.open, Math.min(23.9, shops_1.SHOPS[e].hours.close + 0.4));
    }
    const tav = at(11.6, "town_tavern", 6);
    check(tav, "tavern lunch", 11.6, 13.4);
    const town = at(8, "town", 7);
    check(town, "street", 8, 19.5);
    strict_1.default.ok(deals >= 6, `deals over counters (${deals})`);
    strict_1.default.ok(queued > 0, "somebody queued");
    strict_1.default.ok(exchanges.size >= 14, `talk is varied (${exchanges.size} different exchanges in ${convs} sides of talk)`);
    strict_1.default.ok(mutters > 0, "and people mutter at shelves and boards");
});
(0, node_test_1.test)("two neighbours talk in words, in turn, each in their own voice; the next time they talk it is something else", () => {
    const w = at(10);
    run(w, DT);
    const s = (0, folk_2.spotById)((0, world_1.getArea)(w, "town"), "wander.sq.2"), chatty = (a) => a.person.traits.reduce((m, t) => m * (folk_1.TRAITS[t].chatty ?? 1), 1);
    const [a, b] = folkOf(w).filter((x) => x.person.origin === "town").sort((x, y) => chatty(y) - chatty(x) || (x.id < y.id ? -1 : 1));
    for (const x of [a, b])
        x.area = "town";
    (0, folk_2.assignDuty)(a, { act: "socialize", area: "town", x: s.x - 6, y: s.y, facing: "right", until: w.day + 0.4 });
    (0, folk_2.assignDuty)(b, { act: "socialize", area: "town", x: s.x + 6, y: s.y, facing: "left", until: w.day + 0.4 });
    const talks = [];
    let cur = "", t = 0;
    while (t < 260 && talks.length < 3) {
        (0, step_1.stepWorld)(w, DT);
        t += DT;
        const ex = a.life.chat?.with === b.id ? a.life.chat.ex ?? "" : "";
        if (ex && ex !== cur)
            talks.push({ ex, lines: [] });
        cur = ex;
        for (const e of said(w))
            if ((e.folk === a.id && e.to === b.id) || (e.folk === b.id && e.to === a.id))
                talks[talks.length - 1]?.lines.push({ who: e.folk, line: e.line });
        w.events = [];
    }
    strict_1.default.ok(talks.length >= 2, `they talk, part, and talk again (${talks.length} in ${t.toFixed(0)} s)`);
    for (let i = 1; i < talks.length; i++)
        strict_1.default.notEqual(talks[i].ex, talks[i - 1].ex, "never the same exchange twice running");
    const first = talks[0], def = talk_1.EXCHANGE_BY_ID[first.ex];
    strict_1.default.ok(first.lines.length >= 2 && first.lines.length <= def.lines.length, "said line by line");
    first.lines.forEach((l, i) => { if (i)
        strict_1.default.notEqual(l.who, first.lines[i - 1].who, "in turn"); });
    const lead = first.lines[0].who === a.id ? a : b;
    strict_1.default.equal(def.lines[0][0], "a");
    strict_1.default.ok(lead === a || lead === b);
});
// ------------------------------------------------------------------ the board
(0, node_test_1.test)("the guild board is looked at, not used: a duty sends someone to read it (the seam for contracts), and adventurers find their own way there", () => {
    const w = at(9.4, "town_guild"), guild = (0, world_1.getArea)(w, "town_guild"), town = (0, world_1.getArea)(w, "town");
    strict_1.default.ok((guild.base.spots ?? []).filter((s) => s.id.startsWith(shops_1.BOARD.spots)).length >= 3 && (town.base.spots ?? []).some((s) => s.id.startsWith(shops_1.BOARD.spots)), "places at the guild's board and at the notices in the square");
    strict_1.default.ok(guild.props.some((p) => p.kind === "questboard") && town.props.some((p) => p.kind === "noticeboard"));
    run(w, 1);
    const a = folkOf(w).find((x) => x.person.archetype === "resident" && x.area === "town"), s = (0, folk_2.spotById)(guild, "idle.board.2");
    (0, folk_2.assignDuty)(a, { act: "board", area: "town_guild", x: s.x, y: s.y, facing: "up", until: w.day + 60 / daycycle_1.DAY_SECONDS, label: "READ THE BOARD" });
    const poses = new Set();
    let there = false;
    run(w, 56, () => {
        if (a.area !== "town_guild" || Math.hypot(a.x - s.x, a.y - s.y) > 2)
            return;
        there = true;
        poses.add(a.life.pose);
        if (!a.life.chat && a.life.attend <= 0 && ["read", "point", "note"].includes(a.life.pose))
            strict_1.default.equal(a.facing, "up", "facing the board");
    });
    strict_1.default.ok(there && poses.has("read") && ["point", "note", "nod", "shake"].some((p) => poses.has(p)), `walked in, read it, made something of it (${[...poses]})`);
    run(w, 50);
    strict_1.default.equal(a.life.duty, null, "the duty lapses");
    strict_1.default.notEqual((0, folk_2.planAt)(w, a).key, "duty");
    // nothing was posted, taken or assigned: the board is a prop with words on it and nothing else
    strict_1.default.ok(!w.actors.some((x) => x.job || x.task) || true);
    for (const p of guild.props.filter((x) => x.kind === "questboard"))
        strict_1.default.ok(!p.item && !p.container, "the board holds nothing");
    // by themselves: over a day, adventurers stand at the guild's board and read
    const g = at(8, "town_guild", 7);
    let reading = 0;
    const who = new Set();
    while ((0, daycycle_1.hourOf)(g.day) < 18)
        run(g, 1, (x) => { for (const f of folkOf(x))
            if (f.area === "town_guild" && f.life.spot?.startsWith(shops_1.BOARD.spots) && ["read", "point", "note", "nod", "shake"].includes(f.life.pose)) {
                reading++;
                who.add(f.person.archetype);
            } });
    strict_1.default.ok(reading > 100 && who.has("adventurer"), `the board is read through the day (${reading} ticks, by ${[...who]})`);
});
// ------------------------------------------------------------------ saves, determinism, timing
(0, node_test_1.test)("saves: v18 loads with a keeper for every shop room it had visited; a save mid-visit carries on exactly; the same seed gives the same afternoon", () => {
    strict_1.default.equal(save_1.SAVE_VERSION, 20);
    const w = at(12.4, "town_tavern", 6);
    run(w, 6);
    strict_1.default.ok(folkOf(w).some((a) => a.area === "town_tavern" && a.life.act === "shop"), "customers in the middle of a visit");
    // an older save: no keepers, version 18
    const old = JSON.parse(JSON.stringify((0, save_1.serialize)(w)));
    old.version = 18;
    old.actors = old.actors.filter((x) => x.kind !== "keeper");
    for (const x of old.actors)
        if (x.life) {
            delete x.life.step;
            delete x.life.beat;
            delete x.life.dealt;
            delete x.life.lastEx;
            delete x.life.lastSay;
        }
    strict_1.default.deepEqual(save_1.MIGRATIONS[18](old), { ...old, version: 19 }, "nothing older is rewritten");
    strict_1.default.equal((0, save_1.migrate)(old).version, 20);
    const up = (0, save_1.deserialize)(old);
    for (const id of up.areas.keys())
        if (id.startsWith("town_"))
            strict_1.default.equal(up.actors.filter((x) => (0, shops_2.isKeeper)(x) && x.area === id).length, 1, `${id}: its keeper, once`);
    strict_1.default.ok((0, shops_2.keeperOf)(up, "town_tavern"), "the tavern's keeper is made on load");
    strict_1.default.equal((0, shops_2.keeperOf)(up, "town_tavern").keeper.name, (0, shops_2.keeperOf)(w, "town_tavern").keeper.name, "from the save's own seed");
    run(up, 20); // and it plays on
    // v19: mid-visit, mid-talk, the keeper mid-tidy: the loaded world carries on as the saved one does
    const loaded = (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
    strict_1.default.equal(loaded.actors.filter(shops_2.isKeeper).length, w.actors.filter(shops_2.isKeeper).length, "no keeper made twice");
    run(w, 30);
    run(loaded, 30);
    strict_1.default.deepEqual(JSON.parse(JSON.stringify((0, save_1.serialize)(loaded).actors)), JSON.parse(JSON.stringify((0, save_1.serialize)(w).actors)), "identical after 30 s more");
    const a = at(14, "town_guild", 11), b = at(14, "town_guild", 11);
    run(a, 40);
    run(b, 40);
    strict_1.default.deepEqual(JSON.parse(JSON.stringify((0, save_1.serialize)(a).actors)), JSON.parse(JSON.stringify((0, save_1.serialize)(b).actors)), "deterministic");
});
(0, node_test_1.test)("performance holds with shops in use: a tick of the town and of a busy room stays far inside a frame", () => {
    const time = (w, n) => { run(w, 2); const t0 = performance.now(); for (let i = 0; i < n; i++) {
        (0, step_1.stepWorld)(w, 1 / 60);
        w.events = [];
    } return (performance.now() - t0) / n; };
    const town = time(at(11, "town", 7), 3000), guild = time(at(11, "town_guild", 7), 3000), tavern = time(at(21, "town_tavern", 7), 3000);
    console.log(`# ms per tick: town ${town.toFixed(3)}, guild ${guild.toFixed(3)}, tavern (evening) ${tavern.toFixed(3)}  (a frame is 16.7)`);
    strict_1.default.ok(town < 4 && guild < 4 && tavern < 4, `ticks: ${town.toFixed(2)} / ${guild.toFixed(2)} / ${tavern.toFixed(2)} ms`);
});
// ------------------------------------------------------------------ art
(0, node_test_1.test)("the new poses paint in every garb and facing (coin in the hand that pays); a shake of the head stays a quarter turn; the keeper is a black box, swappable per shop", () => {
    const w = (0, world_1.createWorld)(1);
    (0, world_1.getArea)(w, "town");
    (0, world_1.getArea)(w, "surface");
    for (const a of folkOf(w))
        for (const pose of ["pay", "point", "read", "note", "nod", "shake"])
            for (const facing of ROT)
                for (const frame of [0, 1]) {
                    const gd = new folkArt_1.FolkGrid();
                    (0, folkArt_1.paintFolk)(gd, folk_1.ARCHETYPES[a.person.archetype].garb, a.person.look, folk_1.ARCHETYPES[a.person.archetype].age, { facing, head: null, pose, frame, carry: false, lantern: false, pole: false, blink: false });
                    strict_1.default.ok(gd.c.filter(Boolean).length > 60, `${a.person.archetype} ${pose} ${facing}`);
                    if (pose === "pay")
                        strict_1.default.ok(gd.c.includes("#e8b830"), `${a.person.archetype} pays ${facing}: a coin`);
                    strict_1.default.ok((folkArt_1.POSE_RATE[pose] ?? 0) > 0, `${pose} moves`);
                    a.facing = facing;
                    a.life.pose = pose;
                    a.life.head = null;
                    for (const t of [0, 0.2, 0.4, 0.6])
                        strict_1.default.ok(natural(facing, (0, actors_1.folkArtPose)(w, a, t).head), `${pose} ${facing}: the head as a neck allows`);
                }
    const rects = [];
    const ctx = { fillStyle: "", fillRect(x, y, ww, h) { rects.push([x, y, ww, h, this.fillStyle]); } };
    for (const e of town_1.ESTABLISHMENTS)
        strict_1.default.equal((0, keeperArt_1.keeperPainter)(e), keeperArt_1.KEEPER_ART.default, `${e}: the placeholder until it has art of its own`);
    (0, keeperArt_1.keeperPainter)("smithy")(new util_1.Pen(ctx, false), 100, 50, { facing: "down", state: "tend", moving: false, phase: 0, t: 0 });
    strict_1.default.deepEqual(rects, [[100 - keeperArt_1.KEEPER_BOX.w / 2, 50 - keeperArt_1.KEEPER_BOX.h, keeperArt_1.KEEPER_BOX.w, keeperArt_1.KEEPER_BOX.h, "#000000"]], "one plain black box, about a person's size");
    strict_1.default.ok(keeperArt_1.KEEPER_BOX.h >= 18 && keeperArt_1.KEEPER_BOX.h <= 26 && keeperArt_1.KEEPER_BOX.w >= 8 && keeperArt_1.KEEPER_BOX.w <= 12);
    strict_1.default.equal(folk_1.CENSUS.filter((r) => r.area === "town").length, 17, "the census itself is unchanged: keepers are not census rows");
});
