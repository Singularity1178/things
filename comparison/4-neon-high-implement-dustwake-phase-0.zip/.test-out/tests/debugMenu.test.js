"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The Ctrl+0 debug menu: the pure sim functions it calls (summon, delete, flags,
// places, teleport, kits, noclip), the screen's keys on a headless host, a text
// lint of every tab, and the real Game opening and closing it.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const g0 = globalThis;
g0.localStorage ?? (g0.localStorage = { getItem: () => null, setItem: () => { }, removeItem: () => { } });
const game_1 = require("../src/game/game");
const debug_1 = require("../src/game/screens/debug");
const items_1 = require("../src/game/content/items");
const flags_1 = require("../src/game/content/flags");
const runes_1 = require("../src/game/content/runes");
const tiles_1 = require("../src/game/content/tiles");
const world_1 = require("../src/game/world/world");
const inventory_1 = require("../src/game/sim/inventory");
const gear_1 = require("../src/game/sim/gear");
const collision_1 = require("../src/game/sim/collision");
const step_1 = require("../src/game/sim/step");
const debug_2 = require("../src/game/sim/debug");
const helpers_1 = require("./helpers");
const screenHost_1 = require("./support/screenHost");
const looseCount = (w, id) => (0, world_1.currentArea)(w).loose.filter((l) => !l.taken && l.item === id).reduce((n, l) => n + (l.n ?? 1), 0);
// ---------------------------------------------------------------- sim
(0, node_test_1.test)("every item can be summoned (the arm installs, the rest land in the pack)", () => {
    for (const id of items_1.ITEM_IDS) {
        const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), eq = items_1.ITEMS[id].equip;
        const r = (0, debug_2.summonItem)(w, pl, id, 1);
        strict_1.default.ok(r.ok, id);
        if (eq)
            strict_1.default.ok((0, world_1.hasFlag)(w, eq.flag), `${id} installs`);
        else
            strict_1.default.equal((0, inventory_1.countItem)(pl, id), 1, id);
    }
});
(0, node_test_1.test)("a summon too big for the pack spills onto the ground and nothing is lost", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    const r = (0, debug_2.summonItem)(w, pl, "wood", 200);
    strict_1.default.ok(r.ok);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood") + looseCount(w, "wood"), 200);
    strict_1.default.ok(looseCount(w, "wood") > 0, "the 8-slot pack (stacks of 20) cannot hold 200");
});
(0, node_test_1.test)("summonLoose puts stacks on the ground in front (split at the stack size); the arm cannot lie there", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    const before = looseCount(w, "stone");
    strict_1.default.ok((0, debug_2.summonLoose)(w, pl, "stone", 35).ok);
    strict_1.default.equal(looseCount(w, "stone") - before, 35);
    strict_1.default.ok((0, world_1.currentArea)(w).loose.filter((l) => l.dyn && l.item === "stone").every((l) => (l.n ?? 1) <= (0, items_1.maxStack)("stone")));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "stone"), 0, "the pack is untouched");
    strict_1.default.ok(!(0, debug_2.summonLoose)(w, pl, "arm", 1).ok);
});
(0, node_test_1.test)("deleteItem, clearPack and fillMaterials", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, debug_2.summonItem)(w, pl, "wood", 12);
    (0, debug_2.summonItem)(w, pl, "coin", 1);
    strict_1.default.equal((0, debug_2.deleteItem)(pl, "wood", 5), 5);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 7);
    strict_1.default.equal((0, debug_2.deleteItem)(pl, "wood", 50), 7, "never more than held");
    (0, debug_2.summonItem)(w, pl, "key", 1);
    strict_1.default.equal((0, debug_2.clearPack)(pl), 2);
    strict_1.default.ok(pl.inventory.every((s) => !s));
    (0, debug_2.grantBuildKit)(w, pl);
    (0, debug_2.fillMaterials)(w, pl, 40);
    for (const id of items_1.ITEM_IDS)
        if (items_1.ITEMS[id].tags.includes("material"))
            strict_1.default.ok((0, inventory_1.countItem)(pl, id) >= 40, id);
});
(0, node_test_1.test)("kits: the story kit gives each piece once, the build kit teaches building and wears the basket, slots toggle", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    const first = (0, debug_2.grantStoryKit)(w, pl);
    strict_1.default.ok(first >= 7, "four glyphs, core, chisel, schematic");
    strict_1.default.equal((0, debug_2.grantStoryKit)(w, pl), 0, "nothing given twice");
    (0, debug_2.grantBuildKit)(w, pl);
    strict_1.default.ok((0, world_1.hasFlag)(w, flags_1.FLAGS.knowBuild) && (0, world_1.hasFlag)(w, flags_1.FLAGS.knowMasonry));
    strict_1.default.ok((0, gear_1.wears)(pl, "basket"));
    strict_1.default.ok(!(0, debug_2.allSlotsUnlocked)(w, pl));
    (0, debug_2.setAllSlots)(w, pl, true);
    strict_1.default.ok((0, debug_2.allSlotsUnlocked)(w, pl));
    (0, debug_2.setAllSlots)(w, pl, false);
    strict_1.default.ok(!(0, debug_2.allSlotsUnlocked)(w, pl));
});
(0, node_test_1.test)("the flag list covers the FLAGS table, rune sites, plans and NPC states, once each, and toggling round-trips", () => {
    const w = (0, helpers_1.newWorld)();
    const list = (0, debug_2.debugFlags)(w), names = list.map((f) => f.flag);
    strict_1.default.equal(new Set(names).size, names.length, "no duplicates");
    for (const f of Object.values(flags_1.FLAGS))
        strict_1.default.ok(names.includes(f), f);
    for (const n of Object.values(runes_1.RUNE_NODES))
        strict_1.default.ok(names.includes(n.flag), n.flag);
    strict_1.default.ok(names.includes((0, flags_1.npcFlag)("npc.guardian", flags_1.NPC_AWAKE)), "the guardian's awake state");
    strict_1.default.ok(list.some((f) => f.group === "PLANS"), "analysis plans");
    const f = flags_1.FLAGS.knowRepair;
    strict_1.default.ok(!(0, debug_2.flagOn)(w, f));
    (0, world_1.setFlag)(w, f);
    strict_1.default.ok((0, debug_2.flagOn)(w, f));
    (0, world_1.clearFlag)(w, f);
    strict_1.default.ok(!(0, debug_2.flagOn)(w, f));
    const arm = flags_1.FLAGS.golemArm;
    (0, world_1.setFlag)(w, arm);
    strict_1.default.ok((0, debug_2.flagOn)(w, arm), "body flags read from the actor");
    for (const x of list)
        strict_1.default.ok(/^[A-Z0-9 .,:\-/'()+=?!<>#^*]*$/.test(x.label), `label font check: ${x.label}`);
});
(0, node_test_1.test)("places: reading them changes nothing; every one is reachable by teleport and lands on free ground", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    const areasBefore = w.areas.size;
    const places = (0, debug_2.debugPlaces)(w);
    strict_1.default.equal(w.areas.size, areasBefore, "listing instantiates nothing");
    strict_1.default.ok(places.some((p) => p.area === "dungeon" && p.label.includes("THRONE HALL")));
    strict_1.default.ok(places.some((p) => p.area === "surface"), "an unvisited area offers its start");
    strict_1.default.ok(places.some((p) => p.label.includes("GUARDIAN")), "NPCs are listed");
    for (const p of places.filter((q) => q.area === "dungeon")) {
        strict_1.default.ok((0, debug_2.teleportTo)(w, pl, p.area, p.x, p.y), p.label);
        const area = (0, world_1.currentArea)(w);
        strict_1.default.ok((0, collision_1.boxFree)(area, pl.x, pl.y, (0, collision_1.actorBoxes)(w, area.id, pl.id)), `${p.label}: on free ground`);
    }
});
(0, node_test_1.test)("teleport crosses into an unvisited area and the player arrives there", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    strict_1.default.ok(!w.areas.has("surface"));
    const s = (0, debug_2.debugPlaces)(w).find((p) => p.area === "surface");
    strict_1.default.ok((0, debug_2.teleportTo)(w, pl, s.area, s.x, s.y));
    strict_1.default.equal(pl.area, "surface");
    strict_1.default.ok(w.areas.has("surface"));
    strict_1.default.ok((0, collision_1.boxFree)((0, world_1.getArea)(w, "surface"), pl.x, pl.y, (0, collision_1.actorBoxes)(w, "surface", pl.id)));
    strict_1.default.ok(!(0, debug_2.teleportTo)(w, pl, "nowhere", 0, 0), "an unknown area is refused");
});
(0, node_test_1.test)("noclip walks through a wall that blocks a normal walk", () => {
    const find = () => {
        const a = (0, world_1.currentArea)((0, helpers_1.newWorld)());
        for (let ty = 3; ty < a.h - 3; ty++)
            for (let tx = 3; tx < a.w - 4; tx++) {
                if (!(0, tiles_1.isSolidT)(a.tile(tx, ty)) && (0, tiles_1.isSolidT)(a.tile(tx + 1, ty)) && !(0, tiles_1.isSolidT)(a.tile(tx + 3, ty)) && !(0, tiles_1.isSolidT)(a.tile(tx, ty - 1)) && !(0, tiles_1.isSolidT)(a.tile(tx, ty + 1)))
                    return { tx, ty };
            }
        throw new Error("no wall");
    };
    const { tx, ty } = find();
    const run = (noclip) => {
        const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
        pl.x = tx * tiles_1.TS + 8;
        pl.y = ty * tiles_1.TS + 12;
        for (let i = 0; i < 120; i++)
            (0, step_1.stepPlayer)(w, helpers_1.DT, { ix: 1, iy: 0, use: false, speed: 3, noclip });
        return pl.x;
    };
    strict_1.default.ok(run(false) < (tx + 1) * tiles_1.TS, "blocked by the wall");
    strict_1.default.ok(run(true) > (tx + 1) * tiles_1.TS + 4, "walked through it");
});
// ---------------------------------------------------------------- screen
function menu() {
    const w = (0, helpers_1.newWorld)(), sh = (0, screenHost_1.screenHost)(w), pl = (0, world_1.player)(w);
    const st = { speed: false, mult: 3, noclip: false, hud: false, zoom: 1, tele: [], saved: 0 };
    Object.defineProperties(sh.host, {
        debugSpeed: { get: () => st.speed, set: (v) => { st.speed = v; } },
        debugSpeedMult: { get: () => st.mult, set: (v) => { st.mult = v; } },
        debugNoclip: { get: () => st.noclip, set: (v) => { st.noclip = v; } },
        debugHud: { get: () => st.hud, set: (v) => { st.hud = v; } },
        zoom: { get: () => st.zoom },
        hasArm: { get: () => (0, world_1.hasFlag)(w, flags_1.FLAGS.golemArm) },
    });
    Object.assign(sh.host, {
        has: () => false,
        debugSetFlag: (f, on) => { if (on)
            (0, world_1.setFlag)(w, f);
        else
            (0, world_1.clearFlag)(w, f); },
        debugTeleport: (p) => { st.tele.push(p.label); return (0, debug_2.teleportTo)(w, pl, p.area, p.x, p.y); },
        debugNewGame() { }, debugFoundations() { }, debugZoom: () => { st.zoom = 1.5; },
        saveGame: () => { st.saved++; }, loadGame: () => false,
    });
    const ui = new debug_1.DebugUi(sh.host);
    ui.toggle();
    return { w, pl, sh, ui, st };
}
const type = (sh, ...chars) => { sh.host.typed = chars; sh.press(); sh.host.typed = []; };
(0, node_test_1.test)("opens on the play screen only, and the toggle closes it", () => {
    const { sh, ui } = menu();
    strict_1.default.ok(sh.host.screens.is("debug"));
    ui.toggle();
    strict_1.default.ok(sh.host.screens.is("play"));
    ui.toggle();
    sh.press("escape");
    strict_1.default.ok(sh.host.screens.is("play"), "Esc closes");
    ui.toggle();
    strict_1.default.ok(sh.host.screens.is("debug"));
    sh.press("tab");
    strict_1.default.ok(sh.host.screens.is("play"), "Tab closes");
});
(0, node_test_1.test)("ITEMS: quantity with A / D (Shift x10), E gives, G drops on the ground, X deletes, F wears", () => {
    const { w, pl, sh, ui } = menu();
    strict_1.default.ok(ui.select("item", "wood"));
    for (let i = 0; i < 4; i++)
        sh.press("d");
    strict_1.default.equal(ui.qty, 5);
    sh.press("a");
    strict_1.default.equal(ui.qty, 4);
    sh.press("m");
    strict_1.default.equal(ui.qty, (0, items_1.maxStack)("wood"));
    sh.press("e");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), (0, items_1.maxStack)("wood"));
    sh.press("x");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 0);
    sh.press("g");
    strict_1.default.equal(looseCount(w, "wood"), (0, items_1.maxStack)("wood"));
});
(0, node_test_1.test)("ITEMS: F wears the basket and a rune once their slots can take them", () => {
    const { pl, sh, ui } = menu();
    strict_1.default.ok(ui.select("item", "basket"));
    sh.press("f");
    strict_1.default.ok((0, gear_1.wears)(pl, "basket"));
    strict_1.default.ok(ui.select("item", "coin"));
    sh.press("f");
    strict_1.default.match(ui.status.text, /NOT WEARABLE/);
});
(0, node_test_1.test)("ITEMS: search filters by name and tag; Esc clears the search before it closes the menu", () => {
    const { sh, ui } = menu();
    const all = ui.rows.length;
    strict_1.default.equal(all, items_1.ITEM_IDS.length);
    sh.press("/");
    strict_1.default.ok(ui.search.active);
    type(sh, "R", "u", "n", "e");
    strict_1.default.ok(ui.rows.length > 0 && ui.rows.length < all);
    strict_1.default.ok(ui.rows.every((r) => /RUNE/.test(`${r.label} ${items_1.ITEMS[r.item].tags.join(" ").toUpperCase()}`)));
    sh.press("enter");
    strict_1.default.ok(!ui.search.active);
    sh.press("escape");
    strict_1.default.equal(ui.rows.length, all);
    strict_1.default.ok(sh.host.screens.is("debug"));
    sh.press("escape");
    strict_1.default.ok(sh.host.screens.is("play"));
});
(0, node_test_1.test)("typing in the search field never fires commands (W A S D E G X are letters there)", () => {
    const { pl, sh, ui } = menu();
    sh.press("/");
    type(sh, "w", "a", "s", "d", "e", "g", "x", "f");
    strict_1.default.equal(ui.search.value, "WASDEGXF");
    strict_1.default.equal(pl.inventory.filter(Boolean).length, 0);
});
(0, node_test_1.test)("tabs: Q / R step (wrapping), 1-5 jump", () => {
    const { sh, ui } = menu();
    sh.press("r");
    strict_1.default.equal(ui.tab, 1);
    sh.press("q");
    sh.press("q");
    strict_1.default.equal(ui.tab, debug_1.DEBUG_TABS.length - 1);
    sh.press("3");
    strict_1.default.equal(ui.tab, 2);
    sh.press("1");
    strict_1.default.equal(ui.tab, 0);
});
(0, node_test_1.test)("PLAYER: arm, eye, noclip, slots, speed cycling both ways, kits and pack tools", () => {
    const { w, pl, sh, ui, st } = menu();
    sh.press("2");
    strict_1.default.ok(ui.select("arm"));
    sh.press("e");
    strict_1.default.ok((0, world_1.hasFlag)(w, flags_1.FLAGS.golemArm));
    sh.press("e");
    strict_1.default.ok(!(0, world_1.hasFlag)(w, flags_1.FLAGS.golemArm));
    strict_1.default.ok(ui.select("eye"));
    sh.press("e");
    strict_1.default.ok((0, world_1.hasFlag)(w, flags_1.FLAGS.golemEye));
    strict_1.default.ok(ui.select("noclip"));
    sh.press("e");
    strict_1.default.ok(st.noclip);
    sh.press("e");
    strict_1.default.ok(!st.noclip);
    strict_1.default.ok(ui.select("speed"));
    const seen = [];
    for (let i = 0; i < 4; i++) {
        sh.press("d");
        seen.push(st.speed ? st.mult : 1);
    }
    strict_1.default.deepEqual(seen, [3, 6, 12, 1]);
    sh.press("a");
    strict_1.default.equal(st.mult, 12, "A steps back from off to the top");
    strict_1.default.ok(ui.select("slots"));
    sh.press("e");
    strict_1.default.ok((0, debug_2.allSlotsUnlocked)(w, pl));
    strict_1.default.ok(ui.select("buildkit"));
    sh.press("e");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "planks") > 0, true);
    strict_1.default.ok(ui.select("storykit"));
    sh.press("e");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "core"), 1);
    strict_1.default.ok(ui.select("clear"));
    sh.press("e");
    strict_1.default.ok(pl.inventory.every((s) => !s));
});
(0, node_test_1.test)("FLAGS: E toggles the flag under the cursor; the list can be searched", () => {
    const { w, sh, ui } = menu();
    sh.press("3");
    strict_1.default.ok(ui.select("flag", flags_1.FLAGS.knowRepair));
    sh.press("e");
    strict_1.default.ok((0, world_1.hasFlag)(w, flags_1.FLAGS.knowRepair));
    sh.press("e");
    strict_1.default.ok(!(0, world_1.hasFlag)(w, flags_1.FLAGS.knowRepair));
    sh.press("/");
    type(sh, "g", "u", "a", "r", "d");
    strict_1.default.ok(ui.rows.length >= 1 && ui.rows.every((r) => r.label.includes("GUARDIAN")));
});
(0, node_test_1.test)("TELEPORT: E on a place moves the golem and closes the menu", () => {
    const { w, pl, sh, ui, st } = menu();
    sh.press("4");
    strict_1.default.ok(ui.select("go", "DUNGEON: GREAT HALL"));
    const before = { x: pl.x, y: pl.y };
    sh.press("e");
    strict_1.default.deepEqual(st.tele, ["DUNGEON: GREAT HALL"]);
    strict_1.default.ok(pl.x !== before.x || pl.y !== before.y);
    strict_1.default.ok(sh.host.screens.is("play"));
    const room = (0, world_1.currentArea)(w).rooms.find((r) => r.name === "GREAT HALL");
    strict_1.default.ok(pl.x > room.x * tiles_1.TS && pl.x < (room.x + room.w) * tiles_1.TS);
});
(0, node_test_1.test)("WORLD: HUD, zoom and save call through", () => {
    const { sh, ui, st } = menu();
    sh.press("5");
    strict_1.default.ok(ui.select("hud"));
    sh.press("e");
    strict_1.default.ok(st.hud);
    strict_1.default.ok(ui.select("zoom"));
    sh.press("e");
    strict_1.default.equal(st.zoom, 1.5);
    strict_1.default.ok(ui.select("save"));
    sh.press("e");
    strict_1.default.equal(st.saved, 1);
    strict_1.default.ok(ui.select("unlock"));
    sh.press("e");
    strict_1.default.match(ui.status.text, /UNLOCKED/);
});
(0, node_test_1.test)("every tab draws only font glyphs, inside the panel, with no overlapping text", () => {
    const { w, sh, ui } = menu();
    for (let t = 0; t < debug_1.DEBUG_TABS.length; t++) {
        ui.setTab(t);
        (0, screenHost_1.assertTextFits)(`debug tab ${debug_1.DEBUG_TABS[t].name}`, sh.draw(), debug_1.DEBUG_PANEL);
        // every row's detail on the longer lists
        const n = ui.rows.length;
        for (let i = 0; i < n; i += Math.max(1, Math.floor(n / 12))) {
            sh.press("s");
            (0, screenHost_1.assertTextFits)(`debug tab ${debug_1.DEBUG_TABS[t].name} row ${i}`, sh.draw(), debug_1.DEBUG_PANEL);
        }
    }
    // each item's detail panel, with a long status line
    ui.setTab(0);
    for (const id of items_1.ITEM_IDS) {
        ui.select("item", id);
        (0, screenHost_1.assertTextFits)(`item ${id}`, sh.draw(), debug_1.DEBUG_PANEL);
    }
    ui.select("item", "wood");
    sh.press("e");
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
    (0, screenHost_1.assertTextFits)("with a status", sh.draw(), debug_1.DEBUG_PANEL);
});
// ---------------------------------------------------------------- the real host
(0, node_test_1.test)("Ctrl+0 on the real Game opens the menu over the play screen, Ctrl+0 again closes it, and it works from the menu's keys", () => {
    const canvas = () => globalThis.document.createElement("canvas");
    const g = new game_1.Game(canvas(), canvas());
    const w = (0, helpers_1.newWorld)();
    g.resume(w);
    const tick = (n = 1) => { for (let i = 0; i < n; i++)
        g.update(1 / 60); };
    const press = (k) => { g.keyDown(k); tick(); g.keyUp(k); };
    tick(2);
    g.debugKey(0);
    strict_1.default.ok(g.screens.is("debug"));
    const t0 = w.time;
    tick(30);
    strict_1.default.equal(w.time, t0, "the world is paused behind the menu");
    press("e"); // ITEMS tab, first item: the rune chisel
    strict_1.default.equal((0, inventory_1.countItem)((0, world_1.player)(w), "chisel"), 1);
    press("2");
    press("s");
    press("s");
    press("s"); // noclip row
    press("e");
    strict_1.default.equal(g.debugNoclip, true);
    press("5");
    press("e"); // HUD
    strict_1.default.equal(g.debugHud, true);
    g.debugKey(0);
    strict_1.default.ok(g.screens.is("play"));
    // Ctrl+0 does nothing off the play screen
    g.screens.set(g.S.title);
    g.debugKey(0);
    strict_1.default.ok(!g.screens.is("debug"));
});
(0, node_test_1.test)("Game: the debug menu's flag, teleport, zoom and new-game hooks", () => {
    const canvas = () => globalThis.document.createElement("canvas");
    const g = new game_1.Game(canvas(), canvas());
    const w = (0, helpers_1.newWorld)();
    g.resume(w);
    g.debugSetFlag(flags_1.FLAGS.golemEye, true);
    strict_1.default.ok((0, world_1.hasFlag)(w, flags_1.FLAGS.golemEye));
    g.debugSetFlag(flags_1.FLAGS.golemEye, false);
    strict_1.default.ok(!(0, world_1.hasFlag)(w, flags_1.FLAGS.golemEye));
    const surface = (0, debug_2.debugPlaces)(w).find((p) => p.area === "surface");
    strict_1.default.ok(g.debugTeleport(surface));
    strict_1.default.equal(g.area.id, "surface");
    strict_1.default.equal(g.view.area, g.area, "the view follows the player at once");
    g.update(1 / 60);
    g.render();
    const z = g.zoom;
    g.debugZoom();
    g.update(1);
    strict_1.default.notEqual(g.zoom, z);
    g.debugNewGame();
    strict_1.default.ok(g.screens.is("play"));
    strict_1.default.notEqual(g.world, w);
    g.debugFoundations();
    strict_1.default.ok(g.screens.is("play"));
    strict_1.default.equal(g.pl.area, "debug_workshop");
});
