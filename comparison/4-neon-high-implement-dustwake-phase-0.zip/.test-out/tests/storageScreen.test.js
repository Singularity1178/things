"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The storage screen (screens/storage.ts) and its command (commands.ts:
// moveStorageSlot): opened on the chest, moves both ways, as much as fits,
// refusals with a message, the cursor crossing between the panes, closing, a
// save with items in the chest, and a text lint of what it draws.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const storage_1 = require("../src/game/screens/storage");
const commands_1 = require("../src/game/sim/commands");
const items_1 = require("../src/game/content/items");
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const inventory_1 = require("../src/game/sim/inventory");
const inventoryOps_1 = require("../src/game/sim/inventoryOps");
const font_1 = require("../src/game/font");
const helpers_1 = require("./helpers");
const screenHost_1 = require("./support/screenHost");
const workerFixture_1 = require("./support/workerFixture");
const roundTrip = (w) => (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
const setChest = (w, slots) => (0, world_1.getArea)(w, workerFixture_1.CHEST.area).setInventory(workerFixture_1.CHEST.prop, slots);
const slotOf = (w, item) => (0, world_1.player)(w).inventory.findIndex((s) => s?.item === item);
function open() {
    const f = (0, workerFixture_1.fixture)(), sh = (0, screenHost_1.screenHost)(f.w), ui = new storage_1.StorageUi(sh.host);
    (0, workerFixture_1.besideChest)(f.w);
    ui.open(workerFixture_1.CHEST.prop);
    return { ...f, sh, ui };
}
const last = (a) => a[a.length - 1];
(0, node_test_1.test)("opens on the pack with the cursor on the first slot; the pack is the tier's size and the chest has 32", () => {
    const { sh, ui, w } = open();
    strict_1.default.ok(sh.host.screens.is("storage"));
    strict_1.default.equal(ui.pane, "pack");
    strict_1.default.equal(ui.cursor, 0);
    strict_1.default.equal(ui.slots("pack").cap, (0, inventory_1.capacity)(w, (0, world_1.player)(w)));
    strict_1.default.equal(ui.slots("chest").cap, 32);
    strict_1.default.deepEqual([(0, storage_1.gridLayout)(8, "pack").cols, (0, storage_1.gridLayout)(16, "pack").cols, (0, storage_1.gridLayout)(48, "pack").cols, (0, storage_1.gridLayout)(32, "chest").cols], [4, 4, 8, 8]);
});
(0, node_test_1.test)("E moves the whole stack into the chest and back; Q moves one", () => {
    const { w, pl, sh, ui } = open();
    const planks = slotOf(w, "planks");
    ui.cursors.pack = planks;
    sh.press("e");
    strict_1.default.equal((0, workerFixture_1.chestCount)(w, "planks"), 8);
    strict_1.default.equal((0, inventoryOps_1.countItem)(pl, "planks"), 0);
    strict_1.default.equal(last(sh.notes), "STORED 8 PLANKS");
    // across to the chest (D off the pack's last column) and take one, then the rest
    ui.cursors.pack = 3;
    sh.press("d");
    strict_1.default.equal(ui.pane, "chest");
    strict_1.default.equal(ui.cursor, 0);
    sh.press("q");
    strict_1.default.equal((0, inventoryOps_1.countItem)(pl, "planks"), 1);
    strict_1.default.equal((0, workerFixture_1.chestCount)(w, "planks"), 7);
    strict_1.default.equal(last(sh.notes), "TOOK 1 PLANKS");
    sh.press("e");
    strict_1.default.equal((0, inventoryOps_1.countItem)(pl, "planks"), 8);
    strict_1.default.equal((0, workerFixture_1.chestCount)(w, "planks"), 0);
    strict_1.default.equal(last(sh.notes), "TOOK 7 PLANKS");
    // Q on the pack side stores one
    ui.pane = "pack";
    ui.cursors.pack = slotOf(w, "planks");
    sh.press("q");
    strict_1.default.equal((0, workerFixture_1.chestCount)(w, "planks"), 1);
    strict_1.default.equal((0, inventoryOps_1.countItem)(pl, "planks"), 7);
    strict_1.default.equal((0, workerFixture_1.chestProp)(w).inventory.filter(Boolean).length, 1);
});
(0, node_test_1.test)("a partly fitting stack moves as much as fits and says so; a full chest refuses; items are never lost", () => {
    const { w, pl, sh, ui } = open();
    const full = Array.from({ length: 32 }, () => ({ item: "stone", n: 20 }));
    full[31] = { item: "planks", n: 17 }; // room for three more planks, nowhere else
    setChest(w, full);
    const total = () => (0, workerFixture_1.chestCount)(w, "planks") + (0, inventoryOps_1.countItem)(pl, "planks");
    const before = total();
    ui.cursors.pack = slotOf(w, "planks");
    sh.press("e");
    strict_1.default.equal((0, workerFixture_1.chestCount)(w, "planks"), 20);
    strict_1.default.equal((0, inventoryOps_1.countItem)(pl, "planks"), 5);
    strict_1.default.equal(last(sh.notes), "STORED 3 OF 8 PLANKS. THE STORAGE IS FULL");
    sh.press("e");
    strict_1.default.equal(last(sh.notes), commands_1.STORE_TEXT.chestFull);
    strict_1.default.equal((0, inventoryOps_1.countItem)(pl, "planks"), 5);
    sh.press("q");
    strict_1.default.equal(last(sh.notes), commands_1.STORE_TEXT.chestFull);
    strict_1.default.equal(total(), before, "nothing created or destroyed");
    // taking into a full pack
    const f2 = open(); // fresh world
    f2.pl.inventory = Array.from({ length: 8 }, () => ({ item: "wood", n: 20 }));
    setChest(f2.w, [{ item: "stone", n: 4 }, ...Array(31).fill(null)]);
    f2.ui.pane = "chest";
    f2.ui.cursors.chest = 0;
    f2.sh.press("e");
    strict_1.default.equal(last(f2.sh.notes), commands_1.STORE_TEXT.packFull);
    strict_1.default.equal((0, workerFixture_1.chestCount)(f2.w, "stone"), 4);
    // partial take: one slot of room (a stack of stone is 20, so 3 of 9 fit beside 17)
    f2.pl.inventory[7] = { item: "stone", n: 17 };
    setChest(f2.w, [{ item: "stone", n: 9 }, ...Array(31).fill(null)]);
    f2.sh.press("e");
    strict_1.default.equal(last(f2.sh.notes), "TOOK 3 OF 9 STONE. YOUR PACK IS FULL");
    strict_1.default.equal((0, workerFixture_1.chestCount)(f2.w, "stone"), 6);
    strict_1.default.equal((0, inventoryOps_1.countItem)(f2.pl, "stone"), 20);
});
(0, node_test_1.test)("an empty slot says so; the tutorial's undroppable items are never stored", () => {
    const { w, pl, sh, ui } = open();
    ui.cursors.pack = 7;
    sh.press("e");
    strict_1.default.equal(last(sh.notes), commands_1.STORE_TEXT.empty);
    ui.pane = "chest";
    ui.cursors.chest = 5;
    sh.press("q");
    strict_1.default.equal(last(sh.notes), commands_1.STORE_TEXT.empty);
    ui.pane = "pack";
    ui.cursors.pack = slotOf(w, "chisel");
    sh.press("e");
    strict_1.default.equal(last(sh.notes), commands_1.STORE_TEXT.critical);
    strict_1.default.equal((0, inventoryOps_1.countItem)(pl, "chisel"), 1);
    strict_1.default.equal((0, workerFixture_1.chestCount)(w, "chisel"), 0);
    strict_1.default.equal(items_1.ITEMS.chisel.droppable, false);
});
(0, node_test_1.test)("the cursor crosses between the panes on the same row, and stays inside the grids", () => {
    const { w, pl, sh, ui } = open();
    // 8-slot pack: 4 columns, 2 rows. D x3 along row 0, then across.
    sh.press("d");
    sh.press("d");
    sh.press("d");
    strict_1.default.deepEqual([ui.pane, ui.cursor], ["pack", 3]);
    sh.press("d");
    strict_1.default.deepEqual([ui.pane, ui.cursor], ["chest", 0]);
    sh.press("a");
    strict_1.default.deepEqual([ui.pane, ui.cursor], ["pack", 3], "A off the chest's first column comes back to the pack's last");
    sh.press("s");
    sh.press("s");
    strict_1.default.equal(ui.cursor, 7, "stops at the last row");
    sh.press("d");
    strict_1.default.deepEqual([ui.pane, ui.cursor], ["chest", 8], "same row on the other side");
    sh.press("w");
    sh.press("w");
    sh.press("w");
    strict_1.default.equal(ui.cursor, 0);
    sh.press("arrowleft");
    strict_1.default.equal(ui.pane, "pack");
    sh.press("a");
    sh.press("a");
    sh.press("a");
    sh.press("a");
    strict_1.default.deepEqual([ui.pane, ui.cursor], ["pack", 0], "the pack's own left edge holds");
    // the basket: 48 slots, 8 columns, six rows; the chest only has four
    pl.gear.back = "basket";
    (0, helpers_1.frame)(w);
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 48);
    ui.cursors.pack = 40;
    for (let i = 0; i < 7; i++)
        sh.press("d");
    strict_1.default.equal(ui.cursor, 47);
    sh.press("d");
    strict_1.default.deepEqual([ui.pane, ui.cursor], ["chest", 24], "row 5 of the pack lands on the chest's last row");
    sh.press("a");
    strict_1.default.deepEqual([ui.pane, ui.cursor], ["pack", 31]);
    ui.pane = "chest";
    ui.cursors.chest = 31;
    sh.press("d");
    sh.press("s");
    strict_1.default.equal(ui.cursor, 31, "the chest's right and bottom edges hold");
});
(0, node_test_1.test)("Esc, I and Tab close it, and the world's state is whatever the moves left", () => {
    for (const key of ["escape", "i", "tab"]) {
        const { sh } = open();
        sh.press(key);
        strict_1.default.ok(sh.host.screens.is("play"), key);
    }
    const { sh, ui, w } = open();
    const at = slotOf(w, "planks");
    ui.cursors.pack = at;
    sh.press("e");
    sh.press("escape");
    strict_1.default.equal((0, workerFixture_1.chestCount)(w, "planks"), 8);
    ui.open(workerFixture_1.CHEST.prop);
    strict_1.default.deepEqual([ui.pane, ui.cursors.pack], ["pack", at], "reopens with the cursor where it was, on the pack");
});
(0, node_test_1.test)("a chest that is gone or out of reach changes nothing and the screen closes itself", () => {
    const { w, pl, sh, ui } = open();
    ui.cursors.pack = slotOf(w, "planks");
    pl.x += 80;
    strict_1.default.deepEqual({ ...(0, commands_1.moveStorageSlot)(w, pl, workerFixture_1.CHEST.prop, "store", ui.cursor, 5), text: undefined }, { result: "far", moved: 0, text: undefined });
    sh.press("e");
    strict_1.default.equal(last(sh.notes), commands_1.STORE_TEXT.far);
    strict_1.default.equal((0, inventoryOps_1.countItem)(pl, "planks"), 8);
    (0, workerFixture_1.besideChest)(w);
    (0, world_1.getArea)(w, workerFixture_1.CHEST.area).removeProp(workerFixture_1.CHEST.prop);
    strict_1.default.equal((0, commands_1.moveStorageSlot)(w, pl, workerFixture_1.CHEST.prop, "store", ui.cursor, 5).result, "gone");
    sh.press("w");
    strict_1.default.ok(sh.host.screens.is("play"));
    strict_1.default.equal(last(sh.notes), commands_1.STORE_TEXT.gone);
});
(0, node_test_1.test)("moves are saved: items in the chest survive a save and load, and replaying the keys gives identical worlds", () => {
    const run = () => {
        const { w, sh, ui } = open();
        ui.cursors.pack = slotOf(w, "planks");
        sh.press("e");
        ui.pane = "pack";
        ui.cursors.pack = slotOf(w, "crown");
        sh.press("q");
        return w;
    };
    const a = run(), b = run();
    strict_1.default.deepEqual((0, save_1.serialize)(a), (0, save_1.serialize)(b), "deterministic");
    const loaded = roundTrip(a);
    strict_1.default.equal((0, workerFixture_1.chestCount)(loaded, "planks"), 8);
    strict_1.default.equal((0, workerFixture_1.chestCount)(loaded, "crown"), 1);
    strict_1.default.deepEqual((0, workerFixture_1.chestProp)(loaded).inventory, (0, workerFixture_1.chestProp)(a).inventory);
    strict_1.default.deepEqual((0, save_1.serialize)(loaded), (0, save_1.serialize)(a));
    // and the reloaded chest gives them back
    (0, workerFixture_1.besideChest)(loaded);
    strict_1.default.equal((0, commands_1.moveStorageSlot)(loaded, (0, world_1.player)(loaded), workerFixture_1.CHEST.prop, "take", (0, workerFixture_1.chestProp)(loaded).inventory.findIndex((s) => s?.item === "planks"), 99).moved, 8);
    strict_1.default.equal((0, inventoryOps_1.countItem)((0, world_1.player)(loaded), "planks"), 8);
});
(0, node_test_1.test)("the screen draws only font glyphs, inside its panel, with no text over text: every item, both panes, every pack tier", () => {
    const { w, pl, sh, ui } = open();
    (0, screenHost_1.assertTextFits)("storage (fresh)", sh.draw());
    sh.save(".test-out/shots/storage-fresh.png");
    // every item in the description panel, from either pane
    for (const id of Object.keys(items_1.ITEMS)) {
        const n = Math.min((0, items_1.maxStack)(id), 12);
        pl.inventory[0] = { item: id, n };
        setChest(w, [{ item: id, n }, ...Array(31).fill(null)]);
        for (const pane of ["pack", "chest"]) {
            ui.pane = pane;
            ui.cursors[pane] = 0;
            (0, screenHost_1.assertTextFits)(`storage ${id} ${pane}`, sh.draw());
        }
    }
    // tiers, full and empty, with the cursor in the far corners
    pl.gear.back = "basket";
    (0, helpers_1.frame)(w);
    pl.inventory = Array.from({ length: 48 }, (_, i) => ({ item: ["wood", "stone", "planks", "cut_stone"][i % 4], n: 1 + (i % 19) }));
    setChest(w, Array.from({ length: 32 }, (_, i) => ({ item: "stone", n: 1 + (i % 19) })));
    ui.pane = "pack";
    ui.cursors.pack = 47;
    (0, screenHost_1.assertTextFits)("storage 48 full", sh.draw());
    sh.save(".test-out/shots/storage-full.png");
    ui.pane = "chest";
    ui.cursors.chest = 31;
    (0, screenHost_1.assertTextFits)("storage chest full", sh.draw());
    delete pl.gear.back;
    pl.upgrades.push("golem.arm");
    (0, helpers_1.frame)(w);
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 16);
    ui.pane = "pack";
    ui.cursors.pack = 15;
    (0, screenHost_1.assertTextFits)("storage 16", sh.draw());
    for (const text of Object.values(commands_1.STORE_TEXT))
        strict_1.default.ok([...text].every((c) => font_1.FONT_GLYPHS.has(c)) && text.length <= 78, text);
    for (const id of Object.keys(items_1.ITEMS))
        strict_1.default.ok(items_1.ITEM_NAMES[id].length <= 24);
});
