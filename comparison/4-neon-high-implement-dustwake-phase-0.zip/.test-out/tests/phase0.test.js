"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Phase 0 Groundwork verification suite (0.1 through 0.8 + exit criteria).
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const g0 = globalThis;
g0.localStorage ?? (g0.localStorage = { getItem: () => null, setItem: () => { }, removeItem: () => { } });
const game_1 = require("../src/game/game");
const clock_1 = require("../src/game/sim/clock");
const lod_1 = require("../src/game/sim/lod");
const step_1 = require("../src/game/sim/step");
const world_1 = require("../src/game/world/world");
const tiles_1 = require("../src/game/content/tiles");
const save_1 = require("../src/game/world/save");
const saveStore_1 = require("../src/game/view/saveStore");
const contentLint_1 = require("../src/game/sim/contentLint");
const soak_1 = require("../src/game/sim/soak");
const propFont_1 = require("../src/game/ui/propFont");
const input_1 = require("../src/game/ui/input");
const notifications_1 = require("../src/game/ui/notifications");
const components_1 = require("../src/game/ui/components");
const settings_1 = require("../src/game/settings");
const vision_1 = require("../src/game/content/vision");
const makeCanvasEl = () => globalThis.document.createElement("canvas");
// ========================================================================= 0.1
(0, node_test_1.test)("0.1 fixed-timestep determinism: same save + input stream yields identical world state at 1x and 8x", () => {
    const base = (0, world_1.createWorld)(1337);
    const saved = (0, save_1.serialize)(base);
    const w1 = (0, save_1.deserialize)(saved);
    const w8 = (0, save_1.deserialize)(saved);
    // Deterministic tick-indexed input stream over 240 fixed ticks (4 sim seconds)
    const inputAtTick = (tick) => ({
        ix: tick < 80 ? 1 : tick < 140 ? 0 : -1,
        iy: tick >= 40 && tick < 160 ? 1 : 0,
        use: tick === 50 || tick === 150,
        attack: tick === 90,
        toggleScan: tick === 110,
    });
    const c1 = new clock_1.SimClock(clock_1.SIM_DT);
    c1.setSpeed(1);
    const c8 = new clock_1.SimClock(clock_1.SIM_DT);
    c8.setSpeed(8);
    const stepBoth = (w, clock, frameDt) => {
        clock.advance(frameDt, (dt, tickIdx) => {
            (0, step_1.stepPlayer)(w, dt, inputAtTick(tickIdx));
            (0, step_1.stepWorld)(w, dt);
            w.events.length = 0;
        });
    };
    // Run 240 frames at 1x (1 tick per 1/60s frame = 240 ticks)
    for (let f = 0; f < 240; f++)
        stepBoth(w1, c1, clock_1.SIM_DT);
    // Run 30 frames at 8x (8 ticks per 1/60s frame = 240 ticks)
    for (let f = 0; f < 30; f++)
        stepBoth(w8, c8, clock_1.SIM_DT);
    strict_1.default.equal(c1.tick, 240);
    strict_1.default.equal(c8.tick, 240);
    strict_1.default.deepEqual((0, save_1.serialize)(w1), (0, save_1.serialize)(w8), "1x and 8x must produce byte-identical world state");
    // Pause runs 0 ticks
    c8.setSpeed(0);
    const pausedRes = c8.advance(0.05, () => { throw new Error("should not step while paused"); });
    strict_1.default.equal(pausedRes.ticks, 0);
    // InterpBuffer smoothly interpolates actor movement and snaps across teleports
    const interp = new clock_1.InterpBuffer();
    const pl = (0, world_1.player)(w1);
    interp.capture(w1);
    const x0 = pl.x, y0 = pl.y;
    pl.x += 10;
    pl.y += 4;
    const mid = interp.position(pl, 0.5);
    strict_1.default.equal(mid.x, x0 + 5);
    strict_1.default.equal(mid.y, y0 + 2);
    pl.x += 120; // teleport jump > 32px snaps cleanly
    strict_1.default.equal(interp.position(pl, 0.5).x, pl.x);
});
// ========================================================================= 0.2
(0, node_test_1.test)("0.2 simulation LOD: classifies Active / Near / Far and catches up Far areas via world.time - area.lastTicked", () => {
    const w = (0, world_1.createWorld)(2026);
    const town = (0, world_1.getArea)(w, "town");
    const dungeon = (0, world_1.getArea)(w, "dungeon");
    (0, world_1.enterArea)(w, (0, world_1.player)(w), town.id, town.start.x, town.start.y);
    w.lod = (0, lod_1.createLodConfig)();
    w.lod.view = { x: town.start.x - 100, y: town.start.y - 60, w: 200, h: 120 };
    const tiers = { active: 0, near: 0, far: 0 };
    for (const a of w.actors) {
        tiers[(0, lod_1.classifyActorLod)(w, a, w.lod.view, 0)]++;
    }
    strict_1.default.ok(tiers.active >= 1, "player (and nearby town actors) are Active");
    strict_1.default.ok(tiers.near >= 1, "off-camera town residents are Near");
    strict_1.default.ok(tiers.far >= 1, "dungeon actors are Far");
    // Advance world time while dungeon is Far; dungeon.lastTicked stays behind w.time
    dungeon.ritual.active = true;
    const beforeActT = dungeon.ritual.actT;
    const beforeLast = dungeon.lastTicked;
    for (let i = 0; i < 60; i++)
        (0, step_1.stepWorld)(w, clock_1.SIM_DT);
    strict_1.default.equal(dungeon.lastTicked, beforeLast, "Far area does not advance per tick");
    strict_1.default.ok(w.time - dungeon.lastTicked >= 0.99);
    // Entering dungeon triggers catch-up using world.time - area.lastTicked
    const elapsed = (0, lod_1.catchUpArea)(w, dungeon);
    strict_1.default.ok(elapsed >= 0.99, "catch-up delta equals world.time - area.lastTicked");
    strict_1.default.ok(dungeon.ritual.actT > beforeActT + 0.9, "Far area ritual caught up accurately");
    strict_1.default.equal(dungeon.lastTicked, w.time);
});
// ========================================================================= 0.3
(0, node_test_1.test)("0.3 dynamic areas (AreaSpec): create, enter, edit, save, load and leave a generated test floor", () => {
    const w = (0, world_1.createWorld)(777);
    const pl = (0, world_1.player)(w);
    // Create generated areas of every kind
    const floor = (0, world_1.createDynamicArea)(w, { id: "test_floor_1", kind: "dungeon_floor", seed: 9001, w: 34, h: 26, parent: "dungeon", depth: 2, label: "Test Floor 2" });
    const cavern = (0, world_1.createDynamicArea)(w, { kind: "cavern", seed: 9002, w: 30, h: 24, parent: "test_floor_1", depth: 3 });
    const outpost = (0, world_1.createDynamicArea)(w, { kind: "outpost", seed: 9003, w: 30, h: 24, parent: "surface", depth: 0 });
    const wilds = (0, world_1.createDynamicArea)(w, { kind: "wilds", seed: 9004, w: 30, h: 24, parent: "surface", depth: 0 });
    strict_1.default.ok(floor.rooms.length >= 2 && cavern.w === 30 && outpost.base.outdoor && wilds.base.outdoor);
    // Enter the generated floor, edit a tile and add a prop
    (0, world_1.enterArea)(w, pl, floor.id, floor.start.x, floor.start.y);
    strict_1.default.equal((0, world_1.currentArea)(w).id, "test_floor_1");
    const editTx = Math.floor(floor.start.x / 16) + 1;
    const editTy = Math.floor(floor.start.y / 16);
    floor.setTile(editTx, editTy, tiles_1.T.RUBBLE);
    floor.addProp("chest", floor.start.x + 16, floor.start.y + 8, { container: true }, "built_floor_chest");
    // Save & load round-trip
    const raw = (0, save_1.serialize)(w);
    strict_1.default.ok(raw.specs?.test_floor_1, "AreaSpec persisted in save");
    const loaded = (0, save_1.deserialize)(raw);
    strict_1.default.equal((0, world_1.currentArea)(loaded).id, "test_floor_1");
    const loadedFloor = (0, world_1.getArea)(loaded, "test_floor_1");
    strict_1.default.equal(loadedFloor.tile(editTx, editTy), tiles_1.T.RUBBLE, "edited tile persisted on generated floor");
    strict_1.default.ok(loadedFloor.prop("built_floor_chest"), "built prop persisted on generated floor");
    strict_1.default.deepEqual((0, save_1.serialize)(loaded), raw, "exact round-trip on generated areas");
    // Leave generated floor back to parent dungeon
    const parentId = loadedFloor.spec.parent;
    const parent = (0, world_1.getArea)(loaded, parentId);
    (0, world_1.enterArea)(loaded, (0, world_1.player)(loaded), parent.id, parent.start.x, parent.start.y);
    strict_1.default.equal((0, world_1.currentArea)(loaded).id, "dungeon");
});
// ========================================================================= 0.4
(0, node_test_1.test)("0.4 save system v2: v19 migration, RLE compression, multi-slot store, rolling backups, export/import, corruption recovery, size & load budgets", async () => {
    const w = (0, world_1.createWorld)(5150);
    // 1. v19 save still loads through MIGRATIONS[19]
    const v20 = (0, save_1.serialize)(w);
    strict_1.default.equal(v20.version, save_1.SAVE_VERSION);
    const v19 = { ...JSON.parse(JSON.stringify(v20)), version: 19 };
    delete v19.specs;
    const migrated = (0, save_1.migrate)(v19);
    strict_1.default.equal(migrated.version, save_1.SAVE_VERSION);
    const fromV19 = (0, save_1.deserialize)(v19);
    strict_1.default.equal((0, world_1.player)(fromV19).area, "dungeon");
    // 2. RLE compression round-trip & threshold engagement on player-built / heavily edited area
    const pb = (0, world_1.createDynamicArea)(w, { id: "player_hall", kind: "dungeon_floor", seed: 123, w: 32, h: 24, depth: 1, playerBuilt: true });
    const encoded = (0, save_1.encodeRle)(pb.grid);
    strict_1.default.deepEqual((0, save_1.decodeRle)(encoded, pb.grid.length), pb.grid);
    const savedWithPb = (0, save_1.serialize)(w);
    strict_1.default.ok(Array.isArray(savedWithPb.areas.player_hall.tilesRle), "player-built area uses RLE full grid");
    strict_1.default.equal(savedWithPb.areas.player_hall.tiles.length, 0);
    const reloadedPb = (0, save_1.deserialize)(savedWithPb);
    strict_1.default.deepEqual((0, world_1.getArea)(reloadedPb, "player_hall").grid, pb.grid);
    // 3. Size & load-time budgets
    const t0 = performance.now();
    const json = (0, save_1.exportSaveJson)(w);
    const imported = (0, save_1.importSaveJson)(json);
    const loadMs = performance.now() - t0;
    strict_1.default.ok(json.length < 250000, `Save size within budget (${json.length} bytes)`);
    strict_1.default.ok(loadMs < 150, `Save/load round-trip within budget (${loadMs.toFixed(1)}ms)`);
    strict_1.default.equal(imported.seed, w.seed);
    strict_1.default.equal((0, save_1.validateSave)({ bad: true }).ok, false);
    // 4. Multi-slot SaveStore + rolling backups + corrupted-save recovery
    const store = new saveStore_1.SaveStore(new saveStore_1.MemorySaveBackend());
    await store.saveSlot("slot-1", w, "First Save");
    w.playTime = 42;
    await store.saveSlot("slot-1", w, "Second Save");
    const slots = await store.listSlots();
    strict_1.default.equal(slots.length, 1);
    strict_1.default.equal(slots[0].backupCount, 1, "rolling backup created on overwrite");
    // Corrupt primary slot and verify automatic recovery from rolling backup #1
    await store.corruptSlotForTest("slot-1");
    const recovered = await store.loadSlot("slot-1");
    strict_1.default.ok(recovered, "recovered from rolling backup");
    strict_1.default.equal(recovered.recoveredFrom, "backup #1");
    strict_1.default.equal(recovered.world.seed, 5150);
    // Export & import through store
    const exported = await store.exportSlotJson("slot-1");
    strict_1.default.ok(exported);
    const impRes = await store.importSlotJson("slot-2", exported, "Imported Slot");
    strict_1.default.equal(impRes.world.seed, 5150);
    strict_1.default.equal((await store.listSlots()).length, 2);
});
// ========================================================================= 0.5
(0, node_test_1.test)("0.5 input & UI v2: mixed-case proportional font, mouse/drag/wheel/context, reusable components, notification feed & pause-on-alert", () => {
    // Mixed-case proportional font: narrower 'i'/'l' than 'M'/'W', supports lowercase + descenders
    strict_1.default.ok((0, propFont_1.propTextWidth)("iii") < (0, propFont_1.propTextWidth)("MMM"), "proportional widths differ");
    strict_1.default.ok((0, propFont_1.propTextWidth)("Dustwake Phase 0") > 40);
    const wrapped = (0, propFont_1.wrapPropText)("The quick brown golem leaps over the lazy rubble", 70);
    strict_1.default.ok(wrapped.length >= 2);
    // Reusable components render cleanly on 640x360 2x UI canvas with mouse input
    const hiCanvas = makeCanvasEl();
    hiCanvas.width = game_1.UI2_W;
    hiCanvas.height = game_1.UI2_H;
    const ctx = hiCanvas.getContext("2d");
    const input = new input_1.InputManager();
    const tips = new components_1.TooltipHost();
    (0, propFont_1.drawPropText)(ctx, "Mixed Case 123 (gjpqy)", 10, 10, "#fff");
    // Click a button
    input.onPointerDown(0, 30, 30, 0, 0, 320, 180);
    input.onPointerUp(0, 30, 30, 0, 0, 320, 180);
    strict_1.default.equal((0, components_1.hiButton)(ctx, { x: 10, y: 20, w: 80, h: 20 }, "Click Me", input.pointer, {}, tips), true);
    input.endFrame();
    // Drag-select in world coordinates
    input.onPointerDown(0, 100, 100, 10, 20, 320, 180);
    input.onPointerMove(200, 200, 10, 20, 320, 180);
    strict_1.default.ok(input.pointer.drag?.active, "drag-select becomes active past threshold");
    input.onPointerUp(0, 200, 200, 10, 20, 320, 180);
    strict_1.default.ok(input.pointer.dragFinished, "dragFinished emitted on release");
    strict_1.default.equal(input.pointer.dragFinished.wx0, 10 + (100 / game_1.UI2_W) * 320);
    input.endFrame();
    // Slider, Toggle, Tabs, ScrollList, Table, Graph, Modal, ContextMenu
    input.onPointerDown(0, 150, 50, 0, 0, 320, 180);
    const sl = (0, components_1.hiSlider)(ctx, { x: 100, y: 40, w: 100, h: 20 }, 0, 0, 1, 0.1, input.pointer);
    strict_1.default.ok(sl !== null && sl >= 0.4 && sl <= 0.6);
    input.endFrame();
    (0, components_1.hiToggle)(ctx, { x: 10, y: 10, w: 60, h: 16 }, true, input.pointer);
    (0, components_1.hiTabs)(ctx, { x: 10, y: 30, w: 200, h: 18 }, [{ id: "a", label: "Tab A" }, { id: "b", label: "Tab B" }], "a", input.pointer);
    (0, components_1.hiScrollList)(ctx, { x: 10, y: 60, w: 120, h: 80 }, ["Row 1", "Row 2", "Row 3"], 16, { scroll: 0, selected: 0 }, input, () => { });
    (0, components_1.hiTable)(ctx, { x: 140, y: 60, w: 200, h: 80 }, [{ id: "n", label: "Name", w: 100, value: (x) => x }], ["Alpha", "Beta"], { scroll: 0, selected: 0, sortCol: "n", sortAsc: true }, input);
    (0, components_1.hiGraph)(ctx, { x: 350, y: 60, w: 120, h: 50 }, [1.2, 2.4, 3.1, 2.0], { label: "Sim", unit: "ms" });
    (0, components_1.hiModal)(ctx, { x: 60, y: 40, w: 500, h: 260 }, "Test Modal", "sub", input.pointer);
    const cm = new components_1.ContextMenu();
    let ran = false;
    cm.show(200, 150, [{ id: "act", label: "Inspect", action: () => { ran = true; } }], "Menu");
    cm.updateAndRender(ctx, input.pointer, (...k) => k.includes("enter"));
    strict_1.default.equal(ran, true, "ContextMenu supports keyboard Enter parity");
    // Notification feed + pause-on-alert
    const feed = new notifications_1.NotificationFeed();
    const s = { ...settings_1.DEFAULT_SETTINGS, pauseOnAlert: true, pauseOnJobBlocked: true };
    const r1 = feed.push({ title: "Info note", severity: "info", category: "world" }, s);
    strict_1.default.equal(r1.pause, false);
    const r2 = feed.push({ title: "Critical Alert", severity: "alert", category: "world" }, s);
    strict_1.default.equal(r2.pause, true, "pauseOnAlert triggers pause on alert severity");
    const r3 = feed.push({ title: "Worker blocked", severity: "warn", category: "worker" }, s);
    strict_1.default.equal(r3.pause, true, "pauseOnJobBlocked triggers pause on worker warn");
    strict_1.default.equal(feed.unreadCount(), 3);
});
// ========================================================================= 0.6 & 0.7
(0, node_test_1.test)("0.6 split host & 0.7 settings/accessibility: volume, palettes, key remapping, registry, Game integration", () => {
    const settings = new settings_1.SettingsStore();
    // Extensible settings registry
    (0, settings_1.registerSetting)({
        id: "phase0_test_opt",
        category: "gameplay",
        kind: "toggle",
        label: "Test Option",
        get: (st) => Boolean(st.extra.testOpt),
        set: (st, v) => { st.extra.testOpt = v; },
    });
    strict_1.default.ok((0, settings_1.registeredSettings)("gameplay").some((d) => d.id === "phase0_test_opt"));
    // Color-blind palettes distinct & valid hex
    for (const pal of Object.keys(vision_1.OVERLAY_PALETTES)) {
        strict_1.default.match((0, vision_1.visionColor)("important", pal), /^#[0-9a-f]{6}$/i);
        strict_1.default.match((0, vision_1.visionColor)("buildable", pal), /^#[0-9a-f]{6}$/i);
    }
    strict_1.default.notEqual((0, vision_1.visionColor)("buildable", "default"), (0, vision_1.visionColor)("buildable", "deuteranopia"));
    // Key remapping
    settings.rebind("pause", "f8");
    strict_1.default.ok(settings.keysFor("pause").includes("f8"));
    settings.resetKeybinds();
    strict_1.default.ok(settings.keysFor("pause").includes("p"));
    // Split host smoke check (Game uses Camera, ParticleSystem, WorldRenderer, SimClock)
    const g = new game_1.Game(makeCanvasEl(), makeCanvasEl(), makeCanvasEl());
    g.resume((0, world_1.createWorld)(99));
    g.setSpeed(4);
    strict_1.default.equal(g.clock.speed, 4);
    const beforeTime = g.world.time;
    g.update(clock_1.SIM_DT);
    strict_1.default.ok(g.world.time - beforeTime >= clock_1.SIM_DT * 3.9, "4x speed advances 4 fixed ticks per frame");
    g.render();
    g.dispose();
});
// ========================================================================= 0.8 + 0.2 frame budget
(0, node_test_1.test)("0.8 content linter: every content row resolves and fits bitmap font", () => {
    const res = (0, contentLint_1.lintAllContent)();
    strict_1.default.ok(res.checked > 200, `checked ${res.checked} content rows`);
    strict_1.default.deepEqual(res.errors, [], `Content lint errors:\n${res.errors.map((e) => `${e.table}:${e.row}: ${e.message}`).join("\n")}`);
});
(0, node_test_1.test)("0.2 & 0.8 300-actor headless soak test: invariants and frame budget hold", () => {
    const report = (0, soak_1.runSoak)({
        actors: 300,
        days: 0.15, // 108 in-game seconds (~3240 ticks at 1/30s) across Active/Near/Far
        tickDt: 1 / 30,
        seed: 2026,
        maxStuckSeconds: 15,
        frameBudgetMs: 12,
        checkRoundTrip: true,
    });
    strict_1.default.equal(report.actors, 300);
    strict_1.default.ok(report.lodCounts.active > 0 && report.lodCounts.far > 0, "LOD tiers engaged during soak");
    strict_1.default.ok(report.avgTickMs <= 12, `300-actor avg tick ${report.avgTickMs.toFixed(2)}ms exceeded 12ms budget`);
    strict_1.default.deepEqual(report.violations, [], `Soak violations:\n${report.violations.join("\n")}`);
});
