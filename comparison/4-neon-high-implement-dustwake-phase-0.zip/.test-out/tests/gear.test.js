"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Gear: the basket is picked up like any item, worn in the golem's back slot
// from the pack (capacity 48), and taken off only if everything, the basket
// included, still fits. Headless, through the sim commands the pack screen uses.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const inventory_1 = require("../src/game/sim/inventory");
const commands_1 = require("../src/game/sim/commands");
const gear_1 = require("../src/game/sim/gear");
const tasks_1 = require("../src/game/sim/tasks");
const flags_1 = require("../src/game/content/flags");
const helpers_1 = require("./helpers");
const slotOf = (w, id) => (0, world_1.player)(w).inventory.findIndex((s) => s?.item === id);
const onGround = (w) => [...w.areas.values()].flatMap((a) => a.loose.filter((l) => l.dyn && !l.taken));
/** Everything the golem owns, by item: pack plus worn gear. */
function owned(w) {
    const pl = (0, world_1.player)(w), m = {};
    for (const s of pl.inventory)
        if (s)
            m[s.item] = (m[s.item] ?? 0) + s.n;
    for (const id of Object.values(pl.gear))
        if (id)
            m[id] = (m[id] ?? 0) + 1;
    return m;
}
/** A golem with the iron arm (16 slots) that has picked up the surface basket. */
function withBasket() {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
    (0, world_1.enterArea)(w, pl, "surface", 100, 100);
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.looseId === "basket"));
    (0, helpers_1.events)(w);
    return { w, pl };
}
(0, node_test_1.test)("picking up the basket stores it like any item: no attach animation, no equip ceremony", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, world_1.enterArea)(w, pl, "surface", 100, 100);
    (0, helpers_1.events)(w);
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.looseId === "basket"));
    const ev = (0, helpers_1.events)(w);
    strict_1.default.ok((0, inventory_1.hasItem)(pl, "basket"), "in the pack");
    strict_1.default.ok((0, world_1.currentArea)(w).looseItem("basket").taken);
    strict_1.default.ok(ev.some((e) => e.t === "itemGained" && e.item === "basket" && e.stored), "ordinary pickup feedback");
    strict_1.default.ok(!ev.some((e) => e.t === "equipped" || e.t === "gearOn"), "nothing installed or worn");
    strict_1.default.ok(!ev.some((e) => e.t === "taskTick" && e.task.kind === "attach"), "no attach task");
    strict_1.default.equal((0, gear_1.wornIn)(pl, "back"), undefined);
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 8, "carrying it grants nothing");
});
(0, node_test_1.test)("the iron arm's pickup is unchanged: attached with the ceremony, never stored", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "limbrack@65.5,3"));
    const ev = (0, helpers_1.events)(w);
    strict_1.default.ok(ev.some((e) => e.t === "taskTick" && e.task.kind === "attach"));
    strict_1.default.ok(ev.some((e) => e.t === "equipped" && e.item === "arm"));
    strict_1.default.ok((0, world_1.hasFlag)(w, flags_1.FLAGS.golemArm) && !(0, inventory_1.hasItem)(pl, "arm"));
});
(0, node_test_1.test)("wearing the basket moves it to the back slot and raises capacity; taking it off lowers it again", () => {
    const { w, pl } = withBasket();
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 16);
    strict_1.default.equal((0, commands_1.wearFromSlot)(w, pl, slotOf(w, "basket")), "ok");
    strict_1.default.equal((0, gear_1.wornIn)(pl, "back"), "basket");
    strict_1.default.ok(!(0, inventory_1.hasItem)(pl, "basket"), "out of the pack");
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 48);
    strict_1.default.equal(pl.inventory.length, 48, "the new slots appear at once (the pack is open, the world paused)");
    let ev = (0, helpers_1.events)(w);
    strict_1.default.ok(ev.some((e) => e.t === "gearOn" && e.item === "basket" && e.slot === "back"));
    strict_1.default.ok(!ev.some((e) => e.t === "equipped" || e.t === "taskTick"), "no iron-arm ceremony");
    strict_1.default.equal((0, commands_1.takeOffGear)(w, pl, "back"), "ok");
    strict_1.default.equal((0, gear_1.wornIn)(pl, "back"), undefined);
    strict_1.default.ok((0, inventory_1.hasItem)(pl, "basket"), "back in the pack");
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 16);
    strict_1.default.equal(pl.inventory.length, 16);
    ev = (0, helpers_1.events)(w);
    strict_1.default.ok(ev.some((e) => e.t === "gearOff" && e.item === "basket"));
    (0, inventory_1.addItems)(w, pl, "coin", 1);
    strict_1.default.equal((0, commands_1.wearFromSlot)(w, pl, slotOf(w, "coin")), "notWearable");
    strict_1.default.equal((0, commands_1.takeOffGear)(w, pl, "back"), "empty", "nothing worn");
    strict_1.default.equal(onGround(w).length, 0);
});
(0, node_test_1.test)("taking it off is refused when the basket itself would need a 17th slot; nothing changes; one free slot is enough", () => {
    const { w, pl } = withBasket();
    (0, commands_1.wearFromSlot)(w, pl, slotOf(w, "basket"));
    for (let i = 0; i < 13; i++)
        (0, inventory_1.addItems)(w, pl, "stone", 20);
    for (const id of ["coin", "crown", "goblet"])
        (0, inventory_1.addItems)(w, pl, id, 1);
    strict_1.default.equal(pl.inventory.filter(Boolean).length, 16, "exactly what 16 slots hold");
    (0, helpers_1.events)(w);
    const before = JSON.stringify([pl.inventory, pl.gear]);
    strict_1.default.equal((0, gear_1.takeOffCheck)(w, pl, "back").ok, false);
    strict_1.default.equal((0, commands_1.takeOffGear)(w, pl, "back"), "noRoom");
    strict_1.default.equal(JSON.stringify([pl.inventory, pl.gear]), before, "nothing changed");
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 48);
    const msg = (0, helpers_1.events)(w).find((e) => e.t === "message");
    strict_1.default.ok(msg?.t === "message" && /TOO MUCH TO CARRY WITHOUT THE WOVEN BASKET - FREE 1 SLOT$/.test(msg.text), "a clear refusal");
    (0, helpers_1.frames)(w, 5);
    strict_1.default.equal(onGround(w).length, 0, "nothing dropped");
    // Drop one relic: 15 slots plus the basket fill the 16 exactly.
    strict_1.default.equal((0, commands_1.dropFromSlot)(w, pl, slotOf(w, "goblet")), "ok");
    const own = owned(w), ground = onGround(w).length;
    strict_1.default.equal((0, commands_1.takeOffGear)(w, pl, "back"), "ok");
    strict_1.default.deepEqual(owned(w), own, "nothing lost");
    strict_1.default.equal(pl.inventory.filter(Boolean).length, 16, "the basket took the last slot");
    (0, helpers_1.frames)(w, 5);
    strict_1.default.equal(onGround(w).length, ground, "nothing dropped");
});
(0, node_test_1.test)("the fit check counts stacking: half stacks that merge make room, and repacking loses nothing", () => {
    const { w, pl } = withBasket();
    (0, commands_1.wearFromSlot)(w, pl, slotOf(w, "basket"));
    const fill = (woodB) => {
        pl.inventory.fill(null);
        pl.inventory[0] = { item: "wood", n: 10 };
        pl.inventory[1] = { item: "wood", n: woodB };
        for (let i = 0; i < 12; i++)
            pl.inventory[2 + i] = { item: "stone", n: 20 };
        pl.inventory[30] = { item: "coin", n: 1 };
        pl.inventory[47] = { item: "crown", n: 1 };
    };
    // 15 slots in use, but 10 + 11 wood needs two slots: with the basket that is 17.
    fill(11);
    const before = JSON.stringify(pl.inventory);
    strict_1.default.equal((0, commands_1.takeOffGear)(w, pl, "back"), "noRoom");
    strict_1.default.equal(JSON.stringify(pl.inventory), before);
    // 10 + 10 wood merge into one stack: 16 exactly, items far beyond slot 16 included.
    fill(10);
    const own = owned(w);
    strict_1.default.equal((0, commands_1.takeOffGear)(w, pl, "back"), "ok");
    strict_1.default.deepEqual(owned(w), own, "nothing lost");
    strict_1.default.equal(pl.inventory.length, 16);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "wood"), 20);
    strict_1.default.ok((0, inventory_1.hasItem)(pl, "coin") && (0, inventory_1.hasItem)(pl, "crown") && (0, inventory_1.hasItem)(pl, "basket"));
    (0, helpers_1.frames)(w, 5);
    strict_1.default.equal(onGround(w).length, 0);
});
(0, node_test_1.test)("taking it off keeps the pack's order where it can: only items beyond the smaller pack move", () => {
    const { w, pl } = withBasket();
    (0, commands_1.wearFromSlot)(w, pl, slotOf(w, "basket"));
    pl.inventory.fill(null);
    pl.inventory[0] = { item: "wood", n: 5 };
    pl.inventory[3] = { item: "crown", n: 1 };
    pl.inventory[20] = { item: "wood", n: 7 };
    pl.inventory[40] = { item: "goblet", n: 1 };
    strict_1.default.equal((0, commands_1.takeOffGear)(w, pl, "back"), "ok");
    strict_1.default.deepEqual(pl.inventory.slice(0, 5), [{ item: "wood", n: 12 }, { item: "goblet", n: 1 }, { item: "basket", n: 1 }, { item: "crown", n: 1 }, null]);
});
(0, node_test_1.test)("the worn basket survives save/load; v7 saves with it installed migrate to wearing it", () => {
    const { w, pl } = withBasket();
    (0, commands_1.wearFromSlot)(w, pl, slotOf(w, "basket"));
    (0, inventory_1.addItems)(w, pl, "wood", 300);
    const w2 = (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
    strict_1.default.equal((0, gear_1.wornIn)((0, world_1.player)(w2), "back"), "basket");
    strict_1.default.equal((0, inventory_1.capacity)(w2, (0, world_1.player)(w2)), 48);
    strict_1.default.deepEqual((0, save_1.serialize)(w2), (0, save_1.serialize)(w));
    // v7: the installed basket was the world flag golem.basket, and actors had no gear.
    const s = (0, save_1.serialize)(w);
    const v7 = { ...s, version: 7, flags: [...s.flags, "golem.basket"], actors: s.actors.map(({ gear: _g, ...a }) => a) };
    const w3 = (0, save_1.deserialize)(v7), p3 = (0, world_1.player)(w3);
    strict_1.default.equal((0, gear_1.wornIn)(p3, "back"), "basket");
    strict_1.default.ok(!w3.flags.has("golem.basket"), "the flag is retired");
    strict_1.default.equal((0, inventory_1.capacity)(w3, p3), 48, "same capacity");
    strict_1.default.deepEqual(p3.inventory, pl.inventory, "the pack is untouched");
    for (const a of w3.actors)
        strict_1.default.deepEqual(a.gear, a.id === p3.id ? { back: "basket" } : {}, a.id);
    (0, helpers_1.frames)(w3, 5);
    strict_1.default.equal((0, inventory_1.countItem)(p3, "wood"), 300);
    strict_1.default.equal(onGround(w3).length, 0, "no overflow");
    // A v7 save made mid-attach (picked up, still attaching) ends worn, with no stale task left to fire.
    const s7 = (0, save_1.serialize)((0, helpers_1.newWorld)());
    s7.version = 7;
    s7.actors = s7.actors.map(({ gear: _g, ...a }) => (a.id === s7.playerId ? { ...a, task: { kind: "attach", dur: 1.2, t: 0.3, fired: false, effect: { op: "equip", item: "basket" }, area: a.area } } : a));
    const w5 = (0, save_1.deserialize)(s7), p5 = (0, world_1.player)(w5);
    strict_1.default.equal((0, gear_1.wornIn)(p5, "back"), "basket");
    strict_1.default.equal(p5.task, null);
    strict_1.default.equal((0, inventory_1.capacity)(w5, p5), 48);
    // A v7 save without it: nobody wears anything.
    const s8 = (0, save_1.serialize)((0, helpers_1.newWorld)());
    const w6 = (0, save_1.deserialize)({ ...s8, version: 7, actors: s8.actors.map(({ gear: _g, ...a }) => a) });
    strict_1.default.ok(w6.actors.every((a) => Object.keys(a.gear).length === 0));
});
(0, node_test_1.test)("Ctrl+4's kit leaves the golem wearing the basket: the pack's one if it has it, else a new one, never two", () => {
    const { w, pl } = withBasket();
    strict_1.default.ok((0, gear_1.ensureWorn)(w, pl, "basket"));
    strict_1.default.equal((0, gear_1.wornIn)(pl, "back"), "basket");
    strict_1.default.ok(!(0, inventory_1.hasItem)(pl, "basket"), "the pack's basket was put on");
    strict_1.default.ok((0, gear_1.ensureWorn)(w, pl, "basket"));
    strict_1.default.equal(owned(w).basket, 1, "already worn: nothing added");
    const w2 = (0, helpers_1.newWorld)(), p2 = (0, world_1.player)(w2);
    strict_1.default.ok((0, gear_1.ensureWorn)(w2, p2, "basket"));
    strict_1.default.equal((0, gear_1.wornIn)(p2, "back"), "basket");
    strict_1.default.equal((0, inventory_1.capacity)(w2, p2), 48);
    strict_1.default.equal(p2.inventory.length, 48);
});
(0, node_test_1.test)("gear is actor state, not a world flag: another actor can wear a basket through its task queue", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    const other = (0, world_1.makeActor)("golem2", "golem", "dungeon", pl.x + 24, pl.y);
    w.actors.push(other);
    (0, inventory_1.addItems)(w, other, "basket", 1);
    (0, tasks_1.enqueueTask)(other, { kind: "reach", dur: 0.3, effect: { op: "wear", slot: 0 } });
    (0, helpers_1.frames)(w, 30);
    strict_1.default.equal((0, gear_1.wornIn)(other, "back"), "basket");
    strict_1.default.equal((0, inventory_1.capacity)(w, other), 48);
    strict_1.default.equal((0, gear_1.wornIn)(pl, "back"), undefined);
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 8, "the player's pack is unaffected");
    strict_1.default.ok(![...w.flags].some((f) => f.includes("basket")), "no world flag");
});
