"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The tutorial dungeon's audit, kept: the layout checks the town gets
// (tests/support/townAudit.ts) run over the dungeon with the findings that are
// there by design named one by one, and the things the audit fixed pinned so
// they stay fixed (the throne hall's colonnade, the cracked wall as wall mass,
// the barracks' beds and footlockers, the chapel's axis, roots off the walls).
// Headless: the builder, the content tables and the recording fake canvas only.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const townAudit_1 = require("./support/townAudit");
const map_1 = require("../src/game/map");
const tiles_1 = require("../src/game/content/tiles");
const props_1 = require("../src/game/art/props");
const tiles_2 = require("../src/game/art/tiles");
const d = (0, map_1.buildDungeon)();
const tile = (x, y) => d.grid[y * map_1.MW + x];
const props = (kind) => d.props.filter((p) => p.kind === kind);
(0, node_test_1.test)("the layout audit finds nothing in the dungeon but what is there by design", () => {
    const found = (0, townAudit_1.auditArea)("dungeon");
    // boulders heaped on the collapsed SURFACE GATE's rubble, and the seam of night air buried in it
    // and under the same fall the stair's own stonework: its two newel posts and two cheek walls stand in the rubble
    // that buries the flight (floor once it is dug out), and the fall's boulders lie heaped against them
    const stonework = /stair(post|cheek)\.[we] /;
    const buried = found.filter((f) => stonework.test(f.msg) && (f.check === "in-wall" || ((f.check === "crowded" || f.check === "overlap") && f.msg.startsWith("rockpile@"))));
    strict_1.default.equal(buried.filter((f) => f.check === "in-wall").length, 4, buried.map((f) => f.msg).join("\n"));
    const gate = found.filter((f) => (f.check === "in-wall" && f.msg.startsWith("rockpile@")) || f.check === "light" || buried.includes(f));
    // the throne hall (behind the cracked wall), the treasury (behind the locked door) and two gaol cells (behind bars)
    const sealed = found.filter((f) => f.check === "sealed");
    strict_1.default.equal(sealed.length, 4, sealed.map((f) => f.msg).join("\n"));
    const rest = found.filter((f) => !gate.includes(f) && !sealed.includes(f));
    strict_1.default.deepEqual(rest.map((f) => `[${f.check}] ${f.msg}`), []);
});
(0, node_test_1.test)("no pillar stands on the capital of the one in front of it", () => {
    const rows = Math.ceil((0, tiles_2.pillarSprite)(false).h / tiles_1.TS); // how many tiles tall a whole pillar is drawn
    let n = 0;
    for (let y = 0; y < d.h; y++)
        for (let x = 0; x < d.w; x++) {
            if (tile(x, y) !== tiles_1.T.PILLAR)
                continue;
            n++;
            for (let k = 1; k <= rows; k++)
                strict_1.default.notEqual(tile(x, y + k), tiles_1.T.PILLAR, `pillars at ${x},${y} and ${x},${y + k} are drawn into each other`);
        }
    strict_1.default.equal(n, 16, "ten in the great hall, six in the throne hall");
});
(0, node_test_1.test)("the cracked wall is part of the wall it stands in until it is broken", () => {
    strict_1.default.ok((0, tiles_1.isWallMassT)(tiles_1.T.CRACKED) && (0, tiles_1.isSolidT)(tiles_1.T.CRACKED) && (0, tiles_1.isOpaqueT)(tiles_1.T.CRACKED));
    strict_1.default.ok(!(0, tiles_1.isWallMassT)(tiles_1.T.FLOOR) && !(0, tiles_1.isWallMassT)(tiles_1.T.RUBBLE), "broken, it is floor: the wall above shows its face again");
    for (let y = 0; y < d.h; y++)
        for (let x = 0; x < d.w; x++) {
            if (tile(x, y) !== tiles_1.T.CRACKED)
                continue;
            // flush with wall (or more cracked wall) above and below, open floor to either side
            for (const dy of [-1, 1])
                strict_1.default.ok(tile(x, y + dy) === tiles_1.T.WALL || tile(x, y + dy) === tiles_1.T.CRACKED, `cracked wall at ${x},${y} is not built into the wall`);
            for (const dx of [-1, 1])
                strict_1.default.equal(tile(x + dx, y), tiles_1.T.FLOOR);
        }
});
(0, node_test_1.test)("every footlocker stands at the foot of its bed, and all four bed variants exist", () => {
    const beds = props("bed");
    for (const f of props("footlocker")) {
        const bed = beds.filter((b) => b.x === f.x).sort((a, b) => Math.abs(a.y - f.y) - Math.abs(b.y - f.y))[0];
        strict_1.default.ok(bed, `${f.id} has no bed`);
        // bed v bit 1: the head lies to the south. A locker below its bed wants the head north, one above it the head south.
        strict_1.default.equal((bed.v & 2) === 2, f.y < bed.y, `${f.id} stands at the head of ${bed.id}`);
    }
    // all four variants exist and are one size
    for (let v = 0; v < 4; v++) {
        const s = (0, props_1.propSprite)("bed", v, false);
        strict_1.default.deepEqual([s.w, s.h], [16, 30]);
    }
});
(0, node_test_1.test)("the chapel keeps one axis: the banner, the altar under it, the pews facing them", () => {
    const altar = d.props.find((p) => p.id === "altar@26,48"), banner = d.props.find((p) => p.id === "banner@23,46");
    strict_1.default.equal(banner.x, altar.x);
    for (const pew of props("pew"))
        strict_1.default.equal(pew.x, altar.x);
    strict_1.default.ok(banner.y < altar.y && props("pew").every((p) => p.y > altar.y));
});
(0, node_test_1.test)("roots trail across floor and rubble, never across the top of a wall", () => {
    const roots = d.decals.filter((dc) => dc.kind === "rootfall");
    strict_1.default.ok(roots.length >= 5);
    for (const r of roots)
        for (const [dx, dy] of [[-9, 0], [9, 0], [-9, 22], [9, 22]]) {
            const tx = Math.floor((r.x + dx) / tiles_1.TS), ty = Math.floor((r.y + dy) / tiles_1.TS);
            strict_1.default.notEqual(tile(tx, ty), tiles_1.T.WALL, `a root at ${(r.x / tiles_1.TS).toFixed(1)},${(r.y / tiles_1.TS).toFixed(1)} runs over the wall at ${tx},${ty}`);
        }
});
