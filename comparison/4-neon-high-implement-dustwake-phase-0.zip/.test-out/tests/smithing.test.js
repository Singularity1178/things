"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Iron, tools and the two new stations: ore on the surface, the smelter, the
// anvil's four jobs, tool heads on the arm slots, hafted tools for workers,
// and the rooms they stand in. Headless, through the same sim entry points the
// play screen uses.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const world_1 = require("../src/game/world/world");
const flags_1 = require("../src/game/content/flags");
const items_1 = require("../src/game/content/items");
const items_2 = require("../src/game/art/items");
const props_1 = require("../src/game/art/props");
const props_2 = require("../src/game/content/props");
const harvest_1 = require("../src/game/content/harvest");
const build_1 = require("../src/game/content/build");
const crafting_1 = require("../src/game/content/crafting");
const tools_1 = require("../src/game/content/tools");
const gear_1 = require("../src/game/content/gear");
const font_1 = require("../src/game/font");
const vision_1 = require("../src/game/content/vision");
const inventory_1 = require("../src/game/sim/inventory");
const crafting_2 = require("../src/game/sim/crafting");
const commands_1 = require("../src/game/sim/commands");
const gear_2 = require("../src/game/sim/gear");
const tools_2 = require("../src/game/sim/tools");
const harvesting_1 = require("../src/game/sim/harvesting");
const step_1 = require("../src/game/sim/step");
const tasks_1 = require("../src/game/sim/tasks");
const map_1 = require("../src/game/map");
const surface_1 = require("../src/game/surface");
const town_1 = require("../src/game/content/town");
const areas_1 = require("../src/game/world/areas");
const geography_1 = require("../src/game/content/geography");
const helpers_1 = require("./helpers");
const TOWN_AREAS = [town_1.TOWN_ID, ...town_1.ESTABLISHMENTS.map(town_1.interiorId)];
const FORGE = "forge@5.5,37", ANVIL = "anvil@6,40", BENCH = "workbench@13.5,37";
const slotOf = (w, id) => (0, world_1.player)(w).inventory.findIndex((s) => s?.item === id);
const wear = (w, id) => (0, commands_1.wearFromSlot)(w, (0, world_1.player)(w), slotOf(w, id));
const text = (s) => [...s].every((ch) => font_1.FONT_GLYPHS.has(ch));
/** Stand at a station, open it with E, and return its prop id. */
function openStation(w, propId) {
    (0, helpers_1.events)(w);
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "station" && i.propId === propId));
    return (0, helpers_1.events)(w).find((e) => e.t === "openStation");
}
/** Press the station's action button for a row and let the golem finish the work. */
function make(w, station, propId, recipe) {
    const pl = (0, world_1.player)(w);
    const ok = (0, crafting_2.orderCraft)(w, pl, station, recipe, propId);
    let guard = 0;
    while (pl.task && guard++ < 2000)
        (0, helpers_1.frame)(w);
    (0, helpers_1.frames)(w, 5);
    return ok;
}
// ------------------------------------------------------------------ data
(0, node_test_1.test)("tool rows: three types; a head plain, rusted, fine and with either rune set in it; a hafted tool plain and fine; all named, described and drawn", () => {
    strict_1.default.deepEqual([...tools_1.TOOL_TYPE_IDS], ["shovel", "pickaxe", "axe"]);
    for (const t of tools_1.TOOL_TYPE_IDS) {
        const head = items_1.ITEMS[(0, tools_1.headId)(t)], fine = items_1.ITEMS[(0, tools_1.fineHeadId)(t)], rusted = items_1.ITEMS[(0, tools_1.rustedHeadId)(t)], full = items_1.ITEMS[(0, tools_1.fullToolId)(t)], fineFull = items_1.ITEMS[(0, tools_1.fineToolId)(t)];
        strict_1.default.deepEqual(head.wear, { kind: "arm" }, `${t}: a head is gear for an arm slot`);
        strict_1.default.deepEqual(head.tool, { type: t, form: "head", bonus: 1 });
        strict_1.default.equal(fine.tool.bonus, 2);
        strict_1.default.deepEqual(fine.wear, { kind: "arm" });
        strict_1.default.ok(!rusted.tool && !rusted.wear, `${t}: a rusted head does nothing until it is repaired`);
        strict_1.default.ok(!full.wear && full.tool.form === "full" && fineFull.tool.bonus > full.tool.bonus, `${t}: a hafted tool is for hands, not for an arm slot`);
        for (const r of tools_1.TOOL_RUNES) {
            const set = items_1.ITEMS[(0, tools_1.runedHeadId)(t, r)];
            strict_1.default.equal(set.tool.bonus, fine.tool.bonus, "a rune only goes into a tempered head");
            strict_1.default.ok(set.worn && !set.worn.mark, "it carries the rune's effect; the sigil is drawn for rune slots only");
        }
        strict_1.default.equal(items_1.ITEMS[(0, tools_1.runedHeadId)(t, "swift")].worn.speed, gear_1.RUNE_SWIFT_SPEED_BONUS);
        strict_1.default.equal(items_1.ITEMS[(0, tools_1.runedHeadId)(t, "glow")].worn.light, gear_1.RUNE_GLOW_LIGHT);
    }
    // the pack's limits: a name of at most 20, up to three lines of 34 counting the generated effect lines, font glyphs only
    const fresh = items_1.ITEM_IDS.filter((id) => items_1.ITEMS[id].tool || /^head_|^iron_|^dirt$/.test(id));
    strict_1.default.equal(fresh.length, 3 * 7 + 3, "21 tool rows, and iron ore, iron ingot and dirt");
    for (const id of fresh) {
        const d = items_1.ITEMS[id], lines = [...(d.desc ?? []), ...(0, items_1.effectLines)(id)];
        strict_1.default.ok(d.name.length <= 20 && text(d.name), `${id}: name "${d.name}"`);
        strict_1.default.ok(lines.length >= 1 && lines.length <= 3, `${id}: ${lines.length} lines`);
        for (const l of lines)
            strict_1.default.ok(l.length <= 34 && text(l), `${id}: "${l}"`);
        strict_1.default.equal(typeof items_2.ITEM_ART[id], "function", `${id}: an icon`);
    }
    strict_1.default.deepEqual(items_1.ITEMS.iron_ore.stack, 20);
    strict_1.default.deepEqual(items_1.ITEMS.dirt.tags, ["material"]);
    strict_1.default.ok((0, items_1.effectLines)("head_pickaxe").some((l) => /ON AN ARM/.test(l) && /X2/.test(l)));
    strict_1.default.ok((0, items_1.effectLines)("head_axe_swift").some((l) => /SPEED/.test(l)), "an inset head lists the rune's effect too");
});
(0, node_test_1.test)("station rows: the smelter turns ore into ingots; the anvil forges, repairs, tempers and sets runes; the bench hafts; all within the screen's limits", () => {
    strict_1.default.deepEqual([...crafting_1.STATION_IDS], ["crafting", "smelting", "smithing"]);
    strict_1.default.deepEqual(crafting_1.STATION_REQUIRES.crafting, { flags: [flags_1.FLAGS.knowBuild] });
    strict_1.default.deepEqual(crafting_1.STATION_REQUIRES.smelting, { flags: [flags_1.FLAGS.knowSmelt] }, "smelting has its own knowledge, read off a smelter");
    strict_1.default.equal(props_2.PROPS.forge.station, "smelting");
    strict_1.default.equal(props_2.PROPS.anvil.station, "smithing");
    strict_1.default.equal(props_2.PROPS.workbench.station, "crafting");
    strict_1.default.deepEqual((0, crafting_1.craftRecipesFor)("smelting").map((r) => r.id), ["iron_ingot", "iron_ingot_charge"]);
    for (const r of (0, crafting_1.craftRecipesFor)("smelting")) {
        strict_1.default.ok(r.inputs.some((c) => c.item === "iron_ore") && r.inputs.some((c) => c.item === "wood"));
        strict_1.default.equal(r.output.item, "iron_ingot");
    }
    strict_1.default.equal((0, crafting_1.rawValue)("iron_ingot"), 1.5, "valued by the single-ingot row, not the full charge");
    const tabs = crafting_1.STATIONS.smithing.tabs;
    strict_1.default.deepEqual(tabs.map((t) => t.id), ["forge", "repair", "modify", "runes"]);
    const smith = (0, crafting_1.craftRecipesFor)("smithing"), tab = (id) => smith.filter((r) => r.tab === id);
    strict_1.default.ok(smith.every((r) => tabs.some((t) => t.id === r.tab)), "every anvil row is on a tab");
    strict_1.default.deepEqual(tab("forge").map((r) => r.output.item), tools_1.TOOL_TYPE_IDS.map(tools_1.headId));
    for (const t of tools_1.TOOL_TYPE_IDS) {
        strict_1.default.deepEqual(tab("forge").find((r) => r.id === (0, tools_1.headId)(t)).inputs, [{ item: "iron_ingot", n: tools_1.FORGE_COST[t] }]);
        const rep = tab("repair").find((r) => r.id === `repair_${(0, tools_1.headId)(t)}`);
        strict_1.default.equal(rep.work, (0, tools_1.rustedHeadId)(t));
        strict_1.default.equal(rep.output.item, (0, tools_1.headId)(t));
        strict_1.default.ok(rep.inputs.find((c) => c.item === "iron_ingot").n < tools_1.FORGE_COST[t], "mending costs less iron than forging");
        strict_1.default.equal(tab("modify").find((r) => r.id === `temper_${(0, tools_1.headId)(t)}`).output.item, (0, tools_1.fineHeadId)(t));
        strict_1.default.equal(tab("modify").find((r) => r.id === `temper_${t}`).output.item, (0, tools_1.fineToolId)(t));
        for (const r of tools_1.TOOL_RUNES) {
            const set = tab("runes").find((x) => x.id === `inset_${r}_${t}`), unset = tab("runes").find((x) => x.id === `unset_${r}_${t}`);
            strict_1.default.deepEqual(set.inputs.map((c) => c.item), [(0, tools_1.fineHeadId)(t), `rune_${r}`]);
            strict_1.default.equal(set.output.item, (0, tools_1.runedHeadId)(t, r));
            strict_1.default.equal(unset.output.item, (0, tools_1.fineHeadId)(t));
            strict_1.default.deepEqual(unset.also, [{ item: `rune_${r}`, n: 1 }], "the rune comes back out whole");
        }
        const haft = (0, crafting_1.craftRecipesFor)("crafting").find((r) => r.id === t);
        strict_1.default.deepEqual(haft.inputs.map((c) => c.item), [(0, tools_1.headId)(t), "wood"], "a full tool: a head, some wood, the workbench");
    }
    for (const id of crafting_1.STATION_IDS) {
        const s = crafting_1.STATIONS[id];
        strict_1.default.ok(text(s.name) && text(s.verb) && s.verb.length <= 6 && text(s.lockedText) && text(s.lockedHint) && s.lockedHint.length <= 27, id);
        strict_1.default.ok(props_1.PROP_ART[(0, props_2.propDef)(s.prop).art ?? s.prop], `${id}: its header sprite`);
        for (const t of s.tabs ?? []) {
            strict_1.default.ok(text(t.name) && t.name.length <= 8 && t.verb.length <= 6);
            strict_1.default.ok(t.empty.length <= 3 && t.empty.every((l) => l.length <= 27 && text(l)), t.id);
        }
    }
    for (const r of crafting_1.CRAFT_RECIPES)
        strict_1.default.ok((r.verb ?? "").length <= 6 && (!r.work || r.inputs.some((c) => c.item === r.work)), `${r.id}: the piece it works on is one of its inputs`);
});
// ------------------------------------------------------------------ iron ore
(0, node_test_1.test)("iron ore: veins on the surface, placed without the rng; two bare-handed blows a piece, three pieces a vein; a pickaxe head gets one a blow", () => {
    strict_1.default.deepEqual(harvest_1.HARVEST.ironore, { hp: 6, perHit: { item: "iron_ore", n: 0.5 }, clearBox: true, tool: "pickaxe" });
    const s = (0, surface_1.buildSurface)(), veins = s.props.filter((p) => p.kind === "ironore");
    strict_1.default.equal(veins.length, surface_1.IRON_VEINS);
    strict_1.default.deepEqual((0, surface_1.buildSurface)().props.filter((p) => p.kind === "ironore"), veins, "deterministic");
    const z = geography_1.SURFACE_GATE_ZONE;
    for (const p of veins)
        strict_1.default.ok(!(p.x >= z.x0 * map_1.TS && p.x < (z.x1 + 1) * map_1.TS && p.y >= z.y0 * map_1.TS && p.y < (z.y1 + 1) * map_1.TS), `${p.id} keeps off the stair head`);
    // nothing else in the wild moved to make room for them
    const bare = (0, surface_1.buildSurface)({ iron: false });
    strict_1.default.ok(!bare.props.some((p) => p.kind === "ironore"));
    strict_1.default.deepEqual(s.props.filter((p) => p.kind !== "ironore"), bare.props);
    strict_1.default.deepEqual(s.decals, bare.decals);
    const strike = (w, id, n) => {
        const pl = (0, world_1.player)(w), p = (0, world_1.currentArea)(w).prop(id);
        for (let i = 0; i < n; i++) {
            pl.x = p.x;
            pl.y = p.y + 10;
            pl.vx = 0;
            pl.vy = 0;
            pl.facing = "up";
            (0, helpers_1.slamAt)(w);
        }
        return p;
    };
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, world_1.enterArea)(w, pl, "surface", veins[0].x, veins[0].y + 10);
    strike(w, veins[0].id, 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "iron_ore"), 0, "one blow: nothing yet");
    strike(w, veins[0].id, 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "iron_ore"), 1, "two blows: one piece");
    const p = strike(w, veins[0].id, 4);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "iron_ore"), 3);
    strict_1.default.ok(p.taken, "worked out after three pieces");
    strike(w, veins[0].id, 2);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "iron_ore"), 3, "and it does not grow back");
    // with the pickaxe head on the arm: a piece a blow
    (0, inventory_1.addItems)(w, pl, "head_pickaxe", 1);
    strict_1.default.equal(wear(w, "head_pickaxe"), "ok");
    strike(w, veins[1].id, 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "iron_ore"), 4);
});
// ------------------------------------------------------------------ heads on the arms
(0, node_test_1.test)("a tool head fits an arm slot and multiplies the work of its own resource only; the left arm takes one once the iron arm is on", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, helpers_1.frame)(w);
    const surface = (0, world_1.getArea)(w, "surface"), tree = surface.props.find((p) => p.kind === "tree"), rock = surface.props.find((p) => p.kind === "rock");
    const work = (p) => (0, harvesting_1.harvestStep)(pl, p).damage;
    strict_1.default.equal(work(tree), 1);
    strict_1.default.equal(work(rock), 1);
    (0, inventory_1.addItems)(w, pl, "head_axe", 1);
    strict_1.default.equal(wear(w, "head_axe"), "ok");
    strict_1.default.equal(pl.gear.armR, "head_axe");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "head_axe"), 0);
    strict_1.default.equal((0, tools_2.toolBonus)(pl, "axe"), 1);
    strict_1.default.equal((0, tools_2.toolBonus)(pl, "pickaxe"), 0);
    strict_1.default.equal((0, tools_2.toolBonus)(pl, "shovel"), 0);
    strict_1.default.equal(work(tree), 2, "twice the work on wood");
    strict_1.default.equal(work(rock), 1, "and nothing extra on stone");
    // the left arm: a broken stub takes nothing, so a second head swaps with the first
    strict_1.default.ok(!(0, gear_2.slotUsable)(w, pl, "armL"));
    (0, inventory_1.addItems)(w, pl, "head_pickaxe", 1);
    strict_1.default.equal(wear(w, "head_pickaxe"), "ok");
    strict_1.default.equal(pl.gear.armR, "head_pickaxe");
    strict_1.default.equal(pl.gear.armL, undefined);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "head_axe"), 1);
    // with the iron arm on, the left arm slot is usable and both heads work at once
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
    strict_1.default.ok((0, gear_2.slotUsable)(w, pl, "armL"));
    strict_1.default.equal(wear(w, "head_axe"), "ok");
    strict_1.default.equal(pl.gear.armL, "head_axe");
    strict_1.default.equal(work(tree), 2);
    strict_1.default.equal(work(rock), 2);
    // a tempered head bites deeper; two of a kind do not add up
    strict_1.default.equal((0, commands_1.takeOffGear)(w, pl, "armR"), "ok");
    (0, inventory_1.addItems)(w, pl, "head_axe_fine", 1);
    strict_1.default.equal(wear(w, "head_axe_fine"), "ok");
    strict_1.default.equal(pl.gear.armR, "head_axe_fine");
    strict_1.default.equal((0, tools_2.toolBonus)(pl, "axe"), 2);
    strict_1.default.equal(work(tree), 3);
    // a slot that locks gives its head back to the pack (nothing is lost)
    (0, world_1.clearFlag)(w, flags_1.FLAGS.golemArm);
    (0, helpers_1.frame)(w);
    strict_1.default.equal(pl.gear.armL, undefined);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "head_axe"), 1);
});
(0, node_test_1.test)("a rune set in a head works while the head is on the arm; a hafted tool works for a worker that carries it, not for the maintainer", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, helpers_1.frame)(w);
    (0, inventory_1.addItems)(w, pl, "head_shovel_swift", 1);
    strict_1.default.equal((0, gear_2.speedMultiplier)(w, pl), 1);
    strict_1.default.equal(wear(w, "head_shovel_swift"), "ok");
    strict_1.default.equal((0, gear_2.speedMultiplier)(w, pl), 1 + gear_1.RUNE_SWIFT_SPEED_BONUS, "the rune of swift rides on the arm");
    strict_1.default.equal((0, tools_2.toolBonus)(pl, "shovel"), 2);
    strict_1.default.equal((0, commands_1.takeOffGear)(w, pl, "armR"), "ok");
    strict_1.default.equal((0, gear_2.speedMultiplier)(w, pl), 1);
    (0, inventory_1.addItems)(w, pl, "head_axe_glow", 1);
    strict_1.default.equal(wear(w, "head_axe_glow"), "ok");
    strict_1.default.equal((0, gear_2.golemGlow)(w, pl), gear_1.RUNE_GLOW_LIGHT);
    strict_1.default.equal((0, commands_1.takeOffGear)(w, pl, "armR"), "ok");
    // hafted tools: in the maintainer's pack they are cargo; in a worker's they work
    (0, inventory_1.addItems)(w, pl, "pickaxe", 1);
    strict_1.default.equal((0, tools_2.toolBonus)(pl, "pickaxe"), 0);
    strict_1.default.equal(wear(w, "pickaxe"), "notWearable");
    const worker = (0, world_1.actorById)(w, "npc.worker.artificery");
    strict_1.default.equal((0, tools_2.toolBonus)(worker, "pickaxe"), 0);
    worker.inventory[0] = { item: "pickaxe_fine", n: 1 };
    strict_1.default.equal((0, tools_2.toolBonus)(worker, "pickaxe"), 2);
    strict_1.default.equal((0, tools_2.toolBonus)(worker, "axe"), 0);
    // (the worker's blow is half the maintainer's, and it only lands while it has a core: sim/actorStats.ts)
    worker.powerCore = "ruby_core";
    const rock = (0, world_1.getArea)(w, "surface").props.find((p) => p.kind === "rock");
    strict_1.default.equal((0, harvesting_1.harvestStep)(worker, rock).damage, 0.5 * 3);
});
// ------------------------------------------------------------------ scanning
(0, node_test_1.test)("scanning the smelter teaches smelting and gives the plan to build one; scanning the anvil gives the anvil's plan", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), a = (0, world_1.currentArea)(w);
    (0, helpers_1.frame)(w);
    strict_1.default.equal(build_1.RECIPES.smelter.prop, "forge");
    strict_1.default.equal(build_1.RECIPES.smelter.teaches, flags_1.FLAGS.knowSmelt);
    strict_1.default.equal(build_1.RECIPES.anvil.prop, "anvil");
    strict_1.default.equal(build_1.RECIPES.anvil.teaches, undefined);
    strict_1.default.ok(!build_1.RECIPES.smelter.cost.some((c) => c.item === "iron_ingot"), "the first smelter needs no iron");
    strict_1.default.ok(build_1.RECIPES.anvil.cost.some((c) => c.item === "iron_ingot"));
    // before: the smelter opens, but dark
    strict_1.default.ok((0, crafting_2.craftLocked)(w, pl, "smelting"));
    const ev = openStation(w, FORGE);
    strict_1.default.deepEqual(ev, { t: "openStation", actor: pl.id, prop: FORGE, station: "smelting" });
    strict_1.default.deepEqual((0, crafting_2.craftList)(w, pl, "smelting", FORGE), []);
    (0, helpers_1.events)(w);
    strict_1.default.equal((0, crafting_2.orderCraft)(w, pl, "smelting", "iron_ingot", FORGE), false);
    strict_1.default.deepEqual((0, helpers_1.events)(w), [{ t: "message", text: (0, crafting_2.craftLockedText)("smelting") }]);
    // scan it (Z, then E)
    const scan = (id) => {
        const p = a.prop(id);
        pl.mode = "normal";
        pl.x = p.x;
        pl.y = p.y + 11;
        pl.vx = 0;
        pl.vy = 0;
        pl.facing = "up";
        (0, helpers_1.events)(w);
        (0, step_1.stepPlayer)(w, 0.01, { ix: 0, iy: 0, use: true, toggleScan: true });
        strict_1.default.equal(pl.task?.kind, "scan", id);
        (0, tasks_1.tickTask)(w, pl, 1);
        return (0, helpers_1.events)(w);
    };
    const got = scan(FORGE);
    strict_1.default.ok((0, world_1.hasFlag)(w, (0, vision_1.analysisFlag)("smelter")) && (0, world_1.hasFlag)(w, flags_1.FLAGS.knowSmelt));
    strict_1.default.ok(got.some((e) => e.t === "learned" && e.flag === flags_1.FLAGS.knowSmelt));
    strict_1.default.ok(got.some((e) => e.t === "message" && e.text === "ANALYZED: SMELTER"));
    strict_1.default.ok(!(0, crafting_2.craftLocked)(w, pl, "smelting"));
    strict_1.default.ok(!scan(FORGE).some((e) => e.t === "learned"), "learned once");
    strict_1.default.ok(!(0, world_1.hasFlag)(w, (0, vision_1.analysisFlag)("anvil")));
    const anvil = scan(ANVIL);
    strict_1.default.ok((0, world_1.hasFlag)(w, (0, vision_1.analysisFlag)("anvil")));
    strict_1.default.ok(anvil.some((e) => e.t === "message" && e.text === "ANALYZED: ANVIL") && !anvil.some((e) => e.t === "learned"));
});
// ------------------------------------------------------------------ smelting
(0, node_test_1.test)("the smelter: E opens its screen's station; ore and a wood fire become ingots through the craft task", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, helpers_1.frame)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowSmelt);
    (0, inventory_1.addItems)(w, pl, "iron_ore", 8);
    (0, inventory_1.addItems)(w, pl, "wood", 3);
    strict_1.default.equal(openStation(w, FORGE).t, "openStation");
    const list = (0, crafting_2.craftList)(w, pl, "smelting", FORGE);
    strict_1.default.deepEqual(list.map((e) => [e.recipe.id, e.status]), [["iron_ingot", "ok"], ["iron_ingot_charge", "ok"]]);
    strict_1.default.ok(make(w, "smelting", FORGE, "iron_ingot"));
    strict_1.default.deepEqual([(0, inventory_1.countItem)(pl, "iron_ore"), (0, inventory_1.countItem)(pl, "wood"), (0, inventory_1.countItem)(pl, "iron_ingot")], [6, 2, 2]);
    strict_1.default.ok(make(w, "smelting", FORGE, "iron_ingot_charge"));
    strict_1.default.deepEqual([(0, inventory_1.countItem)(pl, "iron_ore"), (0, inventory_1.countItem)(pl, "wood"), (0, inventory_1.countItem)(pl, "iron_ingot")], [0, 0, 8]);
    (0, helpers_1.events)(w);
    strict_1.default.equal(make(w, "smelting", FORGE, "iron_ingot"), false, "no ore, no ingot");
    strict_1.default.deepEqual((0, helpers_1.events)(w), [{ t: "message", text: "NOT ENOUGH MATERIALS" }]);
    // not at the anvil: a smelting row is the smelter's
    strict_1.default.equal((0, crafting_2.orderCraft)(w, pl, "smithing", "iron_ingot", ANVIL), false);
});
// ------------------------------------------------------------------ smithing
(0, node_test_1.test)("the anvil: forge a head, repair a rusted one, temper it, set a rune in it and pry it out again; each tab lists what was brought", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, helpers_1.frame)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    const tab = (id) => (0, crafting_2.craftList)(w, pl, "smithing", ANVIL, id).map((e) => [e.recipe.id, e.status]);
    strict_1.default.deepEqual(openStation(w, ANVIL), { t: "openStation", actor: pl.id, prop: ANVIL, station: "smithing" });
    // FORGE always lists the three heads; the others list nothing until there is something to work on
    strict_1.default.deepEqual(tab("forge"), [["head_shovel", "cost"], ["head_pickaxe", "cost"], ["head_axe", "cost"]]);
    strict_1.default.deepEqual([tab("repair"), tab("modify"), tab("runes")], [[], [], []]);
    (0, inventory_1.addItems)(w, pl, "iron_ingot", 12);
    strict_1.default.ok(make(w, "smithing", ANVIL, "head_pickaxe"));
    strict_1.default.deepEqual([(0, inventory_1.countItem)(pl, "head_pickaxe"), (0, inventory_1.countItem)(pl, "iron_ingot")], [1, 9]);
    // REPAIR: the rusted shovel head from the artificery floor, for one ingot
    (0, inventory_1.addItems)(w, pl, "head_shovel_rusted", 1);
    strict_1.default.deepEqual(tab("repair"), [["repair_head_shovel", "ok"]]);
    strict_1.default.ok(make(w, "smithing", ANVIL, "repair_head_shovel"));
    strict_1.default.deepEqual([(0, inventory_1.countItem)(pl, "head_shovel_rusted"), (0, inventory_1.countItem)(pl, "head_shovel"), (0, inventory_1.countItem)(pl, "iron_ingot")], [0, 1, 8]);
    strict_1.default.deepEqual(tab("repair"), []);
    // MODIFY: temper what is carried (two heads now: two rows)
    strict_1.default.deepEqual(tab("modify"), [["temper_head_shovel", "ok"], ["temper_head_pickaxe", "ok"]]);
    strict_1.default.ok(make(w, "smithing", ANVIL, "temper_head_shovel"));
    strict_1.default.deepEqual([(0, inventory_1.countItem)(pl, "head_shovel"), (0, inventory_1.countItem)(pl, "head_shovel_fine"), (0, inventory_1.countItem)(pl, "iron_ingot")], [0, 1, 6]);
    // RUNES: a tempered head takes a rune; without the rune the row is there but cannot be made
    strict_1.default.deepEqual(tab("runes"), [["inset_swift_shovel", "cost"], ["inset_glow_shovel", "cost"]]);
    (0, inventory_1.addItems)(w, pl, "rune_swift", 1);
    strict_1.default.ok(make(w, "smithing", ANVIL, "inset_swift_shovel"));
    strict_1.default.deepEqual([(0, inventory_1.countItem)(pl, "head_shovel_fine"), (0, inventory_1.countItem)(pl, "rune_swift"), (0, inventory_1.countItem)(pl, "head_shovel_swift")], [0, 0, 1]);
    strict_1.default.deepEqual(tab("runes"), [["unset_swift_shovel", "ok"]]);
    strict_1.default.ok(make(w, "smithing", ANVIL, "unset_swift_shovel"));
    strict_1.default.deepEqual([(0, inventory_1.countItem)(pl, "head_shovel_fine"), (0, inventory_1.countItem)(pl, "rune_swift"), (0, inventory_1.countItem)(pl, "head_shovel_swift")], [1, 1, 0], "head and rune both come back");
    // a head worn on the arm is not at hand: it has to come off to be worked on
    strict_1.default.equal(wear(w, "head_pickaxe"), "ok");
    strict_1.default.deepEqual(tab("modify"), []);
});
(0, node_test_1.test)("a full tool is a head, wood and the workbench; the anvil tempers it on its haft", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, helpers_1.frame)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, BENCH)); // the chisel comes off the bench first, as in the tutorial
    (0, inventory_1.addItems)(w, pl, "head_axe", 1);
    (0, inventory_1.addItems)(w, pl, "wood", 4);
    (0, inventory_1.addItems)(w, pl, "iron_ingot", 2);
    openStation(w, BENCH);
    const bench = (0, crafting_2.craftList)(w, pl, "crafting", BENCH).map((e) => e.recipe.id);
    strict_1.default.ok(bench.includes("axe") && bench.includes("shovel") && bench.includes("planks"));
    strict_1.default.ok(!bench.includes("axe_fine"), "the fine haft row waits for a fine head");
    strict_1.default.ok(make(w, "crafting", BENCH, "axe"));
    strict_1.default.deepEqual([(0, inventory_1.countItem)(pl, "head_axe"), (0, inventory_1.countItem)(pl, "wood"), (0, inventory_1.countItem)(pl, "axe")], [0, 2, 1]);
    openStation(w, ANVIL);
    strict_1.default.deepEqual((0, crafting_2.craftList)(w, pl, "smithing", ANVIL, "modify").map((e) => e.recipe.id), ["temper_axe"]);
    strict_1.default.ok(make(w, "smithing", ANVIL, "temper_axe"));
    strict_1.default.deepEqual([(0, inventory_1.countItem)(pl, "axe"), (0, inventory_1.countItem)(pl, "axe_fine"), (0, inventory_1.countItem)(pl, "iron_ingot")], [0, 1, 0]);
});
// ------------------------------------------------------------------ the rooms
(0, node_test_1.test)("the artificery and the armory: the smelter and the anvil where they were, the new pieces drawn, two rusted heads to find; the town's own stay whole and idle", () => {
    const d = (0, map_1.buildDungeon)(), kinds = (x0, y0, x1, y1) => d.props.filter((p) => p.x >= x0 * map_1.TS && p.x < (x1 + 1) * map_1.TS && p.y > (y0 - 1) * map_1.TS && p.y <= (y1 + 1) * map_1.TS).map((p) => p.kind).sort();
    const art = kinds(4, 36, 16, 45), arm = kinds(62, 3, 68, 10);
    for (const k of ["forge", "anvil", "workbench", "cradle", "slab", "coalbin", "quench", "toolboard", "runetable", "clayvat", "husk"])
        strict_1.default.ok(art.includes(k), `artificery: ${k}`);
    for (const k of ["limbrack", "weaponrack", "armorstand", "staffrack", "wallhooks", "armorpile"])
        strict_1.default.ok(arm.includes(k), `armory: ${k}`);
    strict_1.default.equal(arm.filter((k) => k === "weaponrack").length, 2);
    strict_1.default.equal(arm.filter((k) => k === "armorstand").length, 3);
    for (const id of [FORGE, ANVIL, BENCH, "cradle@9,37", "limbrack@65.5,3", "weaponrack@63,3", "armorstand@63,7"])
        strict_1.default.ok(d.props.some((p) => p.id === id), `${id} keeps its id`);
    for (const k of new Set([...art, ...arm]))
        strict_1.default.equal(typeof props_1.PROP_ART[(0, props_2.propDef)(k).art ?? k], "function", `${k}: a sprite`);
    const loose = Object.fromEntries(d.loose.map((l) => [l.id, l]));
    strict_1.default.equal(loose.rusted_shovel.item, "head_shovel_rusted");
    strict_1.default.equal(loose.rusted_axe.item, "head_axe_rusted");
    strict_1.default.ok(loose.rusted_shovel.x < 17 * map_1.TS && loose.rusted_shovel.y > 36 * map_1.TS, "the coal shovel's head, by the smelter");
    strict_1.default.ok(loose.rusted_axe.x > 62 * map_1.TS && loose.rusted_axe.y < 11 * map_1.TS, "an old axe head, in the armory");
    // both can be picked up where they lie
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    (0, helpers_1.frame)(w);
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.looseId === "rusted_shovel"));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "head_shovel_rusted"), 1);
    // the town: its anvils work nothing and its racks and stands are not the halls' ruins
    for (const id of TOWN_AREAS)
        for (const p of areas_1.AREAS[id]().props)
            strict_1.default.ok(!["anvil", "forge", "weaponrack", "armorstand"].includes(p.kind), `${id}: ${p.id}`);
    strict_1.default.equal((0, props_2.propDef)("townanvil").station, undefined);
    strict_1.default.equal((0, props_2.propDef)("townanvil").art, "anvil");
    strict_1.default.ok(props_1.PROP_ART.shoprack && props_1.PROP_ART.shopstand);
});
