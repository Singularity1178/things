"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The production rollout of the foundations: analysis-gated build plans (and
// the taken-prop scan fix), the storage chest, the ruby chain at the bench, the
// dormant worker golem in the artificery with the C-key core seam (in and out,
// golem and guardian), both power thoughts, the v11 -> v12 migration, and the
// host's screens (storage, management, core feedback). Plus the
// guarantees: the tutorial never touches a gate, the one core is never
// consumed, stranded or duplicated, and a fresh game reaches all of it with no
// debug tools.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const g0 = globalThis;
g0.localStorage ?? (g0.localStorage = { getItem: () => null, setItem: () => { }, removeItem: () => { } });
const build_1 = require("../src/game/content/build");
const crafting_1 = require("../src/game/content/crafting");
const items_1 = require("../src/game/content/items");
const interactions_1 = require("../src/game/content/interactions");
const dialogue_1 = require("../src/game/content/dialogue");
const monologue_1 = require("../src/game/content/monologue");
const actors_1 = require("../src/game/content/actors");
const npcs_1 = require("../src/game/content/npcs");
const props_1 = require("../src/game/content/props");
const flags_1 = require("../src/game/content/flags");
const tiles_1 = require("../src/game/content/tiles");
const font_1 = require("../src/game/font");
const map_1 = require("../src/game/map");
const surface_1 = require("../src/game/surface");
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const inventory_1 = require("../src/game/sim/inventory");
const commands_1 = require("../src/game/sim/commands");
const build_2 = require("../src/game/sim/build");
const catalog_1 = require("../src/game/sim/catalog");
const crafting_2 = require("../src/game/sim/crafting");
const interact_1 = require("../src/game/sim/interact");
const analysis_1 = require("../src/game/sim/analysis");
const actorStats_1 = require("../src/game/sim/actorStats");
const discovery_1 = require("../src/game/sim/discovery");
const dialogue_2 = require("../src/game/sim/dialogue");
const ritual_1 = require("../src/game/sim/ritual");
const collision_1 = require("../src/game/sim/collision");
const reach_1 = require("../src/game/sim/reach");
const actors_2 = require("../src/game/view/actors");
const workerArt_1 = require("../src/game/workerArt");
const game_1 = require("../src/game/game");
const helpers_1 = require("./helpers");
const WORKER = map_1.ARTIFICERY_WORKER.id;
const GATED = ["anvil", "brazier", "chair", "craftbench", "smelter", "storage_chest", "table", "wall_banner", "wall_torch"];
const thoughts = (evs) => evs.filter((e) => e.t === "thought").map((e) => e.line);
const finish = (w) => { let g = 0; while ((0, world_1.player)(w).task && g++ < 900)
    (0, helpers_1.frame)(w); };
/** Every Ruby Golem Core in the world: packs, gear, power sockets, the ground, props and their storage. */
function coreCount(w) {
    let n = 0;
    for (const a of w.actors) {
        n += (0, inventory_1.countItem)(a, "ruby_core") + (a.powerCore === "ruby_core" ? 1 : 0);
        n += Object.values(a.gear).filter((g) => g === "ruby_core").length;
    }
    for (const area of w.areas.values()) {
        for (const l of area.loose)
            if (!l.taken && l.item === "ruby_core")
                n += l.n ?? 1;
        for (const p of area.props) {
            if (p.item === "ruby_core" && !p.taken)
                n++;
            for (const s of p.inventory ?? [])
                if (s?.item === "ruby_core")
                    n += s.n;
        }
    }
    return n;
}
/** Stand in front of a body the way the player would, press C, and let the reach play out. */
function coreKeyAt(w, target) {
    const pl = (0, world_1.player)(w);
    if (pl.area !== target.area)
        (0, world_1.enterArea)(w, pl, target.area, target.x, target.y + 11);
    pl.x = target.x;
    pl.y = target.y + 11;
    pl.vx = pl.vy = 0;
    pl.facing = "up";
    (0, helpers_1.frame)(w, { ix: 0, iy: 0, use: false, core: true });
    finish(w);
    (0, helpers_1.frames)(w, 5);
}
/** Golem vision on (Z), E at a buildable prop, the scan plays out. */
function scanProp(w, propId) {
    const pl = (0, world_1.player)(w), p = (0, world_1.currentArea)(w).prop(propId);
    pl.x = p.x;
    pl.y = p.y + 11;
    pl.vx = pl.vy = 0;
    pl.facing = "up";
    (0, helpers_1.frame)(w, { ix: 0, iy: 0, use: true, toggleScan: pl.mode !== "scan" });
    finish(w);
}
const boxes = (w, area, except) => [...(0, world_1.getArea)(w, area).props.filter(collision_1.propBlocks).map((p) => p.box), ...(0, collision_1.actorBoxes)(w, area, w.playerId).filter((b) => !except || b.join() !== (0, collision_1.actorBox)((0, world_1.actorById)(w, except)).join())];
// ------------------------------------------------------------------ the catalog
(0, node_test_1.test)("gating data: which plans need analysis, and every gate has an example to read in a production area", () => {
    strict_1.default.deepEqual(Object.keys(build_1.RECIPES).filter((id) => build_1.RECIPES[id].analysis).sort(), GATED);
    strict_1.default.ok(!build_1.RECIPES.torch_post.analysis && !build_1.RECIPES.barricade.analysis, "the torch post and the barricade stay free");
    const kinds = new Set([...(0, map_1.buildDungeon)().props, ...(0, surface_1.buildSurface)().props].map((p) => p.kind));
    for (const free of ["torch_post", "barricade"])
        strict_1.default.ok(!kinds.has(build_1.RECIPES[free].prop), `${free}: no example stands anywhere, so a gate would lock it forever`);
    for (const id of GATED) {
        const r = build_1.RECIPES[id], sources = [r.prop, ...(r.learnFrom ?? []).map((l) => l.kind)];
        strict_1.default.equal(r.analysis, id, `${id}: its flag is analysis.${id}`);
        strict_1.default.ok(sources.some((k) => kinds.has(k)), `${id}: something to scan for it in a production area`);
    }
    // the storage chest: its own 1-tile, 32-slot kind on planks; the looted dungeon chests stay out of AUTHORED_SALVAGE
    const chest = build_1.RECIPES.storage_chest;
    strict_1.default.equal(chest.prop, "storage_chest");
    strict_1.default.equal(props_1.PROPS.storage_chest.storage.slots, 32);
    strict_1.default.ok(props_1.PROPS.storage_chest.box[0] <= tiles_1.TS, "one tile");
    strict_1.default.deepEqual(chest.cost, [{ item: "planks", n: 4 }]);
    strict_1.default.ok(!("chest" in build_1.AUTHORED_SALVAGE) && build_1.AUTHORED_SALVAGE.storage_chest);
    strict_1.default.deepEqual(chest.learnFrom, [{ kind: "chest", name: "OLD CHEST" }]);
    // the promoted bench rows: distinct names that fit the crafting list (20 characters), the ruby chain on the chisel
    const names = crafting_1.CRAFT_RECIPES.map((r) => r.name);
    strict_1.default.equal(new Set(names).size, names.length, "no two rows share a name");
    for (const r of crafting_1.CRAFT_RECIPES)
        strict_1.default.ok(r.name.length <= 20 && [...r.name].every((c) => font_1.FONT_GLYPHS.has(c)), r.name);
    const by = Object.fromEntries(crafting_1.CRAFT_RECIPES.map((r) => [r.id, r]));
    strict_1.default.deepEqual([by.unmake_rune_swift.name, by.unmake_rune_glow.name, by.unmake_crown.name], ["UNMAKE RUNE OF SWIFT", "UNMAKE RUNE OF GLOW", "UNMAKE BROKEN CROWN"]);
    strict_1.default.deepEqual([by.unmake_crown.output, by.unmake_rune_swift.output, by.unmake_rune_glow.output], [{ item: "large_ruby", n: 1 }, { item: "stone", n: 1 }, { item: "stone", n: 1 }]);
    strict_1.default.deepEqual([by.ruby_core.inputs, by.ruby_core.tools, by.ruby_core.output], [[{ item: "large_ruby", n: 1 }], ["chisel"], { item: "ruby_core", n: 1 }]);
    strict_1.default.ok(crafting_1.CRAFT_RECIPES.every((r) => !r.requires), "station knowledge (know.build) only: nothing at a bench is analysis-gated");
    strict_1.default.deepEqual([items_1.ITEMS.large_ruby.name, items_1.ITEMS.ruby_core.name], ["HIGH-GRADE RUBY", "RUBY GOLEM CORE"]);
    strict_1.default.ok(!items_1.ITEMS.large_ruby.desc.join(" ").includes("UNCUT"));
});
(0, node_test_1.test)("the build menu says what to scan and that vision is Z, distinct from missing knowledge, within the panel", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    for (const id of GATED)
        strict_1.default.equal((0, catalog_1.entryReason)((0, catalog_1.entryFor)(w, pl, id)), "UNKNOWN RECIPE - NOT YET LEARNED", `${id} before the Primer`);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    for (const id of GATED.filter((x) => x !== "brazier")) {
        const e = (0, catalog_1.entryFor)(w, pl, id), why = (0, catalog_1.entryReason)(e);
        strict_1.default.equal(e.status, "unknown");
        strict_1.default.equal(e.lock, "analysis");
        strict_1.default.equal(why, `SCAN ${(0, build_1.scanHint)(build_1.RECIPES[id])} IN VISION (Z)`);
        strict_1.default.ok(why.length <= 36 && [...why].every((c) => font_1.FONT_GLYPHS.has(c)), `${id}: "${why}" fits the status line`);
    }
    strict_1.default.equal((0, catalog_1.entryReason)((0, catalog_1.entryFor)(w, pl, "storage_chest")), "SCAN AN OLD CHEST IN VISION (Z)");
    strict_1.default.equal((0, catalog_1.entryReason)((0, catalog_1.entryFor)(w, pl, "table")), "SCAN A TABLE IN VISION (Z)");
    // the brazier still needs masonry, which no book grants yet: that is a knowledge lock, said as before
    strict_1.default.equal((0, catalog_1.entryFor)(w, pl, "brazier").lock, "knowledge");
    strict_1.default.equal((0, catalog_1.entryReason)((0, catalog_1.entryFor)(w, pl, "brazier")), "UNKNOWN RECIPE - NOT YET LEARNED");
    strict_1.default.equal((0, catalog_1.entryFor)(w, pl, "torch_post").lock, undefined);
});
// ------------------------------------------------------------------ the taken-prop scan fix
(0, node_test_1.test)("taking the chisel or the Primer leaves the workbench and the library table scannable; scanning never steals", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), area = (0, world_1.currentArea)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    // scanning the occupied workbench reads it and leaves the chisel where it is
    scanProp(w, "workbench@13.5,37");
    strict_1.default.ok(w.flags.has("analysis.craftbench"));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "chisel"), 0);
    w.flags.delete("analysis.craftbench");
    (0, helpers_1.frame)(w, { ix: 0, iy: 0, use: false, toggleScan: true }); // vision off: E picks the chisel up
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "workbench@13.5,37"));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "chisel"), 1);
    strict_1.default.ok(area.prop("workbench@13.5,37").taken);
    strict_1.default.ok((0, interact_1.scanTargets)(area).some((t) => t.propId === "workbench@13.5,37"), "still a scan target once taken");
    scanProp(w, "workbench@13.5,37");
    strict_1.default.ok(w.flags.has("analysis.craftbench"), "and scanning it after the chisel is gone reads the bench");
    (0, helpers_1.frame)(w, { ix: 0, iy: 0, use: false, toggleScan: true });
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "table@11,29"));
    strict_1.default.ok((0, inventory_1.hasItem)(pl, "book_build") && area.prop("table@11,29").taken);
    scanProp(w, "table@11,29");
    strict_1.default.ok(w.flags.has("analysis.table"), "the library table reads after the Primer is taken");
    const vt = (0, analysis_1.visionTargets)(w, area).find((t) => t.id === "table@11,29");
    strict_1.default.deepEqual([vt.category, vt.analysis], ["buildable", "done"]);
});
(0, node_test_1.test)("taking a buildable apart reads its plan too, so the only workbench can go and crafting is never lost", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), area = (0, world_1.currentArea)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "workbench@13.5,37")); // the chisel first: the bench refuses while it holds it
    const bench = area.prop("workbench@13.5,37");
    pl.x = bench.x;
    pl.y = bench.y + 14;
    pl.facing = "up";
    (0, helpers_1.events)(w);
    strict_1.default.ok((0, commands_1.orderDeconstruct)(w, pl, bench.id));
    finish(w);
    strict_1.default.equal(area.prop(bench.id), undefined);
    const evs = (0, helpers_1.events)(w);
    strict_1.default.ok(w.flags.has("analysis.craftbench"));
    strict_1.default.ok(evs.some((e) => e.t === "message" && e.text === "PLAN LEARNED: CRAFTING BENCH"));
    strict_1.default.ok(evs.some((e) => e.t === "analyzed"));
    strict_1.default.deepEqual((0, build_2.canBuild)(w, pl, "craftbench"), { ok: true }, "its own refund rebuilds it");
});
(0, node_test_1.test)("the treasury's looted chests teach the storage chest, and stay what they are", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), area = (0, world_1.currentArea)(w);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowBuild);
    area.setTile(51, 5, tiles_1.T.FLOOR);
    (0, world_1.enterArea)(w, pl, "dungeon", 54 * tiles_1.TS + 8, 6 * tiles_1.TS);
    strict_1.default.equal((0, analysis_1.visionTargets)(w, area).find((t) => t.id === "chest@54,4").analysis, "pending");
    scanProp(w, "chest@54,4");
    strict_1.default.ok(w.flags.has("analysis.storage_chest"));
    strict_1.default.equal((0, analysis_1.planLock)(w, pl, build_1.RECIPES.storage_chest), null);
    strict_1.default.ok(!(0, interact_1.interactables)(area).some((i) => i.propId === "chest@54,4"), "not a container, not storage");
    strict_1.default.equal(area.prop("chest@54,4").kind, "chest");
});
// ------------------------------------------------------------------ the tutorial never touches a gate
(0, node_test_1.test)("the tutorial's critical path needs no building, crafting or analysis, and no rule or story step reads a gate", () => {
    const reqs = [...Object.values(interactions_1.RULES).flat().map((r) => r.when), ...Object.values(interactions_1.SLAM_RULES).flat().map((r) => r.when),
        ...Object.values(dialogue_1.DIALOGUE).flatMap((d) => d.segments.flatMap((s) => [s.when, ...s.pages.map((p) => p.when)]))];
    for (const q of reqs)
        strict_1.default.ok(!(q?.flags ?? []).some((f) => f.startsWith("analysis.") || f === flags_1.FLAGS.knowBuild), JSON.stringify(q));
    const made = new Set([...crafting_1.CRAFT_RECIPES.map((r) => r.output.item)]);
    for (const id of Object.keys(items_1.ITEMS))
        if ((0, items_1.isCritical)(id) && items_1.ITEMS[id].tags.includes("glyph"))
            strict_1.default.ok(!made.has(id));
    for (const id of ["chisel", "key", "core", "schematic", "glyph0", "glyph1", "glyph2", "glyph3", "arm"])
        strict_1.default.ok(!made.has(id), `${id} is never made at a bench`);
    const w = (0, helpers_1.newWorld)(77), pl = (0, world_1.player)(w), area = (0, world_1.currentArea)(w), r = area.ritual;
    const seen = [];
    const step = (f) => { f(); seen.push(...(0, helpers_1.events)(w)); };
    step(() => (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "limbrack@65.5,3")));
    step(() => (0, helpers_1.slamAt)(w, (0, helpers_1.find)(w, (i) => i.kind === "cracked")));
    step(() => (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "skeleton@66,32")));
    step(() => (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "door")));
    step(() => (0, helpers_1.talkThrough)(w, (0, helpers_1.guardianIt)(w)));
    for (const id of ["workbench@13.5,37", "maptable@39.5,5", "hearth@60.5,43", "lectern@5,29", "footlocker@63,21", "altar@26,48"])
        step(() => (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, id)));
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowSchematic); // the schematic screen sets this on opening
    step(() => (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "gap")));
    step(() => (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "center")));
    r.solution.forEach((g, s) => step(() => { (0, ritual_1.placeGlyph)(w, pl, area, s, g); while (pl.task)
        (0, helpers_1.frame)(w); }));
    strict_1.default.ok(r.active);
    pl.x = area.ritualPos.x;
    pl.y = area.ritualPos.y + 2;
    step(() => (0, helpers_1.frames)(w, 220));
    strict_1.default.ok(seen.some((e) => e.t === "teleport"), "the circle carries the golem out");
    strict_1.default.ok(!seen.some((e) => e.t === "built" || e.t === "crafted" || e.t === "analyzed"), "nothing built, crafted or analyzed");
    strict_1.default.ok(![...w.flags].some((f) => f.startsWith("analysis.")), "and no plan was ever read");
});
// ------------------------------------------------------------------ the dormant worker golem
(0, node_test_1.test)("the dormant worker golem: placed by the builder with a stable id, a worker not an NPC, no dialogue, violet in vision", () => {
    const w = (0, helpers_1.newWorld)(), area = (0, world_1.currentArea)(w), wk = (0, world_1.actorById)(w, WORKER);
    strict_1.default.deepEqual([wk.definition, wk.kind, wk.npc, wk.area, wk.x, wk.y, wk.facing, wk.powerCore], ["worker_golem", "npc", "worker_golem", "dungeon", map_1.ARTIFICERY_WORKER.x, map_1.ARTIFICERY_WORKER.y, "down", null]);
    strict_1.default.equal((0, npcs_1.npcDef)(wk.npc), undefined, "no NPCS row");
    strict_1.default.deepEqual((0, world_1.actorById)((0, world_1.createWorld)(999), WORKER), wk, "deterministic, whatever the seed");
    strict_1.default.equal((0, interact_1.npcInteractables)(w, area).find((i) => i.actorId === WORKER).kind, "worker");
    strict_1.default.equal((0, dialogue_2.npcActor)(w, WORKER), undefined);
    strict_1.default.equal((0, dialogue_2.talkTo)(w, (0, world_1.player)(w), WORKER), null);
    strict_1.default.deepEqual((0, helpers_1.events)(w), [], "talking to it says nothing");
    const vt = (0, analysis_1.visionTargets)(w, area).find((t) => t.id === WORKER);
    strict_1.default.deepEqual([vt.category, vt.kind, vt.source], ["npc", "actor:worker_golem", "actor"]);
    strict_1.default.deepEqual(actors_1.ACTORS.worker_golem.art, { key: "worker" });
    strict_1.default.ok(workerArt_1.BODY_ART.worker);
    // the human stand-in is fixture-only: nothing in production resolves to npc_worker
    const spawns = [...((0, map_1.buildDungeon)().npcs ?? []), ...((0, surface_1.buildSurface)().npcs ?? [])];
    strict_1.default.ok(spawns.every((s) => (npcs_1.NPCS[s.npc]?.actor ?? s.npc) !== "npc_worker"));
    strict_1.default.ok(Object.values(npcs_1.NPCS).every((n) => n.actor !== "npc_worker"));
});
(0, node_test_1.test)("the worker keeps every route open: cradle, forge, workbench, start and the exit, from both of its spots", () => {
    for (const spot of [map_1.ARTIFICERY_WORKER, { x: 5 * tiles_1.TS + 8, y: 43 * tiles_1.TS + 12 }]) {
        const w = (0, helpers_1.newWorld)(), a = (0, world_1.getArea)(w, "dungeon"), wk = (0, world_1.actorById)(w, WORKER);
        wk.x = spot.x;
        wk.y = spot.y;
        const withW = (0, reach_1.reachable)(a, boxes(w, "dungeon"), a.base.start), without = (0, reach_1.reachable)(a, boxes(w, "dungeon", WORKER), a.base.start);
        const wb = (0, collision_1.actorBox)(wk);
        for (let ty = 0; ty < a.h; ty++)
            for (let tx = 0; tx < a.w; tx++) {
                if (!without[ty * a.w + tx] || withW[ty * a.w + tx])
                    continue;
                const fx = tx * tiles_1.TS + 8, fy = ty * tiles_1.TS + 11;
                strict_1.default.ok(fx + 5 > wb[0] && fx - 5 < wb[2] && fy > wb[1] && fy - 5 < wb[3], `the worker at ${spot.x},${spot.y} cuts off ${tx},${ty}`);
            }
        for (const [tx, ty, what] of [[9, 38, "start / cradle"], [5, 38, "forge"], [13, 38, "workbench"], [17, 40, "exit"], [21, 40, "corridor"]])
            strict_1.default.equal(withW[ty * a.w + tx], 1, `${what} reachable`);
        const it = (0, interact_1.npcInteractables)(w, a).find((i) => i.actorId === WORKER);
        strict_1.default.ok((0, reach_1.nearReached)(a, withW, it.x, it.y + it.r / 2, 0), "somewhere to stand to reach it");
        const s = a.base.start;
        strict_1.default.ok(!(s.x + 5 > wb[0] && s.x - 5 < wb[2] && s.y > wb[1] && s.y - 5 < wb[3]), "the start is clear of it");
    }
});
// ------------------------------------------------------------------ slotting and removing: the C key
(0, node_test_1.test)("C slots the core into the dormant golem and takes it out again; powered with no task it stays dormant and still", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), wk = (0, world_1.actorById)(w, WORKER);
    (0, inventory_1.addItems)(w, pl, "ruby_core", 1);
    const at = { x: wk.x, y: wk.y, facing: wk.facing };
    (0, helpers_1.events)(w);
    coreKeyAt(w, wk);
    let evs = (0, helpers_1.events)(w);
    strict_1.default.equal(wk.powerCore, "ruby_core");
    strict_1.default.ok((0, actorStats_1.powered)(wk));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "ruby_core"), 0);
    strict_1.default.deepEqual(evs.filter((e) => e.t === "coreSlotted"), [{ t: "coreSlotted", actor: pl.id, target: WORKER, item: "ruby_core", inserted: true, powered: true }]);
    strict_1.default.ok(evs.some((e) => e.t === "powerChanged" && e.actor === WORKER && e.powered));
    strict_1.default.deepEqual(thoughts(evs), [], "nothing to think about a body that runs");
    (0, helpers_1.frames)(w, 600); // ten seconds: powered, idle, untouched
    strict_1.default.deepEqual({ x: wk.x, y: wk.y, facing: wk.facing }, at, "it does not wander or turn");
    strict_1.default.ok(!wk.task && !wk.job && !wk.moving && wk.queue.length === 0);
    strict_1.default.equal((0, workerArt_1.workerState)((0, actorStats_1.powered)(wk), (0, actors_2.actorActive)(wk)), "idle", "drawn in its dormant posture with a faint core");
    coreKeyAt(w, wk);
    evs = (0, helpers_1.events)(w);
    strict_1.default.equal(wk.powerCore, null);
    strict_1.default.ok(!(0, actorStats_1.powered)(wk));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "ruby_core"), 1);
    strict_1.default.deepEqual(evs.filter((e) => e.t === "coreSlotted"), [{ t: "coreSlotted", actor: pl.id, target: WORKER, item: "ruby_core", inserted: false, powered: false }]);
    strict_1.default.equal((0, workerArt_1.workerState)((0, actorStats_1.powered)(wk), (0, actors_2.actorActive)(wk)), "off");
    // E never slots anything, and C facing nothing does nothing
    (0, helpers_1.useOn)(w, (0, interact_1.npcInteractables)(w, (0, world_1.currentArea)(w)).find((i) => i.actorId === WORKER));
    strict_1.default.equal(wk.powerCore, null);
    pl.x = 300;
    pl.y = 660;
    (0, helpers_1.frame)(w, { ix: 0, iy: 0, use: false, core: true });
    strict_1.default.equal(pl.task, null);
});
(0, node_test_1.test)("the guardian takes the core with C (it fits, too weak to run it) and gives it back; E always talks", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), g = (0, world_1.actorById)(w, helpers_1.GUARDIAN);
    (0, world_1.currentArea)(w).setTile(51, 5, tiles_1.T.FLOOR);
    (0, inventory_1.addItems)(w, pl, "ruby_core", 1);
    // carrying the core, E still opens the guardian's dialogue and slots nothing
    (0, helpers_1.events)(w);
    (0, helpers_1.useOn)(w, (0, helpers_1.guardianIt)(w));
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "dialogue"));
    strict_1.default.equal(g.powerCore, null);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "ruby_core"), 1);
    coreKeyAt(w, g);
    const evs = (0, helpers_1.events)(w);
    strict_1.default.equal(g.powerCore, "ruby_core");
    strict_1.default.equal((0, actorStats_1.powered)(g), false);
    strict_1.default.ok(evs.some((e) => e.t === "coreSlotted" && e.inserted && !e.powered));
    strict_1.default.deepEqual(thoughts(evs), ["golem.underpowered"], "it knows at once");
    (0, helpers_1.frames)(w, 150);
    coreKeyAt(w, g);
    strict_1.default.equal(g.powerCore, null);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "ruby_core"), 1);
});
(0, node_test_1.test)("one core moves freely: pack -> golem -> pack -> guardian -> pack -> golem, exactly one throughout, across a save/load", () => {
    let w = (0, helpers_1.newWorld)(31);
    (0, world_1.currentArea)(w).setTile(51, 5, tiles_1.T.FLOOR);
    (0, inventory_1.addItems)(w, (0, world_1.player)(w), "ruby_core", 1);
    const check = (where) => strict_1.default.equal(coreCount(w), 1, `one core (${where})`);
    check("pack");
    coreKeyAt(w, (0, world_1.actorById)(w, WORKER));
    check("golem");
    strict_1.default.equal((0, world_1.actorById)(w, WORKER).powerCore, "ruby_core");
    coreKeyAt(w, (0, world_1.actorById)(w, WORKER));
    check("pack");
    strict_1.default.equal((0, inventory_1.countItem)((0, world_1.player)(w), "ruby_core"), 1);
    coreKeyAt(w, (0, world_1.actorById)(w, helpers_1.GUARDIAN));
    check("guardian");
    strict_1.default.equal((0, world_1.actorById)(w, helpers_1.GUARDIAN).powerCore, "ruby_core");
    // mid-cycle save and load: the core is still in the guardian, and only there
    w = (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
    check("guardian, after loading");
    strict_1.default.equal((0, world_1.actorById)(w, helpers_1.GUARDIAN).powerCore, "ruby_core");
    coreKeyAt(w, (0, world_1.actorById)(w, helpers_1.GUARDIAN));
    check("pack");
    strict_1.default.equal((0, inventory_1.countItem)((0, world_1.player)(w), "ruby_core"), 1);
    coreKeyAt(w, (0, world_1.actorById)(w, WORKER));
    check("golem");
    strict_1.default.ok((0, actorStats_1.powered)((0, world_1.actorById)(w, WORKER)));
    strict_1.default.equal((0, inventory_1.countItem)((0, world_1.player)(w), "ruby_core"), 0);
});
(0, node_test_1.test)("a full pack: taking the core out lands it on the ground, never deletes it, and it can be picked up", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), wk = (0, world_1.actorById)(w, WORKER);
    (0, inventory_1.addItems)(w, pl, "ruby_core", 1);
    coreKeyAt(w, wk);
    (0, inventory_1.addItems)(w, pl, "stone", 20 * pl.inventory.length);
    strict_1.default.ok(pl.inventory.every((s) => s && s.item === "stone"), "pack full");
    coreKeyAt(w, wk);
    strict_1.default.equal(wk.powerCore, null);
    strict_1.default.equal(coreCount(w), 1);
    const loose = (0, world_1.currentArea)(w).loose.find((l) => l.item === "ruby_core" && !l.taken);
    strict_1.default.ok(loose, "on the ground");
    // a refusal changes nothing: no core carried, nothing to slot
    strict_1.default.equal((0, commands_1.orderCoreSwap)(w, pl, WORKER, "ruby_core"), false);
    strict_1.default.equal(coreCount(w), 1);
    pl.inventory[0] = null; // make room, then pick it up like anything else
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.looseId === loose.id));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "ruby_core"), 1);
    strict_1.default.equal(coreCount(w), 1);
});
// ------------------------------------------------------------------ the two thoughts
(0, node_test_1.test)("the dormant line: E on the unpowered golem only, never about the guardian, never once it runs", () => {
    strict_1.default.equal(monologue_1.THOUGHTS["golem.dormant"].text, "INTEGRITY INTACT, MISSING POWER SOURCE.");
    strict_1.default.equal(monologue_1.THOUGHTS["golem.underpowered"].text, "INSUFFICIENT POWER SOURCE.");
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), it = () => (0, interact_1.npcInteractables)(w, (0, world_1.currentArea)(w)).find((i) => i.actorId === WORKER);
    (0, helpers_1.events)(w);
    (0, helpers_1.useOn)(w, it());
    let evs = (0, helpers_1.events)(w);
    strict_1.default.ok(evs.some((e) => e.t === "dormantTouched" && e.target === WORKER));
    strict_1.default.ok(!evs.some((e) => e.t === "manageActor"), "no screen for a body that never had a core");
    strict_1.default.deepEqual(thoughts(evs), ["golem.dormant"]);
    // the unpowered guardian also has no core, but talking to it is not managing a worker
    (0, world_1.currentArea)(w).setTile(51, 5, tiles_1.T.FLOOR);
    (0, helpers_1.frames)(w, 150);
    (0, helpers_1.useOn)(w, (0, helpers_1.guardianIt)(w));
    strict_1.default.deepEqual(thoughts((0, helpers_1.events)(w)), []);
    (0, inventory_1.addItems)(w, pl, "ruby_core", 1);
    coreKeyAt(w, (0, world_1.actorById)(w, WORKER));
    (0, helpers_1.events)(w);
    (0, helpers_1.frames)(w, 150);
    (0, helpers_1.useOn)(w, it());
    evs = (0, helpers_1.events)(w);
    strict_1.default.ok(evs.some((e) => e.t === "manageActor"));
    strict_1.default.deepEqual(thoughts(evs), [], "powered: nothing to diagnose");
    // core taken out again: the screen still opens, and the golem no longer thinks it
    coreKeyAt(w, (0, world_1.actorById)(w, WORKER));
    (0, helpers_1.events)(w);
    (0, helpers_1.frames)(w, 150);
    strict_1.default.equal((0, world_1.actorById)(w, WORKER).powerCore, null);
    (0, helpers_1.useOn)(w, it());
    evs = (0, helpers_1.events)(w);
    strict_1.default.ok(evs.some((e) => e.t === "manageActor"));
    strict_1.default.deepEqual(thoughts(evs), [], "slotted once: never the dormant line again");
});
(0, node_test_1.test)("with the core in the guardian, every interaction thinks INSUFFICIENT POWER SOURCE., and the story plays unchanged", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), g = (0, world_1.actorById)(w, helpers_1.GUARDIAN);
    (0, world_1.currentArea)(w).setTile(51, 5, tiles_1.T.FLOOR);
    (0, inventory_1.addItems)(w, pl, "ruby_core", 1);
    coreKeyAt(w, g);
    (0, helpers_1.events)(w);
    const played = [];
    for (let talk = 0; talk < 5; talk++) {
        (0, helpers_1.frames)(w, 150); // past the 2 s cooldown
        (0, helpers_1.useOn)(w, (0, helpers_1.guardianIt)(w));
        const evs = (0, helpers_1.events)(w), d = evs.find((e) => e.t === "dialogue");
        strict_1.default.ok(evs.some((e) => e.t === "talkedTo" && e.npc === helpers_1.GUARDIAN));
        strict_1.default.deepEqual(thoughts(evs), ["golem.underpowered"], `talk ${talk + 1} (${d && d.t === "dialogue" ? d.segment : "idle"})`);
        if (d && d.t === "dialogue") {
            played.push(d.segment);
            (0, dialogue_2.playSegment)(w, pl, helpers_1.GUARDIAN, (0, dialogue_2.scriptOf)(w, helpers_1.GUARDIAN).segments.find((s) => s.id === d.segment));
        }
        else
            strict_1.default.ok(evs.some((e) => e.t === "message" && e.text === dialogue_1.DIALOGUE.guardian.idle), "the idle line, once the story is done");
    }
    strict_1.default.deepEqual(played, ["intro", "repair", "core", "farewell"], "the same segments, in order");
    strict_1.default.ok(w.flags.has(flags_1.FLAGS.golemEye));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "core"), 1, "the aether core, given once");
    strict_1.default.equal(g.powerCore, "ruby_core");
});
// ------------------------------------------------------------------ the whole route, no debug tools
(0, node_test_1.test)("a fresh game reaches it all with no debug tools: Primer, scans, a storage chest, the crown, the ruby, the core, the golem", () => {
    const w = (0, helpers_1.newWorld)(4242), pl = (0, world_1.player)(w), area = (0, world_1.currentArea)(w);
    const start = area.base.start, crown = area.looseItem("crown");
    const canReach = (x, y) => (0, reach_1.nearReached)(area, (0, reach_1.reachable)(area, boxes(w, "dungeon"), { x: pl.x, y: pl.y }), x, y);
    // The Primer (library) and the chisel (artificery) are reachable from the start; the crown only past the cracked wall.
    strict_1.default.ok((0, reach_1.nearReached)(area, (0, reach_1.reachable)(area, boxes(w, "dungeon"), start), area.prop("table@11,29").x, area.prop("table@11,29").y + 12));
    strict_1.default.ok(!(0, reach_1.nearReached)(area, (0, reach_1.reachable)(area, boxes(w, "dungeon"), start), crown.x, crown.y), "the throne hall is sealed by the cracked wall");
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "table@11,29"));
    (0, commands_1.readItem)(w, pl, "book_build");
    strict_1.default.ok(w.flags.has(flags_1.FLAGS.knowBuild));
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "workbench@13.5,37"));
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "limbrack@65.5,3"));
    (0, helpers_1.slamAt)(w, (0, helpers_1.find)(w, (i) => i.kind === "cracked"));
    pl.x = start.x;
    pl.y = start.y;
    strict_1.default.ok(canReach(crown.x, crown.y), "walkable from the start once the wall is down");
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.looseId === "crown"));
    strict_1.default.equal((0, inventory_1.countItem)(pl, "crown"), 1);
    strict_1.default.equal((0, discovery_1.relicCount)(w, pl), 1);
    // scan the dungeon furniture: the bench (chisel gone), the library table (Primer gone), a chair, the treasury's old chest
    strict_1.default.equal((0, catalog_1.entryFor)(w, pl, "table").lock, "analysis");
    scanProp(w, "workbench@13.5,37");
    scanProp(w, "table@11,29");
    scanProp(w, "chair@58.6,18");
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "skeleton@66,32"));
    (0, helpers_1.frame)(w, { ix: 0, iy: 0, use: false, toggleScan: true });
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "door"));
    scanProp(w, "chest@54,4");
    (0, helpers_1.frame)(w, { ix: 0, iy: 0, use: false, toggleScan: true });
    for (const id of ["craftbench", "table", "chair", "storage_chest"])
        strict_1.default.ok(w.flags.has(`analysis.${id}`), id);
    // planks from the barracks table, then a storage chest; E on it opens its storage screen (the host's seam)
    const t = area.prop("table@60.5,18");
    pl.x = t.x;
    pl.y = t.y + 14;
    pl.facing = "up";
    strict_1.default.ok((0, commands_1.orderDeconstruct)(w, pl, t.id));
    finish(w);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "planks"), 4);
    const site = (0, build_2.suggestTile)(w, pl, area, "storage_chest");
    strict_1.default.ok(site && (0, commands_1.orderBuild)(w, pl, "storage_chest", site.tx, site.ty));
    finish(w);
    const chest = area.props.find((p) => p.dyn && p.kind === "storage_chest");
    strict_1.default.ok(chest && chest.inventory?.length === 32 && (0, inventory_1.countItem)(pl, "planks") === 0);
    (0, helpers_1.events)(w);
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.propId === chest.id));
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "openStorage" && e.prop === chest.id));
    strict_1.default.equal(chest.inventory.filter(Boolean).length, 0, "an empty 32-slot chest; its screen is tests/storageScreen.test.ts");
    // the bench: unmake the crown into the High-Grade Ruby, carve the Ruby Golem Core (station knowledge only)
    const flagsBefore = [...w.flags].filter((f) => f.startsWith("analysis.")).sort();
    const bench = area.prop("workbench@13.5,37");
    pl.x = bench.x;
    pl.y = bench.y + 12;
    pl.facing = "up";
    strict_1.default.deepEqual(crafting_1.STATION_REQUIRES.crafting, { flags: [flags_1.FLAGS.knowBuild] });
    strict_1.default.ok((0, crafting_2.orderCraft)(w, pl, "crafting", "unmake_crown", bench.id));
    finish(w);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "large_ruby"), 1);
    strict_1.default.equal(items_1.ITEMS.large_ruby.name, "HIGH-GRADE RUBY");
    strict_1.default.equal((0, discovery_1.relicCount)(w, pl), 1, "the relics display doesn't drop: credit is discovery");
    strict_1.default.ok((0, crafting_2.orderCraft)(w, pl, "crafting", "ruby_core", bench.id));
    finish(w);
    strict_1.default.deepEqual([(0, inventory_1.countItem)(pl, "ruby_core"), (0, inventory_1.countItem)(pl, "large_ruby"), (0, inventory_1.countItem)(pl, "chisel")], [1, 0, 1]);
    strict_1.default.deepEqual([...w.flags].filter((f) => f.startsWith("analysis.")).sort(), flagsBefore, "the chain read no plan");
    // the golem: E (the dormant thought), C in (on, faint, still dormant), out, in, then to the guardian and back
    const wk = (0, world_1.actorById)(w, WORKER);
    (0, helpers_1.events)(w);
    (0, helpers_1.useOn)(w, (0, interact_1.npcInteractables)(w, area).find((i) => i.actorId === WORKER));
    strict_1.default.deepEqual(thoughts((0, helpers_1.events)(w)), ["golem.dormant"]);
    coreKeyAt(w, wk);
    strict_1.default.ok((0, actorStats_1.powered)(wk));
    strict_1.default.equal((0, workerArt_1.workerState)((0, actorStats_1.powered)(wk), (0, actors_2.actorActive)(wk)), "idle");
    coreKeyAt(w, wk);
    strict_1.default.ok(!(0, actorStats_1.powered)(wk));
    coreKeyAt(w, wk);
    strict_1.default.ok((0, actorStats_1.powered)(wk));
    coreKeyAt(w, wk);
    (0, helpers_1.events)(w);
    coreKeyAt(w, (0, world_1.actorById)(w, helpers_1.GUARDIAN));
    strict_1.default.deepEqual(thoughts((0, helpers_1.events)(w)), ["golem.underpowered"]);
    (0, helpers_1.frames)(w, 150);
    (0, helpers_1.useOn)(w, (0, helpers_1.guardianIt)(w));
    strict_1.default.deepEqual(thoughts((0, helpers_1.events)(w)), ["golem.underpowered"]);
    coreKeyAt(w, (0, world_1.actorById)(w, helpers_1.GUARDIAN));
    coreKeyAt(w, wk);
    strict_1.default.ok((0, actorStats_1.powered)(wk));
    strict_1.default.equal(coreCount(w), 1);
    (0, helpers_1.frames)(w, 300);
    strict_1.default.deepEqual([wk.x, wk.y], [map_1.ARTIFICERY_WORKER.x, map_1.ARTIFICERY_WORKER.y], "powered with no task, it stays idle");
});
// ------------------------------------------------------------------ v11 -> v12
/** A pre-rollout save of `version`, made the way it would have been: no worker golem, the shapes of the time. */
function preRollout(version, knowBuild, extraFlags = []) {
    const s = (0, save_1.serialize)((0, helpers_1.newWorld)(5));
    s.version = version;
    s.actors = s.actors.filter((a) => a.id !== WORKER && (version > 4 || a.kind !== "npc"));
    s.flags = [...(knowBuild ? ["know.build"] : []), ...extraFlags];
    if (version <= 10)
        delete s.monologue;
    if (version <= 9)
        for (const a of s.actors)
            for (const k of ["definition", "upgrades", "powerCore", "mode", "job", "jobSeq"])
                delete a[k];
    return s;
}
(0, node_test_1.test)("v9, v10 and v11 saves load with no lost plans and no free ones; storage stays locked; one worker is added", () => {
    strict_1.default.equal(save_1.SAVE_VERSION, 20);
    const LEGACY = ["wall_torch", "brazier", "craftbench", "table", "chair", "wall_banner"];
    for (const v of [9, 10, 11])
        for (const knows of [true, false]) {
            const raw = preRollout(v, knows, ["analysis.surprise"]), w = (0, save_1.deserialize)(raw), pl = (0, world_1.player)(w);
            strict_1.default.equal((0, save_1.migrate)(raw).version, 20);
            for (const id of LEGACY)
                strict_1.default.equal(w.flags.has(`analysis.${id}`), knows, `v${v} ${knows ? "with" : "without"} know.build: ${id}`);
            strict_1.default.equal(w.flags.has("analysis.storage_chest"), false, `v${v}: the storage chest is not grandfathered`);
            strict_1.default.ok(w.flags.has("analysis.surprise"), "flags it had are kept");
            if (knows) {
                for (const id of ["torch_post", "wall_torch", "craftbench", "barricade", "table", "chair", "wall_banner"])
                    strict_1.default.equal((0, analysis_1.planLock)(w, pl, build_1.RECIPES[id]), null, `v${v}: still knows ${id}`);
                strict_1.default.equal((0, analysis_1.planLock)(w, pl, build_1.RECIPES.storage_chest), "analysis");
            }
            const workers = w.actors.filter((a) => a.id === WORKER);
            strict_1.default.equal(workers.length, 1);
            strict_1.default.deepEqual([workers[0].definition, workers[0].x, workers[0].y, workers[0].powerCore], ["worker_golem", map_1.ARTIFICERY_WORKER.x, map_1.ARTIFICERY_WORKER.y, null]);
            strict_1.default.deepEqual((0, save_1.serialize)((0, save_1.deserialize)((0, save_1.serialize)(w))), (0, save_1.serialize)(w), "round trip");
        }
});
(0, node_test_1.test)("v4 saves pass both worker migrations (MIGRATIONS[4] loops the live spawns) and still get one worker, one guardian", () => {
    const w = (0, save_1.deserialize)(preRollout(4, false));
    strict_1.default.equal(w.actors.filter((a) => a.id === WORKER).length, 1);
    strict_1.default.equal(w.actors.filter((a) => a.id === helpers_1.GUARDIAN).length, 1);
    strict_1.default.equal((0, world_1.actorById)(w, WORKER).definition, "worker_golem");
});
(0, node_test_1.test)("a migrated player standing where the worker goes: the worker takes its second spot, never overlapping a body", () => {
    const raw = preRollout(11, true);
    const p = raw.actors.find((a) => a.id === raw.playerId);
    p.x = map_1.ARTIFICERY_WORKER.x + 2;
    p.y = map_1.ARTIFICERY_WORKER.y + 1;
    const w = (0, save_1.deserialize)(raw), wk = (0, world_1.actorById)(w, WORKER), pl = (0, world_1.player)(w);
    strict_1.default.deepEqual([wk.x, wk.y], [5 * tiles_1.TS + 8, 43 * tiles_1.TS + 12]);
    const a = (0, collision_1.actorBox)(wk), b = (0, collision_1.actorBox)(pl);
    strict_1.default.ok(!(a[0] < b[2] && b[0] < a[2] && a[1] < b[3] && b[1] < a[3]), "no overlap");
    (0, helpers_1.frames)(w, 30, { ix: 1, iy: 0, use: false });
    strict_1.default.ok(pl.x > map_1.ARTIFICERY_WORKER.x + 2, "the player walks freely");
    // a fresh v12 world is untouched by the migration
    const fresh = (0, save_1.serialize)((0, helpers_1.newWorld)(8));
    const again = JSON.parse(JSON.stringify(fresh));
    again.version = 11;
    strict_1.default.deepEqual((0, save_1.migrate)(again), fresh);
});
// ------------------------------------------------------------------ the host's seams
(0, node_test_1.test)("the opening with a second golem in the room: the worker is in frame, clear of the diagnostic log and the bars", () => {
    const g = new game_1.Game(canvas(), canvas());
    g.keyDown("x");
    tick(g);
    g.keyUp("x");
    strict_1.default.ok(g.screens.is("intro"));
    const wk = (0, world_1.actorById)(g.world, WORKER);
    for (let t = 0; t < 11; t += 0.5) {
        tick(g, 30);
        const x0 = wk.x - g.cam.x - 7, x1 = x0 + 14, y1 = wk.y - g.cam.y, y0 = y1 - 22;
        strict_1.default.ok(x0 >= 0 && x1 <= 320 && y0 >= 14 && y1 <= 180 - 14, `in view, inside the letterbox (${x0},${y0})`);
        strict_1.default.ok(x0 > 6 + 6 + 4 * 24 || y0 > 7 + 12 + 9 * 5, "not under the monologue's lines");
    }
});
const canvas = () => globalThis.document.createElement("canvas");
const tick = (g, n = 1) => { for (let i = 0; i < n; i++)
    g.update(1 / 60); };
const press = (g, key) => { g.keyDown(key); tick(g); g.keyUp(key); };
(0, node_test_1.test)("host: C on the golem gives matching in/out feedback, E on it opens its management screen, E on a chest its storage screen", () => {
    const g = new game_1.Game(canvas(), canvas()), w = (0, helpers_1.newWorld)();
    g.resume(w);
    const pl = (0, world_1.player)(w), wk = (0, world_1.actorById)(w, WORKER);
    (0, inventory_1.addItems)(w, pl, "ruby_core", 1);
    (0, helpers_1.standAt)(w, (0, interact_1.npcInteractables)(w, (0, world_1.currentArea)(w)).find((i) => i.actorId === WORKER));
    tick(g);
    press(g, "e");
    tick(g, 30);
    strict_1.default.ok(g.screens.is("play"), "E on the dormant worker opens nothing: its screen stays shut until a core has been slotted in");
    tick(g, 30); // the reach finishes
    press(g, "c");
    tick(g, 60);
    strict_1.default.ok((0, actorStats_1.powered)(wk));
    strict_1.default.equal(g.note?.text, "RUBY GOLEM CORE SLOTTED - IT POWERS ON");
    press(g, "e");
    tick(g, 30);
    strict_1.default.ok(g.screens.is("manage"));
    press(g, "escape");
    tick(g, 30);
    press(g, "c");
    tick(g, 60);
    strict_1.default.ok(!(0, actorStats_1.powered)(wk));
    strict_1.default.equal(g.note?.text, "RUBY GOLEM CORE TAKEN OUT - IT POWERS DOWN");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "ruby_core"), 1);
    // core out again: the screen still opens
    press(g, "e");
    tick(g, 30);
    strict_1.default.ok(g.screens.is("manage"));
    press(g, "escape");
    tick(g, 30);
    // a storage chest standing in the artificery: E opens its storage screen
    const area = (0, world_1.currentArea)(w), chest = area.addProp("storage_chest", 11 * tiles_1.TS + 8, 42 * tiles_1.TS + 16);
    (0, helpers_1.standAt)(w, (0, helpers_1.find)(w, (i) => i.propId === chest.id));
    tick(g);
    press(g, "e");
    tick(g, 30);
    strict_1.default.ok(g.screens.is("storage"));
    press(g, "escape");
    strict_1.default.ok(g.screens.is("play"));
});
