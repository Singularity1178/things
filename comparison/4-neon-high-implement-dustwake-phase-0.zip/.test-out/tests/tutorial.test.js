"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The tutorial, played headlessly end to end through the sim API. This is the
// regression net for the tutorial's mechanics: requirements, item flow, world
// changes, the puzzle and the teleport.
const inventory_1 = require("../src/game/sim/inventory");
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const world_1 = require("../src/game/world/world");
const tiles_1 = require("../src/game/content/tiles");
const flags_1 = require("../src/game/content/flags");
const interact_1 = require("../src/game/sim/interact");
const ritual_1 = require("../src/game/sim/ritual");
const helpers_1 = require("./helpers");
const inventory_2 = require("../src/game/sim/inventory");
(0, node_test_1.test)("start state matches the authored dungeon", () => {
    const w = (0, helpers_1.newWorld)();
    const a = (0, world_1.currentArea)(w), pl = (0, world_1.player)(w);
    strict_1.default.equal(a.id, "dungeon");
    strict_1.default.equal(a.w, 72);
    strict_1.default.equal(a.h, 56);
    strict_1.default.deepEqual([pl.x, pl.y], [9 * tiles_1.TS + 8, 38 * tiles_1.TS + 14]);
    strict_1.default.equal(a.tile(51, 5), tiles_1.T.LOCKED);
    strict_1.default.equal(a.tile(47, 10), tiles_1.T.CRACKED);
    const kinds = (0, interact_1.interactables)(a).map((i) => i.kind);
    strict_1.default.equal(kinds.filter((k) => k === "door").length, 1);
    strict_1.default.equal(kinds.filter((k) => k === "cracked").length, 1, "two-tile crack anchors once");
    strict_1.default.equal(kinds.filter((k) => k === "socket").length, 4);
    const door = (0, helpers_1.find)(w, (i) => i.kind === "door");
    strict_1.default.deepEqual([door.x, door.y, door.r], [51 * tiles_1.TS - 2, 5 * tiles_1.TS + 10, 18]);
    const crack = (0, helpers_1.find)(w, (i) => i.kind === "cracked");
    strict_1.default.deepEqual([crack.x, crack.y, crack.r], [47 * tiles_1.TS + 8, 11 * tiles_1.TS, 22]);
});
(0, node_test_1.test)("the solution is a seeded permutation", () => {
    const s = (seed) => (0, world_1.currentArea)((0, helpers_1.newWorld)(seed)).ritual.solution;
    strict_1.default.deepEqual(s(7), s(7));
    strict_1.default.deepEqual([...s(7)].sort(), [0, 1, 2, 3]);
    const seen = new Set();
    for (let i = 0; i < 40; i++)
        seen.add(s(i).join());
    strict_1.default.ok(seen.size > 5, "different sessions get different solutions");
});
(0, node_test_1.test)("walking moves the golem, limps, and collides with walls", () => {
    const w = (0, helpers_1.newWorld)();
    const pl = (0, world_1.player)(w);
    const x0 = pl.x;
    (0, helpers_1.frames)(w, 60, { ix: 1, iy: 0, use: false });
    strict_1.default.ok(pl.x > x0 + 10, "moved right");
    strict_1.default.equal(pl.facing, "right");
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "step"));
    (0, helpers_1.frames)(w, 600, { ix: -1, iy: 0, use: false });
    strict_1.default.ok(pl.x > 4 * tiles_1.TS && pl.x < 6 * tiles_1.TS, "stopped at the artificery's west wall");
});
(0, node_test_1.test)("full tutorial playthrough", () => {
    const w = (0, helpers_1.newWorld)(99);
    const pl = (0, world_1.player)(w), area = (0, world_1.currentArea)(w), r = area.ritual;
    // Without the arm the slam (Space) lands but the cracked wall holds; E only shudders it, with a hint.
    (0, helpers_1.slamAt)(w, (0, helpers_1.find)(w, (i) => i.kind === "cracked"));
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "withstood"));
    strict_1.default.equal(area.tile(47, 10), tiles_1.T.CRACKED);
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "cracked"));
    const pushed = (0, helpers_1.events)(w);
    strict_1.default.ok(pushed.some((e) => e.t === "cue" && e.cue === "push"));
    strict_1.default.ok(pushed.some((e) => e.t === "message" && /SPACE/.test(e.text)));
    strict_1.default.equal(area.tile(47, 10), tiles_1.T.CRACKED);
    // Arm: taken from the rack and attached, not stored.
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "limbrack@65.5,3"));
    strict_1.default.ok((0, world_1.hasFlag)(w, flags_1.FLAGS.golemArm));
    strict_1.default.ok(!(0, inventory_1.hasItem)(pl, "arm"));
    let ev = (0, helpers_1.events)(w);
    strict_1.default.ok(ev.some((e) => e.t === "itemGained" && e.item === "arm" && !e.stored));
    strict_1.default.ok(ev.some((e) => e.t === "equipped"));
    // E still doesn't break it; the slam does: both tiles open, debris decals appear, interactable disappears.
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "cracked"));
    strict_1.default.equal(area.tile(47, 10), tiles_1.T.CRACKED);
    const decals0 = area.decals.length, rev0 = area.revision;
    (0, helpers_1.slamAt)(w, (0, helpers_1.find)(w, (i) => i.kind === "cracked"));
    strict_1.default.equal(area.tile(47, 10), tiles_1.T.FLOOR);
    strict_1.default.equal(area.tile(47, 11), tiles_1.T.FLOOR);
    strict_1.default.equal(area.decals.length, decals0 + 26);
    strict_1.default.ok(area.revision > rev0);
    strict_1.default.ok(!(0, interact_1.interactables)(area).some((i) => i.kind === "cracked"));
    // Door needs the key; the key is in a skeleton (container -> delayed grant).
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "door"));
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "cue" && e.cue === "clank"));
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "skeleton@66,32"));
    strict_1.default.ok((0, inventory_1.hasItem)(pl, "key"));
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "door"));
    strict_1.default.equal(area.tile(51, 5), tiles_1.T.FLOOR);
    strict_1.default.ok(!(0, inventory_1.hasItem)(pl, "key"), "key consumed");
    strict_1.default.equal(area.decals[area.decals.length - 1].kind, "door_open");
    // The treasury was looted long ago: its chest is open and empty. The core
    // comes from the Treasury Guardian, who wakes, mends the eye and hands it over.
    strict_1.default.ok(!(0, interact_1.interactables)(area).some((i) => i.propId === "chest@57,4"));
    strict_1.default.deepEqual((0, helpers_1.talkThrough)(w, (0, helpers_1.guardianIt)(w)), ["intro", "repair", "core", "farewell"]);
    strict_1.default.ok((0, world_1.hasFlag)(w, flags_1.FLAGS.golemEye));
    strict_1.default.equal((0, inventory_2.countItem)(pl, "core"), 1);
    // Collect everything else.
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "workbench@13.5,37"));
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "maptable@39.5,5"));
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "hearth@60.5,43"));
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "lectern@5,29"));
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "footlocker@63,21"));
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "altar@26,48"));
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.looseId === "crown"));
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.looseId === "coin"));
    (0, helpers_1.useOn)(w, (0, helpers_1.propItem)(w, "longtable@59.5,47"));
    for (const id of ["core", "chisel", "schematic", "glyph0", "glyph1", "glyph2", "glyph3", "crown", "coin", "goblet"])
        strict_1.default.ok((0, inventory_1.hasItem)(pl, id), id);
    // Carving needs the schematic to have been read (the UI sets this flag on opening it).
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "gap"));
    strict_1.default.equal(r.carved, false);
    (0, world_1.setFlag)(w, flags_1.FLAGS.knowSchematic);
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "gap"));
    strict_1.default.equal(r.carved, true);
    (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "center"));
    strict_1.default.equal(r.core, true);
    strict_1.default.ok(!(0, inventory_1.hasItem)(pl, "core"));
    // Seat glyphs in a wrong order -> fizzle and mark wrong sockets.
    const wrong = [r.solution[1], r.solution[0], r.solution[2], r.solution[3]];
    (0, helpers_1.events)(w);
    wrong.forEach((g, s) => { (0, ritual_1.placeGlyph)(w, pl, area, s, g); while (pl.task)
        (0, helpers_1.frame)(w); });
    strict_1.default.equal(r.active, false);
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "runeFizzled"));
    strict_1.default.deepEqual(r.wrong, [true, true, false, false]);
    // Take the two wrong glyphs back (via the socket interaction) and seat them correctly.
    for (const s of [0, 1])
        (0, helpers_1.useOn)(w, (0, helpers_1.find)(w, (i) => i.kind === "socket" && i.socket === s));
    for (const s of [0, 1]) {
        (0, ritual_1.placeGlyph)(w, pl, area, s, r.solution[s]);
        while (pl.task)
            (0, helpers_1.frame)(w);
    }
    strict_1.default.equal(r.active, true);
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "runeActivated"));
    // Teleport only after the circle has charged for 3s and the golem stands on it.
    const c = area.ritualPos;
    pl.x = c.x;
    pl.y = c.y + 2;
    (0, helpers_1.frame)(w);
    strict_1.default.ok(!(0, helpers_1.events)(w).some((e) => e.t === "teleport"), "not yet charged");
    (0, helpers_1.frames)(w, 200);
    strict_1.default.ok((0, helpers_1.events)(w).some((e) => e.t === "teleport"));
    strict_1.default.ok(w.playTime > 0);
});
(0, node_test_1.test)("an empty socket with glyphs in the pack asks the UI for a choice", () => {
    const w = (0, helpers_1.newWorld)();
    const pl = (0, world_1.player)(w);
    (0, inventory_1.addItems)(w, pl, "glyph2", 1);
    const sock = (0, helpers_1.find)(w, (i) => i.kind === "socket" && i.socket === 3);
    (0, helpers_1.standAt)(w, sock);
    strict_1.default.equal((0, interact_1.findTarget)((0, world_1.currentArea)(w), pl)?.socket, 3);
    const res = (0, helpers_1.frame)(w, { ix: 0, iy: 0, use: true });
    strict_1.default.deepEqual(res.ui, { ui: "selectGlyph", socket: 3 });
    strict_1.default.equal(pl.task, null);
});
