"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Westwake's edge and its wall: the map simply ends (no thicket: the ground
// runs to the last tile and stops), the town wall is a closed ring with a gate
// at each end of the High Street, and the layout audit
// (tests/support/townAudit.ts) finds nothing wrong in the town or its rooms.
// Headless: builders, sim and the recording fake canvas only.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const areas_1 = require("../src/game/world/areas");
const area_1 = require("../src/game/world/area");
const town_1 = require("../src/game/town");
const town_2 = require("../src/game/content/town");
const tiles_1 = require("../src/game/content/tiles");
const reach_1 = require("../src/game/sim/reach");
const collision_1 = require("../src/game/sim/collision");
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const tilesTown_1 = require("../src/game/art/tilesTown");
const townAudit_1 = require("./support/townAudit");
const helpers_1 = require("./helpers");
const Wl = town_2.STREETS.wall;
const onRing = (x, y) => x >= Wl.westX0 && x <= Wl.x1 && y >= Wl.northY0 && y <= Wl.southY1 && (x <= Wl.westX1 || x >= Wl.x0 || y <= Wl.northY1 || y >= Wl.southY0);
const inGate = (x, y) => onRing(x, y) && y >= Wl.gateY0 && y <= Wl.gateY1;
const outside = (x, y) => x < Wl.westX0 || x > Wl.x1 || y < Wl.northY0 || y > Wl.southY1;
const TOWERS = ["gate_n", "gate_s", "bar_n", "bar_s"].map(town_2.building);
(0, node_test_1.test)("the map just ends: no thicket anywhere, and plain ground runs to all four edges", () => {
    const t = (0, town_1.buildTown)();
    strict_1.default.ok(!t.grid.includes(tiles_1.T.THICKET), "no thicket is left in the town");
    for (let x = 0; x < t.w; x++) {
        strict_1.default.equal(t.grid[x], tiles_1.T.FLOOR, `top edge ${x}`);
        strict_1.default.equal(t.grid[(t.h - 1) * t.w + x], tiles_1.T.FLOOR, `bottom edge ${x}`);
    }
    for (let y = 0; y < t.h; y++) {
        strict_1.default.equal(t.grid[y * t.w], tiles_1.T.FLOOR, `left edge ${y}`);
        strict_1.default.equal(t.grid[y * t.w + t.w - 1], tiles_1.T.FLOOR, `right edge ${y}`);
    }
    // the old road still runs out through the east gate to the last column, and the west road out past the bar
    const mid = town_2.STREETS.high.y0 + 1;
    for (const x of [0, 1, 2, t.w - 3, t.w - 2, t.w - 1])
        strict_1.default.equal(t.grid[mid * t.w + x], tiles_1.T.FLOOR, `road at ${x}`);
    // nothing scattered stands on the outermost ring of tiles, where its picture would be cut off
    for (const p of t.props)
        strict_1.default.ok(p.x >= tiles_1.TS && p.x < (t.w - 1) * tiles_1.TS && p.y > tiles_1.TS, `${p.id} keeps off the edge`);
});
(0, node_test_1.test)("the town wall is a closed ring of rampart, open only where the High Street passes through it", () => {
    const t = (0, town_1.buildTown)(), I = (x, y) => y * t.w + x;
    const tower = (x, y) => TOWERS.some((b) => x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h);
    strict_1.default.ok(Wl.westX0 > 0 && Wl.northY0 > 0 && Wl.x1 < t.w - 1 && Wl.southY1 < t.h - 1, "there is ground outside every side of the wall");
    let gates = 0;
    for (let y = 0; y < t.h; y++)
        for (let x = 0; x < t.w; x++) {
            if (!onRing(x, y))
                continue;
            if (inGate(x, y)) {
                gates++;
                strict_1.default.equal(t.grid[I(x, y)], tiles_1.T.FLOOR, `the gate is open at ${x},${y}`);
                continue;
            }
            strict_1.default.ok((0, tiles_1.isSolidT)(t.grid[I(x, y)]), `the wall is solid at ${x},${y}`);
            strict_1.default.ok(tower(x, y) || (t.grid[I(x, y)] === tiles_1.T.WALL && t.style[I(x, y)] === tiles_1.WS.RAMPART), `${x},${y} is rampart or a gate tower`);
        }
    strict_1.default.equal(gates, 2 * (Wl.gateY1 - Wl.gateY0 + 1) * 2, "two gates, each the width of the street and the depth of the wall");
    // every building stands inside it (the towers stand astride it)
    for (const b of town_2.BUILDINGS)
        if (!TOWERS.includes(b))
            strict_1.default.ok(b.x > Wl.westX1 && b.x + b.w <= Wl.x0 && b.y > Wl.northY1 && b.y + b.h <= Wl.southY0, `${b.id} is inside the wall`);
    // tile by tile, with the gates shut, nothing inside connects to anything outside
    const seen = new Uint8Array(t.w * t.h), q = [I(47, 30)];
    seen[q[0]] = 1;
    while (q.length) {
        const k = q.pop(), x = k % t.w, y = (k / t.w) | 0;
        strict_1.default.ok(!outside(x, y), `the wall leaks: ${x},${y} is outside it`);
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
            const nx = x + dx, ny = y + dy;
            if (nx < 0 || ny < 0 || nx >= t.w || ny >= t.h || seen[I(nx, ny)] || (0, tiles_1.isSolidT)(t.grid[I(nx, ny)]) || inGate(nx, ny))
                continue;
            seen[I(nx, ny)] = 1;
            q.push(I(nx, ny));
        }
    }
});
(0, node_test_1.test)("the West Bar is shut: the bar spans its passage, so the east gate is the only way through the wall", () => {
    const a = new area_1.Area(areas_1.AREAS[town_2.TOWN_ID]());
    const boxes = a.props.filter(collision_1.propBlocks).map((p) => p.box);
    const bar = a.props.find((p) => p.kind === "tollbar");
    strict_1.default.ok(bar.box, "the bar is solid");
    strict_1.default.ok(bar.box[1] <= Wl.gateY0 * tiles_1.TS && bar.box[3] >= (Wl.gateY1 + 1) * tiles_1.TS, "it reaches from tower to tower");
    strict_1.default.ok(bar.box[0] >= Wl.westX0 * tiles_1.TS && bar.box[2] <= (Wl.westX1 + 1) * tiles_1.TS, "and lies within the thickness of the wall");
    // as built, the golem can get out (by the east gate)...
    const open = (0, reach_1.reachable)(a, boxes, a.base.start);
    strict_1.default.ok(open[(Wl.gateY0 + 1) * a.w + Wl.x1 + 2], "the road outside the east gate can be walked to");
    // ...but with the east gate blocked as well, nowhere outside the wall can be reached: the bar cannot be passed or walked round
    const shut = [Wl.x0 * tiles_1.TS, Wl.gateY0 * tiles_1.TS, (Wl.x1 + 1) * tiles_1.TS, (Wl.gateY1 + 1) * tiles_1.TS];
    const closed = (0, reach_1.reachable)(a, [...boxes, shut], a.base.start);
    strict_1.default.ok(closed[(Wl.gateY0 + 1) * a.w + Wl.westX1 + 2], "the street just inside the bar can still be walked to");
    for (let y = 0; y < a.h; y++)
        for (let x = 0; x < a.w; x++)
            if (outside(x, y))
                strict_1.default.equal(closed[y * a.w + x], 0, `${x},${y} is outside the wall`);
});
(0, node_test_1.test)("walking into the edge of the map: the golem stops where the tiles end, in every direction", () => {
    const t = (0, town_1.buildTown)(), W = t.w * tiles_1.TS, H = t.h * tiles_1.TS;
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
    const walk = (ix, iy, n = 240) => { for (let i = 0; i < n; i++)
        (0, helpers_1.frame)(w, { ix, iy, use: false }); };
    // the north-west corner of the land outside the wall
    (0, world_1.enterArea)(w, pl, town_2.TOWN_ID, 24, 24);
    walk(-1, 0);
    walk(0, -1);
    walk(-1, -1);
    strict_1.default.equal(pl.area, town_2.TOWN_ID);
    strict_1.default.ok(pl.x >= 5 - 0.01 && pl.x < 12 && pl.y >= 5 - 0.01 && pl.y < 12, `stopped in the corner (${pl.x.toFixed(1)}, ${pl.y.toFixed(1)})`);
    // the south-east corner
    pl.x = W - 24;
    pl.y = H - 24;
    pl.vx = pl.vy = 0;
    walk(1, 0);
    walk(0, 1);
    walk(1, 1);
    strict_1.default.equal(pl.area, town_2.TOWN_ID);
    strict_1.default.ok(pl.x <= W - 5 + 0.01 && pl.x > W - 12 && pl.y <= H + 0.01 && pl.y > H - 7, `stopped in the corner (${pl.x.toFixed(1)}, ${pl.y.toFixed(1)})`);
    // the west road beyond the bar is a road that goes nowhere yet: pushing along it off the map changes nothing
    pl.x = 40;
    pl.y = (town_2.STREETS.high.y0 + 1) * tiles_1.TS + 12;
    pl.vx = pl.vy = 0;
    walk(-1, 0, 400);
    strict_1.default.equal(pl.area, town_2.TOWN_ID);
    strict_1.default.ok(pl.x >= 5 - 0.01 && pl.x < 12);
});
(0, node_test_1.test)("layout audit: nothing in the town or its rooms stands in a wall, in something else, on a doorstep or out of reach", () => {
    for (const id of townAudit_1.AUDIT_AREAS)
        strict_1.default.deepEqual((0, townAudit_1.auditArea)(id).map((f) => `[${f.check}] ${f.msg}`), [], id);
});
(0, node_test_1.test)("houses are painted over the ground decals round them, and the wall-walk has a parapet wherever it drops away", () => {
    const t = (0, town_1.buildTown)(), first = t.decals.findIndex((d) => d.kind === "building");
    strict_1.default.ok(first > 0, "ground decals come first");
    strict_1.default.ok(t.decals.slice(first).every((d) => d.kind === "building"), "then every building, last");
    strict_1.default.equal(t.decals.length - first, town_2.BUILDINGS.length);
    const O = tilesTown_1.RAMPART_OPEN, px = (lx, ly, open) => (0, tilesTown_1.rampartTopPix)(3, 3, lx, ly, open).join();
    const cases = [[O.L, 1, 8], [O.R, 14, 8], [O.U, 8, 1], [O.D, 8, 14], [O.UL, 1, 1], [O.UR, 14, 1], [O.DL, 1, 14], [O.DR, 14, 14]];
    for (const [bit, lx, ly] of cases) {
        strict_1.default.notEqual(px(lx, ly, bit), px(lx, ly, 0), `open side ${bit}: a parapet at ${lx},${ly}`);
        strict_1.default.equal(px(8, 8, bit), px(8, 8, 0), `open side ${bit}: the middle of the walk is still paving`);
    }
    // an inner corner's post fills only its own corner of the tile
    strict_1.default.equal(px(1, 14, O.DR), px(1, 14, 0));
    strict_1.default.equal(px(14, 1, O.DR), px(14, 1, 0));
});
(0, node_test_1.test)("a save from before the wall: a golem saved where masonry now stands is set down on free ground beside it", () => {
    const roundTrip = (x, y) => {
        const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w);
        (0, world_1.enterArea)(w, pl, town_2.TOWN_ID, x, y);
        pl.x = x;
        pl.y = y;
        pl.vx = pl.vy = 0;
        const kept = new Map(), storage = { getItem: (k) => kept.get(k) ?? null, setItem: (k, v) => { kept.set(k, v); } };
        (0, save_1.saveToStorage)(w, storage);
        const back = (0, save_1.loadFromStorage)(storage);
        // (deserialize alone stays the exact inverse of serialize: the guard is on the way in from storage)
        strict_1.default.deepEqual((0, save_1.serialize)((0, save_1.deserialize)((0, save_1.serialize)(w))), (0, save_1.serialize)(w));
        return { p: (0, world_1.player)(back), a: (0, world_1.getArea)(back, town_2.TOWN_ID) };
    };
    // inside the north wall, inside the West Bar's tower, inside the south wall (all open meadow, once)
    for (const [x, y] of [[40 * tiles_1.TS + 8, Wl.northY0 * tiles_1.TS + 20], [4 * tiles_1.TS + 8, 27 * tiles_1.TS], [60 * tiles_1.TS + 8, Wl.southY0 * tiles_1.TS + 24]]) {
        const { p, a } = roundTrip(x, y);
        strict_1.default.equal(p.area, town_2.TOWN_ID);
        strict_1.default.ok((0, collision_1.boxFree)(a, p.x, p.y), `(${x}, ${y}) loads onto free ground`);
        strict_1.default.ok(Math.hypot(p.x - x, p.y - y) <= 80, `(${x}, ${y}) loads close to where it was saved`);
    }
    // somewhere sensible is left exactly as it was saved
    const { p } = roundTrip(47 * tiles_1.TS + 8, 34 * tiles_1.TS + 8);
    strict_1.default.deepEqual([p.x, p.y], [47 * tiles_1.TS + 8, 34 * tiles_1.TS + 8]);
});
