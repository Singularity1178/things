"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Art added with crafted materials, runes and the gear slots. Own file: node
// --test runs each file in a fresh process, so the sprite cache starts empty
// and the traces don't depend on other tests. The goldens for what existed
// before (tests/artRegistry.test.ts, tests/golemArt.test.ts) are untouched;
// these pin the new icons, slot silhouettes and rune-bearing poses.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const items_1 = require("../src/game/art/items");
const slots_1 = require("../src/game/art/slots");
const golem_1 = require("../src/game/golem");
const gear_1 = require("../src/game/content/gear");
const items_2 = require("../src/game/content/items");
const util_1 = require("../src/game/util");
const GOLDEN = { items: "650359c4", slots: "fef1ce6e", runes: "fea2d425" };
const NEW_ITEMS = ["planks", "cut_stone", "rune_swift", "rune_glow"];
(0, node_test_1.test)("every item has an icon and a description", () => {
    for (const id of items_2.ITEM_IDS) {
        strict_1.default.ok(items_1.ITEM_ART[id], id);
        strict_1.default.ok(items_2.ITEMS[id].desc && items_2.ITEMS[id].desc.length <= 3 && items_2.ITEMS[id].desc.every((l) => l.length <= 34), id);
    }
});
(0, node_test_1.test)("new item icons are pixel-stable", () => {
    (0, fakeCanvas_1.resetTrace)();
    for (const id of NEW_ITEMS)
        (0, items_1.itemIcon)(id);
    strict_1.default.equal((0, fakeCanvas_1.traceHash)(), GOLDEN.items);
});
(0, node_test_1.test)("slot silhouettes: one per slot kind, pixel-stable", () => {
    for (const d of gear_1.GEAR_SLOT_DEFS)
        strict_1.default.ok(slots_1.SLOT_ART[d.kind], d.id);
    (0, fakeCanvas_1.resetTrace)();
    for (const k of Object.keys(slots_1.SLOT_ART))
        (0, slots_1.slotIcon)(k);
    strict_1.default.equal((0, fakeCanvas_1.traceHash)(), GOLDEN.slots);
});
(0, node_test_1.test)("runes show on the golem in every facing; no runes draws nothing extra", () => {
    const swift = { col: "#5cf0c8", pat: ["#..", ".#.", "#.."] }, glow = { col: "#ffffff", pat: [".#.", "###", ".#."] };
    const trace = (list) => {
        (0, fakeCanvas_1.resetTrace)();
        const c = (0, util_1.makeCanvas)(48, 48);
        for (const p of list) {
            (0, golem_1.drawGolem)(new util_1.Pen(c.ctx, false), 24, 40, p);
            (0, golem_1.drawGolem)(new util_1.Pen(c.ctx, true), 24, 40, p);
        }
        return (0, fakeCanvas_1.traceHash)();
    };
    const list = [];
    for (const facing of ["down", "up", "left", "right"])
        for (const hasArm of [false, true])
            for (const back of [undefined, "basket"])
                list.push({ facing, phase: 0, moving: false, hasArm, dormant: 0, eye: 1, core: 1, raise: 0, reach: 0, t: 0.3, back, runes: [swift, glow, swift, glow] });
    strict_1.default.equal(trace(list), GOLDEN.runes);
    for (const p of list.slice(0, 8)) {
        strict_1.default.notEqual(trace([p]), trace([{ ...p, runes: undefined }]), `${p.facing}: visible`);
        strict_1.default.equal(trace([{ ...p, runes: [null, null, null, null] }]), trace([{ ...p, runes: undefined }]), "empty slots draw nothing");
        strict_1.default.notEqual(trace([{ ...p, runes: [swift, null, null, null] }]), trace([{ ...p, runes: [null, swift, null, null] }]), "each slot has its own place");
    }
});
