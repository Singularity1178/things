"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// The real host (Game, on the fake canvas, driven by held keys) in Westwake:
// walking the old road and a shop door through the play screen, the host's
// answer to the `portal` event (the view follows, a fade, the place's name as a
// note), drawing the town and a room, and a lived-in room staying quiet (no
// cave rumble). The sim side of all this is tests/town.test.ts.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const g0 = globalThis;
g0.localStorage ?? (g0.localStorage = { getItem: () => null, setItem: () => { }, removeItem: () => { } });
const game_1 = require("../src/game/game");
const area_1 = require("../src/game/world/area");
const areas_1 = require("../src/game/world/areas");
const world_1 = require("../src/game/world/world");
const portals_1 = require("../src/game/sim/portals");
const geography_1 = require("../src/game/content/geography");
const helpers_1 = require("./helpers");
const canvas = () => globalThis.document.createElement("canvas");
const tick = (g, n = 1, dt = 1 / 60) => { for (let i = 0; i < n; i++)
    g.update(dt); };
/** Hold a key until `done` (or give up). */
function hold(g, key, done, max = 900) {
    g.keyDown(key);
    for (let i = 0; i < max && !done(); i++)
        tick(g);
    g.keyUp(key);
    tick(g);
    return done();
}
(0, node_test_1.test)("the host: west along the old road into Westwake, into the tavern and out again", () => {
    const w = (0, helpers_1.newWorld)(), pl = (0, world_1.player)(w), g = new game_1.Game(canvas(), canvas());
    const out = (0, portals_1.portalArrival)((0, portals_1.portalById)(new area_1.Area(areas_1.AREAS.surface()), geography_1.WEST_ROAD.portal));
    (0, world_1.enterArea)(w, pl, "surface", out.x + 24, out.y);
    g.resume(w);
    tick(g, 5);
    strict_1.default.ok(g.screens.is("play"));
    strict_1.default.ok(hold(g, "a", () => pl.area === "town"), "holding west walks out of the wild and into the town");
    strict_1.default.equal(g.area.id, "town", "the view follows");
    strict_1.default.equal(g.note?.text, "WESTWAKE, MARKET TOWN");
    strict_1.default.ok(g.doorFade > 0, "arriving fades up from dark");
    g.render();
    tick(g, 60);
    strict_1.default.equal(g.doorFade, 0, "and the fade is short");
    g.render(); // the east gate, lit: nothing throws
    const door = (0, portals_1.portalArrival)((0, portals_1.portalById)(g.area, "door.tavern"));
    pl.x = door.x;
    pl.y = door.y;
    pl.vx = pl.vy = 0;
    tick(g, 2);
    g.render(); // Low Street and the tavern front
    strict_1.default.ok(hold(g, "w", () => pl.area === "town_tavern", 240), "pushing on the tavern door goes in");
    strict_1.default.equal(g.area.id, "town_tavern");
    strict_1.default.equal(g.note?.text, "THE SUNKEN CROWN");
    g.render();
    // a lived-in room: however long the golem stands in it, the buried halls' rumble never comes
    const quiet = g.rumbleT;
    tick(g, 60 * 20);
    strict_1.default.equal(g.rumbleT, quiet);
    g.render();
    strict_1.default.ok(hold(g, "s", () => pl.area === "town", 600), "walking down onto the sill goes back out");
    strict_1.default.equal(g.note?.text, "LOW STREET");
    strict_1.default.ok(g.screens.is("play"));
    g.render();
});
