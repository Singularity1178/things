"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Gear slots: the full set (helm, back, two arms, core attachment, four rune
// slots), which are usable and which locked, that unlocking is a data/state
// change, the wear / take-off rules (locked slots take nothing, fit checks,
// capacity tiers), the iron arm and aether core decisions, saves, the debug kit,
// and the pack screen's navigation between the paper doll and the pack.
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const fakeCanvas_1 = require("./support/fakeCanvas");
(0, fakeCanvas_1.installFakeCanvas)();
const world_1 = require("../src/game/world/world");
const save_1 = require("../src/game/world/save");
const inventory_1 = require("../src/game/sim/inventory");
const commands_1 = require("../src/game/sim/commands");
const tasks_1 = require("../src/game/sim/tasks");
const step_1 = require("../src/game/sim/step");
const gear_1 = require("../src/game/content/gear");
const items_1 = require("../src/game/content/items");
const flags_1 = require("../src/game/content/flags");
const font_1 = require("../src/game/font");
const gear_2 = require("../src/game/sim/gear");
const debug_1 = require("../src/game/sim/debug");
const pack_1 = require("../src/game/screens/pack");
const screens_1 = require("../src/game/ui/screens");
const helpers_1 = require("./helpers");
const fresh = () => { const w = (0, helpers_1.newWorld)(); (0, helpers_1.frame)(w); return { w, pl: (0, world_1.player)(w) }; };
const give = (w, id, n = 1) => (0, inventory_1.addItems)(w, (0, world_1.player)(w), id, n);
const slotOf = (w, id) => (0, world_1.player)(w).inventory.findIndex((s) => s?.item === id);
(0, node_test_1.test)("the golem has every slot; the sound arm, the helm, the core mount, the back and one rune slot are usable now; the rest are locked", () => {
    const { w, pl } = fresh();
    strict_1.default.deepEqual([...gear_1.GEAR_SLOTS].sort(), ["armL", "armR", "back", "core", "head", "rune0", "rune1", "rune2", "rune3"]);
    strict_1.default.equal(gear_1.RUNE_SLOTS.length, 4);
    strict_1.default.deepEqual((0, gear_2.usableSlots)(w, pl).sort(), ["armR", "back", "core", "head", "rune0"]);
    const locked = gear_1.GEAR_SLOTS.filter((s) => !(0, gear_2.slotUsable)(w, pl, s)).sort();
    strict_1.default.deepEqual(locked, ["armL", "rune1", "rune2", "rune3"]);
    // every locked slot says why; text fits the font and the description panel
    const ok = (s) => [...s].every((ch) => font_1.FONT_GLYPHS.has(ch));
    for (const d of gear_1.GEAR_SLOT_DEFS) {
        strict_1.default.ok(ok(d.name), d.id);
        for (const t of [...(d.hint ?? []), ...(d.locked ?? []).flatMap((l) => l.text)])
            strict_1.default.ok(ok(t) && t.length <= 34, `${d.id}: ${t}`);
        if (d.unlock)
            strict_1.default.ok((0, gear_2.lockedText)(w, pl, d).length > 0 && d.locked?.length, d.id);
        else
            strict_1.default.ok(d.hint && d.hint.length, d.id);
    }
});
(0, node_test_1.test)("which arm: the right arm is the sound one and usable; the left (the broken stub) opens once the iron arm is on it, or by its own flag", () => {
    const { w, pl } = fresh();
    strict_1.default.ok((0, gear_2.slotUsable)(w, pl, "armR") && !(0, gear_2.slotUsable)(w, pl, "armL"));
    strict_1.default.match((0, gear_2.lockedText)(w, pl, (0, gear_1.slotDef)("armL")).join(" "), /BROKEN STUB/);
    // the iron arm stays an installed body part (an equip flag, never a slot item), and now takes fittings
    strict_1.default.equal(items_1.ITEMS.arm.wear, undefined, "the iron arm stays an equip flag");
    strict_1.default.ok(items_1.ITEMS.arm.equip);
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
    strict_1.default.ok((0, gear_2.slotUsable)(w, pl, "armL"), "the iron arm opens the left arm slot");
    strict_1.default.ok(!(0, world_1.hasFlag)(w, flags_1.FLAGS.slotArmLeft), "nothing is stored for it: the slot follows the arm");
    (0, world_1.clearFlag)(w, flags_1.FLAGS.golemArm);
    strict_1.default.ok(!(0, gear_2.slotUsable)(w, pl, "armL"), "and shuts again without it");
    // the slot's own upgrade flag still opens it by itself (the debug kit; a proper arm later)
    (0, world_1.setFlag)(w, flags_1.FLAGS.slotArmLeft);
    strict_1.default.ok((0, gear_2.slotUsable)(w, pl, "armL"));
    strict_1.default.equal((0, debug_1.slotUnlockFlags)(pl).includes(flags_1.FLAGS.slotArmLeft), true, "the debug kit still knows which flag opens it");
});
(0, node_test_1.test)("the aether core is not slot-aware: it can't be worn, stays in the pack, and the core attachment slot is a separate mount", () => {
    const { w, pl } = fresh();
    give(w, "core");
    strict_1.default.equal(items_1.ITEMS.core.wear, undefined);
    strict_1.default.equal((0, commands_1.wearFromSlot)(w, pl, slotOf(w, "core")), "notWearable");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "core"), 1);
    strict_1.default.equal((0, gear_1.slotDef)("core").kind, "core");
    strict_1.default.ok((0, gear_2.slotUsable)(w, pl, "core"));
});
(0, node_test_1.test)("runes go in the first free usable rune slot; with one slot the next swaps the first back into the pack", () => {
    const { w, pl } = fresh();
    give(w, "rune_swift");
    give(w, "rune_glow");
    strict_1.default.equal((0, gear_2.targetSlot)(w, pl, "rune_swift"), "rune0");
    strict_1.default.equal((0, commands_1.wearFromSlot)(w, pl, slotOf(w, "rune_swift")), "ok");
    strict_1.default.equal(pl.gear.rune0, "rune_swift");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "rune_swift"), 0, "worn, not in the pack");
    strict_1.default.equal((0, commands_1.wearFromSlot)(w, pl, slotOf(w, "rune_glow")), "ok");
    strict_1.default.deepEqual([pl.gear.rune0, (0, inventory_1.countItem)(pl, "rune_swift")], ["rune_glow", 1], "swapped: the first is back in the pack");
    strict_1.default.equal(pl.gear.rune1, undefined, "locked slots take nothing");
    strict_1.default.equal((0, gear_2.wearCheck)(w, pl, slotOf(w, "rune_swift"), "rune1").ok, false, "explicitly into a locked slot is refused");
    strict_1.default.equal((0, gear_2.wearCheck)(w, pl, slotOf(w, "rune_swift"), "rune1").reason, "noSlot");
    // unlocking is just setting a flag: the same runes now fill the next slot
    (0, world_1.setFlag)(w, flags_1.FLAGS.slotRune1);
    strict_1.default.equal((0, commands_1.wearFromSlot)(w, pl, slotOf(w, "rune_swift")), "ok");
    strict_1.default.deepEqual([pl.gear.rune0, pl.gear.rune1], ["rune_glow", "rune_swift"]);
    strict_1.default.equal((0, commands_1.takeOffGear)(w, pl, "rune0"), "ok");
    strict_1.default.equal(pl.gear.rune0, undefined);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "rune_glow"), 1);
});
(0, node_test_1.test)("a future slot unlock is a data change: a new item for a locked arm slot needs no code", () => {
    const { w, pl } = fresh();
    const items = items_1.ITEMS;
    items.test_gauntlet = { name: "TEST GAUNTLET", tags: [], wear: { kind: "arm" } };
    items.test_left_only = { name: "TEST LEFT", tags: [], wear: { kind: "arm", slot: "armL" } };
    try {
        give(w, "test_gauntlet");
        give(w, "test_left_only");
        strict_1.default.equal((0, commands_1.wearFromSlot)(w, pl, slotOf(w, "test_left_only")), "noSlot", "a left-only item can't use a locked left arm");
        strict_1.default.equal((0, commands_1.wearFromSlot)(w, pl, slotOf(w, "test_gauntlet")), "ok");
        strict_1.default.equal(pl.gear.armR, "test_gauntlet");
        (0, world_1.setFlag)(w, flags_1.FLAGS.slotArmLeft);
        strict_1.default.equal((0, commands_1.wearFromSlot)(w, pl, slotOf(w, "test_left_only")), "ok");
        strict_1.default.equal(pl.gear.armL, "test_left_only");
    }
    finally {
        delete items.test_gauntlet;
        delete items.test_left_only;
    }
});
(0, node_test_1.test)("relocking a slot returns what it held to the pack; nothing is deleted and its effect stops", () => {
    const { w, pl } = fresh();
    (0, world_1.setFlag)(w, flags_1.FLAGS.slotRune1);
    give(w, "rune_swift");
    give(w, "rune_glow");
    (0, commands_1.wearFromSlot)(w, pl, slotOf(w, "rune_glow"));
    (0, commands_1.wearFromSlot)(w, pl, slotOf(w, "rune_swift"));
    strict_1.default.deepEqual([pl.gear.rune0, pl.gear.rune1], ["rune_glow", "rune_swift"]);
    strict_1.default.equal((0, gear_2.speedMultiplier)(w, pl), 1 + items_1.ITEMS.rune_swift.worn.speed);
    (0, world_1.clearFlag)(w, flags_1.FLAGS.slotRune1);
    strict_1.default.equal((0, gear_2.speedMultiplier)(w, pl), 1, "a locked slot's item has no effect even before it is put away");
    (0, helpers_1.events)(w);
    (0, helpers_1.frames)(w, 2);
    strict_1.default.equal(pl.gear.rune1, undefined);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "rune_swift"), 1);
    strict_1.default.equal(pl.gear.rune0, "rune_glow");
});
(0, node_test_1.test)("take-off fit rules: refused with nothing changed when the pack is full, and capacity tiers still follow the worn basket", () => {
    const { w, pl } = fresh();
    give(w, "rune_swift");
    (0, commands_1.wearFromSlot)(w, pl, slotOf(w, "rune_swift"));
    strict_1.default.equal((0, inventory_1.capacity)(w, pl), 8, "a rune grants no pack slots");
    pl.inventory = pl.inventory.map(() => ({ item: "coin", n: 1 }));
    const snap = JSON.stringify([pl.inventory, pl.gear]);
    const chk = (0, gear_2.takeOffCheck)(w, pl, "rune0");
    strict_1.default.ok(!chk.ok && chk.reason === "noRoom" && chk.over === 1 && chk.item === "rune_swift");
    (0, helpers_1.events)(w);
    strict_1.default.equal((0, commands_1.takeOffGear)(w, pl, "rune0"), "noRoom");
    strict_1.default.equal(JSON.stringify([pl.inventory, pl.gear]), snap, "nothing changed, nothing dropped");
    strict_1.default.match((0, helpers_1.events)(w)[0].text, /NO ROOM IN THE PACK FOR THE RUNE OF SWIFT/);
    strict_1.default.match((0, gear_2.gearRefusal)(chk), /FREE 1 SLOT$/);
    pl.inventory[3] = null;
    strict_1.default.equal((0, commands_1.takeOffGear)(w, pl, "rune0"), "ok");
    strict_1.default.equal(pl.inventory.map((x) => x?.item)[3], "rune_swift");
    // basket: worn it grants the 48-slot tier (any slot kind counts as worn), and the shrink check still applies
    const { w: w2, pl: p2 } = fresh();
    strict_1.default.ok((0, gear_2.ensureWorn)(w2, p2, "basket"));
    strict_1.default.equal((0, inventory_1.capacity)(w2, p2), 48);
    strict_1.default.equal(p2.gear.back, "basket");
    for (let i = 0; i < 9; i++)
        (0, inventory_1.addItems)(w2, p2, "coin", 1);
    const off = (0, gear_2.takeOffCheck)(w2, p2, "back");
    strict_1.default.ok(!off.ok && off.reason === "noRoom" && off.shrinks);
    strict_1.default.match((0, gear_2.gearRefusal)(off), /TOO MUCH TO CARRY WITHOUT THE WOVEN BASKET/);
});
(0, node_test_1.test)("worn gear in every slot round-trips through save/load, with the unlock flags", () => {
    const { w, pl } = fresh();
    (0, debug_1.toggleGearKit)(w, pl);
    (0, gear_2.ensureWorn)(w, pl, "rune_swift");
    (0, commands_1.wearFromSlot)(w, pl, slotOf(w, "rune_glow"));
    const w2 = (0, save_1.deserialize)(JSON.parse(JSON.stringify((0, save_1.serialize)(w))));
    strict_1.default.deepEqual((0, save_1.serialize)(w2), (0, save_1.serialize)(w));
    const p2 = (0, world_1.player)(w2);
    strict_1.default.deepEqual([p2.gear.back, p2.gear.rune0, p2.gear.rune1], ["basket", "rune_swift", "rune_glow"]);
    strict_1.default.ok((0, debug_1.allSlotsUnlocked)(w2));
    strict_1.default.equal((0, gear_2.usableSlots)(w2, p2).length, gear_1.GEAR_SLOTS.length);
});
(0, node_test_1.test)("debug kit (Ctrl+6): grants the materials and both runes, unlocks every locked slot, and toggles back", () => {
    const { w, pl } = fresh();
    strict_1.default.deepEqual((0, debug_1.slotUnlockFlags)().sort(), [flags_1.FLAGS.slotArmLeft, flags_1.FLAGS.slotRune1, flags_1.FLAGS.slotRune2, flags_1.FLAGS.slotRune3].sort());
    strict_1.default.equal((0, debug_1.toggleGearKit)(w, pl), true);
    strict_1.default.ok((0, debug_1.allSlotsUnlocked)(w));
    strict_1.default.deepEqual((0, gear_2.usableSlots)(w, pl).sort(), [...gear_1.GEAR_SLOTS].sort());
    strict_1.default.equal(pl.gear.back, "basket");
    for (const [item, n] of debug_1.GEAR_KIT)
        strict_1.default.ok((0, inventory_1.countItem)(pl, item) >= n, item);
    strict_1.default.ok((0, inventory_1.countItem)(pl, "planks") >= 40 && (0, inventory_1.countItem)(pl, "cut_stone") >= 40);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "rune_swift"), 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "rune_glow"), 1);
    strict_1.default.ok(w.flags.has(flags_1.FLAGS.knowBuild));
    // wear a rune in the slot that will lock again, and one in the slot that stays open
    (0, commands_1.wearFromSlot)(w, pl, slotOf(w, "rune_swift"));
    (0, commands_1.wearFromSlot)(w, pl, slotOf(w, "rune_glow"));
    strict_1.default.deepEqual([pl.gear.rune0, pl.gear.rune1], ["rune_swift", "rune_glow"]);
    strict_1.default.equal((0, debug_1.toggleGearKit)(w, pl), false);
    strict_1.default.deepEqual((0, gear_2.usableSlots)(w, pl).sort(), ["armR", "back", "core", "head", "rune0"]);
    strict_1.default.equal(pl.gear.rune0, "rune_swift");
    strict_1.default.equal(pl.gear.rune1, undefined);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "rune_glow"), 1, "the rune from the relocked slot is back in the pack");
    // on again: topped up, never a third rune
    strict_1.default.equal((0, debug_1.toggleGearKit)(w, pl), true);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "rune_swift") + (pl.gear.rune0 === "rune_swift" ? 1 : 0), 1);
    strict_1.default.equal((0, inventory_1.countItem)(pl, "rune_glow"), 1);
    strict_1.default.ok((0, inventory_1.countItem)(pl, "wood") <= 40 && (0, inventory_1.countItem)(pl, "planks") <= 40, "a second press tops up, it doesn't pile on");
});
// ------------------------------------------------------------------ the pack screen
function packHost(w) {
    const ctx = globalThis.document.createElement("canvas").getContext("2d");
    const keys = [], said = [];
    const host = {
        ctx, wctx: ctx, world: w, get pl() { return (0, world_1.player)(w); }, get area() { return (0, world_1.currentArea)(w); },
        t: 0.1, cam: { x: 0, y: 0 }, vw: 320, vh: 180, screens: new screens_1.ScreenStack(), typed: [],
        sfx: new Proxy({}, { get: () => () => { } }), hit: (...k) => k.some((x) => keys.includes(x)),
        say: (s) => said.push(s), renderNote: () => { }, read: () => { },
        drainEvents: () => { for (const e of w.events)
            if (e.t === "message")
                said.push(e.text); w.events = []; },
    };
    host.screens.set({ id: "play", opaque: true, t: 0, update() { }, render() { } });
    const ui = new pack_1.PackUi(host);
    const tap = (...k) => { keys.splice(0, keys.length, ...k); host.screens.update(1 / 60); keys.length = 0; };
    return { ui, tap, said, host };
}
(0, node_test_1.test)("pack screen: spatial navigation between the paper doll and the pack, wear / take off from either side, locked slots refuse", () => {
    const { w, pl } = fresh();
    (0, world_1.setFlag)(w, flags_1.FLAGS.golemArm);
    give(w, "rune_swift");
    give(w, "coin");
    const { ui, tap, said } = packHost(w);
    ui.open("view");
    strict_1.default.equal(ui.slot, null);
    tap("a");
    strict_1.default.equal(ui.slot, "core", "left from the pack's first row lands on the doll's right-hand edge, level with it");
    ui.slot = null;
    ui.cursor = 3 * (0, pack_1.packLayout)(ui.cap).cols;
    tap("a");
    strict_1.default.ok(["armL", "rune3"].includes(ui.slot), "lower rows reach the lower slots");
    ui.slot = "core";
    tap("d");
    strict_1.default.equal(ui.slot, null, "right off the doll's right-hand column goes back to the pack");
    strict_1.default.equal(ui.cursor % (0, pack_1.packLayout)(ui.cap).cols, 0);
    // inside the doll: the nearest slot that way
    ui.slot = "armR";
    tap("w");
    strict_1.default.equal(ui.slot, "back");
    tap("w");
    strict_1.default.equal(ui.slot, "head", "nothing straight above the back slot but the helm, up and to the right");
    ui.slot = "armL";
    tap("w");
    strict_1.default.equal(ui.slot, "core");
    ui.slot = "armR";
    tap("d");
    strict_1.default.equal(ui.slot, "armL");
    // E on a pack rune: worn, and the cursor follows it to the slot
    ui.slot = null;
    ui.cursor = slotOf(w, "rune_swift");
    tap("e");
    strict_1.default.equal(pl.gear.rune0, "rune_swift");
    strict_1.default.equal(ui.slot, "rune0");
    // E on the worn slot takes it off; the cursor goes to it in the pack
    tap("e");
    strict_1.default.equal(pl.gear.rune0, undefined);
    strict_1.default.equal(ui.slot, null);
    strict_1.default.equal(pl.inventory[ui.cursor]?.item, "rune_swift");
    // a locked slot: E only thuds; nothing changes; wearing never targets it
    ui.slot = "rune2";
    const snap = JSON.stringify([pl.inventory, pl.gear]);
    tap("e");
    strict_1.default.equal(JSON.stringify([pl.inventory, pl.gear]), snap);
    // Q drops in the pack only
    ui.slot = null;
    ui.cursor = slotOf(w, "coin");
    tap("q");
    strict_1.default.equal((0, inventory_1.countItem)(pl, "coin"), 0);
    tap("escape");
    strict_1.default.ok(!said.length || said.every((s) => typeof s === "string"));
});
(0, node_test_1.test)("pack screen: renders every slot state (empty, filled, locked, selected) and every capacity tier", () => {
    const { w, pl } = fresh();
    const { ui } = packHost(w);
    const draw = () => { (0, fakeCanvas_1.resetTrace)(); ui.screen.render(); return (0, fakeCanvas_1.traceHash)(); };
    ui.open("view");
    draw(); // (the first draw builds the icons' sprites)
    const bare = draw();
    strict_1.default.equal(bare, draw(), "deterministic");
    ui.slot = "armL";
    const lockedSel = draw();
    ui.slot = "armR";
    const emptySel = draw();
    strict_1.default.notEqual(lockedSel, emptySel);
    (0, debug_1.toggleGearKit)(w, pl);
    ui.slot = "armL";
    strict_1.default.notEqual(draw(), lockedSel, "unlocking changes how the slot is drawn");
    (0, gear_2.ensureWorn)(w, pl, "rune_swift");
    ui.slot = "rune0";
    draw();
    w.flags.delete(flags_1.FLAGS.knowBuild);
    for (const n of [8, 16, 48]) {
        const L = (0, pack_1.packLayout)(n);
        strict_1.default.ok(L.gx >= 156 && L.gx + L.gw <= 308 && L.gy + L.gh <= 134, `tier ${n} fits beside the doll`);
    }
    // the doll never overlaps itself or the pack column
    const rs = gear_1.GEAR_SLOTS.map((s) => (0, pack_1.dollRect)(s));
    for (let i = 0; i < rs.length; i++) {
        strict_1.default.ok(rs[i].x + rs[i].w < 156);
        for (let j = i + 1; j < rs.length; j++)
            strict_1.default.ok(rs[i].x + rs[i].w <= rs[j].x || rs[j].x + rs[j].w <= rs[i].x || rs[i].y + rs[i].h <= rs[j].y || rs[j].y + rs[j].h <= rs[i].y, `${i}/${j}`);
    }
    strict_1.default.equal((0, pack_1.neighbor)({ x: 0, y: 0, w: 10, h: 10 }, "right", [{ r: { x: 50, y: 0, w: 10, h: 10 } }, { r: { x: 20, y: 40, w: 10, h: 10 } }]).r.x, 50, "lined up beats nearer but off-line");
    strict_1.default.equal((0, pack_1.neighbor)({ x: 0, y: 0, w: 10, h: 10 }, "left", [{ r: { x: 50, y: 0, w: 10, h: 10 } }]), undefined);
    void gear_1.slotsOfKind;
    void step_1.stepWorld;
    void tasks_1.applyEffect;
});
