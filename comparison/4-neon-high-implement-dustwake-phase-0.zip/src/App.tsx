import { useEffect, useRef } from "react";
import { Game, W, H, UI2_W, UI2_H } from "./game/game";
import { serialize } from "./game/world/save";
import { saveToStorage, loadFromStorage } from "./game/view/persistence";
import { foundationDemo, registerFoundations } from "./game/sim/debugFoundations";
import { setWorkerOrder } from "./game/sim/jobs";
import type { JobOrder } from "./game/world/jobs";
import { createDynamicArea, enterArea, player } from "./game/world/world";
import type { AreaKind } from "./game/world/areaSpec";
import type { GameSpeed } from "./game/sim/clock";

export default function App() {
  const ref = useRef<HTMLCanvasElement>(null);
  const uiRef = useRef<HTMLCanvasElement>(null);
  const hiUiRef = useRef<HTMLCanvasElement>(null);
  const wrap = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Three stacked pixel-crisp layers sharing the exact display rect:
    // 1. World canvas (vw x vh, pixel-perfect low base resolution)
    // 2. Legacy 1x UI canvas (320 x 180)
    // 3. 2x Hi-Res UI canvas (640 x 360) for Phase 0 mixed-case proportional UI,
    //    mouse HUD, tooltips, drag-select, context menu, and management modals.
    const canvas = ref.current!;
    const ui = uiRef.current!;
    const hiUi = hiUiRef.current!;
    const game = new Game(canvas, ui, hiUi);

    if (new URLSearchParams(window.location.search).has("debug")) {
      registerFoundations();
      (window as unknown as Record<string, unknown>).dustwake = {
        game,
        serialize: () => serialize(game.world),
        save: () => saveToStorage(game.world),
        load: () => { const w = loadFromStorage(); if (w) game.resume(w); return !!w; },
        foundations: () => { game.resume(foundationDemo()); game.say("FOUNDATION FIXTURE: A WORKER GATHERS THROUGH THE RUNES."); },
        order: (id: string, order: JobOrder | null) => setWorkerOrder(game.world, player(game.world), id, order),
        setSpeed: (s: GameSpeed) => game.setSpeed(s),
        createFloor: (kind: AreaKind = "dungeon_floor", depth = 1) => {
          const a = createDynamicArea(game.world, { kind, depth, parent: game.area.id, w: 36, h: 28 });
          enterArea(game.world, player(game.world), a.id, a.start.x, a.start.y);
          return a.id;
        },
      };
    }

    let raf = 0;
    let last = performance.now();
    let running = true;

    const fit = () => {
      const vw = window.innerWidth, vh = window.innerHeight;
      let s = Math.min(vw / W, vh / H);
      if (s >= 2) s = Math.floor(s);
      const dw = Math.round(W * s), dh = Math.round(H * s);
      const ws = dw / game.vw;
      for (const c of [canvas, ui, hiUi]) {
        c.style.width = `${dw}px`;
        c.style.height = `${dh}px`;
      }
      canvas.style.width = `${Math.round(game.vw * ws)}px`;
      canvas.style.height = `${Math.round(game.vh * ws)}px`;
    };
    game.onView = fit;
    fit();
    window.addEventListener("resize", fit);

    const toHiUiCoords = (e: PointerEvent | MouseEvent) => {
      const rect = hiUi.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / Math.max(1, rect.width)) * UI2_W;
      const y = ((e.clientY - rect.top) / Math.max(1, rect.height)) * UI2_H;
      return { x, y };
    };

    const block = new Set(["arrowup", "arrowdown", "arrowleft", "arrowright", " ", "tab", "/", "'", "backspace", "f5", "f9", "f10"]);
    const kd = (e: KeyboardEvent) => {
      if (e.ctrlKey && !e.altKey && !e.shiftKey) {
        const n = ({ Digit0: 0, Numpad0: 0, Digit1: 1, Digit2: 2, Digit3: 3, Digit4: 4, Digit5: 5, Digit6: 6, Numpad1: 1, Numpad2: 2, Numpad3: 3, Numpad4: 4, Numpad5: 5, Numpad6: 6 } as Record<string, number>)[e.code];
        if (n !== undefined) {
          e.preventDefault();
          if (!e.repeat) game.debugKey(n);
          return;
        }
      }
      if (block.has(e.key.toLowerCase())) e.preventDefault();
      game.keyDown(e.key);
    };
    const ku = (e: KeyboardEvent) => game.keyUp(e.key);

    const pm = (e: PointerEvent) => {
      const { x, y } = toHiUiCoords(e);
      game.pointerMove(x, y);
    };
    const pd = (e: PointerEvent) => {
      hiUi.focus();
      const { x, y } = toHiUiCoords(e);
      game.pointerDown(e.button, x, y);
    };
    const pu = (e: PointerEvent) => {
      const { x, y } = toHiUiCoords(e);
      game.pointerUp(e.button, x, y);
    };
    const pl = () => game.pointerLeave();
    const cm = (e: MouseEvent) => { e.preventDefault(); };
    const wh = (e: WheelEvent) => { e.preventDefault(); game.wheel(e.deltaY); };
    const blur = () => game.keys.clear();

    window.addEventListener("keydown", kd);
    window.addEventListener("keyup", ku);
    window.addEventListener("blur", blur);
    window.addEventListener("wheel", wh, { passive: false });
    hiUi.addEventListener("pointermove", pm);
    hiUi.addEventListener("pointerdown", pd);
    window.addEventListener("pointerup", pu);
    hiUi.addEventListener("pointerleave", pl);
    hiUi.addEventListener("contextmenu", cm);

    const loop = (now: number) => {
      if (!running) return;
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      game.update(dt);
      game.render();
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      game.onView = null;
      window.removeEventListener("resize", fit);
      window.removeEventListener("keydown", kd);
      window.removeEventListener("keyup", ku);
      window.removeEventListener("blur", blur);
      window.removeEventListener("wheel", wh);
      hiUi.removeEventListener("pointermove", pm);
      hiUi.removeEventListener("pointerdown", pd);
      window.removeEventListener("pointerup", pu);
      hiUi.removeEventListener("pointerleave", pl);
      hiUi.removeEventListener("contextmenu", cm);
      game.sfx.ctx?.close();
      game.dispose();
      delete (window as unknown as Record<string, unknown>).dustwake;
    };
  }, []);

  return (
    <div ref={wrap} className="fixed inset-0 bg-black flex items-center justify-center overflow-hidden select-none">
      <div className="relative">
        <canvas
          ref={ref}
          width={W}
          height={H}
          className="block outline-none"
          style={{ imageRendering: "pixelated" }}
        />
        <canvas
          ref={uiRef}
          width={W}
          height={H}
          className="absolute inset-0 block outline-none pointer-events-none"
          style={{ imageRendering: "pixelated" }}
        />
        <canvas
          ref={hiUiRef}
          width={UI2_W}
          height={UI2_H}
          tabIndex={0}
          className="absolute inset-0 block outline-none cursor-default"
          style={{ imageRendering: "pixelated" }}
        />
      </div>
    </div>
  );
}
