import type { ItemTag } from "./items";

export type Highlight = "important" | "interactable" | "npc" | "buildable";
/**
 * How a category's hologram is drawn over the sprite (view/vision.ts), so the
 * categories differ in treatment as well as hue:
 * - `radiant`   solid glowing fill, scanlines climbing through it, a bright rim (things that matter most)
 * - `wireframe` outline plus the sprite's own internal edges as faint lines (quietest: there are many)
 * - `signal`    interlaced rows and an occasional sideways glitch (something alive looking back)
 * - `blueprint` marching dashed outline over a dot grid (a pattern the golem can read and rebuild)
 */
export type HoloEffect = "radiant" | "wireframe" | "signal" | "blueprint";
import type { ColorBlindPalette } from "../settings";

export const VISION_CATEGORIES: Record<Highlight, { color: string; effect: HoloEffect }> = {
  important: { color: "#ffd27a", effect: "radiant" }, interactable: { color: "#74dce2", effect: "wireframe" },
  npc: { color: "#c5a0ff", effect: "signal" }, buildable: { color: "#97d38a", effect: "blueprint" },
};

/**
 * Color-blind-safe palettes for vision & management overlays (Phase 0.7).
 * Based on Okabe-Ito and Paul Tol high-separation categorical palettes.
 */
export const OVERLAY_PALETTES: Record<ColorBlindPalette, Record<Highlight, string> & { ok: string; warn: string; alert: string; info: string }> = {
  default: {
    important: "#ffd27a", interactable: "#74dce2", npc: "#c5a0ff", buildable: "#97d38a",
    ok: "#7ae08a", warn: "#f0b050", alert: "#e86a6a", info: "#74dce2",
  },
  deuteranopia: {
    important: "#e69f00", interactable: "#56b4e9", npc: "#cc79a7", buildable: "#f0e442",
    ok: "#56b4e9", warn: "#f0e442", alert: "#d55e00", info: "#0072b2",
  },
  protanopia: {
    important: "#f0e442", interactable: "#56b4e9", npc: "#cc79a7", buildable: "#009e73",
    ok: "#009e73", warn: "#f0e442", alert: "#e69f00", info: "#56b4e9",
  },
  tritanopia: {
    important: "#ff8844", interactable: "#44ccbb", npc: "#ee6688", buildable: "#f0f0f0",
    ok: "#44ccbb", warn: "#ffaa44", alert: "#ee3355", info: "#77bbff",
  },
  highContrast: {
    important: "#ffee00", interactable: "#00ffff", npc: "#ff66ff", buildable: "#66ff66",
    ok: "#55ff55", warn: "#ffee00", alert: "#ff4444", info: "#00ffff",
  },
};

export function visionColor(category: Highlight, palette: ColorBlindPalette = "default"): string {
  return (OVERLAY_PALETTES[palette] ?? OVERLAY_PALETTES.default)[category];
}
/** First matching row wins. A new category rule is data, not a host branch. */
export const HIGHLIGHT_RULES: { category: Highlight; tags?: ItemTag[]; trait?: "rune" | "actor" | "buildable" | "interactable" }[] = [
  { category: "important", tags: ["rune", "glyph", "part", "document", "relic", "power"] },
  { category: "important", trait: "rune" },
  { category: "npc", trait: "actor" },
  { category: "buildable", trait: "buildable" },
  { category: "interactable", trait: "interactable" },
];
export const SCAN_DURATION = 0.9;
/**
 * Effects that take the golem's attention elsewhere (a conversation, a rune jump,
 * a work/storage/management screen). Starting a task with one of these ends vision
 * mode on its own, so the overlay plays its normal switch-off.
 */
export const VISION_OFF_OPS: readonly string[] = ["talk", "travel", "useStation", "useStorage", "manageActor"];
export const analysisFlag = (key: string) => `analysis.${key}`;
