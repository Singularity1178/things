// Reusable v2 Hi-Res UI Components (Phase 0.5) for the 640x360 2x UI layer.
// Drawn with pure fillRect + mixed-case proportional font (propFont.ts), so
// every widget is crisp, theme-consistent with Dustwake's dark stone/rivet look,
// color-blind-palette aware, and testable in headless FakeCanvas/RCanvas runs.
import { OVERLAY_PALETTES } from "../content/vision";
import type { ColorBlindPalette } from "../settings";
import { clamp } from "../util";
import { clipPropText, drawPropText, drawPropTextS, PROP_LINE_H, propTextWidth, wrapPropText } from "./propFont";
import { UI2_H, UI2_W, type InputManager, type PointerState } from "./input";

export interface Rect { x: number; y: number; w: number; h: number }

export const hitRect = (r: Rect, x: number, y: number) => x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h;

export const UI2 = {
  bg: "#121016",
  bgDeep: "#0b090e",
  bgPanel: "#17141d",
  bgHover: "#241f2d",
  bgActive: "#2e2739",
  bgRowAlt: "#1c1823",
  border: "#3b3545",
  borderHi: "#564e64",
  borderSel: "#d8c48a",
  text: "#e2dac4",
  title: "#f2e4bd",
  dim: "#7c7488",
  mid: "#a59db0",
  gold: "#d9b04c",
} as const;

export function semanticColor(kind: "ok" | "warn" | "alert" | "info", palette: ColorBlindPalette = "default"): string {
  return (OVERLAY_PALETTES[palette] ?? OVERLAY_PALETTES.default)[kind];
}

// ---------------------------------------------------------------- primitives
export function hiFrame(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, fill: string = UI2.bgPanel, edge: string = UI2.border, hi: string = UI2.borderHi) {
  x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
  ctx.fillStyle = "#060509"; ctx.fillRect(x - 1, y - 1, w + 2, h + 2);
  ctx.fillStyle = edge; ctx.fillRect(x, y, w, h);
  ctx.fillStyle = hi; ctx.fillRect(x, y, w, 1); ctx.fillRect(x, y, 1, h);
  ctx.fillStyle = fill; ctx.fillRect(x + 1, y + 1, Math.max(0, w - 2), Math.max(0, h - 2));
}

export function hiPanel(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, fill: string = UI2.bgPanel) {
  hiFrame(ctx, x, y, w, h, fill);
  ctx.fillStyle = "#6a6276";
  for (const [rx, ry] of [[x + 3, y + 3], [x + w - 5, y + 3], [x + 3, y + h - 5], [x + w - 5, y + h - 5]]) {
    ctx.fillRect(Math.round(rx), Math.round(ry), 2, 2);
  }
}

// ---------------------------------------------------------------- tooltips
export interface TooltipRequest {
  title: string;
  body?: string;
  shortcut?: string;
  x: number;
  y: number;
  accent?: string;
}

export class TooltipHost {
  current: TooltipRequest | null = null;
  clear() { this.current = null; }
  show(req: TooltipRequest) { this.current = req; }
  render(ctx: CanvasRenderingContext2D) {
    if (!this.current) return;
    drawTooltip(ctx, this.current);
  }
}

export function drawTooltip(ctx: CanvasRenderingContext2D, tip: TooltipRequest) {
  const maxW = 190;
  const pad = 6;
  const titleW = propTextWidth(tip.title) + (tip.shortcut ? propTextWidth(` [${tip.shortcut}]`) + 4 : 0);
  const bodyLines = tip.body ? wrapPropText(tip.body, maxW - pad * 2) : [];
  let contentW = Math.min(maxW - pad * 2, titleW);
  for (const l of bodyLines) contentW = Math.max(contentW, propTextWidth(l));
  const w = Math.min(maxW, Math.max(54, contentW + pad * 2));
  const h = pad * 2 + PROP_LINE_H + (bodyLines.length ? 3 + bodyLines.length * PROP_LINE_H : 0);
  const x = clamp(Math.round(tip.x + 10), 4, UI2_W - w - 4);
  const y = clamp(Math.round(tip.y + 12), 4, UI2_H - h - 4);

  hiFrame(ctx, x, y, w, h, "#100e15", tip.accent ?? UI2.borderHi, tip.accent ?? "#7c728c");
  drawPropTextS(ctx, tip.title, x + pad, y + pad, tip.accent ?? UI2.title);
  if (tip.shortcut) {
    drawPropText(ctx, `[${tip.shortcut}]`, x + w - pad, y + pad, UI2.dim, 1, "right");
  }
  if (bodyLines.length) {
    ctx.fillStyle = "#2b2634";
    ctx.fillRect(x + pad, y + pad + PROP_LINE_H, w - pad * 2, 1);
    bodyLines.forEach((line, i) => {
      drawPropText(ctx, line, x + pad, y + pad + PROP_LINE_H + 3 + i * PROP_LINE_H, UI2.text);
    });
  }
}

// ---------------------------------------------------------------- button
export interface ButtonOpts {
  active?: boolean;
  disabled?: boolean;
  accent?: string;
  tooltip?: { title: string; body?: string; shortcut?: string };
  badge?: string;
}

export function hiButton(
  ctx: CanvasRenderingContext2D,
  r: Rect,
  label: string,
  ptr: PointerState,
  opts: ButtonOpts = {},
  tips?: TooltipHost
): boolean {
  const hover = !opts.disabled && ptr.inside && !ptr.consumed && hitRect(r, ptr.x, ptr.y);
  const fill = opts.disabled ? "#100e14" : opts.active ? UI2.bgActive : hover ? UI2.bgHover : UI2.bg;
  const edge = opts.active ? (opts.accent ?? UI2.borderSel) : hover ? UI2.borderHi : UI2.border;
  const hi = opts.active ? (opts.accent ?? "#f0dea8") : hover ? "#7a708c" : UI2.borderHi;
  hiFrame(ctx, r.x, r.y, r.w, r.h, fill, edge, hi);
  const col = opts.disabled ? UI2.dim : opts.active ? (opts.accent ?? UI2.title) : hover ? UI2.title : UI2.text;
  const text = clipPropText(label, r.w - 8);
  drawPropTextS(ctx, text, r.x + r.w / 2, r.y + Math.floor((r.h - 7) / 2), col, 1, "center");
  if (opts.badge) {
    const bw = propTextWidth(opts.badge) + 6;
    ctx.fillStyle = opts.accent ?? "#c94a4a";
    ctx.fillRect(r.x + r.w - bw - 1, r.y - 3, bw, 9);
    drawPropText(ctx, opts.badge, r.x + r.w - bw / 2 - 1, r.y - 2, "#fff", 1, "center");
  }
  if (hover && opts.tooltip && tips) {
    tips.show({ ...opts.tooltip, x: ptr.x, y: ptr.y, accent: opts.accent });
  }
  if (hover && ptr.clicked) {
    ptr.consumed = true;
    return true;
  }
  return false;
}

// ---------------------------------------------------------------- toggle
export function hiToggle(
  ctx: CanvasRenderingContext2D,
  r: Rect,
  value: boolean,
  ptr: PointerState,
  accent: string = "#7ae08a",
  focused = false
): boolean {
  const hover = ptr.inside && !ptr.consumed && hitRect(r, ptr.x, ptr.y);
  const tw = 28, th = 13;
  const tx = r.x + r.w - tw, ty = r.y + Math.floor((r.h - th) / 2);
  hiFrame(ctx, tx, ty, tw, th, value ? "#1e2e24" : "#18151f", focused || hover ? UI2.borderSel : value ? accent : UI2.border);
  const knobX = value ? tx + tw - 11 : tx + 2;
  ctx.fillStyle = value ? accent : UI2.dim;
  ctx.fillRect(knobX, ty + 2, 9, th - 4);
  if (hover && ptr.clicked) {
    ptr.consumed = true;
    return true;
  }
  return false;
}

// ---------------------------------------------------------------- slider
export function hiSlider(
  ctx: CanvasRenderingContext2D,
  r: Rect,
  value: number,
  min: number,
  max: number,
  step: number,
  ptr: PointerState,
  accent: string = UI2.gold,
  focused = false
): number | null {
  const hover = ptr.inside && !ptr.consumed && hitRect(r, ptr.x, ptr.y);
  const ratio = max > min ? clamp((value - min) / (max - min), 0, 1) : 0;
  const trackY = r.y + Math.floor(r.h / 2) - 2;
  hiFrame(ctx, r.x, trackY, r.w, 5, UI2.bgDeep, focused || hover ? UI2.borderSel : UI2.border);
  const fillW = Math.round((r.w - 2) * ratio);
  ctx.fillStyle = accent;
  ctx.fillRect(r.x + 1, trackY + 1, fillW, 3);
  const kx = r.x + Math.round((r.w - 6) * ratio);
  hiFrame(ctx, kx, r.y + Math.floor(r.h / 2) - 5, 6, 11, hover || focused ? UI2.title : UI2.text, "#09080d", "#fff");

  if (hover && (ptr.down || ptr.clicked)) {
    ptr.consumed = true;
    const raw = min + clamp((ptr.x - r.x) / Math.max(1, r.w), 0, 1) * (max - min);
    const snapped = step > 0 ? Math.round(raw / step) * step : raw;
    const next = clamp(Number(snapped.toFixed(4)), min, max);
    if (Math.abs(next - value) > 1e-6) return next;
  }
  return null;
}

// ---------------------------------------------------------------- tabs
export function hiTabs(
  ctx: CanvasRenderingContext2D,
  r: Rect,
  tabs: readonly { id: string; label: string }[],
  activeId: string,
  ptr: PointerState,
  tips?: TooltipHost
): string | null {
  if (!tabs.length) return null;
  let chosen: string | null = null;
  const gap = 4;
  const tw = Math.floor((r.w - gap * (tabs.length - 1)) / tabs.length);
  for (let i = 0; i < tabs.length; i++) {
    const tr: Rect = { x: r.x + i * (tw + gap), y: r.y, w: i === tabs.length - 1 ? r.w - i * (tw + gap) : tw, h: r.h };
    if (hiButton(ctx, tr, tabs[i].label, ptr, { active: tabs[i].id === activeId }, tips)) {
      chosen = tabs[i].id;
    }
  }
  return chosen;
}

// ---------------------------------------------------------------- scrolling list
export interface ScrollListState {
  scroll: number;
  selected: number;
}

export function hiScrollList<T>(
  ctx: CanvasRenderingContext2D,
  r: Rect,
  items: readonly T[],
  rowH: number,
  state: ScrollListState,
  input: InputManager,
  drawRow: (ctx: CanvasRenderingContext2D, item: T, index: number, rowRect: Rect, selected: boolean, hovered: boolean) => void
): { clickedIndex: number; doubleClickedIndex: number } {
  const ptr = input.pointer;
  hiFrame(ctx, r.x, r.y, r.w, r.h, UI2.bgDeep);
  const innerH = r.h - 4;
  const visibleRows = Math.max(1, Math.floor(innerH / rowH));
  const maxScroll = Math.max(0, items.length - visibleRows);
  const hoverBox = ptr.inside && !ptr.consumed && hitRect(r, ptr.x, ptr.y);
  if (hoverBox && ptr.wheel !== 0) {
    const w = input.consumeWheel();
    state.scroll = clamp(state.scroll + (w > 0 ? 1 : -1), 0, maxScroll);
  }
  state.scroll = clamp(state.scroll, 0, maxScroll);
  const hasBar = maxScroll > 0;
  const barW = hasBar ? 6 : 0;
  const rowW = r.w - 4 - barW;

  let clickedIndex = -1;
  let doubleClickedIndex = -1;
  const start = state.scroll;
  const end = Math.min(items.length, start + visibleRows);
  for (let i = start; i < end; i++) {
    const rr: Rect = { x: r.x + 2, y: r.y + 2 + (i - start) * rowH, w: rowW, h: rowH };
    const hovered = hoverBox && hitRect(rr, ptr.x, ptr.y);
    const selected = i === state.selected;
    ctx.fillStyle = selected ? UI2.bgActive : hovered ? UI2.bgHover : i % 2 === 1 ? UI2.bgRowAlt : UI2.bgDeep;
    ctx.fillRect(rr.x, rr.y, rr.w, rr.h);
    if (selected) {
      ctx.fillStyle = UI2.borderSel;
      ctx.fillRect(rr.x, rr.y, 2, rr.h);
    }
    drawRow(ctx, items[i], i, rr, selected, hovered);
    if (hovered && ptr.clicked) {
      state.selected = i;
      clickedIndex = i;
      ptr.consumed = true;
    }
    if (hovered && ptr.doubleClicked) {
      doubleClickedIndex = i;
    }
  }
  // Scrollbar
  if (hasBar) {
    const bx = r.x + r.w - barW - 1, by = r.y + 2, bh = innerH;
    ctx.fillStyle = "#16131c";
    ctx.fillRect(bx, by, barW - 1, bh);
    const thumbH = Math.max(12, Math.round((visibleRows / items.length) * bh));
    const thumbY = by + Math.round((state.scroll / maxScroll) * (bh - thumbH));
    ctx.fillStyle = UI2.borderHi;
    ctx.fillRect(bx + 1, thumbY, barW - 3, thumbH);
  }
  return { clickedIndex, doubleClickedIndex };
}

// ---------------------------------------------------------------- sortable table
export interface TableColumn<T> {
  id: string;
  label: string;
  w: number;
  align?: "left" | "center" | "right";
  value: (row: T) => string;
  sortKey?: (row: T) => string | number;
  color?: (row: T) => string;
}

export interface TableState {
  scroll: number;
  selected: number;
  sortCol: string | null;
  sortAsc: boolean;
}

export function hiTable<T>(
  ctx: CanvasRenderingContext2D,
  r: Rect,
  columns: readonly TableColumn<T>[],
  rows: readonly T[],
  state: TableState,
  input: InputManager,
  rowH = 15
): { clickedRow: T | null; doubleClickedRow: T | null; sorted: T[] } {
  const ptr = input.pointer;
  const headerH = 15;
  // Sort rows deterministically
  const sorted = [...rows];
  if (state.sortCol) {
    const col = columns.find((c) => c.id === state.sortCol);
    if (col) {
      sorted.sort((a, b) => {
        const ka = col.sortKey ? col.sortKey(a) : col.value(a);
        const kb = col.sortKey ? col.sortKey(b) : col.value(b);
        const cmp = typeof ka === "number" && typeof kb === "number" ? ka - kb : String(ka).localeCompare(String(kb));
        return state.sortAsc ? cmp : -cmp;
      });
    }
  }

  // Header bar
  hiFrame(ctx, r.x, r.y, r.w, headerH, "#1e1a26", UI2.border, UI2.borderHi);
  let cx = r.x + 4;
  for (const col of columns) {
    const cr: Rect = { x: cx, y: r.y, w: col.w, h: headerH };
    const hov = ptr.inside && !ptr.consumed && hitRect(cr, ptr.x, ptr.y);
    const arrow = state.sortCol === col.id ? (state.sortAsc ? " ^" : " v") : "";
    const text = clipPropText(col.label + arrow, col.w - 4);
    const tx = col.align === "right" ? cx + col.w - 4 : col.align === "center" ? cx + col.w / 2 : cx + 2;
    drawPropText(ctx, text, tx, r.y + 4, hov || state.sortCol === col.id ? UI2.title : UI2.mid, 1, col.align ?? "left");
    if (hov && ptr.clicked) {
      if (state.sortCol === col.id) state.sortAsc = !state.sortAsc;
      else { state.sortCol = col.id; state.sortAsc = true; }
      ptr.consumed = true;
    }
    cx += col.w;
  }

  const bodyR: Rect = { x: r.x, y: r.y + headerH, w: r.w, h: Math.max(rowH + 4, r.h - headerH) };
  const res = hiScrollList(ctx, bodyR, sorted, rowH, state, input, (c, row, _idx, rr) => {
    let x = rr.x + 2;
    for (const col of columns) {
      const txt = clipPropText(col.value(row), col.w - 4);
      const tx = col.align === "right" ? x + col.w - 4 : col.align === "center" ? x + col.w / 2 : x + 2;
      drawPropText(c, txt, tx, rr.y + Math.floor((rr.h - 7) / 2), col.color ? col.color(row) : UI2.text, 1, col.align ?? "left");
      x += col.w;
    }
  });
  return {
    clickedRow: res.clickedIndex >= 0 ? sorted[res.clickedIndex] : null,
    doubleClickedRow: res.doubleClickedIndex >= 0 ? sorted[res.doubleClickedIndex] : null,
    sorted,
  };
}

// ---------------------------------------------------------------- sparkline / time-series graph
export interface GraphOpts {
  label?: string;
  unit?: string;
  min?: number;
  max?: number;
  accent?: string;
  warnLine?: number;
}

export function hiGraph(ctx: CanvasRenderingContext2D, r: Rect, samples: readonly number[], opts: GraphOpts = {}) {
  hiFrame(ctx, r.x, r.y, r.w, r.h, UI2.bgDeep);
  const pad = 4;
  const top = opts.label ? 12 : 4;
  const gx = r.x + pad, gy = r.y + top, gw = Math.max(4, r.w - pad * 2), gh = Math.max(6, r.h - top - pad);

  const lo = opts.min ?? (samples.length ? Math.min(...samples) : 0);
  const hi = Math.max(lo + 0.001, opts.max ?? (samples.length ? Math.max(...samples) : 1));
  const latest = samples.length ? samples[samples.length - 1] : 0;

  if (opts.label) {
    drawPropText(ctx, opts.label, r.x + pad, r.y + 3, UI2.mid);
    drawPropText(ctx, `${latest.toFixed(1)}${opts.unit ?? ""}`, r.x + r.w - pad, r.y + 3, opts.accent ?? UI2.title, 1, "right");
  }

  // Horizontal mid grid line
  ctx.fillStyle = "#221e2b";
  ctx.fillRect(gx, gy + Math.floor(gh / 2), gw, 1);

  if (opts.warnLine !== undefined && opts.warnLine >= lo && opts.warnLine <= hi) {
    const wy = gy + gh - Math.round(((opts.warnLine - lo) / (hi - lo)) * gh);
    ctx.fillStyle = "#7a3838";
    ctx.fillRect(gx, wy, gw, 1);
  }

  if (!samples.length) return;
  const accent = opts.accent ?? "#74dce2";
  const count = Math.min(samples.length, gw);
  const start = samples.length - count;
  const barW = Math.max(1, Math.floor(gw / Math.max(1, count)));
  for (let i = 0; i < count; i++) {
    const v = samples[start + i];
    const norm = clamp((v - lo) / (hi - lo), 0, 1);
    const bh = Math.max(1, Math.round(norm * gh));
    const bx = gx + Math.floor((i / Math.max(1, count)) * gw);
    const by = gy + gh - bh;
    ctx.fillStyle = accent;
    ctx.globalAlpha = 0.25;
    ctx.fillRect(bx, by, barW, bh);
    ctx.globalAlpha = 1;
    ctx.fillRect(bx, by, barW, 1);
  }
}

// ---------------------------------------------------------------- modal frame
export function hiModal(
  ctx: CanvasRenderingContext2D,
  r: Rect,
  title: string,
  subtitle: string | undefined,
  ptr: PointerState
): { closeClicked: boolean } {
  // Dimmed backdrop
  ctx.fillStyle = "rgba(5, 4, 9, 0.72)";
  ctx.fillRect(0, 0, UI2_W, UI2_H);

  hiPanel(ctx, r.x, r.y, r.w, r.h, UI2.bgPanel);
  // Title bar
  ctx.fillStyle = "#1e1a27";
  ctx.fillRect(r.x + 2, r.y + 2, r.w - 4, 20);
  ctx.fillStyle = UI2.border;
  ctx.fillRect(r.x + 2, r.y + 22, r.w - 4, 1);
  drawPropTextS(ctx, title, r.x + 10, r.y + 8, UI2.title);
  if (subtitle) {
    drawPropText(ctx, subtitle, r.x + 16 + propTextWidth(title), r.y + 8, UI2.dim);
  }
  const closeR: Rect = { x: r.x + r.w - 22, y: r.y + 5, w: 16, h: 14 };
  const closeClicked = hiButton(ctx, closeR, "x", ptr, { accent: "#e86a6a" });
  // Clicking outside modal closes it too
  const outsideClick = !ptr.consumed && ptr.clicked && !hitRect(r, ptr.x, ptr.y);
  if (outsideClick) ptr.consumed = true;
  return { closeClicked: closeClicked || outsideClick };
}

// ---------------------------------------------------------------- right-click context menu
export interface ContextMenuItem {
  id: string;
  label: string;
  shortcut?: string;
  disabled?: boolean;
  accent?: string;
  action: () => void;
}

export class ContextMenu {
  open = false;
  x = 0;
  y = 0;
  title?: string;
  items: ContextMenuItem[] = [];
  focus = 0;

  show(x: number, y: number, items: ContextMenuItem[], title?: string) {
    if (!items.length) { this.close(); return; }
    this.items = items;
    this.title = title;
    this.focus = 0;
    this.x = x;
    this.y = y;
    this.open = true;
  }

  close() {
    this.open = false;
    this.items = [];
  }

  /** Update keyboard navigation + render & process mouse clicks. Returns true while open. */
  updateAndRender(ctx: CanvasRenderingContext2D, ptr: PointerState, hitKey: (...k: string[]) => boolean): boolean {
    if (!this.open) return false;
    const rowH = 15;
    const pad = 4;
    let maxW = this.title ? propTextWidth(this.title) + 16 : 80;
    for (const it of this.items) {
      const w = propTextWidth(it.label) + (it.shortcut ? propTextWidth(it.shortcut) + 18 : 14);
      if (w > maxW) maxW = w;
    }
    const w = clamp(maxW + pad * 2, 100, 200);
    const titleH = this.title ? 14 : 0;
    const h = titleH + this.items.length * rowH + pad * 2;
    const mx = clamp(Math.round(this.x), 4, UI2_W - w - 4);
    const my = clamp(Math.round(this.y), 4, UI2_H - h - 4);
    const box: Rect = { x: mx, y: my, w, h };

    // Keyboard parity
    if (hitKey("escape")) { this.close(); return true; }
    if (hitKey("arrowdown", "s")) this.focus = (this.focus + 1) % this.items.length;
    if (hitKey("arrowup", "w")) this.focus = (this.focus - 1 + this.items.length) % this.items.length;
    if (hitKey("enter", "e")) {
      const it = this.items[this.focus];
      if (it && !it.disabled) { this.close(); it.action(); return true; }
    }

    hiFrame(ctx, mx, my, w, h, "#14111a", UI2.borderHi, "#7a708c");
    if (this.title) {
      drawPropText(ctx, clipPropText(this.title, w - 10), mx + 6, my + 4, UI2.gold);
      ctx.fillStyle = UI2.border;
      ctx.fillRect(mx + 3, my + titleH, w - 6, 1);
    }

    for (let i = 0; i < this.items.length; i++) {
      const it = this.items[i];
      const rr: Rect = { x: mx + 2, y: my + pad + titleH + i * rowH, w: w - 4, h: rowH };
      const hov = !it.disabled && ptr.inside && hitRect(rr, ptr.x, ptr.y);
      if (hov) this.focus = i;
      const sel = this.focus === i && !it.disabled;
      if (sel) {
        ctx.fillStyle = UI2.bgHover;
        ctx.fillRect(rr.x, rr.y, rr.w, rr.h);
      }
      drawPropText(ctx, clipPropText(it.label, rr.w - 28), rr.x + 5, rr.y + 4, it.disabled ? UI2.dim : it.accent ?? (sel ? UI2.title : UI2.text));
      if (it.shortcut) {
        drawPropText(ctx, it.shortcut, rr.x + rr.w - 5, rr.y + 4, UI2.dim, 1, "right");
      }
      if (hov && ptr.clicked) {
        ptr.consumed = true;
        this.close();
        it.action();
        return true;
      }
    }

    if ((ptr.clicked || ptr.rightClicked) && !hitRect(box, ptr.x, ptr.y)) {
      this.close();
    }
    if (hitRect(box, ptr.x, ptr.y)) ptr.consumed = true;
    return true;
  }
}
