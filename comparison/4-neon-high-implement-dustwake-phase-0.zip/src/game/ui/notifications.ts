// Notification feed with pause-on-alert support (Phase 0.5).
// Captures system, worker, day-phase, save, and world alerts with optional
// world coordinates so clicking a notification can jump or inspect.
import type { Settings } from "../settings";

export type AlertSeverity = "info" | "success" | "warn" | "alert";
export type AlertCategory = "system" | "worker" | "day" | "save" | "world";

export interface NotificationItem {
  id: number;
  title: string;
  detail?: string;
  severity: AlertSeverity;
  category: AlertCategory;
  /** World sim time when emitted. */
  worldTime: number;
  /** Real presentation clock timestamp for toast fade. */
  createdAt: number;
  /** Optional location for camera jump / inspection. */
  area?: string;
  x?: number;
  y?: number;
  read: boolean;
  dismissed: boolean;
  causedPause?: boolean;
}

export interface PushNotificationOpts {
  title: string;
  detail?: string;
  severity?: AlertSeverity;
  category?: AlertCategory;
  worldTime?: number;
  area?: string;
  x?: number;
  y?: number;
}

const MAX_HISTORY = 64;
export const TOAST_DURATION = 5.5;

export class NotificationFeed {
  items: NotificationItem[] = [];
  drawerOpen = false;
  private seq = 1;
  private now = 0;

  /** Returns whether `settings` dictates pausing the simulation for this alert. */
  shouldPause(item: NotificationItem, settings: Settings): boolean {
    if (item.severity === "alert" && settings.pauseOnAlert) return true;
    if (item.category === "worker" && item.severity === "warn" && settings.pauseOnJobBlocked) return true;
    if (item.category === "day" && settings.pauseOnDayPhase) return true;
    return false;
  }

  /**
   * Push a new notification into the feed.
   * Returns `{ item, pause }` where `pause` is true if pause-on-alert triggered.
   */
  push(opts: PushNotificationOpts, settings?: Settings): { item: NotificationItem; pause: boolean } {
    const item: NotificationItem = {
      id: this.seq++,
      title: opts.title,
      detail: opts.detail,
      severity: opts.severity ?? "info",
      category: opts.category ?? "world",
      worldTime: opts.worldTime ?? 0,
      createdAt: this.now,
      area: opts.area,
      x: opts.x,
      y: opts.y,
      read: false,
      dismissed: false,
    };
    const pause = settings ? this.shouldPause(item, settings) : false;
    item.causedPause = pause;
    this.items.unshift(item);
    if (this.items.length > MAX_HISTORY) this.items.length = MAX_HISTORY;
    return { item, pause };
  }

  tick(dt: number) {
    this.now += dt;
  }

  /** Active live toast notifications (recent & not dismissed). */
  liveToasts(limit = 4): NotificationItem[] {
    return this.items
      .filter((it) => !it.dismissed && this.now - it.createdAt < TOAST_DURATION)
      .slice(0, limit);
  }

  toastAlpha(it: NotificationItem): number {
    const age = this.now - it.createdAt;
    if (age < 0.15) return Math.max(0, age / 0.15);
    if (age > TOAST_DURATION - 0.6) return Math.max(0, (TOAST_DURATION - age) / 0.6);
    return 1;
  }

  unreadCount(): number {
    return this.items.reduce((n, it) => n + (it.read ? 0 : 1), 0);
  }

  markRead(id: number) {
    const it = this.items.find((x) => x.id === id);
    if (it) it.read = true;
  }

  dismiss(id: number) {
    const it = this.items.find((x) => x.id === id);
    if (it) { it.dismissed = true; it.read = true; }
  }

  markAllRead() {
    for (const it of this.items) it.read = true;
  }

  clear() {
    this.items = [];
  }
}
