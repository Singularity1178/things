// Settings and accessibility store (Phase 0.7).
// Central registry so later phases register their options in one place and the
// Settings screen renders them automatically. Safe in headless Node tests.

export type ColorBlindPalette = "default" | "deuteranopia" | "protanopia" | "tritanopia" | "highContrast";
export type UiScaleOption = 1 | 1.25 | 1.5;

export type ActionId =
  | "moveUp"
  | "moveDown"
  | "moveLeft"
  | "moveRight"
  | "interact"
  | "attack"
  | "core"
  | "scan"
  | "pack"
  | "build"
  | "quickPlace"
  | "map"
  | "quickSave"
  | "quickLoad"
  | "pause"
  | "speedDown"
  | "speedUp"
  | "settings"
  | "floors"
  | "alerts";

export const ACTION_LABELS: Record<ActionId, string> = {
  moveUp: "Move Up",
  moveDown: "Move Down",
  moveLeft: "Move Left",
  moveRight: "Move Right",
  interact: "Interact / Use",
  attack: "Ground Slam",
  core: "Slot / Remove Core",
  scan: "Toggle Vision Scan",
  pack: "Open Pack",
  build: "Build Menu",
  quickPlace: "Quick Place",
  map: "Schematic Map",
  quickSave: "Quick Save",
  quickLoad: "Quick Load",
  pause: "Pause Simulation",
  speedDown: "Decrease Speed",
  speedUp: "Increase Speed",
  settings: "Settings & Accessibility",
  floors: "Areas & Floors",
  alerts: "Notification Feed",
};

export const DEFAULT_KEYBINDS: Record<ActionId, string[]> = {
  moveUp: ["w", "arrowup"],
  moveDown: ["s", "arrowdown"],
  moveLeft: ["a", "arrowleft"],
  moveRight: ["d", "arrowright"],
  interact: ["e", "enter"],
  attack: [" "],
  core: ["c"],
  scan: ["z"],
  pack: ["i", "tab"],
  build: ["b"],
  quickPlace: ["v"],
  map: ["m"],
  quickSave: ["k", "f5"],
  quickLoad: ["l", "f9"],
  pause: ["p"],
  speedDown: ["-"],
  speedUp: ["="],
  settings: ["o", "f10"],
  floors: ["f"],
  alerts: ["n"],
};

export interface Settings {
  masterVolume: number;
  sfxVolume: number;
  ambientVolume: number;
  screenShake: boolean;
  screenFlash: boolean;
  uiScale: UiScaleOption;
  colorBlindPalette: ColorBlindPalette;
  autosaveInterval: number; // seconds: 0 = off, 60, 120, 300
  autosaveOnAreaChange: boolean;
  pauseOnAlert: boolean;
  pauseOnJobBlocked: boolean;
  pauseOnDayPhase: boolean;
  showHudBar: boolean;
  keybinds: Record<ActionId, string[]>;
  /** Extra options registered by future phases. */
  extra: Record<string, number | boolean | string>;
}

export const DEFAULT_SETTINGS: Settings = {
  masterVolume: 0.55,
  sfxVolume: 1.0,
  ambientVolume: 1.0,
  screenShake: true,
  screenFlash: true,
  uiScale: 1,
  colorBlindPalette: "default",
  autosaveInterval: 120,
  autosaveOnAreaChange: true,
  pauseOnAlert: true,
  pauseOnJobBlocked: false,
  pauseOnDayPhase: false,
  showHudBar: true,
  keybinds: cloneKeybinds(DEFAULT_KEYBINDS),
  extra: {},
};

export type SettingCategory = "audio" | "display" | "alerts" | "gameplay";

export type SettingDef =
  | { id: string; category: SettingCategory; kind: "slider"; label: string; hint?: string; min: number; max: number; step: number; format?: (v: number) => string; get: (s: Settings) => number; set: (s: Settings, v: number) => void }
  | { id: string; category: SettingCategory; kind: "toggle"; label: string; hint?: string; get: (s: Settings) => boolean; set: (s: Settings, v: boolean) => void }
  | { id: string; category: SettingCategory; kind: "choice"; label: string; hint?: string; choices: { value: string | number; label: string }[]; get: (s: Settings) => string | number; set: (s: Settings, v: string | number) => void };

const SETTINGS_KEY = "dustwake.settings.v1";

function cloneKeybinds(kb: Record<ActionId, string[]>): Record<ActionId, string[]> {
  const out = {} as Record<ActionId, string[]>;
  for (const k of Object.keys(DEFAULT_KEYBINDS) as ActionId[]) {
    out[k] = [...(kb[k] ?? DEFAULT_KEYBINDS[k])];
  }
  return out;
}

/** Core settings registered up-front; later phases append via `registerSetting()`. */
const registry: SettingDef[] = [
  {
    id: "masterVolume", category: "audio", kind: "slider", label: "Master Volume", hint: "Overall sound level",
    min: 0, max: 1, step: 0.05, format: (v) => `${Math.round(v * 100)}%`,
    get: (s) => s.masterVolume, set: (s, v) => { s.masterVolume = v; },
  },
  {
    id: "sfxVolume", category: "audio", kind: "slider", label: "Effects Volume", hint: "Footsteps, tools, UI cues",
    min: 0, max: 1, step: 0.05, format: (v) => `${Math.round(v * 100)}%`,
    get: (s) => s.sfxVolume, set: (s, v) => { s.sfxVolume = v; },
  },
  {
    id: "ambientVolume", category: "audio", kind: "slider", label: "Ambient Volume", hint: "Halls drone, wind, rune hum",
    min: 0, max: 1, step: 0.05, format: (v) => `${Math.round(v * 100)}%`,
    get: (s) => s.ambientVolume, set: (s, v) => { s.ambientVolume = v; },
  },
  {
    id: "screenShake", category: "display", kind: "toggle", label: "Screen Shake", hint: "Camera jolt on impacts & rumbles",
    get: (s) => s.screenShake, set: (s, v) => { s.screenShake = v; },
  },
  {
    id: "screenFlash", category: "display", kind: "toggle", label: "Screen Flash", hint: "Bright flashes on rune jumps & hits",
    get: (s) => s.screenFlash, set: (s, v) => { s.screenFlash = v; },
  },
  {
    id: "uiScale", category: "display", kind: "choice", label: "UI Scale", hint: "Hi-res management UI scale",
    choices: [{ value: 1, label: "100%" }, { value: 1.25, label: "125%" }, { value: 1.5, label: "150%" }],
    get: (s) => s.uiScale, set: (s, v) => { s.uiScale = Number(v) as UiScaleOption; },
  },
  {
    id: "colorBlindPalette", category: "display", kind: "choice", label: "Overlay Palette", hint: "Color-blind-safe vision & alert colors",
    choices: [
      { value: "default", label: "Default" },
      { value: "deuteranopia", label: "Deuteranopia (Okabe-Ito)" },
      { value: "protanopia", label: "Protanopia Safe" },
      { value: "tritanopia", label: "Tritanopia Safe" },
      { value: "highContrast", label: "High Contrast" },
    ],
    get: (s) => s.colorBlindPalette, set: (s, v) => { s.colorBlindPalette = v as ColorBlindPalette; },
  },
  {
    id: "showHudBar", category: "display", kind: "toggle", label: "Management HUD Bar", hint: "Top bar with speed, floors, saves & alerts",
    get: (s) => s.showHudBar, set: (s, v) => { s.showHudBar = v; },
  },
  {
    id: "autosaveInterval", category: "alerts", kind: "choice", label: "Autosave Timer", hint: "Automatic save cadence during play",
    choices: [{ value: 0, label: "Off" }, { value: 60, label: "Every 1 min" }, { value: 120, label: "Every 2 min" }, { value: 300, label: "Every 5 min" }],
    get: (s) => s.autosaveInterval, set: (s, v) => { s.autosaveInterval = Number(v); },
  },
  {
    id: "autosaveOnAreaChange", category: "alerts", kind: "toggle", label: "Autosave on Area Change", hint: "Save whenever you travel to another area",
    get: (s) => s.autosaveOnAreaChange, set: (s, v) => { s.autosaveOnAreaChange = v; },
  },
  {
    id: "pauseOnAlert", category: "alerts", kind: "toggle", label: "Pause on Critical Alert", hint: "Auto-pause sim when an alert fires",
    get: (s) => s.pauseOnAlert, set: (s, v) => { s.pauseOnAlert = v; },
  },
  {
    id: "pauseOnJobBlocked", category: "alerts", kind: "toggle", label: "Pause when Worker Blocked", hint: "Auto-pause when a worker cannot continue",
    get: (s) => s.pauseOnJobBlocked, set: (s, v) => { s.pauseOnJobBlocked = v; },
  },
  {
    id: "pauseOnDayPhase", category: "alerts", kind: "toggle", label: "Pause at Dawn / Dusk", hint: "Auto-pause on major day phase transitions",
    get: (s) => s.pauseOnDayPhase, set: (s, v) => { s.pauseOnDayPhase = v; },
  },
];

/** Register an additional setting option for any phase/module (idempotent by id). */
export function registerSetting(def: SettingDef) {
  const idx = registry.findIndex((d) => d.id === def.id);
  if (idx >= 0) registry[idx] = def;
  else registry.push(def);
}

/** List all registered settings, optionally filtered by category. */
export function registeredSettings(category?: SettingCategory): readonly SettingDef[] {
  return category ? registry.filter((d) => d.category === category) : registry;
}

type SettingsListener = (s: Settings) => void;

export class SettingsStore {
  data: Settings = this.load();
  private listeners: SettingsListener[] = [];

  private load(): Settings {
    const base: Settings = { ...DEFAULT_SETTINGS, keybinds: cloneKeybinds(DEFAULT_KEYBINDS), extra: {} };
    if (typeof localStorage === "undefined") return base;
    try {
      const raw = localStorage.getItem(SETTINGS_KEY);
      if (!raw) return base;
      const parsed = JSON.parse(raw) as Partial<Settings>;
      return {
        ...base,
        ...parsed,
        keybinds: cloneKeybinds({ ...DEFAULT_KEYBINDS, ...(parsed.keybinds ?? {}) }),
        extra: { ...(parsed.extra ?? {}) },
      };
    } catch {
      return base;
    }
  }

  save() {
    if (typeof localStorage !== "undefined") {
      try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(this.data)); } catch { /* ignore quota */ }
    }
    for (const fn of this.listeners) fn(this.data);
  }

  onChange(fn: SettingsListener): () => void {
    this.listeners.push(fn);
    return () => { this.listeners = this.listeners.filter((l) => l !== fn); };
  }

  /** Rebind primary key for `action`. Preserves secondary alias if any. */
  rebind(action: ActionId, key: string) {
    const k = key.toLowerCase();
    const prev = this.data.keybinds[action] ?? DEFAULT_KEYBINDS[action];
    this.data.keybinds[action] = prev.length > 1 ? [k, prev[1]] : [k];
    this.save();
  }

  resetKeybinds() {
    this.data.keybinds = cloneKeybinds(DEFAULT_KEYBINDS);
    this.save();
  }

  resetAll() {
    this.data = { ...DEFAULT_SETTINGS, keybinds: cloneKeybinds(DEFAULT_KEYBINDS), extra: {} };
    this.save();
  }

  keysFor(action: ActionId): readonly string[] {
    return this.data.keybinds[action] ?? DEFAULT_KEYBINDS[action];
  }

  formatBinding(action: ActionId): string {
    const list = this.keysFor(action);
    return list.map((k) => (k === " " ? "Space" : k.length === 1 ? k.toUpperCase() : k[0].toUpperCase() + k.slice(1))).join(" / ");
  }
}

export const settingsStore = new SettingsStore();
