// Dynamic runtime areas (Phase 0.3): AreaSpec -> deterministic builder by kind.
// Authored areas continue to resolve via AREAS; generated floors, caverns,
// outposts and wilds are instantiated from a saved AreaSpec at runtime.
import { mulberry } from "../core/rng";
import { TS, T, FS } from "../content/tiles";
import type { AreaData, DecalDef, LightDef, LooseItem, Portal, PropDef, Room, Spot } from "../map";
import { AREAS } from "./areas";

export type AreaKind = "authored" | "dungeon_floor" | "cavern" | "outpost" | "wilds";

export interface AreaSpec {
  id: string;
  kind: AreaKind;
  seed: number;
  w: number;
  h: number;
  parent?: string;
  depth: number;
  /** Optional display label for HUD / floor switcher. */
  label?: string;
  /** True for player-built areas (saves use compressed full grid). */
  playerBuilt?: boolean;
}

export type AreaKindBuilder = (spec: AreaSpec) => AreaData;

export const AREA_KIND_BUILDERS: Record<AreaKind, AreaKindBuilder> = {
  authored: (spec) => {
    const fn = AREAS[spec.id];
    if (!fn) throw new Error(`unknown authored area "${spec.id}"`);
    return fn();
  },
  dungeon_floor: buildDungeonFloor,
  cavern: buildCavern,
  outpost: buildOutpost,
  wilds: buildWilds,
};

/** Register a custom dynamic area builder at runtime (extension seam). */
export function registerAreaKind(kind: string, builder: AreaKindBuilder) {
  (AREA_KIND_BUILDERS as Record<string, AreaKindBuilder>)[kind] = builder;
}

/** Build an AreaData deterministically from an AreaSpec. */
export function buildAreaFromSpec(spec: AreaSpec): AreaData {
  const builder = AREA_KIND_BUILDERS[spec.kind];
  if (!builder) throw new Error(`unknown area kind "${spec.kind}"`);
  return builder(spec);
}

/** Helper to safely clamp dynamic area dimensions. */
function clampSize(spec: AreaSpec, minW = 24, minH = 20, maxW = 128, maxH = 128) {
  return {
    w: Math.max(minW, Math.min(maxW, Math.floor(spec.w || 40))),
    h: Math.max(minH, Math.min(maxH, Math.floor(spec.h || 32))),
  };
}

// ---------------------------------------------------------------- dungeon_floor
function buildDungeonFloor(spec: AreaSpec): AreaData {
  const { w, h } = clampSize(spec, 28, 22);
  const rng = mulberry((spec.seed ^ (spec.depth * 2654435761)) >>> 0);
  const grid = new Uint8Array(w * h); // defaults to T.WALL (0)
  const style = new Uint8Array(w * h);
  const tvar = new Uint8Array(w * h);

  const inb = (x: number, y: number) => x >= 1 && y >= 1 && x < w - 1 && y < h - 1;
  const carve = (x: number, y: number, s: number) => {
    if (!inb(x, y)) return;
    grid[y * w + x] = T.FLOOR;
    style[y * w + x] = s;
  };
  const carveRect = (x0: number, y0: number, rw: number, rh: number, s: number) => {
    for (let y = y0; y < y0 + rh; y++) {
      for (let x = x0; x < x0 + rw; x++) carve(x, y, s);
    }
  };

  const rooms: Room[] = [];
  const props: PropDef[] = [];
  const lights: LightDef[] = [];
  const loose: LooseItem[] = [];
  const decals: DecalDef[] = [];
  const spots: Spot[] = [];
  const drips: { x: number; y: number }[] = [];

  const roomStyles = [FS.FLAG, FS.BRICK, FS.COBBLE, FS.MARBLE];
  const roomNames = ["LANDING HALL", "VAULT", "STOREHOUSE", "WORKROOM", "GALLERY", "CHAMBER", "CRYPT", "ARMORY"];

  // 1. Entry room near top-center
  const entryW = 8, entryH = 6;
  const entryX = Math.max(2, Math.floor(w / 2) - 4);
  const entryY = 2;
  carveRect(entryX, entryY, entryW, entryH, FS.FLAG);
  rooms.push({ num: 1, name: `FLOOR ${spec.depth} LANDING`, x: entryX, y: entryY, w: entryW, h: entryH });

  // 2. Generate non-overlapping rooms
  const targetRooms = Math.max(4, Math.min(10, Math.floor((w * h) / 170)));
  for (let attempt = 0; attempt < 90 && rooms.length < targetRooms; attempt++) {
    const rw = 5 + Math.floor(rng() * 6);
    const rh = 4 + Math.floor(rng() * 5);
    const rx = 2 + Math.floor(rng() * Math.max(1, w - rw - 4));
    const ry = 2 + Math.floor(rng() * Math.max(1, h - rh - 4));
    const overlaps = rooms.some((r) => rx <= r.x + r.w + 1 && rx + rw + 1 >= r.x && ry <= r.y + r.h + 1 && ry + rh + 1 >= r.y);
    if (overlaps) continue;
    const st = roomStyles[Math.floor(rng() * roomStyles.length)];
    carveRect(rx, ry, rw, rh, st);
    const num = rooms.length + 1;
    rooms.push({ num, name: `${roomNames[num % roomNames.length]} ${num}`, x: rx, y: ry, w: rw, h: rh });
  }

  // 3. Connect each room to the previous one with 2-tile-wide corridors
  for (let i = 1; i < rooms.length; i++) {
    const a = rooms[i - 1], b = rooms[i];
    let cx = Math.floor(a.x + a.w / 2), cy = Math.floor(a.y + a.h / 2);
    const tx = Math.floor(b.x + b.w / 2), ty = Math.floor(b.y + b.h / 2);
    while (cx !== tx) {
      carve(cx, cy, FS.COBBLE);
      carve(cx, Math.min(h - 2, cy + 1), FS.COBBLE);
      cx += cx < tx ? 1 : -1;
    }
    while (cy !== ty) {
      carve(cx, cy, FS.COBBLE);
      carve(Math.min(w - 2, cx + 1), cy, FS.COBBLE);
      cy += cy < ty ? 1 : -1;
    }
  }

  // 4. Populate rooms with torches, chests, rocks/rubble, spots, drips
  let propIdx = 0;
  let spotIdx = 0;
  for (let i = 0; i < rooms.length; i++) {
    const r = rooms[i];
    // North wall torches
    const torchTx = r.x + Math.floor(r.w / 2);
    const torchTy = r.y;
    const tid = `torch@${torchTx},${torchTy}#${propIdx++}`;
    props.push({ id: tid, kind: "torch", x: torchTx * TS + 8, y: torchTy * TS + 4, v: 0, lit: true });
    lights.push({ x: torchTx * TS + 8, y: torchTy * TS + 10, rad: 96, col: [1.0, 0.72, 0.42], int: 0.78, flick: 0.14, owner: tid });

    // Standing spots for residents/workers
    const cx = Math.floor(r.x + r.w / 2) * TS + 8;
    const cy = Math.floor(r.y + r.h / 2) * TS + 8;
    spots.push({ id: `wander.${spotIdx++}`, kind: "wander", x: cx, y: cy, facing: "down" });
    if (r.w >= 6 && r.h >= 5) {
      spots.push({ id: `work.floor.${spotIdx++}`, kind: "work", x: (r.x + 2) * TS + 8, y: (r.y + 2) * TS + 8, facing: "right" });
    }

    if (i > 0) {
      // Storage chest in alternating rooms
      if (i % 2 === 1) {
        const px = (r.x + 1) * TS + 10, py = (r.y + 1) * TS + 14;
        props.push({ id: `chest@${r.x + 1},${r.y + 1}#${propIdx++}`, kind: "chest", x: px, y: py, v: 0, container: true });
      }
      // Harvestable stone / iron vein or loose items
      if (rng() < 0.7) {
        const rx = (r.x + r.w - 2) * TS + 8, ry = (r.y + r.h - 2) * TS + 8;
        props.push({ id: `rock@${r.x + r.w - 2},${r.y + r.h - 2}#${propIdx++}`, kind: rng() < 0.4 ? "iron_vein" : "rock", x: rx, y: ry, v: Math.floor(rng() * 3) });
      }
      if (rng() < 0.5) {
        loose.push({ id: `loose_${i}`, item: rng() < 0.5 ? "stone" : "wood", n: 2 + Math.floor(rng() * 3), x: cx + 10, y: cy + 6 });
      }
      if (rng() < 0.5) {
        drips.push({ x: cx, y: cy });
      }
    }
    if (i === 0) {
      // Brazier in landing hall
      const bx = (r.x + 2) * TS + 8, by = (r.y + 2) * TS + 10;
      const bid = `brazier@${r.x + 2},${r.y + 2}#${propIdx++}`;
      props.push({ id: bid, kind: "brazier", x: bx, y: by, v: 0, lit: true });
      lights.push({ x: bx, y: by - 4, rad: 120, col: [1.0, 0.68, 0.35], int: 0.9, flick: 0.12, owner: bid });
    }
  }

  // Tile variation
  for (let i = 0; i < w * h; i++) tvar[i] = Math.floor(rng() * 4);

  const startX = (entryX + Math.floor(entryW / 2)) * TS + 8;
  const startY = (entryY + Math.floor(entryH / 2)) * TS + 8;
  const portals: Portal[] = [];
  if (spec.parent) {
    portals.push({
      id: "up",
      x: entryX * TS + 8,
      y: entryY * TS + 2,
      w: TS * 2,
      h: TS,
      dir: "up",
      to: { area: spec.parent, portal: `to:${spec.id}` },
      arrive: { x: startX, y: startY },
      door: true,
      label: spec.label ?? `FLOOR ${spec.depth}`,
    });
  }

  return {
    id: spec.id,
    w,
    h,
    grid,
    plan: grid.slice(),
    style,
    tvar,
    rooms,
    props,
    decals,
    lights,
    loose,
    portals,
    spots,
    ambient: [0.06, 0.055, 0.075],
    start: { x: startX, y: startY },
    exits: spec.parent ? [{ x: entryX + 1, y: entryY, label: `UP TO ${spec.parent.toUpperCase()}`, dir: "n" }] : [],
    drips,
  };
}

// ---------------------------------------------------------------- cavern
function buildCavern(spec: AreaSpec): AreaData {
  const { w, h } = clampSize(spec, 28, 22);
  const rng = mulberry((spec.seed ^ 0x51a7c3) >>> 0);
  const grid = new Uint8Array(w * h);
  const style = new Uint8Array(w * h);
  const tvar = new Uint8Array(w * h);

  // Random walk / drunken miner carving organic chambers
  const cx0 = Math.floor(w / 2), cy0 = Math.floor(h / 2);
  const carveDisk = (cx: number, cy: number, rad: number, s: number) => {
    for (let dy = -rad; dy <= rad; dy++) {
      for (let dx = -rad; dx <= rad; dx++) {
        if (dx * dx + dy * dy > rad * rad + 0.5) continue;
        const x = cx + dx, y = cy + dy;
        if (x >= 2 && y >= 2 && x < w - 2 && y < h - 2) {
          grid[y * w + x] = T.FLOOR;
          style[y * w + x] = s;
        }
      }
    }
  };
  carveDisk(cx0, cy0, 3, FS.DIRT);
  let wx = cx0, wy = cy0;
  const steps = Math.floor(w * h * 0.6);
  for (let i = 0; i < steps; i++) {
    const dir = Math.floor(rng() * 4);
    wx += dir === 0 ? 1 : dir === 1 ? -1 : 0;
    wy += dir === 2 ? 1 : dir === 3 ? -1 : 0;
    wx = Math.max(3, Math.min(w - 4, wx));
    wy = Math.max(3, Math.min(h - 4, wy));
    carveDisk(wx, wy, rng() < 0.25 ? 2 : 1, rng() < 0.3 ? FS.MOSS : FS.DIRT);
  }

  const props: PropDef[] = [];
  const lights: LightDef[] = [];
  const loose: LooseItem[] = [];
  const spots: Spot[] = [];
  const drips: { x: number; y: number }[] = [];

  const startX = cx0 * TS + 8, startY = cy0 * TS + 8;
  // Camp brazier at cavern entry
  props.push({ id: "cavern_brazier", kind: "brazier", x: startX - 18, y: startY - 6, v: 0, lit: true });
  lights.push({ x: startX - 18, y: startY - 10, rad: 128, col: [0.95, 0.72, 0.45], int: 0.9, flick: 0.14, owner: "cavern_brazier" });

  let pIdx = 0, sIdx = 0;
  for (let y = 3; y < h - 3; y += 3) {
    for (let x = 3; x < w - 3; x += 3) {
      if (grid[y * w + x] !== T.FLOOR) continue;
      if (Math.hypot(x - cx0, y - cy0) < 3) continue;
      const px = x * TS + 8, py = y * TS + 8;
      const r = rng();
      if (r < 0.18) {
        props.push({ id: `vein@${x},${y}#${pIdx++}`, kind: r < 0.08 ? "iron_vein" : "rock", x: px, y: py, v: Math.floor(rng() * 3) });
      } else if (r < 0.24) {
        loose.push({ id: `ore_${pIdx++}`, item: "stone", n: 2, x: px, y: py });
      } else if (r < 0.34) {
        spots.push({ id: `wander.${sIdx++}`, kind: "wander", x: px, y: py, facing: "down" });
      }
      if (r > 0.92) drips.push({ x: px, y: py });
    }
  }
  for (let i = 0; i < w * h; i++) tvar[i] = Math.floor(rng() * 4);

  return {
    id: spec.id,
    w,
    h,
    grid,
    plan: grid.slice(),
    style,
    tvar,
    rooms: [{ num: 1, name: spec.label ?? `CAVERN D${spec.depth}`, x: 2, y: 2, w: w - 4, h: h - 4 }],
    props,
    decals: [],
    lights,
    loose,
    portals: spec.parent ? [{ id: "up", x: startX - 12, y: startY - 24, w: 24, h: 16, dir: "up", to: { area: spec.parent, portal: `to:${spec.id}` }, arrive: { x: startX, y: startY }, label: spec.label ?? `CAVERN ${spec.depth}` }] : [],
    spots,
    ambient: [0.055, 0.065, 0.08],
    start: { x: startX, y: startY },
    exits: [],
    drips,
  };
}

// ---------------------------------------------------------------- outpost
function buildOutpost(spec: AreaSpec): AreaData {
  const { w, h } = clampSize(spec, 28, 22);
  const rng = mulberry((spec.seed ^ 0x93c11d) >>> 0);
  const grid = new Uint8Array(w * h);
  const style = new Uint8Array(w * h);
  const tvar = new Uint8Array(w * h);

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const border = x < 2 || y < 2 || x >= w - 2 || y >= h - 2;
      grid[y * w + x] = border ? T.THICKET : T.FLOOR;
      style[y * w + x] = rng() < 0.25 ? FS.MOSS : FS.GRASS;
      tvar[y * w + x] = Math.floor(rng() * 4);
    }
  }

  // Central stone clearing for outpost work
  const cx = Math.floor(w / 2), cy = Math.floor(h / 2);
  for (let y = cy - 3; y <= cy + 3; y++) {
    for (let x = cx - 4; x <= cx + 4; x++) {
      style[y * w + x] = FS.COBBLE;
    }
  }

  const startX = cx * TS + 8, startY = cy * TS + 8;
  const props: PropDef[] = [
    { id: "outpost_brazier", kind: "brazier", x: startX - 24, y: startY - 12, v: 0, lit: true },
    { id: "outpost_chest", kind: "chest", x: startX + 26, y: startY - 12, v: 0, container: true },
  ];
  const lights: LightDef[] = [
    { x: startX - 24, y: startY - 16, rad: 120, col: [1.0, 0.72, 0.38], int: 0.85, flick: 0.14, owner: "outpost_brazier" },
  ];
  const spots: Spot[] = [
    { id: "camp.center", kind: "camp", x: startX, y: startY + 12, facing: "up" },
    { id: "wander.east", kind: "wander", x: startX + 48, y: startY, facing: "left" },
    { id: "wander.west", kind: "wander", x: startX - 48, y: startY, facing: "right" },
  ];

  let pIdx = 0;
  for (let y = 3; y < h - 3; y += 3) {
    for (let x = 3; x < w - 3; x += 3) {
      if (Math.abs(x - cx) <= 5 && Math.abs(y - cy) <= 4) continue;
      if (rng() < 0.35) {
        props.push({ id: `tree@${x},${y}#${pIdx++}`, kind: "tree", x: x * TS + 8, y: y * TS + 12, v: Math.floor(rng() * 3) });
      } else if (rng() < 0.12) {
        props.push({ id: `rock@${x},${y}#${pIdx++}`, kind: "rock", x: x * TS + 8, y: y * TS + 10, v: Math.floor(rng() * 3) });
      }
    }
  }

  return {
    id: spec.id,
    w,
    h,
    grid,
    plan: grid.slice(),
    style,
    tvar,
    rooms: [{ num: 1, name: spec.label ?? `OUTPOST ${spec.depth}`, x: 2, y: 2, w: w - 4, h: h - 4 }],
    props,
    decals: [],
    lights,
    loose: [{ id: "outpost_wood", item: "wood", n: 4, x: startX + 16, y: startY + 18 }],
    outdoor: true,
    ambient: [0.14, 0.15, 0.22],
    portals: spec.parent ? [{ id: "return", x: startX - 16, y: (h - 3) * TS, w: 32, h: TS, dir: "down", to: { area: spec.parent, portal: `to:${spec.id}` }, arrive: { x: startX, y: startY }, label: spec.label ?? `OUTPOST ${spec.depth}` }] : [],
    spots,
    start: { x: startX, y: startY },
    exits: [],
    drips: [],
  };
}

// ---------------------------------------------------------------- wilds
function buildWilds(spec: AreaSpec): AreaData {
  const { w, h } = clampSize(spec, 28, 22);
  const rng = mulberry((spec.seed ^ 0x3b72f5) >>> 0);
  const grid = new Uint8Array(w * h);
  const style = new Uint8Array(w * h);
  const tvar = new Uint8Array(w * h);

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const border = x < 2 || y < 2 || x >= w - 2 || y >= h - 2;
      grid[y * w + x] = border ? T.THICKET : T.FLOOR;
      const r = rng();
      style[y * w + x] = r < 0.55 ? FS.GRASS : r < 0.78 ? FS.LEAF : r < 0.9 ? FS.MOSS : FS.DIRT;
      tvar[y * w + x] = Math.floor(rng() * 4);
    }
  }

  const cx = Math.floor(w / 2), cy = Math.floor(h / 2);
  const startX = cx * TS + 8, startY = cy * TS + 8;
  const props: PropDef[] = [];
  const loose: LooseItem[] = [];
  const spots: Spot[] = [];

  let idx = 0;
  for (let y = 3; y < h - 3; y += 2) {
    for (let x = 3; x < w - 3; x += 2) {
      if (Math.hypot(x - cx, y - cy) < 3) continue;
      const r = rng();
      const px = x * TS + 8, py = y * TS + 10;
      if (r < 0.24) props.push({ id: `tree@${x},${y}#${idx++}`, kind: "tree", x: px, y: py, v: Math.floor(rng() * 3) });
      else if (r < 0.30) props.push({ id: `rock@${x},${y}#${idx++}`, kind: r < 0.27 ? "rock" : "iron_vein", x: px, y: py, v: Math.floor(rng() * 3) });
      else if (r < 0.34) spots.push({ id: `forage.${idx++}`, kind: "forage", x: px, y: py, facing: "down" });
      else if (r < 0.37) loose.push({ id: `wild_drop_${idx++}`, item: r < 0.355 ? "wood" : "stone", n: 1, x: px, y: py });
    }
  }

  return {
    id: spec.id,
    w,
    h,
    grid,
    plan: grid.slice(),
    style,
    tvar,
    rooms: [{ num: 1, name: spec.label ?? `WILDS ${spec.depth}`, x: 2, y: 2, w: w - 4, h: h - 4 }],
    props,
    decals: [],
    lights: [],
    loose,
    outdoor: true,
    ambient: [0.14, 0.15, 0.22],
    portals: spec.parent ? [{ id: "return", x: startX - 16, y: (h - 3) * TS, w: 32, h: TS, dir: "down", to: { area: spec.parent, portal: `to:${spec.id}` }, arrive: { x: startX, y: startY }, label: spec.label ?? `WILDS ${spec.depth}` }] : [],
    spots,
    start: { x: startX, y: startY },
    exits: [],
    drips: [],
  };
}
