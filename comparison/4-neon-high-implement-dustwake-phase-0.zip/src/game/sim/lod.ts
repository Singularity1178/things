// Simulation Level-of-Detail (Phase 0.2): Active / Near / Far tiers.
// Pure (no DOM). Deterministic given (world, tickIndex, viewRect).
//
// - Active: in camera view (or the player) -> full step every tick.
// - Near:   same area, off-camera -> stepped every NEAR_STRIDE ticks with
//           accumulated dt (staggered deterministically by actor index).
// - Far:    other areas -> abstract, schedule-based ("set down where the hour
//           says" on entry via catchUpArea using `world.time - area.lastTicked`).
import type { Actor, World } from "../world/world";
import type { Area } from "../world/area";
import { player } from "../world/world";
import { isFolk, settle } from "./folk";

export type LodTier = "active" | "near" | "far";

export interface ViewRect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface LodConfig {
  /** Current camera viewport in world pixels. When omitted (unit tests), all actors in player's area are Active. */
  view?: ViewRect;
  /** Padding around viewport (px) before downgrading Active -> Near. */
  pad?: number;
  /** Tick stride for Near actors (default 4: runs every 4th tick with 4*dt). */
  nearStride?: number;
  /** Tick stride for Far active workers (default 4). */
  farStride?: number;
  /** Monotonic fixed-step tick index (incremented each stepWorld). */
  tick: number;
  /** Last computed tier counts for HUD / diagnostics. */
  counts: { active: number; near: number; far: number };
}

export const DEFAULT_NEAR_STRIDE = 4;
export const DEFAULT_FAR_STRIDE = 4;
export const DEFAULT_VIEW_PAD = 48;

export function createLodConfig(): LodConfig {
  return {
    pad: DEFAULT_VIEW_PAD,
    nearStride: DEFAULT_NEAR_STRIDE,
    farStride: DEFAULT_FAR_STRIDE,
    tick: 0,
    counts: { active: 0, near: 0, far: 0 },
  };
}

/** Deterministic small integer bucket from actor id (FNV-1a 32-bit). */
export function actorBucket(id: string): number {
  let h = 2166136261;
  for (let i = 0; i < id.length; i++) {
    h ^= id.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** Classify an actor into Active, Near, or Far relative to player & camera view. */
export function classifyActorLod(w: World, a: Actor, view?: ViewRect, pad = DEFAULT_VIEW_PAD): LodTier {
  const pl = player(w);
  if (!pl) return "active";
  if (a.id === w.playerId) return "active";
  if (a.area !== pl.area) return "far";
  if (!view) return "active";
  const inView =
    a.x >= view.x - pad &&
    a.x <= view.x + view.w + pad &&
    a.y >= view.y - pad &&
    a.y <= view.y + view.h + pad;
  return inView ? "active" : "near";
}

/**
 * Determine whether an actor should step on this tick, and the effective `dt`
 * it should simulate with. Returns `0` when skipped this tick.
 */
export function actorStepDt(w: World, a: Actor, dt: number): { tier: LodTier; stepDt: number } {
  const lod = w.lod;
  const tier = classifyActorLod(w, a, lod?.view, lod?.pad ?? DEFAULT_VIEW_PAD);
  if (tier === "active") return { tier, stepDt: dt };
  if (tier === "near") {
    const stride = Math.max(1, lod?.nearStride ?? DEFAULT_NEAR_STRIDE);
    if (stride === 1) return { tier, stepDt: dt };
    const tick = lod?.tick ?? 0;
    const due = (actorBucket(a.id) % stride) === (tick % stride);
    return { tier, stepDt: due ? dt * stride : 0 };
  }
  // Far tier:
  // - Folk & keepers are schedule-based and skipped completely until catch-up on area entry.
  // - Actors with an active task or unfinished job still progress at Far stride so
  //   off-screen workers complete logistics across areas.
  if (isFolk(a) || a.kind === "keeper") {
    return { tier, stepDt: 0 };
  }
  const hasWork = !!a.task || (!!a.job && a.job.status !== "done");
  if (!hasWork) return { tier, stepDt: 0 };
  const farStride = lod?.view ? Math.max(1, lod.farStride ?? DEFAULT_FAR_STRIDE) : 1;
  if (farStride === 1) return { tier, stepDt: dt };
  const tick = lod?.tick ?? 0;
  const due = (actorBucket(a.id) % farStride) === (tick % farStride);
  return { tier, stepDt: due ? dt * farStride : 0 };
}

/**
 * Catch up a Far area when the player enters it (or on explicit refresh),
 * using `elapsed = world.time - area.lastTicked`.
 * Advances area-level timers (rituals) and settles schedule-driven residents
 * to where the current calendar hour says they belong.
 */
export function catchUpArea(w: World, area: Area): number {
  const elapsed = Math.max(0, w.time - area.lastTicked);
  if (elapsed > 0) {
    area.advanceRitual(elapsed);
    for (const a of w.actors) {
      if (a.area !== area.id) continue;
      if (isFolk(a)) {
        // Respect active jobs/tasks; settle schedule-driven residents if stale
        if (!a.task && (!a.job || a.job.status === "done")) {
          if (elapsed > 20 || w.time - a.life!.seen > 20) {
            settle(w, a);
          }
          a.life!.seen = w.time;
        }
      }
    }
  }
  area.lastTicked = w.time;
  return elapsed;
}
