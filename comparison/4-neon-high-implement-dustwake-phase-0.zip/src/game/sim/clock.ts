// Fixed-timestep simulation clock with interpolated rendering support (Phase 0.1).
// Pure (no DOM). Game speeds (pause / 1x / 2x / 4x / 8x) simply advance more
// fixed ticks per animation frame, guaranteeing identical world state across
// speeds for the same save and tick-indexed input stream.
import type { Actor, World } from "../world/world";

/** Fixed simulation rate (Hz) and tick duration (seconds). */
export const SIM_HZ = 60;
export const SIM_DT = 1 / SIM_HZ;

/** Supported management simulation speeds (0 = paused). */
export type GameSpeed = 0 | 1 | 2 | 4 | 8;
export const GAME_SPEEDS: readonly GameSpeed[] = [0, 1, 2, 4, 8];

/** Small epsilon so exact 1/60 frames never suffer IEEE-754 underflow. */
const EPS = 1e-9;

/** Maximum ticks per animation frame to prevent spiral-of-death on tab resume. */
const MAX_TICKS_PER_FRAME = 24;

export interface StepSummary {
  /** Number of fixed simulation ticks executed this frame. */
  ticks: number;
  /** Interpolation fraction in [0, 1) between previous and current tick. */
  alpha: number;
}

export interface ActorPoseSnap {
  x: number;
  y: number;
  area: string;
}

/**
 * Snapshot of actor positions before the latest simulation tick so the renderer
 * can smoothly interpolate between ticks without mutating simulation state.
 */
export class InterpBuffer {
  private prev = new Map<string, ActorPoseSnap>();

  capture(world: World) {
    this.prev.clear();
    for (const a of world.actors) {
      this.prev.set(a.id, { x: a.x, y: a.y, area: a.area });
    }
  }

  clear() {
    this.prev.clear();
  }

  /** Interpolated world position for rendering `actor` at fraction `alpha` in [0, 1]. */
  position(a: Actor, alpha: number): { x: number; y: number } {
    const p = this.prev.get(a.id);
    if (!p || p.area !== a.area) return { x: a.x, y: a.y };
    // Snap across teleports / portals / large jumps (> 32 px in a single tick)
    const dx = a.x - p.x, dy = a.y - p.y;
    if (dx * dx + dy * dy > 32 * 32) return { x: a.x, y: a.y };
    const k = alpha < 0 ? 0 : alpha > 1 ? 1 : alpha;
    return { x: p.x + dx * k, y: p.y + dy * k };
  }
}

/**
 * Accumulator-based fixed-timestep clock.
 * - `speed === 0` pauses simulation (accumulator does not advance).
 * - `speed === 8` runs 8x as many fixed `tickDt` steps over the same real time.
 */
export class SimClock {
  readonly tickDt: number;
  speed: GameSpeed = 1;
  accumulator = 0;
  tick = 0;
  alpha = 1;
  private lastNonZeroSpeed: GameSpeed = 1;

  constructor(tickDt = SIM_DT) {
    this.tickDt = tickDt;
  }

  get paused(): boolean {
    return this.speed === 0;
  }

  setSpeed(s: GameSpeed) {
    if (s !== 0) this.lastNonZeroSpeed = s;
    this.speed = s;
  }

  togglePause(): GameSpeed {
    this.speed = this.speed === 0 ? this.lastNonZeroSpeed : 0;
    return this.speed;
  }

  stepSpeed(dir: -1 | 1): GameSpeed {
    const idx = GAME_SPEEDS.indexOf(this.speed);
    const next = GAME_SPEEDS[Math.max(0, Math.min(GAME_SPEEDS.length - 1, idx + dir))];
    this.setSpeed(next);
    return this.speed;
  }

  reset() {
    this.accumulator = 0;
    this.tick = 0;
    this.alpha = 1;
  }

  /**
   * Advance the clock by `frameDt` real seconds, invoking `onTick(tickDt, tickIndex)`
   * for each fixed simulation tick. Returns how many ticks ran and the render alpha.
   */
  advance(frameDt: number, onTick: (dt: number, tickIndex: number) => void, onBeforeLastTick?: () => void): StepSummary {
    if (this.speed === 0 || frameDt <= 0) {
      return { ticks: 0, alpha: this.alpha };
    }
    // Clamp absurd frame spikes, then scale by game speed
    const clamped = Math.min(frameDt, 0.1);
    this.accumulator += clamped * this.speed;

    let pending = Math.floor((this.accumulator + EPS) / this.tickDt);
    if (pending > MAX_TICKS_PER_FRAME) {
      pending = MAX_TICKS_PER_FRAME;
      this.accumulator = pending * this.tickDt;
    }

    let ticks = 0;
    for (let i = 0; i < pending; i++) {
      if (i === pending - 1 && onBeforeLastTick) onBeforeLastTick();
      onTick(this.tickDt, this.tick);
      this.tick++;
      this.accumulator = Math.max(0, this.accumulator - this.tickDt);
      ticks++;
    }
    this.alpha = Math.min(1, Math.max(0, this.accumulator / this.tickDt));
    // When accumulator drains cleanly (e.g. exact 1/60 stepping), show the exact latest tick.
    if (this.accumulator < EPS) this.alpha = 1;
    return { ticks, alpha: this.alpha };
  }
}
