// General Content Linter (Phase 0.8). Pure (no DOM).
// Validates every content row across items, recipes, crafting, props, harvest,
// actors, NPCs, dialogue, monologue, shops, folk, talk, runes, and entrances,
// including bitmap font glyph compatibility and cross-table references.
import { FONT_GLYPHS } from "../font";
import { ITEMS, ITEM_NAMES } from "../content/items";
import { RECIPES } from "../content/build";
import { CRAFT_RECIPES, STATIONS } from "../content/crafting";
import { PROPS } from "../content/props";
import { HARVEST } from "../content/harvest";
import { ACTORS } from "../content/actors";
import { NPCS } from "../content/npcs";
import { DIALOGUE } from "../content/dialogue";
import { THOUGHTS } from "../content/monologue";
import { SHOPS, VISITS, SHOP_HABITS } from "../content/shops";
import { ARCHETYPES, CENSUS, FOLK_INTERIORS, ROUTES, ROUTINES, TRAITS, ACTIVITY_LINES } from "../content/folk";
import { EXCHANGES, GRIPES, MUTTERS, NEWS, PEER_LINES, REACTIONS } from "../content/talk";
import { RUNE_NODES } from "../content/runes";
import { ENTRANCES } from "../content/geography";
import { AREAS } from "../world/areas";
import type { AreaData } from "../map";

export interface LintIssue {
  table: string;
  row: string;
  message: string;
}

export interface ContentLintResult {
  ok: boolean;
  checked: number;
  errors: LintIssue[];
  warnings: LintIssue[];
}

/** Check that every character of `text` (uppercased, ignoring `{tokens}` / `@tokens`) exists in FONT_GLYPHS. */
function checkFontText(errors: LintIssue[], table: string, row: string, text: string) {
  const cleaned = text.replace(/\{[a-z]+\}/gi, "").replace(/@[a-z]+/gi, "").toUpperCase();
  for (const ch of cleaned) {
    if (ch === "\n") continue;
    if (!FONT_GLYPHS.has(ch)) {
      errors.push({ table, row, message: `Unsupported bitmap font glyph ${JSON.stringify(ch)} in "${text}"` });
      return;
    }
  }
}

export function lintAllContent(): ContentLintResult {
  const errors: LintIssue[] = [];
  const warnings: LintIssue[] = [];
  let checked = 0;

  const areaCache = new Map<string, AreaData>();
  const getBuiltArea = (id: string): AreaData | null => {
    if (!(id in AREAS)) return null;
    let a = areaCache.get(id);
    if (!a) { a = AREAS[id](); areaCache.set(id, a); }
    return a;
  };

  // 1. ITEMS & ITEM_NAMES
  for (const [id, def] of Object.entries(ITEMS)) {
    checked++;
    const name = ITEM_NAMES[id as keyof typeof ITEM_NAMES];
    if (!name) errors.push({ table: "ITEMS", row: id, message: "Missing ITEM_NAMES entry" });
    else checkFontText(errors, "ITEM_NAMES", id, name);
    if (def.stack !== undefined && (!Number.isInteger(def.stack) || def.stack < 1)) {
      errors.push({ table: "ITEMS", row: id, message: `Invalid stack size ${def.stack}` });
    }
  }

  // 2. PROPS
  for (const [id, def] of Object.entries(PROPS)) {
    checked++;
    if (def.storage && (!Number.isInteger(def.storage.slots) || def.storage.slots <= 0)) {
      errors.push({ table: "PROPS", row: id, message: `Invalid storage slot count ${def.storage.slots}` });
    }
    if (def.box && (def.box[0] <= 0 || def.box[1] <= 0)) {
      errors.push({ table: "PROPS", row: id, message: `Invalid collision box [${def.box.join(",")}]` });
    }
  }

  // 3. HARVEST
  for (const [kind, def] of Object.entries(HARVEST)) {
    checked++;
    if (!(kind in PROPS)) errors.push({ table: "HARVEST", row: kind, message: `Unknown prop kind "${kind}"` });
    if (!(def.perHit.item in ITEMS)) errors.push({ table: "HARVEST", row: kind, message: `Unknown perHit item "${def.perHit.item}"` });
    if (def.final && !(def.final.item in ITEMS)) errors.push({ table: "HARVEST", row: kind, message: `Unknown final item "${def.final.item}"` });
    if (def.hp <= 0) errors.push({ table: "HARVEST", row: kind, message: `Non-positive hp ${def.hp}` });
  }

  // 4. BUILD RECIPES
  for (const [id, r] of Object.entries(RECIPES)) {
    checked++;
    checkFontText(errors, "RECIPES", id, r.name);
    if (!(r.prop in PROPS)) errors.push({ table: "RECIPES", row: id, message: `Unknown prop "${r.prop}"` });
    for (const c of r.cost) {
      if (!(c.item in ITEMS)) errors.push({ table: "RECIPES", row: id, message: `Unknown cost item "${c.item}"` });
      if (!Number.isInteger(c.n) || c.n <= 0) errors.push({ table: "RECIPES", row: id, message: `Invalid cost count ${c.n} for ${c.item}` });
    }
  }

  // 5. CRAFTING STATIONS & RECIPES
  for (const [id, st] of Object.entries(STATIONS)) {
    checked++;
    checkFontText(errors, "STATIONS", id, st.name);
    checkFontText(errors, "STATIONS", `${id}.lockedText`, st.lockedText);
    checkFontText(errors, "STATIONS", `${id}.lockedHint`, st.lockedHint);
    for (const tab of st.tabs ?? []) {
      checkFontText(errors, "STATIONS", `${id}.${tab.id}`, tab.name);
      for (const ln of tab.empty) checkFontText(errors, "STATIONS", `${id}.${tab.id}.empty`, ln);
    }
  }
  for (const r of CRAFT_RECIPES) {
    checked++;
    if (!(r.station in STATIONS)) errors.push({ table: "CRAFT_RECIPES", row: r.id, message: `Unknown station "${r.station}"` });
    checkFontText(errors, "CRAFT_RECIPES", r.id, r.name);
    for (const d of r.desc) checkFontText(errors, "CRAFT_RECIPES", `${r.id}.desc`, d);
    if (!(r.output.item in ITEMS)) errors.push({ table: "CRAFT_RECIPES", row: r.id, message: `Unknown output item "${r.output.item}"` });
    if (!Number.isInteger(r.output.n) || r.output.n <= 0) errors.push({ table: "CRAFT_RECIPES", row: r.id, message: `Invalid output count ${r.output.n}` });
    for (const c of r.inputs) {
      if (!(c.item in ITEMS)) errors.push({ table: "CRAFT_RECIPES", row: r.id, message: `Unknown input item "${c.item}"` });
      if (!Number.isInteger(c.n) || c.n <= 0) errors.push({ table: "CRAFT_RECIPES", row: r.id, message: `Invalid input count ${c.n}` });
    }
    for (const t of r.tools ?? []) {
      if (!(t in ITEMS)) errors.push({ table: "CRAFT_RECIPES", row: r.id, message: `Unknown tool "${t}"` });
    }
  }

  // 6. ACTORS & NPCS
  for (const [id, a] of Object.entries(ACTORS)) {
    checked++;
    checkFontText(errors, "ACTORS", id, a.name);
    if (a.speed < 0) errors.push({ table: "ACTORS", row: id, message: `Negative speed ${a.speed}` });
    if (a.body.box[0] < 0 || a.body.box[1] < 0) errors.push({ table: "ACTORS", row: id, message: "Negative body box" });
  }
  for (const [id, n] of Object.entries(NPCS)) {
    checked++;
    checkFontText(errors, "NPCS", id, n.name);
    if (n.actor && !(n.actor in ACTORS)) errors.push({ table: "NPCS", row: id, message: `Unknown actor definition "${n.actor}"` });
    if (n.dialogue && !(n.dialogue in DIALOGUE)) errors.push({ table: "NPCS", row: id, message: `Unknown dialogue script "${n.dialogue}"` });
  }

  // 7. DIALOGUE SCRIPTS
  for (const [sid, script] of Object.entries(DIALOGUE)) {
    checked++;
    checkFontText(errors, "DIALOGUE", `${sid}.idle`, script.idle);
    for (const seg of script.segments) {
      checked++;
      for (const page of seg.pages) {
        checkFontText(errors, "DIALOGUE", `${sid}.${seg.id}`, page.text);
        if (page.speaker) checkFontText(errors, "DIALOGUE", `${sid}.${seg.id}.speaker`, page.speaker);
      }
    }
  }

  // 8. MONOLOGUE THOUGHTS
  for (const [id, th] of Object.entries(THOUGHTS)) {
    checked++;
    checkFontText(errors, "THOUGHTS", id, th.text);
  }

  // 9. SHOPS & VISITS (verify every shop step resolves in every shop using that visit!)
  for (const [id, shop] of Object.entries(SHOPS)) {
    checked++;
    const areaId = `town_${id}`;
    const area = getBuiltArea(areaId);
    if (!area) {
      errors.push({ table: "SHOPS", row: id, message: `Shop interior area "${areaId}" not in AREAS` });
      continue;
    }
    const spots = area.spots ?? [];
    if (!spots.some((s) => s.id === "keeper")) {
      errors.push({ table: "SHOPS", row: id, message: `Shop "${areaId}" missing "keeper" spot` });
    }
    checkFontText(errors, "SHOPS", id, shop.keeper.title);
    checkFontText(errors, "SHOPS", `${id}.closedNote`, shop.closedNote);
    for (const ln of [...shop.keeper.greet, ...shop.keeper.welcome, ...shop.keeper.hello, ...shop.keeper.closing]) {
      checkFontText(errors, "SHOPS", `${id}.keeper`, ln);
    }
    for (const vid of Object.keys(shop.visits)) {
      const visit = VISITS[vid];
      if (!visit) {
        errors.push({ table: "SHOPS", row: `${id}.visits.${vid}`, message: `Unknown visit "${vid}"` });
        continue;
      }
      for (let i = 0; i < visit.steps.length; i++) {
        const st = visit.steps[i];
        const resolves = st.at.some((pref) =>
          pref === "counter" ? spots.some((s) => s.id === "customer") : spots.some((s) => s.id.startsWith(pref))
        );
        if (!resolves) {
          errors.push({ table: "VISITS", row: `${id}/${vid}.step[${i}]`, message: `None of [${st.at.join(", ")}] match any spot in ${areaId}` });
        }
        if (st.mutter && !(st.mutter in MUTTERS)) {
          errors.push({ table: "VISITS", row: `${vid}.step[${i}]`, message: `Unknown mutter pool "${st.mutter}"` });
        }
      }
    }
  }
  for (const [archId, habit] of Object.entries(SHOP_HABITS)) {
    checked++;
    if (!(archId in ARCHETYPES)) errors.push({ table: "SHOP_HABITS", row: archId, message: `Unknown archetype "${archId}"` });
    for (const sh of Object.keys(habit.shops)) {
      if (!(sh in SHOPS)) errors.push({ table: "SHOP_HABITS", row: archId, message: `Unknown shop "${sh}"` });
    }
  }

  // 10. FOLK (CENSUS, ARCHETYPES, ROUTINES, TRAITS, ROUTES, FOLK_INTERIORS)
  for (const [id, def] of Object.entries(ARCHETYPES)) {
    checked++;
    checkFontText(errors, "ARCHETYPES", id, def.title);
    for (const r of def.routines) if (!(r in ROUTINES)) errors.push({ table: "ARCHETYPES", row: id, message: `Unknown routine "${r}"` });
    for (const ln of def.lines) checkFontText(errors, "ARCHETYPES", `${id}.lines`, ln);
  }
  for (const [id, rt] of Object.entries(ROUTINES)) {
    checked++;
    if (!rt.blocks.length || rt.blocks[0].from !== 0) {
      errors.push({ table: "ROUTINES", row: id, message: "Routine must start at hour 0" });
    }
    for (let i = 1; i < rt.blocks.length; i++) {
      if (rt.blocks[i].from <= rt.blocks[i - 1].from) {
        errors.push({ table: "ROUTINES", row: id, message: `Non-increasing routine block at index ${i}` });
      }
    }
  }
  for (const [id, tr] of Object.entries(TRAITS)) {
    checked++;
    for (const ln of tr.lines ?? []) checkFontText(errors, "TRAITS", id, ln);
  }
  for (const [act, lines] of Object.entries(ACTIVITY_LINES)) {
    for (const ln of lines ?? []) { checked++; checkFontText(errors, "ACTIVITY_LINES", act, ln); }
  }
  for (const [k, fi] of Object.entries(FOLK_INTERIORS)) {
    checked++;
    if (!(fi.area in AREAS)) errors.push({ table: "FOLK_INTERIORS", row: k, message: `Unknown interior area "${fi.area}"` });
  }
  for (const row of CENSUS) {
    checked++;
    if (!(row.archetype in ARCHETYPES)) errors.push({ table: "CENSUS", row: row.id, message: `Unknown archetype "${row.archetype}"` });
    if (row.routine && !(row.routine in ROUTINES)) errors.push({ table: "CENSUS", row: row.id, message: `Unknown routine "${row.routine}"` });
    const area = getBuiltArea(row.area);
    if (!area) errors.push({ table: "CENSUS", row: row.id, message: `Unknown area "${row.area}"` });
    else if (!(area.spots ?? []).some((s) => s.id === row.home)) {
      errors.push({ table: "CENSUS", row: row.id, message: `Home spot "${row.home}" not found in "${row.area}"` });
    }
    if (row.route && !ROUTES[row.area]?.[row.route]) {
      errors.push({ table: "CENSUS", row: row.id, message: `Route "${row.route}" not found in ROUTES.${row.area}` });
    }
  }

  // 11. TALK EXCHANGES & POOLS
  for (const ex of EXCHANGES) {
    checked++;
    if (!ex.lines.length) errors.push({ table: "EXCHANGES", row: ex.id, message: "Empty exchange lines" });
    for (const ln of ex.lines) {
      if (ln[0] !== "a" && ln[0] !== "b") errors.push({ table: "EXCHANGES", row: ex.id, message: `Invalid speaker "${ln[0]}"` });
      checkFontText(errors, "EXCHANGES", ex.id, ln[1]);
    }
  }
  for (const ln of GRIPES) { checked++; checkFontText(errors, "GRIPES", ln.slice(0, 16), ln); }
  for (const ln of NEWS) { checked++; checkFontText(errors, "NEWS", ln.slice(0, 16), ln); }
  for (const [k, pool] of Object.entries(MUTTERS)) for (const ln of pool) { checked++; checkFontText(errors, "MUTTERS", k, ln); }
  for (const [k, pool] of Object.entries(REACTIONS)) for (const ln of pool) { checked++; checkFontText(errors, "REACTIONS", k, ln); }
  for (const [k, pool] of Object.entries(PEER_LINES)) for (const ln of pool) { checked++; checkFontText(errors, "PEER_LINES", k, ln); }

  // 12. RUNE_NODES & ENTRANCES
  for (const [id, node] of Object.entries(RUNE_NODES)) {
    checked++;
    if (!(node.area in AREAS)) errors.push({ table: "RUNE_NODES", row: id, message: `Unknown area "${node.area}"` });
  }
  for (const [id, ent] of Object.entries(ENTRANCES)) {
    checked++;
    if (!(ent.above.area in AREAS)) errors.push({ table: "ENTRANCES", row: id, message: `Unknown above area "${ent.above.area}"` });
    if (!(ent.below.area in AREAS)) errors.push({ table: "ENTRANCES", row: id, message: `Unknown below area "${ent.below.area}"` });
  }

  return { ok: errors.length === 0, checked, errors, warnings };
}
