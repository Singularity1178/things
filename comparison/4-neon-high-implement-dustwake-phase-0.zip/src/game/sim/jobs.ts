// Orders outlive their short, area-bound tasks. All continuation state is
// plain data on Actor.job, including a receipt written at a task's fire point.
import { JOB_KINDS } from "../content/jobs";
import { actorDef, capable } from "../content/actors";
import { HARVEST } from "../content/harvest";
import { ITEMS, type ItemId } from "../content/items";
import { CRAFT_RECIPES } from "../content/crafting";
import { RUNE_NODES } from "../content/runes";
import { propDef, propReach } from "../content/props";
import { actorById, areaOf, emit, getArea, type Actor, type World } from "../world/world";
import type { Destination, Job, JobOrder, Json, PropRef } from "../world/jobs";
import type { TaskSpec, Target } from "../content/tasks";
import { AREAS } from "../world/areas";
import { beginTask, faceTo } from "./tasks";
import { countItem, roomFor } from "./inventory";
import { powered } from "./actorStats";
import { findPath, lineOfSight, navGrid, walkTo } from "./navigation";
import { firstHops, meansOf, type Hop } from "./routes";
import { inPortal, portalById, portalStand, walkThrough } from "./portals";
import type { Area } from "../world/area";
import { craftEntry, craftLocked, orderCraft, outputFits } from "./crafting";
import { inventoryHandle, storageRef } from "./storage";
import { roomIn } from "./inventoryOps";
import { harvestStep } from "./harvesting";

export interface JobHandler {
  validate: (args: Record<string, Json>) => boolean;
  step: (w: World, a: Actor, job: Job, dt: number) => void;
}
const text = (x: Json | undefined): x is string => typeof x === "string" && x.length > 0;
const positive = (x: Json | undefined) => typeof x === "number" && Number.isSafeInteger(x) && x > 0;
const refOf = (x: Json | undefined): PropRef | null => x && typeof x === "object" && !Array.isArray(x) && text(x.area) && text(x.prop) ? { area: x.area, prop: x.prop } : null;
const validRef = (x: Json | undefined) => { const ref = refOf(x); return !!ref && !!AREAS[ref.area]; };
const quantity = (j: Job) => j.args.repeat === true ? Infinity : j.args.amount as number;
const stop = (a: Actor) => { a.vx = 0; a.vy = 0; a.moving = false; };

export function assignJob(w: World, a: Actor, order: JobOrder): boolean {
  const def = JOB_KINDS[order.kind], handler = JOB_HANDLERS[order.kind];
  if (!def || !handler || !handler.validate(order.args) || !def.capabilities.every((c) => capable(a, c))) return false;
  if (a.task && a.task.jobId === undefined) return false;
  cancelJob(w, a);
  a.job = {
    ...JSON.parse(JSON.stringify(order)), id: ++a.jobSeq, phase: def.phase, status: powered(a) ? "running" : "paused",
    completed: 0, waiting: false, transit: false, result: null, target: null, nav: null, retryAt: 0, failures: 0,
    reason: powered(a) ? null : "power",
  };
  emit(w, { t: "jobChanged", actor: a.id, status: a.job!.status });
  return true;
}

/**
 * Why a walk-up command on `targetId` is refused before the order itself is
 * looked at (a message for the management screen), or null if the commander can
 * reach it: a worker, in the commander's area, within reach, in clear sight.
 */
export function workerRefusal(w: World, commander: Actor, targetId: string): string | null {
  const target = actorById(w, targetId);
  if (!target || !capable(target, "worker")) return "THAT IS NOT A WORKER";
  if (target.area !== commander.area || Math.hypot(target.x - commander.x, target.y - commander.y) > actorDef(target).body.reach + 8) return "STEP UP TO THE WORKER";
  if (!lineOfSight(areaOf(w, commander), commander, target)) return "NO CLEAR LINE TO THE WORKER";
  return null;
}

/** What is wrong with the arguments of an order, in words (the handler's `validate` only says yes or no). */
function argumentRefusal(order: JobOrder): string {
  const p = order.args;
  if (order.kind === "gatherDeposit") {
    if (!text(p.resource) || !ITEMS[p.resource as ItemId]) return "NO SUCH RESOURCE";
    if (!text(p.fromArea) || !AREAS[p.fromArea]) return "NO SUCH SOURCE AREA";
    if (p.storage !== null && !validRef(p.storage)) return "NO SUCH STORAGE";
  } else if (order.kind === "craftAt") {
    if (!validRef(p.station)) return "NO SUCH STATION";
    if (!CRAFT_RECIPES.some((r) => r.id === p.recipe)) return "NO SUCH RECIPE";
  } else if (order.kind === "walk") return "THERE IS NOWHERE TO GO";
  return p.repeat === true || positive(p.amount) ? "THAT ORDER IS NOT VALID" : "THE AMOUNT IS NOT VALID";
}

/**
 * Why `setWorkerOrder` would refuse `order` for this commander and worker, in
 * the screen's words, or null if it would be accepted. Mirrors setWorkerOrder
 * and assignJob check for check, so the two never disagree (tested).
 */
export function orderRefusal(w: World, commander: Actor, targetId: string, order: JobOrder): string | null {
  const why = workerRefusal(w, commander, targetId);
  if (why) return why;
  const target = actorById(w, targetId)!, def = JOB_KINDS[order.kind], handler = JOB_HANDLERS[order.kind];
  if (!def || !handler) return "THAT KIND OF ORDER IS UNKNOWN";
  if (!handler.validate(order.args)) return argumentRefusal(order);
  if (!def.capabilities.every((c) => capable(target, c))) return "IT CANNOT DO THAT WORK";
  if (target.task && target.task.jobId === undefined) return "IT IS BUSY. TRY AGAIN IN A MOMENT";
  return null;
}

/** Walk-up management command (the management screen's only way to order a worker; see commands.ts: giveWorkerOrder). */
export function setWorkerOrder(w: World, commander: Actor, targetId: string, order: JobOrder | null): boolean {
  if (workerRefusal(w, commander, targetId)) return false;
  const target = actorById(w, targetId)!;
  if (order) return assignJob(w, target, order);
  cancelJob(w, target);
  return true;
}

export function cancelJob(w: World, a: Actor) {
  if (!a.job) return;
  if (a.task?.jobId === a.job.id) a.task = null;
  a.queue = a.queue.filter((t) => t.jobId !== a.job!.id);
  a.job = null; stop(a);
  emit(w, { t: "jobChanged", actor: a.id, status: "idle" });
}
export function pauseJob(w: World, a: Actor) {
  if (!a.job || a.job.status === "done") return;
  a.job.status = "paused"; a.job.reason = "manual"; stop(a);
  emit(w, { t: "jobChanged", actor: a.id, status: "paused" });
}
export function resumeJob(w: World, a: Actor) {
  if (!a.job || a.job.status === "done") return;
  a.job.status = powered(a) ? "running" : "paused";
  a.job.reason = powered(a) ? null : "power";
  a.job.failures = 0; a.job.retryAt = 0;
  emit(w, { t: "jobChanged", actor: a.id, status: a.job.status });
}

function block(w: World, a: Actor, reason: string) {
  const job = a.job!;
  job.status = "blocked"; job.reason = reason; job.failures++;
  job.retryAt = w.time + Math.min(8, 1 + job.failures); job.nav = null;
  stop(a);
  emit(w, { t: "jobChanged", actor: a.id, status: "blocked", reason });
}
function finish(w: World, a: Actor) {
  a.job!.status = "done"; a.job!.reason = null; a.job!.nav = null; stop(a);
  emit(w, { t: "jobChanged", actor: a.id, status: "done" });
}
function work(a: Actor, spec: TaskSpec, target: Target) {
  faceTo(a, target.x, target.y);
  beginTask(a, spec, target);
  a.task!.jobId = a.job!.id;
  a.job!.waiting = true; a.job!.result = null;
  stop(a);
}

/** A way out of the area a body stands in: where it walks to (and how near) to take a hop, and the rune it then channels. */
interface Way { hop: Hop; x: number; y: number; range: number; rune?: string }
function wayIn(area: Area, a: Actor, hop: Hop): Way | null {
  if (hop.via === "rune") {
    const p = area.prop(RUNE_NODES[hop.from].prop);
    return p ? { hop, x: p.x, y: p.y, range: 15, rune: p.id } : null;
  }
  // A portal is walked into: a place inside its box where this body can stand (sim/portals.ts).
  const p = portalById(area, hop.portal), at = p && portalStand(p, navGrid(area, a).free);
  return at ? { hop, x: at.x, y: at.y, range: 1 } : null;
}

/**
 * Walk to a local target, or set out for another area: by rune (walk up, channel, travel) or on foot through a
 * portal (a road, a door, the dug-out stair), whichever ways the route offers (sim/routes.ts). A body keeps to the
 * way it has set out on (its saved walk goal); choosing afresh, it takes the nearest one it can walk to.
 */
function approach(w: World, a: Actor, goal: Destination, dt: number): boolean {
  if (a.area !== goal.area) {
    const area = areaOf(w, a), hops = firstHops(w, meansOf(a), a.area, goal.area);
    if (!hops.length) { block(w, a, capable(a, "travel") ? "noRoute" : "noTravel"); return false; }
    const ways = hops.flatMap((h) => wayIn(area, a, h) ?? []);
    if (!ways.length) { block(w, a, hops[0].via === "rune" ? "missingRune" : "pathBlocked"); return false; }
    const heading = a.job!.nav?.goal;
    let way = ways.find((x) => `${a.area}:${x.x},${x.y}:${x.range}` === heading);
    if (!way) {
      const near = [...ways].sort((p, q) => Math.hypot(p.x - a.x, p.y - a.y) - Math.hypot(q.x - a.x, q.y - a.y));
      way = near.find((x) => findPath(w, a, x, false) !== null) ?? near[0];
    }
    const result = walkTo(w, a, { area: a.area, x: way.x, y: way.y, range: way.range }, dt);
    if (result === "stuck") block(w, a, "pathBlocked");
    if (result === "arrived") {
      if (way.hop.via === "rune" && way.rune) {
        beginTask(a, { kind: "channel", dur: 2.2, effect: { op: "travel", destination: way.hop.to } }, { kind: "rune", x: way.x, y: way.y, propId: way.rune });
        a.task!.jobId = a.job!.id;
        a.job!.transit = true; a.job!.result = null;
        stop(a);
      } else if (way.hop.via === "portal") {
        // Nothing is channelled: with its feet in the box it steps through, as the maintainer does by pushing on.
        const p = portalById(area, way.hop.portal);
        if (!p || !inPortal(p, a.x, a.y) || !walkThrough(w, a, area, p)) block(w, a, "arrivalBlocked");
        else stop(a);
      }
    }
    return false;
  }
  const result = walkTo(w, a, goal, dt);
  if (result === "stuck") block(w, a, "pathBlocked");
  return result === "arrived";
}

function gatherDeposit(w: World, a: Actor, j: Job, dt: number) {
  // `storage` null: it keeps what it gathers in its own pack. There is no deposit phase then, and the harvest
  // effect counts what each blow paid (sim/tasks.ts), so `completed` is what it gathered, not what it stored.
  const item = j.args.resource as ItemId, storage = refOf(j.args.storage);
  if (j.waiting) {
    const failed = j.result === false;
    j.waiting = false; j.result = null;
    if (failed && j.phase === "deposit") { block(w, a, "storageFull"); return; }
    if (failed) j.target = null;
  }
  if (j.completed >= quantity(j)) { finish(w, a); return; }
  const stock = countItem(a, item), remaining = quantity(j) - j.completed;
  const resource = j.target && w.areas.get(j.target.area)?.prop(j.target.prop);
  if (storage && stock > 0 && (stock >= remaining || roomFor(w, a, item) === 0 || resource?.taken)) { j.phase = "deposit"; j.target = null; }
  if (storage && j.phase === "deposit") {
    const area = getArea(w, storage.area), p = area.prop(storage.prop);
    if (!p?.inventory) { block(w, a, "missingStorage"); return; }
    if (!stock) { j.phase = "gather"; j.target = null; return; }
    if (!approach(w, a, { area: area.id, x: p.x, y: p.y, range: propReach(p.kind) + 2 }, dt)) return;
    const h = inventoryHandle(w, storageRef(area.id, p.id));
    if (!h || !roomIn(h.inventory, h.capacity, item)) { block(w, a, "storageFull"); return; }
    work(a, { kind: "reach", dur: 0.45, effect: { op: "deposit", item, n: Math.min(stock, remaining) } }, { kind: "storage", propId: p.id, x: p.x, y: p.y });
    return;
  }
  const source = getArea(w, j.args.fromArea as string);
  if (a.area !== source.id) { approach(w, a, { area: source.id, ...source.start, range: 1 }, dt); return; }
  if (!roomFor(w, a, item)) { block(w, a, "packFull"); return; }
  let p = j.target ? source.prop(j.target.prop) : undefined;
  if (!p || p.taken) {
    const candidates = source.props.filter((p) => !p.taken && (HARVEST[p.kind]?.perHit.item === item || HARVEST[p.kind]?.final?.item === item))
      .sort((p, q) => Math.hypot(p.x - a.x, p.y - a.y) - Math.hypot(q.x - a.x, q.y - a.y) || (p.id < q.id ? -1 : 1));
    p = candidates.find((p) => findPath(w, a, { x: p.x, y: p.y, range: propReach(p.kind) + 2 }, false) !== null);
    if (!p) {
      if (stock && storage) { j.phase = "deposit"; return; }
      block(w, a, "noResource"); return;
    }
    j.target = { area: source.id, prop: p.id };
  }
  if (!approach(w, a, { area: source.id, x: p.x, y: p.y, range: propReach(p.kind) + 2 }, dt)) return;
  const hit = harvestStep(a, p);
  if (!hit) { block(w, a, "cannotHarvest"); return; }
  if (hit.rewards.some((r) => roomFor(w, a, r.item) < r.n)) {
    if (stock && storage) { j.phase = "deposit"; j.target = null; }
    else block(w, a, "packFull");
    return;
  }
  work(a, { kind: "punch", dur: 0.75, effect: { op: "harvest" } }, { kind: "harvest", propId: p.id, x: p.x, y: p.y });
}

function craftAt(w: World, a: Actor, j: Job, dt: number) {
  if (j.waiting) {
    const ok = j.result;
    j.waiting = false; j.result = null;
    if (ok) j.completed++;
    else { block(w, a, "craftChanged"); return; }
  }
  if (j.completed >= quantity(j)) { finish(w, a); return; }
  const station = refOf(j.args.station)!, area = getArea(w, station.area), p = area.prop(station.prop);
  const recipe = CRAFT_RECIPES.find((r) => r.id === j.args.recipe);
  if (!p || !recipe || propDef(p.kind).station !== recipe.station) { block(w, a, "missingStation"); return; }
  if (!approach(w, a, { area: area.id, x: p.x, y: p.y, range: propReach(p.kind) + 2 }, dt)) return;
  const entry = craftEntry(w, a, recipe, p);
  if (craftLocked(w, a, recipe.station) || entry.status !== "ok") { block(w, a, entry.status === "ok" ? "unknown" : entry.status); return; }
  if (!outputFits(w, a, recipe)) { block(w, a, "packFull"); return; }
  if (!orderCraft(w, a, recipe.station, recipe.id, p.id)) { block(w, a, "craftChanged"); return; }
  a.task!.jobId = j.id; j.waiting = true; j.result = null; stop(a);
}

export const JOB_HANDLERS: Record<string, JobHandler> = {
  gatherDeposit: {
    validate: (p) => text(p.resource) && !!ITEMS[p.resource as ItemId] && text(p.fromArea) && !!AREAS[p.fromArea] && (p.storage === null || validRef(p.storage)) && (p.repeat === true || positive(p.amount)),
    step: gatherDeposit,
  },
  craftAt: {
    validate: (p) => validRef(p.station) && text(p.recipe) && CRAFT_RECIPES.some((r) => r.id === p.recipe) && (p.repeat === true || positive(p.amount)),
    step: craftAt,
  },
  walk: {
    validate: (p) => text(p.area) && !!AREAS[p.area] && typeof p.x === "number" && Number.isFinite(p.x) && typeof p.y === "number" && Number.isFinite(p.y),
    step: (w, a, j, dt) => {
      if (approach(w, a, { area: j.args.area as string, x: j.args.x as number, y: j.args.y as number, range: 1 }, dt)) finish(w, a);
    },
  },
};

export function tickJob(w: World, a: Actor, dt: number) {
  const job = a.job;
  if (!job || job.status === "done") { if (!a.task) stop(a); return; }
  if (!powered(a)) { if (job.reason !== "manual") { job.status = "paused"; job.reason = "power"; } stop(a); return; }
  if (job.status === "paused" && job.reason === "power") { job.status = "running"; job.reason = null; }
  if (job.status === "paused") return;
  if (job.status === "blocked") {
    // Bounded retries. Impossible corridors and missing resources settle into
    // an explicit, savable blocked order, not an infinite active-work loop.
    if (job.failures >= 3 || w.time < job.retryAt) return;
    job.status = "running"; job.reason = null; job.nav = null;
  }
  if (a.task || a.queue.length) return;
  if (job.transit) {
    job.transit = false;
    const ok = job.result; job.result = null;
    if (!ok) { block(w, a, "arrivalBlocked"); return; }
  }
  const handler = JOB_HANDLERS[job.kind];
  if (!handler) { block(w, a, "unknownJob"); return; }
  handler.step(w, a, job, dt);
}

/** `storage` null: the worker keeps what it gathers in its own pack (the order screen's INVENTORY), and the amount counts what it gathered. */
export const gatherOrder = (resource: ItemId, fromArea: string, storage: PropRef | null, amount: number, repeat = false): JobOrder => ({
  kind: "gatherDeposit", args: { resource, fromArea, storage: storage ? { ...storage } : null, amount, repeat },
});
export const craftOrder = (station: PropRef, recipe: string, amount: number, repeat = false): JobOrder => ({
  kind: "craftAt", args: { station: { ...station }, recipe, amount, repeat },
});
/** Stand at a spot: the order screen's "go to". The spot should be free (sim/orders.ts: walkOptions picks one). */
export const walkOrder = (area: string, x: number, y: number): JobOrder => ({ kind: "walk", args: { area, x, y } });
