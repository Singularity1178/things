// Camera, zoom easing and screen shake (extracted from game.ts in Phase 0.6).
import { TS } from "../content/tiles";
import { clamp, lerp } from "../util";
import { BASE_H, BASE_W, nextZoomStep, viewSize } from "./zoom";
import type { ViewRect } from "../sim/lod";

export class Camera {
  x = 0;
  y = 0;
  vw = BASE_W;
  vh = BASE_H;
  zoom = 1;
  zoomAnim: { from: number; to: number; t: number; dur: number } | null = null;
  shakeT = 0;
  shakeMag = 0;
  onResize: ((vw: number, vh: number) => void) | null = null;

  /** Snap camera to centre on (px, py) clamped inside area pixel bounds. */
  snap(px: number, py: number, areaW: number, areaH: number) {
    this.x = clamp(px - this.vw / 2, 0, Math.max(0, areaW * TS - this.vw));
    this.y = clamp(py - 12 - this.vh / 2, 0, Math.max(0, areaH * TS - this.vh));
  }

  /** Smoothly follow target (px, py) inside area pixel bounds. */
  follow(px: number, py: number, areaW: number, areaH: number, dt: number) {
    const tx = clamp(px - this.vw / 2, 0, Math.max(0, areaW * TS - this.vw));
    const ty = clamp(py - 12 - this.vh / 2, 0, Math.max(0, areaH * TS - this.vh));
    const k = Math.min(1, dt * 3.5);
    this.x += (tx - this.x) * k;
    this.y += (ty - this.y) * k;
  }

  shake(dur: number, mag: number) {
    this.shakeT = Math.max(this.shakeT, dur);
    this.shakeMag = Math.max(this.shakeMag, mag);
  }

  stepShake(dt: number) {
    this.shakeT = Math.max(0, this.shakeT - dt);
    if (this.shakeT <= 0) this.shakeMag = 0;
  }

  /** Current camera pixel origin with optional screen-shake offset (respects accessibility toggle). */
  renderOrigin(shakeEnabled: boolean): { camX: number; camY: number } {
    let sx = 0, sy = 0;
    if (shakeEnabled && this.shakeT > 0) {
      sx = (Math.random() - 0.5) * this.shakeMag * 2;
      sy = (Math.random() - 0.5) * this.shakeMag * 2;
    }
    return { camX: Math.round(this.x + sx), camY: Math.round(this.y + sy) };
  }

  /** Apply a zoom level immediately; notifies `onResize` if view dimensions changed. */
  setZoom(z: number, areaW?: number, areaH?: number): boolean {
    this.zoom = z;
    const { w, h } = viewSize(z);
    if (w === this.vw && h === this.vh) return false;
    this.x -= (w - this.vw) / 2;
    this.y -= (h - this.vh) / 2;
    this.vw = w;
    this.vh = h;
    if (areaW !== undefined && areaH !== undefined) {
      this.x = clamp(this.x, 0, Math.max(0, areaW * TS - w));
      this.y = clamp(this.y, 0, Math.max(0, areaH * TS - h));
    }
    this.onResize?.(w, h);
    return true;
  }

  zoomTo(z: number, dur: number) {
    if (z === this.zoom && !this.zoomAnim) return;
    this.zoomAnim = { from: this.zoom, to: z, t: 0, dur };
  }

  stepZoom(dt: number, areaW?: number, areaH?: number) {
    const a = this.zoomAnim;
    if (!a) return;
    a.t += dt;
    const k = clamp(a.t / a.dur, 0, 1);
    const e = k * k * (3 - 2 * k);
    this.setZoom(lerp(a.from, a.to, e), areaW, areaH);
    if (k >= 1) this.zoomAnim = null;
  }

  /** Step zoom from mouse wheel; returns `{ changed, zoomIn }`. */
  applyWheel(deltaY: number): { changed: boolean; zoomIn: boolean } {
    if (deltaY === 0) return { changed: false, zoomIn: false };
    const cur = this.zoomAnim?.to ?? this.zoom;
    const next = nextZoomStep(cur, deltaY);
    if (next === cur) return { changed: false, zoomIn: false };
    this.zoomTo(next, 0.25);
    return { changed: true, zoomIn: next < cur };
  }

  /** Current camera viewport in world coordinates (fed to sim/lod.ts). */
  viewRect(): ViewRect {
    return { x: this.x, y: this.y, w: this.vw, h: this.vh };
  }
}
