// Save System v2 (Phase 0.4): IndexedDB multi-slot persistence, rolling
// backups, autosave, file export/import, integrity checksums, and automatic
// corrupted-save recovery.
//
// In the browser, uses IndexedDB (`dustwake-saves-v2`) with graceful fallback
// to an in-memory / injected backend for headless tests.
import { deserialize, serialize, settle, validateSave, type SaveData } from "../world/save";
import { player, type World } from "../world/world";

export const DEFAULT_SLOTS = ["autosave", "slot-1", "slot-2", "slot-3"] as const;
export const MAX_BACKUPS = 3;

export interface SaveSlotMeta {
  id: string;
  name: string;
  savedAt: number;
  day: number;
  playTime: number;
  area: string;
  actors: number;
  version: number;
  sizeBytes: number;
  corrupted?: boolean;
  backupCount?: number;
}

export interface SaveEnvelope {
  id: string;
  name: string;
  savedAt: number;
  checksum: number;
  payload: string; // JSON-encoded SaveData
  meta: Omit<SaveSlotMeta, "corrupted" | "backupCount">;
}

export interface LoadSlotResult {
  world: World;
  meta: SaveSlotMeta;
  /** Non-empty when primary slot was corrupted and restored from a rolling backup. */
  recoveredFrom?: string;
  warning?: string;
}

/** Simple async key-value backend so IndexedDB and in-memory test stores share identical logic. */
export interface AsyncSaveBackend {
  get(key: string): Promise<string | null>;
  set(key: string, value: string): Promise<void>;
  del(key: string): Promise<void>;
  keys(): Promise<string[]>;
}

/** Fast deterministic FNV-1a 32-bit checksum for save integrity verification. */
export function checksumStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** In-memory backend (used by headless tests and as a fallback when IndexedDB is unavailable). */
export class MemorySaveBackend implements AsyncSaveBackend {
  readonly data = new Map<string, string>();
  async get(key: string) { return this.data.get(key) ?? null; }
  async set(key: string, value: string) { this.data.set(key, value); }
  async del(key: string) { this.data.delete(key); }
  async keys() { return [...this.data.keys()]; }
}

/** IndexedDB backend for browser persistence (`dustwake-saves-v2`). */
export class IndexedDbBackend implements AsyncSaveBackend {
  private dbPromise: Promise<IDBDatabase> | null = null;
  constructor(private dbName = "dustwake-saves-v2", private storeName = "saves") {}

  private open(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;
    this.dbPromise = new Promise((resolve, reject) => {
      if (typeof indexedDB === "undefined") {
        reject(new Error("IndexedDB not available"));
        return;
      }
      const req = indexedDB.open(this.dbName, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(this.storeName)) {
          db.createObjectStore(this.storeName);
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error ?? new Error("IndexedDB open failed"));
    });
    return this.dbPromise;
  }

  async get(key: string): Promise<string | null> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.storeName, "readonly");
      const req = tx.objectStore(this.storeName).get(key);
      req.onsuccess = () => resolve(typeof req.result === "string" ? req.result : null);
      req.onerror = () => reject(req.error);
    });
  }

  async set(key: string, value: string): Promise<void> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.storeName, "readwrite");
      tx.objectStore(this.storeName).put(value, key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async del(key: string): Promise<void> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.storeName, "readwrite");
      tx.objectStore(this.storeName).delete(key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async keys(): Promise<string[]> {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.storeName, "readonly");
      const req = tx.objectStore(this.storeName).getAllKeys();
      req.onsuccess = () => resolve((req.result as string[]).map(String));
      req.onerror = () => reject(req.error);
    });
  }
}

const slotKey = (id: string) => `slot:${id}`;
const backupKey = (id: string, n: number) => `bak:${id}:${n}`;

export class SaveStore {
  private backend: AsyncSaveBackend;
  private fallback = new MemorySaveBackend();
  private useFallback = false;

  constructor(backend?: AsyncSaveBackend) {
    this.backend = backend ?? (typeof indexedDB !== "undefined" ? new IndexedDbBackend() : this.fallback);
  }

  private async run<T>(fn: (b: AsyncSaveBackend) => Promise<T>): Promise<T> {
    if (this.useFallback) return fn(this.fallback);
    try {
      return await fn(this.backend);
    } catch {
      this.useFallback = true;
      return fn(this.fallback);
    }
  }

  /** Save `world` into slot `id`, rotating up to `MAX_BACKUPS` rolling backups of the previous save. */
  async saveSlot(id: string, world: World, name?: string): Promise<SaveSlotMeta> {
    const saveData = serialize(world);
    const payload = JSON.stringify(saveData);
    const pl = player(world);
    const savedAt = Date.now();
    const label = name ?? (id === "autosave" ? "Autosave" : id.replace(/^slot-/, "Slot "));
    const meta: Omit<SaveSlotMeta, "corrupted" | "backupCount"> = {
      id,
      name: label,
      savedAt,
      day: Math.floor(world.day) + 1,
      playTime: world.playTime,
      area: pl?.area ?? "dungeon",
      actors: world.actors.length,
      version: saveData.version,
      sizeBytes: payload.length,
    };
    const env: SaveEnvelope = {
      id,
      name: label,
      savedAt,
      checksum: checksumStr(payload),
      payload,
      meta,
    };

    // Rotate existing backups: bak(N-1) -> bak(N), current -> bak(1)
    const existing = await this.run((b) => b.get(slotKey(id)));
    if (existing) {
      for (let i = MAX_BACKUPS; i >= 2; i--) {
        const prev = await this.run((b) => b.get(backupKey(id, i - 1)));
        if (prev) await this.run((b) => b.set(backupKey(id, i), prev));
      }
      await this.run((b) => b.set(backupKey(id, 1), existing));
    }

    await this.run((b) => b.set(slotKey(id), JSON.stringify(env)));
    const backups = await this.countBackups(id);
    return { ...meta, backupCount: backups };
  }

  /** Parse and verify a raw stored envelope string, returning the settled World + meta or null on corruption. */
  private parseEnvelope(raw: string): { world: World; meta: SaveSlotMeta; save: SaveData } | null {
    try {
      const env = JSON.parse(raw) as Partial<SaveEnvelope>;
      if (!env || typeof env.payload !== "string" || typeof env.checksum !== "number") return null;
      if (checksumStr(env.payload) !== env.checksum) return null;
      const parsed: unknown = JSON.parse(env.payload);
      const valid = validateSave(parsed);
      if (!valid.ok) return null;
      const world = settle(deserialize(parsed));
      const meta: SaveSlotMeta = {
        ...(env.meta ?? {
          id: env.id ?? "unknown",
          name: env.name ?? "Save",
          savedAt: env.savedAt ?? 0,
          day: Math.floor(world.day) + 1,
          playTime: world.playTime,
          area: player(world)?.area ?? "dungeon",
          actors: world.actors.length,
          version: valid.data.version,
          sizeBytes: env.payload.length,
        }),
      };
      return { world, meta, save: valid.data };
    } catch {
      return null;
    }
  }

  /**
   * Load slot `id`. If the primary entry is corrupted (bad JSON, checksum mismatch,
   * or invalid save schema), automatically recovers from the newest valid rolling backup.
   */
  async loadSlot(id: string): Promise<LoadSlotResult | null> {
    const primary = await this.run((b) => b.get(slotKey(id)));
    if (primary) {
      const ok = this.parseEnvelope(primary);
      if (ok) {
        ok.meta.backupCount = await this.countBackups(id);
        return { world: ok.world, meta: ok.meta };
      }
    }
    // Primary missing or corrupted -> try rolling backups newest to oldest
    for (let i = 1; i <= MAX_BACKUPS; i++) {
      const bak = await this.run((b) => b.get(backupKey(id, i)));
      if (!bak) continue;
      const ok = this.parseEnvelope(bak);
      if (ok) {
        // Restore primary from healthy backup so subsequent loads succeed cleanly
        await this.run((b) => b.set(slotKey(id), bak));
        ok.meta.backupCount = await this.countBackups(id);
        return {
          world: ok.world,
          meta: ok.meta,
          recoveredFrom: `backup #${i}`,
          warning: `Slot "${id}" was corrupted and recovered from rolling backup #${i}.`,
        };
      }
    }
    if (primary) {
      throw new Error(`Save slot "${id}" is corrupted and no valid backup could be recovered.`);
    }
    return null;
  }

  /** Intentionally corrupt a slot's primary entry (for testing recovery paths). */
  async corruptSlotForTest(id: string, garbage = "{corrupted_save_data!!!"): Promise<void> {
    await this.run((b) => b.set(slotKey(id), garbage));
  }

  async deleteSlot(id: string): Promise<void> {
    await this.run((b) => b.del(slotKey(id)));
    for (let i = 1; i <= MAX_BACKUPS; i++) {
      await this.run((b) => b.del(backupKey(id, i)));
    }
  }

  async countBackups(id: string): Promise<number> {
    let n = 0;
    for (let i = 1; i <= MAX_BACKUPS; i++) {
      if (await this.run((b) => b.get(backupKey(id, i)))) n++;
    }
    return n;
  }

  /** List metadata for all stored slots (newest first). */
  async listSlots(): Promise<SaveSlotMeta[]> {
    const allKeys = await this.run((b) => b.keys());
    const slotIds = new Set<string>();
    for (const k of allKeys) {
      if (k.startsWith("slot:")) slotIds.add(k.slice(5));
    }
    const list: SaveSlotMeta[] = [];
    for (const id of slotIds) {
      const raw = await this.run((b) => b.get(slotKey(id)));
      const backups = await this.countBackups(id);
      if (!raw) continue;
      try {
        const env = JSON.parse(raw) as Partial<SaveEnvelope>;
        const validChecksum = typeof env.payload === "string" && typeof env.checksum === "number" && checksumStr(env.payload) === env.checksum;
        if (env.meta && validChecksum) {
          list.push({ ...env.meta, corrupted: false, backupCount: backups });
        } else {
          list.push({
            id, name: env.name ?? id, savedAt: env.savedAt ?? 0, day: 0, playTime: 0,
            area: "unknown", actors: 0, version: 0, sizeBytes: raw.length, corrupted: true, backupCount: backups,
          });
        }
      } catch {
        list.push({
          id, name: id, savedAt: 0, day: 0, playTime: 0,
          area: "unknown", actors: 0, version: 0, sizeBytes: raw.length, corrupted: true, backupCount: backups,
        });
      }
    }
    return list.sort((a, b) => b.savedAt - a.savedAt);
  }

  /** Export a slot (or live world) as a portable JSON string. */
  async exportSlotJson(id: string): Promise<string | null> {
    const res = await this.loadSlot(id);
    if (!res) return null;
    return JSON.stringify(serialize(res.world), null, 2);
  }

  /** Import a JSON string into slot `id`, validating and migrating through SAVE_VERSION. */
  async importSlotJson(id: string, jsonText: string, name?: string): Promise<LoadSlotResult> {
    const parsed: unknown = JSON.parse(jsonText);
    const valid = validateSave(parsed);
    if (!valid.ok) throw new Error(`Invalid save file: ${valid.error}`);
    const world = settle(deserialize(parsed));
    const meta = await this.saveSlot(id, world, name ?? `Imported (${id})`);
    return { world, meta };
  }

  /** Migrate legacy localStorage `"dustwake.save"` into `slot-1` if not already present. */
  async migrateLegacyLocalStorage(): Promise<boolean> {
    if (typeof localStorage === "undefined") return false;
    const legacy = localStorage.getItem("dustwake.save");
    if (!legacy) return false;
    const existing = await this.run((b) => b.get(slotKey("slot-1")));
    if (existing) return false;
    try {
      await this.importSlotJson("slot-1", legacy, "Migrated Legacy Save");
      return true;
    } catch {
      return false;
    }
  }
}

/** Shared browser save store singleton. */
export const saveStore = new SaveStore();

/** Trigger a browser file download for an exported save JSON. */
export function downloadSaveFile(filename: string, jsonText: string) {
  if (typeof document === "undefined" || typeof Blob === "undefined" || typeof URL === "undefined") return;
  const blob = new Blob([jsonText], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
