// Particle system (extracted from game.ts in Phase 0.6).
// Presentation-only transient visual effects (sparks, embers, dust, debris,
// drips, splashes, rune motes, fireflies, smoke, glints).
import { clamp } from "../util";
import type { Actor } from "../world/world";
import { actorDef } from "../content/actors";

export interface Particle {
  x: number; y: number; z: number;
  vx: number; vy: number; vz: number;
  life: number; max: number;
  kind: "spark" | "ember" | "dust" | "debris" | "drip" | "splash" | "rune" | "mote" | "glint" | "smoke";
  col: string;
  emit: boolean;
  g: number;
  size: number;
}

export class ParticleSystem {
  list: Particle[] = [];

  spawn(p: Partial<Particle> & { x: number; y: number }) {
    if (this.list.length > 900) return;
    this.list.push({
      z: 0, vx: 0, vy: 0, vz: 0, life: 1, max: p.life ?? 1,
      kind: "dust", col: "#888", emit: false, g: 0, size: 1,
      ...p,
    } as Particle);
  }

  clear() {
    this.list.length = 0;
  }

  update(dt: number, onDrip?: (x: number, y: number) => void) {
    const ps = this.list;
    for (let i = ps.length - 1; i >= 0; i--) {
      const p = ps[i];
      p.life -= dt / p.max;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vz -= p.g * dt;
      p.z += p.vz * dt;
      if (p.kind === "debris" || p.kind === "spark" || p.kind === "dust") {
        if (p.z < 0) { p.z = 0; p.vz = -p.vz * 0.35; p.vx *= 0.6; p.vy *= 0.6; }
      }
      if (p.kind === "drip" && p.z <= 0) {
        for (let k = 0; k < 5; k++) {
          this.spawn({ x: p.x, y: p.y, z: 0, vx: (Math.random() - 0.5) * 20, vy: (Math.random() - 0.5) * 8, vz: 12 + Math.random() * 8, life: 0.35, kind: "splash", col: "#7a9ab8", g: 80 });
        }
        onDrip?.(p.x, p.y);
        p.life = 0;
      }
      if (p.kind === "mote") {
        p.vx += (Math.random() - 0.5) * dt * 4;
        p.vz += (Math.random() - 0.5) * dt * 4;
      }
      if (p.kind === "smoke") {
        p.vx *= 0.97;
        p.vy *= 0.97;
      }
      if (p.life <= 0) ps.splice(i, 1);
    }
  }

  // ---- reusable effect bursts
  sparkBurst(pl: Actor, dormant: number, n: number) {
    const right = pl.facing === "down" || pl.facing === "left";
    const sx = pl.x + (pl.facing === "up" ? -8 : pl.facing === "down" ? 8 : right ? -1 : 1);
    const sy = pl.y - 9 + Math.round(dormant * 4);
    for (let i = 0; i < n; i++) {
      this.spawn({
        x: sx, y: sy + 9, z: 9,
        vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.3) * 20, vz: 10 + Math.random() * 30,
        life: 0.3 + Math.random() * 0.4, kind: "spark", col: Math.random() < 0.5 ? "#fff2a0" : "#ffb040", emit: true, g: 120,
      });
    }
  }

  coreSparks(a: Actor, n: number, bright: boolean) {
    const z = actorDef(a).body.height * 0.55;
    for (let i = 0; i < n; i++) {
      this.spawn({
        x: a.x + (Math.random() - 0.5) * 4, y: a.y + 1, z: z + Math.random() * 3,
        vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.2) * 16, vz: 8 + Math.random() * 24,
        life: 0.3 + Math.random() * 0.4, kind: "spark",
        col: bright ? (Math.random() < 0.5 ? "#ff5a70" : "#ffc0c8") : "#8a3040", emit: true, g: 110,
      });
    }
  }

  npcSparks(a: Actor, n: number) {
    for (let i = 0; i < n; i++) {
      this.spawn({
        x: a.x + (Math.random() - 0.5) * 16, y: a.y - 2, z: 18 + Math.random() * 14,
        vx: (Math.random() - 0.5) * 50, vy: (Math.random() - 0.5) * 20, vz: 10 + Math.random() * 30,
        life: 0.3 + Math.random() * 0.4, kind: "spark", col: Math.random() < 0.5 ? "#fff2a0" : "#7fe8ff", emit: true, g: 120,
      });
    }
  }

  npcDust(a: Actor) {
    for (let i = 0; i < 12; i++) {
      this.spawn({ x: a.x + (Math.random() - 0.5) * 26, y: a.y, z: 2 + Math.random() * 6, vx: (Math.random() - 0.5) * 24, vz: 6 + Math.random() * 8, life: 1, kind: "dust", col: "#8a8478", g: 14 });
    }
  }

  witherClump(x: number, y: number, size: number) {
    const cols = ["#3e5e2a", "#527636", "#6e8e34", "#7a6a3a", "#5a4630"];
    for (let i = 0; i < 1 + Math.min(4, size / 6); i++) {
      this.spawn({ x: x + (Math.random() - 0.5) * 6, y: y + (Math.random() - 0.5) * 4, z: 1, vx: 10 + Math.random() * 22, vy: (Math.random() - 0.5) * 10, vz: 12 + Math.random() * 18, life: 0.7 + Math.random() * 0.7, kind: "debris", col: cols[(Math.random() * cols.length) | 0], g: 26 });
    }
    if (Math.random() < 0.6) {
      this.spawn({ x, y, z: 1, vz: 10 + Math.random() * 8, life: 0.8, kind: "rune", col: "#c0a0ff", emit: true, g: -3 });
    }
  }

  runeBurst(x: number, y: number) {
    for (let i = 0; i < 26; i++) {
      const ang = Math.random() * Math.PI * 2, sp = 14 + Math.random() * 30;
      this.spawn({ x, y, z: 2 + Math.random() * 10, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp * 0.5, vz: 10 + Math.random() * 30, life: 0.7, kind: "rune", col: Math.random() < 0.4 ? "#ffffff" : Math.random() < 0.5 ? "#c0a0ff" : "#80e0ff", emit: true, g: 10 });
    }
  }

  /** Draw floating/emissive particles (non-ground-sorted) onto scene & emit canvases. */
  renderFloating(sc: CanvasRenderingContext2D, ec: CanvasRenderingContext2D, camX: number, camY: number, vw: number, vh: number) {
    for (const p of this.list) {
      if (p.kind === "debris" || p.kind === "dust" || p.kind === "smoke" || p.kind === "splash") continue;
      const x = Math.round(p.x - camX), y = Math.round(p.y - p.z - camY);
      if (x < -2 || y < -2 || x > vw + 2 || y > vh + 2) continue;
      if (p.kind === "glint") {
        const a = Math.sin(clamp(p.life, 0, 1) * Math.PI);
        ec.globalCompositeOperation = "lighter";
        ec.fillStyle = `rgba(255,240,200,${a})`;
        ec.fillRect(x, y, 1, 1);
        if (a > 0.5) {
          ec.fillStyle = `rgba(255,240,200,${a * 0.5})`;
          ec.fillRect(x - 1, y, 3, 1);
          ec.fillRect(x, y - 1, 1, 3);
        }
        ec.globalCompositeOperation = "source-over";
        continue;
      }
      if (p.emit) {
        ec.globalCompositeOperation = "lighter";
        ec.globalAlpha = clamp(p.life * 1.5, 0, 1);
        ec.fillStyle = p.col; ec.fillRect(x, y, p.size, p.size);
        ec.globalAlpha = 1;
        ec.globalCompositeOperation = "source-over";
      } else if (p.kind === "mote") {
        sc.fillStyle = p.col; sc.fillRect(x, y, 1, 1);
      } else {
        sc.fillStyle = p.col; sc.fillRect(x, y, p.size, p.size);
      }
    }
  }
}
