// Phase 0 Management UI Shell (2x Hi-Res UI Layer, 640x360):
// - Top management bar with Area/Depth, Day/Clock, LOD counts, Speed controls
//   (Pause / 1x / 2x / 4x / 8x), Performance sparkline toggle, and quick buttons
//   for Floors, Saves, Alerts, and Settings.
// - Live Notification Feed toasts + expandable Alert Drawer with Pause-on-Alert toggles.
// - Mouse world interaction: hover tooltips on actors/props/items, drag-select box
//   with multi-actor selection inspector, and right-click context menu.
import { GAME_SPEEDS, type GameSpeed, type SimClock } from "../sim/clock";
import { clockText, phaseAt } from "../content/daycycle";
import { worldHour } from "../sim/daytime";
import { folkLabel, folkPresent, isFolk } from "../sim/folk";
import { keeperLabel, keeperPresent } from "../sim/shops";
import { ITEM_NAMES } from "../content/items";
import { actorDef } from "../content/actors";
import { currentArea, player, type Actor, type World } from "../world/world";
import type { SettingsStore } from "../settings";
import type { InputManager } from "../ui/input";
import { UI2_H, UI2_W } from "../ui/input";
import {
  ContextMenu,
  hiButton,
  hiFrame,
  hiGraph,
  hiScrollList,
  hiToggle,
  hitRect,
  semanticColor,
  TooltipHost,
  UI2,
  type ContextMenuItem,
  type Rect,
  type ScrollListState,
} from "../ui/components";
import { clipPropText, drawPropText, drawPropTextS, propTextWidth } from "../ui/propFont";
import type { NotificationFeed, NotificationItem } from "../ui/notifications";

export interface HudActions {
  setSpeed(s: GameSpeed): void;
  openFloors(): void;
  openSaves(): void;
  openSettings(): void;
  quickSave(): void;
  openManage(actorId: string): void;
  focusCameraOn(areaId: string, x: number, y: number): void;
  createQuickFloor(): void;
}

export class ManagementHud {
  readonly tips = new TooltipHost();
  readonly contextMenu = new ContextMenu();
  readonly selectedActors = new Set<string>();
  showPerf = false;
  readonly tickSamples: number[] = [];
  private alertScroll: ScrollListState = { scroll: 0, selected: -1 };

  recordTickMs(ms: number) {
    this.tickSamples.push(ms);
    if (this.tickSamples.length > 90) this.tickSamples.shift();
  }

  /** Find an actor near world position (wx, wy) in the player's current area. */
  pickActorAt(w: World, wx: number, wy: number): Actor | null {
    const areaId = currentArea(w).id;
    let best: Actor | null = null;
    let bestD = 16;
    for (const a of w.actors) {
      if (a.area !== areaId) continue;
      if (a.kind === "folk" && !folkPresent(a)) continue;
      if (a.kind === "keeper" && !keeperPresent(a)) continue;
      const d = Math.hypot(a.x - wx, a.y - 8 - wy);
      if (d < bestD) { bestD = d; best = a; }
    }
    return best;
  }

  /** Render & process the management HUD, tooltips, drag-select, context menu, and alert drawer. */
  updateAndRender(
    ctx: CanvasRenderingContext2D,
    input: InputManager,
    world: World,
    clock: SimClock,
    feed: NotificationFeed,
    settings: SettingsStore,
    hitKey: (...k: string[]) => boolean,
    actions: HudActions,
    isPlayScreen: boolean
  ) {
    this.tips.clear();
    const ptr = input.pointer;
    const s = settings.data;
    const pal = s.colorBlindPalette;
    const area = currentArea(world);

    // 1. Top Management Bar (play screen only when enabled)
    if (isPlayScreen && s.showHudBar) {
      const barH = 22;
      hiFrame(ctx, 0, 0, UI2_W, barH, "#110f16", "#2f2a38", "#474055");
      if (ptr.inside && hitRect({ x: 0, y: 0, w: UI2_W, h: barH }, ptr.x, ptr.y)) {
        // Reserve top bar clicks from world drag-select
        if (ptr.clicked || ptr.down) {
          /* buttons below consume clicks; keep bar hover distinct from world */
        }
      }

      // Left cluster: Area badge + Day/Clock + Resident count
      const areaLabel = area.spec?.label ?? area.id.replace(/_/g, " ");
      const depthStr = area.spec ? ` D${area.spec.depth}` : "";
      drawPropTextS(ctx, clipPropText(`${areaLabel}${depthStr}`, 110), 7, 7, UI2.title);

      const hour = worldHour(world);
      const dayNum = Math.floor(world.day) + 1;
      const phase = phaseAt(hour);
      const clockStr = `Day ${dayNum} ${clockText(hour)} (${phase})`;
      drawPropText(ctx, clockStr, 118, 7, UI2.mid);

      const lod = world.lod?.counts;
      const popStr = lod ? `${world.actors.length} actors (${lod.active}A/${lod.near}N/${lod.far}F)` : `${world.actors.length} actors`;
      const perfR: Rect = { x: 222, y: 3, w: 112, h: 16 };
      if (hiButton(ctx, perfR, popStr, ptr, {
        active: this.showPerf,
        tooltip: { title: "Simulation LOD & Perf", body: "Active (in view), Near (same area), Far (abstract). Click for frame-time graph." },
      }, this.tips)) {
        this.showPerf = !this.showPerf;
      }

      // Center cluster: Fixed-Timestep Speed Controls (Pause / 1x / 2x / 4x / 8x)
      let sx = 342;
      for (const sp of GAME_SPEEDS) {
        const lbl = sp === 0 ? "||" : `${sp}x`;
        const w = sp === 0 ? 18 : 20;
        const active = clock.speed === sp;
        const accent = sp === 0 ? semanticColor("warn", pal) : sp >= 4 ? semanticColor("info", pal) : semanticColor("ok", pal);
        if (hiButton(ctx, { x: sx, y: 3, w, h: 16 }, lbl, ptr, {
          active,
          accent,
          tooltip: { title: sp === 0 ? "Pause Simulation" : `Run at ${sp}x Speed`, body: "Deterministic fixed-timestep ticks.", shortcut: sp === 0 ? "P" : undefined },
        }, this.tips)) {
          actions.setSpeed(sp);
        }
        sx += w + 2;
      }

      // Right cluster: Floors / Saves / Alerts / Settings
      if (hiButton(ctx, { x: 458, y: 3, w: 42, h: 16 }, "Floors", ptr, {
        tooltip: { title: "Areas & Floors", body: "Inspect or generate dynamic AreaSpec floors.", shortcut: "F" },
      }, this.tips)) {
        actions.openFloors();
      }
      if (hiButton(ctx, { x: 502, y: 3, w: 40, h: 16 }, "Saves", ptr, {
        tooltip: { title: "Save Slots (v2)", body: "IndexedDB slots, autosave, export/import.", shortcut: "K/L" },
      }, this.tips)) {
        actions.openSaves();
      }
      const unread = feed.unreadCount();
      if (hiButton(ctx, { x: 544, y: 3, w: 44, h: 16 }, "Alerts", ptr, {
        active: feed.drawerOpen,
        badge: unread > 0 ? String(Math.min(99, unread)) : undefined,
        accent: unread > 0 ? semanticColor("alert", pal) : undefined,
        tooltip: { title: "Notification Feed", body: "View alerts & pause-on-alert options.", shortcut: "N" },
      }, this.tips)) {
        feed.drawerOpen = !feed.drawerOpen;
        if (feed.drawerOpen) feed.markAllRead();
      }
      if (hiButton(ctx, { x: 590, y: 3, w: 46, h: 16 }, "Options", ptr, {
        tooltip: { title: "Settings & Accessibility", body: "Audio, color-blind palettes, keybinds.", shortcut: "O" },
      }, this.tips)) {
        actions.openSettings();
      }

      // Prevent clicks inside bar from bleeding to world
      if (ptr.inside && ptr.y < barH) {
        if (ptr.clicked || ptr.rightClicked) ptr.consumed = true;
      }
    }

    // 2. Optional Performance & LOD Sparkline Graph
    if (isPlayScreen && this.showPerf) {
      const gr: Rect = { x: 222, y: 26, w: 150, h: 46 };
      hiGraph(ctx, gr, this.tickSamples, {
        label: "Sim Step",
        unit: "ms",
        min: 0,
        max: 16.6,
        warnLine: 10,
        accent: semanticColor("info", pal),
      });
    }

    // 3. Paused banner indicator
    if (isPlayScreen && clock.paused) {
      const pw = 104, px = Math.round((UI2_W - pw) / 2);
      hiFrame(ctx, px, 26, pw, 16, "#1f1814", semanticColor("warn", pal), "#ffe09a");
      drawPropTextS(ctx, "PAUSED  (P)", px + pw / 2, 30, semanticColor("warn", pal), 1, "center");
    }

    // 4. Notification Feed Drawer OR Live Toasts (upper right)
    if (isPlayScreen) {
      if (feed.drawerOpen) {
        this.renderAlertDrawer(ctx, input, feed, settings, actions, pal);
      } else {
        this.renderToasts(ctx, input, feed, actions, pal);
      }
    }

    // 5. Right-click Context Menu
    this.contextMenu.updateAndRender(ctx, ptr, hitKey);

    // 6. World Mouse Interactions (Play screen only, when not consumed by HUD/modals)
    if (isPlayScreen && !ptr.consumed && ptr.inside && (!s.showHudBar || ptr.y >= 22)) {
      // Live drag-select rectangle
      if (ptr.drag) {
        const d = ptr.drag;
        const x0 = Math.round(Math.min(d.startX, d.curX));
        const y0 = Math.round(Math.min(d.startY, d.curY));
        const rw = Math.round(Math.abs(d.curX - d.startX));
        const rh = Math.round(Math.abs(d.curY - d.startY));
        const col = semanticColor("info", pal);
        ctx.fillStyle = col;
        ctx.globalAlpha = 0.14;
        ctx.fillRect(x0, y0, rw, rh);
        ctx.globalAlpha = 0.9;
        ctx.fillRect(x0, y0, rw, 1);
        ctx.fillRect(x0, y0 + rh - 1, rw, 1);
        ctx.fillRect(x0, y0, 1, rh);
        ctx.fillRect(x0 + rw - 1, y0, 1, rh);
        ctx.globalAlpha = 1;
      }

      // Finished drag-select: pick all actors in the world bounding box
      if (ptr.dragFinished) {
        const b = ptr.dragFinished;
        this.selectedActors.clear();
        for (const a of world.actors) {
          if (a.area !== area.id) continue;
          if (a.kind === "folk" && !folkPresent(a)) continue;
          if (a.x >= b.wx0 && a.x <= b.wx1 && a.y >= b.wy0 && a.y <= b.wy1) {
            this.selectedActors.add(a.id);
          }
        }
      }

      // Single click in world: select hovered actor or clear selection
      if (ptr.clicked) {
        const picked = this.pickActorAt(world, ptr.wx, ptr.wy);
        this.selectedActors.clear();
        if (picked) this.selectedActors.add(picked.id);
      }

      // Right-click in world: open context menu
      if (ptr.rightClicked) {
        const picked = this.pickActorAt(world, ptr.wx, ptr.wy);
        const items: ContextMenuItem[] = [];
        if (picked) {
          items.push({
            id: "select",
            label: `Select ${actorDisplayName(picked)}`,
            action: () => { this.selectedActors.clear(); this.selectedActors.add(picked.id); },
          });
          if (picked.kind !== "folk" && picked.kind !== "keeper" && picked.id !== world.playerId) {
            items.push({
              id: "manage",
              label: "Manage Worker",
              shortcut: "E",
              action: () => actions.openManage(picked.id),
            });
          }
        }
        items.push(
          { id: "speed", label: clock.paused ? "Resume Simulation" : "Pause Simulation", shortcut: "P", action: () => actions.setSpeed(clock.paused ? 1 : 0) },
          { id: "floor", label: "Generate Test Floor", shortcut: "F", action: () => actions.createQuickFloor() },
          { id: "save", label: "Quick Save", shortcut: "K", action: () => actions.quickSave() },
          { id: "settings", label: "Settings & Accessibility", shortcut: "O", action: () => actions.openSettings() }
        );
        this.contextMenu.show(ptr.x, ptr.y, items, picked ? actorDisplayName(picked) : area.spec?.label ?? area.id);
      }

      // World hover tooltip (actors, loose items, props)
      if (!this.contextMenu.open && !ptr.drag) {
        this.inspectWorldHover(world, ptr.wx, ptr.wy, ptr.x, ptr.y, pal);
      }
    }

    // 7. Selection Inspector Card (bottom-left when >= 1 actor selected)
    if (isPlayScreen && this.selectedActors.size > 0) {
      this.renderSelectionCard(ctx, input, world, actions, pal);
    }

    // 8. Tooltip always renders last (topmost)
    this.tips.render(ctx);
  }

  private renderToasts(ctx: CanvasRenderingContext2D, input: InputManager, feed: NotificationFeed, actions: HudActions, pal: SettingsStore["data"]["colorBlindPalette"]) {
    const ptr = input.pointer;
    const toasts = feed.liveToasts(4);
    let ty = 28;
    for (const it of toasts) {
      const w = 196, h = it.detail ? 26 : 16;
      const x = UI2_W - w - 6;
      const col = semanticColor(it.severity === "success" ? "ok" : it.severity, pal);
      ctx.globalAlpha = feed.toastAlpha(it);
      hiFrame(ctx, x, ty, w, h, "#14111a", col, col);
      ctx.fillStyle = col;
      ctx.fillRect(x + 1, ty + 1, 3, h - 2);
      drawPropTextS(ctx, clipPropText(it.title, w - 26), x + 8, ty + 4, UI2.title);
      if (it.detail) drawPropText(ctx, clipPropText(it.detail, w - 16), x + 8, ty + 14, UI2.mid);
      ctx.globalAlpha = 1;

      const r: Rect = { x, y: ty, w, h };
      if (ptr.inside && !ptr.consumed && hitRect(r, ptr.x, ptr.y) && ptr.clicked) {
        ptr.consumed = true;
        feed.dismiss(it.id);
        if (it.area && it.x !== undefined && it.y !== undefined) {
          actions.focusCameraOn(it.area, it.x, it.y);
        }
      }
      ty += h + 4;
    }
  }

  private renderAlertDrawer(
    ctx: CanvasRenderingContext2D,
    input: InputManager,
    feed: NotificationFeed,
    settings: SettingsStore,
    actions: HudActions,
    pal: SettingsStore["data"]["colorBlindPalette"]
  ) {
    const ptr = input.pointer;
    const s = settings.data;
    const r: Rect = { x: UI2_W - 238, y: 26, w: 232, h: 224 };
    hiFrame(ctx, r.x, r.y, r.w, r.h, UI2.bgPanel, UI2.borderHi);
    drawPropTextS(ctx, "Notification Feed", r.x + 8, r.y + 6, UI2.title);
    if (hiButton(ctx, { x: r.x + r.w - 58, y: r.y + 4, w: 36, h: 13 }, "Clear", ptr)) feed.clear();
    if (hiButton(ctx, { x: r.x + r.w - 19, y: r.y + 4, w: 14, h: 13 }, "x", ptr)) feed.drawerOpen = false;

    // Pause-on-alert quick toggles
    const py = r.y + 21;
    drawPropText(ctx, "Pause on Alert:", r.x + 8, py + 3, UI2.mid);
    if (hiToggle(ctx, { x: r.x + 76, y: py, w: 32, h: 14 }, s.pauseOnAlert, ptr, semanticColor("alert", pal))) {
      s.pauseOnAlert = !s.pauseOnAlert; settings.save();
    }
    drawPropText(ctx, "Worker:", r.x + 120, py + 3, UI2.mid);
    if (hiToggle(ctx, { x: r.x + 158, y: py, w: 32, h: 14 }, s.pauseOnJobBlocked, ptr, semanticColor("warn", pal))) {
      s.pauseOnJobBlocked = !s.pauseOnJobBlocked; settings.save();
    }

    const listR: Rect = { x: r.x + 6, y: r.y + 39, w: r.w - 12, h: r.h - 46 };
    const res = hiScrollList<NotificationItem>(ctx, listR, feed.items, 24, this.alertScroll, input, (c, it, _i, rr) => {
      const col = semanticColor(it.severity === "success" ? "ok" : it.severity, pal);
      c.fillStyle = col;
      c.fillRect(rr.x + 2, rr.y + 2, 2, rr.h - 4);
      drawPropText(c, clipPropText(it.title, rr.w - 16), rr.x + 7, rr.y + 3, UI2.title);
      if (it.detail) drawPropText(c, clipPropText(it.detail, rr.w - 16), rr.x + 7, rr.y + 13, UI2.dim);
    });
    if (res.clickedIndex >= 0) {
      const it = feed.items[res.clickedIndex];
      if (it) {
        feed.markRead(it.id);
        if (it.area && it.x !== undefined && it.y !== undefined) {
          actions.focusCameraOn(it.area, it.x, it.y);
        }
      }
    }
    if (ptr.inside && hitRect(r, ptr.x, ptr.y)) {
      if (ptr.clicked || ptr.rightClicked) ptr.consumed = true;
    }
  }

  private renderSelectionCard(
    ctx: CanvasRenderingContext2D,
    input: InputManager,
    world: World,
    actions: HudActions,
    pal: SettingsStore["data"]["colorBlindPalette"]
  ) {
    const ptr = input.pointer;
    const areaId = currentArea(world).id;
    const actors = world.actors.filter((a) => this.selectedActors.has(a.id) && a.area === areaId);
    if (!actors.length) { this.selectedActors.clear(); return; }

    const r: Rect = { x: 8, y: UI2_H - 64, w: 196, h: 56 };
    hiFrame(ctx, r.x, r.y, r.w, r.h, "#13101a", semanticColor("info", pal));
    if (actors.length === 1) {
      const a = actors[0];
      drawPropTextS(ctx, clipPropText(actorDisplayName(a), r.w - 28), r.x + 8, r.y + 6, UI2.title);
      const sub = a.life ? `${a.life.act} (${a.life.state})` : a.job ? `Order: ${a.job.status}` : a.task ? `Task: ${a.task.kind}` : actorDef(a).name;
      drawPropText(ctx, clipPropText(sub, r.w - 16), r.x + 8, r.y + 18, UI2.mid);
      drawPropText(ctx, `Pos ${Math.round(a.x)}, ${Math.round(a.y)} | Pack ${a.inventory.filter(Boolean).length}/${a.inventory.length}`, r.x + 8, r.y + 29, UI2.dim);
      if (a.kind !== "folk" && a.kind !== "keeper" && a.id !== world.playerId) {
        if (hiButton(ctx, { x: r.x + 8, y: r.y + 40, w: 72, h: 13 }, "Manage", ptr)) actions.openManage(a.id);
      }
    } else {
      drawPropTextS(ctx, `Selected: ${actors.length} actors`, r.x + 8, r.y + 6, UI2.title);
      const names = actors.slice(0, 3).map(actorDisplayName).join(", ");
      drawPropText(ctx, clipPropText(names + (actors.length > 3 ? "..." : ""), r.w - 16), r.x + 8, r.y + 18, UI2.mid);
      drawPropText(ctx, "Drag-select to pick units", r.x + 8, r.y + 30, UI2.dim);
    }
    if (hiButton(ctx, { x: r.x + r.w - 18, y: r.y + 4, w: 14, h: 13 }, "x", ptr)) {
      this.selectedActors.clear();
    }
    if (ptr.inside && hitRect(r, ptr.x, ptr.y) && ptr.clicked) ptr.consumed = true;
  }

  private inspectWorldHover(w: World, wx: number, wy: number, sx: number, sy: number, pal: SettingsStore["data"]["colorBlindPalette"]) {
    const area = currentArea(w);
    const actor = this.pickActorAt(w, wx, wy);
    if (actor) {
      const body = isFolk(actor)
        ? `${actor.life!.act} (${actor.life!.state})`
        : actor.job
          ? `Order: ${actor.job.status}`
          : actor.task
            ? `Working: ${actor.task.kind}`
            : actorDef(actor).name;
      this.tips.show({ title: actorDisplayName(actor), body, x: sx, y: sy, accent: semanticColor("info", pal) });
      return;
    }
    for (const l of area.loose) {
      if (l.taken) continue;
      if (Math.hypot(l.x - wx, l.y - wy) < 10) {
        const name = ITEM_NAMES[l.item] ?? l.item;
        this.tips.show({ title: name, body: l.n && l.n > 1 ? `Loose stack x${l.n}` : "Loose item (E to pick up)", x: sx, y: sy, accent: UI2.gold });
        return;
      }
    }
    for (const p of area.props) {
      if (p.taken) continue;
      if (Math.hypot(p.x - wx, p.y - 6 - wy) < 12) {
        const title = p.name ?? p.kind.replace(/_/g, " ");
        const body = p.inventory ? `Storage (${p.inventory.filter(Boolean).length}/${p.inventory.length} slots)` : p.dmg > 0 ? `Damage: ${p.dmg}` : undefined;
        this.tips.show({ title, body, x: sx, y: sy });
        return;
      }
    }
  }
}

function actorDisplayName(a: Actor): string {
  if (a.name) return a.name;
  if (a.person) return folkLabel(a);
  if (a.keeper) return keeperLabel(a);
  if (a.id === "golem") return "Maintainer Golem";
  return actorDef(a).name;
}

export { propTextWidth, player };
