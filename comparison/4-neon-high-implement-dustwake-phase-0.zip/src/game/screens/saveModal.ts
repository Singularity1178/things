// Save System v2 Multi-Slot Modal (Phase 0.4) rendered on the 2x hi-res UI layer.
// Displays IndexedDB slots + autosave + rolling backup counts, with Save, Load,
// Delete, Export JSON file, Import JSON file, and Corruption Recovery test.
import {
  DEFAULT_SLOTS,
  downloadSaveFile,
  type SaveSlotMeta,
  type SaveStore,
} from "../view/saveStore";
import {
  hiButton,
  hiModal,
  hiTable,
  semanticColor,
  UI2,
  type Rect,
  type TableColumn,
  type TableState,
  type TooltipHost,
} from "../ui/components";
import { UI2_H, UI2_W, type InputManager } from "../ui/input";
import { drawPropText } from "../ui/propFont";
import type { ColorBlindPalette } from "../settings";
import type { World } from "../world/world";

interface SlotRow {
  id: string;
  name: string;
  status: string;
  area: string;
  day: string;
  size: string;
  backups: string;
  corrupted: boolean;
  exists: boolean;
  savedAt: number;
}

export interface SaveModalCallbacks {
  getWorld(): World;
  onLoaded(world: World, msg: string, recoveredFrom?: string): void;
  onStatus(msg: string, severity?: "info" | "success" | "warn" | "alert"): void;
}

export class SaveModal {
  open = false;
  slots: SaveSlotMeta[] = [];
  busy = false;
  statusMsg = "";
  private table: TableState = { scroll: 0, selected: 0, sortCol: null, sortAsc: false };

  async show(store: SaveStore) {
    this.open = true;
    this.statusMsg = "";
    await this.refresh(store);
  }

  close() {
    this.open = false;
  }

  async refresh(store: SaveStore) {
    this.busy = true;
    try {
      this.slots = await store.listSlots();
    } finally {
      this.busy = false;
    }
  }

  private rows(): SlotRow[] {
    const byId = new Map(this.slots.map((s) => [s.id, s]));
    const ids = [...new Set([...DEFAULT_SLOTS, ...this.slots.map((s) => s.id)])];
    return ids.map((id) => {
      const m = byId.get(id);
      if (!m) {
        return {
          id,
          name: id === "autosave" ? "Autosave" : id.replace(/^slot-/, "Slot "),
          status: "Empty",
          area: "-",
          day: "-",
          size: "-",
          backups: "0",
          corrupted: false,
          exists: false,
          savedAt: 0,
        };
      }
      return {
        id,
        name: m.name,
        status: m.corrupted ? "CORRUPT" : `v${m.version}`,
        area: m.area,
        day: m.corrupted ? "-" : `Day ${m.day}`,
        size: `${(m.sizeBytes / 1024).toFixed(1)} KB`,
        backups: String(m.backupCount ?? 0),
        corrupted: !!m.corrupted,
        exists: true,
        savedAt: m.savedAt,
      };
    });
  }

  updateAndRender(
    ctx: CanvasRenderingContext2D,
    input: InputManager,
    store: SaveStore,
    cb: SaveModalCallbacks,
    pal: ColorBlindPalette,
    hitKey: (...k: string[]) => boolean,
    tips: TooltipHost
  ): boolean {
    if (!this.open) return false;
    const ptr = input.pointer;
    if (hitKey("escape")) { this.close(); return true; }

    const r: Rect = { x: 64, y: 34, w: UI2_W - 128, h: UI2_H - 68 };
    const { closeClicked } = hiModal(ctx, r, "Save Slots (IndexedDB v2)", "Rolling backups & recovery", ptr);
    if (closeClicked) { this.close(); return true; }

    const rows = this.rows();
    if (hitKey("arrowdown", "s")) this.table.selected = Math.min(rows.length - 1, this.table.selected + 1);
    if (hitKey("arrowup", "w")) this.table.selected = Math.max(0, this.table.selected - 1);

    const cols: TableColumn<SlotRow>[] = [
      { id: "name", label: "Slot", w: 112, value: (x) => x.name, color: (x) => x.corrupted ? semanticColor("alert", pal) : x.exists ? UI2.title : UI2.dim },
      { id: "area", label: "Area", w: 108, value: (x) => x.area },
      { id: "day", label: "Day", w: 58, value: (x) => x.day },
      { id: "status", label: "Ver", w: 62, value: (x) => x.status, color: (x) => x.corrupted ? semanticColor("alert", pal) : semanticColor("ok", pal) },
      { id: "size", label: "Size", w: 66, align: "right", value: (x) => x.size },
      { id: "backups", label: "Bak", w: 50, align: "right", value: (x) => x.backups },
    ];

    const tableR: Rect = { x: r.x + 10, y: r.y + 32, w: r.w - 20, h: r.h - 102 };
    const res = hiTable(ctx, tableR, cols, rows, this.table, input, 18);
    const selected = res.sorted[this.table.selected] ?? rows[0];

    if (this.statusMsg) {
      drawPropText(ctx, this.statusMsg, r.x + 12, r.y + r.h - 62, semanticColor("info", pal));
    } else if (selected) {
      const info = selected.exists
        ? `Selected: ${selected.name} (${selected.area}, ${selected.backups} rolling backup${selected.backups === "1" ? "" : "s"})`
        : `Selected: ${selected.name} (empty slot)`;
      drawPropText(ctx, info, r.x + 12, r.y + r.h - 62, UI2.mid);
    }

    const by = r.y + r.h - 46;
    const bh = 18;
    // Row 1: Save, Load, Delete
    if (hiButton(ctx, { x: r.x + 10, y: by, w: 84, h: bh }, "Save Slot", ptr, { active: true, disabled: this.busy || !selected }, tips)) {
      const id = selected.id;
      void store.saveSlot(id, cb.getWorld(), selected.name).then(async (meta) => {
        this.statusMsg = `Saved ${meta.name} (${(meta.sizeBytes / 1024).toFixed(1)} KB).`;
        cb.onStatus(this.statusMsg, "success");
        await this.refresh(store);
      });
    }
    if (hiButton(ctx, { x: r.x + 100, y: by, w: 84, h: bh }, "Load Slot", ptr, { disabled: this.busy || !selected?.exists }, tips)) {
      const id = selected.id;
      void store.loadSlot(id).then(async (loaded) => {
        if (!loaded) { this.statusMsg = "Slot is empty."; return; }
        cb.onLoaded(loaded.world, loaded.warning ?? `Loaded ${loaded.meta.name}.`, loaded.recoveredFrom);
        await this.refresh(store);
        this.close();
      }).catch((err) => {
        this.statusMsg = String(err instanceof Error ? err.message : err);
        cb.onStatus(this.statusMsg, "alert");
      });
    }
    if (hiButton(ctx, { x: r.x + 190, y: by, w: 74, h: bh }, "Delete", ptr, { disabled: this.busy || !selected?.exists, accent: semanticColor("alert", pal) }, tips)) {
      const id = selected.id;
      void store.deleteSlot(id).then(async () => {
        this.statusMsg = `Deleted ${selected.name}.`;
        await this.refresh(store);
      });
    }

    // Export / Import JSON file
    if (hiButton(ctx, { x: r.x + 272, y: by, w: 82, h: bh }, "Export File", ptr, { disabled: this.busy, tooltip: { title: "Export Save", body: "Download JSON backup file." } }, tips)) {
      const json = JSON.stringify(store ? null : null);
      void json;
      const targetId = selected?.exists ? selected.id : null;
      if (targetId) {
        void store.exportSlotJson(targetId).then((txt) => {
          if (txt) {
            downloadSaveFile(`dustwake-${targetId}.json`, txt);
            this.statusMsg = `Exported dustwake-${targetId}.json`;
          }
        });
      } else {
        void store.saveSlot("slot-1", cb.getWorld()).then(async () => {
          const txt = await store.exportSlotJson("slot-1");
          if (txt) downloadSaveFile("dustwake-slot-1.json", txt);
          this.statusMsg = "Exported live world to dustwake-slot-1.json";
          await this.refresh(store);
        });
      }
    }
    if (hiButton(ctx, { x: r.x + 360, y: by, w: 82, h: bh }, "Import File", ptr, { disabled: this.busy, tooltip: { title: "Import Save", body: "Load a .json save file into the selected slot." } }, tips)) {
      if (typeof document !== "undefined") {
        const inp = document.createElement("input");
        inp.type = "file";
        inp.accept = ".json,application/json";
        inp.onchange = () => {
          const file = inp.files?.[0];
          if (!file) return;
          void file.text().then(async (txt) => {
            try {
              const target = selected?.id ?? "slot-1";
              const imported = await store.importSlotJson(target, txt, file.name.replace(/\.json$/i, ""));
              cb.onLoaded(imported.world, `Imported "${file.name}" into ${target}.`);
              await this.refresh(store);
              this.close();
            } catch (err) {
              this.statusMsg = `Import failed: ${err instanceof Error ? err.message : String(err)}`;
              cb.onStatus(this.statusMsg, "alert");
            }
          });
        };
        inp.click();
      }
    }

    // Row 2: Close button + quick tip
    drawPropText(ctx, "Tip: Autosave runs on timer & area change with 3 rolling backups.", r.x + 12, r.y + r.h - 19, UI2.dim);
    if (hiButton(ctx, { x: r.x + r.w - 78, y: r.y + r.h - 24, w: 68, h: 16 }, "Close", ptr)) {
      this.close();
    }

    ptr.consumed = true;
    return true;
  }
}
