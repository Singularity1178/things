// Dynamic Areas & Floors Modal (Phase 0.3) rendered on the 2x hi-res UI layer.
// Lists all authored and runtime-generated areas (`AreaSpec`), lets the player
// create new procedural floors/caverns/outposts/wilds, travel to any area, or
// return to an area's parent.
import { createDynamicArea, currentArea, enterArea, getArea, player, type World } from "../world/world";
import { AREAS } from "../world/areas";
import type { AreaKind } from "../world/areaSpec";
import {
  hiButton,
  hiFrame,
  hiModal,
  hiTable,
  semanticColor,
  UI2,
  type Rect,
  type TableColumn,
  type TableState,
  type TooltipHost,
} from "../ui/components";
import { UI2_H, UI2_W, type InputManager } from "../ui/input";
import { drawPropText } from "../ui/propFont";
import type { ColorBlindPalette } from "../settings";

interface AreaRow {
  id: string;
  label: string;
  kind: string;
  depth: number;
  size: string;
  actors: number;
  current: boolean;
  dynamic: boolean;
  parent?: string;
}

const KINDS: readonly { kind: AreaKind; label: string }[] = [
  { kind: "dungeon_floor", label: "Dungeon Floor" },
  { kind: "cavern", label: "Cavern" },
  { kind: "outpost", label: "Outpost" },
  { kind: "wilds", label: "Wilds" },
];

export class FloorsModal {
  open = false;
  kindIdx = 0;
  depth = 1;
  private table: TableState = { scroll: 0, selected: 0, sortCol: null, sortAsc: true };

  toggle() { this.open = !this.open; }
  close() { this.open = false; }

  private rows(w: World): AreaRow[] {
    const curId = currentArea(w).id;
    const ids = new Set<string>([...Object.keys(AREAS), ...w.areas.keys(), ...w.specs.keys()]);
    const list: AreaRow[] = [];
    for (const id of ids) {
      const spec = w.specs.get(id);
      const area = w.areas.get(id);
      const actors = w.actors.filter((a) => a.area === id).length;
      list.push({
        id,
        label: spec?.label ?? id.replace(/_/g, " "),
        kind: spec ? spec.kind : "authored",
        depth: spec?.depth ?? (id === "dungeon" ? 1 : 0),
        size: area ? `${area.w}x${area.h}` : spec ? `${spec.w}x${spec.h}` : "lazy",
        actors,
        current: id === curId,
        dynamic: !!spec,
        parent: spec?.parent,
      });
    }
    return list;
  }

  updateAndRender(
    ctx: CanvasRenderingContext2D,
    input: InputManager,
    w: World,
    pal: ColorBlindPalette,
    hitKey: (...k: string[]) => boolean,
    tips: TooltipHost,
    onTravel: (areaId: string) => void
  ): boolean {
    if (!this.open) return false;
    const ptr = input.pointer;
    if (hitKey("escape")) { this.close(); return true; }

    const r: Rect = { x: 56, y: 30, w: UI2_W - 112, h: UI2_H - 60 };
    const { closeClicked } = hiModal(ctx, r, "Areas & Dynamic Floors (AreaSpec)", `${w.specs.size} generated`, ptr);
    if (closeClicked) { this.close(); return true; }

    const rows = this.rows(w);
    if (hitKey("arrowdown", "s")) this.table.selected = Math.min(rows.length - 1, this.table.selected + 1);
    if (hitKey("arrowup", "w")) this.table.selected = Math.max(0, this.table.selected - 1);

    const cols: TableColumn<AreaRow>[] = [
      { id: "id", label: "Area ID", w: 128, value: (x) => (x.current ? "* " : "") + x.label, color: (x) => x.current ? semanticColor("ok", pal) : x.dynamic ? semanticColor("info", pal) : UI2.text },
      { id: "kind", label: "Kind", w: 96, value: (x) => x.kind },
      { id: "depth", label: "Depth", w: 50, align: "right", value: (x) => `D${x.depth}`, sortKey: (x) => x.depth },
      { id: "size", label: "Size", w: 66, align: "right", value: (x) => x.size },
      { id: "actors", label: "Actors", w: 56, align: "right", value: (x) => String(x.actors), sortKey: (x) => x.actors },
      { id: "parent", label: "Parent", w: 96, value: (x) => x.parent ?? "-" },
    ];

    const tableR: Rect = { x: r.x + 10, y: r.y + 30, w: r.w - 20, h: r.h - 108 };
    const res = hiTable(ctx, tableR, cols, rows, this.table, input, 16);
    const sel = res.sorted[this.table.selected] ?? rows[0];

    // Generator bar
    const genY = r.y + r.h - 70;
    hiFrame(ctx, r.x + 10, genY, r.w - 20, 34, UI2.bgDeep);
    drawPropText(ctx, "Create Runtime Area:", r.x + 18, genY + 13, UI2.mid);

    const kind = KINDS[this.kindIdx];
    if (hiButton(ctx, { x: r.x + 128, y: genY + 8, w: 108, h: 18 }, `Kind: ${kind.label}`, ptr, { tooltip: { title: "Area Builder Kind", body: "Click to cycle dungeon_floor, cavern, outpost, wilds." } }, tips)) {
      this.kindIdx = (this.kindIdx + 1) % KINDS.length;
    }
    if (hiButton(ctx, { x: r.x + 242, y: genY + 8, w: 66, h: 18 }, `Depth ${this.depth}`, ptr, { tooltip: { title: "Floor Depth", body: "Click to increment depth (1..8)." } }, tips)) {
      this.depth = (this.depth % 8) + 1;
    }
    if (hiButton(ctx, { x: r.x + 314, y: genY + 8, w: 118, h: 18 }, "Generate & Enter", ptr, { active: true, accent: semanticColor("info", pal) }, tips)) {
      const parent = currentArea(w).id;
      const area = createDynamicArea(w, {
        kind: kind.kind,
        depth: this.depth,
        parent,
        w: 36,
        h: 28,
        label: `${kind.label} D${this.depth}`,
      });
      enterArea(w, player(w), area.id, area.start.x, area.start.y);
      onTravel(area.id);
      this.close();
      return true;
    }
    if (hiButton(ctx, { x: r.x + 438, y: genY + 8, w: 72, h: 18 }, "Gen Only", ptr, { tooltip: { title: "Generate Area", body: "Creates an AreaSpec without travelling yet." } }, tips)) {
      createDynamicArea(w, {
        kind: kind.kind,
        depth: this.depth,
        parent: currentArea(w).id,
        w: 36,
        h: 28,
        label: `${kind.label} D${this.depth}`,
      });
    }

    // Footer actions: Travel to Selected / Leave to Parent / Close
    const fy = r.y + r.h - 28;
    const travel = (targetId: string) => {
      const a = getArea(w, targetId);
      enterArea(w, player(w), a.id, a.start.x, a.start.y);
      onTravel(a.id);
      this.close();
    };
    if (res.doubleClickedRow && !res.doubleClickedRow.current) {
      travel(res.doubleClickedRow.id);
      return true;
    }
    if (hiButton(ctx, { x: r.x + 10, y: fy, w: 120, h: 18 }, "Travel to Selected", ptr, { active: true, disabled: !sel || sel.current }, tips)) {
      travel(sel.id);
      return true;
    }
    const curSpec = currentArea(w).spec;
    if (hiButton(ctx, { x: r.x + 136, y: fy, w: 126, h: 18 }, curSpec?.parent ? `Leave -> ${curSpec.parent}` : "Return to Dungeon", ptr, { disabled: !curSpec?.parent && currentArea(w).id === "dungeon" }, tips)) {
      travel(curSpec?.parent ?? "dungeon");
      return true;
    }
    if (hiButton(ctx, { x: r.x + r.w - 80, y: fy, w: 70, h: 18 }, "Close", ptr)) {
      this.close();
    }

    ptr.consumed = true;
    return true;
  }
}
