// Settings & Accessibility Modal (Phase 0.7) rendered on the 2x hi-res UI layer.
// Reads dynamically from `registeredSettings()` so future phases register their
// options in one central place. Supports mouse, keyboard, and gamepad navigation.
import {
  ACTION_LABELS,
  registeredSettings,
  type ActionId,
  type SettingCategory,
  type SettingsStore,
} from "../settings";
import {
  hiButton,
  hiFrame,
  hiModal,
  hiScrollList,
  hiSlider,
  hiTabs,
  hiToggle,
  semanticColor,
  UI2,
  type Rect,
  type ScrollListState,
  type TooltipHost,
} from "../ui/components";
import { UI2_H, UI2_W, type InputManager } from "../ui/input";
import { clipPropText, drawPropText, drawPropTextS } from "../ui/propFont";

type TabId = "audio" | "display" | "alerts" | "controls";
const TABS: readonly { id: TabId; label: string }[] = [
  { id: "audio", label: "Audio" },
  { id: "display", label: "Display & Accessibility" },
  { id: "alerts", label: "Alerts & Autosave" },
  { id: "controls", label: "Keybinds" },
];

export class SettingsModal {
  open = false;
  tab: TabId = "audio";
  focus = 0;
  rebinding: ActionId | null = null;
  private controlsList: ScrollListState = { scroll: 0, selected: 0 };

  toggle() {
    this.open = !this.open;
    this.rebinding = null;
    this.focus = 0;
  }

  close() {
    this.open = false;
    this.rebinding = null;
  }

  /** Capture a key press while waiting to rebind an action. Returns true if consumed. */
  captureKey(rawKey: string, settings: SettingsStore): boolean {
    if (!this.open || !this.rebinding) return false;
    const k = rawKey.toLowerCase();
    if (k === "escape") {
      this.rebinding = null;
      return true;
    }
    settings.rebind(this.rebinding, k);
    this.rebinding = null;
    return true;
  }

  updateAndRender(
    ctx: CanvasRenderingContext2D,
    input: InputManager,
    settings: SettingsStore,
    hitKey: (...k: string[]) => boolean,
    tips: TooltipHost
  ): boolean {
    if (!this.open) return false;
    const ptr = input.pointer;
    const s = settings.data;
    const pal = s.colorBlindPalette;

    if (!this.rebinding) {
      if (hitKey("escape")) { this.close(); return true; }
      if (hitKey("q")) {
        const i = TABS.findIndex((t) => t.id === this.tab);
        this.tab = TABS[(i - 1 + TABS.length) % TABS.length].id;
        this.focus = 0;
      } else if (hitKey("e") && this.tab === "controls" && !ptr.inside) {
        const actions = Object.keys(ACTION_LABELS) as ActionId[];
        const act = actions[this.controlsList.selected];
        if (act) this.rebinding = act;
      }
    }

    const r: Rect = { x: 80, y: 34, w: UI2_W - 160, h: UI2_H - 68 };
    const { closeClicked } = hiModal(ctx, r, "Settings & Accessibility", "Esc to close", ptr);
    if (closeClicked) { this.close(); return true; }

    // Tabs
    const tabR: Rect = { x: r.x + 10, y: r.y + 30, w: r.w - 20, h: 18 };
    const nextTab = hiTabs(ctx, tabR, TABS, this.tab, ptr, tips);
    if (nextTab) { this.tab = nextTab as TabId; this.focus = 0; this.rebinding = null; }

    const bodyR: Rect = { x: r.x + 10, y: r.y + 54, w: r.w - 20, h: r.h - 92 };

    if (this.tab === "controls") {
      const actions = Object.keys(ACTION_LABELS) as ActionId[];
      if (!this.rebinding) {
        if (hitKey("arrowdown")) this.controlsList.selected = Math.min(actions.length - 1, this.controlsList.selected + 1);
        if (hitKey("arrowup")) this.controlsList.selected = Math.max(0, this.controlsList.selected - 1);
      }
      const res = hiScrollList(ctx, bodyR, actions, 18, this.controlsList, input, (c, act, _i, rr) => {
        drawPropText(c, ACTION_LABELS[act], rr.x + 6, rr.y + 5, UI2.text);
        const waiting = this.rebinding === act;
        const bindLabel = waiting ? "Press a key..." : settings.formatBinding(act);
        const col = waiting ? semanticColor("warn", pal) : UI2.title;
        drawPropText(c, bindLabel, rr.x + rr.w - 8, rr.y + 5, col, 1, "right");
      });
      if (res.clickedIndex >= 0) {
        this.rebinding = actions[res.clickedIndex];
      }
      // Footer button: Reset Keybinds
      const resetR: Rect = { x: r.x + 10, y: r.y + r.h - 28, w: 110, h: 18 };
      if (hiButton(ctx, resetR, "Reset Keybinds", ptr, { tooltip: { title: "Reset Controls", body: "Restore all keybindings to defaults." } }, tips)) {
        settings.resetKeybinds();
      }
    } else {
      const defs = registeredSettings(this.tab as SettingCategory);
      if (hitKey("arrowdown", "s")) this.focus = (this.focus + 1) % Math.max(1, defs.length);
      if (hitKey("arrowup", "w")) this.focus = (this.focus - 1 + Math.max(1, defs.length)) % Math.max(1, defs.length);

      hiFrame(ctx, bodyR.x, bodyR.y, bodyR.w, bodyR.h, UI2.bgDeep);
      const rowH = 28;
      defs.forEach((def, idx) => {
        const ry = bodyR.y + 6 + idx * rowH;
        if (ry + rowH > bodyR.y + bodyR.h) return;
        const focused = this.focus === idx;
        if (focused) {
          ctx.fillStyle = "#1c1826";
          ctx.fillRect(bodyR.x + 3, ry - 2, bodyR.w - 6, rowH - 2);
        }
        drawPropTextS(ctx, def.label, bodyR.x + 10, ry + 2, focused ? UI2.title : UI2.text);
        if (def.hint) drawPropText(ctx, clipPropText(def.hint, 210), bodyR.x + 10, ry + 13, UI2.dim);

        const ctrlR: Rect = { x: bodyR.x + bodyR.w - 178, y: ry + 3, w: 168, h: 18 };
        if (def.kind === "slider") {
          const cur = def.get(s);
          const sliderR: Rect = { x: ctrlR.x, y: ctrlR.y, w: ctrlR.w - 36, h: ctrlR.h };
          const nv = hiSlider(ctx, sliderR, cur, def.min, def.max, def.step, ptr, semanticColor("info", pal), focused);
          if (nv !== null) { def.set(s, nv); settings.save(); }
          if (focused && hitKey("arrowleft", "a")) { def.set(s, Math.max(def.min, Number((cur - def.step).toFixed(4)))); settings.save(); }
          if (focused && hitKey("arrowright", "d")) { def.set(s, Math.min(def.max, Number((cur + def.step).toFixed(4)))); settings.save(); }
          const label = def.format ? def.format(def.get(s)) : String(def.get(s));
          drawPropText(ctx, label, ctrlR.x + ctrlR.w - 2, ry + 7, UI2.title, 1, "right");
        } else if (def.kind === "toggle") {
          const cur = def.get(s);
          const toggled = hiToggle(ctx, ctrlR, cur, ptr, semanticColor("ok", pal), focused) || (focused && hitKey("enter", " "));
          if (toggled) { def.set(s, !cur); settings.save(); }
          drawPropText(ctx, cur ? "On" : "Off", ctrlR.x + ctrlR.w - 36, ry + 7, cur ? semanticColor("ok", pal) : UI2.dim, 1, "right");
        } else if (def.kind === "choice") {
          const cur = def.get(s);
          const ci = Math.max(0, def.choices.findIndex((c) => c.value === cur));
          const choice = def.choices[ci] ?? def.choices[0];
          const clicked = hiButton(ctx, ctrlR, choice.label, ptr, { active: focused });
          if (clicked || (focused && hitKey("arrowright", "d", "enter"))) {
            const next = def.choices[(ci + 1) % def.choices.length];
            def.set(s, next.value);
            settings.save();
          } else if (focused && hitKey("arrowleft", "a")) {
            const prev = def.choices[(ci - 1 + def.choices.length) % def.choices.length];
            def.set(s, prev.value);
            settings.save();
          }
        }
      });
    }

    // Footer buttons
    const resetAllR: Rect = { x: r.x + r.w - 196, y: r.y + r.h - 28, w: 96, h: 18 };
    if (hiButton(ctx, resetAllR, "Reset All", ptr)) {
      settings.resetAll();
    }
    const doneR: Rect = { x: r.x + r.w - 92, y: r.y + r.h - 28, w: 82, h: 18 };
    if (hiButton(ctx, doneR, "Done", ptr, { active: true })) {
      this.close();
    }

    ptr.consumed = true;
    return true;
  }
}
