// General content linter CLI (Phase 0.8).
// Usage: node scripts/lint-content.mjs
import { execFileSync } from "node:child_process";
import { mkdirSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
execFileSync(process.execPath, [require.resolve("typescript/bin/tsc"), "-p", "tsconfig.test.json"], { stdio: "inherit" });
mkdirSync(".test-out", { recursive: true });
writeFileSync(".test-out/package.json", '{"type":"commonjs"}');

const { lintAllContent } = require("../.test-out/src/game/sim/contentLint.js");
const res = lintAllContent();
console.log(`[content-lint] checked ${res.checked} content rows: ${res.errors.length} error(s), ${res.warnings.length} warning(s).`);
if (!res.ok) {
  for (const err of res.errors) console.error(`  [${err.table}:${err.row}] ${err.message}`);
  process.exit(1);
}
console.log("[content-lint] PASS");
