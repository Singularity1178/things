// Headless soak-test runner (Phase 0.8).
// Usage: node scripts/soak.mjs [--actors=300] [--days=1] [--budget=12]
import { execFileSync } from "node:child_process";
import { mkdirSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
execFileSync(process.execPath, [require.resolve("typescript/bin/tsc"), "-p", "tsconfig.test.json"], { stdio: "inherit" });
mkdirSync(".test-out", { recursive: true });
writeFileSync(".test-out/package.json", '{"type":"commonjs"}');

const arg = (name, fallback) => {
  const hit = process.argv.find((a) => a.startsWith(`--${name}=`));
  return hit ? Number(hit.split("=")[1]) : fallback;
};

const { runSoak } = require("../.test-out/src/game/sim/soak.js");
const actors = arg("actors", 300);
const days = arg("days", 1);
const frameBudgetMs = arg("budget", 12);

const report = runSoak({ actors, days, frameBudgetMs, checkRoundTrip: true });
console.log(
  `[soak] actors=${report.actors} ticks=${report.ticks} sim=${report.simSeconds.toFixed(0)}s ` +
  `avg=${report.avgTickMs.toFixed(2)}ms p95=${report.p95TickMs.toFixed(2)}ms max=${report.maxTickMs.toFixed(2)}ms ` +
  `LOD=(${report.lodCounts.active}A/${report.lodCounts.near}N/${report.lodCounts.far}F)`
);
if (!report.ok) {
  console.error("[soak] FAILED with violations:");
  for (const v of report.violations) console.error("  -", v);
  process.exit(1);
}
console.log("[soak] PASS — all invariants & frame budget satisfied.");
