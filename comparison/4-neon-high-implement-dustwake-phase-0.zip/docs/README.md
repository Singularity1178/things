# Dustwake Documentation Index

Dustwake's architecture is split by system so every subsystem has one focused, maintainable home.

## Simulation (`docs/sim/`)
- [Overview, Fixed Timestep & Simulation LOD](sim/overview.md) — layer boundaries, `SimClock`, `InterpBuffer`, Active/Near/Far LOD, day/night clock.
- [Actors, Body Power, Gear & Inventory](sim/actors-and-power.md) — `ACTORS` definitions, power cores, worn gear slots, capacity tiers.
- [Orders, Navigation & Tasks](sim/orders.md) — tasks/effects as data, durable worker jobs, A* pathing, cross-area routes & portals.
- [Crafting, Building, Storage & Vision](sim/crafting-and-building.md) — shared station crafting, harvesting, analysis gating, vision holograms.
- [Townsfolk & Shops](sim/folk-and-shops.md) — daily routines, exclusive spots, shopkeeper visits, peer talk & guild board.

## World & Persistence (`docs/world/`)
- [Areas & Dynamic `AreaSpec`](world/areas.md) — `Area` revisions, authored areas, runtime procedural floors/caverns/outposts/wilds, rune network.
- [Save System v2 & Migrations](world/saves.md) — IndexedDB multi-slot store, autosave, rolling backups, corruption recovery, RLE grids, v1–v20 migrations.

## View, Input & UI (`docs/view/`)
- [Rendering, Split Host, UI v2 & Settings](view/rendering-and-ui.md) — `Camera`, `ParticleSystem`, `WorldRenderer`, `EventReactions`, 2x hi-res UI layer, mixed-case proportional font, Input v2, components, notifications, accessibility.

## Verification & Quality (`docs/testing.md`)
- [Testing, Soak Harness & Content Linter](testing.md) — headless Node tests, golden pixel checks, 300-actor soak frame budget, content linter.

## How-To Guides (`docs/guides/`)
- [How to add a Recipe (Build or Craft)](guides/how-to-add-recipe.md)
- [How to add a Dynamic Area Kind (`AreaSpec`)](guides/how-to-add-area-kind.md)
- [How to add an Actor or Species](guides/how-to-add-actor-or-species.md)
- [How to register a Setting or Accessibility Option](guides/how-to-add-setting.md)
