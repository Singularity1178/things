# Dustwake Architecture

> **Note (Phase 0.9):** The former 180 KB single-file architecture document has been split into per-system documentation with dedicated "How to add X" guides. See **[docs/README.md](README.md)** for the full index.

## Four Strict Layers

1. **`src/game/content/` — Data tables (pure, no DOM).** Items, tiles, props, recipes, stations, actors, NPCs, dialogue, monologue, folk routines, shops, talk pools, day/night cycle, vision rules.
2. **`src/game/world/` — Runtime state & persistence (pure, no DOM).** `World`, `Area`, `AreaSpec` dynamic builders, `save.ts` (v20 serialization, RLE grids, migrations v1–v20).
3. **`src/game/sim/` — Simulation rules (pure, no DOM).** Fixed-timestep `SimClock`, Active/Near/Far `lod.ts`, `step.ts`, tasks, inventory, gear, power, orders, navigation, routes, folk, shops, content linter, headless soak harness.
4. **`src/game/view/`, `src/game/ui/`, `src/game/screens/`, `src/game/game.ts` — Presentation & host.** Split into `Camera`, `ParticleSystem`, `WorldRenderer` (with interpolated rendering), `eventReactions.ts`, `AreaView`, `VisionView`, `SaveStore` (IndexedDB), `InputManager` (mouse/keyboard/gamepad), 2x hi-res `propFont` + UI components, `NotificationFeed`, and `SettingsStore`.

## Quick Links
- [Simulation Overview, Fixed Timestep & LOD](sim/overview.md)
- [Orders, Navigation & Tasks](sim/orders.md)
- [Areas & Dynamic `AreaSpec`](world/areas.md)
- [Save System v2](world/saves.md)
- [Split Host, UI v2 & Accessibility](view/rendering-and-ui.md)
- [Testing, Soak & Content Linter](testing.md)
- [All Docs & How-To Guides](README.md)
