# Testing, Soak Harness & Content Linter

## Running Tests

```bash
# Full headless unit, migration, golden pixel & Phase 0 suite
node scripts/test.mjs

# Standalone general content linter (checks every content row)
node scripts/lint-content.mjs

# Standalone headless soak test (default 300 actors, 1 in-game day)
node scripts/soak.mjs --actors=300 --days=1 --budget=12
```

## Test Categories

1. **Simulation & Migration Tests (`tests/*.test.ts`):** Pure Node tests with no browser dependency covering crafting, building, storage, orders, routes, townsfolk, shops, daycycle, and save migrations v1–v20.
2. **Golden Art & UI Snapshots (`tests/support/`):** `FakeCanvas` FNV-1a trace hashing and `RCanvas` pixel rendering catch unintended visual regressions.
3. **Phase 0 Groundwork Suite (`tests/phase0.test.ts`):**
   - 1x vs 8x fixed-timestep determinism & interpolation.
   - LOD Active/Near/Far classification & `world.time - area.lastTicked` catch-up.
   - Dynamic `AreaSpec` creation, tile/prop editing, save/load round-trip, and exit.
   - Save v2: v19 migration, RLE compression, multi-slot backups, corrupted-save recovery, size & load-time budgets.
   - Input v2, mixed-case proportional font, UI v2 components, notification feed & pause-on-alert.
   - Settings registry, color-blind palettes, key remapping.
4. **General Content Linter (`src/game/sim/contentLint.ts`):** Verifies cross-table integrity (items, build/craft recipes, stations, props, harvest yields, actors, NPCs, dialogue, monologue, shops/visits/spots, folk census/routines/routes, talk exchanges, runes, entrances) and ensures every legacy-font string uses only supported glyphs.
5. **300-Actor Soak Harness (`src/game/sim/soak.ts`):** Runs hundreds of residents across authored + generated areas and fails the build if:
   - Any walking resident is stuck for > 15 seconds.
   - Any item is duplicated or deleted across inventories, gear, storage, and ground stacks.
   - Any exclusive spot is held by two actors simultaneously.
   - Save/load round-trip differs from the live world state.
   - Average tick time exceeds the frame budget.
