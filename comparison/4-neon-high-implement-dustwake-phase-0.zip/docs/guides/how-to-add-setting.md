# How to Register a Setting or Accessibility Option

All settings live in one central registry (`src/game/settings.ts`) and are automatically rendered by `src/game/screens/settingsModal.ts`.

1. For core settings, add a typed field and default to `Settings` / `DEFAULT_SETTINGS` in `src/game/settings.ts`, or store phase-specific values under `settings.extra[key]`.
2. Call `registerSetting(...)` with a `SettingDef` (`kind: "slider" | "toggle" | "choice"`, `category: "audio" | "display" | "alerts" | "gameplay"`, `label`, `hint`, `get`, `set`).
3. Subscribe to live updates via `settingsStore.onChange((s) => ...)` in your view/audio subsystem.
4. For new remappable keys, add the action id to `ActionId`, `ACTION_LABELS`, and `DEFAULT_KEYBINDS` in `src/game/settings.ts`, then read it with `game.input.actionHit(id, game.pressed)` or `game.input.actionDown(id, game.keys)`.
