# How to Add a Recipe (Build or Craft)

## Adding a Crafting Recipe (`src/game/content/crafting.ts`)

1. Ensure every input item, output item, and optional tool exists in `src/game/content/items.ts` (`ITEMS` and `ITEM_NAMES`).
2. Append a `CraftRecipe` row to `CRAFT_RECIPES`:
   - `id`: unique snake_case id.
   - `name`: uppercase bitmap-font-safe label (checked by `contentLint.ts`).
   - `station`: `"crafting" | "smelting" | "smithing"` (or a new station in `STATIONS`).
   - `tab`: optional tab id matching `STATIONS[station].tabs`.
   - `inputs`: `[{ item, n }, ...]` with positive integers.
   - `output`: `{ item, n }`.
   - `desc`: up to 3 short lines (<= 30 chars each, bitmap-font safe).
3. Run `node scripts/lint-content.mjs` and `node scripts/test.mjs`.

## Adding a Build Recipe (`src/game/content/build.ts`)

1. Ensure the built prop exists in `src/game/content/props.ts` (`PROPS`) and has a sprite in `src/game/art/props.ts`.
2. Add a row to `RECIPES` in `src/game/content/build.ts` specifying `name`, `prop`, `cost`, `category`, and optional `requires` / `analysis`.
3. If the plan should be analysis-gated, add its `analysis.<id>` flag or `teaches` reference on a scannable prop.
4. Run `node scripts/lint-content.mjs` to verify all references and glyph coverage.
