# How to Add an Actor or Species

1. **Data row (`src/game/content/actors.ts`):**
   - Add an `ActorDef` entry to `ACTORS` specifying `name`, `body` (`box`, `height`, `reach`), `art: { key }`, `speed`, `harvestPower`, `inventory`, `gearSlots`, optional `power`, and `capabilities`.
2. **Art (`src/game/view/actors.ts` + art module):**
   - Register the drawing routine for `art.key` so `drawActor` renders the actor's silhouette, facing, and animation states (and `view/vision.ts` automatically traces holograms for it).
3. **Spawning:**
   - For authored placements, add an `NpcSpawn` row in the area builder (`AreaData.npcs`).
   - For dynamic spawning, call `makeActor(id, defKey, areaId, x, y)` and push to `world.actors`.
   - If the species has daily routines, define an archetype & routine in `src/game/content/folk.ts` and spawn via `makeFolk`.
4. **LOD compatibility:**
   - Ensure per-tick AI respects `actorStepDt(world, actor, dt)` in `src/game/sim/lod.ts` and catches up cleanly on Far -> Active area entry.
5. Run `node scripts/lint-content.mjs` and `node scripts/soak.mjs --actors=300`.
