# How to Add a Dynamic Area Kind (`AreaSpec`)

1. Open `src/game/world/areaSpec.ts`.
2. Add the new kind name to the `AreaKind` union (or call `registerAreaKind(kind, builder)` at startup).
3. Implement a **100% deterministic** builder `(spec: AreaSpec) => AreaData`:
   - Seed a local PRNG (`mulberry(spec.seed)`); never use `Math.random()`.
   - Allocate `grid`, `plan`, `style`, `tvar` as `Uint8Array(w * h)`.
   - Populate `rooms`, `props`, `lights`, `loose`, `spots`, `start`, and optional return `portals` back to `spec.parent`.
   - Set `outdoor: true` for open-sky biomes or `ambient` for underground areas.
4. Register the builder in `AREA_KIND_BUILDERS`.
5. Spawn instances at runtime via `createDynamicArea(world, { kind, seed, w, h, parent, depth })`.
   - Saves automatically persist `AreaSpec` in `SaveData.specs` and reconstruct the area deterministically on load.
   - Set `playerBuilt: true` if the player can freely reshape the grid so saves automatically use RLE compression (`tilesRle`).
6. Add a create -> edit -> save -> load -> leave test in `tests/phase0.test.ts`.
