# Crafting, Building, Harvesting & Vision

## Harvesting & Digging (`src/game/sim/harvesting.ts`, `sim/digging.ts`)

- Harvestables (`content/harvest.ts`: trees, logs, rocks, iron ore veins) track cumulative damage on `PropInst.dmg` so any actor's blows accumulate and persist across saves.
- Weak, strong, and mixed harvesters receive identical total finite yields.
- Dig sites (`content/digging.ts`) clear layered earth/stone columns until the entrance flag (`ENTRANCES`) opens both portals.

## Shared Station Crafting (`src/game/sim/crafting.ts`, `content/crafting.ts`)

- Crafting draws inputs from the actor's pack plus storage props within 2 tiles of the station (`workbench`, `forge`, `anvil`), while required tools must be carried.
- Inputs are atomically revalidated at task fire time so concurrent crafters never double-spend or partially consume materials.

## Building & Deconstruction (`src/game/sim/build.ts`, `content/build.ts`)

- Built props record their `recipe` and `refund` snapshot so later recipe rebalancing cannot be exploited by deconstruction.
- Deconstructing a storage prop spills all non-critical stacks onto the floor.

## Vision Mode & Analysis (`src/game/sim/analysis.ts`, `content/vision.ts`, `view/vision.ts`)

- `Actor.mode` (`"normal" | "scan"`) is sim state. In scan mode, interacting with a scan target analyzes it, granting `analysis.<plan>` flags.
- Highlight classification is data-driven (`HIGHLIGHT_RULES`). Presentation renders cached sprite-outline holograms tinted by the active color-blind-safe palette (`OVERLAY_PALETTES`).
