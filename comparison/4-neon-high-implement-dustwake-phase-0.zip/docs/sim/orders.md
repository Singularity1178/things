# Orders, Navigation, Routes & Tasks

## Tasks & Effects as Data (`src/game/content/tasks.ts`, `sim/tasks.ts`)

Every timed action (reach, slam, smash, harvest, dig, carve, craft, build, dismantle, scan, channel) is stored as plain JSON `Task` data on `Actor.task` and `Actor.queue`.

- Because tasks and delayed `World.scheduled` effects are plain data, saving mid-swing, mid-craft, or mid-channel resumes identically after load.
- Effects revalidate preconditions at the fire point (e.g., two crafters competing for one chest never partially consume inputs).

## Durable Worker Jobs (`src/game/world/jobs.ts`, `sim/jobs.ts`, `sim/orders.ts`)

Workers accept durable `JobOrder`s (e.g., gather resource to a storage chest or personal inventory).

- Jobs decompose into resumable states (acquire target, pathfind, work, haul, deposit).
- Blocked orders emit `jobChanged` events with explicit reasons (`noRoute`, `storageFull`, `power`) and settle into bounded retries rather than spinning CPU.

## Navigation & Cross-Area Routes (`src/game/sim/navigation.ts`, `sim/routes.ts`, `sim/portals.ts`)

- `navGrid(area, actor)` caches walkability keyed on `area.layoutRevision` so storage transfers never invalidate pathfinding grids.
- `sim/routes.ts` plans multi-area journeys across both **rune network links** (requiring both ends active) and **walk-through portals** (roads, doorways, dug-out stairs).
