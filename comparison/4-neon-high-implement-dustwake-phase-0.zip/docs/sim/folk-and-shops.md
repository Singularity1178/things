# Townsfolk & Shops

## Townsfolk Routines (`src/game/sim/folk.ts`, `content/folk.ts`)

- Generic residents are ordinary `Actor` rows of kind `"folk"` carrying `person` (immutable traits/look generated deterministically from `world.seed`) and `life` (current schedule block, goal, claimed spot, pose, conversation).
- Priority order: active `Task`/`Job` > `Life.duty` (contract seam) > clock-driven `planAt(world, actor)`.
- **Exclusive spots (`EXCLUSIVE_KINDS`, `EXCLUSIVE_IDS`):** Stools, anvils, bedrolls, blinds, and counter slots are claimed via `Life.spot`; no two actors may hold the same exclusive place simultaneously (enforced by the soak harness).
- **Soft bodies:** Folk have no solid collision box; they steer round the golem and step aside when approached.

## Shops, Keepers & Peer Talk (`src/game/sim/shops.ts`, `content/shops.ts`, `content/talk.ts`)

- Six establishments (`smithy`, `armory`, `jeweler`, `tailor`, `tavern`, `guild`) each have an interior area, opening hours, a shopkeeper actor (`kind: "keeper"`), and weighted `VISITS`.
- Multi-line peer exchanges (`EXCHANGES`) and shop counter deals emit `folkSay` / `folkChat` events; presentation renders word bubbles within earshot and pictograms further away.
