# Simulation Overview, Fixed Timestep & LOD

## Core Invariant: Pure, Deterministic Simulation

Everything under `src/game/content/`, `src/game/world/`, and `src/game/sim/` is strictly DOM-free and never reads `Math.random()`. Randomness comes solely from `World.rng` (`SeededRng`) or deterministic hashes (`hash01`) keyed by `world.seed` and stable entity ids.

## Fixed-Timestep Simulation (`src/game/sim/clock.ts`)

Management play requires variable speed controls (**Pause / 1x / 2x / 4x / 8x**) and deterministic replays:

- `SimClock` accumulates `frameDt * speed` and drains fixed `SIM_DT` (`1/60 s`) ticks.
- **1x vs 8x determinism:** Running 8x simply executes 8 fixed ticks per frame instead of 1. Edge-triggered player actions fire on the first tick of the frame. Given the same save and tick-indexed input stream, 1x and 8x produce byte-for-byte identical `serialize(world)` states.
- **Interpolated Rendering (`InterpBuffer`):** Before the final tick of a frame, `InterpBuffer.capture(world)` snapshots every actor's `(x, y, area)`. `WorldRenderer` renders actors at `lerp(prev, cur, clock.alpha)`, snapping cleanly across portals/teleports (> 32 px).

## Simulation Level of Detail (`src/game/sim/lod.ts`)

To support 300+ residents across multiple floors and town areas within a tight frame budget, actors are partitioned into three deterministic tiers every tick:

| Tier | Condition | Simulation Policy |
| :--- | :--- | :--- |
| **Active** | Same area as player, inside camera `ViewRect` + 48 px pad (or player actor) | Full simulation every tick (`dt`). |
| **Near** | Same area as player, outside camera viewport | Stepped every `nearStride` (4) ticks with `dt * nearStride`, deterministically staggered by `actorBucket(id) % nearStride`. |
| **Far** | Any other area | Schedule-based residents (`folk`, `keeper`) cost 0 per tick; caught up on area entry via `catchUpArea(world, area)` using `elapsed = world.time - area.lastTicked`. Off-screen workers with active jobs step at `farStride`. |

`Area.lastTicked` records the last `world.time` an area simulated. For Far areas whose `lastTicked !== world.time`, `SaveData.areaLastTicked` persists the timestamp across save/load.

## Calendar Clock (`src/game/sim/daytime.ts`, `content/daycycle.ts`)

`World.day` counts days since world start (the fraction is time-of-day, `0 = midnight`, `0.5 = noon`; `DAY_SECONDS = 720`). Crossing phase boundaries emits `dayPhase` events for presentation and optional pause-on-alert triggers.
