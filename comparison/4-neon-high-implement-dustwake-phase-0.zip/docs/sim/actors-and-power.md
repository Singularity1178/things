# Actors, Body Power, Gear & Inventory

## Actor Definitions (`src/game/content/actors.ts`, `sim/actorStats.ts`)

Every living or mechanical body (`golem`, `guardian`, `worker_golem`, `townsfolk`, `keeper`) is an `Actor` on `World.actors`. Capabilities, collision footprints, speed tiers, harvest power, inventory capacity tiers, and gear slots are data-driven rows in `ACTORS`.

- **Player vs NPCs:** `World.playerId` identifies the controlled actor. Body upgrades (`golem.arm`, `golem.slot.*`) live on `Actor.upgrades`, not global flags.
- **Body Power (`sim/power.ts`):** Bodies with `ActorDef.power` require a core in `Actor.powerCore` whose tier meets the body's rank. Dormant bodies that have never held a core reject management screens until woken.

## Inventory & Storage (`src/game/sim/inventory.ts`, `sim/inventoryOps.ts`, `sim/storage.ts`)

- Inventories are fixed-length `Slot[]` arrays (`{ item, n } | null`) owned by actors and storage props (`Area.setInventory`).
- Transfers and stacking are atomic; overflow spills onto the ground as `LooseInst` stacks—items are never silently deleted or duplicated.
- `reconcileCapacity` adjusts slot array length when capacity-changing gear (such as the wicker basket) is equipped or removed.

## Gear (`src/game/sim/gear.ts`, `content/gear.ts`)

Actors wear items in named slots (`back`, `core`, `rune0..`, tool heads). Worn runes modify derived stats such as golem light radius (`golemGlow`) and movement speed without duplicating sim rules in presentation.
