# Rendering, Split Host, UI v2 & Settings

## Split Host Architecture (`src/game/view/`, Phase 0.6)

`src/game/game.ts` acts as a thin coordinator over four extracted presentation modules:

1. **`view/camera.ts` (`Camera`):** World viewport (`vw x vh`), zoom easing (`1x / 1.5x / 2x`), smooth target follow, snap, `viewRect()` for LOD, and accessibility-aware screen shake.
2. **`view/particles.ts` (`ParticleSystem`):** Pooled/capped transient visual effects (sparks, embers, dust, debris, drips, splashes, rune motes, fireflies, smoke, glints) and floating particle rendering.
3. **`view/worldRenderer.ts` (`WorldRenderer`):** Offscreen `scene`/`emit`/`lighting` buffers, daylight/moonlight shafts, rune circles, y-sorted props/tiles/actors with **fixed-timestep interpolation** (`InterpBuffer` + `alpha`), drag-select highlights, and vision mode overlay. Leaves clean room for Phase 2's overview renderer.
4. **`view/eventReactions.ts`:** Translates drained `SimEvent`s into audio cues, particle bursts, shakes, speech bubbles, screen openings, and `NotificationFeed` alerts.

## Three Stacked Pixel-Crisp Canvases (`src/App.tsx`)

1. **World canvas (`vw x vh`):** Low base resolution (`320x180` at 1x), pixel-perfect nearest-neighbour scaling.
2. **Legacy 1x UI canvas (`320x180`):** Preserves existing screens (`pack`, `buildMenu`, `crafting`, `storage`, `manage`, `dialogue`, `debug`, `cards`, `schematic`, `book`).
3. **2x Hi-Res UI canvas (`640x360`):** Renders dense management UI at 2x resolution using the **mixed-case proportional bitmap font** (`src/game/ui/propFont.ts`).

## Input v2 & Reusable Components (`src/game/ui/`)

- **`ui/input.ts` (`InputManager`):** Tracks 2x UI, 1x UI, and world pointer coordinates; hover, left/right/double click, world drag-select box, wheel consumption, remappable keyboard `ActionId`s, and HTML5 Gamepad polling into the same screen stack.
- **`ui/components.ts`:** `hiButton`, `hiToggle`, `hiSlider`, `hiTabs`, `hiScrollList`, `hiTable` (sortable columns), `hiGraph` (sparklines), `hiModal`, `TooltipHost`, and right-click `ContextMenu`.
- **`ui/notifications.ts` (`NotificationFeed`):** Live clickable toast stack, expandable history drawer, jump-to-location metadata, and **pause-on-alert** rules.

## Settings & Accessibility (`src/game/settings.ts`, `screens/settingsModal.ts`)

- Volume buses (`master`, `sfx`, `ambient`) wired into `Sfx` (`audio.ts`).
- `screenShake` and `screenFlash` toggles, `uiScale`, key remapping, and color-blind-safe overlay palettes (`default`, `deuteranopia`, `protanopia`, `tritanopia`, `highContrast` in `content/vision.ts`).
- Central `registerSetting()` registry so future phases add options in one place.
