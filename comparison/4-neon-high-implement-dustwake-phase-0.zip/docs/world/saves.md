# Save System v2 & Migrations

## Format (`src/game/world/save.ts`, `SAVE_VERSION = 20`)

A save is plain JSON containing:
- World scalars: `version`, `seed`, `rng`, `time`, `playTime`, `day`, `flags`, `playerId`, `scheduled`, `monologue`.
- `actors` verbatim (including in-progress `task`, `queue`, `inventory`, `gear`, `job`, `person`, `life`, `keeper`).
- `specs` (optional): dynamic `AreaSpec` records for runtime-generated areas.
- `areaLastTicked` (optional): last simulated `world.time` for Far areas (omitted for up-to-date active areas).
- `areas`: per-area diff against its deterministic builder (`tiles`, `props`, `propsAdded`, `propsRemoved`, `looseTaken`, `looseAdded`, `decalsAdded`, `ritual`).

### Run-Length Compressed Tile Grids (`tilesRle`)

When an area is marked `spec.playerBuilt` OR its changed tile fraction reaches `RLE_EDIT_THRESHOLD` (25%), `diffArea` automatically switches from sparse `[index, tile]` diffs to `encodeRle(grid)` (`[tile, runLength, ...]`). `decodeRle` validates bounds and length on load.

### Migrations (v1 through v20)

- Every schema evolution increments `SAVE_VERSION` and adds a pure step in `MIGRATIONS[n]`.
- `migrate(raw)` chains sequentially up to `SAVE_VERSION` and rejects unknown future versions.
- **v19 -> v20:** Adds optional `specs`, `areaLastTicked`, and `tilesRle`; existing v19 saves load seamlessly without rewriting area diffs.

## Multi-Slot IndexedDB Store (`src/game/view/saveStore.ts`)

- Persists multiple slots (`autosave`, `slot-1`, `slot-2`, `slot-3`) in IndexedDB (`dustwake-saves-v2`), with automatic fallback to an injectable `MemorySaveBackend` for headless tests.
- **Rolling backups:** Every overwrite rotates up to 3 rolling backups (`bak:<slot>:1..3`) before writing the new envelope.
- **Integrity & corrupted-save recovery:** Every slot envelope carries an FNV-1a checksum (`checksumStr`). If `loadSlot` detects invalid JSON, checksum mismatch, or schema failure on the primary entry, it automatically recovers from the newest valid rolling backup and reports a recovery warning.
- **Autosave:** Runs on a configurable timer (`Settings.autosaveInterval`) and on area change (`Settings.autosaveOnAreaChange`).
- **Export / Import:** Saves can be downloaded as `.json` files and imported into any slot with full validation and migration.
