# Areas & Dynamic `AreaSpec`

## `Area` Runtime Model (`src/game/world/area.ts`)

Every area holds its mutable tile `grid`, `props`, `loose` items, `decals`, `ritual`, `lastTicked` timestamp, and optional `spec`.

- **Mutation invariant:** Every change goes through `Area` methods, which bump dependency-specific revisions (`revision`, `layoutRevision`, `interactionRevision`, `storageRevision`) and emit dirty `TileRect`s for localized background re-baking in `AreaView`.
- **Authored areas (`src/game/world/areas.ts`):** `dungeon`, `surface`, `town`, and six `town_*` shop interiors are built deterministically by static builder functions.

## Dynamic Runtime Areas (`src/game/world/areaSpec.ts`, Phase 0.3)

Multi-floor dungeons, caves, outposts, and wilds are created at runtime via `AreaSpec`:

```ts
export interface AreaSpec {
  id: string;
  kind: "authored" | "dungeon_floor" | "cavern" | "outpost" | "wilds";
  seed: number;
  w: number;
  h: number;
  parent?: string;
  depth: number;
  label?: string;
  playerBuilt?: boolean;
}
```

- `World.specs` stores all runtime `AreaSpec`s and persists them in `SaveData.specs`.
- `createDynamicArea(world, opts)` allocates a unique id, registers the `AreaSpec`, and builds it deterministically through `AREA_KIND_BUILDERS[spec.kind]`.
- `getArea(world, id)` checks `world.areas`, then `world.specs`, then static `AREAS`.
- Authored & lightly-edited dynamic areas save as sparse diffs against their deterministic builder; player-built or heavily-edited areas save as RLE-compressed full tile grids (`tilesRle`).
