// Bulk operations. Each takes the model plus the already-selected layers and
// edits the in-memory scene. They return `{ changes, skipped }`; persisting is
// the caller's job (so every operation supports dry runs for free).
//
// Edits mirror what Koharu's own editor does: the touched component is stamped
// as user-authored and the layer + its text content are promoted to user origin,
// which protects them from being overwritten by a later pipeline run.

import { ENUMS, KIND, USER, encodeComponent } from "./codec.js";
import { boundsOf, comp, hex, promote, removeComp, round, setComp } from "./model.js";

// ------------------------------------------------------------------- utilities

const NAMED_COLORS = {
  black: [0, 0, 0, 255],
  white: [255, 255, 255, 255],
  red: [255, 0, 0, 255],
  green: [0, 128, 0, 255],
  blue: [0, 0, 255, 255],
  yellow: [255, 255, 0, 255],
  gray: [128, 128, 128, 255],
  grey: [128, 128, 128, 255],
  transparent: [0, 0, 0, 0],
};

/** Accepts "#rgb", "#rrggbb", "#rrggbbaa", names, or [r,g,b,(a)]. */
export function parseColor(value) {
  if (value === null) return null;
  if (Array.isArray(value)) {
    if (value.length < 3 || value.length > 4 || value.some((v) => !Number.isInteger(v) || v < 0 || v > 255)) {
      throw new Error("color arrays must be [r,g,b] or [r,g,b,a] with integers 0-255");
    }
    return value.length === 3 ? [...value, 255] : [...value];
  }
  if (typeof value === "string") {
    const named = NAMED_COLORS[value.trim().toLowerCase()];
    if (named) return [...named];
    let h = value.trim().replace(/^#/, "");
    if (/^[0-9a-f]{3,4}$/i.test(h)) h = [...h].map((c) => c + c).join("");
    if (/^[0-9a-f]{6}$/i.test(h)) h += "ff";
    if (/^[0-9a-f]{8}$/i.test(h)) return [0, 2, 4, 6].map((i) => parseInt(h.slice(i, i + 2), 16));
  }
  throw new Error(`Invalid color ${JSON.stringify(value)}. Use "#rrggbb", "#rrggbbaa", a name, or [r,g,b,a].`);
}

const finite = (n, name) => {
  if (typeof n !== "number" || !Number.isFinite(n)) throw new Error(`${name} must be a finite number`);
  return n;
};

const clone = (v) => structuredClone(v);

const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);

function diffFields(before, after, keys) {
  const out = {};
  for (const k of keys) {
    if (!same(before?.[k] ?? null, after?.[k] ?? null)) {
      const show = (v) => (k.endsWith("color") ? hex(v) : typeof v === "number" ? round(v) : (v ?? null));
      out[k] = { from: show(before?.[k]), to: show(after?.[k]) };
    }
  }
  return out;
}

function record(layer, extra) {
  return { layer: layer.id, page: layer.page.number, order: layer.order, ...extra };
}

// ------------------------------------------------------------------ typography

const TYPO_KEYS = [
  "preferred_font",
  "font_weight",
  "font_style",
  "size",
  "auto_fit",
  "color",
  "stroke_color",
  "stroke_width",
  "stroke_method",
  "stroke_position",
  "stroke_join",
  "outer_stroke_color",
  "outer_stroke_width",
  "alignment",
  "writing_mode",
  "line_spacing",
];

const ALIASES = {
  font: "preferred_font",
  font_family: "preferred_font",
  weight: "font_weight",
  style: "font_style",
  font_size: "size",
  text_color: "color",
  fill: "color",
  outline_color: "stroke_color",
  outline_width: "stroke_width",
  autofit: "auto_fit",
  direction: "writing_mode",
  leading: "line_spacing",
};

const ENUM_FOR = {
  font_style: ENUMS.fontStyle,
  alignment: ENUMS.alignment,
  writing_mode: ENUMS.writingMode,
  stroke_method: ENUMS.strokeMethod,
  stroke_position: ENUMS.strokePosition,
  stroke_join: ENUMS.strokeJoin,
};

export function baseTypography() {
  return {
    origin: USER,
    preferred_font: null,
    font_weight: null,
    font_style: null,
    size: null,
    auto_fit: true,
    color: null,
    stroke_color: null,
    stroke_width: null,
    alignment: null,
    writing_mode: null,
    extensions: {},
    stroke_method: null,
    stroke_position: null,
    stroke_join: null,
    outer_stroke_color: null,
    outer_stroke_width: null,
    line_spacing: null,
    spans: [],
  };
}

/** Normalizes user input into a partial typography patch (absent = unchanged, null = clear). */
export function parseTypographyPatch(input = {}) {
  const patch = {};
  for (const [rawKey, value] of Object.entries(input)) {
    if (value === undefined) continue;
    const key = ALIASES[rawKey] ?? rawKey;
    if (!TYPO_KEYS.includes(key)) {
      throw new Error(`Unknown typography property "${rawKey}". Valid: ${TYPO_KEYS.join(", ")}`);
    }
    if (key === "auto_fit") {
      if (typeof value !== "boolean") throw new Error("auto_fit must be true or false");
      patch[key] = value;
    } else if (value === null) {
      patch[key] = null;
    } else if (key.endsWith("color")) {
      patch[key] = parseColor(value);
    } else if (ENUM_FOR[key]) {
      const e = ENUM_FOR[key];
      const v = String(value).toLowerCase();
      if (!e.variants.includes(v)) throw new Error(`${rawKey} must be one of ${e.variants.join(", ")}`);
      patch[key] = v;
    } else if (key === "preferred_font") {
      patch[key] = String(value);
    } else if (key === "font_weight") {
      if (!Number.isInteger(value) || value < 1 || value > 1000) throw new Error("font_weight must be an integer 1-1000");
      patch[key] = value;
    } else {
      patch[key] = finite(value, rawKey);
    }
  }
  if (patch.size !== undefined && patch.size !== null && patch.size <= 0) throw new Error("size must be greater than 0");
  for (const k of ["stroke_width", "outer_stroke_width"]) {
    if (patch[k] !== undefined && patch[k] !== null && patch[k] < 0) throw new Error(`${k} must be 0 or more`);
  }
  if (patch.line_spacing !== undefined && patch.line_spacing !== null && (patch.line_spacing < 0.1 || patch.line_spacing > 10)) {
    throw new Error("line_spacing must be between 0.1 and 10 (multiple of the font size)");
  }
  if (patch.size === null && patch.auto_fit === false) throw new Error("Cannot clear size while turning auto_fit off.");
  return patch;
}

function checkTypography(t) {
  if (!t.auto_fit && (t.size === null || t.size === undefined)) {
    throw new Error("fixed-size text needs a size (auto_fit is off and no size is set)");
  }
}

/**
 * Pipeline-generated typography carries an *inferred* writing_mode (detected from the source text).
 * Koharu ignores it unless the component's origin is User. Because every write here re-stamps the
 * origin as User, an untouched inferred mode (often "vertical") would silently become an authored
 * override. Drop it unless the caller explicitly set/copied writing_mode.
 */
function releaseInferredWritingMode(before, next, explicit = false) {
  if (explicit || !before || before.origin?.kind === "user") return;
  if (next.writing_mode === before.writing_mode) next.writing_mode = null;
}

function writeTypography(model, layer, next, { writingModeExplicit = false } = {}) {
  releaseInferredWritingMode(layer.typography, next, writingModeExplicit);
  checkTypography(next);
  next.origin = USER;
  setComp(layer.entity, encodeComponent(KIND.TYPOGRAPHY, next, comp(layer.entity, KIND.TYPOGRAPHY)));
  layer.typography = next;
  promote(model, layer);
}

/** Applies a typography patch to each layer. A size without `auto_fit` implies fixed size. */
export function setTypography(model, layers, rawPatch) {
  const patch = parseTypographyPatch(rawPatch);
  if (!Object.keys(patch).length) throw new Error("No typography properties given.");
  if (patch.size !== undefined && patch.size !== null && patch.auto_fit === undefined) patch.auto_fit = false;
  const changes = [];
  const skipped = [];
  for (const layer of layers) {
    const before = layer.typography;
    const next = before ? clone(before) : baseTypography();
    Object.assign(next, patch);
    releaseInferredWritingMode(before, next, "writing_mode" in patch);
    try {
      checkTypography(next);
    } catch (error) {
      skipped.push({ layer: layer.id, page: layer.page.number, reason: `${error.message}; include "size" to apply` });
      continue;
    }
    const diff = diffFields(before ?? baseTypography(), next, TYPO_KEYS);
    if (!Object.keys(diff).length && before) continue;
    writeTypography(model, layer, next, { writingModeExplicit: "writing_mode" in patch });
    changes.push(record(layer, { typography: diff }));
  }
  return { changes, skipped };
}

/** Multiplies and/or offsets explicit font sizes. */
export function scaleFontSize(model, layers, { factor, delta, min, max, round_to }) {
  if (factor === undefined && delta === undefined) throw new Error("Provide `factor` and/or `delta`.");
  if (factor !== undefined && !(finite(factor, "factor") > 0)) throw new Error("factor must be greater than 0");
  const places = round_to ?? 2;
  const changes = [];
  const skipped = [];
  for (const layer of layers) {
    const t = layer.typography;
    if (!t || t.size === null) {
      skipped.push({ layer: layer.id, page: layer.page.number, reason: "no explicit size (auto-fit text); use set_typography with size to pin one" });
      continue;
    }
    let size = t.size * (factor ?? 1) + (delta ?? 0);
    if (min !== undefined) size = Math.max(size, min);
    if (max !== undefined) size = Math.min(size, max);
    size = Math.max(0.1, round(size, places));
    if (Math.abs(size - t.size) < 1e-4) continue;
    const next = clone(t);
    next.size = size;
    writeTypography(model, layer, next);
    changes.push(record(layer, { typography: { size: { from: round(t.size), to: size } } }));
  }
  return { changes, skipped };
}

export function copyTypography(model, layers, from, fields) {
  const source = model.layers.find((l) => l.id === from || (from.length >= 6 && l.id.startsWith(from)));
  if (!source) throw new Error(`Source layer "${from}" not found.`);
  if (!source.typography) throw new Error("Source layer has no typography to copy.");
  const keys = fields?.length ? fields.map((f) => ALIASES[f] ?? f) : TYPO_KEYS;
  for (const k of keys) if (!TYPO_KEYS.includes(k)) throw new Error(`Unknown typography property "${k}"`);
  const changes = [];
  for (const layer of layers) {
    if (layer.id === source.id) continue;
    const before = layer.typography;
    const next = before ? clone(before) : baseTypography();
    for (const k of keys) next[k] = clone(source.typography[k]);
    // A non-user source's writing_mode is inferred, not authored: don't turn it into an override.
    if (keys.includes("writing_mode") && source.typography.origin?.kind !== "user") next.writing_mode = null;
    releaseInferredWritingMode(before, next, keys.includes("writing_mode"));
    const diff = diffFields(before ?? baseTypography(), next, TYPO_KEYS);
    if (!Object.keys(diff).length && before) continue;
    writeTypography(model, layer, next, { writingModeExplicit: keys.includes("writing_mode") });
    changes.push(record(layer, { typography: diff }));
  }
  return { changes, skipped: [] };
}

export function resetTypography(model, layers) {
  const changes = [];
  for (const layer of layers) {
    if (!layer.typography) continue;
    removeComp(layer.entity, KIND.TYPOGRAPHY);
    layer.typography = null;
    promote(model, layer);
    changes.push(record(layer, { typography: "removed (renderer defaults apply)" }));
  }
  return { changes, skipped: [] };
}

// ------------------------------------------------------------------ geometry

function pageBox(layer) {
  return { w: layer.page.width, h: layer.page.height };
}

function writeFrame(model, layer, points) {
  for (const p of points) {
    if (!Number.isFinite(p.x) || !Number.isFinite(p.y)) throw new Error("geometry must be finite");
  }
  const geometry = { origin: USER, points };
  setComp(layer.entity, encodeComponent(KIND.GEOMETRY, geometry, comp(layer.entity, KIND.GEOMETRY)));
  layer.ownGeometry = geometry;
  layer.frame = points;
  layer.frameFrom = "own";
  promote(model, layer);
}

/** Shifts points back inside the page when a move pushed them out. */
function clampInside(points, { w, h }) {
  const [l, t, r, b] = boundsOf(points);
  let dx = 0;
  let dy = 0;
  if (r - l <= w) {
    if (l < 0) dx = -l;
    else if (r > w) dx = w - r;
  } else dx = -l;
  if (b - t <= h) {
    if (t < 0) dy = -t;
    else if (b > h) dy = h - b;
  } else dy = -t;
  return points.map((p) => ({ x: p.x + dx, y: p.y + dy }));
}

function frameChange(layer, before, after) {
  const fmt = (pts) => boundsOf(pts).map((v) => round(v, 1));
  return record(layer, { bounds: { from: fmt(before), to: fmt(after) } });
}

const MOVED_EPS = 0.01;
const movedEnough = (a, b) => a.some((p, i) => Math.abs(p.x - b[i].x) > MOVED_EPS || Math.abs(p.y - b[i].y) > MOVED_EPS);

function applyFrameEdit(model, layers, transform, keepInside) {
  const changes = [];
  const skipped = [];
  for (const layer of layers) {
    if (!layer.frame) {
      skipped.push({ layer: layer.id, page: layer.page.number, reason: "layer has no frame (no geometry and no fits-to/flows-in region)" });
      continue;
    }
    const before = layer.frame.map((p) => ({ x: p.x, y: p.y }));
    let after = transform(before, layer);
    if (keepInside !== false) after = clampInside(after, pageBox(layer));
    if (!movedEnough(before, after)) continue;
    writeFrame(model, layer, after);
    changes.push(frameChange(layer, before, after));
  }
  return { changes, skipped };
}

// Rough glyph advance (in em) for wrapping estimates; the real layout uses the actual font.
function glyphEm(ch) {
  if (/[\u1100-\u11ff\u3000-\u9fff\uac00-\ud7af\uff00-\uffef]/u.test(ch)) return 1;
  if (ch === " ") return 0.28;
  if (/[.,!?'"`:;\-–—…]/u.test(ch)) return 0.32;
  if (/\p{Lu}|\d/u.test(ch)) return 0.68; // comic fonts are wide
  return 0.54;
}

/**
 * Koharu centres the laid-out text block inside its frame on both axes, and fixed-size text that
 * does not fit simply spills out equally on both sides. The project file does not store the rendered
 * size, so this estimates it (average glyph widths, greedy word wrap, line height = size x
 * line_spacing, default 1.2). Returns the estimated on-page box [l, t, r, b], or null when the frame is
 * trusted as-is (auto-fit text, no size/text, or the estimate fits inside the frame).
 */
function estimateTextBox(layer) {
  const t = layer.typography;
  const text = layer.translation?.text ?? layer.source?.text;
  if (!t || t.auto_fit || !t.size || !text || !layer.frame) return null;
  const [l, tp, r, b] = boundsOf(layer.frame);
  const fw = r - l;
  const fh = b - tp;
  const size = t.size;
  const lineH = size * (t.line_spacing ?? 1.2);
  const vertical = t.writing_mode === "vertical" && t.origin?.kind === "user";
  const inline = Math.max(size, vertical ? fh : fw);
  let lines = 0;
  for (const hard of text.split(/\r?\n/)) {
    if (vertical) {
      lines += Math.max(1, Math.ceil(Array.from(hard).length / Math.max(1, Math.floor(inline / size))));
      continue;
    }
    let width = 0;
    let n = 1;
    for (const word of hard.split(/(?<= )/u)) {
      const wordW = Array.from(word).reduce((sum, ch) => sum + glyphEm(ch) * size, 0);
      if (width > 0 && width + wordW > inline + 1e-6 && word.trim() !== "") {
        n++;
        width = wordW;
      } else width += wordW;
    }
    lines += n;
  }
  const pad = 2 * ((t.stroke_width ?? 0) + (t.outer_stroke_width ?? 0));
  const block = lines * lineH + pad;
  const cx = (l + r) / 2;
  const cy = (tp + b) / 2;
  if (vertical) {
    if (block <= fw + 1) return null;
    return [cx - block / 2, tp, cx + block / 2, b];
  }
  if (block <= fh + 1) return null;
  return [l, cy - block / 2, r, cy + block / 2];
}

/**
 * Nudges text so that all of it is visible on the page, by the smallest move that does the job (a box
 * 1/4 off the left edge shifts right by exactly that quarter). It checks the frame and, for fixed-size
 * text that is too big for its frame, the estimated spill-over too (see estimateTextBox; turn off with
 * `check_text_overflow: false`). Things already fully inside are not touched. `margin` keeps a gap from
 * the page edges. If the box (or text) is larger than the usable page on an axis it cannot fit: it is
 * centred on that axis and reported in `skipped`.
 */
export function fitTextInPage(model, layers, { margin = 0, check_text_overflow = true } = {}) {
  finite(margin, "margin");
  if (margin < 0) throw new Error("margin must be 0 or more");
  const oversized = [];
  const result = applyFrameEdit(
    model,
    layers,
    (points, layer) => {
      const { w, h } = pageBox(layer);
      let [l, t, r, b] = boundsOf(points);
      let textBox = false;
      const est = check_text_overflow ? estimateTextBox(layer) : null;
      if (est) {
        [l, t, r, b] = [Math.min(l, est[0]), Math.min(t, est[1]), Math.max(r, est[2]), Math.max(b, est[3])];
        textBox = true;
      }
      const axis = (lo, hi, size) => {
        const room = size - 2 * margin;
        if (hi - lo > room) return { d: (size - (hi - lo)) / 2 - lo, big: true };
        if (lo < margin) return { d: margin - lo, big: false };
        if (hi > size - margin) return { d: size - margin - hi, big: false };
        return { d: 0, big: false };
      };
      const x = axis(l, r, w);
      const y = axis(t, b, h);
      if (x.big || y.big) oversized.push({ layer, textBox, axes: [x.big && "width", y.big && "height"].filter(Boolean) });
      return points.map((p) => ({ x: p.x + x.d, y: p.y + y.d }));
    },
    false,
  );
  for (const { layer, textBox, axes } of oversized) {
    result.skipped.push({
      layer: layer.id,
      page: layer.page.number,
      reason: textBox
        ? `estimated text is larger than the page ${axes.join(" and ")} at this size; centered instead of fully fitted (lower the font size, or set auto_fit:true)`
        : `frame is larger than the page ${axes.join(" and ")}; centered instead of fully fitted (shrink it with set_frame)`,
    });
  }
  return result;
}

/** Moves frames by dx/dy (pixels, or percent of page size with unit="percent"). */
export function moveText(model, layers, { dx = 0, dy = 0, unit = "px", keep_inside_page }) {
  finite(dx, "dx");
  finite(dy, "dy");
  if (!["px", "percent"].includes(unit)) throw new Error('unit must be "px" or "percent"');
  return applyFrameEdit(
    model,
    layers,
    (pts, layer) => {
      const { w, h } = pageBox(layer);
      const mx = unit === "percent" ? (dx / 100) * w : dx;
      const my = unit === "percent" ? (dy / 100) * h : dy;
      return pts.map((p) => ({ x: p.x + mx, y: p.y + my }));
    },
    keep_inside_page,
  );
}

/**
 * Sets an exact frame. Any of x/y/width/height may be omitted (kept as is).
 * scale_x/scale_y resize relative to the current size. `anchor` picks which point
 * of the box x/y refer to and which point stays fixed while resizing.
 */
export function setFrame(model, layers, p) {
  const { x, y, width, height, scale_x, scale_y, scale, anchor = "top-left", keep_inside_page } = p;
  const anchors = {
    "top-left": [0, 0],
    top: [0.5, 0],
    "top-right": [1, 0],
    left: [0, 0.5],
    center: [0.5, 0.5],
    right: [1, 0.5],
    "bottom-left": [0, 1],
    bottom: [0.5, 1],
    "bottom-right": [1, 1],
  };
  const a = anchors[anchor];
  if (!a) throw new Error(`anchor must be one of ${Object.keys(anchors).join(", ")}`);
  for (const [k, v] of Object.entries({ x, y, width, height, scale_x, scale_y, scale })) {
    if (v !== undefined) finite(v, k);
  }
  if ([width, height, scale_x, scale_y, scale].some((v) => v !== undefined && v <= 0)) {
    throw new Error("width, height and scale values must be greater than 0");
  }
  if ([x, y, width, height, scale_x, scale_y, scale].every((v) => v === undefined)) {
    throw new Error("Provide at least one of x, y, width, height, scale, scale_x, scale_y.");
  }
  return applyFrameEdit(
    model,
    layers,
    (pts) => {
      const [l, t, r, b] = boundsOf(pts);
      const bw = r - l;
      const bh = b - t;
      const nw = width ?? bw * (scale_x ?? scale ?? 1);
      const nh = height ?? bh * (scale_y ?? scale ?? 1);
      const sx = bw > 0 ? nw / bw : 1;
      const sy = bh > 0 ? nh / bh : 1;
      const ax = l + bw * a[0];
      const ay = t + bh * a[1];
      // Scale about the anchor, then move the anchor to the requested x/y.
      const tx = x !== undefined ? x - ax : 0;
      const ty = y !== undefined ? y - ay : 0;
      return pts.map((q) => ({ x: ax + (q.x - ax) * sx + tx, y: ay + (q.y - ay) * sy + ty }));
    },
    keep_inside_page,
  );
}

/** Aligns frames to the page: horizontal left|center|right, vertical top|middle|bottom. */
export function alignToPage(model, layers, { horizontal, vertical, margin = 0 }) {
  if (!horizontal && !vertical) throw new Error("Provide `horizontal` and/or `vertical`.");
  if (horizontal && !["left", "center", "right"].includes(horizontal)) throw new Error("horizontal must be left|center|right");
  if (vertical && !["top", "middle", "bottom"].includes(vertical)) throw new Error("vertical must be top|middle|bottom");
  return applyFrameEdit(
    model,
    layers,
    (pts, layer) => {
      const { w, h } = pageBox(layer);
      const [l, t, r, b] = boundsOf(pts);
      let dx = 0;
      let dy = 0;
      if (horizontal === "left") dx = margin - l;
      if (horizontal === "right") dx = w - margin - r;
      if (horizontal === "center") dx = (w - (r - l)) / 2 - l;
      if (vertical === "top") dy = margin - t;
      if (vertical === "bottom") dy = h - margin - b;
      if (vertical === "middle") dy = (h - (b - t)) / 2 - t;
      return pts.map((q) => ({ x: q.x + dx, y: q.y + dy }));
    },
    false,
  );
}

/** Drops a manual frame so the layer follows its detected region again. */
export function resetFrame(model, layers) {
  const changes = [];
  const skipped = [];
  for (const layer of layers) {
    if (!layer.ownGeometry) continue;
    const hasRegion = model.relations.has(`${KIND.REL_FITS_TO}|${layer.id}`) || model.relations.has(`${KIND.REL_FLOWS_IN}|${layer.id}`);
    if (!hasRegion) {
      skipped.push({ layer: layer.id, page: layer.page.number, reason: "no detected region to fall back to; keeping manual frame" });
      continue;
    }
    const before = layer.frame;
    removeComp(layer.entity, KIND.GEOMETRY);
    layer.ownGeometry = null;
    promote(model, layer);
    changes.push(record(layer, { frame: `manual frame removed (was ${boundsOf(before).map((v) => round(v, 1))})` }));
  }
  return { changes, skipped };
}

/** Sets (or, with relative=true, adds to) the layout rotation in degrees. */
export function setAngle(model, layers, { degrees, relative = false }) {
  finite(degrees, "degrees");
  const changes = [];
  for (const layer of layers) {
    const before = layer.layout;
    let angle = relative ? (before.angle_degrees ?? 0) + degrees : degrees;
    angle = round(((angle + 180) % 360 + 360) % 360 - 180, 3);
    if (Math.abs((before.angle_degrees ?? 0) - angle) < 1e-4) continue;
    const next = { ...before, origin: USER, angle_degrees: angle };
    setComp(layer.entity, encodeComponent(KIND.TEXT_LAYOUT, next, comp(layer.entity, KIND.TEXT_LAYOUT)));
    layer.layout = next;
    promote(model, layer);
    changes.push(record(layer, { angle: { from: round(before.angle_degrees ?? 0, 2), to: angle } }));
  }
  return { changes, skipped: [] };
}

// ---------------------------------------------------------------- visibility

export function setVisibility(model, layers, { visible, opacity }) {
  if (visible === undefined && opacity === undefined) throw new Error("Provide `visible` and/or `opacity`.");
  if (opacity !== undefined && (!Number.isFinite(opacity) || opacity < 0 || opacity > 1)) {
    throw new Error("opacity must be between 0 and 1");
  }
  const changes = [];
  for (const layer of layers) {
    const before = layer.visibility ?? { origin: USER, visible: true, opacity: 1 };
    const next = { origin: USER, visible: visible ?? before.visible, opacity: opacity ?? before.opacity };
    if (layer.visibility && next.visible === before.visible && Math.abs(next.opacity - before.opacity) < 1e-6) continue;
    if (!layer.visibility && next.visible && next.opacity === 1) continue;
    setComp(layer.entity, encodeComponent(KIND.VISIBILITY, next, comp(layer.entity, KIND.VISIBILITY)));
    layer.visibility = next;
    promote(model, layer);
    changes.push(
      record(layer, {
        visibility: diffFields(before, next, ["visible", "opacity"]),
      }),
    );
  }
  return { changes, skipped: [] };
}

// ---------------------------------------------------------------------- text

function validateText(text) {
  if (typeof text !== "string") throw new Error("text must be a string");
  if (text.includes("\0")) throw new Error("text must not contain NUL characters");
  if (Buffer.byteLength(text) > 16 * 1024 * 1024) throw new Error("text is too large");
}

/** Carries per-word style spans across a translation edit (mirrors Koharu's TextStyleSpan::remap). */
export function remapSpans(spans, oldText, newText) {
  if (!spans?.length || oldText === newText) return spans ?? [];
  const o = Array.from(oldText);
  const n = Array.from(newText);
  let prefix = 0;
  while (prefix < o.length && prefix < n.length && o[prefix] === n[prefix]) prefix++;
  let suffix = 0;
  while (
    suffix < o.length - prefix &&
    suffix < n.length - prefix &&
    o[o.length - 1 - suffix] === n[n.length - 1 - suffix]
  ) suffix++;
  const oldEnd = o.length - suffix;
  const newEnd = n.length - suffix;
  const map = (pos, isEnd) => {
    if (pos <= prefix) return pos;
    if (pos >= oldEnd) return pos - oldEnd + newEnd;
    return isEnd ? prefix : newEnd;
  };
  const styleKeys = ["preferred_font", "font_weight", "font_style", "color", "stroke_color", "stroke_width"];
  const plain = (sp) => styleKeys.every((k) => sp[k] === null || sp[k] === undefined);
  const same = (a, b) => styleKeys.every((k) => JSON.stringify(a[k] ?? null) === JSON.stringify(b[k] ?? null));
  const remapped = [];
  for (const sp of spans) {
    const start = map(sp.start, false);
    const end = map(sp.end, true);
    if (start < end && !plain(sp)) remapped.push({ ...sp, start, end });
  }
  remapped.sort((a, b) => a.start - b.start || a.end - b.end);
  const merged = [];
  for (const sp of remapped) {
    const last = merged[merged.length - 1];
    if (last && last.end === sp.start && same(last, sp)) last.end = sp.end;
    else merged.push(sp);
  }
  return merged;
}

function writeText(model, layer, field, text) {
  const content = layer.contentEntity;
  if (!content) return { error: "layer has no text content entity" };
  const kind = field === "translation" ? KIND.TEXT_TRANSLATION : KIND.TEXT_SOURCE;
  const existing = field === "translation" ? layer.translation : layer.source;
  if (text === null) {
    if (field !== "translation") return { error: "source text cannot be removed" };
    if (!existing) return { unchanged: true };
    removeComp(content, kind);
    layer.translation = null;
    promote(model, layer);
    return { from: existing.text, to: null };
  }
  validateText(text);
  if (field === "translation" && !layer.source) return { error: "layer has no source text; a translation requires one" };
  if (existing && existing.text === text) return { unchanged: true };
  const next = { text, origin: USER, language: existing?.language ?? null };
  setComp(content, encodeComponent(kind, next, comp(content, kind)));
  if (field === "translation") layer.translation = next;
  else layer.source = next;
  if (field === "translation" && layer.typography?.spans?.length) {
    const spans = remapSpans(layer.typography.spans, existing?.text ?? "", text);
    writeTypography(model, layer, { ...layer.typography, spans });
  }
  promote(model, layer);
  return { from: existing?.text ?? null, to: text };
}

const clipText = (s) => (s && s.length > 160 ? `${s.slice(0, 159)}…` : s);

/** Explicit per-layer text edits: [{ layer, translation?, source? }]. */
export function setTexts(model, edits) {
  if (!Array.isArray(edits) || !edits.length) throw new Error("`edits` must be a non-empty array of { layer, translation?, source? }");
  const changes = [];
  const skipped = [];
  for (const edit of edits) {
    const ref = String(edit.layer ?? "");
    const matches = model.layers.filter((l) => l.id === ref || (ref.length >= 6 && l.id.startsWith(ref)));
    if (matches.length !== 1) {
      skipped.push({ layer: ref, reason: matches.length ? "ambiguous id prefix" : "no such text layer" });
      continue;
    }
    const layer = matches[0];
    const diff = {};
    for (const field of ["source", "translation"]) {
      if (edit[field] === undefined) continue;
      const result = writeText(model, layer, field, edit[field]);
      if (result.error) skipped.push({ layer: layer.id, page: layer.page.number, reason: `${field}: ${result.error}` });
      else if (!result.unchanged) diff[field] = { from: clipText(result.from), to: clipText(result.to) };
    }
    if (Object.keys(diff).length) changes.push(record(layer, { text: diff }));
  }
  return { changes, skipped };
}

function buildMatcher({ find, regex = false, case_sensitive = false, whole_word = false }) {
  if (typeof find !== "string" || find === "") throw new Error("`find` must be a non-empty string");
  const escaped = regex ? find : find.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const source = whole_word ? `\\b${escaped}\\b` : escaped;
  try {
    return new RegExp(source, `g${case_sensitive ? "" : "i"}u`);
  } catch (error) {
    throw new Error(`Invalid pattern: ${error.message}`);
  }
}

/** Find & replace across the selected layers' translation (default), source, or both. */
export function replaceText(model, layers, params) {
  const { replace, field = "translation" } = params;
  if (typeof replace !== "string") throw new Error("`replace` must be a string");
  if (!["translation", "source", "both"].includes(field)) throw new Error("field must be translation|source|both");
  const re = buildMatcher(params);
  const fields = field === "both" ? ["translation", "source"] : [field];
  const changes = [];
  const skipped = [];
  for (const layer of layers) {
    const diff = {};
    let count = 0;
    for (const f of fields) {
      const current = f === "translation" ? layer.translation?.text : layer.source?.text;
      if (current === undefined || current === null) continue;
      re.lastIndex = 0;
      const matches = current.match(re)?.length ?? 0;
      if (!matches) continue;
      re.lastIndex = 0;
      const next = params.regex ? current.replace(re, replace) : current.replace(re, () => replace);
      if (next === current) continue;
      const result = writeText(model, layer, f, next);
      if (result.error) skipped.push({ layer: layer.id, page: layer.page.number, reason: result.error });
      else if (!result.unchanged) {
        diff[f] = { from: clipText(result.from), to: clipText(result.to) };
        count += matches;
      }
    }
    if (Object.keys(diff).length) changes.push(record(layer, { replacements: count, text: diff }));
  }
  return { changes, skipped };
}

const TITLE = (s) => s.toLowerCase().replace(/(^|[\s"'(\-—])(\p{L})/gu, (_, a, b) => a + b.toUpperCase());
const SENTENCE = (s) => s.toLowerCase().replace(/(^\s*|[.!?…]\s+)(\p{L})/gu, (_, a, b) => a + b.toUpperCase());
const TRANSFORMS = {
  uppercase: (s) => s.toUpperCase(),
  lowercase: (s) => s.toLowerCase(),
  title_case: TITLE,
  sentence_case: SENTENCE,
  trim: (s) => s.trim(),
  collapse_whitespace: (s) => s.replace(/[ \t]+/g, " ").replace(/ *\n */g, "\n").trim(),
  join_lines: (s) => s.replace(/\s*\n\s*/g, " "),
};

export const TEXT_TRANSFORMS = Object.keys(TRANSFORMS);

export function transformText(model, layers, { mode, field = "translation" }) {
  const fn = TRANSFORMS[mode];
  if (!fn) throw new Error(`mode must be one of ${TEXT_TRANSFORMS.join(", ")}`);
  if (!["translation", "source"].includes(field)) throw new Error("field must be translation|source");
  const changes = [];
  const skipped = [];
  for (const layer of layers) {
    const current = field === "translation" ? layer.translation?.text : layer.source?.text;
    if (!current) continue;
    const result = writeText(model, layer, field, fn(current));
    if (result.error) skipped.push({ layer: layer.id, page: layer.page.number, reason: result.error });
    else if (!result.unchanged) changes.push(record(layer, { text: { [field]: { from: clipText(result.from), to: clipText(result.to) } } }));
  }
  return { changes, skipped };
}

// ------------------------------------------------------------------ analytics

const tally = (map, key) => map.set(key, (map.get(key) ?? 0) + 1);
const sorted = (map) =>
  Object.fromEntries([...map.entries()].sort((a, b) => b[1] - a[1]).map(([k, v]) => [String(k), v]));

export function statistics(model, layers) {
  const sizes = new Map();
  const fonts = new Map();
  const colors = new Map();
  const alignments = new Map();
  const modes = new Map();
  const frames = new Map();
  let translated = 0;
  let hidden = 0;
  let autoFit = 0;
  let noTypography = 0;
  let noSize = 0;
  for (const l of layers) {
    const t = l.typography;
    if (l.translation?.text) translated++;
    if (l.visibility && !l.visibility.visible) hidden++;
    if (!t) noTypography++;
    else if (t.auto_fit) autoFit++;
    // Layers without typography use renderer defaults, so they count as "unset"/"default".
    tally(sizes, t?.size == null ? "unset" : round(t.size, 2));
    tally(fonts, t?.preferred_font ?? "default");
    tally(colors, hex(t?.color ?? null) ?? "default");
    tally(alignments, t?.alignment ?? "default");
    tally(modes, t?.writing_mode ?? "default");
    if (t && t.size === null) noSize++;
    tally(frames, l.frameFrom);
  }
  return {
    text_layers: layers.length,
    translated,
    untranslated: layers.length - translated,
    hidden,
    auto_fit_layers: autoFit,
    layers_without_typography: noTypography,
    layers_without_explicit_size: noSize + noTypography,
    sizes: sorted(sizes),
    fonts: sorted(fonts),
    colors: sorted(colors),
    alignments: sorted(alignments),
    writing_modes: sorted(modes),
    frame_sources: sorted(frames),
  };
}


// -------------------------------------------------------------------- overlaps
//
// Text boxes that sit too close together (or even on top of each other) are a common typesetting
// problem after font sizes grow. `findOverlaps` lets an agent *see* which layers collide and what
// they say; `resolveTextOverlaps` pushes them apart, either automatically (the later layer in
// reading order gives way) or following the agent's explicit per-pair decisions.
//
// A layer's occupied box is its frame, widened by the estimated text spill-over for fixed-size text
// that is too big for its frame (same estimate fit_text_in_page uses). Rotation is not modelled.

const OVERLAP_EPS = 0.01;
const DIRECTIONS = ["left", "right", "up", "down"];
const MAX_PUSHES_PER_LAYER = 24;
const MAX_PAIRS_SHOWN = 50;

function occupiedBox(layer, checkOverflow) {
  const frame = boundsOf(layer.frame);
  const est = checkOverflow ? estimateTextBox(layer) : null;
  if (!est) return frame;
  return [Math.min(frame[0], est[0]), Math.min(frame[1], est[1]), Math.max(frame[2], est[2]), Math.max(frame[3], est[3])];
}

/** Intersection of two boxes; with `margin`, boxes closer than that also count. Returns null when clear. */
function overlapOf(a, b, margin = 0) {
  const width = Math.min(a[2], b[2]) - Math.max(a[0], b[0]);
  const height = Math.min(a[3], b[3]) - Math.max(a[1], b[1]);
  if (width + margin <= OVERLAP_EPS || height + margin <= OVERLAP_EPS) return null;
  return { width, height };
}

const overlapArea = (o) => Math.max(0, o.width) * Math.max(0, o.height);

const shiftBox = (b, dx, dy) => [b[0] + dx, b[1] + dy, b[2] + dx, b[3] + dy];

const overflowOf = (b, { w, h }) => Math.max(0, -b[0]) + Math.max(0, b[2] - w) + Math.max(0, -b[1]) + Math.max(0, b[3] - h);

/** Every way to move box `m` clear of box `k` (one per direction), filtered by axis/direction. */
function pushOptions(m, k, margin, axis = "auto", direction) {
  const all = [
    { direction: "right", dx: k[2] + margin - m[0], dy: 0 },
    { direction: "left", dx: -(m[2] - (k[0] - margin)), dy: 0 },
    { direction: "down", dx: 0, dy: k[3] + margin - m[1] },
    { direction: "up", dx: 0, dy: -(m[3] - (k[1] - margin)) },
  ];
  const horizontal = (o) => o.direction === "left" || o.direction === "right";
  return all
    .filter((o) => axis === "auto" || (axis === "horizontal") === horizontal(o))
    .filter((o) => !direction || o.direction === direction)
    .map((o) => ({ ...o, distance: Math.abs(o.dx || o.dy) }))
    .filter((o) => o.distance > OVERLAP_EPS);
}

/** Limits a move so it never carries a box further out of the page. */
function clampMove(box, dx, dy, { w, h }) {
  const axis = (lo, hi, d, size) => (d > 0 ? Math.min(d, Math.max(0, size - hi)) : Math.max(d, -Math.max(0, lo)));
  return { dx: axis(box[0], box[2], dx, w), dy: axis(box[1], box[3], dy, h) };
}

/**
 * Chooses how to move `m` away from `k`: prefer options that stay on the page, then ones that do not
 * bump into other boxes, then the shortest move. Returns null when no option exists.
 */
function pickPush(m, k, others, { margin, axis, direction, keepInside, page }) {
  const before = overflowOf(m, page);
  const scored = pushOptions(m, k, margin, axis, direction).map((o) => {
    const moved = shiftBox(m, o.dx, o.dy);
    const outside = keepInside && overflowOf(moved, page) > before + OVERLAP_EPS ? 1 : 0;
    const hits = others.filter((b) => overlapOf(moved, b, margin)).length;
    return { ...o, outside, hits };
  });
  scored.sort((a, b) => a.outside - b.outside || a.hits - b.hits || a.distance - b.distance);
  const best = scored[0];
  if (!best) return null;
  if (best.outside) {
    const c = clampMove(m, best.dx, best.dy, page);
    if (Math.abs(c.dx) + Math.abs(c.dy) <= OVERLAP_EPS) return null;
    return { ...best, dx: c.dx, dy: c.dy, distance: Math.abs(c.dx || c.dy), clamped: true };
  }
  return best;
}

const findLayerRef = (model, ref) => {
  const text = String(ref ?? "");
  const matches = model.layers.filter((l) => l.id === text || (text.length >= 6 && l.id.startsWith(text)));
  if (matches.length !== 1) {
    throw new Error(
      matches.length ? `Layer id prefix "${text}" is ambiguous.` : `No text layer with id "${text}". Use find_text_overlaps or list_text to get ids.`,
    );
  }
  return matches[0];
};

const layerText = (layer) => layer.translation?.text ?? layer.source?.text ?? "";

/** Layers that take part in overlap checks: on the selected pages, with a frame, visible. */
function overlapPool(model, layers, { include_hidden = false } = {}) {
  const pages = new Set(layers.map((l) => l.page.number));
  return model.layers.filter(
    (l) => pages.has(l.page.number) && l.frame && (include_hidden || !l.visibility || l.visibility.visible),
  );
}

function checkMargin(margin) {
  finite(margin, "margin");
  if (margin < 0) throw new Error("margin must be 0 or more");
}

function pairBrief(layer, box, frame) {
  const text = layerText(layer);
  const out = {
    id: layer.id,
    order: layer.order,
    text: clipText(text),
    ...(layer.translation?.text && layer.source?.text ? { source: clipText(layer.source.text) } : {}),
    size: round(layer.typography?.size ?? null),
    bounds: frame.map((v) => round(v, 1)),
  };
  if (box.some((v, i) => Math.abs(v - frame[i]) > 0.5)) out.text_bounds = box.map((v) => round(v, 1));
  return out;
}

/** All colliding pairs among `entries` ({ layer, box }) where at least one layer is in `selected`. */
function collectPairs(entries, selected, margin) {
  const pairs = [];
  for (let i = 0; i < entries.length; i++) {
    for (let j = i + 1; j < entries.length; j++) {
      const a = entries[i];
      const b = entries[j];
      if (a.layer.page.number !== b.layer.page.number) continue;
      if (!selected.has(a.layer.id) && !selected.has(b.layer.id)) continue;
      const overlap = overlapOf(a.box, b.box, margin);
      if (!overlap) continue;
      const [first, second] = a.layer.order <= b.layer.order ? [a, b] : [b, a];
      pairs.push({ first, second, overlap });
    }
  }
  pairs.sort((x, y) => x.first.layer.page.number - y.first.layer.page.number || x.first.layer.order - y.first.layer.order || x.second.layer.order - y.second.layer.order);
  return pairs;
}

/**
 * Read-only: lists pairs of text layers whose boxes overlap (or sit closer than `margin`), with the text
 * of both so a caller can decide which one should give way, plus what each push would cost.
 */
export function findOverlaps(model, layers, { margin = 0, check_text_overflow = true, include_hidden = false, limit = MAX_PAIRS_SHOWN } = {}) {
  checkMargin(margin);
  const pool = overlapPool(model, layers, { include_hidden });
  const entries = pool.map((layer) => ({ layer, box: occupiedBox(layer, check_text_overflow) }));
  const pairs = collectPairs(entries, new Set(layers.map((l) => l.id)), margin);
  const describe = ({ first, second, overlap }) => {
    const page = pageBox(first.layer);
    const others = (self) => entries.filter((e) => e.layer.id !== self.layer.id).map((e) => e.box);
    const cost = (mover, other) => {
      const o = pickPush(mover.box, other.box, others(mover), { margin, axis: "auto", keepInside: true, page });
      return o ? { push: mover.layer.id, direction: o.direction, distance: round(o.distance, 1), bumps_into_others: o.hits, ...(o.clamped ? { limited_by_page_edge: true } : {}) } : { push: mover.layer.id, impossible: "no room on the page" };
    };
    return {
      page: first.layer.page.number,
      first: pairBrief(first.layer, first.box, boundsOf(first.layer.frame)),
      second: pairBrief(second.layer, second.box, boundsOf(second.layer.frame)),
      overlap: {
        width: round(Math.max(0, overlap.width), 1),
        height: round(Math.max(0, overlap.height), 1),
        ...(overlap.width <= 0 || overlap.height <= 0 ? { too_close_only: true } : {}),
      },
      if_push_second: cost(second, first),
      if_push_first: cost(first, second),
    };
  };
  const shown = pairs.slice(0, Math.max(0, limit)).map(describe);
  return {
    pairs_total: pairs.length,
    pairs_returned: shown.length,
    margin,
    pairs: shown,
    note: pairs.length
      ? "first/second follow reading order. Read both texts, then call resolve_text_overlaps with resolutions: " +
        '[{ "layers": [firstId, secondId], "push": <id to move | "both">, "axis"?: "horizontal"|"vertical", "direction"?: "left"|"right"|"up"|"down" }]. ' +
        "Pairs you do not decide are resolved automatically (the later one in reading order moves) unless resolve_remaining is false."
      : "No overlapping text boxes found.",
  };
}

/**
 * Pushes overlapping text boxes apart by the smallest move that clears them (plus `margin`).
 *
 *  - `resolutions` are explicit per-pair decisions: { layers: [a, b], push: a | b | "both" | "first" | "second",
 *    axis?, direction? }. They are applied first, in order.
 *  - Whatever still overlaps is then swept automatically (unless `resolve_remaining` is false): within a page, layers
 *    earlier in `priority` (then in reading order) stay put and later ones give way.
 *  - Layers outside the selection never move; they act as fixed obstacles for the selected ones.
 */
export function resolveTextOverlaps(model, layers, params = {}) {
  const {
    margin = 0,
    axis = "auto",
    resolutions = [],
    priority = [],
    resolve_remaining = true,
    check_text_overflow = true,
    keep_inside_page = true,
    include_hidden = false,
  } = params;
  checkMargin(margin);
  if (![ "auto", "horizontal", "vertical" ].includes(axis)) throw new Error("axis must be auto|horizontal|vertical");
  if (!Array.isArray(resolutions)) throw new Error("`resolutions` must be an array");
  if (!Array.isArray(priority)) throw new Error("`priority` must be an array of layer ids");

  const selected = new Set(layers.map((l) => l.id));
  const pool = overlapPool(model, layers, { include_hidden });
  const states = new Map(
    pool.map((layer) => [
      layer.id,
      { layer, box: occupiedBox(layer, check_text_overflow), original: layer.frame.map((p) => ({ x: p.x, y: p.y })), dx: 0, dy: 0, notes: [] },
    ]),
  );
  const common = { margin, keepInside: keep_inside_page };
  const skipped = [];
  const applied = [];
  const othersOf = (state, only) =>
    [...states.values()].filter((s) => s !== state && s.layer.page.number === state.layer.page.number && (!only || only(s))).map((s) => s.box);
  const move = (state, dx, dy, note) => {
    state.box = shiftBox(state.box, dx, dy);
    state.dx += dx;
    state.dy += dy;
    state.notes.push(note);
  };
  const label = (s) => `${s.layer.id.slice(0, 8)} ("${(layerText(s.layer) || "").slice(0, 24)}")`;
  const describeMove = (dir, dist, from) => `pushed ${dir} ${round(dist, 1)}px away from ${label(from)}`;

  // 1. Explicit decisions.
  const before = collectPairs([...states.values()].map((s) => ({ layer: s.layer, box: s.box })), selected, margin).length;
  resolutions.forEach((r, index) => {
    const tag = `resolutions[${index}]`;
    if (!r || !Array.isArray(r.layers) || r.layers.length !== 2) throw new Error(`${tag}: \`layers\` must be [idA, idB]`);
    if (r.axis !== undefined && ![ "auto", "horizontal", "vertical" ].includes(r.axis)) throw new Error(`${tag}: axis must be auto|horizontal|vertical`);
    if (r.direction !== undefined && !DIRECTIONS.includes(r.direction)) throw new Error(`${tag}: direction must be ${DIRECTIONS.join("|")}`);
    const [la, lb] = r.layers.map((ref) => findLayerRef(model, ref));
    if (la.id === lb.id) throw new Error(`${tag}: layers must be two different layers`);
    const [first, second] = la.order <= lb.order ? [la, lb] : [lb, la];
    const states2 = [first, second].map((l) => states.get(l.id));
    if (states2.some((s) => !s)) {
      skipped.push({ layer: la.id, reason: `${tag}: a layer has no frame or is hidden (set include_hidden to include hidden ones)` });
      return;
    }
    if (la.page.number !== lb.page.number) throw new Error(`${tag}: the two layers are on different pages`);
    const [sFirst, sSecond] = states2;
    if (!overlapOf(sFirst.box, sSecond.box, margin)) {
      skipped.push({ layer: second.id, page: second.page.number, reason: `${tag}: layers are already clear of each other` });
      return;
    }
    let push = r.push;
    if (push === "first") push = first.id;
    else if (push === "second") push = second.id;
    else if (push !== "both") {
      const target = findLayerRef(model, push);
      if (target.id !== first.id && target.id !== second.id) throw new Error(`${tag}: \`push\` must be one of the two layers, "both", "first" or "second"`);
      push = target.id;
    }
    const opts = { ...common, axis: r.axis ?? axis, direction: r.direction, page: pageBox(first) };
    if (push === "both") {
      const movable = [sFirst, sSecond].filter((s) => selected.has(s.layer.id));
      if (movable.length < 2) {
        skipped.push({ layer: second.id, page: second.page.number, reason: `${tag}: "both" needs both layers in \`select\`` });
        return;
      }
      const o = pickPush(sSecond.box, sFirst.box, [], { ...opts, direction: undefined });
      if (!o) {
        skipped.push({ layer: second.id, page: second.page.number, reason: `${tag}: no room to separate them` });
        return;
      }
      move(sSecond, o.dx / 2, o.dy / 2, `${describeMove(o.direction, o.distance / 2, sFirst)} (shared push)`);
      move(sFirst, -o.dx / 2, -o.dy / 2, `pushed ${{ left: "right", right: "left", up: "down", down: "up" }[o.direction]} ${round(o.distance / 2, 1)}px away from ${label(sSecond)} (shared push)`);
      applied.push({ layers: [first.id, second.id], pushed: "both", direction: o.direction, distance: round(o.distance, 1) });
      return;
    }
    const mover = push === first.id ? sFirst : sSecond;
    const keeper = mover === sFirst ? sSecond : sFirst;
    if (!selected.has(mover.layer.id)) {
      skipped.push({ layer: mover.layer.id, page: mover.layer.page.number, reason: `${tag}: layer is not in \`select\`, so it cannot be moved (add it, or push the other layer)` });
      return;
    }
    const o = pickPush(mover.box, keeper.box, othersOf(mover), opts);
    if (!o) {
      skipped.push({ layer: mover.layer.id, page: mover.layer.page.number, reason: `${tag}: no room to move it ${r.direction ?? r.axis ?? "anywhere"} (page edge)` });
      return;
    }
    move(mover, o.dx, o.dy, describeMove(o.direction, o.distance, keeper));
    applied.push({ layers: [first.id, second.id], pushed: mover.layer.id, direction: o.direction, distance: round(o.distance, 1) });
  });

  // 2. Automatic sweep for everything still overlapping.
  if (resolve_remaining) {
    const rank = new Map(priority.map((ref, i) => [findLayerRef(model, ref).id, i]));
    const byPage = new Map();
    for (const s of states.values()) {
      const list = byPage.get(s.layer.page.number) ?? [];
      list.push(s);
      byPage.set(s.layer.page.number, list);
    }
    for (const list of byPage.values()) {
      const placed = list.filter((s) => !selected.has(s.layer.id));
      const movers = list
        .filter((s) => selected.has(s.layer.id))
        .sort((a, b) => (rank.get(a.layer.id) ?? Infinity) - (rank.get(b.layer.id) ?? Infinity) || a.layer.order - b.layer.order);
      for (const m of movers) {
        for (let i = 0; i < MAX_PUSHES_PER_LAYER; i++) {
          let hit = null;
          let hitArea = -1;
          for (const p of placed) {
            const o = overlapOf(m.box, p.box, margin);
            const area = o ? overlapArea(o) : -1;
            if (o && area > hitArea) {
              hit = p;
              hitArea = area;
            }
          }
          if (!hit) break;
          const o = pickPush(m.box, hit.box, placed.filter((p) => p !== hit).map((p) => p.box), { ...common, axis, page: pageBox(m.layer) });
          if (!o) break;
          move(m, o.dx, o.dy, describeMove(o.direction, o.distance, hit));
        }
        placed.push(m);
      }
    }
  }

  // 3. Write the frames that moved.
  const changes = [];
  for (const s of states.values()) {
    if (Math.abs(s.dx) <= OVERLAP_EPS && Math.abs(s.dy) <= OVERLAP_EPS) continue;
    const after = s.original.map((p) => ({ x: p.x + s.dx, y: p.y + s.dy }));
    writeFrame(model, s.layer, after);
    changes.push({ ...frameChange(s.layer, s.original, after), moved: { dx: round(s.dx, 2), dy: round(s.dy, 2) }, reasons: s.notes });
  }

  const remaining = collectPairs([...states.values()].map((s) => ({ layer: s.layer, box: s.box })), selected, margin);
  return {
    changes,
    skipped,
    extra: {
      overlapping_pairs_before: before,
      overlapping_pairs_after: remaining.length,
      ...(applied.length ? { explicit_resolutions_applied: applied } : {}),
      ...(remaining.length
        ? {
            unresolved: remaining.slice(0, 15).map(({ first, second }) => ({
              page: first.layer.page.number,
              layers: [first.layer.id, second.layer.id],
              texts: [clipText(layerText(first.layer)), clipText(layerText(second.layer))],
            })),
            unresolved_hint: "These could not be separated without leaving the page or are blocked (resolve_remaining false, no room). Reduce font size, shrink frames, or choose another axis/direction.",
          }
        : {}),
    },
  };
}
