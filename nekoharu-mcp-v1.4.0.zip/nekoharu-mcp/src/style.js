// Everything about *how a text layer looks*, resolved the way Koharu actually renders it.
//
// A raw `Typography` component stores intent: `null` means "use the renderer default", not "none".
// Reading the raw value alone is therefore misleading. Rules taken from koharu-renderer
// (`renderer.rs::resolve_stroke`, `text_draft`) and the editor inspector (`Inspector.tsx`):
//
//   * fill colour unset              -> BLACK  (#000000)
//   * stroke_width > 0, colour unset -> WHITE stroke (#ffffff)       <- "white text with a white border"
//   * stroke_width unset / 0         -> no stroke at all, whatever stroke_color says
//   * stroke colour alpha 0          -> the stroke is invisible (the editor's "transparent border")
//   * stroke method / position / join unset -> expansion / outside / round
//   * outer (second) stroke colour unset    -> BLACK, only drawn when the main stroke width > 0
//   * font weight / style unset      -> 400 / normal, line spacing unset -> 1.2
//
// This module turns a raw typography object into those effective values, and into compact
// summaries, signatures (for grouping/selecting "layers that look the same") and plain-language notes.

export const DEFAULTS = Object.freeze({
  color: [0, 0, 0, 255],
  stroke_color: [255, 255, 255, 255],
  outer_stroke_color: [0, 0, 0, 255],
  font_weight: 400,
  font_style: "normal",
  line_spacing: 1.2,
  stroke_method: "expansion",
  stroke_position: "outside",
  stroke_join: "round",
  // What the editor uses when a border colour is picked on a layer that has no width yet.
  editor_stroke_width: 1.5,
  editor_outer_stroke_width: 3,
});

// ---------------------------------------------------------------------- colours

export const NAMED_COLORS = {
  black: [0, 0, 0, 255],
  white: [255, 255, 255, 255],
  red: [255, 0, 0, 255],
  green: [0, 128, 0, 255],
  blue: [0, 0, 255, 255],
  yellow: [255, 255, 0, 255],
  orange: [255, 165, 0, 255],
  purple: [128, 0, 128, 255],
  pink: [255, 192, 203, 255],
  cyan: [0, 255, 255, 255],
  magenta: [255, 0, 255, 255],
  gray: [128, 128, 128, 255],
  grey: [128, 128, 128, 255],
  transparent: [0, 0, 0, 0],
};

/** "#rrggbb" (opaque) or "#rrggbbaa" (translucent) for an RGBA array. */
export const hex = (rgba) =>
  rgba
    ? `#${rgba
        .slice(0, rgba[3] === 255 ? 3 : 4)
        .map((v) => v.toString(16).padStart(2, "0"))
        .join("")}`
    : null;

/** Accepts "#rgb", "#rgba", "#rrggbb", "#rrggbbaa", names, or [r,g,b,(a)]. `null` stays `null`. */
export function parseColor(value) {
  if (value === null) return null;
  if (Array.isArray(value)) {
    if (value.length < 3 || value.length > 4 || value.some((v) => !Number.isInteger(v) || v < 0 || v > 255)) {
      throw new Error("color arrays must be [r,g,b] or [r,g,b,a] with integers 0-255");
    }
    return value.length === 3 ? [...value, 255] : [...value];
  }
  if (typeof value === "string") {
    const named = NAMED_COLORS[value.trim().toLowerCase()];
    if (named) return [...named];
    let h = value.trim().replace(/^#/, "");
    if (/^[0-9a-f]{3,4}$/i.test(h)) h = [...h].map((c) => c + c).join("");
    if (/^[0-9a-f]{6}$/i.test(h)) h += "ff";
    if (/^[0-9a-f]{8}$/i.test(h)) return [0, 2, 4, 6].map((i) => parseInt(h.slice(i, i + 2), 16));
  }
  throw new Error(`Invalid color ${JSON.stringify(value)}. Use "#rrggbb", "#rrggbbaa", a name, or [r,g,b,a].`);
}

export const sameRgb = (a, b) => Boolean(a && b) && a[0] === b[0] && a[1] === b[1] && a[2] === b[2];
export const sameRgba = (a, b) => sameRgb(a, b) && a[3] === b[3];

/** Does `actual` match `wanted` within a per-channel tolerance? Alpha is only compared when `wanted` is translucent. */
export function colorMatches(actual, wanted, tolerance = 0) {
  if (!actual || !wanted) return false;
  for (let i = 0; i < 3; i++) if (Math.abs(actual[i] - wanted[i]) > tolerance) return false;
  return wanted[3] === 255 ? true : Math.abs(actual[3] - wanted[3]) <= tolerance;
}

// ------------------------------------------------------------- effective style

const pos = (n) => (typeof n === "number" && n > 0 ? n : 0);
const r3 = (n) => (n === null || n === undefined ? n : Math.round(n * 1000) / 1000);

/**
 * Resolves a raw typography object (or `null` = no component at all) into what the renderer will use.
 * Pure data, safe to JSON-serialise.
 */
export function effectiveStyle(t) {
  const fill = t?.color ?? DEFAULTS.color;
  const strokeWidth = pos(t?.stroke_width);
  const strokeColor = t?.stroke_color ?? DEFAULTS.stroke_color;
  const strokeEnabled = strokeWidth > 0 && strokeColor[3] > 0;
  const outerWidth = pos(t?.outer_stroke_width);
  const outerColor = t?.outer_stroke_color ?? DEFAULTS.outer_stroke_color;
  // The renderer attaches the outer stroke to the main one: it needs a main stroke *width*, not a visible colour.
  const outerEnabled = strokeWidth > 0 && outerWidth > 0 && outerColor[3] > 0;

  const out = {
    fill: {
      rgba: fill,
      color: hex(fill),
      source: t?.color ? "explicit" : "default",
      visible: fill[3] > 0,
    },
    stroke: {
      enabled: strokeEnabled,
      rgba: strokeColor,
      color: hex(strokeColor),
      color_source: t?.stroke_color ? "explicit" : "default",
      width: r3(strokeWidth),
      method: t?.stroke_method ?? DEFAULTS.stroke_method,
      position: t?.stroke_position ?? DEFAULTS.stroke_position,
      join: t?.stroke_join ?? DEFAULTS.stroke_join,
    },
    outer_stroke: {
      enabled: outerEnabled,
      rgba: outerColor,
      color: hex(outerColor),
      color_source: t?.outer_stroke_color ? "explicit" : "default",
      width: r3(outerWidth),
    },
    font: {
      family: t?.preferred_font ?? null,
      weight: t?.font_weight ?? DEFAULTS.font_weight,
      style: t?.font_style ?? DEFAULTS.font_style,
    },
    line_spacing: t?.line_spacing ?? DEFAULTS.line_spacing,
  };
  out.stroke_same_as_fill = strokeEnabled && sameRgb(fill, strokeColor);
  out.stroke_same_as_outer_stroke = strokeEnabled && outerEnabled && sameRgb(strokeColor, outerColor);
  out.outer_stroke_same_as_fill = outerEnabled && sameRgb(fill, outerColor);
  // Text that cannot be seen at all (transparent fill and no visible border).
  out.ink_visible = out.fill.visible || strokeEnabled || outerEnabled;
  return out;
}

/** The effective style without the raw rgba arrays, for JSON output. */
export function publicStyle(t) {
  const e = effectiveStyle(t);
  const strip = ({ rgba: _rgba, ...rest }) => rest;
  return {
    fill: strip(e.fill),
    stroke: strip(e.stroke),
    outer_stroke: strip(e.outer_stroke),
    font: e.font,
    line_spacing: e.line_spacing,
    stroke_same_as_fill: e.stroke_same_as_fill,
    stroke_same_as_outer_stroke: e.stroke_same_as_outer_stroke,
    outer_stroke_same_as_fill: e.outer_stroke_same_as_fill,
    ink_visible: e.ink_visible,
  };
}

/** Compact one-line description of the visible border, e.g. "#ffffff 3px" or "none". */
export function strokeLabel(e) {
  if (!e.stroke.enabled) return "none";
  const extras = [];
  if (e.stroke.method !== DEFAULTS.stroke_method) extras.push(e.stroke.method);
  if (e.stroke.position !== DEFAULTS.stroke_position) extras.push(e.stroke.position);
  if (e.stroke.join !== DEFAULTS.stroke_join) extras.push(`${e.stroke.join} join`);
  return `${e.stroke.color} ${e.stroke.width}px${extras.length ? ` (${extras.join(", ")})` : ""}`;
}

export const outerStrokeLabel = (e) => (e.outer_stroke.enabled ? `${e.outer_stroke.color} ${e.outer_stroke.width}px` : "none");

/** Small, always-present colour/border block for list output. */
export function styleBrief(t) {
  const e = effectiveStyle(t);
  return {
    fill: e.fill.color,
    stroke: strokeLabel(e),
    outer_stroke: outerStrokeLabel(e),
    stroke_same_as_fill: e.stroke_same_as_fill,
  };
}

/**
 * Stable text key for "looks the same". `parts` chooses what counts:
 * fill, stroke, outer_stroke, font, weight, style, size, alignment, line_spacing, writing_mode.
 */
export const SIGNATURE_PARTS = ["fill", "stroke", "outer_stroke", "font", "weight", "style", "size", "alignment", "line_spacing", "writing_mode"];

export function styleSignature(t, parts = ["fill", "stroke", "outer_stroke"]) {
  const e = effectiveStyle(t);
  const bits = [];
  for (const part of parts) {
    switch (part) {
      case "fill":
        bits.push(`fill=${e.fill.color}`);
        break;
      case "stroke":
        bits.push(`stroke=${e.stroke.enabled ? `${e.stroke.color}/${e.stroke.width}/${e.stroke.method}/${e.stroke.position}/${e.stroke.join}` : "none"}`);
        break;
      case "outer_stroke":
        bits.push(`outer=${e.outer_stroke.enabled ? `${e.outer_stroke.color}/${e.outer_stroke.width}` : "none"}`);
        break;
      case "font":
        bits.push(`font=${e.font.family ?? "default"}`);
        break;
      case "weight":
        bits.push(`weight=${e.font.weight}`);
        break;
      case "style":
        bits.push(`style=${e.font.style}`);
        break;
      case "size":
        bits.push(`size=${!t || t.auto_fit ? "auto" : (t.size ?? "default")}`);
        break;
      case "alignment":
        bits.push(`align=${t?.alignment ?? "default"}`);
        break;
      case "line_spacing":
        bits.push(`leading=${e.line_spacing}`);
        break;
      case "writing_mode":
        bits.push(`mode=${t?.writing_mode ?? "auto"}`);
        break;
      default:
        throw new Error(`Unknown style part "${part}". Valid: ${SIGNATURE_PARTS.join(", ")}`);
    }
  }
  return bits.join(" | ");
}

/** A `select` fragment that matches layers with exactly the effective fill + border style of `t`. */
export function selectHintFor(t) {
  const e = effectiveStyle(t);
  const hint = { color: e.fill.color };
  if (e.stroke.enabled) {
    hint.stroke_color = e.stroke.color;
    hint.stroke_width = e.stroke.width;
  } else hint.has_stroke = false;
  if (e.outer_stroke.enabled) {
    hint.outer_stroke_color = e.outer_stroke.color;
    hint.outer_stroke_width = e.outer_stroke.width;
  } else hint.has_outer_stroke = false;
  return hint;
}

// ------------------------------------------------------------------------ spans

const chars = (s) => Array.from(s ?? "");
const SPAN_FIELDS = ["preferred_font", "font_weight", "font_style", "color", "stroke_color", "stroke_width"];

/** Per-word style overrides with the words they cover. */
export function describeSpans(typography, text) {
  const spans = typography?.spans ?? [];
  if (!spans.length) return [];
  const all = chars(text);
  return spans.map((sp) => ({
    start: sp.start,
    end: sp.end,
    text: all.slice(sp.start, sp.end).join(""),
    ...(sp.preferred_font ? { font: sp.preferred_font } : {}),
    ...(sp.font_weight ? { font_weight: sp.font_weight } : {}),
    ...(sp.font_style ? { font_style: sp.font_style } : {}),
    ...(sp.color ? { color: hex(sp.color) } : {}),
    ...(sp.stroke_color ? { stroke_color: hex(sp.stroke_color) } : {}),
    ...(sp.stroke_width !== null && sp.stroke_width !== undefined ? { stroke_width: r3(sp.stroke_width) } : {}),
  }));
}

/** Which typography fields do per-word spans override on this layer? */
export function spanOverrides(typography) {
  const keys = new Set();
  for (const sp of typography?.spans ?? []) {
    for (const k of SPAN_FIELDS) if (sp[k] !== null && sp[k] !== undefined) keys.add(k);
  }
  return [...keys];
}

// ------------------------------------------------------------------------ notes

/**
 * Plain-language observations an agent should know before editing or reporting on this layer's look.
 * Each note is a short sentence; none of them is an error.
 */
export function styleNotes(t, { translation = "" } = {}) {
  const notes = [];
  if (!t) {
    notes.push("No typography component: the renderer uses black text, no border, auto-fit size and its default font.");
    return notes;
  }
  const e = effectiveStyle(t);
  if (t.color === null) notes.push("Fill color is not set: text renders BLACK (#000000).");
  if (!e.fill.visible) notes.push("Fill color has alpha 0: the text fill is invisible.");
  const width = pos(t.stroke_width);
  if (width > 0 && t.stroke_color === null) {
    notes.push(`stroke_color is not set but stroke_width is ${r3(width)}: the renderer draws a WHITE (#ffffff) border.`);
  }
  if (width === 0 && t.stroke_color) {
    notes.push(`stroke_color ${hex(t.stroke_color)} is stored but stroke_width is ${t.stroke_width ?? "unset"}: NO border is drawn.`);
  }
  if (width > 0 && e.stroke.rgba[3] === 0) notes.push("The border has alpha 0 (a 'transparent border'): it is stored but invisible.");
  if (e.stroke_same_as_fill) notes.push(`Border and fill are the same color (${e.fill.color}): the border is not distinguishable from the text itself.`);
  if (e.outer_stroke_same_as_fill) notes.push(`Second border and fill are the same color (${e.fill.color}).`);
  if (pos(t.outer_stroke_width) > 0 && width === 0) notes.push("outer_stroke_width is set but there is no main border: the second border is not drawn.");
  if (!e.ink_visible) notes.push("Nothing visible would be drawn (transparent fill and no visible border).");
  if (t.auto_fit && t.size !== null) notes.push(`auto_fit is on, so size ${r3(t.size)} is ignored by the renderer until auto_fit is turned off.`);
  if (t.origin?.kind === "generated" && t.writing_mode) notes.push(`writing_mode "${t.writing_mode}" was inferred by the detector; Koharu only honours it for CJK text.`);
  if (t.spans?.length) {
    const words = describeSpans(t, translation)
      .slice(0, 3)
      .map((s) => `"${s.text}"`)
      .join(", ");
    notes.push(
      `${t.spans.length} per-word style span(s) (${words}${t.spans.length > 3 ? ", …" : ""}) override ${spanOverrides(t).join(", ") || "nothing visible"}; ` +
        "layer-level changes to those fields do not affect the spanned words (see span_overrides).",
    );
  }
  return notes;
}
