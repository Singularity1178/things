// A navigable view over the raw scene: pages, text layers, their text content,
// effective frames, detection/OCR regions, plus the selector engine shared by every bulk operation.
//
// Koharu text anatomy (see koharu-scene README):
//   page ── text group ── text layer (TextLayout + Typography [+ Geometry] [+ Visibility])
//                              └─ presents ─▶ text content entity (SourceText + Translation + TextRole)
//                                                  └─ recognized-from ─▶ text region (Region + Geometry + Detection + OCR)
//   A layer without its own Geometry takes its frame from a fits-to / flows-in region.
//   A layer that flows-in a bubble region is laid out as balloon text (role "dialogue").

import { KIND, USER, decodeComponent, encodeComponent, hasCodec } from "./codec.js";
import {
  colorMatches,
  describeSpans,
  effectiveStyle,
  hex,
  parseColor,
  publicStyle,
  spanOverrides,
  styleBrief,
  styleNotes,
  styleSignature,
} from "./style.js";
import { describeMeasure, frameGeometry, measureText, renderedText, resolveWritingMode } from "./textlayout.js";

export { hex };

export const round = (n, digits = 3) =>
  n === null || n === undefined ? n : Math.round(n * 10 ** digits) / 10 ** digits;

export const comp = (entity, kind) => entity.components.find((c) => c.key === kind);

export function setComp(entity, entry) {
  const i = entity.components.findIndex((c) => c.key === entry.key);
  if (i >= 0) entity.components[i] = entry;
  else {
    entity.components.push(entry);
    // Entities keep components sorted by key (bytewise), as koharu-scene does.
    entity.components.sort((a, b) => Buffer.compare(Buffer.from(a.key), Buffer.from(b.key)));
  }
}

export function removeComp(entity, kind) {
  const i = entity.components.findIndex((c) => c.key === kind);
  if (i < 0) return false;
  entity.components.splice(i, 1);
  return true;
}

export function boundsOf(points) {
  const xs = points.map((p) => p.x);
  const ys = points.map((p) => p.y);
  return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
}

// ----------------------------------------------------------------------- loading

/** Decodes a component, returning `null` (and remembering a warning) instead of throwing. */
export function tryDecode(model, entity, kind, what) {
  const entry = comp(entity, kind);
  if (!entry || !hasCodec(kind)) return null;
  try {
    return decodeComponent(entry);
  } catch (error) {
    model.warnings.push(`${what ?? kind} on ${entity.id} could not be read: ${error.message}`);
    return null;
  }
}

export const shortRegionKind = (kind) => (kind ?? "").replace(/^dev\.koharu\.region\./, "");
export const shortRole = (role) => (role ?? "").replace(/^dev\.koharu\.text\./, "");

export function loadModel(handle) {
  const { scene } = handle;
  const entities = new Map(); // id -> { entity, pageIndex }
  const relations = new Map(); // `${kind}|${source}` -> relation
  const pages = [];
  const warnings = [];

  scene.pages.forEach((pageRef, index) => {
    const root = pageRef.entities[0];
    const children = new Map();
    for (const e of pageRef.entities) {
      entities.set(e.id, { entity: e, pageIndex: index });
      if (e.parent) {
        if (!children.has(e.parent)) children.set(e.parent, []);
        children.get(e.parent).push(e.id);
      }
    }
    const pageComp = comp(root, KIND.PAGE);
    const meta = pageComp ? decodeComponent(pageComp) : { label: "", width: 0, height: 0 };
    const groupId = (children.get(root.id) ?? []).find((id) =>
      comp(entities.get(id).entity, KIND.TEXT_GROUP),
    );
    pages.push({
      index,
      number: index + 1,
      id: pageRef.id,
      label: meta.label,
      width: meta.width,
      height: meta.height,
      chapterStart: meta.chapter_start,
      ref: pageRef,
      root,
      children,
      layerIds: groupId ? (children.get(groupId) ?? []) : [],
    });
  });
  for (const rel of scene.relations) relations.set(`${rel.kind}|${rel.source}`, rel);

  const model = {
    handle,
    scene,
    entities,
    relations,
    pages,
    touchedPages: new Set(),
    layers: [],
    regions: [],
    regionById: new Map(),
    warnings,
    typographyRevision: 0,
    projectInfo: null,
  };

  // Project-wide settings (languages).
  const projectEntry = scene.projectComponents.find((c) => c.key === KIND.PROJECT);
  if (projectEntry) {
    try {
      model.projectInfo = decodeComponent(projectEntry);
    } catch (error) {
      warnings.push(`project settings could not be read: ${error.message}`);
    }
  }

  // Detection / OCR regions come first so layers can link to them.
  for (const page of pages) {
    for (const ref of page.ref.entities) {
      if (!comp(ref, KIND.REGION)) continue;
      const region = describeRegion(model, page, ref);
      if (region) {
        model.regions.push(region);
        model.regionById.set(region.id, region);
      }
    }
  }

  for (const page of pages) {
    page.layerIds.forEach((id, order) => {
      if (comp(entities.get(id).entity, KIND.TEXT_LAYOUT)) {
        model.layers.push(describeLayer(model, page, id, order));
      }
    });
  }
  for (const layer of model.layers) {
    if (layer.typography?.revision) model.typographyRevision = Math.max(model.typographyRevision, layer.typography.revision);
  }
  // Revision given to typography components this tool creates: what the project already uses, never below NeKoharu's own.
  model.writeTypographyRevision = Math.max(model.typographyRevision, 4);
  model.spansSupported = model.typographyRevision >= 5;

  // Which regions are inside which (text region -> bubble).
  for (const region of model.regions) {
    const target = relationTarget(model, KIND.REL_INSIDE, region.id);
    region.insideId = target && model.regionById.has(target) ? target : null;
  }
  return model;
}

const relationTarget = (model, kind, source) => model.relations.get(`${kind}|${source}`)?.target ?? null;

function safeDecode(entity, kind) {
  const entry = comp(entity, kind);
  return entry && hasCodec(kind) ? decodeComponent(entry) : null;
}

function describeRegion(model, page, entity) {
  const region = tryDecode(model, entity, KIND.REGION, "region");
  if (!region) return null;
  const geometry = tryDecode(model, entity, KIND.GEOMETRY, "region geometry");
  const detection = tryDecode(model, entity, KIND.DETECTION, "detection analysis");
  const ocr = tryDecode(model, entity, KIND.OCR, "OCR analysis");
  return {
    id: entity.id,
    page,
    entity,
    kind: shortRegionKind(region.kind),
    kind_full: region.kind,
    label: region.label,
    origin: region.origin,
    points: geometry?.points ?? null,
    bounds: geometry?.points?.length ? boundsOf(geometry.points) : null,
    detection,
    ocr,
    insideId: null,
  };
}

function describeLayer(model, page, id, order) {
  const entity = model.entities.get(id).entity;
  const layout = safeDecode(entity, KIND.TEXT_LAYOUT);
  const typography = safeDecode(entity, KIND.TYPOGRAPHY);
  const visibility = safeDecode(entity, KIND.VISIBILITY);
  const ownGeometry = safeDecode(entity, KIND.GEOMETRY);
  const entityOrigin = tryDecode(model, entity, KIND.ENTITY_ORIGIN, "entity origin");

  const contentId = relationTarget(model, KIND.REL_PRESENTS, id);
  const contentEntity = contentId ? (model.entities.get(contentId)?.entity ?? null) : null;
  const source = contentEntity ? safeDecode(contentEntity, KIND.TEXT_SOURCE) : null;
  const translation = contentEntity ? safeDecode(contentEntity, KIND.TEXT_TRANSLATION) : null;
  const role = contentEntity ? tryDecode(model, contentEntity, KIND.TEXT_ROLE, "text role") : null;

  // Regions this layer is tied to.
  const regionAt = (kind, from) => {
    const target = from ? relationTarget(model, kind, from) : null;
    return target ? (model.regionById.get(target) ?? null) : null;
  };
  const recognizedRegion = regionAt(KIND.REL_RECOGNIZED_FROM, contentId);
  const fitsRegion = regionAt(KIND.REL_FITS_TO, id);
  const flowsRegion = regionAt(KIND.REL_FLOWS_IN, id);

  let frame = null;
  let frameFrom = "none";
  let frameEntityId = null;
  // Koharu lays text out as balloon text whenever the layer flows in a balloon, even with its own frame.
  const flowTarget = relationTarget(model, KIND.REL_FLOWS_IN, id);
  const flowsIn = Boolean(flowTarget && model.entities.has(flowTarget));
  if (ownGeometry) {
    frame = ownGeometry.points;
    frameFrom = "own";
  } else {
    for (const [rel, label] of [
      [KIND.REL_FITS_TO, "fits-to"],
      [KIND.REL_FLOWS_IN, "flows-in"],
    ]) {
      const target = relationTarget(model, rel, id);
      const geometry = target && model.entities.has(target) && safeDecode(model.entities.get(target).entity, KIND.GEOMETRY);
      if (geometry) {
        frame = geometry.points;
        frameFrom = label;
        frameEntityId = target;
        break;
      }
    }
  }

  return {
    id,
    page,
    order: order + 1,
    entity,
    contentId,
    contentEntity,
    layout,
    typography,
    visibility,
    ownGeometry,
    source,
    translation,
    role,
    entityOrigin,
    ocr: recognizedRegion?.ocr ?? null,
    detection: recognizedRegion?.detection ?? null,
    recognizedRegion,
    fitsRegion,
    flowsRegion,
    frame,
    frameFrom,
    frameEntityId,
    flowsIn,
  };
}

// ---------------------------------------------------------------------- summaries

const clip = (s, n) => (s && s.length > n ? `${s.slice(0, n - 1)}…` : s);

export const originLabel = (origin) => (origin ? (origin.kind === "user" ? "user" : "generated") : null);

export const provenance = (origin) =>
  origin
    ? origin.kind === "user"
      ? { kind: "user" }
      : {
          kind: "generated",
          producer: origin.producer,
          model: origin.model ?? undefined,
          confidence: origin.confidence === null || origin.confidence === undefined ? undefined : round(origin.confidence, 3),
        }
    : null;

const translationText = (layer) => layer.translation?.text ?? "";

/** What Koharu will really use for the direction of this layer (best effort). */
export function effectiveWritingMode(layer) {
  const text = renderedText(layer) || translationText(layer) || layer.source?.text || "";
  const frame = layer.frame ? frameGeometry(layer.frame, layer.frameFrom === "own" ? (layer.layout?.angle_degrees ?? null) : null) : null;
  if (!frame) return layer.typography?.writing_mode ?? null;
  return resolveWritingMode(text, frame, layer.typography, layer.ocr?.direction ?? null);
}

/** Short list of things worth a second look, so an agent notices them without asking for `full`. */
export function layerFlags(layer) {
  const t = layer.typography;
  const e = effectiveStyle(t);
  const flags = [];
  if (e.stroke_same_as_fill) flags.push("stroke_same_as_fill");
  if (t && t.stroke_width > 0 && t.stroke_color === null) flags.push("stroke_color_defaulted_to_white");
  if (t && !(t.stroke_width > 0) && t.stroke_color) flags.push("stroke_color_stored_but_no_width");
  if (t && t.stroke_width > 0 && e.stroke.rgba[3] === 0) flags.push("stroke_transparent");
  if (e.outer_stroke_same_as_fill) flags.push("outer_stroke_same_as_fill");
  if (!e.ink_visible) flags.push("invisible_text");
  if (t?.spans?.length) flags.push("has_word_styles");
  if (layer.visibility && !layer.visibility.visible) flags.push("hidden");
  if (!layer.translation?.text) flags.push("no_translation");
  if (layer.ocr?.confidence !== null && layer.ocr?.confidence !== undefined && layer.ocr.confidence < 0.6) flags.push("low_ocr_confidence");
  return flags;
}

/** JSON-friendly summary of a layer for tool output. */
export function summarize(layer, detail = "brief") {
  const t = layer.typography;
  const e = effectiveStyle(t);
  const text = layer.translation?.text ?? layer.source?.text ?? "";
  const brief = styleBrief(t);
  const flags = layerFlags(layer);
  const out = {
    id: layer.id,
    page: layer.page.number,
    page_label: layer.page.label,
    order: layer.order,
    translation: layer.translation?.text ?? null,
    source: layer.source?.text ?? null,
    role: shortRole(layer.role?.role) || null,
    in_bubble: layer.flowsIn,
    font: t?.preferred_font ?? null,
    font_weight: e.font.weight,
    font_style: e.font.style,
    size: round(t?.size ?? null),
    auto_fit: t ? t.auto_fit : true,
    // Effective colours: what is drawn, with defaults resolved (unset fill = black, unset border colour = white).
    color: brief.fill,
    fill: brief.fill,
    stroke: brief.stroke,
    outer_stroke: brief.outer_stroke,
    stroke_same_as_fill: brief.stroke_same_as_fill,
    line_spacing: round(e.line_spacing, 3),
    alignment: t?.alignment ?? null,
    writing_mode: t?.writing_mode ?? null,
    writing_mode_effective: effectiveWritingMode(layer),
    typography_origin: t ? originLabel(t.origin) : "none",
    word_styles: t?.spans?.length || undefined,
    bounds: layer.frame ? boundsOf(layer.frame).map((v) => round(v, 1)) : null,
    frame_from: layer.frameFrom,
    visible: layer.visibility ? layer.visibility.visible : true,
    opacity: round(layer.visibility ? layer.visibility.opacity : 1, 3),
    angle: round(layer.layout?.angle_degrees ?? 0, 2),
    ocr_confidence: layer.ocr?.confidence === null || layer.ocr?.confidence === undefined ? undefined : round(layer.ocr.confidence, 3),
    flags: flags.length ? flags : undefined,
  };
  if (detail === "compact") {
    const compact = {
      id: out.id,
      page: out.page,
      order: out.order,
      text: clip(out.translation ?? out.source, 60),
      role: out.role ?? undefined,
      fill: out.fill,
      stroke: out.stroke,
      outer_stroke: out.outer_stroke === "none" ? undefined : out.outer_stroke,
      font: out.font ?? undefined,
      size: out.auto_fit ? "auto" : out.size,
      flags: out.flags,
    };
    return compact;
  }
  if (detail === "brief") {
    out.translation = clip(out.translation, 120);
    out.source = clip(out.source, 120);
    return out;
  }
  out.layout_kind = layer.layout?.kind ?? null;
  const { revision, spans: _spans, ...rawTypography } = t ?? {};
  out.typography = t
    ? {
        ...rawTypography,
        size: round(t.size),
        stroke_width: round(t.stroke_width),
        outer_stroke_width: round(t.outer_stroke_width),
        line_spacing: round(t.line_spacing),
        color: hex(t.color),
        stroke_color: hex(t.stroke_color),
        outer_stroke_color: hex(t.outer_stroke_color),
        format_revision: revision,
        word_styles: describeSpans(t, translationText(layer)),
      }
    : null;
  out.style = publicStyle(t);
  out.style_notes = styleNotes(t, { translation: translationText(layer) });
  out.word_style_overrides = spanOverrides(t);
  out.frame_points = layer.frame?.map((p) => ({ x: round(p.x, 2), y: round(p.y, 2) })) ?? null;
  out.text_preview = clip(text, 400);
  out.content_id = layer.contentId;
  out.language = { source: layer.source?.language ?? null, translation: layer.translation?.language ?? null };
  out.provenance = {
    layer: provenance(layer.entityOrigin?.origin),
    layout: provenance(layer.layout?.origin),
    typography: provenance(t?.origin),
    source_text: provenance(layer.source?.origin),
    translation: provenance(layer.translation?.origin),
    frame: layer.ownGeometry ? provenance(layer.ownGeometry.origin) : null,
    visibility: provenance(layer.visibility?.origin),
    role: provenance(layer.role?.origin),
  };
  out.detection = describeDetection(layer);
  try {
    const measured = measureText(layer);
    if (measured) out.rendered = describeMeasure(measured);
  } catch {
    // Measurement is a best-effort extra; never let it break a read.
  }
  return out;
}

export function describeRegionBrief(region) {
  if (!region) return null;
  return {
    id: region.id,
    kind: region.kind,
    label: region.label,
    bounds: region.bounds ? region.bounds.map((v) => round(v, 1)) : null,
    detection: region.detection
      ? {
          origin: provenance(region.detection.origin),
          labels: region.detection.labels.map((l) => ({ kind: shortRegionKind(l.kind), confidence: round(l.confidence, 3) })),
        }
      : null,
  };
}

/** Everything the detector / OCR recorded about the source artwork behind a layer. */
export function describeDetection(layer) {
  const ocr = layer.ocr;
  return {
    text_region: describeRegionBrief(layer.recognizedRegion),
    fits_to_region: describeRegionBrief(layer.fitsRegion),
    balloon_region: describeRegionBrief(layer.flowsRegion),
    ocr: ocr
      ? {
          direction: ocr.direction,
          confidence: round(ocr.confidence, 3),
          lines: ocr.line_boundaries.length,
          origin: provenance(ocr.origin),
        }
      : null,
  };
}

// ------------------------------------------------------------------- selection

/** "1-3,7" | 4 | [1,"5-6","Cover"] -> predicate over a page. */
function pageMatcher(model, spec) {
  if (spec === undefined || spec === null || spec === "all") return () => true;
  const tokens = (Array.isArray(spec) ? spec : String(spec).split(",")).map((t) =>
    typeof t === "number" ? String(t) : String(t).trim(),
  );
  const numbers = new Set();
  const others = [];
  for (const token of tokens) {
    const range = /^(\d+)(?:\s*-\s*(\d+))?$/.exec(token);
    if (range) {
      const from = Number(range[1]);
      const to = Number(range[2] ?? range[1]);
      for (let n = from; n <= to; n++) numbers.add(n);
    } else if (/^(first|last)$/i.test(token)) {
      numbers.add(token.toLowerCase() === "first" ? 1 : model.pages.length);
    } else if (token) others.push(token);
  }
  const unknown = others.filter(
    (t) => !model.pages.some((p) => p.id === t || p.label === t || p.id.startsWith(t)),
  );
  if (unknown.length) {
    throw new Error(`Unknown page reference(s): ${unknown.join(", ")}. Use 1-based page numbers, ranges like "2-5", labels or ids.`);
  }
  for (const n of numbers) {
    if (n < 1 || n > model.pages.length) {
      throw new Error(`Page ${n} is out of range (project has ${model.pages.length} pages).`);
    }
  }
  return (page) =>
    numbers.has(page.number) ||
    others.some((t) => page.id === t || page.label === t || page.id.startsWith(t));
}

/** Page predicate for tools outside `select` (e.g. list_regions). */
export const pagePredicate = pageMatcher;

function layerMatcher(model, ids) {
  if (!ids) return () => true;
  const list = [...new Set(ids)];
  const resolved = new Set();
  for (const ref of list) {
    const exact = model.layers.filter((l) => l.id === ref);
    const matches = exact.length ? exact : ref.length >= 6 ? model.layers.filter((l) => l.id.startsWith(ref)) : [];
    if (matches.length !== 1) {
      throw new Error(
        matches.length === 0
          ? `No text layer with id "${ref}". Use list_text to find ids.`
          : `Layer id prefix "${ref}" is ambiguous.`,
      );
    }
    resolved.add(matches[0].id);
  }
  return (layer) => resolved.has(layer.id);
}

const ci = (s) => (s ?? "").toLowerCase();

export const SELECT_KEYS = [
  "pages", "layers", "exclude_layers", "order", "text_contains", "text_regex", "text_field", "case_sensitive",
  "has_translation", "font", "size", "size_min", "size_max", "auto_fit", "writing_mode", "alignment",
  "layout_kind", "visible", "translation_origin", "bounds_within",
  // typography, colours and borders
  "color", "stroke_color", "stroke_width", "stroke_width_min", "stroke_width_max", "has_stroke",
  "stroke_same_as_fill", "stroke_method", "stroke_position", "stroke_join", "color_tolerance",
  "outer_stroke_color", "outer_stroke_width", "outer_stroke_width_min", "outer_stroke_width_max", "has_outer_stroke",
  "font_weight", "font_weight_min", "font_weight_max", "font_style", "line_spacing_min", "line_spacing_max",
  "typography_origin", "has_typography", "has_word_styles", "word_style_overrides", "same_style_as", "ink_visible",
  // content, detection, geometry
  "role", "in_bubble", "frame_from", "rotated", "opacity_min", "opacity_max", "language",
  "ocr_confidence_min", "ocr_confidence_max", "ocr_direction", "detection_confidence_min", "detection_confidence_max",
  "flag",
];
const SELECT_KEY_SET = new Set(SELECT_KEYS);

/** A colour selector value: a colour, or `null` for "not set (renderer default)". */
function colorSelector(value, label) {
  if (value === null) return { unset: true };
  try {
    return { wanted: parseColor(value) };
  } catch (error) {
    throw new Error(`select.${label}: ${error.message}`);
  }
}

const inRange = (value, min, max) =>
  (min === undefined || (value !== null && value !== undefined && value >= min)) &&
  (max === undefined || (value !== null && value !== undefined && value <= max));

const LOOKS_PARTS = ["fill", "stroke", "outer_stroke", "font", "weight", "style"];

/** Returns the text layers matching a selector (default: every text layer). */
export function selectLayers(model, select = {}) {
  const s = select ?? {};
  const unknownKeys = Object.keys(s).filter((k) => !SELECT_KEY_SET.has(k));
  if (unknownKeys.length) {
    throw new Error(`Unknown select condition(s): ${unknownKeys.join(", ")}. Valid: ${SELECT_KEYS.join(", ")}`);
  }
  const pageOk = pageMatcher(model, s.pages);
  const orderOk = s.order === undefined ? () => true : orderMatcher(s.order);
  const idOk = layerMatcher(model, s.layers);
  const excluded = s.exclude_layers?.length ? layerMatcher(model, s.exclude_layers) : () => false;
  let regex = null;
  if (s.text_regex) {
    try {
      regex = new RegExp(s.text_regex, s.case_sensitive ? "" : "i");
    } catch (error) {
      throw new Error(`Invalid text_regex: ${error.message}`);
    }
  }
  const field = s.text_field ?? "any";
  const textOf = (l) =>
    field === "translation"
      ? [l.translation?.text ?? ""]
      : field === "source"
        ? [l.source?.text ?? ""]
        : [l.translation?.text ?? "", l.source?.text ?? ""];

  const tol = s.color_tolerance ?? 0;
  const fillSel = s.color !== undefined ? colorSelector(s.color, "color") : null;
  const strokeSel = s.stroke_color !== undefined ? colorSelector(s.stroke_color, "stroke_color") : null;
  const outerSel = s.outer_stroke_color !== undefined ? colorSelector(s.outer_stroke_color, "outer_stroke_color") : null;
  const wantedWeights = s.font_weight === undefined ? null : [].concat(s.font_weight);
  const overrideKeys = s.word_style_overrides === undefined ? null : [].concat(s.word_style_overrides).map((k) => (k === "preferred_font" ? "font" : k));
  let sameAs = null;
  if (s.same_style_as !== undefined) {
    const ref = layerMatcher(model, [s.same_style_as]);
    const reference = model.layers.find((l) => ref(l));
    sameAs = styleSignature(reference.typography, LOOKS_PARTS);
  }

  return model.layers.filter((l) => {
    if (!pageOk(l.page) || !orderOk(l.order) || !idOk(l) || excluded(l)) return false;
    const t = l.typography;
    const e = effectiveStyle(t);
    if (s.text_contains !== undefined) {
      const needle = s.case_sensitive ? s.text_contains : ci(s.text_contains);
      if (!textOf(l).some((x) => (s.case_sensitive ? x : ci(x)).includes(needle))) return false;
    }
    if (regex && !textOf(l).some((x) => regex.test(x))) return false;
    if (s.has_translation !== undefined && Boolean(l.translation?.text) !== s.has_translation) return false;
    if (s.font !== undefined) {
      const want = s.font === null || ci(String(s.font)) === "none" ? null : ci(String(s.font));
      if ((t?.preferred_font ? ci(t.preferred_font) : null) !== want) return false;
    }
    const size = t?.size ?? null;
    if (s.size !== undefined && (size === null || Math.abs(size - s.size) > 0.01)) return false;
    if (s.size_min !== undefined && (size === null || size < s.size_min)) return false;
    if (s.size_max !== undefined && (size === null || size > s.size_max)) return false;
    if (s.auto_fit !== undefined && (t ? t.auto_fit : true) !== s.auto_fit) return false;
    if (s.writing_mode !== undefined && (t?.writing_mode ?? "horizontal") !== s.writing_mode) return false;
    if (s.alignment !== undefined && (t?.alignment ?? null) !== s.alignment) return false;
    if (s.layout_kind !== undefined && l.layout?.kind !== s.layout_kind) return false;
    if (s.visible !== undefined && (l.visibility ? l.visibility.visible : true) !== s.visible) return false;
    if (s.translation_origin !== undefined) {
      const origin = l.translation?.origin?.kind;
      if (origin !== s.translation_origin) return false;
    }
    if (s.bounds_within !== undefined) {
      if (!l.frame) return false;
      const [x0, y0, x1, y1] = s.bounds_within;
      const [l0, t0, r0, b0] = boundsOf(l.frame);
      const cx = (l0 + r0) / 2;
      const cy = (t0 + b0) / 2;
      if (cx < x0 || cx > x1 || cy < y0 || cy > y1) return false;
    }

    // ---- colours and borders (effective values: defaults resolved, a border only counts if it is drawn)
    if (fillSel) {
      if (fillSel.unset) {
        if (t?.color !== null && t?.color !== undefined) return false;
      } else if (!colorMatches(e.fill.rgba, fillSel.wanted, tol)) return false;
    }
    if (strokeSel) {
      if (strokeSel.unset) {
        if (t?.stroke_color !== null && t?.stroke_color !== undefined) return false;
      } else if (!e.stroke.enabled || !colorMatches(e.stroke.rgba, strokeSel.wanted, tol)) return false;
    }
    if (s.stroke_width !== undefined && Math.abs(e.stroke.width - s.stroke_width) > 0.01) return false;
    if (!inRange(e.stroke.width, s.stroke_width_min, s.stroke_width_max)) return false;
    if (s.has_stroke !== undefined && e.stroke.enabled !== s.has_stroke) return false;
    if (s.stroke_same_as_fill !== undefined && e.stroke_same_as_fill !== s.stroke_same_as_fill) return false;
    if (s.stroke_method !== undefined && e.stroke.method !== s.stroke_method) return false;
    if (s.stroke_position !== undefined && e.stroke.position !== s.stroke_position) return false;
    if (s.stroke_join !== undefined && e.stroke.join !== s.stroke_join) return false;
    if (outerSel) {
      if (outerSel.unset) {
        if (t?.outer_stroke_color !== null && t?.outer_stroke_color !== undefined) return false;
      } else if (!e.outer_stroke.enabled || !colorMatches(e.outer_stroke.rgba, outerSel.wanted, tol)) return false;
    }
    if (s.outer_stroke_width !== undefined && Math.abs(e.outer_stroke.width - s.outer_stroke_width) > 0.01) return false;
    if (!inRange(e.outer_stroke.width, s.outer_stroke_width_min, s.outer_stroke_width_max)) return false;
    if (s.has_outer_stroke !== undefined && e.outer_stroke.enabled !== s.has_outer_stroke) return false;
    if (wantedWeights && !wantedWeights.includes(e.font.weight)) return false;
    if (!inRange(e.font.weight, s.font_weight_min, s.font_weight_max)) return false;
    if (s.font_style !== undefined && e.font.style !== s.font_style) return false;
    if (!inRange(e.line_spacing, s.line_spacing_min, s.line_spacing_max)) return false;
    if (s.typography_origin !== undefined && (t ? originLabel(t.origin) : "none") !== s.typography_origin) return false;
    if (s.has_typography !== undefined && Boolean(t) !== s.has_typography) return false;
    if (s.has_word_styles !== undefined && Boolean(t?.spans?.length) !== s.has_word_styles) return false;
    if (overrideKeys) {
      const actual = spanOverrides(t).map((k) => (k === "preferred_font" ? "font" : k));
      if (!overrideKeys.some((k) => actual.includes(k))) return false;
    }
    if (sameAs !== null && styleSignature(t, LOOKS_PARTS) !== sameAs) return false;
    if (s.ink_visible !== undefined && e.ink_visible !== s.ink_visible) return false;

    // ---- content, detection, geometry
    if (s.role !== undefined) {
      const role = shortRole(l.role?.role) || null;
      if (role !== (s.role === null ? null : String(s.role).replace(/^dev\.koharu\.text\./, ""))) return false;
    }
    if (s.in_bubble !== undefined && l.flowsIn !== s.in_bubble) return false;
    if (s.frame_from !== undefined && l.frameFrom !== s.frame_from) return false;
    if (s.rotated !== undefined && Math.abs(l.layout?.angle_degrees ?? 0) > 0.01 !== s.rotated) return false;
    const opacity = l.visibility ? l.visibility.opacity : 1;
    if (!inRange(opacity, s.opacity_min, s.opacity_max)) return false;
    if (s.language !== undefined) {
      const tag = l.translation?.language ?? null;
      if (ci(tag) !== ci(s.language) && !ci(tag).startsWith(`${ci(s.language)}-`)) return false;
    }
    if (s.ocr_confidence_min !== undefined || s.ocr_confidence_max !== undefined) {
      if (!inRange(l.ocr?.confidence ?? null, s.ocr_confidence_min, s.ocr_confidence_max)) return false;
    }
    if (s.ocr_direction !== undefined && (l.ocr?.direction ?? null) !== s.ocr_direction) return false;
    if (s.detection_confidence_min !== undefined || s.detection_confidence_max !== undefined) {
      const best = l.detection?.labels?.length ? Math.max(...l.detection.labels.map((x) => x.confidence)) : null;
      if (!inRange(best, s.detection_confidence_min, s.detection_confidence_max)) return false;
    }
    if (s.flag !== undefined && !layerFlags(l).includes(s.flag)) return false;
    return true;
  });
}

function orderMatcher(spec) {
  const numbers = new Set();
  for (const token of (Array.isArray(spec) ? spec : String(spec).split(",")).map(String)) {
    const m = /^\s*(\d+)(?:\s*-\s*(\d+))?\s*$/.exec(token);
    if (!m) throw new Error(`Invalid order selector "${token}" (use e.g. "1-3,5").`);
    for (let n = Number(m[1]); n <= Number(m[2] ?? m[1]); n++) numbers.add(n);
  }
  return (order) => numbers.has(order);
}

/** Describes a selector in words for tool output. */
export function describeSelect(select) {
  const keys = Object.keys(select ?? {}).filter((k) => select[k] !== undefined);
  return keys.length ? select : "all text layers";
}

// -------------------------------------------------------------------- mutation

/** Marks a layer (and its text content) as user-authored, like Koharu's own edits. */
export function promote(model, layer) {
  for (const entity of [layer.entity, layer.contentEntity]) {
    if (!entity) continue;
    setComp(entity, encodeComponent(KIND.ENTITY_ORIGIN, { origin: USER }, comp(entity, KIND.ENTITY_ORIGIN)));
  }
  touch(model, layer.page);
}

export function touch(model, page) {
  model.touchedPages.add(page.index);
}

/** Bumps the mutation epoch of every page that changed. */
export function finalizeEpochs(model) {
  for (const index of model.touchedPages) model.scene.pages[index].epoch += 1n;
}
