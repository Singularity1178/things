// Read-only reports: what is in a project and how it looks.
//
// Everything here works on *effective* values (see style.js), so "white text with a white border" is
// visible as such even when the stored typography only says `stroke_width: 3` and leaves the colour unset.

import { KIND, TYPOGRAPHY_NEKOHARU_REVISION, TYPOGRAPHY_MAX_REVISION, decodeComponent, hasCodec, isKnownKind } from "./codec.js";
import {
  comp,
  effectiveWritingMode,
  layerFlags,
  originLabel,
  pagePredicate,
  provenance,
  round,
  shortRegionKind,
  shortRole,
  tryDecode,
} from "./model.js";
import { effectiveStyle, selectHintFor, spanOverrides, strokeLabel, outerStrokeLabel, styleSignature, SIGNATURE_PARTS } from "./style.js";

// --------------------------------------------------------------------- helpers

const tally = (map, key) => map.set(key, (map.get(key) ?? 0) + 1);
const sorted = (map) =>
  Object.fromEntries([...map.entries()].sort((a, b) => b[1] - a[1]).map(([k, v]) => [String(k), v]));

/** [1,2,3,7] -> "1-3,7" */
export function pageRanges(numbers) {
  const list = [...new Set(numbers)].sort((a, b) => a - b);
  const out = [];
  for (let i = 0; i < list.length; ) {
    let j = i;
    while (j + 1 < list.length && list[j + 1] === list[j] + 1) j++;
    out.push(j > i ? `${list[i]}-${list[j]}` : `${list[i]}`);
    i = j + 1;
  }
  return out.join(",");
}

const clip = (s, n) => (s && s.length > n ? `${s.slice(0, n - 1)}…` : s);

// ------------------------------------------------------------------ statistics

/** Distribution of everything an agent might want to normalise, over the given layers. */
export function statistics(model, layers) {
  const sizes = new Map();
  const fonts = new Map();
  const fills = new Map();
  const strokeColors = new Map();
  const strokeWidths = new Map();
  const strokeMethods = new Map();
  const strokePositions = new Map();
  const strokeJoins = new Map();
  const outerColors = new Map();
  const outerWidths = new Map();
  const looks = new Map();
  const weights = new Map();
  const styles = new Map();
  const spacings = new Map();
  const alignments = new Map();
  const modes = new Map();
  const effectiveModes = new Map();
  const frames = new Map();
  const typoOrigins = new Map();
  const roles = new Map();
  const layouts = new Map();
  const transOrigins = new Map();
  const languages = new Map();
  const revisions = new Map();
  const flagCounts = new Map();
  const ocrDirections = new Map();
  const spanFields = new Map();

  let translated = 0;
  let hidden = 0;
  let autoFit = 0;
  let noTypography = 0;
  let noSize = 0;
  let inBubble = 0;
  let rotated = 0;
  let translucent = 0;
  let strokeVisible = 0;
  let strokeSame = 0;
  let defaultedWhite = 0;
  let storedNoWidth = 0;
  let transparentStroke = 0;
  let outerVisible = 0;
  let withSpans = 0;
  let spansTotal = 0;
  let ocrCount = 0;
  let ocrLow = 0;
  let ocrSum = 0;
  let ocrMin = null;

  for (const l of layers) {
    const t = l.typography;
    const e = effectiveStyle(t);
    if (l.translation?.text) translated++;
    if (l.visibility && !l.visibility.visible) hidden++;
    if (l.visibility && l.visibility.opacity < 1) translucent++;
    if (!t) noTypography++;
    else if (t.auto_fit) autoFit++;
    if (l.flowsIn) inBubble++;
    if (Math.abs(l.layout?.angle_degrees ?? 0) > 0.01) rotated++;
    // Layers without typography use renderer defaults, so they count as "unset"/"default".
    tally(sizes, t?.size == null ? "unset" : round(t.size, 2));
    tally(fonts, t?.preferred_font ?? "default");
    tally(fills, e.fill.color);
    tally(weights, e.font.weight);
    tally(styles, e.font.style);
    tally(spacings, round(e.line_spacing, 2));
    tally(alignments, t?.alignment ?? "default");
    tally(modes, t?.writing_mode ?? "auto");
    tally(effectiveModes, effectiveWritingMode(l) ?? "unknown");
    if (t && t.size === null) noSize++;
    tally(frames, l.frameFrom);
    tally(typoOrigins, t ? originLabel(t.origin) : "none");
    tally(roles, shortRole(l.role?.role) || "none");
    tally(layouts, l.layout?.kind ?? "unknown");
    tally(transOrigins, l.translation ? originLabel(l.translation.origin) : "none");
    tally(languages, l.translation?.language ?? "unset");
    if (t) tally(revisions, t.revision);

    if (e.stroke.enabled) {
      strokeVisible++;
      tally(strokeColors, e.stroke.color);
      tally(strokeWidths, e.stroke.width);
      tally(strokeMethods, e.stroke.method);
      tally(strokePositions, e.stroke.position);
      tally(strokeJoins, e.stroke.join);
    } else {
      tally(strokeColors, "none");
      tally(strokeWidths, 0);
    }
    if (e.stroke_same_as_fill) strokeSame++;
    if (t && t.stroke_width > 0 && t.stroke_color === null) defaultedWhite++;
    if (t && !(t.stroke_width > 0) && t.stroke_color) storedNoWidth++;
    if (t && t.stroke_width > 0 && e.stroke.rgba[3] === 0) transparentStroke++;
    if (e.outer_stroke.enabled) {
      outerVisible++;
      tally(outerColors, e.outer_stroke.color);
      tally(outerWidths, e.outer_stroke.width);
    }
    tally(looks, `fill ${e.fill.color} | border ${strokeLabel(e)} | second border ${outerStrokeLabel(e)}`);

    if (t?.spans?.length) {
      withSpans++;
      spansTotal += t.spans.length;
      for (const f of spanOverrides(t)) tally(spanFields, f);
    }
    for (const f of layerFlags(l)) tally(flagCounts, f);
    if (l.ocr) {
      ocrCount++;
      tally(ocrDirections, l.ocr.direction);
      if (l.ocr.confidence !== null && l.ocr.confidence !== undefined) {
        ocrSum += l.ocr.confidence;
        ocrMin = ocrMin === null ? l.ocr.confidence : Math.min(ocrMin, l.ocr.confidence);
        if (l.ocr.confidence < 0.6) ocrLow++;
      }
    }
  }
  return {
    text_layers: layers.length,
    translated,
    untranslated: layers.length - translated,
    hidden,
    translucent,
    auto_fit_layers: autoFit,
    layers_without_typography: noTypography,
    layers_without_explicit_size: noSize + noTypography,
    in_bubble: inBubble,
    rotated,
    sizes: sorted(sizes),
    fonts: sorted(fonts),
    font_weights: sorted(weights),
    font_styles: sorted(styles),
    line_spacings: sorted(spacings),
    // Effective fill colour (unset = black).
    colors: sorted(fills),
    fill_colors: sorted(fills),
    borders: {
      with_visible_border: strokeVisible,
      without_border: layers.length - strokeVisible,
      border_same_color_as_fill: strokeSame,
      border_color_unset_so_white: defaultedWhite,
      border_color_stored_but_no_width: storedNoWidth,
      border_transparent: transparentStroke,
      colors: sorted(strokeColors),
      widths: sorted(strokeWidths),
      methods: sorted(strokeMethods),
      positions: sorted(strokePositions),
      joins: sorted(strokeJoins),
    },
    second_borders: {
      with_second_border: outerVisible,
      colors: sorted(outerColors),
      widths: sorted(outerWidths),
    },
    looks: sorted(looks),
    word_styles: {
      layers_with_word_styles: withSpans,
      spans_total: spansTotal,
      overridden_fields: sorted(spanFields),
      editing_supported: model.spansSupported,
    },
    alignments: sorted(alignments),
    writing_modes: sorted(modes),
    writing_modes_effective: sorted(effectiveModes),
    layout_kinds: sorted(layouts),
    frame_sources: sorted(frames),
    roles: sorted(roles),
    typography_origins: sorted(typoOrigins),
    translation_origins: sorted(transOrigins),
    translation_languages: sorted(languages),
    ocr: ocrCount
      ? {
          layers_with_ocr: ocrCount,
          directions: sorted(ocrDirections),
          average_confidence: ocrCount ? round(ocrSum / ocrCount, 3) : null,
          lowest_confidence: round(ocrMin, 3),
          below_0_6: ocrLow,
        }
      : null,
    typography_format_revisions: sorted(revisions),
    flags: sorted(flagCounts),
  };
}

// ----------------------------------------------------------------- style report

/**
 * Groups layers by how they look. The answer to "which texts have a white border?" or "are there
 * layers whose fill and border are the same colour?": every group lists its size, pages, sample layer
 * ids and a ready-made `select` that picks exactly the group in an editing tool.
 */
export function styleReport(model, layers, { group_by, limit = 25, samples = 8 } = {}) {
  const parts = group_by?.length ? group_by : ["fill", "stroke", "outer_stroke"];
  for (const p of parts) {
    if (!SIGNATURE_PARTS.includes(p)) throw new Error(`Unknown group_by "${p}". Valid: ${SIGNATURE_PARTS.join(", ")}`);
  }
  const groups = new Map();
  for (const l of layers) {
    const key = styleSignature(l.typography, parts);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(l);
  }
  const list = [...groups.entries()].sort((a, b) => b[1].length - a[1].length);
  return {
    layers: layers.length,
    group_by: parts,
    groups_total: list.length,
    groups: list.slice(0, limit).map(([key, members]) => {
      const first = members[0];
      const e = effectiveStyle(first.typography);
      const t = first.typography;
      const style = {};
      if (parts.includes("fill")) style.fill = e.fill.color;
      if (parts.includes("stroke")) {
        style.stroke = strokeLabel(e);
        if (e.stroke.enabled && e.stroke.color_source === "default") style.stroke_color_is_unset_default = true;
      }
      if (parts.includes("outer_stroke")) style.outer_stroke = outerStrokeLabel(e);
      if (parts.includes("font")) style.font = e.font.family ?? "default";
      if (parts.includes("weight")) style.font_weight = e.font.weight;
      if (parts.includes("style")) style.font_style = e.font.style;
      if (parts.includes("size")) style.size = !t || t.auto_fit ? "auto-fit" : (t.size ?? "default");
      if (parts.includes("alignment")) style.alignment = t?.alignment ?? "default";
      if (parts.includes("line_spacing")) style.line_spacing = round(e.line_spacing, 2);
      if (parts.includes("writing_mode")) style.writing_mode = t?.writing_mode ?? "auto";
      const sameFill = members.filter((m) => effectiveStyle(m.typography).stroke_same_as_fill).length;
      return {
        style,
        signature: key,
        layers: members.length,
        pages: pageRanges(members.map((m) => m.page.number)),
        stroke_same_as_fill: e.stroke_same_as_fill ? true : sameFill ? `${sameFill} of ${members.length}` : false,
        word_styles: members.filter((m) => m.typography?.spans?.length).length || undefined,
        sample_layer_ids: members.slice(0, samples).map((m) => m.id),
        select: { ...selectHintFor(first.typography), same_style_as: first.id },
        select_note:
          "`select` matches this group's fill and border exactly (same_style_as also pins font, weight and style). " +
          "Add `pages` to narrow it. Drop `same_style_as` to ignore font.",
      };
    }),
  };
}

// --------------------------------------------------------------------- regions

/** Detection / OCR regions with the layers attached to them. */
export function listRegions(model, { pages, kind, text_contains, limit = 100, offset = 0, include_layers = true } = {}) {
  const pageOk = pagePredicate(model, pages);
  const wantKind = kind ? String(kind).replace(/^dev\.koharu\.region\./, "") : null;
  const attached = new Map(); // region id -> [{layer, relation}]
  const add = (regionId, layer, relation) => {
    if (!regionId) return;
    if (!attached.has(regionId)) attached.set(regionId, []);
    attached.get(regionId).push({ layer, relation });
  };
  for (const l of model.layers) {
    add(l.recognizedRegion?.id, l, "recognized-from");
    add(l.fitsRegion?.id, l, "fits-to");
    add(l.flowsRegion?.id, l, "flows-in");
  }
  const needle = text_contains ? String(text_contains).toLowerCase() : null;
  const matching = model.regions.filter((r) => {
    if (!pageOk(r.page)) return false;
    if (wantKind && r.kind !== wantKind) return false;
    if (needle) {
      const texts = (attached.get(r.id) ?? []).flatMap(({ layer }) => [layer.translation?.text, layer.source?.text]);
      if (!texts.some((x) => x && x.toLowerCase().includes(needle))) return false;
    }
    return true;
  });
  const counts = new Map();
  for (const r of matching) tally(counts, r.kind);
  return {
    total: matching.length,
    by_kind: sorted(counts),
    offset,
    returned: Math.min(limit, Math.max(0, matching.length - offset)),
    regions: matching.slice(offset, offset + limit).map((r) => {
      const inside = r.insideId ? model.regionById.get(r.insideId) : null;
      return {
        id: r.id,
        page: r.page.number,
        page_label: r.page.label,
        kind: r.kind,
        label: r.label,
        bounds: r.bounds ? r.bounds.map((v) => round(v, 1)) : null,
        points: r.points && r.points.length !== 4 ? r.points.length : undefined,
        created_by: provenance(r.origin),
        detection: r.detection
          ? { created_by: provenance(r.detection.origin), labels: r.detection.labels.map((x) => ({ kind: shortRegionKind(x.kind), confidence: round(x.confidence, 3) })) }
          : null,
        ocr: r.ocr
          ? { direction: r.ocr.direction, confidence: round(r.ocr.confidence, 3), lines: r.ocr.line_boundaries.length, created_by: provenance(r.ocr.origin) }
          : null,
        inside: inside ? { id: inside.id, kind: inside.kind, bounds: inside.bounds?.map((v) => round(v, 1)) ?? null } : null,
        ...(include_layers
          ? {
              layers: (attached.get(r.id) ?? []).map(({ layer, relation }) => ({
                layer: layer.id,
                relation,
                order: layer.order,
                role: shortRole(layer.role?.role) || null,
                source: clip(layer.source?.text ?? null, 80),
                translation: clip(layer.translation?.text ?? null, 80),
              })),
            }
          : {}),
      };
    }),
  };
}

// ------------------------------------------------------------- project overview

const KIND_ORDER = ["text", "bubble", "panel"];

/** Pages: size, text, detection regions, raster layers and stored assets. */
export function pageOverview(model) {
  return model.pages.map((p) => {
    const own = model.layers.filter((l) => l.page === p);
    const regions = model.regions.filter((r) => r.page === p);
    const regionCounts = new Map();
    for (const r of regions) tally(regionCounts, r.kind);
    const rasters = [];
    for (const ref of p.ref.entities) {
      if (!comp(ref, KIND.RASTER_LAYER)) continue;
      const raster = tryDecode(model, ref, KIND.RASTER_LAYER, "raster layer");
      if (raster) rasters.push({ name: raster.name, kind: raster.kind });
    }
    const assets = tryDecode(model, p.root, KIND.ASSETS, "page assets");
    const roles = new Map();
    for (const l of own) tally(roles, shortRole(l.role?.role) || "none");
    return {
      page: p.number,
      label: p.label,
      id: p.id,
      width: round(p.width, 1),
      height: round(p.height, 1),
      text_layers: own.length,
      translated: own.filter((l) => l.translation?.text).length,
      hidden: own.filter((l) => l.visibility && !l.visibility.visible).length || undefined,
      with_visible_border: own.filter((l) => effectiveStyle(l.typography).stroke.enabled).length,
      roles: sorted(roles),
      regions: Object.fromEntries([...KIND_ORDER, ...[...regionCounts.keys()].filter((k) => !KIND_ORDER.includes(k))].filter((k) => regionCounts.has(k)).map((k) => [k, regionCounts.get(k)])),
      raster_layers: rasters.length ? rasters : undefined,
      assets: assets
        ? Object.entries(assets.values).map(([role, a]) => ({
            role,
            media_type: a.media_type,
            width: a.width ?? undefined,
            height: a.height ?? undefined,
            created_by: provenance(a.origin),
          }))
        : undefined,
      chapter_start: p.chapterStart || undefined,
    };
  });
}

/** Project-level facts: languages, format revision, what this tool understands. */
export function projectFacts(model) {
  const pi = model.projectInfo;
  return {
    source_language: pi?.source_locale ?? null,
    target_languages: pi?.target_locales ?? [],
    typography_format: {
      revision_in_use: model.typographyRevision || null,
      nekoharu_release_reads_up_to: TYPOGRAPHY_NEKOHARU_REVISION,
      this_tool_writes_revision: model.writeTypographyRevision,
      this_tool_understands_up_to: TYPOGRAPHY_MAX_REVISION,
      word_styles_supported: model.spansSupported,
    },
    ...(model.warnings.length ? { read_warnings: model.warnings.slice(0, 20) } : {}),
  };
}

/** Counts every component kind in the project, whether this tool understands it, and whether it really decodes. */
export function componentInventory(model) {
  const counts = new Map();
  const failures = new Map();
  const visit = (entry, where) => {
    tally(counts, entry.key);
    if (!hasCodec(entry.key)) return;
    try {
      decodeComponent(entry);
    } catch (error) {
      if (!failures.has(entry.key)) failures.set(entry.key, { count: 0, example: `${where}: ${error.message}` });
      failures.get(entry.key).count++;
    }
  };
  for (const page of model.pages) {
    for (const e of page.ref.entities) for (const c of e.components) visit(c, e.id);
  }
  for (const c of model.scene.projectComponents) visit(c, "project");
  for (const rel of model.scene.relations) tally(counts, `relation:${rel.kind}`);
  return Object.fromEntries(
    [...counts.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([kind, count]) => [
        kind,
        {
          count,
          understood: kind.startsWith("relation:") ? true : isKnownKind(kind),
          ...(failures.has(kind) ? { decode_failures: failures.get(kind) } : {}),
        },
      ]),
  );
}

