// A minimal Model Context Protocol server over stdio (newline-delimited JSON-RPC 2.0).
// No SDK dependency: the protocol surface needed for tools is small and stable.

import readline from "node:readline";
import { TOOLS, callTool } from "./tools.js";
import { koharuMayBeRunning } from "./store.js";

const SUPPORTED = ["2025-06-18", "2025-03-26", "2024-11-05"];
const VERSION = "1.4.0";

export const INSTRUCTIONS = `\
NeKoharu Bulk Editor: project-wide edits to Koharu (.khrproj) manga-translation projects.

Workflow
1. list_projects (if you do not know the path), then project_info to see pages and current typography stats.
2. Inspect with list_text / text_stats before editing; use the ids it returns.
3. Edit with the bulk tools (set_font_size, set_typography, scale_font_size, move_text, set_frame, align_text_to_page, fit_text_in_page,
   resolve_text_overlaps, replace_text, transform_text, set_visibility, ...). Omit \`select\` to affect every text layer, or narrow it
   by pages ("1-5"), text, font, size, region, etc. Use dry_run:true first for large or ambiguous edits.
   Overlapping text: call find_text_overlaps (it shows what each colliding pair says), decide which layer of each pair should
   move, then call resolve_text_overlaps with \`resolutions\` ([{ layers: [a, b], push: <id> }]). Undecided pairs are pushed apart
   automatically in reading order.
4. Group related edits with \`batch\` so they share one revision. Every change is backed up; use \`undo\` to revert.

Looking before editing (colours, borders, detection)
- Values you get back are EFFECTIVE: an unset fill is black, a border with a width but no colour is white, a border with width 0
  does not exist, alpha 0 is invisible. Raw nulls in typography mean "renderer default", never "none".
- list_text rows show fill / stroke / outer_stroke / stroke_same_as_fill, role, in_bubble, OCR confidence and flags. Use
  detail "compact" to scan many layers, "full" for raw typography, word styles, provenance, detection and OCR.
- style_report groups layers by look and returns a ready-made \`select\` per group: call it before "change the colour of the texts that ...".
  select understands color, stroke_color, has_stroke, stroke_same_as_fill, stroke_width, outer_stroke_*, font_weight, role, in_bubble,
  has_word_styles, ocr_confidence_max, same_style_as, ... Colour/border conditions compare effective values.
- list_regions shows what the detector/OCR found (text regions, bubbles, panels, confidences) and the layers attached to them.
- Words with their own style (flag has_word_styles) keep it when you change the layer colour/border: pass span_overrides "clear".
- set_typography results include \`warnings\` and each layer's resulting look (\`now\`): read them and tell the user.

Conventions
- Pages are 1-based. Coordinates are page pixels, origin top-left, y grows downward. Bounds are [left, top, right, bottom].
- Font size is in page pixels. Setting a size turns auto-fit off for that layer (fixed size) unless you pass auto_fit.
- Layers that follow a detected region get their own manual frame the first time you move or resize them.
- Edits are written to disk. The Koharu desktop app does not live-reload: the project must be CLOSED in Koharu while
  you edit, then reopened to see the result.`;

function send(message) {
  process.stdout.write(`${JSON.stringify(message)}\n`);
}

function reply(id, result) {
  send({ jsonrpc: "2.0", id, result });
}

function fail(id, code, message) {
  send({ jsonrpc: "2.0", id, error: { code, message } });
}

function toolList() {
  return TOOLS.map(({ name, description, inputSchema, annotations }) => ({
    name,
    description,
    inputSchema,
    annotations,
  }));
}

function handle(message) {
  const { id, method, params } = message;
  const isRequest = id !== undefined && id !== null;
  switch (method) {
    case "initialize": {
      const wanted = params?.protocolVersion;
      reply(id, {
        protocolVersion: SUPPORTED.includes(wanted) ? wanted : SUPPORTED[0],
        capabilities: { tools: { listChanged: false } },
        serverInfo: { name: "nekoharu-mcp", title: "NeKoharu Bulk Editor", version: VERSION },
        instructions: INSTRUCTIONS,
      });
      return;
    }
    case "ping":
      if (isRequest) reply(id, {});
      return;
    case "tools/list":
      reply(id, { tools: toolList() });
      return;
    case "tools/call": {
      const name = params?.name;
      const outcome = callTool(name, params?.arguments ?? {});
      const body = outcome.ok ? outcome.result : { error: outcome.error };
      reply(id, {
        content: [{ type: "text", text: JSON.stringify(body, null, 2) }],
        isError: !outcome.ok,
      });
      return;
    }
    case "resources/list":
      reply(id, { resources: [] });
      return;
    case "prompts/list":
      reply(id, { prompts: [] });
      return;
    default:
      // Notifications (initialized, cancelled, ...) need no reply.
      if (isRequest) fail(id, -32601, `Method not found: ${method}`);
  }
}

export function serve() {
  const rl = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
  rl.on("line", (line) => {
    if (!line.trim()) return;
    let message;
    try {
      message = JSON.parse(line);
    } catch {
      fail(null, -32700, "Parse error");
      return;
    }
    try {
      handle(message);
    } catch (error) {
      if (message.id !== undefined) fail(message.id, -32603, error.message);
    }
  });
  rl.on("close", () => process.exit(0));
  process.stderr.write(
    `[nekoharu-mcp] ready (${TOOLS.length} tools)${koharuMayBeRunning() ? " - note: Koharu appears to be running" : ""}\n`,
  );
}
