#!/usr/bin/env node
// nekoharu - command line front end. `nekoharu serve` starts the MCP server;
// every other command runs one tool and prints its JSON result.

import { TOOLS, callTool, getTool } from "./tools.js";
import { serve } from "./mcp.js";

const HELP = `\
nekoharu - project-wide edits for Koharu / NeKoharu projects

Usage
  nekoharu serve                           Start the MCP server on stdio (for opencode, Claude, Cursor, ...)
  nekoharu tools                           List all tools
  nekoharu <tool> <project> [--flag value] Run a tool directly

Examples
  nekoharu project-info ~/Documents/Koharu/MyManga.khrproj
  nekoharu set-font-size MyManga --size 40 --dry-run
  nekoharu set-font-size MyManga --size 40 --select.pages 1-5
  nekoharu scale-font-size MyManga --factor 1.15 --select.size_max 30
  nekoharu move-text MyManga --dy -2 --unit percent --select.text_contains "Hey"
  nekoharu set-typography MyManga --font "Anime Ace" --alignment center --color "#111111"
  nekoharu replace-text MyManga --find "Mr." --replace "Mister"
  nekoharu style-report MyManga                              Which looks (fill + border) exist, with counts
  nekoharu list-text MyManga --select.stroke_same_as_fill true --detail compact
  nekoharu set-typography MyManga --select.color "#ffffff" --select.stroke_color "#ffffff" --color "#222222" --dry-run
  nekoharu list-regions MyManga --kind bubble
  nekoharu undo MyManga

Flags are tool arguments. Nest with dots (--select.pages 1-3). Values are parsed as JSON when
possible (40, true, null, [1,2]); otherwise treated as strings. Use --json '{...}' for a full
argument object. Use \`nekoharu help <tool>\` for a tool's schema.

Close the project in Koharu before editing, then reopen it. The project can also come from the
KOHARU_PROJECT environment variable.`;

function parseValue(raw) {
  try {
    return JSON.parse(raw);
  } catch {
    return raw;
  }
}

function setPath(target, path, value) {
  const keys = path.split(".");
  let cursor = target;
  for (const key of keys.slice(0, -1)) cursor = cursor[key] ??= {};
  cursor[keys.at(-1)] = value;
}

function parseArgs(argv) {
  const args = {};
  const positional = [];
  for (let i = 0; i < argv.length; i++) {
    const token = argv[i];
    if (!token.startsWith("--")) {
      positional.push(token);
      continue;
    }
    let [flag, inline] = token.slice(2).split(/=(.*)/s);
    flag = flag.replace(/-/g, "_");
    if (flag === "json") {
      Object.assign(args, JSON.parse(inline ?? argv[++i]));
      continue;
    }
    const next = argv[i + 1];
    const value =
      inline !== undefined ? parseValue(inline) : next === undefined || next.startsWith("--") ? true : parseValue(argv[++i]);
    setPath(args, flag, value);
  }
  return { args, positional };
}

const [command, ...rest] = process.argv.slice(2);

if (!command || command === "-h" || command === "--help") {
  console.log(HELP);
} else if (command === "serve" || command === "mcp") {
  serve();
} else if (command === "tools") {
  for (const tool of TOOLS) console.log(`${tool.name.padEnd(20)} ${tool.description.split(". ")[0]}`);
} else if (command === "help") {
  const tool = rest[0] && getTool(rest[0]);
  if (!tool) console.log(HELP);
  else console.log(`${tool.name}\n${tool.description}\n\n${JSON.stringify(tool.inputSchema, null, 2)}`);
} else {
  const { args, positional } = parseArgs(rest);
  if (positional[0] && args.project === undefined) args.project = positional[0];
  if (args.dry_run === undefined && rest.includes("--dry-run")) args.dry_run = true;
  const outcome = callTool(command, args);
  if (outcome.ok) {
    console.log(JSON.stringify(outcome.result, null, 2));
  } else {
    console.error(`Error: ${outcome.error}`);
    process.exitCode = 1;
  }
}
