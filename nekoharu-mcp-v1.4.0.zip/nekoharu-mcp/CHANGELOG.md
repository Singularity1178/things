# Changelog

## 1.4.0 - honest colours, borders and detection data

Found by reading the tool output against NeKoharu `v0.85.3-N` (`koharu-scene`, `koharu-renderer`, the editor inspector,
the detection pipeline):

1. **Borders were invisible to agents.** `list_text` showed only the fill colour; border colour/width, second border,
   weight and style were only in `detail: "full"`, one layer at a time, and `select` could not filter on any of them.
   "Change the white texts that have a white border" found nothing. Now every row carries the effective `fill`, `stroke`,
   `outer_stroke` and `stroke_same_as_fill`, and `select` understands colours and borders (see README).
2. **Unset did not mean "none".** The renderer draws an unset fill black and a border with a width but no colour *white*
   (`resolve_stroke`); a stored border colour with no width draws nothing; alpha 0 hides a border. Raw `null`s hid all of
   that, so white text with a defaulted (white) border looked border-less. All read tools now report effective values
   (`src/style.js`), plus `flags` and `style_notes` that explain the quirks.
3. **Per-word styles were invisible and silently survived colour changes.** Word styles are now listed (with the words
   they cover), selectable (`has_word_styles`, `word_style_overrides`), counted in `text_stats`, and `set_typography` warns
   when they override the field being changed; `span_overrides` (`keep`/`clear`/`remove_all`) resolves it.
4. **Typography was always written as revision 5.** NeKoharu `v0.85.3-N` reads revision 4 and rejects anything newer
   (`UnsupportedComponent`), and the stored schema number was a constant 5 regardless of the payload. Writes now keep the
   project's revision and the schema number always matches the payload.
5. **Detection/OCR/provenance data was ignored.** New decoders for text roles (dialogue / free-text), regions (text, bubble,
   panel), detection labels and confidence, OCR direction/confidence/lines, project languages, raster layers and assets.
   Exposed through `list_text`, `get_text_layer` (detection, provenance, languages, measured rendering), `list_regions`,
   `project_info` and `check_project` (which now also decodes every known component and lists unknown ones).
6. `writing_mode` was reported raw; `writing_mode_effective` now follows the renderer (authored mode, CJK text, OCR direction,
   frame shape). Unset size/auto_fit/weight/line spacing are reported as the defaults the renderer uses.

New tools: `style_report`, `list_regions`. New `list_text` detail level: `compact`. `select` rejects unknown conditions.
Tests that need the Rust-written fixture are skipped when it is missing; new synthetic-project tests cover everything above.

## Unreleased - accurate text-on-page fitting

`fit_text_in_page` could report success while text was still cut off at the top (or bottom) of the page. Causes found
by reading `koharu-renderer` and fixed:

1. **Auto-fit layers were never checked.** Every translated layer is auto-fit by default, but the renderer only shrinks
   text down to 9 px (and caps free text at 24 px, ignoring `typography.size`), so long translations in small boxes still
   spill out of the frame. They are now simulated like the renderer does.
2. **Layers without an explicit `size` were skipped**, although the renderer then uses its default size.
3. **Rotation was ignored.** The frame's bounding box was used as if it were the text box, so rotated layers (author
   `angle_degrees` or a rotated 4-point frame) never looked like they overflowed. Frames are now measured in their own
   axes and the text rotated about the centre, as in `renderer.rs::placement`.
4. **Point text was treated as centred.** It is anchored at the frame's top-left corner and never wraps.
5. **Text height was `lines x line-height`, wrapped greedily with fixed average glyph widths.** The renderer uses the
   tight ink box of the real glyphs and an optimal-fit line breaker with hyphenation, so the line count (and with it the
   height) was often wrong, especially for wide comic fonts and all-caps lettering. A built-in TrueType/OpenType reader
   (`src/fontfile.js`) now provides real advances and ink bounds, and `src/textlayout.js` reproduces the line breaking.
6. **Source text was used when the translation was empty**, but Koharu draws only the translation.
7. The frame is no longer allowed to block showing the text: if the frame is bigger than the page but the text fits,
   the text is kept fully visible.

New: `find_offscreen_text` (read-only report), `include_frame` option, per-layer verification (`text.visible_after`),
`text_check` summary telling you whether real font files or estimates were used, `NEKOHARU_FONT_DIRS`.
`find_text_overlaps` / `resolve_text_overlaps` use the same text measurement.
