// Tests for what the MCP tells an agent about a project: effective colours/borders, selectors,
// style groups, detection/OCR info, and the typography revision that gets written back.

import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";

import { KIND, decodeComponent, decodeScene, decodeStateFile } from "../src/codec.js";
import { callTool } from "../src/tools.js";
import { effectiveStyle, styleNotes } from "../src/style.js";
import { makeProject } from "./helpers/make-project.js";

const ok = (name, args) => {
  const out = callTool(name, args);
  assert.ok(out.ok, out.error);
  return out.result;
};

const WHITE = [255, 255, 255, 255];
const BLACK = [0, 0, 0, 255];
const RED = [255, 0, 0, 255];

/** The scenario from the bug report: lots of white text with a white border, in several disguises. */
function whiteOnWhiteProject({ revision = 4, withSpans = false } = {}) {
  const layers = [
    // 0: white fill + explicit white border
    { text: "explicit", revision, typography: { color: WHITE, stroke_color: WHITE, stroke_width: 3 } },
    // 1: white fill + border width but NO border colour (renderer draws it white)
    { text: "defaulted", revision, typography: { color: WHITE, stroke_color: null, stroke_width: 3 } },
    // 2: black fill + white border: a normal look
    { text: "normal", revision, typography: { color: BLACK, stroke_color: WHITE, stroke_width: 3 } },
    // 3: white fill, white colour stored, but no width => no border at all
    { text: "stored", revision, typography: { color: WHITE, stroke_color: WHITE, stroke_width: null } },
    // 4: nothing set
    { text: "bare", revision, typography: {} },
  ];
  if (withSpans) {
    layers.push({
      text: "hello big world",
      revision: 5,
      typography: {
        color: WHITE,
        stroke_color: WHITE,
        stroke_width: 2,
        spans: [{ start: 6, end: 9, preferred_font: null, font_weight: 800, font_style: null, color: RED, stroke_color: null, stroke_width: null }],
      },
    });
  }
  return makeProject({ layers });
}

const layerById = (list, id) => list.layers.find((l) => l.id === id);

test("effective style resolves renderer defaults", () => {
  const e = effectiveStyle({ color: null, stroke_color: null, stroke_width: 2 });
  assert.equal(e.fill.color, "#000000");
  assert.equal(e.stroke.color, "#ffffff");
  assert.equal(e.stroke.color_source, "default");
  assert.equal(e.stroke.enabled, true);
  assert.equal(effectiveStyle({ stroke_color: WHITE, stroke_width: 0 }).stroke.enabled, false);
  assert.equal(effectiveStyle({ stroke_color: [1, 2, 3, 0], stroke_width: 4 }).stroke.enabled, false);
  assert.equal(effectiveStyle({ color: WHITE, stroke_color: WHITE, stroke_width: 1 }).stroke_same_as_fill, true);
  // The second border is only drawn together with a main border width.
  assert.equal(effectiveStyle({ outer_stroke_width: 3 }).outer_stroke.enabled, false);
  assert.equal(effectiveStyle({ stroke_width: 1, outer_stroke_width: 3 }).outer_stroke.color, "#000000");
  assert.match(styleNotes({ color: WHITE, stroke_color: null, stroke_width: 3 }).join(" "), /WHITE/);
});

test("list_text shows fill and border for every layer, with flags", () => {
  const { dir, ids } = whiteOnWhiteProject();
  const list = ok("list_text", { project: dir });
  const explicit = layerById(list, ids[0]);
  assert.equal(explicit.fill, "#ffffff");
  assert.equal(explicit.stroke, "#ffffff 3px");
  assert.equal(explicit.stroke_same_as_fill, true);
  assert.ok(explicit.flags.includes("stroke_same_as_fill"));

  const defaulted = layerById(list, ids[1]);
  assert.equal(defaulted.stroke, "#ffffff 3px");
  assert.equal(defaulted.stroke_same_as_fill, true);
  assert.ok(defaulted.flags.includes("stroke_color_defaulted_to_white"));

  assert.equal(layerById(list, ids[2]).stroke_same_as_fill, false);
  const stored = layerById(list, ids[3]);
  assert.equal(stored.stroke, "none");
  assert.ok(stored.flags.includes("stroke_color_stored_but_no_width"));
  const bare = layerById(list, ids[4]);
  assert.equal(bare.fill, "#000000");
  assert.equal(bare.font_weight, 400);
  assert.equal(bare.line_spacing, 1.2);
});

test("select finds layers by fill colour, border colour and same-colour borders", () => {
  const { dir, ids } = whiteOnWhiteProject();
  const same = ok("list_text", { project: dir, select: { stroke_same_as_fill: true } });
  assert.deepEqual(same.layers.map((l) => l.id), [ids[0], ids[1]]);

  const byColors = ok("list_text", { project: dir, select: { color: "#fff", stroke_color: "white" } });
  assert.deepEqual(byColors.layers.map((l) => l.id), [ids[0], ids[1], ids[3]].filter((x) => x !== ids[3]));

  // A stored-but-off border colour is not a border.
  assert.equal(ok("list_text", { project: dir, select: { stroke_color: "#ffffff", color: "#ffffff" } }).total, 2);
  assert.equal(ok("list_text", { project: dir, select: { has_stroke: false } }).total, 2);
  assert.equal(ok("list_text", { project: dir, select: { stroke_width_min: 3 } }).total, 3);
  assert.equal(ok("list_text", { project: dir, select: { color: null } }).total, 1); // only "bare" has no explicit fill
  assert.equal(ok("list_text", { project: dir, select: { flag: "stroke_color_defaulted_to_white" } }).total, 1);
  assert.equal(ok("list_text", { project: dir, select: { same_style_as: ids[0] } }).total, 2); // layers 0 and 1 look identical
  assert.equal(ok("list_text", { project: dir, select: { color: "#fefefe", color_tolerance: 2, has_stroke: true } }).total, 2);
  assert.equal(ok("list_text", { project: dir, select: { stroke_same_as_fill: true, exclude_layers: [ids[0]] } }).total, 1);

  const bad = callTool("list_text", { project: dir, select: { stroke_colour: "white" } });
  assert.equal(bad.ok, false);
  assert.match(bad.error, /Unknown select condition/);
  assert.match(callTool("list_text", { project: dir, select: { color: "bluish" } }).error, /Invalid color/);
});

test("style_report groups looks and hands back a usable select", () => {
  const { dir, ids } = whiteOnWhiteProject();
  const report = ok("style_report", { project: dir });
  const top = report.groups[0];
  assert.equal(top.layers, 2);
  assert.equal(top.style.fill, "#ffffff");
  assert.equal(top.style.stroke, "#ffffff 3px");
  assert.equal(top.stroke_same_as_fill, true);
  assert.deepEqual(new Set(top.sample_layer_ids), new Set([ids[0], ids[1]]));
  assert.equal(report.groups_total, 4);

  // The select shipped with the group edits exactly that group.
  const select = { ...top.select };
  delete select.same_style_as;
  const dry = ok("set_typography", { project: dir, select, color: "#000000", dry_run: true });
  assert.equal(dry.matched_layers, 2);

  const split = ok("style_report", { project: dir, group_by: ["fill", "stroke", "weight", "size"] });
  assert.ok(split.groups[0].style.font_weight);
  assert.equal(callTool("style_report", { project: dir, group_by: ["colour"] }).ok, false);
});

test("changing the colour of 'same colour border' texts works end to end", () => {
  const { dir, ids } = whiteOnWhiteProject();
  const result = ok("set_typography", {
    project: dir,
    select: { stroke_same_as_fill: true },
    color: "#101010",
  });
  assert.equal(result.matched_layers, 2);
  assert.equal(result.changed_layers, 2);
  assert.equal(result.changes[0].now.fill, "#101010");
  assert.equal(result.changes[0].now.stroke, "#ffffff 3px");
  assert.equal(ok("list_text", { project: dir, select: { stroke_same_as_fill: true } }).total, 0);
  assert.equal(ok("get_text_layer", { project: dir, layer: ids[1] }).typography.color, "#101010");
  // Fill and border together.
  const both = ok("set_typography", { project: dir, select: { pages: "1", layers: [ids[2]] }, color: "#336699", stroke_color: "#336699" });
  assert.ok(both.warnings.some((w) => /same color as the fill/.test(w.message)));
});

test("a border colour without a width warns, stroke_enabled fixes it", () => {
  const { dir, ids } = whiteOnWhiteProject();
  const result = ok("set_typography", { project: dir, select: { layers: [ids[4]] }, stroke_color: "#ff0000" });
  assert.ok(result.warnings.some((w) => /NO border is drawn/.test(w.message)));
  const lay = ok("get_text_layer", { project: dir, layer: ids[4] });
  assert.equal(lay.style.stroke.enabled, false);

  const on = ok("set_typography", { project: dir, select: { layers: [ids[4]] }, stroke_enabled: true });
  assert.equal(on.changes[0].now.stroke, "#ff0000 1.5px");
  const off = ok("set_typography", { project: dir, select: { layers: [ids[4]] }, stroke_enabled: false });
  assert.equal(off.changes[0].now.stroke, "none");
  assert.equal(ok("get_text_layer", { project: dir, layer: ids[4] }).typography.stroke_color, "#ff0000"); // colour kept
  assert.equal(callTool("set_typography", { project: dir, stroke_enabled: false, stroke_width: 3 }).ok, false);
});

test("word styles are reported and span_overrides decides what happens to them", () => {
  const { dir, ids } = whiteOnWhiteProject({ withSpans: true });
  const spanId = ids[5];
  const layer = ok("get_text_layer", { project: dir, layer: spanId });
  assert.equal(layer.typography.word_styles.length, 1);
  assert.equal(layer.typography.word_styles[0].text, "big");
  assert.equal(layer.typography.word_styles[0].color, "#ff0000");
  assert.deepEqual(layer.word_style_overrides.sort(), ["color", "font_weight"]);
  assert.match(layer.style_notes.join(" "), /per-word style/);
  assert.equal(ok("list_text", { project: dir, select: { has_word_styles: true } }).total, 1);
  assert.equal(ok("list_text", { project: dir, select: { word_style_overrides: "color" } }).total, 1);
  assert.equal(ok("list_text", { project: dir, select: { word_style_overrides: "stroke_color" } }).total, 0);
  assert.equal(ok("text_stats", { project: dir }).word_styles.layers_with_word_styles, 1);

  const kept = ok("set_typography", { project: dir, select: { layers: [spanId] }, color: "#0000ff" });
  assert.ok(kept.warnings.some((w) => /Per-word styles override color/.test(w.message)));
  assert.equal(ok("get_text_layer", { project: dir, layer: spanId }).typography.word_styles.length, 1);

  const cleared = ok("set_typography", { project: dir, select: { layers: [spanId] }, color: "#00ff00", span_overrides: "clear" });
  assert.equal(cleared.warnings, undefined);
  const after = ok("get_text_layer", { project: dir, layer: spanId });
  // Only the colour override went away; the bold word keeps its weight.
  assert.equal(after.typography.word_styles.length, 1);
  assert.equal(after.typography.word_styles[0].color, undefined);
  assert.equal(after.typography.word_styles[0].font_weight, 800);

  ok("set_typography", { project: dir, select: { layers: [spanId] }, color: "#ffffff", span_overrides: "remove_all" });
  assert.equal(ok("get_text_layer", { project: dir, layer: spanId }).typography.word_styles.length, 0);
});

test("typography is written back at the revision the project uses", () => {
  const revisionsOf = (dir) => {
    const scene = decodeScene(decodeStateFile(fs.readFileSync(path.join(dir, "state-b.khr"))).payload);
    return scene.pages[0].entities
      .flatMap((e) => e.components)
      .filter((c) => c.key === KIND.TYPOGRAPHY)
      .map((c) => ({ schema: c.schema, decoded: decodeComponent(c).revision }));
  };

  // A NeKoharu v0.85.3-N project (Typography revision 4): never stamp it revision 5.
  const four = whiteOnWhiteProject({ revision: 4 });
  ok("set_typography", { project: four.dir, color: "#123456" });
  const afterFour = revisionsOf(four.dir);
  assert.ok(afterFour.length > 0);
  assert.ok(afterFour.every((r) => r.schema === 4 && r.decoded === 4), JSON.stringify(afterFour));
  assert.equal(ok("project_info", { project: four.dir }).typography_format.word_styles_supported, false);

  // A project that already has word styles (revision 5) keeps them.
  const five = whiteOnWhiteProject({ withSpans: true });
  ok("set_typography", { project: five.dir, color: "#123456" });
  const afterFive = revisionsOf(five.dir);
  assert.ok(afterFive.every((r) => r.schema === 5));
  assert.equal(ok("get_text_layer", { project: five.dir, layer: five.ids[5] }).typography.word_styles.length, 1);

  // An older component is lifted to the current NeKoharu revision, not past it.
  const two = makeProject({ layers: [{ text: "old", revision: 2, typography: { color: WHITE } }] });
  ok("set_typography", { project: two.dir, size: 20 });
  const afterTwo = revisionsOf(two.dir);
  assert.deepEqual(afterTwo, [{ schema: 4, decoded: 4 }]);
});

test("detection, OCR and role information is exposed", () => {
  const { dir, ids } = makeProject({
    layers: [
      {
        text: "Hello!",
        source: "こんにちは",
        generated: true,
        role: "dialogue",
        region: { bounds: [100, 100, 220, 200], confidence: 0.91, ocr: { direction: "vertical", confidence: 0.42, lines: 3 } },
        bubble: [80, 80, 260, 240],
        typography: { color: BLACK },
      },
      { text: "BOOM", role: "free-text", region: { bounds: [300, 300, 400, 380], confidence: 0.77, ocr: { direction: "horizontal", confidence: 0.98, lines: 1 } }, typography: {} },
      { text: "manual", points: [{ x: 0, y: 0 }, { x: 50, y: 0 }, { x: 50, y: 50 }, { x: 0, y: 50 }], typography: {} },
    ],
    project: { source_locale: "ja", target_locales: ["en"] },
  });

  const list = ok("list_text", { project: dir });
  const a = layerById(list, ids[0]);
  assert.equal(a.role, "dialogue");
  assert.equal(a.in_bubble, true);
  assert.equal(a.frame_from, "flows-in");
  assert.equal(a.typography_origin, "generated");
  assert.equal(a.ocr_confidence, 0.42);
  assert.ok(a.flags.includes("low_ocr_confidence"));
  assert.equal(layerById(list, ids[1]).role, "free-text");
  assert.equal(layerById(list, ids[2]).role, null);

  const full = ok("get_text_layer", { project: dir, layer: ids[0] });
  assert.equal(full.detection.text_region.kind, "text");
  assert.equal(full.detection.text_region.detection.labels[0].confidence, 0.91);
  assert.equal(full.detection.balloon_region.kind, "bubble");
  assert.equal(full.detection.ocr.direction, "vertical");
  assert.equal(full.detection.ocr.lines, 3);
  assert.equal(full.provenance.typography.kind, "generated");
  assert.equal(full.provenance.typography.producer, "dev.koharu.detector");
  assert.equal(full.language.source, "ja");
  assert.equal(full.language.translation, "en");

  assert.equal(ok("list_text", { project: dir, select: { role: "dialogue" } }).total, 1);
  assert.equal(ok("list_text", { project: dir, select: { in_bubble: false } }).total, 2);
  assert.equal(ok("list_text", { project: dir, select: { ocr_confidence_max: 0.6 } }).total, 1);
  assert.equal(ok("list_text", { project: dir, select: { ocr_direction: "horizontal" } }).total, 1);
  assert.equal(ok("list_text", { project: dir, select: { typography_origin: "generated" } }).total, 1);
  assert.equal(ok("list_text", { project: dir, select: { frame_from: "own" } }).total, 1);
  assert.equal(ok("list_text", { project: dir, select: { language: "en" } }).total, 3);
  assert.equal(ok("list_text", { project: dir, select: { detection_confidence_min: 0.8 } }).total, 1);

  const regions = ok("list_regions", { project: dir });
  assert.equal(regions.total, 3);
  assert.deepEqual(regions.by_kind, { text: 2, bubble: 1 });
  const bubbleText = regions.regions.find((r) => r.kind === "text" && r.inside);
  assert.equal(bubbleText.inside.kind, "bubble");
  assert.ok(bubbleText.layers.some((l) => l.relation === "recognized-from" && l.translation === "Hello!"));
  assert.equal(ok("list_regions", { project: dir, kind: "bubble" }).total, 1);
  assert.equal(ok("list_regions", { project: dir, text_contains: "boom" }).total, 1);

  const info = ok("project_info", { project: dir });
  assert.equal(info.source_language, "ja");
  assert.deepEqual(info.target_languages, ["en"]);
  assert.deepEqual(info.pages[0].regions, { text: 2, bubble: 1 });
  assert.equal(info.pages[0].roles.dialogue, 1);
  assert.equal(info.stats.roles["free-text"], 1);
  assert.equal(info.stats.ocr.below_0_6, 1);

  const check = ok("check_project", { project: dir });
  assert.equal(check.ok, true);
  assert.ok(check.components["dev.koharu.analysis.ocr"].understood);
  assert.deepEqual(check.components_not_understood, []);
});

test("text_stats breaks down borders, fill+border looks and defaults", () => {
  const { dir } = whiteOnWhiteProject();
  const stats = ok("text_stats", { project: dir });
  assert.equal(stats.borders.with_visible_border, 3);
  assert.equal(stats.borders.border_same_color_as_fill, 2);
  assert.equal(stats.borders.border_color_unset_so_white, 1);
  assert.equal(stats.borders.border_color_stored_but_no_width, 1);
  assert.equal(stats.borders.colors["#ffffff"], 3);
  assert.equal(stats.borders.widths["3"], 3);
  assert.equal(stats.colors["#ffffff"], 3);
  assert.equal(stats.colors["#000000"], 2);
  assert.equal(stats.looks["fill #ffffff | border #ffffff 3px | second border none"], 2);
  assert.equal(stats.font_weights["400"], 5);
  assert.equal(stats.flags.stroke_same_as_fill, 2);
  assert.equal(stats.typography_format_revisions["4"], 5);
});

test("compact detail is a cheap scan and full detail carries notes", () => {
  const { dir, ids } = whiteOnWhiteProject();
  const compact = JSON.parse(JSON.stringify(ok("list_text", { project: dir, detail: "compact" })));
  const row = layerById(compact, ids[1]);
  assert.deepEqual(Object.keys(row).sort(), ["fill", "flags", "id", "order", "page", "size", "stroke", "text"].sort());
  assert.equal(row.stroke, "#ffffff 3px");
  const full = ok("get_text_layer", { project: dir, layer: ids[1] });
  assert.match(full.style_notes.join(" "), /WHITE/);
  assert.equal(full.typography.stroke_color, null);
  assert.equal(full.style.stroke.color_source, "default");
});

test("batch: edits chain on the looks they create, and undo restores the project", () => {
  const { dir } = whiteOnWhiteProject();
  const before = ok("text_stats", { project: dir });
  const result = ok("batch", {
    project: dir,
    steps: [
      { tool: "set_typography", args: { select: { stroke_same_as_fill: true }, color: "#202020" } },
      { tool: "set_typography", args: { select: { color: "#202020" }, stroke_color: "#ffee00", stroke_width: 2 } },
    ],
  });
  assert.equal(result.steps[0].matched_layers, 2);
  assert.equal(result.steps[1].matched_layers, 2);
  assert.equal(ok("list_text", { project: dir, select: { stroke_color: "#ffee00", stroke_width: 2 } }).total, 2);
  ok("undo", { project: dir });
  assert.deepEqual(ok("text_stats", { project: dir }).borders, before.borders);
});
