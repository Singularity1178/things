// Builds a small synthetic .khrproj with the real codec, so tools can be tested end to end
// without Koharu-written fixtures. Layers are described as plain objects.

import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

import { KIND, USER, encodeComponent, encodeScene, encodeStateFile } from "../../src/codec.js";
import { baseTypography } from "../../src/ops.js";

const entry = (kind, value) => encodeComponent(kind, value, undefined);
const bare = (key) => ({ key, schema: 1, payload: Buffer.alloc(0), recordRefs: [], blobRefs: [] });
const sorted = (components) => components.sort((a, b) => Buffer.compare(Buffer.from(a.key), Buffer.from(b.key)));
const GENERATED = { kind: "generated", producer: "dev.koharu.detector", model: "test-model", confidence: 0.9 };

const rect = ([l, t, r, b]) => [
  { x: l, y: t },
  { x: r, y: t },
  { x: r, y: b },
  { x: l, y: b },
];

/**
 * layers: [{
 *   text, points?, typography?, revision?, layout?: {kind, angle_degrees}, role?, generated?: boolean,
 *   region?: [l,t,r,b] | { bounds, confidence?, ocr?: { direction, confidence, lines } },   // text region it fits to
 *   bubble?: [l,t,r,b],                                                                    // bubble it flows in
 * }]
 * Returns the path of the created project folder and the layer ids.
 */
export function makeProject({ width = 600, height = 900, layers, project: projectSettings }) {
  const id = () => crypto.randomUUID();
  const pageId = id();
  const groupId = id();
  const entities = [
    { id: pageId, parent: null, components: sorted([entry(KIND.PAGE, { label: "p1", width, height, chapter_start: false })]) },
    { id: groupId, parent: pageId, components: [bare(KIND.TEXT_GROUP)] },
  ];
  const relations = [];
  const ids = [];
  const relate = (kind, source, target) =>
    relations.push({ id: id(), origin: USER, kind, source, target, components: [] });

  for (const layer of layers) {
    const layerId = id();
    const contentId = id();
    ids.push(layerId);
    const origin = layer.generated ? GENERATED : USER;
    const components = [
      entry(KIND.TEXT_LAYOUT, { origin: USER, kind: layer.layout?.kind ?? "paragraph", angle_degrees: layer.layout?.angle_degrees ?? null }),
      entry(KIND.TYPOGRAPHY, { ...baseTypography(layer.revision ?? 4), origin, ...layer.typography }),
    ];
    if (layer.points) components.push(entry(KIND.GEOMETRY, { origin: USER, points: layer.points }));
    entities.push({ id: layerId, parent: groupId, components: sorted(components) });

    const contentComponents = [
      entry(KIND.TEXT_SOURCE, { text: layer.source ?? "src", origin, language: "ja" }),
      entry(KIND.TEXT_TRANSLATION, { text: layer.text, origin, language: "en" }),
    ];
    if (layer.role) contentComponents.push(entry(KIND.TEXT_ROLE, { origin, role: `dev.koharu.text.${layer.role}` }));
    entities.push({ id: contentId, parent: pageId, components: sorted([...contentComponents, entry(KIND.TEXT_CONTENT, { origin })]) });
    relate(KIND.REL_PRESENTS, layerId, contentId);

    let textRegionId = null;
    if (layer.region) {
      const spec = Array.isArray(layer.region) ? { bounds: layer.region } : layer.region;
      textRegionId = id();
      const regionComponents = [
        entry(KIND.REGION, { origin, kind: "dev.koharu.region.text", label: "text" }),
        entry(KIND.GEOMETRY, { origin, points: rect(spec.bounds) }),
        entry(KIND.DETECTION, { origin, labels: [{ kind: "dev.koharu.region.text", confidence: spec.confidence ?? 0.93 }] }),
      ];
      if (spec.ocr) {
        regionComponents.push(
          entry(KIND.OCR, {
            origin,
            direction: spec.ocr.direction ?? "auto",
            confidence: spec.ocr.confidence ?? null,
            line_boundaries: Array.from({ length: spec.ocr.lines ?? 1 }, () => rect(spec.bounds)),
          }),
        );
      }
      entities.push({ id: textRegionId, parent: pageId, components: sorted(regionComponents) });
      relate(KIND.REL_RECOGNIZED_FROM, contentId, textRegionId);
      if (!layer.bubble) relate(KIND.REL_FITS_TO, layerId, textRegionId);
    }
    if (layer.bubble) {
      const bubbleId = id();
      entities.push({
        id: bubbleId,
        parent: pageId,
        components: sorted([
          entry(KIND.REGION, { origin, kind: "dev.koharu.region.bubble", label: "bubble" }),
          entry(KIND.GEOMETRY, { origin, points: rect(layer.bubble) }),
        ]),
      });
      relate(KIND.REL_FLOWS_IN, layerId, bubbleId);
      if (textRegionId) relate(KIND.REL_INSIDE, textRegionId, bubbleId);
    }
  }
  const projectComponents = projectSettings ? [entry(KIND.PROJECT, projectSettings)] : [];
  const scene = { pageOrderEpoch: 1n, projectComponents, pages: [{ id: pageId, epoch: 1n, entities }], relations };
  const dir = path.join(fs.mkdtempSync(path.join(os.tmpdir(), "nekoharu-synth-")), "Synth.khrproj");
  fs.mkdirSync(dir, { recursive: true });
  const file = encodeStateFile({ document: id(), revision: 1n, blobs: [], payload: encodeScene(scene) });
  fs.writeFileSync(path.join(dir, "state-a.khr"), file);
  return { dir, ids };
}
